import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,shutil,argparse
source=Path(r"D:\Projects\Beat-The-House\.tmp\environment-art-layers")
work=Path(r"E:\CodexQA\BTH\workspaces\BTH-ENVART-INTEGRATION-20261114")
sys.path.insert(0,str(source/"tools"))
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
parser=argparse.ArgumentParser();parser.add_argument("package");parser.add_argument("expected_sha256");parser.add_argument("run_suffix");args=parser.parse_args()
package=Path(args.package).resolve();approved=Path(r"E:\CodexQA\BTH\workspaces\BTH-ENVART-AUDIT-20261114\packages").resolve();assert package.is_relative_to(approved)
seal=json.loads((package/"package-seal.json").read_text());assert seal["package_sha256"]==args.expected_sha256
assert hashlib.sha256("\n".join(k+" "+v["sha256"] for k,v in sorted(seal["files"].items())).encode()).hexdigest()==args.expected_sha256
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for rel,r in seal["files"].items():
 assert (package/rel).resolve().is_relative_to(package) and h(package/rel)==r["sha256"]
 assert rel.startswith("assets/art/environments/back_alley/") or rel in ("data/art/environments/back_alley.json","data/art/environments/index.json")
gas=[p for room in ("gas_station_casino","corner_store") for p in (work/("assets/art/environments/"+room)).rglob("*") if p.is_file() and not p.name.endswith(".import")]+[work/("data/art/environments/"+room+".json") for room in ("gas_station_casino","corner_store")]
before={str(p.relative_to(work)):h(p) for p in gas}
override=work/"data/environments/developer_placement_overrides.json";expected="c5c9808497ee3d4f056bb5a7f24a64524d4e59ee50e3fff106eb41e09383245f"
assert h(override)==expected and h(source/"data/environments/developer_placement_overrides.json")==expected
assert json.loads((package/"data/art/environments/index.json").read_text())["enabled"]==["gas_station_casino","corner_store","back_alley"]
layout=prepare_layout(plan_layout(root=r"E:\CodexQA\BTH",workspace=str(work),run_id="BTH-ENVART-BACK-20261114-"+args.run_suffix))
for rel,r in seal["files"].items():
 dst=work/rel;validate_layout(layout,extra_write_paths=(dst.parent,));assert not dst.is_symlink();dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(package/rel,dst);assert h(dst)==r["sha256"]
assert before=={str(p.relative_to(work)):h(p) for p in gas} and h(override)==expected
(layout.evidence/"stage.json").write_text(json.dumps({"package_sha256":args.expected_sha256,"files":seal["files"],"accepted_gas_and_corner_preserved":before,"override_sha256":expected,"target_or_source_writes":False},indent=2))
print("STAGED",len(seal["files"]),"FILES; GAS AND CORNER PRESERVED",len(gas),"OVERRIDE",expected);print(layout.evidence)
