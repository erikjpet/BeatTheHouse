from pathlib import Path
from PIL import Image,ImageChops
import os,json,hashlib
root=Path(r"E:/CodexQA/BTH/runs/BTH-ENVART-BACK-20261114-r3-animation-probe-01/evidence/probe")
out=Path(os.environ["BTH_QA_EVIDENCE_DIR"])
j=json.loads((root/"back_animation_probe.json").read_text());rows=[];failures=[]
for r in j["entries"]:
 a=Image.open(root/(r["id"]+"_live_a.png")).convert("RGB");b=Image.open(root/(r["id"]+"_live_b.png")).convert("RGB");d=ImageChops.difference(a,b)
 bands=d.split();mask=ImageChops.lighter(ImageChops.lighter(bands[0],bands[1]),bands[2]).point(lambda x:255 if x else 0)
 count=mask.histogram()[255];behind=mask.crop((1276,336,1692,436)).histogram()[255];outside=count-behind
 row={**r,"native_changed_pixels":count,"native_changed_pixels_outside_opaque_crate":outside,"difference_bbox":mask.getbbox(),"maximum_channel_delta":max(ch.getextrema()[1] for ch in bands)};rows.append(row)
 if not (count>0 and outside>0 and r["reduce_motion_stable"]):failures.append(r["id"])
assert len(rows)==23
report={"scope":"Read-only quantitative analysis of unchanged actual native per-entry renderer PNGs. Opaque crate rectangle is production638,168,208,50 at2x. Counts prove changed pixels outside that front, not arbitrary brightness inflation or full-game end-to-end.","checks":len(rows)*3,"failures":failures,"entries":rows,"source_probe":str(root/"back_animation_probe.json")}
p=out/"back-r3-motion-pixel-analysis.json";p.write_text(json.dumps(report,indent=2));print(json.dumps({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"checks":report["checks"],"failures":failures,"right_glint":next(r for r in rows if r["id"]=="warm_glint_1")}));raise SystemExit(1 if failures else 0)
