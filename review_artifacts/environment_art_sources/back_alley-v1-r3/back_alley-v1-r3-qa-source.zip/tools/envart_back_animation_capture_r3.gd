extends "res://tools/environment_art_baseline_capture.gd"
const PreviewCanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
const PreviewPackScript := preload("res://scripts/ui/environment_art_pack.gd")
func _run() -> void:
    var admitted_evidence := OS.get_environment("BTH_QA_EVIDENCE_DIR").replace("\\", "/")
    var normalized_output := out_dir.replace("\\", "/")
    if admitted_evidence.is_empty() or not normalized_output.begins_with(admitted_evidence + "/"):
        push_error("Capture output must be an explicit child of this admitted run evidence directory.")
        quit(1)
        return
    var archetype := "back_alley"
    var layer := ""
    var scenario := "__none"
    var excerpt_seconds := -1.0
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--excerpt-seconds="):
            excerpt_seconds = float(argument.trim_prefix("--excerpt-seconds="))
        elif argument.begins_with("--archetype="):
            archetype = argument.trim_prefix("--archetype=")
        elif argument.begins_with("--layer="):
            layer = argument.trim_prefix("--layer=")
        elif argument.begins_with("--scenario="):
            scenario = argument.trim_prefix("--scenario=")
    DirAccess.make_dir_recursive_absolute(out_dir)
    root.size = Vector2i(1280, 720)
    app = MainScene.instantiate()
    app.set("script_prewarm_stopping", true)
    root.add_child(app)
    await _settle(8)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id", app.get("environment_test_archetype_option"), archetype)
    app.call("_refresh_environment_test_identity_options")
    app.call("_environment_test_select_id", app.get("environment_test_scenario_option"), scenario)
    if not layer.is_empty():
        app.call("_environment_test_select_id", app.get("environment_test_layer_option"), layer)
    app.get("environment_test_seed_input").text = SEED_TEXT
    var generated: Dictionary = app.call("start_environment_test_session")
    if not bool(generated.get("ok", false)):
        push_error("Preview room generation failed: " + str(generated))
        quit(1)
        return
    var canvas: Control = app.get("environment_canvas")
    for _index in range(180):
        await process_frame
        if canvas.get("environment_art_pack") != null:
            break
    if canvas.get("environment_art_pack") == null:
        push_error("Preview candidate art pack did not load.")
        quit(1)
        return
    await _settle(8)
    # Await production actor arrival, then create a native900 board from the exact
    # same live production snapshot. This is a separate actual render, never a resize.
    var arrival := await _settle_production_arrivals(canvas)
    if int(arrival["remaining_person_transits"]) != 0:
        push_error("Production room actors did not finish arriving.")
        quit(1)
        return
    var board900_view := SubViewport.new()
    board900_view.size = Vector2i(900, 430)
    board900_view.disable_3d = true
    board900_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    root.add_child(board900_view)
    var board900_canvas: Control = PreviewCanvasScript.new()
    board900_canvas.size = Vector2(900, 430)
    board900_view.add_child(board900_canvas)
    board900_canvas.call("render_environment_snapshot", canvas.get("foundation_snapshot"))
    var board_arrival := await _settle_production_arrivals(board900_canvas)
    if int(board_arrival["remaining_person_transits"]) != 0:
        push_error("Native900 board actors did not finish arriving.")
        quit(1)
        return
    # Align only the QA clone clocks once to the production canvas. Production
    # state, clock and motion remain untouched; both then run autonomously.
    board900_canvas.set("flicker", canvas.get("flicker"))
    board900_canvas.set("actor_route_time", canvas.get("actor_route_time"))
    # One real input event through the owned viewport, before autonomous recording.
    # Park on the canvas margin, not a live object; do not warp the desktop cursor.
    var neutral_pointer := InputEventMouseMotion.new()
    neutral_pointer.position = canvas.get_global_rect().position + Vector2(3, 3)
    neutral_pointer.global_position = neutral_pointer.position
    root.push_input(neutral_pointer, true)
    await process_frame
    neutral_pointer = InputEventMouseMotion.new()
    neutral_pointer.position = Vector2(900, 100) # Description HUD gap, not a live object.
    neutral_pointer.global_position = neutral_pointer.position
    root.push_input(neutral_pointer, true)
    await _settle(2)
    var pack: EnvironmentArtPack = canvas.get("environment_art_pack")
    var max_cycle := 3.0
    var max_fps := 5.0
    var inventory: Array = []
    for entry in pack.animations:
        var cycle := 0.0
        match entry.kind:
            PreviewPackScript.AnimationKind.FRAMES:
                cycle = float(entry.frame_count if entry.loop_mode != PreviewPackScript.LoopMode.PINGPONG else maxi(1, (entry.frame_count - 1) * 2)) / entry.fps
                max_fps = maxf(max_fps, entry.fps)
            PreviewPackScript.AnimationKind.PULSE, PreviewPackScript.AnimationKind.SWEEP:
                cycle = entry.period
            PreviewPackScript.AnimationKind.MOVER:
                cycle = entry.duration + entry.gap
            PreviewPackScript.AnimationKind.SCROLL:
                if entry.speed.x != 0.0:
                    cycle = maxf(cycle, entry.rect.size.x / absf(entry.speed.x))
                if entry.speed.y != 0.0:
                    cycle = maxf(cycle, entry.rect.size.y / absf(entry.speed.y))
        max_cycle = maxf(max_cycle, cycle)
        inventory.append({"id": entry.id, "kind": entry.kind, "cycle_seconds": cycle, "frame_count": entry.frame_count, "fps": entry.fps, "texture_size": [entry.texture.get_width(), entry.texture.get_height()], "rect": [entry.rect.position.x, entry.rect.position.y, entry.rect.size.x, entry.rect.size.y], "from": [entry.from_point.x, entry.from_point.y], "to": [entry.to_point.x, entry.to_point.y], "size": [entry.size.x, entry.size.y], "origin": [entry.origin.x, entry.origin.y], "clip": [entry.clip.position.x, entry.clip.position.y, entry.clip.size.x, entry.clip.size.y] if entry.has_clip else [], "web_low_detail": entry.web_low_detail})
    var capture_seconds := minf(20.0, max_cycle + 0.25)
    if excerpt_seconds > 0.0:
        capture_seconds = minf(capture_seconds, excerpt_seconds)
    var sample_fps := minf(20.0, maxf(10.0, max_fps * 2.0))
    var frame_count := ceili(capture_seconds * sample_fps)
    var before: Dictionary = canvas.call("current_view_snapshot")
    var board_before: Dictionary = board900_canvas.call("current_view_snapshot")
    await RenderingServer.frame_post_draw
    root.get_texture().get_image().save_png(out_dir.path_join("settled_play.png"))
    board900_view.get_texture().get_image().save_png(out_dir.path_join("settled_board900.png"))
    var board_renderer: Node = canvas.get("environment_art_renderer")
    if board_renderer == null or not bool(board_renderer.get("ready_to_present")):
        push_error("Production native art renderer is not ready.")
        app.queue_free()
        await process_frame
        quit(1)
        return
    var frames: Array = []
    var board_equivalence: Array = []
    var first_frame_clock := -1.0
    for index in range(frame_count):
        if first_frame_clock >= 0.0 and float(canvas.get("flicker")) - first_frame_clock >= capture_seconds:
            break
        await create_timer(1.0 / sample_fps).timeout
        await RenderingServer.frame_post_draw
        var production_view: Dictionary = canvas.call("current_view_snapshot")
        var clone_view: Dictionary = board900_canvas.call("current_view_snapshot")
        board_equivalence.append({"frame": index, "object_layout_equal": production_view["object_layout"] == clone_view["object_layout"], "objects_equal": production_view["objects"] == clone_view["objects"], "animation_clock_equal": float(canvas.get("flicker")) == float(board900_canvas.get("flicker")), "actor_route_clock_equal": float(canvas.get("actor_route_time")) == float(board900_canvas.get("actor_route_time"))})
        var name := "frame_%03d.png" % index
        var img := root.get_texture().get_image()
        var error := img.save_png(out_dir.path_join(name))
        if error != OK:
            push_error("Preview frame write failed: " + name)
            quit(1)
            return
        var board900_name := "board900_%03d.png" % index
        var board900_error := board900_view.get_texture().get_image().save_png(out_dir.path_join(board900_name))
        if board900_error != OK:
            push_error("Native900 board frame write failed: " + board900_name)
            quit(1)
            return
        var board_name := "board2x_%03d.png" % index
        var board_img := (board_renderer.get("texture") as Texture2D).get_image()
        var board_error := board_img.save_png(out_dir.path_join(board_name))
        if board_error != OK:
            push_error("Native2x board frame write failed: " + board_name)
            quit(1)
            return
        var states: Array = []
        var clock: float = canvas.get("flicker")
        if first_frame_clock < 0.0:
            first_frame_clock = clock
        for entry in pack.animations:
            states.append({"id": entry.id, "frame": entry.frame_at(clock, false), "pulse": entry.pulse_at(clock, false), "mover_visible": entry.mover_visible_at(clock, false), "mover": str(entry.mover_at(clock, false)), "scroll": str(entry.scroll_at(clock, false)), "sweep": str(entry.sweep_at(clock, false))})
        frames.append({"file": name, "board900_file": board900_name, "board900_clock": board900_canvas.get("flicker"), "board2x_file": board_name, "clock": clock, "width": img.get_width(), "height": img.get_height(), "animation_states": states})
    var after: Dictionary = canvas.call("current_view_snapshot")
    var result := {"board900_equivalence": board_equivalence, "board900_is_qa_clone": true, "actual_arrival_wait": arrival, "board900_arrival_wait": board_arrival, "board900_before": board_before, "board900_after": board900_canvas.call("current_view_snapshot"), "board900_size": [900,430], "board900_source": "Separate actual production PixelSceneCanvas rendered from the same settled RunState snapshot, with presentation and actor-route clocks aligned once before recording, then normal autonomous progression; includes counters, objects and labels. This clone is diagnostic; fullapp and1800-art frames come from the unchanged actual production app.", "archetype": archetype, "layer": layer, "scenario": scenario, "seed": SEED_TEXT, "pack_active": canvas.get("environment_art_pack") != null, "frames": frames, "before": before, "after": after, "preview_only": true, "sample_fps": sample_fps, "capture_seconds_requested": capture_seconds, "actual_clock_span": float(frames[-1]["clock"]) - float(frames[0]["clock"]), "measured_frame_count": frames.size(), "max_animation_cycle": max_cycle, "cycle_capped": capture_seconds < max_cycle, "animation_inventory": inventory, "board2x_size": [1800,860], "native_art_layers_only": true, "native_art_source": "actual production canvas environment_art_renderer.texture", "note": "Actual production practice full UI plus its exact native1800x860 background-animation render target. Native art view excludes counter fronts/live objects; full UI retains them. A neutral owned-viewport mouse motion precedes recording; no pointer input during capture, synthetic animation or raster resizing. Desktop cursor is not moved. Nearest filter retained."}
    # Actual production accessibility setting/application route, in this isolated
    # run only. No geometry, asset, animation cadence or process flags are edited.
    var settings: Variant = app.get("user_settings")
    settings.reduce_motion = true
    app.call("_on_settings_applied")
    await _settle(8)
    canvas = app.get("environment_canvas")
    var reduced_view: Dictionary = canvas.call("current_view_snapshot")
    await RenderingServer.frame_post_draw
    var reduced_image := root.get_texture().get_image()
    reduced_image.save_png(out_dir.path_join("reduce_motion_play.png"))
    var reduced_renderer: Node = canvas.get("environment_art_renderer")
    var reduced_board := (reduced_renderer.get("texture") as Texture2D).get_image()
    reduced_board.save_png(out_dir.path_join("reduce_motion_board2x.png"))
    await create_timer(0.5).timeout
    await RenderingServer.frame_post_draw
    var reduced_image_after := root.get_texture().get_image()
    reduced_image_after.save_png(out_dir.path_join("reduce_motion_play_after.png"))
    var reduced_board_after := (reduced_renderer.get("texture") as Texture2D).get_image()
    result["reduce_motion"] = {"actual_setting_route": "QA-only user_settings.reduce_motion=true followed by unchanged _on_settings_applied; no owner setting file saved.", "active": bool(reduced_view.get("reduce_motion", false)), "actual_canvas_view": reduced_view, "full_app_pixels_stable": reduced_image.get_data() == reduced_image_after.get_data(), "production_art_texture_pixels_stable": reduced_board.get_data() == reduced_board_after.get_data(), "wait_seconds": 0.5, "full_app_file": "reduce_motion_play.png", "native_art_file": "reduce_motion_board2x.png"}
    var file := FileAccess.open(out_dir.path_join("animation_capture.json"), FileAccess.WRITE)
    file.store_string(JSON.stringify(result, "\t"))
    file.close()
    print("ENVART_ANIMATION_CAPTURE ", JSON.stringify({"frame_count": frames.size(), "art_id": canvas.get("environment_id"), "out": out_dir}))
    board900_view.free()
    app.queue_free()
    await process_frame
    quit(0)

func _settle_production_arrivals(canvas: Control) -> Dictionary:
    var clock_before: float = canvas.get("flicker")
    var waited := 0.0
    await create_timer(4.0).timeout
    waited = 4.0
    while not (canvas.get("person_transits") as Dictionary).is_empty() and waited < 12.0:
        await create_timer(0.25).timeout
        waited += 0.25
    await RenderingServer.frame_post_draw
    return {"clock_before": clock_before, "clock_after": canvas.get("flicker"), "timer_wait_seconds": waited, "remaining_person_transits": (canvas.get("person_transits") as Dictionary).size(), "input_during_wait": false, "positions_modified": false}
