extends "res://tools/envart_back_settled_r3.gd"
func _run() -> void:
    if baseline_source.is_empty() or not FileAccess.file_exists(baseline_source):
        push_error("Back sequence proof requires exactPhase0canvas source")
        quit(1)
        return
    DirAccess.make_dir_recursive_absolute(out_dir)
    root.size=Vector2i(1280,720)
    app=MainScene.instantiate()
    app.set("script_prewarm_stopping",true)
    root.add_child(app)
    await _settle(8)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id",app.get("environment_test_archetype_option"),"back_alley")
    app.call("_refresh_environment_test_identity_options")
    var catalog: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tools/envart_back_sequence_cases.json"))
    var cases: Array=catalog["cases"]
    for argument in OS.get_cmdline_user_args():
        if argument == "--smoke-back-work":
            cases = cases.filter(func(c): return c["scenario_id"] == "back_alley_street_craps" and c.get("phase", "") == "work")
    catalog = catalog.duplicate(true)
    catalog["cases"] = cases
    var library: Variant=app.get("library")
    var definitions:=_rw06_1_review_definitions(library,cases)
    var original:=GDScript.new()
    original.source_code=FileAccess.get_file_as_string(baseline_source).replace("class_name PixelSceneCanvas","class_name EnvartBackSequenceOriginalCanvas")
    if original.reload()!=OK:
        quit(1)
        return
    var completed: Array=[]
    var serial:=0
    for scenario_value in definitions.keys():
        var scenario:=str(scenario_value)
        var definition: Dictionary=definitions[scenario]
        app.call("_environment_test_select_id",app.get("environment_test_scenario_option"),scenario)
        app.get("environment_test_seed_input").text=SEED_TEXT
        var generated: Dictionary=app.call("start_environment_test_session")
        _check(bool(generated.get("ok",false)),"Initial production practice generation: "+scenario)
        if not bool(generated.get("ok",false)):
            continue
        await _settle(8)
        var run_state: Variant=app.get("run_state")
        var initial_environment: Dictionary=run_state.current_environment.duplicate(true)
        var initial_state: Dictionary=initial_environment.get("scenario_sequence_state",{}).duplicate(true)
        for case_value in cases:
            var test_case: Dictionary=case_value
            if test_case["scenario_id"]!=scenario:
                continue
            var name_value:=scenario+"__"+str(test_case["kind"])+"_"+str(test_case.get("outcome",test_case.get("phase","")))
            var state:=initial_state.duplicate(true)
            var transactions: Array=[]
            var ok:=true
            for command_value in test_case["commands"]:
                var applied:=_rw06_1_apply_trace_command(state,definition,str(command_value),serial,transactions.size())
                serial+=1
                _check(bool(applied.get("ok",false)),name_value+" authoredcommand "+str(command_value)+": "+str(applied.get("errors",[])))
                transactions.append({"command":command_value,"ok":applied.get("ok",false),"errors":applied.get("errors",[])})
                if not bool(applied.get("ok",false)):
                    ok=false
                    break
                state=_dict(applied.get("state",{}))
            if ok and test_case.has("fact"):
                var applied:=_rw06_1_apply_trace_fact(state,definition,test_case["fact"],serial,transactions.size())
                serial+=1
                _check(bool(applied.get("ok",false)),name_value+" supportedfacttransaction: "+str(applied.get("errors",[])))
                transactions.append({"fact":test_case["fact"],"ok":applied.get("ok",false),"errors":applied.get("errors",[])})
                ok=bool(applied.get("ok",false))
                if ok:
                    state=_dict(applied.get("state",{}))
            if not ok:
                report[name_value]={"case":test_case,"transactions":transactions,"prepared":false}
                continue
            var identity_ok: bool=(str(state.get("status",""))=="aftermath" and _array(state.get("resolved_outcomes",[])).has(test_case.get("outcome",""))) if test_case["kind"]=="aftermath" else (str(state.get("status",""))=="active" and str(state.get("phase_id",""))==test_case["phase"])
            _check(identity_ok,name_value+" exactstatus/phase/outcome identity")
            var candidate := initial_environment.duplicate(true)
            var committed := ScenarioEngineScript._commit_sequence_candidate(candidate, candidate.duplicate(true), definition, {"ok":true,"state":state,"errors":[]})
            _check(bool(committed.get("ok",false)), name_value+" unchanged production engine commit: "+str(committed.get("errors",[])))
            var resolved: Dictionary = run_state.call("_publish_scenario_membership_candidate",candidate,committed,"qa_authored_state") if bool(committed.get("ok",false)) else committed
            _check(bool(resolved.get("ok",false)),name_value+" existingproductionseam resolves sealed snapshot: "+str(resolved.get("errors",[])))
            if not bool(resolved.get("ok",false)):
                report[name_value]={"case":test_case,"transactions":transactions,"prepared":false,"resolve_errors":resolved.get("errors",[])}
                continue
            var live_authority: Dictionary = run_state.call("validate_room_action_authority")
            _check(bool(live_authority.get("ok",false)), name_value+" causal live room authority: "+str(live_authority.get("errors",[])))
            app.call("_set_current_screen","ENVIRONMENT")
            app.call("_clear_selected_game_action")
            app.call("_render_environment_screen")
            await _settle(8)
            var canvas: Control=app.get("environment_canvas")
            var arrival := await _settle_production_arrivals(canvas)
            _check(int(arrival["remaining_person_transits"]) == 0, name_value+" actual actor arrival completed")
            var snapshot: Dictionary=canvas.get("foundation_snapshot")
            var actual_state: Dictionary=snapshot.get("scenario_sequence_state",{})
            var actual_identity: bool=str(actual_state.get("status",""))==str(state.get("status","")) and _array(actual_state.get("resolved_outcomes",[]))==_array(state.get("resolved_outcomes",[])) and str(actual_state.get("phase_id",""))==str(state.get("phase_id",""))
            _check(actual_identity,name_value+" actualapp retains preparedphase/outcome")
            var authority: Dictionary=snapshot.get("scenario_layout_authority",{})
            var actual_view: Dictionary = canvas.call("current_view_snapshot")
            var actual_objects: Array = actual_view.get("objects",[])
            var actual_geometry: Array = actual_view.get("object_layout",{}).get("objects",[])
            var material_evidence: Dictionary = {}
            for expected_value in test_case["expected_material_ids"]:
                var identity := "scenario::"+str(expected_value)
                var authority_row: Dictionary = authority.get(identity,{})
                var object_id := str(authority_row.get("presentation_object_id",identity))
                var matches: Array = actual_objects.filter(func(o): return str(o.get("id","")) == object_id)
                var geometry_matches: Array = actual_geometry.filter(func(o): return str(o.get("id","")) == object_id)
                _check(not authority_row.is_empty(), name_value+" expected authority present: "+identity)
                _check(matches.size()==1 and geometry_matches.size()==1, name_value+" expected actual rendered object and geometry: "+identity)
                var label := str(matches[0].get("label","")) if matches.size()==1 else ""
                var label_rect: Dictionary = geometry_matches[0].get("label_rect",{}) if geometry_matches.size()==1 else {}
                _check(not label.is_empty() and float(label_rect.get("w",0))>0 and float(label_rect.get("h",0))>0, name_value+" expected actual label and nonempty rectangle: "+identity)
                material_evidence[identity] = {"authority":authority_row,"object_id":object_id,"actual_objects":matches,"actual_geometry":geometry_matches,"label":label}
            var source_visual_evidence: Array = []
            for visual_value in resolved.get("renderer_snapshot",{}).get("visual_objects",[]):
                var visual: Dictionary = visual_value
                var object_id := str(visual.get("object_id",""))
                var matches: Array = actual_objects.filter(func(o): return str(o.get("id","")) == object_id)
                var geometry_matches: Array = actual_geometry.filter(func(o): return str(o.get("id","")) == object_id)
                var visible: bool = bool(visual.get("visible",true)) and str(visual.get("presentation_mode","room")) == "room"
                var source_label := str(visual.get("label",""))
                var semantic: Dictionary = snapshot.get("scenario_sequence_state",{}).get("semantic_state",{})
                var interaction: Dictionary = semantic.get("interactions",{}).get(object_id,{})
                var present_interaction: bool = not interaction.is_empty() and bool(interaction.get("present",true))
                var expected_label := str(interaction.get("label",source_label)) if present_interaction else source_label
                var published: Array = snapshot.get("interactable_objects",[]).filter(func(o): return str(o.get("object_id","")) == object_id)

                var actual_label := str(matches[0].get("label","")) if matches.size()==1 else ""
                var label_rect: Dictionary = geometry_matches[0].get("label_rect",{}) if geometry_matches.size()==1 else {}
                if visible:
                    _check(matches.size()==1 and geometry_matches.size()==1, name_value+" every source-visible visual reaches actual canvas geometry: "+object_id)
                    _check(published.size()==1 and str(published[0].get("label",""))==expected_label, name_value+" exact source-composed label published: "+object_id)
                    _check(not expected_label.is_empty() and actual_label==expected_label and float(label_rect.get("w",0))>0 and float(label_rect.get("h",0))>0, name_value+" exact production label reaches actual canvas: "+object_id)
                source_visual_evidence.append({"id":object_id,"source_visual":visual,"room_visible":visible,"source_label":source_label,"expected_final_label":expected_label,"interaction_label":interaction.get("label"),"present_interaction":present_interaction,"published_objects":published,"actual_label":actual_label,"actual_objects":matches,"actual_geometry":geometry_matches,"exclusion":"" if visible else "Source explicitly hidden or non-room presentation; no in-room label claim."})
            await RenderingServer.frame_post_draw
            root.get_texture().get_image().save_png(out_dir.path_join(name_value+"_play.png"))
            var pair:=await _compare_pair(original,snapshot,name_value)
            var reduced:=snapshot.duplicate(true)
            reduced["reduce_motion"]=true
            var still_pair:=await _compare_pair(original,reduced,name_value+"_reduced")
            report[name_value]={"case":test_case,"transactions":transactions,"prepared":true,"actual_arrival_wait":arrival,"snapshot":snapshot,"comparison":pair,"reduce_motion_comparison":still_pair,"state_status":actual_state.get("status"),"resolved_outcomes":actual_state.get("resolved_outcomes",[]),"phase":actual_state.get("phase_id"),"authority_keys":authority.keys(),"live_authority":live_authority,"material_evidence":material_evidence,"actual_view":actual_view,"source_visual_evidence":source_visual_evidence}
            completed.append(name_value)
            print("BACK_SEQUENCE_CAPTURED ",name_value)
    _check(completed.size()==cases.size(),"All declared contexts captured")
    var file:=FileAccess.open(out_dir.path_join("back_sequence_live_proof.json"),FileAccess.WRITE)
    file.store_string(JSON.stringify({"checks":checks,"findings":findings,"case_catalog":catalog,"completed":completed,"views":report,"scope":"QA-owned valid Runtime command/fact transactions followed by unchanged production ScenarioEngine commit and RunState physical-membership publication; actual canvas object/label/geometry assertions. Not UI-click end-to-end/revisit/save coverage."},"\t"))
    file.close()
    print("ENVART_BACK_SEQUENCE_PROOF ",JSON.stringify({"checks":checks,"findings":findings,"completed":completed.size(),"expected":cases.size()}))
    app.queue_free()
    await process_frame
    quit(0 if findings.is_empty() else 1)
