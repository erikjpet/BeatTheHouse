extends SceneTree
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const CanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
class FixtureCanvas:
    extends CanvasScript
    var replay := false
    var front := {"foreground_art_id": "back_alley_crate_display", "id": "right_crate_display", "x0": 638, "x1": 846, "top_y": 168, "front_y": 218}
    func _ensure_room_surface_draw_cache() -> void:
        room_surface_counters_by_id_cache = {"right_crate_display": front}
        room_surface_slots_by_id_cache = {"fixed.qa_counter_person": {"support_id": "right_crate_display"}}
    func _draw() -> void:
        flicker = 0.0
        _scale_canvas()
        _bg()
        _draw_environment_art_animations(environment_art_pack)
        _draw_counter_foreground_art(front)
        _draw_named_character("nell", Vector2(740, 200), 1.0, "staff", "left")
        if replay:
            _draw_room_foreground_occluders([{"slot_id": "fixed.qa_counter_person"}])
        draw_string(ThemeDB.fallback_font, Vector2(10, 426), "QA-ONLY COUNTER PERSON FIXTURE. Production clerk/placement unchanged.", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color.WHITE)
        draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
var output := ""
func _initialize() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--out="):
            output = argument.trim_prefix("--out=")
    call_deferred("_run")
func _run() -> void:
    DirAccess.make_dir_recursive_absolute(output)
    var pack := PackScript.load_pack("back_alley")
    if pack == null:
        push_error("Actual trial pack failed to load")
        quit(1)
        return
    var view := SubViewport.new()
    view.size = Vector2i(1800, 860)
    view.disable_3d = true
    view.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
    view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    root.add_child(view)
    var canvas := FixtureCanvas.new()
    canvas.size = Vector2(1800, 860)
    canvas.environment_id = "back_alley"
    view.add_child(canvas)
    canvas.call("_set_environment_art_pack", pack)
    var without := await _image(view)
    without.save_png(output.path_join("qa_counter_person_without_replay.png"))
    canvas.replay = true
    canvas.queue_redraw()
    var with_replay := await _image(view)
    with_replay.save_png(output.path_join("qa_counter_person_with_replay.png"))
    var region := Rect2i(1276, 336, 416, 100)
    var counter_image: Image = pack.counters["back_alley_crate_display"].texture.get_image()
    var mismatch := 0
    var body_pixels_covered := 0
    var alpha_min := 1.0
    var alpha_max := 0.0
    for y in range(100):
        for x in range(416):
            var expected := counter_image.get_pixel(x, y)
            var actual := with_replay.get_pixel(region.position.x + x, region.position.y + y)
            alpha_min = minf(alpha_min, expected.a)
            alpha_max = maxf(alpha_max, expected.a)
            if absf(actual.r - expected.r) > 0.008 or absf(actual.g - expected.g) > 0.008 or absf(actual.b - expected.b) > 0.008:
                mismatch += 1
            if without.get_pixel(region.position.x + x, region.position.y + y) != actual:
                body_pixels_covered += 1
    var torso_unchanged := true
    for y in range(250, 320):
        for x in range(1420, 1540):
            if without.get_pixel(x, y) != with_replay.get_pixel(x, y):
                torso_unchanged = false
    var result := {"qa_only": true, "production_objects_moved": false, "synthetic_person": "Nell painter at QA-only canonical fixture740,200; not production clerk", "counter_id": "back_alley_crate_display", "board_rect": [638,168,208,50], "native_rect": [1276,336,416,100], "counter_texture_size": [counter_image.get_width(),counter_image.get_height()], "counter_alpha_extrema": [alpha_min,alpha_max], "counter_pixel_mismatches": mismatch, "body_pixels_covered": body_pixels_covered, "torso_pixels_unchanged": torso_unchanged, "production_replay_method": "_draw_room_foreground_occluders", "production_override_file_changed": false}
    var file := FileAccess.open(output.path_join("counter_person_fixture.json"), FileAccess.WRITE)
    file.store_string(JSON.stringify(result, "\t"))
    file.close()
    print("ENVART_COUNTER_PERSON_FIXTURE ",JSON.stringify(result))
    view.free()
    PackScript.shutdown_loading()
    await process_frame
    quit(0 if mismatch == 0 and body_pixels_covered > 0 and torso_unchanged else 1)
func _image(view: SubViewport) -> Image:
    for _index in range(6):
        await process_frame
        await RenderingServer.frame_post_draw
    return view.get_texture().get_image()
