extends SceneTree
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const RendererScript := preload("res://scripts/ui/environment_art_renderer.gd")
var output := ""
var checks := 0
var failures: Array[String] = []
func _initialize() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--out="):
            output = argument.trim_prefix("--out=")
    call_deferred("_run")
func _run() -> void:
    DirAccess.make_dir_recursive_absolute(output)
    var pack := PackScript.load_pack("back_alley")
    if pack == null:
        quit(1)
        return
    var base_pack := PackScript.new()
    base_pack.environment_id = pack.environment_id
    base_pack.background = pack.background
    base_pack.background_rect = pack.background_rect
    var base_renderer := RendererScript.new()
    root.add_child(base_renderer)
    base_renderer.configure(base_pack)
    var base := await _render(base_renderer,0.0,false)
    base.save_png(output.path_join("floor_wrap_control.png"))
    var rows: Array = []
    for entry in pack.animations:
        if not entry.id.begins_with("floor_glint_"):
            continue
        var index := int(entry.id.trim_prefix("floor_glint_"))
        var speed := (entry.to_point.x-entry.from_point.x)/entry.duration
        var expected_speed := 18.0 + 2.5*index
        var anchor := 2.0*(entry.duration+entry.gap)-entry.phase
        var before_clock := anchor-0.001
        var after_clock := anchor+0.001
        var midpoint_clock := anchor-entry.duration*0.5
        var before_position := entry.mover_at(before_clock,false)
        var after_position := entry.mover_at(after_clock,false)
        _check(entry.kind==PackScript.AnimationKind.MOVER,entry.id+" uses actual mover")
        _check(is_equal_approx(speed,expected_speed),entry.id+" preserves original speed")
        _check(is_equal_approx(entry.from_point.y,274.0+14.0*(index%4)),entry.id+" preserves floor row")
        _check(is_equal_approx(entry.phase,float(index*137)/expected_speed),entry.id+" preserves phase")
        _check(absf(before_position.x-(entry.to_point.x-speed*0.001))<0.05,entry.id+" reaches exit before wrap")
        _check(absf(after_position.x-(entry.from_point.x+speed*0.001))<0.05,entry.id+" resets after wrap")
        var solo := PackScript.new()
        solo.environment_id=pack.environment_id
        solo.background=pack.background
        solo.background_rect=pack.background_rect
        solo.animations.append(entry)
        var renderer := RendererScript.new()
        root.add_child(renderer)
        renderer.configure(solo)
        var before := await _render(renderer,before_clock,false)
        var after := await _render(renderer,after_clock,false)
        var middle := await _render(renderer,midpoint_clock,false)
        var reduced := await _render(renderer,midpoint_clock,true)
        before.save_png(output.path_join(entry.id+"_before_wrap.png"))
        after.save_png(output.path_join(entry.id+"_after_wrap.png"))
        middle.save_png(output.path_join(entry.id+"_visible_midpoint.png"))
        _check(before.get_data()==base.get_data(),entry.id+" offscreen exit has no stray wrap pixels")
        _check(after.get_data()==base.get_data(),entry.id+" offscreen restart has no stray wrap pixels")
        _check(middle.get_data()!=base.get_data(),entry.id+" actual glint visible inside floor")
        _check(reduced.get_data()==base.get_data(),entry.id+" hides correctly with Reduce Motion")
        rows.append({"id":entry.id,"speed":speed,"phase":entry.phase,"duration":entry.duration,"y":entry.from_point.y,"before_clock":before_clock,"after_clock":after_clock,"midpoint_clock":midpoint_clock,"before_position":str(before_position),"after_position":str(after_position),"actual_midpoint_pixels_differ":middle.get_data()!=base.get_data(),"clean_offscreen_wrap":before.get_data()==base.get_data() and after.get_data()==base.get_data(),"reduce_motion_hidden":reduced.get_data()==base.get_data()})
        renderer.free()
        await process_frame
    _check(rows.size()==7,"all seven floor glints checked")
    var result := {"qa_only":true,"asset_or_manifest_modified":false,"renderer":"actual EnvironmentArtRenderer","checks":checks,"failures":failures,"glints":rows,"note":"Fixed-clock actual renderer proof is separate from normal10-12second runtime excerpt. No accelerated GIF or preview-only opacity change. Seven Back Alley slow floor glints only; eight90px/s ground streaks have a separate visible-edge wrap proof."}
    var file := FileAccess.open(output.path_join("floor_wrap_probe.json"),FileAccess.WRITE)
    file.store_string(JSON.stringify(result,"\t"))
    file.close()
    print("ENVART_FLOOR_WRAP_PROBE ",JSON.stringify({"checks":checks,"failures":failures,"glints":rows.size()}))
    base_renderer.free()
    PackScript.shutdown_loading()
    await process_frame
    quit(0 if failures.is_empty() else 1)
func _render(renderer: Node,clock: float,reduced: bool) -> Image:
    renderer.present(clock,reduced,false)
    for _index in range(3):
        await process_frame
        await RenderingServer.frame_post_draw
    return (renderer.get("texture") as Texture2D).get_image()
func _check(ok: bool,label: String) -> void:
    checks+=1
    if not ok:
        failures.append(label)
        push_error(label)
