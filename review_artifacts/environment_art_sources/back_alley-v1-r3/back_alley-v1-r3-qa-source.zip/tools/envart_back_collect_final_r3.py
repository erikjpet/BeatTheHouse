import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,os,shutil,struct,datetime
W=Path(os.environ['BTH_QA_WORKSPACE']);out=Path(os.environ['BTH_QA_EVIDENCE_DIR']);S=Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers');R=Path(r'E:/CodexQA/BTH/runs');prefix='BTH-ENVART-BACK-20261114-'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
P=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-AUDIT-20261114/packages/back_alley-v1-r3');seal=read(P/'package-seal.json');expected='f42919a146d4fdc17d7cd120ef926b44f6ccaefabcaf6a8a171e805db2150b68'
assert seal['package_sha256']==expected==hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(seal['files'].items())).encode()).hexdigest()
for rel,row in seal['files'].items():assert h(P/rel)==row['sha256']==h(W/rel),rel
stage=read(R/(prefix+'r3-stage-01')/'evidence/stage.json')
for rel,digest in stage['accepted_gas_and_corner_preserved'].items():assert h(W/rel)==digest,rel
logic={}
for directory in ['scripts','scenes']:
 for f in (S/directory).rglob('*'):
  if f.is_file() and f.suffix in ['.gd','.tscn']:
   rel=f.relative_to(S);assert h(W/rel)==h(f),str(rel);logic[str(rel)]=h(f)
for rel in ['data/environments/developer_placement_overrides.json','data/environments/placement_surfaces.json','data/environments/archetypes.json','data/environments/scenarios.json','data/environments/scenario_sequences/env06_7_shops_streets.json','project.godot','export_presets.cfg']:
 assert h(W/rel)==h(S/rel),rel;logic[rel]=h(W/rel)
assert logic['data/environments/developer_placement_overrides.json']=='c5c9808497ee3d4f056bb5a7f24a64524d4e59ee50e3fff106eb41e09383245f'
refs={'settled':'r3-settled-01/evidence/proof/back_proof.json','sequences':'r3-live-sequences-01/evidence/proof/back_sequence_live_proof.json','animations':'r3-animation-probe-01/evidence/probe/back_animation_probe.json','slow_wrap':'r3-floor-wrap-01/evidence/probe/floor_wrap_probe.json','fast_wrap':'r3-ground-wrap-01/evidence/probe/ground_streak_wrap_probe.json','counter':'r3-counter-01/evidence/probe/counter_person_fixture.json','actual_motion':'r3-preview-01/evidence/frames/animation_capture.json','pixel_motion':'r3-motion-pixels-01/evidence/back-r3-motion-pixel-analysis.json','pixel_wrap':'r3-wrap-pixels-01/evidence/back-r3-fast-wrap-pixel-audit.json','capture_integrity':'r3-capture-integrity-01/evidence/back-r3-capture-integrity.json'}
reports={};data={}
for key,rel in refs.items():
 p=R/(prefix+rel);reports[key]={'path':str(p),'sha256':h(p)};data[key]=read(p)
for key in ['settled','sequences']:assert not data[key]['findings']
for key in ['animations','slow_wrap','fast_wrap','pixel_motion','pixel_wrap']:assert not data[key]['failures']
assert len(data['sequences']['completed'])==28 and len(data['sequences']['case_catalog']['cases'])==28
assert len(data['animations']['entries'])==23 and len(data['slow_wrap']['glints'])==7 and len(data['fast_wrap']['glints'])==8
assert data['counter']['counter_pixel_mismatches']==0 and data['counter']['body_pixels_covered']==5070 and data['counter']['torso_pixels_unchanged'] and data['counter']['counter_alpha_extrema']==[1.0,1.0]
counts={'contexts':28,'work':0,'aftermath':0,'expected_material_instances':0,'visible_source_occurrences':0,'hidden_non_room_occurrences':0,'interaction_label_overrides':0}
for name,v in data['sequences']['views'].items():
 assert v['prepared'] and v['live_authority']['ok'] and v['actual_arrival_wait']['remaining_person_transits']==0
 assert v['comparison']['layout_equal'] and v['reduce_motion_comparison']['layout_equal'] and v['reduce_motion_comparison']['reduce_motion_stable']
 counts['work' if v['case']['kind']=='active_phase' else 'aftermath']+=1
 for identity,m in v['material_evidence'].items():
  assert len(m['actual_objects'])==len(m['actual_geometry'])==1 and m['label']
  assert m['actual_geometry'][0]['label_rect']['w']>0 and m['actual_geometry'][0]['label_rect']['h']>0
  counts['expected_material_instances']+=1
 for vis in v['source_visual_evidence']:
  if vis['room_visible']:
   counts['visible_source_occurrences']+=1;assert len(vis['actual_objects'])==len(vis['actual_geometry'])==len(vis['published_objects'])==1
   assert vis['actual_label']==vis['expected_final_label']==vis['published_objects'][0]['label'] and vis['actual_label']
   counts['interaction_label_overrides']+=vis['source_label']!=vis['expected_final_label']
  else:counts['hidden_non_room_occurrences']+=1;assert vis['exclusion']
assert counts=={'contexts':28,'work':4,'aftermath':24,'expected_material_instances':24,'visible_source_occurrences':39,'hidden_non_room_occurrences':1,'interaction_label_overrides':8}
jobs={}
for name in ['r3-import-01','r3-preview-01','r3-no-pointer-01','r3-settled-01','r3-animation-probe-01','r3-floor-wrap-01','r3-ground-wrap-01','r3-counter-01','r3-live-sequences-01','r3-motion-pixels-01','r3-wrap-pixels-01']:
 p=R/(prefix+name)/'evidence/job.json';j=read(p);assert j['exit_code']==0 and j['active_at_release']==0 and j['assigned_before_execution'] and not j['error'] and not j['cleanup_errors'] and not j['timed_out']
 jobs[name]={'path':str(p),'sha256':h(p),'limits':j['limits'],'assigned_before_execution':True,'exit_code':0,'active_at_release':0}
liveness=R/(prefix+'r3-no-pointer-01')/'evidence/worker.log';assert 'Animation liveness without pointer input: PASS' in liveness.read_text();reports['mandatory_liveness']={'path':str(liveness),'sha256':h(liveness)}
pngs={}
for name in ['r3-preview-01','r3-settled-01','r3-live-sequences-01','r3-animation-probe-01','r3-floor-wrap-01','r3-ground-wrap-01','r3-counter-01']:
 for p in (R/(prefix+name)/'evidence').rglob('*.png'):
  b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';pngs[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'size':list(struct.unpack('>II',b[16:24])),'bytes':len(b)}
archive=out/'qa-source-archive';archive.mkdir();helpers={}
relatives=['back_adapter.py','back_stage_sealed.py','tools/envart_back_animation_capture_r3.gd','tools/envart_back_settled_r3.gd','tools/envart_back_sequence_proof_r3.gd','tools/envart_back_sequence_cases.json','tools/envart_back_animation_probe_r3.gd','tools/envart_back_floor_wrap_r3.gd','tools/envart_back_ground_streak_wrap_r3.gd','tools/envart_back_counter_person_r3.gd','tools/envart_back_motion_pixel_analysis_r3.py','tools/envart_back_wrap_pixels_r3.py','tools/envart_back_collect_final_r3.py','tools/environment_art_baseline_capture.gd','tools/environment_layout_screenshots.gd']
for rel in relatives:
 p=W/rel;t=archive/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t);helpers[rel]={'sha256':h(t),'source':str(p)}
for rel in ['tools/bth_qa_storage.py','tools/bth_qa_guarded_run.py','tools/bth_qa_command_paths.py']:
 p=S/rel;t=archive/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t);helpers[rel]={'sha256':h(t),'source':str(p)}
p=Path(r'E:/CodexQA/BTH/runs/BTH-ENVART-CORNER-20261114-r6-repro-archive-02/evidence/qa-source-archive/baseline/pixel_scene_canvas.e5152c34.gd');assert h(p)=='78058e0092552e4aef4d6339041f9d1768af3c14f837ec4eed65e832ae88ee0d';t=archive/'baseline'/p.name;t.parent.mkdir();shutil.copyfile(p,t);helpers['baseline/'+p.name]={'sha256':h(t),'source':str(p),'commit':'e5152c34bfe146600214fb206ec80a5e3e8a27cb'}
manifest=archive/'manifest.json';manifest.write_text(json.dumps(helpers,indent=2))
checks={k:data[k]['checks'] for k in ['settled','sequences','animations','slow_wrap','fast_wrap']};assert sum(checks.values())==785
summary={'status':'PASS_SCOPED_NATIVE_QA_PENDING_INDEPENDENT_FINAL_ART_ACCEPTANCE','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'package_root':str(P),'package_sha256':expected,'package_files':seal['files'],'unchanged_production_inputs_sha256':logic,'accepted_gas_corner_preserved':stage['accepted_gas_and_corner_preserved'],'reports':reports,'job_receipts':jobs,'native_checks':checks,'native_assertions_executed_and_passed':785,'readonly_pixel_checks':85,'counting_note':'85 read-only checks analyze the native probe pixels and are not independent gameplay executions. Mandatory no-pointer gate and exact crate replay are separate.','actual_live_membership_counts':counts,'sequence_scope':{'method':data['sequences']['scope'],'case_catalog':data['sequences']['case_catalog'],'limitations':'Production-model visuals, not UI-click, save/revisit or travel end-to-end.'},'always_open_scope':data['settled']['views']['always_open'],'counter':data['counter'],'capture_integrity':data['capture_integrity'],'png_evidence':pngs,'qa_source_archive':str(archive),'qa_source_manifest_sha256':h(manifest),'native_failures':[],'preserved_prior_trial':'Exact R2 trial receipts and images remain untouched. R1 was never staged.','target_integration_or_deployment_performed':False,'limits':'Native art/compatibility QA only. Independent final auditor/director acceptance and parent Web/TEST work remain separate.'}
p=out/'back-r3-final-native-qa-summary.json';p.write_text(json.dumps(summary,indent=2));print(json.dumps({'status':summary['status'],'native_assertions':785,'readonly_pixel_checks':85,'contexts':counts,'png_count':len(pngs),'closed_clean_jobs':len(jobs),'source_files_unchanged':len(logic),'path':str(p),'sha256':h(p),'archive':str(archive),'archive_manifest_sha256':h(manifest)}))
