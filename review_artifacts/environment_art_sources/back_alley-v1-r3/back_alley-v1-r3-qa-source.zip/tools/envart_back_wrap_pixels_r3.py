from pathlib import Path
from PIL import Image,ImageChops
import os,json,hashlib
root=Path(r"E:/CodexQA/BTH/runs/BTH-ENVART-BACK-20261114-r3-ground-wrap-01/evidence/probe");out=Path(os.environ["BTH_QA_EVIDENCE_DIR"])
j=json.loads((root/"ground_streak_wrap_probe.json").read_text());base=Image.open(root/"floor_wrap_control.png").convert("RGB");rows=[];failures=[]
for r in j["glints"]:
 boxes={}
 for side in ["before_wrap","after_wrap"]:
  img=Image.open(root/(r["id"]+"_"+side+".png")).convert("RGB");diff=ImageChops.difference(base,img);boxes[side]=diff.getbbox()
 y=int(r["y"]*2);pre=boxes["before_wrap"];post=boxes["after_wrap"]
 right=pre is not None and pre[0]>=1782 and pre[2]<=1800 and pre[1]>=y and pre[3]<=y+4
 left=post is not None and post[0]>=18 and post[2]<=86 and post[1]>=y and post[3]<=y+4
 if not right or not left:failures.append(r["id"])
 rows.append({"id":r["id"],"native_diff_bounds":boxes,"expected_right_region":[1782,y,1800,y+4],"expected_left_region":[18,y,86,y+4],"right_edge_only":right,"left_edge_only":left})
p=out/"back-r3-fast-wrap-pixel-audit.json";report={"checks":16,"failures":failures,"rows":rows,"scope":"Read-only diff of actual native before/after-wrap pixels against unchanged background. Fast90px/s family visibly wraps at board edges; offscreen glint expectations are not applied."};p.write_text(json.dumps(report,indent=2));print(json.dumps({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"checks":16,"failures":failures,"rows":rows}));raise SystemExit(1 if failures else 0)
