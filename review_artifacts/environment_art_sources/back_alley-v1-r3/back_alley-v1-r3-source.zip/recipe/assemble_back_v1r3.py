import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw
sys.dont_write_bytecode=True
sys.path.insert(0,r'D:/Projects/Beat-The-House/.tmp/environment-art-layers/tools')
from bth_qa_storage import Layout,validate_layout
m=json.loads((Path(os.environ['BTH_QA_EVIDENCE_DIR'])/'storage-manifest.json').read_text());l=Layout(**{k:Path(v) for k,v in m['paths'].items()},run_id=m['run_id'],token=m['token'],prepared=True,expected_write_bytes=m['expected_write_bytes'],reserve_bytes=m['reserve_bytes'])
artist=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-ARTIST-20261114/back_alley-v1');sources={}
def source(name,sha):
 p=artist/'source'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha;sources[name]={'path':str(p),'sha256':sha,'size':list(Image.open(p).size)};return Image.open(p).convert('RGB').resize((900,430),Image.Resampling.NEAREST)
s=source('background-guide-v1.png','284397d31b4c785d7fa616abdcd7ec4f8eca0758df3202cf54bcf5a29b946d25');floor=source('floor-material-v1.png','80b8472cdca33baf08ff6264364adf77f82d43731563aab467de7f8ec0003cf2')
root=l.workspace/'packages/back_alley-v1-r3';validate_layout(l,extra_write_paths=(root,));assert not root.exists();asset=root/'assets/art/environments/back_alley';(asset/'anim').mkdir(parents=True);(asset/'counters').mkdir();(root/'data/art/environments').mkdir(parents=True)
b=s.copy();p=b.load()
# Reduce only orange wall spill behind gold stock-name territory; preserve hue, masonry and all other vivid materials.
for y in range(130,191):
 for x in range(338,565):
  r,g,bl=p[x,y]
  if r>g*1.23 and g>bl*.82 and r>68:p[x,y]=(round(r*.60),round(g*.52),round(bl*.76))
# Clear small original fixture fringes with phase-related own-wall donors. Objects are replayed at exact coordinates.
def patch(box,donor):
 b.paste(b.crop((donor[0],donor[1],donor[0]+box[2]-box[0],donor[1]+box[3]-box[1])),box[:2])
patch((416,103,485,145),(200,103))
patch((636,165,848,222),(42,165))
patch((279,190,620,192),(279,142));patch((279,216,620,219),(279,168))
patch((279,192,282,216),(63,192));patch((618,192,621,216),(78,192))
for box,donor in [((314,216,318,236),(98,216)),((332,216,334,236),(116,216)),((569,216,572,236),(83,216)),((586,216,590,236),(100,216))]:patch(box,donor)
# Exact-depth crop, not vertical stretching/repetition of the shallow room source. Original floor plate remains intact.
b.paste(floor.crop((0,100,900,294)),(0,236));ImageDraw.Draw(b).line((0,236,899,236),fill=(24,12,29))
def fit(box,size):return s.crop(box).resize(size,Image.Resampling.NEAREST)
# Hanging fixture: original wire remains atx450. Authored housing/core fitted separately to exact small utility footprint.
housing=fit((417,104,481,121),(60,16));mask=Image.new('L',(60,16),0);ImageDraw.Draw(mask).polygon([(2,0),(57,0),(59,2),(59,14),(57,15),(2,15),(0,13),(0,2)],fill=255);b.paste(housing,(420,104),mask)
# Preserve the complete104..130 fixture, with a real dark lower face and an emitting slit inside its upper housing.
p=b.load()
for y in range(115,120):
 for x in range(420,480):
  r,g,bl=p[x,y];p[x,y]=(round(r*.22),round(g*.24),round(bl*.36))
glass=fit((431,122,471,133),(36,10));gp=glass.load()
for y in range(10):
 for x in range(36):
  r,g,bl=gp[x,y];gp[x,y]=(round(r*.12),round(g*.10),round(bl*.17))
ImageDraw.Draw(glass).rectangle((0,0,35,9),outline=(72,39,29));b.paste(glass,(432,120))
core=fit((431,122,471,133),(28,5));cp=core.load();pulse=Image.new('RGBA',(28,5),(0,0,0,0));ap=pulse.load()
for y in range(5):
 for x in range(28):
  r,g,bl=cp[x,y]
  if r>160 and g>105:
   ap[x,y]=(r,g,bl,225);cp[x,y]=(round(r*.75),round(g*.75),round(bl*.75))
b.paste(core,(436,109));pulse.resize((56,10),Image.Resampling.NEAREST).save(asset/'anim/bulb_core.png')
# Exact thin table and crate contact lips; dark authored warm faces retained.
table=fit((280,191,619,217),(336,24));table.paste(table.crop((0,2,336,3)),(0,0));b.paste(table,(282,192))
p=b.load()
for y in range(194,216):
 for x in range(282,618):
  r,g,bl=p[x,y];p[x,y]=(round(r*.44),round(g*.43),round(bl*.60))
crate=fit((637,166,847,220),(208,50));crate.paste(crate.crop((0,2,208,3)),(0,0));b.paste(crate,(638,168))
# Tight own-source wood legs with transparent exterior, avoiding a pasted old wall rectangle over new floor.
for box,pos in [((315,216,332,296),(318,216)),((570,216,588,296),(572,216))]:
 leg=fit(box,(14,78));mask=Image.new('L',(14,78),0);lp=leg.load();mp=mask.load()
 for y in range(78):
  for x in range(14):
   r,g,bl=lp[x,y]
   if (r>=bl*1.015 and r>g*1.08) or 3<=x<11:mp[x,y]=255
 b.paste(leg,pos,mask);ImageDraw.Draw(b).line((pos[0]-1,294,pos[0]+14,294),fill=(15,10,20))
# Ordinary bins retain exact separate lid/body silhouettes and contact shadows, no platforms.
for capbox,bodybox,x in [((112,238,167,250),(116,249,161,302),118),((735,238,791,250),(740,249,785,302),742)]:
 cap=fit(capbox,(50,10));body=fit(bodybox,(42,54));b.paste(body,(x,248));cm=Image.new('L',(50,10),0);ImageDraw.Draw(cm).polygon([(1,0),(48,0),(49,1),(49,8),(48,9),(1,9),(0,8),(0,1)],fill=255);b.paste(cap,(x-4,238),cm);ImageDraw.Draw(b).line((x-1,302,x+42,302),fill=(13,9,19))
animations=[]
def save2(im,name):im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST).save(asset/'anim'/name)
period=math.pi/4
animations.append({'id':'bulb_core_breathe','type':'pulse','texture':'anim/bulb_core.png','rect':[436,109,28,5],'min_opacity':.18,'max_opacity':.58,'period':period,'phase':-period/4,'blend':'add','still':'first'})
# One synchronized restrained authored pool/cone; no second broad luminous wash.
light=Image.new('RGBA',(236,128),(0,0,0,0));lp=light.load()
for yy in range(132,191):
 for xx in range(338,565):
  r,g,bl=s.getpixel((xx,yy));br,bg,bb=b.getpixel((xx,yy))
  if r>g*1.23 and g>bl*.82 and r>68:
   delta=(max(0,round((r-br)*.8)),max(0,round((g-bg)*.8)),max(0,round((bl-bb)*.8)))
   if max(delta)>0:lp[xx-332,yy-116]=(*delta,255)
save2(light,'lamp_pool_cone.png')
animations.append({'id':'lamp_pool_cone_breathe','type':'pulse','texture':'anim/lamp_pool_cone.png','rect':[332,116,236,128],'min_opacity':.12,'max_opacity':.30,'period':period,'phase':-period/4,'blend':'add','still':'first'})
# Director-approved18-streak-family translation: sparse seamless full-field diagonal drift, not literal old trajectories.
rain=Image.new('RGBA',(900,430),(0,0,0,0));d=ImageDraw.Draw(rain)
for i in range(18):
 x=(i*53+11)%900;y=(i*71+17)%430
 for xx in (-900,0,900):
  for yy in (-430,0,430):d.line((x+xx,y+yy,x-16+xx,y+48+yy),fill=(47,215,238,48),width=1)
save2(rain,'rain_field.png');animations.append({'id':'falling_rain_field','type':'scroll','texture':'anim/rain_field.png','rect':[0,0,900,430],'speed':[92,156.4],'opacity':1,'blend':'mix','still':'hide'})
# Eight distinct faster ground rain-light streaks retain original90px/s family and row/phase offsets.
streak=Image.new('RGBA',(34,2),(0,0,0,0));d=ImageDraw.Draw(streak)
for x in range(34):
 a=round(72*min(1,(x+1)/5,(34-x)/5));d.point((x,0),fill=(65,223,239,a))
 if x%9 not in (0,1):d.point((x,1),fill=(52,186,218,round(a*.56)))
save2(streak,'ground_rain_streak.png')
for i in range(8):animations.append({'id':f'ground_rain_streak_{i}','type':'mover','texture':'anim/ground_rain_streak.png','size':[34,2],'from':[0,282+(i%3)*12],'to':[900,282+(i%3)*12],'duration':10,'phase':i*113/90,'opacity':1,'blend':'add','still':'hide'})
# Three compact perspective puddle rings expand at the original abs-sine cadence, without frozen background rings.
F=12;ring=Image.new('RGBA',(52*F,6),(0,0,0,0));d=ImageDraw.Draw(ring)
for f in range(F):
 ph=abs(math.sin(math.pi*f/F));w=round(18+34*ph);a=round(50*(1-ph*.35));x=f*52+(52-w)//2;d.ellipse((x,1,x+w-1,4),outline=(67,215,235,a),width=1)
save2(ring,'puddle_rings.png')
for i,(x,y) in enumerate(((180,304),(420,292),(710,312))):animations.append({'id':f'puddle_ring_{i}','type':'frames','texture':'anim/puddle_rings.png','rect':[x-26,y-3,52,6],'frames':F,'fps':F*2.8/math.pi,'phase':i/2.8,'loop':'loop','opacity':1,'blend':'add','still':'hide'})
# Right glint moves only decoratively to visible top trim, not through an opaque counter hole.
star=Image.new('RGBA',(8,8),(0,0,0,0));d=ImageDraw.Draw(star);d.line((0,4,7,4),fill=(255,191,83,190));d.line((4,0,4,7),fill=(255,214,126,190));d.point((4,4),fill=(255,243,184,220));save2(star,'warm_glint.png')
for i,(x,y) in enumerate(((112,172),(792,165))):
 per=math.pi/4.2;animations.append({'id':f'warm_glint_{i}','type':'pulse','texture':'anim/warm_glint.png','rect':[x-4,y-4,8,8],'min_opacity':.22,'max_opacity':.48,'period':per,'phase':i/4.2-per/4,'blend':'add','still':'hide'})
# Seven restrained wet-material floor-light movers consolidate both common reflection families, not the distinct rain/puddle motifs.
colors=((61,193,222),(233,158,65),(97,175,224),(206,65,160),(70,204,222),(230,161,73),(108,168,221))
for i,color in enumerate(colors):
 w=72-4*i;im=Image.new('RGBA',(w,2),(0,0,0,0));p=im.load()
 for x in range(w):
  a=round(110*max(0,min(1,x/9,(w-1-x)/9)))
  if (x+i*3)%19 in (0,1):a=round(a*.4)
  p[x,0]=(*color,a)
  if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
 save2(im,f'floor_glint_{i}.png');speed=18+2.5*i;y=274+(i%4)*14;animations.append({'id':f'floor_glint_{i}','type':'mover','texture':f'anim/floor_glint_{i}.png','size':[w,2],'from':[-90,y],'to':[950,y],'duration':1040/speed,'phase':i*137/speed,'opacity':.18,'blend':'add','still':'hide'})
assert len(animations)==23
b.save(root/'background-board-review.png');b.resize((1800,860),Image.Resampling.NEAREST).save(asset/'background.png');b.crop((638,168,846,218)).convert('RGBA').resize((416,100),Image.Resampling.NEAREST).save(asset/'counters/back_alley_crate_display.png')
manifest={'schema':'bth.environment_art/v1','environment_id':'back_alley','board_size':[900,430],'pixel_scale':2,'background':{'texture':'background.png'},'animations':animations,'counters':{'back_alley_crate_display':{'texture':'counters/back_alley_crate_display.png','bleed':[0,0,0,0]}}};(root/'data/art/environments/back_alley.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'data/art/environments/index.json').write_text(json.dumps({'enabled':['gas_station_casino','corner_store','back_alley']},indent=2)+'\n')
files={}
for p in sorted(list((root/'assets').rglob('*.png'))+list((root/'data').rglob('*.json'))):
 data=p.read_bytes();e={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 if p.suffix=='.png':
  im=Image.open(p);e.update(size=list(im.size),mode=im.mode)
  if im.mode=='RGBA':e['alpha_extrema']=im.getchannel('A').getextrema()
 files[p.relative_to(root).as_posix()]=e
sha=hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(files.items())).encode()).hexdigest();record={'package_id':'back_alley-v1-r3','status':'SEALED_TRIAL_NOT_PASSED','package_sha256':sha,'files':files,'sources':sources,'frozen_generation_inputs':json.loads((artist/'inputs/input-provenance.json').read_text()),'changes':['Nearest-only900-grid assembly, exact2x final; originals preserved. R3 retains the complete lamp silhouette with internal honey emitter above116 and dark lower glass, plus a dark real table face194..216 under its unchanged192..193 contact rim.','Exact floor236 with same-scale cropped matching material plate; own-source table/crate/lamp/bin/leg fitting, no new live props/cast.','Only strong orange wall spill behind central stock labels reduced; vivid plum/cyan/pink/amber material identity retained.','23 animation entries: honey-lit core minimum and source-derived practical pool/cone modulation, sparse fullfield rain,8fastground streaks,3expanding puddles,2warmglints and7commonfloor movers.','Fullfield rain density/cadence and seven-floor family consolidation are explicit director-approved translations, not frame equivalence. Static NOHEAT/PAYCASH are not falsely counted as animation.','Right decorative glint adapted to visible top trim; exact opaque416x100 crate and no alpha holes.','Cumulative Gas/Corner activation included, but their passed raster/manifest bytes untouched. Native runtime/director/audit gate still required.']};(root/'package-seal.json').write_text(json.dumps(record,indent=2));(root/'edit-record.json').write_text(json.dumps(record,indent=2));print(json.dumps({'package':str(root),'package_sha256':sha,'background_sha256':files['assets/art/environments/back_alley/background.png']['sha256'],'animations':23,'status':'SEALED_TRIAL_NOT_PASSED'}))


