import sys
sys.dont_write_bytecode=True
from pathlib import Path
import os,json,time,threading,urllib.request,hashlib
sys.path.insert(0,r"D:\Projects\Beat-The-House\.tmp\environment-art-layers\tools")
from bth_qa_storage import plan_layout,prepare_layout,validate_layout,child_environment,check_launch
from bth_qa_guarded_run import execute
sys.path.insert(0,r"D:\Projects\site\scripts\bth_cpu_job")
from cpu_job import CpuCappedJob, _base
from native_proof_worker import SuspendedWorker
ROOT=Path(r"E:\CodexQA\BTH")
WORK=ROOT/"workspaces"/"BTH-ENVART-BACK-WEB-20261114"
PY=r"C:\Users\theep\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
CHROME=r"C:\Users\theep\AppData\Local\ms-playwright\chromium-1243\chrome-win64\chrome.exe"
NODE=r"C:\Program Files\nodejs\node.exe"
prefix=sys.argv[1]
from target_gate import admitted_target
authorization,artifact=admitted_target(WORK)
if not str(artifact).lower().startswith(r"e:\codexqa\bth\workspaces\bth-envart-test-web-20261114".lower()): raise ValueError("Unexpected artifact source")
owned=[]
def launch(kind,command_fn):
    layout=prepare_layout(plan_layout(ROOT,WORK,prefix+"-"+kind))
    env=child_environment(layout,os.environ)
    gate=check_launch(layout,WORK,env)
    receipt={"kind":kind,"storage_manifest":str(layout.manifest_path),"gate_before_job":gate,"cleanup_errors":[]}
    job=CpuCappedJob(1200,2*1024**3); receipt["limits"]=job.verify(); receipt["controlled_environment"]={k:v for k,v in env.items() if k.upper() in ("USERPROFILE","LOCALAPPDATA","APPDATA","TEMP","TMP","HOME","BTH_QA_PROFILE_DIR","BTH_QA_EVIDENCE_DIR")}
    record=(layout,job,None,receipt,None); owned.append(record)
    command=command_fn(layout); receipt["command"]=command
    receipt["gate_before_child"]=check_launch(layout,WORK,env)
    worker=SuspendedWorker(job,command,cwd=str(WORK),env=env)
    receipt["pid"]=worker.pid;receipt["assigned_before_resume"]=job.contains(worker._handle) and not worker.resumed
    if not receipt["assigned_before_resume"]:raise RuntimeError("Assignment failed")
    worker.stdin.close()
    def drain():
        with (layout.evidence/"stdout.log").open("x",encoding="utf-8") as output:
            for line in worker.stdout:output.write(line);output.flush()
    thread=threading.Thread(target=drain,daemon=True)
    owned[-1]=(layout,job,worker,receipt,thread)
    thread.start();worker.resume()
    return layout,worker
try:
    url=authorization["canonical_url"]
    if url!="https://192.168.0.36:8443/p/beat-the-house/play/test/":raise ValueError("Unexpected served TEST root")
    browser,bw=launch("browser",lambda l:[CHROME,"--headless=new","--remote-debugging-port=0","--user-data-dir="+str(l.profile),"--disk-cache-dir="+str(l.cache),"--no-first-run","--no-default-browser-check","--window-size=1280,720","about:blank"])
    deadline=time.monotonic()+30
    while not (browser.profile/"DevToolsActivePort").exists() and time.monotonic()<deadline:
        if bw.poll() is not None:raise RuntimeError("Chrome exited")
        time.sleep(.1)
    if not (browser.profile/"DevToolsActivePort").exists():raise RuntimeError("No CDP port")
    endpoint={"url":url,"browser_profile":str(browser.profile),"source":str(artifact),"prefix":prefix,"approved":authorization}
    validate_layout(browser)
    (WORK/(prefix+"-endpoint.json")).write_text(json.dumps(endpoint,indent=2))
    print("READY "+json.dumps(endpoint),flush=True)
    deadline=time.monotonic()+1800
    index=0
    while time.monotonic()<deadline:
        command_file=WORK/(prefix+"-command-"+str(index)+".json")
        if not command_file.exists():time.sleep(.15);continue
        command=json.loads(command_file.read_text())
        if command.get("mode")=="stop":break
        layout=prepare_layout(plan_layout(ROOT,WORK,prefix+"-probe-"+str(index)))
        args=[NODE,str(WORK/"back_probe.cjs"),str(WORK/(prefix+"-endpoint.json")),str(command_file)]
        metrics={}
        class ObservedJob(CpuCappedJob):
            def close(self):
                limits=self.query(9,_base.Limits())
                metrics.update(peak_job_memory_bytes=limits.peakJobMemory,cpu_seconds=self.cpu_seconds(),active_at_release=self.active())
                return super().close()
        result=execute(layout,args,timeout=210,cpu_rate=1200,job_factory=lambda:ObservedJob(1200,2*1024**3),worker_factory=SuspendedWorker)
        result["resource_measurements"]=metrics
        validate_layout(layout)
        (layout.evidence/"job.json").write_text(json.dumps(result,indent=2))
        for live_layout,live_job,live_worker,live_receipt,live_thread in owned:
            limits=live_job.query(9,_base.Limits())
            live_receipt.setdefault("phase_resource_samples",[]).append({"probe":index,"peak_job_memory_bytes":limits.peakJobMemory,"cpu_seconds":live_job.cpu_seconds(),"active_processes":live_job.active()})
        print("PROBE "+str(index)+" "+json.dumps({"exit_code":result.get("exit_code"),"evidence":str(layout.evidence),"cleanup_errors":result["cleanup_errors"]}),flush=True)
        validate_layout(layout)
        (WORK/(prefix+"-done-"+str(index)+".json")).write_text(json.dumps({"result":result,"evidence":str(layout.evidence)},indent=2))
        index+=1
    else:raise RuntimeError("Supervisor deadline")
finally:
    for layout,job,worker,receipt,thread in reversed(owned):
        try:
            limits=job.query(9,_base.Limits());receipt["peak_job_memory_bytes"]=limits.peakJobMemory;receipt["cpu_seconds"]=job.cpu_seconds()
            if worker and worker.poll() is None:
                deadline=time.monotonic()+4
                while worker.poll() is None and time.monotonic()<deadline:time.sleep(.05)
                receipt["forced_owned_termination"]=worker.poll() is None
                if worker.poll() is None:job.terminate();worker.wait(5)
            job.drain(5);receipt["active_at_release"]=job.active()
            if thread:thread.join(5)
            if worker:receipt["exit_code"]=worker.poll();worker.close()
        except BaseException as e:receipt["cleanup_errors"].append(str(e))
        finally:job.close()
        validate_layout(layout)
        (layout.evidence/"owned-job-receipt.json").write_text(json.dumps(receipt,indent=2))
    print("CLEANUP_COMPLETE",flush=True)
