import sys,json
sys.dont_write_bytecode=True
from pathlib import Path
sys.path.insert(0,r"D:\Projects\Beat-The-House\.tmp\environment-art-layers\tools")
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
r=Path(r"E:\CodexQA\BTH");w=r/"workspaces"/"BTH-ENVART-CORNER-WEB-20261114"
prefix=sys.argv[1];i=sys.argv[2];data=json.load(sys.stdin)
l=prepare_layout(plan_layout(r,w,prefix+"-write-"+i));validate_layout(l,extra_write_paths=[w])
f=w/(prefix+"-command-"+i+".json")
with f.open("x")as o:json.dump(data,o)
print(str(f))
