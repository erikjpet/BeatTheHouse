import sys,os,json,math
sys.dont_write_bytecode=True
from pathlib import Path
from PIL import Image,ImageChops
out=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
package=Path(r'E:\CodexQA\BTH\workspaces\BTH-ENVART-AUDIT-20261114\packages\corner_store-v1-r6\data\art\environments\corner_store.json')
pack=json.loads(package.read_text())
reports=[]
for raw in sys.argv[1:]:
 evidence=Path(raw)
 assert str(evidence).lower().startswith(r'e:\codexqa\bth\runs\bth-envart-cornerweb')
 motion=json.loads((evidence/'motion.json').read_text())
 assert motion['input_during_capture'] is False
 width=motion['viewport']['width']
 reference=Image.open(evidence/'frames'/motion['frames'][0]['file']).convert('RGB')
 cyan_rows=[y for y in range(80,210) if (lambda c:c[0]<40 and c[1]>120 and c[2]>120)(reference.getpixel((0,y)))]
 oy=max(cyan_rows)+1;scale=(720-oy)/430.;ox=(1280-900*scale)/2.

 assert width==1280,'Geometry requires exact1280 viewport'
 def box(rect):
  x,y,w,h=rect
  return (max(math.floor(ox),math.floor(ox+x*scale)),math.floor(oy+y*scale),min(math.ceil(1280-ox),math.ceil(ox+(x+w)*scale)),min(720,math.ceil(oy+(y+h)*scale)))
 regions={}
 for e in pack['animations']:
  if e['type']=='mover':
   regions[e['id']]=box([0,e['from'][1],900,e['size'][1]])
  else:regions[e['id']]=box(e['rect'])
 regions['register_left_endpoint']=box([372,203,22,2])
 regions['register_right_endpoint']=box([536,203,22,2])
 regions['floor_whole']=box([0,270,900,50])
 first=Image.open(evidence/'frames'/motion['frames'][0]['file']).convert('RGB')
 base={n:first.crop(b) for n,b in regions.items()}
 maximum={n:Image.new('L',i.size,0) for n,i in base.items()}
 counts={n:[] for n in regions}
 lane_frames={str(y):[] for y in [274,288,302,316]}
 for f in motion['frames']:
  with Image.open(evidence/'frames'/f['file']) as im:
   im=im.convert('RGB')
   for n,b in regions.items():
    diff=ImageChops.difference(base[n],im.crop(b)); r,g,bl=diff.split();d=ImageChops.lighter(ImageChops.lighter(r,g),bl)
    maximum[n]=ImageChops.lighter(maximum[n],d);counts[n].append(d.width*d.height-d.histogram()[0])
   for y in lane_frames:
    crop=im.crop(box([0,int(y),900,2])); pix=list(crop.getdata());w,h=crop.size
    lane_frames[y].append([max(pix[row*w+x][c] for row in range(h) for c in range(3)) for x in range(w)])
 stats={}
 for n,b in regions.items():
  hist=maximum[n].histogram();stats[n]={'box':b,'temporal_changed_pixels':maximum[n].width*maximum[n].height-hist[0],'peak_channel_delta':max(i for i,c in enumerate(hist) if c),'max_pair_changed_pixels':max(counts[n]),'changed_frames':sum(c>0 for c in counts[n])}
 lanes={}
 for y,frames in lane_frames.items():
  baseline=[min(v) for v in zip(*frames)];observations=[]
  for i,v in enumerate(frames):
   xs=[x for x,k in enumerate(v) if 1<=k-baseline[x]<=12]
   components=[]
   if xs:
    lo=last=xs[0]
    for x in xs[1:]:
     if x-last>4:
      if last-lo>=12:components.append([lo,last])
      lo=x
     last=x
    if last-lo>=12:components.append([lo,last])
   observations.append({'frame':i,'elapsed_ms':motion['frames'][i]['elapsed_ms'],'components_x':components})
  lanes[y]={'screen_box':box([0,int(y),900,2]),'raw_unamplified_positive_delta_components':observations}
 report={'label':motion['label'],'board_geometry':{'origin':[ox,oy],'scale':scale,'basis':'Observed screenshot cyan header boundary plus unchanged production fit min(width/900,height/430)'},'source_evidence':str(evidence),'duration_ms':motion['duration_ms'],'frames':len(motion['frames']),'unique_fullframe_hashes':len(set(f['sha256'] for f in motion['frames'])),'regions':stats,'floor_lane_tracking':lanes,'limits':'Actual browser screenshots with no animation clock or state injection. Same-lane mover region metrics overlap and do not independently isolate all7entries; use tracks with authored speeds and native per-entry proof. Animated objects can overlap motif regions.'}
 reports.append(report)
(out/'corner-motion-metrics.json').write_text(json.dumps(reports,indent=2))
print(json.dumps([{'label':r['label'],'duration_ms':r['duration_ms'],'regions':r['regions']}for r in reports]))
