import sys,os,json,math
sys.dont_write_bytecode=True
from pathlib import Path
from PIL import Image,ImageChops
out=Path(os.environ['BTH_QA_EVIDENCE_DIR']);e=Path(sys.argv[1]);m=json.loads((e/'motion.json').read_text());ref=Image.open(e/'frames'/m['frames'][0]['file']).convert('RGB');oy=max(y for y in range(80,210)if (lambda c:c[0]<40 and c[1]>120 and c[2]>120)(ref.getpixel((0,y))))+1;s=(720-oy)/430.;ox=(1280-900*s)/2.
regions={'floor':[0,270,900,50],'headlights':[50,90,270,100],'security_sweep':[700,90,130,110],'fluorescent':[130,43,125,20],'neon':[450,65,180,10]}
a=Image.open(e/'frames'/m['frames'][0]['file']).convert('RGB');results={}
for n,(x,y,w,h)in regions.items():
 b=(math.floor(ox+x*s),math.floor(oy+y*s),math.ceil(ox+(x+w)*s),math.ceil(oy+(y+h)*s));base=a.crop(b);diff=Image.new('L',base.size,0)
 for f in m['frames'][1:]:
  with Image.open(e/'frames'/f['file'])as im:
   d=ImageChops.difference(base,im.convert('RGB').crop(b));r,g,bl=d.split();diff=ImageChops.lighter(diff,ImageChops.lighter(ImageChops.lighter(r,g),bl))
 hist=diff.histogram();results[n]={'box':b,'temporal_changed_pixels':diff.width*diff.height-hist[0],'peak_delta':max(i for i,c in enumerate(hist)if c)}
report={'source':str(e),'actual_ui_title':'GAS STATION CASINO','duration_ms':m['duration_ms'],'frames':len(m['frames']),'input_during_capture':False,'regions':results,'scope':'Focused actual Web Gas R12 retained/animated regression, not a new full Gas outcome or save test.'}
assert all(x['temporal_changed_pixels']>0 for x in results.values())
(out/'gas-regression.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
