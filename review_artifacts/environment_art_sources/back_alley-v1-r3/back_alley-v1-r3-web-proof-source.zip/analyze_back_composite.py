import sys,os,json,math,hashlib
sys.dont_write_bytecode=True
from pathlib import Path
from PIL import Image,ImageChops,ImageStat
out=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
manifest=Path(sys.argv[1]).resolve(strict=True)
pack=json.loads(manifest.read_text())
assert pack['environment_id']=='back_alley' and pack['board_size']==[900,430]
reports=[]
for raw in sys.argv[2:]:
    evidence=Path(raw).resolve(strict=True)
    assert str(evidence).lower().startswith('e:/codexqa/bth/runs/bth-envart-backweb'.replace('/',chr(92)))
    motion=json.loads((evidence/'motion.json').read_text())
    assert motion['input_during_capture'] is False
    width,height=motion['viewport']['width'],motion['viewport']['height']
    first=Image.open(evidence/'frames'/motion['frames'][0]['file']).convert('RGB')
    assert first.size==(width,height)
    # Inspect these calibration facts visually before treating them as proof.
    cyan_rows=[y for y in range(round(height*.10),round(height*.34)) if (lambda c:c[0]<40 and c[1]>120 and c[2]>120)(first.getpixel((0,y)))]
    if not cyan_rows:raise ValueError('No production header boundary: provide observed calibration')
    oy=max(cyan_rows)+1;scale=min(width/900.,(height-oy)/430.);ox=(width-900*scale)/2.
    def box(rect):
        x,y,ww,hh=rect
        return (max(0,math.floor(ox+x*scale)),max(0,math.floor(oy+y*scale)),min(width,math.ceil(ox+(x+ww)*scale)),min(height,math.ceil(oy+(y+hh)*scale)))
    regions={}
    for entry in pack['animations']:
        regions[entry['id']]=box([0,entry['from'][1],900,entry['size'][1]] if entry['type']=='mover' else entry['rect'])
    base={n:first.crop(b)for n,b in regions.items()}
    maximum={n:Image.new('L',im.size,0)for n,im in base.items()}
    stats={n:{'box':b,'changed_frames':0,'max_pair_changed_pixels':0}for n,b in regions.items()}
    warm_ids=[n for n in regions if n.startswith(('bulb_','lamp_','warm_glint_'))]
    warm={n:[]for n in warm_ids}
    for f in motion['frames']:
        with Image.open(evidence/'frames'/f['file'])as source:
            im=source.convert('RGB')
            for n,b in regions.items():
                crop=im.crop(b);diff=ImageChops.difference(base[n],crop);r,g,bl=diff.split();d=ImageChops.lighter(ImageChops.lighter(r,g),bl)
                changed=d.width*d.height-d.histogram()[0];maximum[n]=ImageChops.lighter(maximum[n],d)
                stats[n]['changed_frames']+=int(changed>0);stats[n]['max_pair_changed_pixels']=max(stats[n]['max_pair_changed_pixels'],changed)
                if n in warm:
                    r,g,bl=crop.split();honey=ImageChops.subtract(r,bl)
                    warm[n].append({'frame':f['index'],'file':f['file'],'elapsed_ms':f['elapsed_ms'],'mean_positive_red_minus_blue':ImageStat.Stat(honey).mean[0],'rgb_mean':ImageStat.Stat(crop).mean,'max_positive_red_minus_blue':honey.getextrema()[1]})
    for n,m in maximum.items():
        hist=m.histogram();stats[n].update(temporal_changed_pixels=m.width*m.height-hist[0],peak_channel_delta=max(i for i,c in enumerate(hist)if c))
    signatures={}
    for n,rows in warm.items():
        low=min(rows,key=lambda r:r['mean_positive_red_minus_blue']);high=max(rows,key=lambda r:r['mean_positive_red_minus_blue'])
        signatures[n]={'lowest_sample':low,'highest_sample':high,'observed_warm_range':high['mean_positive_red_minus_blue']-low['mean_positive_red_minus_blue'],'samples':rows,'limit':'Raw positive red-minus-blue measures warm-color variation and suppresses some cool rain. It is not isolated-entry proof or an exact mathematical minimum/maximum.'}
    report={'label':motion['label'],'source_evidence':str(evidence),'duration_ms':motion['duration_ms'],'frames':len(motion['frames']),'unique_fullframe_hashes':len(set(f['sha256']for f in motion['frames'])),'board_geometry':{'origin':[ox,oy],'scale':scale,'requires_visual_confirmation':True,'basis':'Observed cyan header bottom + unchanged900x430production board fit'},'composite_regions':stats,'warm_color_signatures':signatures,'limits':['Full-field rain overlaps nearly all regions. Changed-region counts cannot establish23individual animations.','Moving objects and authored overlays overlap; native exact-package QA supplies isolated-entry evidence.','No state/clock/alpha/contrast changes. Screenshots and scalar measurements are unamplified.','Reduce Motion proof requires comparing all regions and independent visual honey-core readability, not merely a nonzero warm score.']}
    reports.append(report)
(out/'back-composite-motion.json').write_text(json.dumps({'manifest':str(manifest),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'reports':reports},indent=2))
print(json.dumps([{'label':r['label'],'frames':r['frames'],'duration_ms':r['duration_ms'],'geometry':r['board_geometry'],'composite_changed_regions':sum(v['temporal_changed_pixels']>0 for v in r['composite_regions'].values()),'warm_ranges':{n:v['observed_warm_range']for n,v in r['warm_color_signatures'].items()}}for r in reports]))
