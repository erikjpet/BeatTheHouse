import json,hashlib,re
from pathlib import Path

def admitted_target(work):
    approval=work/"approved-target.json"
    if not approval.is_file():
        raise RuntimeError("PREPARATION ONLY: exact full auditor PASS source and finalized-stage GO have not been supplied")
    a=json.loads(approval.read_text())
    if a.get("parent_go") is not True or a.get("full_auditor_pass") is not True:
        raise RuntimeError("Full auditor PASS and parent launch GO are required")
    commit=a.get("source_commit","")
    if not re.fullmatch(r"[0-9a-f]{40}",commit):raise ValueError("Exact source commit required")
    root="https://192.168.0.36:8443/p/beat-the-house/play/test/"
    if a.get("canonical_url")!=root or a.get("immutable_url")!=root+commit+"/index.html":raise ValueError("Unexpected TEST URL")
    artifact=Path(a["finalized_stage"]).resolve(strict=True)
    parent_stage=Path("E:/CodexQA/BTH/workspaces/BTH-ENVART-TEST-WEB-20261114").resolve(strict=True)
    if not artifact.is_relative_to(parent_stage):raise ValueError("Stage outside parent's admitted E Web workspace")
    raw=(artifact/"build_manifest.json").read_bytes()
    if hashlib.sha256(raw).hexdigest()!=a["manifest_sha256"]:raise ValueError("Stage manifest mismatch")
    manifest=json.loads(raw)
    if manifest["source_commit"]!=commit:raise ValueError("Wrong stage source commit")
    if manifest.get("source_tree")!=a["source_tree"]:raise ValueError("Wrong stage source tree")
    for name,expected in manifest["files"].items():
        if name!=Path(name).name:raise ValueError("Unsafe artifact filename")
        p=artifact/name;b=p.read_bytes()
        if len(b)!=expected["bytes"] or hashlib.sha256(b).hexdigest()!=expected["sha256"]:raise ValueError("Stage artifact mismatch: "+name)
    if a["html_sha256"]!=manifest["files"]["index.html"]["sha256"]:raise ValueError("HTML hash mismatch")
    return a,artifact
