const fs=require("fs"),path=require("path"),crypto=require("crypto");
const {chromium}=require("D:/Projects/site/node_modules/playwright");
const endpoint=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));
const cmd=JSON.parse(fs.readFileSync(process.argv[3],"utf8"));
const out=process.env.BTH_QA_EVIDENCE_DIR;
const TEST="/userfs/godot/app_userdata/Beat the House/distribution/web_0_6_1_art_test";
let page,context,messages=[];
const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2));
const hash=v=>crypto.createHash("sha256").update(v).digest("hex");
async function databases(){
 return await page.evaluate(async()=>{
  const list=await indexedDB.databases(), all=[];
  for(const item of list){
   const db=await new Promise((resolve,reject)=>{let r=indexedDB.open(item.name);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
   const stores=[];
   for(const name of db.objectStoreNames){
    const tx=db.transaction(name,"readonly"),store=tx.objectStore(name),indexes=[];
    for(const indexName of store.indexNames){const i=store.index(indexName);indexes.push({name:i.name,keyPath:i.keyPath,unique:i.unique,multiEntry:i.multiEntry});}
    const records=await new Promise((resolve,reject)=>{const rows=[],r=store.openCursor();r.onsuccess=()=>{let c=r.result;if(!c){resolve(rows);return;}let v=c.value;rows.push({key:c.key,value:{...v,contents:v.contents?Array.from(v.contents):null}});c.continue()};r.onerror=()=>reject(r.error);});
    stores.push({name,keyPath:store.keyPath,autoIncrement:store.autoIncrement,indexes,records});
   }
   all.push({name:db.name,version:db.version,stores});db.close();
  }
  return all.sort((a,b)=>a.name.localeCompare(b.name));
 });
}
function decodedSummary(parsed){
 if(!parsed?.run_state?.data)return null;
 const packed=parsed.run_state,alphabet="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-:+=^!/*?&<>()[]{}@%$#";
 const bytes=Buffer.alloc(packed.data.length/5*4);
 for(let i=0;i<packed.data.length;i+=5){let value=0;for(let k=0;k<5;k++)value=value*85+alphabet.indexOf(packed.data[i+k]);bytes.writeUInt32BE(value>>>0,i/5*4);}
 const raw=require("node:zlib").zstdDecompressSync(bytes.subarray(0,packed.compressed_bytes));
 if(hash(raw)!==packed.sha256||raw.length!==packed.uncompressed_bytes)throw Error("Invalid packed save");
 const state=JSON.parse(raw.toString("utf8"));
 return {validated_sha256:hash(raw),seed_text:state.seed_text,rng_state:state.rng_state,current_environment:state.current_environment,bankroll:state.bankroll,inventory:state.inventory,active_item_id:state.active_item_id,game_clock_minutes:state.game_clock_minutes,story_flags:state.story_flags,act:state.act,night:state.night,day:state.day,root_keys:Object.keys(state)};
}
function summarize(dbs){
 return dbs.map(db=>({...db,stores:db.stores.map(s=>({...s,records:s.records.map(r=>{
   const b=r.value.contents?Buffer.from(r.value.contents):null;
   let parsed=null;try{parsed=b?JSON.parse(b.toString("utf8")):null;}catch{}
   return {key:r.key,mode:r.value.mode,timestamp:r.value.timestamp,bytes:b?.length||0,sha256:b?hash(b):null,schema:parsed?.schema||null,slot_id:parsed?.slot_id||null,decoded:decodedSummary(parsed),packed_sha256:parsed?.run_state?.sha256};
 })}))}));
}
async function capture(){
 const dbs=await databases();
 write("indexeddb-full.json",dbs);write("indexeddb-summary.json",summarize(dbs));
 const observation=await page.evaluate(()=>({url:location.href,canvas:{width:document.querySelector("canvas")?.width,height:document.querySelector("canvas")?.height},dbEvents:window.__bthQa?.dbEvents||[],messages:window.__bthQa?.messages||[],body:document.body.innerText,config:typeof GODOT_CONFIG!=="undefined"?GODOT_CONFIG:null}));
 write("observation.json",{...observation,messagesObserved:messages});
 await page.screenshot({path:path.join(out,"screen.png")});
 console.log(JSON.stringify({evidence:out,databases:summarize(dbs).map(d=>({name:d.name,records:d.stores.flatMap(s=>s.records.map(r=>({key:r.key,bytes:r.bytes,schema:r.schema})))})),messages,observation}));
 return dbs;
}
(async()=>{
 const port=fs.readFileSync(path.join(endpoint.browser_profile,"DevToolsActivePort"),"utf8").split(/\r?\n/)[0];
 const browser=await chromium.connectOverCDP("http://127.0.0.1:"+port);
 context=browser.contexts()[0];page=context.pages()[0];
 page.on("console",m=>messages.push({type:m.type(),text:m.text(),location:m.location()}));
 page.on("requestfailed",r=>messages.push({type:"requestfailed",url:r.url(),failure:r.failure()}));
 page.on("pageerror",e=>messages.push({type:"pageerror",text:e.message}));
 await page.setViewportSize(cmd.viewport||{width:1280,height:720});
 if(cmd.identity){
  const response=await page.request.get(endpoint.url+"/build_manifest.json");
  const raw=await response.body();if(hash(raw)!==cmd.identity)throw Error("Served manifest hash mismatch");
  const manifest=JSON.parse(raw),results=[];
  for(const [name,expected] of Object.entries(manifest.files)){
   const r=await page.request.get(endpoint.url+"/"+name);const body=await r.body();
   const got={name,status:r.status(),url:r.url(),bytes:body.length,sha256:hash(body)};
   if(got.status!==200||got.bytes!==expected.bytes||got.sha256!==expected.sha256)throw Error("Served bytes mismatch "+name);
   results.push(got);await r.dispose();
  }
  write("served-identity.json",{manifest_sha256:hash(raw),source_commit:manifest.source_commit,source_tree:manifest.source_tree,art_package_sha256:manifest.art_package_sha256,results});
 }
 if(cmd.mode==="remote_boot"){
  const navigations=[],responses=[];
  page.on("framenavigated",f=>{if(f===page.mainFrame())navigations.push({url:f.url(),at:Date.now()})});
  page.on("response",r=>responses.push({url:r.url(),status:r.status(),type:r.request().resourceType()}));
  await context.addInitScript(()=>{
   window.__bthQa={dbEvents:[],messages:[]};
   const open=IDBFactory.prototype.open;
   IDBFactory.prototype.open=function(...args){window.__bthQa.dbEvents.push({kind:"open",name:args[0],version:args[1]});return open.apply(this,args)};
   const transaction=IDBDatabase.prototype.transaction;
   IDBDatabase.prototype.transaction=function(...args){window.__bthQa.dbEvents.push({kind:"transaction",database:this.name,stores:args[0],mode:args[1]||"readonly"});return transaction.apply(this,args)};
   for(const name of ["error","warn"]){let original=console[name];console[name]=function(...args){window.__bthQa.messages.push({type:name,text:args.map(String).join(" ")});return original.apply(this,args)};}
   addEventListener("error",e=>window.__bthQa.messages.push({type:"pageerror",text:e.message}));
  });
  const firstResponse=await page.goto(endpoint.url,{waitUntil:"domcontentloaded",timeout:60000});
  await page.waitForURL(cmd.expectedURL,{timeout:60000});
  await page.waitForFunction(()=>document.querySelector("canvas")&&!document.getElementById("status"),null,{timeout:150000});
  await page.waitForTimeout(4000);
  const manifest=await page.evaluate(async()=>{const r=await fetch(new URL("build_manifest.json",location.href));return {url:r.url,status:r.status,text:await r.text()};});
  if(manifest.status!==200||hash(Buffer.from(manifest.text))!==cmd.manifestSha256)throw Error("Browser served manifest mismatch");
  const html=await page.evaluate(async()=>{const r=await fetch(location.href);return {url:r.url,status:r.status,text:await r.text()};});
  if(html.status!==200||hash(Buffer.from(html.text))!==cmd.htmlSha256)throw Error("Browser served HTML mismatch");
  write("served-browser-identity.json",{root:endpoint.url,effective_url:page.url(),normal_tls_validation:true,no_https_ignore_or_security_bypass:true,navigations,responses,manifest_sha256:hash(Buffer.from(manifest.text)),html_sha256:hash(Buffer.from(html.text)),source:JSON.parse(manifest.text).source_commit,art_package:JSON.parse(manifest.text).art_package_sha256});
 }else if(cmd.mode==="boot"){
  await page.goto(endpoint.url+"/qa-blank");
  await page.evaluate(async()=>{
   const request=indexedDB.open("/userfs",21);
   request.onupgradeneeded=()=>{const s=request.result.createObjectStore("FILE_DATA");s.createIndex("timestamp","timestamp",{unique:false});};
   const db=await new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
   await new Promise((resolve,reject)=>{const tx=db.transaction("FILE_DATA","readwrite");tx.objectStore("FILE_DATA").put({timestamp:new Date("2020-01-01T00:00:00Z"),mode:33206,contents:new TextEncoder().encode(JSON.stringify({schema:"synthetic.normal.web.sentinel/v1",marker:"NORMAL-UNTOUCHED-20261114",value:314159}))},"/userfs/godot/app_userdata/Beat the House/distribution/web_0_6_1/saves/qa-sentinel.json");tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});db.close();
  });
  write("normal-before.json",(await databases()).find(d=>d.name==="/userfs"));
  await context.addInitScript(()=>{
   window.__bthQa={dbEvents:[],messages:[]};
   const open=IDBFactory.prototype.open;
   IDBFactory.prototype.open=function(...args){window.__bthQa.dbEvents.push({kind:"open",name:args[0],version:args[1]});return open.apply(this,args)};
   const transaction=IDBDatabase.prototype.transaction;
   IDBDatabase.prototype.transaction=function(...args){window.__bthQa.dbEvents.push({kind:"transaction",database:this.name,stores:args[0],mode:args[1]||"readonly"});return transaction.apply(this,args)};
   for(const name of ["error","warn"]){let original=console[name];console[name]=function(...args){window.__bthQa.messages.push({type:name,text:args.map(String).join(" ")});return original.apply(this,args)};}
   addEventListener("error",e=>window.__bthQa.messages.push({type:"pageerror",text:e.message}));
  });
  await page.goto(endpoint.url+"/index.html",{waitUntil:"domcontentloaded"});
  await page.waitForFunction(()=>!document.getElementById("status"),null,{timeout:150000});
  await page.waitForTimeout(5000);
 }else if(cmd.mode==="reload"){
  await context.addInitScript(()=>{
   window.__bthQa={dbEvents:[],messages:[]};
   const open=IDBFactory.prototype.open;
   IDBFactory.prototype.open=function(...args){window.__bthQa.dbEvents.push({kind:"open",name:args[0],version:args[1]});return open.apply(this,args)};
   const transaction=IDBDatabase.prototype.transaction;
   IDBDatabase.prototype.transaction=function(...args){window.__bthQa.dbEvents.push({kind:"transaction",database:this.name,stores:args[0],mode:args[1]||"readonly"});return transaction.apply(this,args)};
   for(const name of ["error","warn"]){let original=console[name];console[name]=function(...args){window.__bthQa.messages.push({type:name,text:args.map(String).join(" ")});return original.apply(this,args)};}
   addEventListener("error",e=>window.__bthQa.messages.push({type:"pageerror",text:e.message}));
  });
  await page.reload({waitUntil:"domcontentloaded"});
  await page.waitForFunction(()=>!document.getElementById("status"),null,{timeout:150000});
  await page.waitForTimeout(5000);
 }else if(cmd.mode==="actions"){
  for(const a of cmd.actions||[]){
   if(a.kind==="screenshot"){if(!/^[a-z0-9_-]+\.png$/i.test(a.name))throw Error("Unsafe screenshot name");await page.screenshot({path:path.join(out,a.name)});}
   if(a.kind==="click")await page.mouse.click(a.x,a.y);
   if(a.kind==="key")await page.keyboard.press(a.key);
   if(a.kind==="type")await page.keyboard.type(a.text,{delay:30});
   if(a.kind==="wheel"){await page.mouse.move(a.x,a.y);await page.mouse.wheel(0,a.dy);}
   await page.waitForTimeout(a.wait||700);
  }
 }
 if(cmd.currentOnly){
 const result=await page.evaluate(async(root)=>({current:(await(await fetch(new URL("current",root))).text()).trim(),manifest:await(await fetch(new URL("build_manifest.json",location.href))).json(),url:location.href}),endpoint.url);
 if(result.current!==cmd.currentOnly||result.manifest.source_commit!==cmd.currentOnly)throw Error("Final current identity mismatch");
 write("current-room-identity.json",{...result,normal_tls:true});
 }
 if(cmd.verifyCurrent){
 await page.goto(new URL(cmd.verifyCurrent+"/build_manifest.json",endpoint.url).href,{waitUntil:"domcontentloaded"});
 const result=await page.evaluate(async({root,expected})=>{
  const digest=async b=>Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",b))).map(n=>n.toString(16).padStart(2,"0")).join("");
  const current=(await(await fetch(new URL("current",root))).text()).trim();
  if(current!==expected)throw Error("Canonical current mismatch "+current);
  const immutable=new URL(expected+"/",root).href;
  const mr=await fetch(new URL("build_manifest.json",immutable)),raw=await mr.arrayBuffer(),manifest=JSON.parse(new TextDecoder().decode(raw));
  const manifestHash=await digest(raw);
  if(manifest.source_commit!==expected||manifestHash!=="68e60e8d57ccbcb1571f284df139a99a105cdb4dfaf40e44e591e291d6ecb844")throw Error("Manifest mismatch");
  const files=[];
  for(const[name,exp]of Object.entries(manifest.files)){
   const rr=await fetch(new URL(name,immutable)),bytes=await rr.arrayBuffer();const got={name,status:rr.status,bytes:bytes.byteLength,sha256:await digest(bytes)};
   if(got.status!==200||got.bytes!==exp.bytes||got.sha256!==exp.sha256)throw Error("Served bytes mismatch "+name);
   files.push(got);
  }
  return {current,immutable_url:immutable,normal_tls:true,browser_fetch_not_node_request:true,source_tree:manifest.source_tree,manifest_sha256:manifestHash,art_package_sha256:manifest.art_package_sha256,files};
 },{root:endpoint.url,expected:cmd.verifyCurrent});
 write("final-served-identity.json",result);
 }
 if(cmd.wait)await page.waitForTimeout(cmd.wait);
 const actualConfig=await page.evaluate(()=>typeof GODOT_CONFIG!=="undefined"?GODOT_CONFIG:null);
 if(actualConfig){
  if(JSON.stringify(actualConfig.args)!==JSON.stringify(["--","--bth-art-test"]))throw Error("Wrong TEST arguments");
  if(actualConfig.persistentPaths && JSON.stringify(actualConfig.persistentPaths)!==JSON.stringify([TEST]))throw Error("Wrong persistence mount");
 }

 if(cmd.motion){
  await page.mouse.move(3,3);await page.waitForTimeout(300);
  const folder=path.join(out,"frames");fs.mkdirSync(folder);
  const frames=[],start=Date.now(),count=cmd.motion.count||48,interval=cmd.motion.interval||250;
  for(let i=0;i<count;i++){
   const name=String(i).padStart(3,"0")+".png";
   const b=await page.screenshot({path:path.join(folder,name)});
   frames.push({index:i,file:name,elapsed_ms:Date.now()-start,sha256:hash(b)});
   if(i<count-1)await page.waitForTimeout(interval);
  }
  write("motion.json",{label:cmd.motion.label,viewport:page.viewportSize(),input_during_capture:false,frames,duration_ms:frames.at(-1).elapsed_ms-frames[0].elapsed_ms});
 }
 const dbs=await capture();
 if(dbs.some(d=>d.name!==TEST))throw Error("Non-TEST database detected in fresh disposable profile");
 const writeEvents=await page.evaluate(()=>window.__bthQa?.dbEvents||[]);
 if(writeEvents.some(e=>e.kind==="transaction"&&e.mode==="readwrite"&&e.database!==TEST))throw Error("Non-TEST write transaction detected");
 write("save-isolation.json",{test_mount:TEST,databases:dbs.map(d=>d.name),all_writes_test_only:true,args:actualConfig?.args||null,events:writeEvents});
 if(cmd.assertSave){
  const test=dbs.find(d=>d.name===TEST);
  const save=test?.stores.flatMap(s=>s.records).find(r=>r.key.endsWith("/saves/foundation_ui_autosave.json"));
  if(!save)throw Error("Actual TEST autosave not found");
  const parsed=JSON.parse(Buffer.from(save.value.contents).toString("utf8"));
  if(parsed.schema!=="beat_the_house.foundation_run"||parsed.slot_id!=="foundation_ui_autosave")throw Error("Unexpected save schema");
 }
 if(cmd.normalBefore){
  const before=JSON.parse(fs.readFileSync(cmd.normalBefore,"utf8"));
  const after=dbs.find(d=>d.name==="/userfs");
  if(JSON.stringify(before)!==JSON.stringify(after))throw Error("NORMAL DATABASE CHANGED");
  const events=await page.evaluate(()=>window.__bthQa.dbEvents);
  if(events.some(e=>e.database==="/userfs"&&e.mode==="readwrite"))throw Error("Normal database was opened for writes");
  write("normal-sentinel-proof.json",{unchanged:true,before_sha256:hash(JSON.stringify(before)),after_sha256:hash(JSON.stringify(after)),normal_readwrite_transactions:events.filter(e=>e.database==="/userfs"&&e.mode==="readwrite"),test_database:TEST});
 }
 if(cmd.mode==="close"){const session=await context.newCDPSession(page);await session.send("Browser.close").catch(()=>{});}
 console.log("PASS "+cmd.mode);process.exit(0);
})().catch(async e=>{write("failure.json",{error:String(e),messages});if(page)await page.screenshot({path:path.join(out,"failure.png")}).catch(()=>{});console.error(e);process.exit(1);});
