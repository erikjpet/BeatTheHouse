import sys,os,json,math
sys.dont_write_bytecode=True
from pathlib import Path
from PIL import Image,ImageChops
out=Path(os.environ['BTH_QA_EVIDENCE_DIR']);e=Path(sys.argv[1]);m=json.loads((e/'motion.json').read_text())
s=594/430.;ox=(1280-900*s)/2.;oy=126
frames=[Image.open(e/'frames'/f['file']).convert('RGB')for f in m['frames']]
times=[(f['elapsed_ms']-m['frames'][0]['elapsed_ms'])/1000. for f in m['frames']]
lanes={}
for y in [282,294,306]:
    box=(math.floor(ox),math.floor(oy+y*s),math.ceil(1280-ox),math.ceil(oy+(y+2)*s))
    crops=[im.crop(box)for im in frames];base=crops[0]
    for im in crops[1:]:base=ImageChops.darker(base,im)
    rows=[]
    for im in crops:
        d=ImageChops.difference(im,base);r,g,b=d.split();d=ImageChops.lighter(ImageChops.lighter(r,g),b);pix=list(d.getdata());ww,hh=d.size
        values=[max(pix[row*ww+x] if 2<=pix[row*ww+x]<=110 else 0 for row in range(hh))for x in range(ww)]
        pref=[0]
        for v in values:pref.append(pref[-1]+v)
        rows.append(pref)
    lanes[y]=rows
results=[]
for speed_board in [87,88,89,90,91,92,93]:
    speed=speed_board*s;span=900*s;width=34*s
    best=(-1,None,None)
    for phase_step in range(200):
        t0=phase_step*.05;totals=[0.]*8;counts=[0]*8
        for i in range(8):
            y=[282,294,306][i%3];phase=i*1.2555555555555555
            for t,p in zip(times,lanes[y]):
                left=((t+t0+phase)*speed)%span;right=left+width;lo=max(0,round(left));hi=min(len(p)-1,round(right))
                if hi-lo<width*.7:continue
                signal=(p[hi]-p[lo])/(hi-lo)
                a=max(0,lo-round(width));b=min(len(p)-1,hi+round(width))
                background=((p[lo]-p[a])+(p[b]-p[hi]))/max(1,(lo-a)+(b-hi))
                totals[i]+=signal-background;counts[i]+=1
        scores=[v/max(1,n)for v,n in zip(totals,counts)];score=sum(scores)/8
        if score>best[0]:best=(score,t0,scores)
    results.append({'speed_board_px_s':speed_board,'mean_inside_minus_adjacent_delta':best[0],'global_phase_seconds':best[1],'per_authored_phase_scores':best[2]})
res={'source_evidence':str(e),'duration_ms':m['duration_ms'],'method':'Eight authored short horizontal34x2streak positions share timing across3lanes; fit one global phase and compare positive raw pixel delta inside predicted track versus adjacent strips. Seven candidate speeds87..93boardpx/s.','expected_speed_board_px_s':90,'best_observed_candidate':max(results,key=lambda x:x['mean_inside_minus_adjacent_delta']),'candidates':results,'limits':'Composite corroboration only. Full-field diagonal rain and nearby animated overlays can bias scores. Does not replace native isolated8-entry proof. Raw screenshots, no altered rendering.'}
(out/'back-ground-streak-fit.json').write_text(json.dumps(res,indent=2));print(json.dumps(res))
