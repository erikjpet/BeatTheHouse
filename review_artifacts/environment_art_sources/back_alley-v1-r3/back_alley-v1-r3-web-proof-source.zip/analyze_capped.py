import sys,os,json
sys.dont_write_bytecode=True
from pathlib import Path
sys.path.insert(0,r"D:\Projects\Beat-The-House\.tmp\environment-art-layers\tools")
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
from bth_qa_guarded_run import execute
sys.path.insert(0,r"D:\Projects\site\scripts\bth_cpu_job")
from cpu_job import CpuCappedJob,_base
from native_proof_worker import SuspendedWorker
w=Path(r"E:\CodexQA\BTH\workspaces\BTH-ENVART-BACK-WEB-20261114")
l=prepare_layout(plan_layout(r"E:\CodexQA\BTH",w,sys.argv[1]))
metrics={}
class ObservedJob(CpuCappedJob):
    def close(self):
        limits=self.query(9,_base.Limits());metrics.update(peak_job_memory_bytes=limits.peakJobMemory,cpu_seconds=self.cpu_seconds(),active_at_release=self.active())
        return super().close()
script=(w/sys.argv[2]).resolve(strict=True)
if script.parent!=w or not script.name.endswith('.py'):raise ValueError('Unexpected helper')
cmd=[sys.executable,'-B',str(script)]+sys.argv[3:]
result=execute(l,cmd,timeout=210,cpu_rate=1200,job_factory=lambda:ObservedJob(1200,2*1024**3),worker_factory=SuspendedWorker)
result['resource_measurements']=metrics;validate_layout(l);(l.evidence/'job.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'exit':result.get('exit_code'),'error':result.get('error'),'active':result.get('active_at_release'),'metrics':metrics,'evidence':str(l.evidence)}))
raise SystemExit(0 if result.get('exit_code')==0 and not result.get('error') else 1)
