import sys,os,json,math
sys.dont_write_bytecode=True
from pathlib import Path
from PIL import Image,ImageChops
out=Path(os.environ['BTH_QA_EVIDENCE_DIR']);e=Path(r'E:\CodexQA\BTH\runs\BTH-ENVART-CORNERWEB01-probe-4\evidence')
m=json.loads((e/'motion.json').read_text());scale=594/430.;ox=(1280-900*scale)/2.;oy=126
frames=[Image.open(e/'frames'/f['file']).convert('RGB')for f in m['frames']]
times=[(f['elapsed_ms']-m['frames'][0]['elapsed_ms'])/1000.for f in m['frames']]
lanes={}
for y in [274,288,302,316]:
 box=(math.floor(ox),math.floor(oy+y*scale),math.ceil(1280-ox),math.ceil(oy+(y+2)*scale));crops=[im.crop(box)for im in frames];base=crops[0]
 for im in crops[1:]:base=ImageChops.darker(base,im)
 rows=[]
 for im in crops:
  d=ImageChops.difference(im,base);r,g,b=d.split();d=ImageChops.lighter(ImageChops.lighter(r,g),b);pixels=list(d.getdata());width,height=d.size
  values=[max((v if v<=15 else 0)for row in range(height)for v in [pixels[row*width+x]])for x in range(width)]
  prefix=[0]
  for v in values:prefix.append(prefix[-1]+v)
  rows.append(prefix)
 lanes[y]=rows
results=[]
for i in range(7):
 y=274+14*(i%4);prefixes=lanes[y];speed=(18+2.5*i)*scale;width=(72-4*i)*scale;wrap=1040*scale;lead=-90*scale
 def fit(v):
  best=(-1,None,None)
  for x0 in range(0,math.ceil(wrap),3):
   total=0;visible=0;support=[]
   for k,(t,p)in enumerate(zip(times,prefixes)):
    left=lead+(x0+v*t)%wrap;right=left+width;lo=max(0,round(left));hi=min(len(p)-1,round(right))
    if hi-lo<width*.7:continue
    value=(p[hi]-p[lo])/(hi-lo);total+=value;visible+=1
    if k%15==0:support.append({'frame':k,'elapsed_s':t,'predicted_x':round(left,2),'mean_raw_delta':round(value,4)})
   score=total/visible if visible>len(times)*.65 else -1
   if score>best[0]:best=(score,x0,support)
  return {'speed_css_px_per_s':v,'score':best[0],'x_phase':best[1],'samples':best[2]}
 candidates=[fit(speed+d*.5)for d in range(-6,7)];best=max(candidates,key=lambda x:x['score']);expected=next(c for c in candidates if abs(c['speed_css_px_per_s']-speed)<.001)
 row={'id':'floor_glint_'+str(i),'board_y':y,'authored_speed_board_px_per_s':18+2.5*i,'expected_css_px_per_s':speed,'best_observed_fit':best,'exact_expected_fit':expected,'method':'Fit moving positive raw pixel support over62s to each independently known speed; additive deltas1..15only reject high-delta object motion; no image boost/state/clock changes.'}
 results.append(row)
(out/'floor-track-fits.json').write_text(json.dumps({'source':str(e),'duration_ms':m['duration_ms'],'results':results,'caution':'Retrospective support fit is corroboration of seven overlapping-floor tracks, not isolated render proof; native per-entry proof supplies isolation.'},indent=2))
print(json.dumps([{'id':r['id'],'expected':r['expected_css_px_per_s'],'observed':r['best_observed_fit']['speed_css_px_per_s'],'score':r['best_observed_fit']['score']}for r in results]))
