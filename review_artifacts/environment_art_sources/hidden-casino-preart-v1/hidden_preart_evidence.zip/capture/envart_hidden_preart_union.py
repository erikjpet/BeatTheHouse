import sys,os,json,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
source=Path(sys.argv[1]); out=Path(os.environ['BTH_QA_EVIDENCE_DIR']); r=Path(os.environ['BTH_QA_WORKSPACE']); data=json.loads(source.read_text())
assert data['commit']=='d4beeb651403135ad4fa5f6fbf989af0d43478b6'
proof=json.loads((r/'hidden_source_identity.json').read_text())
def rect(d):return [round(float(d[k]),4) for k in ['x','y','w','h']]
def intersect(a,b):
 x=max(a[0],b[0]); y=max(a[1],b[1]); X=min(a[0]+a[2],b[0]+b[2]); Y=min(a[1]+a[3],b[1]+b[3]);return [x,y,max(0,X-x),max(0,Y-y)]
def valid(a):return a[2]>0 and a[3]>0
def subtract(a,b):
 i=intersect(a,b)
 if not valid(i):return [a]
 x,y,w,h=a; X=x+w;Y=y+h;u,v,ww,hh=i;U=u+ww;V=v+hh
 return [q for q in [[x,y,w,v-y],[x,V,w,Y-V],[x,v,u-x,hh],[U,v,X-U,hh]] if valid(q)]
def bounds(rows):
 if not rows:return None
 x=min(a[0] for a in rows);y=min(a[1] for a in rows);X=max(a[0]+a[2] for a in rows);Y=max(a[1]+a[3] for a in rows);return [x,y,X-x,Y-y]
def free(region,rects):
 cells=[region]
 for b in rects:cells=[p for cell in cells for p in subtract(cell,b)]
 return cells
regions={'left_table': [100, 154, 242, 86], 'right_table_mapped': [438, 142, 286, 98], 'doorway': [744, 88, 108, 178], 'cart_body': [40, 188, 70, 82], 'cart_top': [48, 168, 54, 20], 'floor': [0, 245, 900, 185], 'physical_bulb_1': [91, 51, 10, 10], 'physical_bulb_2': [163, 51, 10, 10], 'physical_bulb_3': [235, 51, 10, 10], 'physical_bulb_4': [307, 51, 10, 10], 'physical_bulb_5': [379, 51, 10, 10], 'physical_bulb_6': [451, 51, 10, 10], 'physical_bulb_7': [523, 51, 10, 10], 'physical_bulb_8': [595, 51, 10, 10], 'physical_bulb_9': [667, 51, 10, 10], 'physical_bulb_10': [739, 51, 10, 10], 'physical_bulb_11': [811, 51, 10, 10], 'physical_bulb_12': [883, 51, 10, 10]}
contexts={}; all_rows=[]; union={}; totals={'selected_cards':0,'actual_canvas_objects':0,'runtime_visual_records':0,'published_records':0,'authored_exclusions':0}
for name,view in data['views'].items():
 rows=[]; bypub={x['id']:x for x in view['published_evidence']}; bysel={x['id']:x for x in view['selected_label_evidence']}
 for ev in view['actual_canvas_evidence']:
  assert len(ev['geometry'])==1
  obj=ev['object']; geom=ev['geometry'][0]; model=rect(geom['rect']); label=rect(geom['label_rect']); hit=rect(geom['interaction_rect']); footprint=rect(geom['footprint']); selected=bysel[ev['id']]
  assert selected['actual_selected_info']['title']==ev['label'].strip()
  pub=bypub.get(ev['id'],{}).get('published_record',{})
  row={'context':name,'id':ev['id'],'label':ev['label'],'type':obj['type'],'surface':obj.get('surface'),'prop':obj.get('prop'),'model_rect':model,'label_rect':label,'interaction_rect':hit,'footprint_rect':footprint,'type_color_rgba':ev['type_color_rgba'],'disabled':obj.get('disabled',False),'z_order':geom['z_order'],'body_draw_layer':ev['body_draw_layer'],'slot_id':obj.get('slot_id',''),'placement_class':obj.get('placement_class',''),'geometric_model_base_center':[model[0]+model[2]/2,model[1]+model[3]],'source_object':obj,'published_record':pub,'selected_card':selected,'region_intersections':{k:{'model_envelope':intersect(model,v),'label_envelope':intersect(label,v),'hit_envelope':intersect(hit,v)} for k,v in regions.items() if valid(intersect(model,v)) or valid(intersect(label,v)) or valid(intersect(hit,v))}}
  assert ev['body_draw_layer'] in [-1,0,1]
  rows.append(row);all_rows.append(row);union.setdefault(ev['id'],[]).append(row)
 exclusions=[]; initial=view['initial_runtime_state'].get('semantic_state',{}); projected=view['same_state_publication'].get('projection',{}).get('semantic_state',{}); runtime_ids={x['id'] for x in view['runtime_visual_evidence']}
 for collection in ['actors','scene_objects']:
  for identity,raw in initial.get(collection,{}).items():
   if not identity.startswith('scenario::') or identity in runtime_ids:continue
   stable=raw.get('stable_object_id',''); hosts=[]
   for host,interaction in projected.get('interactions',{}).items():
    matching=[a for a in interaction.get('available_actions',[]) if stable and (a.get('attached_stable_object_id')==stable or a.get('action_origin_stable_object_id')==stable)]
    if matching:hosts.append({'host_id':host,'actions':matching,'actual_host_rows':[x for x in rows if x['id']==host]})
   hidden=not raw.get('present',True) or not raw.get('visible',True) or raw.get('presentation_mode','room')!='room'
   initial_interaction=initial.get('interactions',{}).get(identity,{})
   abstract_no_actions=collection=='scene_objects' and raw.get('role','').strip().lower() in ['decision_route','task_station','task_zone'] and not initial_interaction.get('available_actions',[]) and identity not in projected.get('scene_objects',{}) and identity not in projected.get('interactions',{}) and not any(x['id']==identity for x in rows)
   assert hidden or hosts or abstract_no_actions,(name,identity,'Unexplained missing authored visual')
   assert hidden or abstract_no_actions or all(h['actual_host_rows'] for h in hosts),(name,identity,'Hosted action lacks actual visible host')
   reason='Explicitly hidden or non-room in source' if hidden else 'Closed abstract control role with no own actions. Production resolver erases the scene/interactions entry and continues without a host; no independent physical visual or label.' if abstract_no_actions else 'Logical task station folded into a real production host; action identity retained. No separate in-room station or label.'
   exclusions.append({'identity':identity,'source_collection':collection,'source_record':raw,'source_interaction':initial_interaction,'reason':reason,'hosts':hosts,'source_contract':'environment_slot_binder.gd lines48-50,1129-1150 rejects closed attached-control roles before physical authority. scenario_layout_resolver.gd lines516-559 removes abstract scene/interaction then skips host attachment when actions are empty.' if abstract_no_actions else ''})
 shapes=[]
 relevant={}
 for key,region in regions.items():
  labels=[row['label_rect'] for row in rows]; models=[row['model_rect'] for row in rows]
  relevant[key]={'label_blockers':[{'id':row['id'],'label':row['label'],'rect':row['label_rect'],'intersection':intersect(row['label_rect'],region)} for row in rows if valid(intersect(row['label_rect'],region))],'model_blockers':[{'id':row['id'],'label':row['label'],'rect':row['model_rect'],'intersection':intersect(row['model_rect'],region)} for row in rows if valid(intersect(row['model_rect'],region))],'outside_all_model_and_label_envelopes':free(region,labels+models)}
 contexts[name]={'rows':rows,'actual_canvas_object_count':len(rows),'published_record_count':len(view['published_evidence']),'published_nonroom_records':[x for x in view['published_evidence'] if not x['room_visible']],'runtime_visual_record_count':len(view['runtime_visual_evidence']),'runtime_room_visible_ids':[x['id'] for x in view['runtime_visual_evidence'] if x['room_visible']],'runtime_excluded':[x for x in view['runtime_visual_evidence'] if not x['room_visible']],'semantic_exclusions':view['semantic_exclusions'],'authored_projection_exclusions':exclusions,'regions':relevant,'capture_clock':view['capture_clock'],'capture_process_frame':view['capture_process_frame'],'arrival':view['arrival'],'selected_card_count':len(bysel)}
 totals['selected_cards']+=len(bysel);totals['actual_canvas_objects']+=len(rows);totals['runtime_visual_records']+=len(view['runtime_visual_evidence']);totals['published_records']+=len(view['published_evidence']);totals['authored_exclusions']+=len(exclusions)
object_union={identity:{'label_bounding_union':bounds([x['label_rect'] for x in rows]),'model_bounding_union':bounds([x['model_rect'] for x in rows]),'hit_bounding_union':bounds([x['interaction_rect'] for x in rows]),'variants':[{'context':x['context'],'label':x['label'],'type':x['type'],'label_rect':x['label_rect'],'model_rect':x['model_rect'],'hit_rect':x['interaction_rect'],'body_draw_layer':x['body_draw_layer']} for x in rows]} for identity,rows in union.items()}
surfaces=next(x for x in json.loads((r/'data/environments/placement_surfaces.json').read_text())['maps'] if x['id']=='small_underground_casino:casino')
region_union={key:{'label_variants':[{'context':x['context'],'id':x['id'],'label':x['label'],'rect':x['label_rect']} for x in all_rows if valid(intersect(x['label_rect'],region))],'model_variants':[{'context':x['context'],'id':x['id'],'label':x['label'],'rect':x['model_rect']} for x in all_rows if valid(intersect(x['model_rect'],region))],'outside_all_context_model_and_label_envelopes':free(region,[x[field] for x in all_rows for field in ['model_rect','label_rect']])} for key,region in regions.items()}
result={'commit':data['commit'],'archive_sha256':proof['archive_sha256'],'input_hashes':{k:v for k,v in proof['files'].items() if k.startswith(('scripts/','data/environments/','data/art/environments/'))},'metadata_path':str(source),'metadata_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'checks':data['checks'],'findings':data['findings'],'scope':data['scope'],'totals':totals,'coordinates':'Board900x430;1800x860 replay doubles coordinates. All label/model/hit/footprint rectangles from actual production canvas, not p9 positions or name-length guesses.','geometry_caveat':'Model/body/label/hit rectangles are geometric envelopes, not exact opaque masks. Label cells contain transparent space; text uses alpha0.72 (active0.94), disabled0.56. Hit rectangles are interaction targets, not paint. Sprite shadows/glows may extend beyond model bounds. Free regions are outside reported envelopes, not a final pixel-composite visibility pass. No opaque body-mask claim is made; the named static room primitives come from unchanged source.','support_caveat':'Hidden casino only. Mapped opaque right foreground [438,142,286,98] overrides the older258-wide procedural body. No left foreground contract. Contacts and labels unchanged; rectangles are not pixel masks.','physical_regions':regions,'foreground_surfaces':[x for x in surfaces['counters'] if x.get('foreground_art_id')],'all_contact_surfaces':surfaces['counters'],'floor_support_definition':surfaces['floor'],'contexts':contexts,'object_union':object_union,'region_union':region_union,'image_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.parent.glob('*.png')}}

result['capture_input_manifest']=json.loads((r/'hidden_capture_inputs.json').read_text())
result['raw_current_room_overrides']=json.loads((r/'data/environments/developer_placement_overrides.json').read_text())['rooms']['small_underground_casino:casino']

result['static_region_source']='Unchanged pixel_scene_canvas.gd _draw_underground plus current :casino placement map. Twelve physical housings; first10 future aligned moving cores are a director plan, last2 remain steady; no source activation.'
assert data['findings']==[],data['findings']
assert len(contexts)==4
assert any(x.get('foreground_art_id')=='punchline_right_table' for x in result['foreground_surfaces'])
for name,view in data['views'].items():
 assert view['snapshot']['current_layer_id']=='casino'
 assert view['snapshot']['visual_context']['art_key']=='small_underground_casino'
 assert view['actual_view']['environment_id']=='small_underground_casino'
result['status']='ACTUAL_INITIAL_HIDDEN_CONTEXTS_ONLY_NOT_ART_PASS'
(out/'hidden_preart_union.json').write_text(json.dumps(result,indent=2),newline='\n')
lines=['# Hidden casino strictd4beeb pre-art metadata','',result['scope'],'',result['geometry_caveat'],'',result['support_caveat']]
for name,ctx in contexts.items():
 lines += ['', '## '+name]
 for x in ctx['rows']:lines.append(f"- {x['id']}: {x['label']!r}; label{x['label_rect']}; model{x['model_rect']}; hit{x['interaction_rect']}; layer{x['body_draw_layer']}; selected title{x['selected_card']['actual_selected_info']['title']!r}.")
 lines += ['Authored hidden/hosted exclusions: '+json.dumps(ctx['authored_projection_exclusions'])]
(out/'hidden_preart_union.md').write_text('\n'.join(lines),newline='\n')
print(json.dumps({'checks':data['checks'],'findings':data['findings'],'contexts':len(contexts),'totals':totals,'union_json':str(out/'hidden_preart_union.json')}))
