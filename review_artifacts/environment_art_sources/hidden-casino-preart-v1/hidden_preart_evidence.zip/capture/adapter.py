import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,json,hashlib,shutil
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'tools'))
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
from bth_qa_guarded_run import execute
tokens=sys.argv[1:]; split=tokens.index('--') if '--' in tokens else len(tokens)
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--timeout',type=int,default=300);p.add_argument('--cold-import',action='store_true');p.add_argument('--engine-go',action='store_true')
a=p.parse_args(tokens[:split]);command=tokens[split+1:]
assert not any('godot' in x.lower() for x in command) or a.engine_go,'Explicit ENGINE GO is required'
l=prepare_layout(plan_layout(root=r'E:/CodexQA/BTH',workspace=str(W),run_id='BTH-ENVART-HIDDEN-20261114-'+a.name))
validate_layout(l)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((W/'hidden_source_identity.json').read_text())
def verify():
 assert proof['commit']=='d4beeb651403135ad4fa5f6fbf989af0d43478b6'
 for rel,expected in proof['files'].items():assert sha(W/rel)==expected,rel
 assert not (W/'data/art/environments/small_underground_casino.json').exists()
 assert sha(Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers/data/environments/developer_placement_overrides.json'))==proof['files']['data/environments/developer_placement_overrides.json']
verify()
shutil.copyfile(__file__,l.evidence/'adapter.py')
shutil.copyfile(W/'hidden_source_identity.json',l.evidence/'source_identity.json')
shutil.copyfile(W/'hidden_capture_inputs.json',l.evidence/'hidden_capture_inputs.json')
for f in W.glob('tools/envart_hidden_*'):
 if f.is_file():shutil.copyfile(f,l.evidence/f.name)
command=[x.replace('{workspace}',str(W)).replace('{evidence}',str(l.evidence)) for x in command]
if not command:print('PREPARED_NO_ENGINE',l.evidence);sys.exit(0)
override=W/'override.cfg';policy=b'[editor]\nimport/use_multiple_threads=false\n\n[threading]\nworker_pool/max_threads=1\n'
if a.cold_import:
 validate_layout(l,extra_write_paths=(override,))
 with override.open('xb') as f:f.write(policy)
try:
 result=execute(l,command,timeout=a.timeout)
 verify()
 (l.evidence/'post_source_verification.json').write_text(json.dumps({'status':'UNCHANGED_ALL_TRACKED_AND_REFERENCES','files':len(proof['files']),'placement_override_sha256':proof['files']['data/environments/developer_placement_overrides.json']},indent=2),newline='\n')
finally:
 if a.cold_import and override.read_bytes()==policy:override.unlink()
print(json.dumps({k:result.get(k) for k in ['command','exit_code','error','cleanup_errors','timed_out','active_at_release']}));print('EVIDENCE',l.evidence)
sys.exit(0 if result.get('exit_code')==0 and result.get('active_at_release')==0 and not result.get('error') and not result.get('cleanup_errors') and not result.get('timed_out') else 1)
