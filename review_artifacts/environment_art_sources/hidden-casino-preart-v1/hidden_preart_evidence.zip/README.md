# Hidden casino current pre-art closure

Exact commit d4beeb651403135ad4fa5f6fbf989af0d43478b6; tree ab15335c54645803e4d840d4c90556019386b0de. Native four-context capture PASS14867 checks, no findings. Base12 / High-Stakes20 / Greased20 / New Muscle19 =71 actual objects and71 selected-title captures. Hidden pack remains absent; legacy fallback asserted in app and board replay.

Current right table is mapped438,142,286,98, not older258-wide primitive. Left table has no foreground replay contract. Actual source map, raw overrides, fixture/contact/route records, source painters, published membership and exclusions accompany PNGs.

Inherited overlaps preserved: Base Crew Back Room label intersects bulb11 and edge12 envelopes. Scenario Comedy Club label intersects bulb10. High-Stakes observer rail and Greased payoff ledger labels intersect bulb1. Greased inspection-seals model intersects2/3 envelopes, but envelopes are NOT opaque paint masks. Actual PNGs preserve bodies and sampled paint. No fabricated clipping mask or source edit.

Base does not contain the individual lender. Scenarios contain lender:street_lender titled Vic Mercer at the current authored anchor. This is source/runtime membership, not a missing prop. Dealer title Sable; Base leave Travel, scenarios Leave. Each scenario task0 is hosted on a real object, not an independently painted station. Exact selected-source title precedence is asserted.

Twelve physical housings/wires remain unchanged. Ten timed legacy cores remain97+74i,55 with original phases. Future first-ten alignment to centers96..744 and final-two steady remains director planning only, NOT implemented. Separate motion families remain unchanged. No hidden generation, assembly or activation.

Native import/capture Jobs drained exit0/active0/no cleanup errors; native released before Python union. Failed snapshot01 (unresolved git executable), union01 (absent Python path), union02 (helper key mismatch) receipts preserved; all drained. Raw metadata field same_state_hiddenation contains unchanged same-state production publication; union explicitly reads it. This diagnostic naming artifact changes no application source.

Strict Git archive SHA1306e911915bb7260bb2f267d7464c21ede70cf757f61556928344d443bd4885 remains in admitted workspace. Compact bundle carries full file hashes and exact relevant source. No target/main/NEXT/TEST changes or real saves used.
