# Corner R6 QA source archive

Non-active reproduction sources only. These files must not replace production renderer, scenario, placement, project, toolchain or save code. No target integration or deployment is performed by these helpers.

## Exact art and baseline
- Corner package: 6f1e76d5cb4f44dd73f494e4cf52fcf2eb433a0e849c6ee6bd0c090a36897dcb.
- Placement override: c5c9808497ee3d4f056bb5a7f24a64524d4e59ee50e3fff106eb41e09383245f.
- Original canvas: scripts/ui/pixel_scene_canvas.gd at commit e5152c34bfe146600214fb206ec80a5e3e8a27cb. Exact extracted source bytes have SHA256 78058e0092552e4aef4d6339041f9d1768af3c14f837ec4eed65e832ae88ee0d. The baseline source is code, not private runtime data.
- Retain accepted Gas files and cumulative index when staging. Verify all sealed package hashes first.

## Reproduction boundary
Use a fresh admitted E:/CodexQA/BTH workspace/run/profile/cache/temp/save/evidence layout. The adapter depends on maintained tools/bth_qa_storage.py and tools/bth_qa_guarded_run.py in the source repository. It revalidates storage and starts assigned-before-resume owned kill-on-close Jobs at 12 percent CPU and 2 GiB. Serialize native Godot jobs. Never use the adapter's full --sync option for an unpassed cumulative art workspace. Use explicit file sync only. Change hardcoded source/workspace/run prefix paths when reproducing elsewhere; do not select a C: output fallback or real user profile/save.

The scripts expect Godot 4.6 stable with the existing production project and gl_compatibility renderer. Windowed evidence uses 1280x720, Dummy audio, and --script res://tools/<helper>. Arguments after --: '--out=E:\CodexQA\BTH
uns\BTH-ENVART-CORNER-20261114-r6-repro-archive-01\evidence/proof' and '--baseline-source=<path to archived original canvas>'. Quote the entire output argument in PowerShell; do not leave braces unquoted. The adapter substitutes admitted evidence/workspace paths and supplies BTH_QA_* environment variables. Use fresh run IDs and preserve failed receipts.

## Correct helpers and assertions
- envart_corner_settled_r6.gd: real Base plus all five current Corner scenarios, normal autonomous actor arrivals, paired original/current same-snapshot geometry, labels, hits, z order and Reduce Motion. Closing uses a fresh Base advanced from actual noon to its authored 1 AM via public RunState clock advancement and normal app boundary. It does not force a closing state at a conflicting actual clock. Placement no-input redraw proof is included.
- envart_corner_sequence_proof_v3.gd and cases JSON: 28 authored aftermath families plus seven active work phases. Valid Runtime command/fact results cross unchanged ScenarioEngine commit and RunState physical-membership publication before the actual app renders. It validates live room authority and actual canvas object, geometry and nonempty label membership for expected materials. Every source-sealed room-visible visual and authored label is also asserted; hidden/non-room exclusions are explicit. --smoke-repaired-delivery limits the trial to one known context. These are production-model outcome views, not UI-click quest, save, revisit or travel end-to-end tests.
- envart_corner_animation_capture.gd: actual production room, 25 entries, full-app and same-renderer native texture frames. The excerpt uses actual canvas clock duration. Two neutral owned-viewport events precede recording; no pointer input during capture and no pixel painting, brightness or timing boost.
- envart_corner_animation_probe.gd: 25 per-entry actual native pixel changes and Reduce Motion; exact 10-frame register strip endpoints, atlas dimensions and original cycle.
- envart_corner_floor_wrap_probe.gd: seven authored movers, original rows/speeds/phases/wrap, visible midpoint and Reduce Motion. Seven movers are the director-approved consolidated translation, not a claim of literal legacy rectangle count equivalence.
- envart_corner_counter_person_fixture.gd: explicitly synthetic person at the exact 286-wide counter front, production counter replay and occlusion checks. It does not move the production Clerk, contacts or overrides.
- Mandatory unchanged scripts/tests/animation_liveness_without_pointer_check.gd remains separate. Run headless through the same capped launcher.
- envart_corner_collect_final_evidence.py binds exact package, unchanged production input hashes, accepted Gas, reports, PNGs and clean job receipts. It requires the named campaign directories and is a campaign-specific collector, not a generic runner.

## Preserved diagnostic caveats
The earlier v2 sequence helper skipped physical-membership publication. Its 403 passing checks proved state/authority dictionaries and fallback geometry, not actual scenario prop/actor rendering. Do not use v2 or the first summary as final outcome visual acceptance. Earlier failed recipe tests expected interrupted from leave_safely; content defines that command as refused. Correct recipes use the authored travel_departed fact. The initial closing fixture used a closing minute inconsistent with the actual noon clock, and the first settled helper had an indentation parse error. All receipts remain preserved separately.

Final art acceptance belongs to the independent auditor/director. This archive is not authorization to activate or deploy a candidate.


## Final label expectation correction and acceptance evidence
The full production-publication v3 capture executed 659 runtime assertions, with 12 expected-label findings only. All actual IDs and geometry, expected-material labels, and original/current geometry/RM pairs passed. The extra assertion incorrectly required the visual semantic label even where the existing production interaction overlay intentionally supplies a different authored label.

Use envart_corner_recheck_live_labels.py as the tested read-only companion to v3 for this exact campaign. It binds the unchanged production label-selection source and checks each exact state-authored interaction label against both the composed interaction record and actual canvas label/rectangle. All 63 source-visible visual occurrences pass. It resolves exactly the 12 original findings with 226 focused checks, preserving the original runtime exit1 receipt. This is not a nonempty-string relaxation and does not repaint or recapture evidence. The named paths and fixed counts are specific to this Corner R6 campaign; adapt case selection and supported label rules explicitly for another room.

Production source rule: environment_interaction_controller.gd _compose_projected_records builds the visual then applies _merge_projected_interaction; that function assigns the semantic interaction label. pixel_scene_canvas.gd _objects_from_interactable_records copies the final composed record label. This applies to the existing action prompts and exit capitalization. The recorded actual labels were correct.

Final exact summary: corner-r6-final-native-qa-summary.json, SHA256 7c8f0674598481abc273c284c815c675904d05284746851a31d8a86e0c652eb5. It binds 447 PNGs and 870 executed native assertions (858 original passes, 12 label-expectation diagnostics resolved by the separate 226-check revalidation), with counter fixture and no-input liveness separate. Do not add the focused rechecks as independent native coverage. No source or art change was made to resolve these assertions.
