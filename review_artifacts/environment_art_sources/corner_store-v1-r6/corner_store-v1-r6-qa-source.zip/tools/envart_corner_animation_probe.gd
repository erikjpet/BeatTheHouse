extends SceneTree
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const RendererScript := preload("res://scripts/ui/environment_art_renderer.gd")
var output := ""
var checks := 0
var failures: Array[String] = []
func _initialize() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--out="):
            output = argument.trim_prefix("--out=")
    call_deferred("_run")
func _run() -> void:
    DirAccess.make_dir_recursive_absolute(output)
    var pack := PackScript.load_pack("corner_store")
    if pack == null:
        push_error("Corner pack unavailable")
        quit(1)
        return
    _check(pack.animations.size()==25,"Exact25animation entries present")
    var rows: Array = []
    for entry in pack.animations:
        var solo := PackScript.new()
        solo.environment_id = pack.environment_id
        solo.background = pack.background
        solo.background_rect = pack.background_rect
        solo.animations.append(entry)
        var renderer := RendererScript.new()
        root.add_child(renderer)
        renderer.configure(solo)
        var t0 := 0.0
        var t1 := 0.5
        match entry.kind:
            PackScript.AnimationKind.PULSE:
                t0 = entry.period * 10.25 - entry.phase
                t1 = t0 + entry.period * 0.5
            PackScript.AnimationKind.MOVER:
                t0 = (entry.duration+entry.gap)*2.0 - entry.phase + entry.duration*0.5
                t1 = t0 + 1.0
            PackScript.AnimationKind.FRAMES:
                t0 = 0.05 / entry.fps
                t1 = 5.05 / entry.fps
        var live_a := await _render(renderer,t0,false)
        var live_b := await _render(renderer,t1,false)
        var still_a := await _render(renderer,t0,true)
        var still_b := await _render(renderer,t1+10.0,true)
        var live_changes := live_a.get_data()!=live_b.get_data()
        var reduced_stable := still_a.get_data()==still_b.get_data()
        _check(live_changes,entry.id+" makes an actual visible native-renderer pixel change")
        _check(reduced_stable,entry.id+" is pixel-identical with Reduce Motion across clocks")
        live_a.save_png(output.path_join(entry.id+"_live_a.png"))
        live_b.save_png(output.path_join(entry.id+"_live_b.png"))
        rows.append({"id":entry.id,"clock_a":t0,"clock_b":t1,"live_visible_change":live_changes,"reduce_motion_stable":reduced_stable,"still_hidden":entry.still_hidden})
        if entry.id == "register_edge_scanner":
            _check(entry.frame_count==10,"Register has all10frames")
            _check(entry.texture.get_width()==3720 and entry.texture.get_height()==4,"Register fullstrip is3720x4under4096")
            _check(is_equal_approx(float(entry.frame_count)/entry.fps,PI/3.0),"Register cycle preserves original1.04719755seconds")
            _check(entry.rect==Rect2(372,203,186,2),"Register placement remains above opaque front")
            var image := entry.texture.get_image()
            var positions: Array[int] = []
            for f in range(10):
                var lo := 372
                var hi := -1
                for y in range(4):
                    for x in range(372):
                        if image.get_pixel(f*372+x,y).a>0.0:
                            lo=mini(lo,x)
                            hi=maxi(hi,x)
                positions.append(lo)
                _check(lo==int(absf(sin(PI*float(f)/10.0))*164.0)*2,"Register phase%d preserves authored abs-sine strip coordinate"%f)
                _check(hi-lo+1==44,"Register phase%d preserves22boardpixel glint width"%f)
                _check(entry.frame_at((float(f)+0.05)/entry.fps,false)==f,"Register phase%d production frame selection"%f)
            _check(positions.min()==0 and positions.max()==328,"Register reaches both exact left/right travel endpoints")
            rows[-1]["register_atlas_native_x_positions"]=positions
        renderer.free()
        await process_frame
    var result := {"qa_only":true,"asset_or_manifest_modified":false,"renderer":"Actual unchanged EnvironmentArtRenderer","checks":checks,"failures":failures,"entries":rows,"note":"Fixed-clock per-entry native pixel proof is independent of actual no-input runtime excerpt. No contrast, alpha, brightness or timing boost."}
    var file := FileAccess.open(output.path_join("corner_animation_probe.json"),FileAccess.WRITE)
    file.store_string(JSON.stringify(result,"\t"))
    file.close()
    print("ENVART_CORNER_ANIMATION_PROBE ",JSON.stringify({"checks":checks,"failures":failures,"entries":rows.size()}))
    PackScript.shutdown_loading()
    await process_frame
    quit(0 if failures.is_empty() else 1)
func _render(renderer: Node,clock: float,reduced: bool) -> Image:
    renderer.present(clock,reduced,false)
    for _index in range(3):
        await process_frame
        await RenderingServer.frame_post_draw
    return (renderer.get("texture") as Texture2D).get_image()
func _check(ok: bool,label: String) -> void:
    checks+=1
    if not ok:
        failures.append(label)
        push_error(label)
