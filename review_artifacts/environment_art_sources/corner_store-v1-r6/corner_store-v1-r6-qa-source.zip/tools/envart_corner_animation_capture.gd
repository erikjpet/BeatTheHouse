extends "res://tools/environment_art_baseline_capture.gd"
const PreviewCanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
const PreviewPackScript := preload("res://scripts/ui/environment_art_pack.gd")
func _run() -> void:
    var admitted_evidence := OS.get_environment("BTH_QA_EVIDENCE_DIR").replace("\\", "/")
    var normalized_output := out_dir.replace("\\", "/")
    if admitted_evidence.is_empty() or not normalized_output.begins_with(admitted_evidence + "/"):
        push_error("Capture output must be an explicit child of this admitted run evidence directory.")
        quit(1)
        return
    var archetype := "gas_station_casino"
    var layer := ""
    var scenario := "__none"
    var excerpt_seconds := -1.0
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--excerpt-seconds="):
            excerpt_seconds = float(argument.trim_prefix("--excerpt-seconds="))
        elif argument.begins_with("--archetype="):
            archetype = argument.trim_prefix("--archetype=")
        elif argument.begins_with("--layer="):
            layer = argument.trim_prefix("--layer=")
        elif argument.begins_with("--scenario="):
            scenario = argument.trim_prefix("--scenario=")
    DirAccess.make_dir_recursive_absolute(out_dir)
    root.size = Vector2i(1280, 720)
    app = MainScene.instantiate()
    app.set("script_prewarm_stopping", true)
    root.add_child(app)
    await _settle(8)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id", app.get("environment_test_archetype_option"), archetype)
    app.call("_refresh_environment_test_identity_options")
    app.call("_environment_test_select_id", app.get("environment_test_scenario_option"), scenario)
    if not layer.is_empty():
        app.call("_environment_test_select_id", app.get("environment_test_layer_option"), layer)
    app.get("environment_test_seed_input").text = SEED_TEXT
    var generated: Dictionary = app.call("start_environment_test_session")
    if not bool(generated.get("ok", false)):
        push_error("Preview room generation failed: " + str(generated))
        quit(1)
        return
    var canvas: Control = app.get("environment_canvas")
    for _index in range(180):
        await process_frame
        if canvas.get("environment_art_pack") != null:
            break
    if canvas.get("environment_art_pack") == null:
        push_error("Preview candidate art pack did not load.")
        quit(1)
        return
    await _settle(8)
    # One real input event through the owned viewport, before autonomous recording.
    # Park on the canvas margin, not a live object; do not warp the desktop cursor.
    var neutral_pointer := InputEventMouseMotion.new()
    neutral_pointer.position = canvas.get_global_rect().position + Vector2(3, 3)
    neutral_pointer.global_position = neutral_pointer.position
    root.push_input(neutral_pointer, true)
    await process_frame
    neutral_pointer = InputEventMouseMotion.new()
    neutral_pointer.position = Vector2(900, 100) # Description HUD gap, not a live object.
    neutral_pointer.global_position = neutral_pointer.position
    root.push_input(neutral_pointer, true)
    await _settle(2)
    var pack: EnvironmentArtPack = canvas.get("environment_art_pack")
    var max_cycle := 3.0
    var max_fps := 5.0
    var inventory: Array = []
    for entry in pack.animations:
        var cycle := 0.0
        match entry.kind:
            PreviewPackScript.AnimationKind.FRAMES:
                cycle = float(entry.frame_count if entry.loop_mode != PreviewPackScript.LoopMode.PINGPONG else maxi(1, (entry.frame_count - 1) * 2)) / entry.fps
                max_fps = maxf(max_fps, entry.fps)
            PreviewPackScript.AnimationKind.PULSE, PreviewPackScript.AnimationKind.SWEEP:
                cycle = entry.period
            PreviewPackScript.AnimationKind.MOVER:
                cycle = entry.duration + entry.gap
            PreviewPackScript.AnimationKind.SCROLL:
                if entry.speed.x != 0.0:
                    cycle = maxf(cycle, entry.rect.size.x / absf(entry.speed.x))
                if entry.speed.y != 0.0:
                    cycle = maxf(cycle, entry.rect.size.y / absf(entry.speed.y))
        max_cycle = maxf(max_cycle, cycle)
        inventory.append({"id": entry.id, "kind": entry.kind, "cycle_seconds": cycle, "frame_count": entry.frame_count, "fps": entry.fps, "texture_size": [entry.texture.get_width(), entry.texture.get_height()], "rect": [entry.rect.position.x, entry.rect.position.y, entry.rect.size.x, entry.rect.size.y], "from": [entry.from_point.x, entry.from_point.y], "to": [entry.to_point.x, entry.to_point.y], "size": [entry.size.x, entry.size.y], "origin": [entry.origin.x, entry.origin.y], "clip": [entry.clip.position.x, entry.clip.position.y, entry.clip.size.x, entry.clip.size.y] if entry.has_clip else [], "web_low_detail": entry.web_low_detail})
    var capture_seconds := minf(20.0, max_cycle + 0.25)
    if excerpt_seconds > 0.0:
        capture_seconds = minf(capture_seconds, excerpt_seconds)
    var sample_fps := minf(20.0, maxf(10.0, max_fps * 2.0))
    var frame_count := ceili(capture_seconds * sample_fps)
    var before: Dictionary = canvas.call("current_view_snapshot")
    var board_renderer: Node = canvas.get("environment_art_renderer")
    if board_renderer == null or not bool(board_renderer.get("ready_to_present")):
        push_error("Production native art renderer is not ready.")
        app.queue_free()
        await process_frame
        quit(1)
        return
    var frames: Array = []
    var first_frame_clock := -1.0
    for index in range(frame_count):
        if first_frame_clock >= 0.0 and float(canvas.get("flicker")) - first_frame_clock >= capture_seconds:
            break
        await create_timer(1.0 / sample_fps).timeout
        await RenderingServer.frame_post_draw
        var name := "frame_%03d.png" % index
        var img := root.get_texture().get_image()
        var error := img.save_png(out_dir.path_join(name))
        if error != OK:
            push_error("Preview frame write failed: " + name)
            quit(1)
            return
        var board_name := "board2x_%03d.png" % index
        var board_img := (board_renderer.get("texture") as Texture2D).get_image()
        var board_error := board_img.save_png(out_dir.path_join(board_name))
        if board_error != OK:
            push_error("Native2x board frame write failed: " + board_name)
            quit(1)
            return
        var states: Array = []
        var clock: float = canvas.get("flicker")
        if first_frame_clock < 0.0:
            first_frame_clock = clock
        for entry in pack.animations:
            states.append({"id": entry.id, "frame": entry.frame_at(clock, false), "pulse": entry.pulse_at(clock, false), "mover_visible": entry.mover_visible_at(clock, false), "mover": str(entry.mover_at(clock, false)), "scroll": str(entry.scroll_at(clock, false)), "sweep": str(entry.sweep_at(clock, false))})
        frames.append({"file": name, "board2x_file": board_name, "clock": clock, "width": img.get_width(), "height": img.get_height(), "animation_states": states})
    var after: Dictionary = canvas.call("current_view_snapshot")
    var result := {"archetype": archetype, "layer": layer, "scenario": scenario, "seed": SEED_TEXT, "pack_active": canvas.get("environment_art_pack") != null, "frames": frames, "before": before, "after": after, "preview_only": true, "sample_fps": sample_fps, "capture_seconds_requested": capture_seconds, "actual_clock_span": float(frames[-1]["clock"]) - float(frames[0]["clock"]), "measured_frame_count": frames.size(), "max_animation_cycle": max_cycle, "cycle_capped": capture_seconds < max_cycle, "animation_inventory": inventory, "board2x_size": [1800,860], "native_art_layers_only": true, "native_art_source": "actual production canvas environment_art_renderer.texture", "note": "Actual production practice full UI plus its exact native1800x860 background-animation render target. Native art view excludes counter fronts/live objects; full UI retains them. A neutral owned-viewport mouse motion precedes recording; no pointer input during capture, synthetic animation or raster resizing. Desktop cursor is not moved. Nearest filter retained."}
    var file := FileAccess.open(out_dir.path_join("animation_capture.json"), FileAccess.WRITE)
    file.store_string(JSON.stringify(result, "\t"))
    file.close()
    print("ENVART_ANIMATION_CAPTURE ", JSON.stringify({"frame_count": frames.size(), "art_id": canvas.get("environment_id"), "out": out_dir}))
    app.queue_free()
    await process_frame
    quit(0)
