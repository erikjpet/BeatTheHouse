from pathlib import Path
import os,json,hashlib
w=Path(os.environ['BTH_QA_WORKSPACE']);out=Path(os.environ['BTH_QA_EVIDENCE_DIR']);source=Path(r'D:\Projects\Beat-The-House\.tmp\environment-art-layers')
p=Path(r'E:\CodexQA\BTH\runs\BTH-ENVART-CORNER-20261114-r6-live-sequences-01\evidence\proof\corner_sequence_live_proof.json')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=json.loads(p.read_text());assert j['checks']==659 and len(j['completed'])==35 and len(j['findings'])==12
assert all('source-authored label reaches actual canvas: scenario::' in f for f in j['findings'])
source_bindings={}
for rel in ['scripts/ui/environment_interaction_controller.gd','scripts/ui/pixel_scene_canvas.gd','scripts/core/scenario_layout_resolver.gd']:
 assert h(w/rel)==h(source/rel)
 source_bindings[rel]=h(w/rel)
controller=(w/'scripts/ui/environment_interaction_controller.gd').read_text()
assert 'result["label"] = str(semantic.get("label", result.get("label", presentation_id)))' in controller
assert 'var merged := _merge_projected_interaction(visual_base, semantic,' in controller
canvas=(w/'scripts/ui/pixel_scene_canvas.gd').read_text()
assert '"label": str(record.get("label", ""))' in canvas
checks=0;failures=[];rows=[];resolved=[]
def check(ok,message):
 global checks
 checks+=1
 if not ok:failures.append(message)
for name,v in j['views'].items():
 check(v['live_authority']['ok'],name+' causal authority')
 semantic=v['snapshot']['scenario_sequence_state']['semantic_state'];interactions=semantic.get('interactions',{})
 for visual in v['source_visual_evidence']:
  if not visual['room_visible']:continue
  identity=visual['id'];interaction=interactions.get(identity,{})
  has_interaction=bool(interaction) and interaction.get('present',True)
  expected=interaction.get('label',visual['source_label']) if has_interaction else visual['source_label']
  published=[r for r in v['snapshot']['interactable_objects'] if r.get('object_id')==identity]
  check(len(published)==1 and published[0].get('label')==expected,name+' exact composed record label '+identity)
  check(len(visual['actual_objects'])==1 and len(visual['actual_geometry'])==1,name+' actual object/geometry '+identity)
  rect=visual['actual_geometry'][0]['label_rect'] if len(visual['actual_geometry'])==1 else {}
  check(visual['actual_label']==expected and bool(expected) and rect.get('w',0)>0 and rect.get('h',0)>0,name+' exact rendered dynamic label '+identity)
  row={'context':name,'id':identity,'visual_semantic_label':visual['source_label'],'interaction_semantic_label':interaction.get('label'),'expected_final_label':expected,'published_label':published[0].get('label') if len(published)==1 else None,'actual_canvas_label':visual['actual_label'],'label_rect':rect,'rule':'Present interaction label overrides the visual label; the canvas copies the composed record label.' if has_interaction else 'No present interaction override; use the visual semantic label.'}
  rows.append(row)
  if visual['source_label']!=visual['actual_label']:resolved.append(row)
check(len(rows)==63,'All 63 visible sealed source visual occurrences rechecked')
check(len(resolved)==12,'Exactly the 12 original label predicate findings are resolved')
report={'status':'PASS_FOCUSED_CORRECTED_LABEL_EXPECTATIONS' if not failures else 'FAIL','checks':checks,'failures':failures,'original_report':str(p),'original_report_sha256':h(p),'original_runtime_checks':659,'original_runtime_findings':j['findings'],'original_runtime_clean_checks':647,'original_runtime_exit_code':1,'scope':'Read-only revalidation of existing immutable actual production snapshots and canvas geometry. No recapture, no game/art changes, no acceptance based only on nonempty strings. Exact authored interaction-label precedence is checked against each published record and actual canvas label.','source_bindings_sha256':source_bindings,'production_source_locations':{'scripts/ui/environment_interaction_controller.gd':'_compose_projected_records around1577 merges visual then interaction; _merge_projected_interaction line1622 assigns semantic interaction label.','scripts/ui/pixel_scene_canvas.gd':'_objects_from_interactable_records line6075 copies composed record label.'},'visible_source_occurrences':len(rows),'resolved_original_findings':resolved,'rows':rows}
t=out/'corner-r6-live-label-revalidation.json';t.write_text(json.dumps(report,indent=2));print(json.dumps({'status':report['status'],'checks':checks,'failures':failures,'visible_source_occurrences':len(rows),'resolved_findings':len(resolved),'path':str(t),'sha256':h(t)}));raise SystemExit(1 if failures else 0)
