import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,json,hashlib,os,struct,shutil,datetime
parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);args=parser.parse_args()
out=Path(args.out).resolve();admitted=Path(os.environ['BTH_QA_EVIDENCE_DIR']).resolve();assert out==admitted
work=Path(os.environ['BTH_QA_WORKSPACE']);source=Path(r'D:\Projects\Beat-The-House\.tmp\environment-art-layers');runs=Path(r'E:\CodexQA\BTH\runs');prefix='BTH-ENVART-CORNER-20261114-'
package=Path(r'E:\CodexQA\BTH\workspaces\BTH-ENVART-AUDIT-20261114\packages\corner_store-v1-r6')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
seal=read(package/'package-seal.json');expected='6f1e76d5cb4f44dd73f494e4cf52fcf2eb433a0e849c6ee6bd0c090a36897dcb';assert seal['package_sha256']==expected
assert hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(seal['files'].items())).encode()).hexdigest()==expected
for rel,row in seal['files'].items():assert h(package/rel)==row['sha256']==h(work/rel)
stage=read(runs/(prefix+'stage-r6-01')/'evidence/stage.json')
for rel,digest in stage['gas_preserved'].items():assert h(work/rel)==digest
logic={}
for rel in ['scripts/core/run_state.gd','scripts/core/scenario_engine.gd','scripts/core/scenario_sequence_runtime.gd','scripts/core/scenario_layout_resolver.gd','scripts/ui/foundation_main.gd','scripts/ui/pixel_scene_canvas.gd','scripts/ui/environment_art_pack.gd','scripts/ui/environment_art_renderer.gd','scripts/tests/animation_liveness_without_pointer_check.gd','data/environments/placement_surfaces.json','data/environments/developer_placement_overrides.json','data/environments/scenarios.json','data/environments/scenario_sequences/env06_7_shops_streets.json','project.godot','export_presets.cfg']:
 assert h(work/rel)==h(source/rel),rel
 logic[rel]=h(work/rel)
assert logic['data/environments/developer_placement_overrides.json']=='c5c9808497ee3d4f056bb5a7f24a64524d4e59ee50e3fff106eb41e09383245f'
reports={};data={}
files={'scenarios':'r6-settled-scenarios-02/evidence/proof/corner_proof.json','sequence_contexts':'r6-live-sequences-01/evidence/proof/corner_sequence_live_proof.json','animation':'r6-animation-01/evidence/probe/corner_animation_probe.json','floor':'r6-floor-01/evidence/probe/floor_wrap_probe.json','counter':'r6-counter-01/evidence/fixture/counter_person_fixture.json','motion':'r6-motion-01/evidence/frames/animation_capture.json','liveness':'r6-liveness-01/evidence/worker.log','label_revalidation':'r6-label-recheck-01/evidence/corner-r6-live-label-revalidation.json'}
for key,rel in files.items():
 p=runs/(prefix+rel);reports[key]={'path':str(p),'sha256':h(p)}
 if key!='liveness':data[key]=read(p)
assert not data['scenarios']['findings']
assert data['label_revalidation']['status']=='PASS_FOCUSED_CORRECTED_LABEL_EXPECTATIONS' and data['label_revalidation']['checks']==226 and not data['label_revalidation']['failures']
assert data['label_revalidation']['original_report_sha256']==reports['sequence_contexts']['sha256']
assert len(data['sequence_contexts']['findings'])==12 and data['sequence_contexts']['findings']==data['label_revalidation']['original_runtime_findings']
for key in ['animation','floor']:assert not data[key]['failures']
assert data['sequence_contexts']['checks']>=533 and len(data['sequence_contexts']['completed'])==35
assert len(data['sequence_contexts']['case_catalog']['cases'])==35
assert data['animation']['checks']==86 and len(data['animation']['entries'])==25
assert data['floor']['checks']==71 and len(data['floor']['glints'])==7
assert data['scenarios']['checks']==54
assert data['counter']['counter_pixel_mismatches']==0 and data['counter']['body_pixels_covered']>0 and data['counter']['torso_pixels_unchanged']
assert 'Animation liveness without pointer input: PASS' in Path(reports['liveness']['path']).read_text()
for name,row in data['sequence_contexts']['views'].items():
 assert row['prepared'] and row['comparison']['layout_equal'] and row['reduce_motion_comparison']['layout_equal'] and row['reduce_motion_comparison']['reduce_motion_stable']
 assert row['actual_arrival_wait']['remaining_person_transits']==0
jobs={}
for name in ['r6-import-01','r6-motion-01','r6-settled-scenarios-02','r6-live-sequences-01','r6-live-smoke-01','r6-animation-01','r6-floor-01','r6-counter-01','r6-liveness-01','r6-label-recheck-01']:
 p=runs/(prefix+name)/'evidence/job.json';j=read(p);assert j['exit_code']==(1 if name=='r6-live-sequences-01' else 0) and j['active_at_release']==0 and not j.get('error') and not j.get('cleanup_errors') and not j.get('timed_out') and j['assigned_before_execution']
 jobs[name]={'path':str(p),'sha256':h(p),'exit_code':j['exit_code'],'active_at_release':j['active_at_release'],'assigned_before_execution':j['assigned_before_execution'],'limits':j['limits']}
diags=[]
for name,reason in [('r6-scenarios-01','44/45. Earlier QA fixture called begin_closing_time with1380 while actual clock remained noon; normal open-hours boundary clears this forced state. Corrected by freshBase at authored1am through publicclock advancement and normalboundary.'),('r6-settled-scenarios-01','QA helper parse failure before application execution: mixed tab/space indentation. Corrected helper preserved in preparation evidence.'),('r6-sequences-01','403checks/8findings: four recipes incorrectly expected interrupted from leave_safely, which current content defines as refused. Corrected recipes use authored travel_departed facts; entire35context suite rerun.')]:
 p=runs/(prefix+name)/'evidence/job.json';j=read(p);assert j['exit_code']!=0 and j['active_at_release']==0
 diags.append({'job':str(p),'job_sha256':h(p),'reason':reason,'worker_log':str(p.parent/'worker.log'),'worker_log_sha256':h(p.parent/'worker.log')})
pngs={}
for name in ['r6-motion-01','r6-settled-scenarios-02','r6-live-sequences-01','r6-live-smoke-01','r6-animation-01','r6-floor-01','r6-counter-01']:
 for p in (runs/(prefix+name)/'evidence').rglob('*.png'):
  b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n';pngs[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'size':list(struct.unpack('>II',b[16:24])),'bytes':len(b)}
assert len(pngs)==447,len(pngs)
helpers={}
for rel in ['corner_adapter.py','corner_stage_sealed.py','tools/envart_corner_animation_capture.gd','tools/envart_corner_settled_r6.gd','tools/envart_corner_sequence_proof_v3.gd','tools/envart_corner_sequence_cases.json','tools/envart_corner_animation_probe.gd','tools/envart_corner_floor_wrap_probe.gd','tools/envart_corner_counter_person_fixture.gd','tools/envart_corner_recheck_live_labels.py','tools/envart_corner_collect_final_evidence.py']:
 p=work/rel;target=out/('qa-input-'+p.name);shutil.copyfile(p,target);helpers[rel]={'sha256':h(p),'evidence_copy':str(target)}

label_expectations={(r['context'],r['id']):r for r in data['label_revalidation']['rows']}
live_counts={'contexts':35,'expected_material_occurrences':0,'source_visual_occurrences':0,'visible_source_occurrences':0,'source_label_occurrences':0,'explicitly_non_room_or_hidden':0}
for name,row in data['sequence_contexts']['views'].items():
 assert row['live_authority']['ok'], name
 for identity,m in row['material_evidence'].items():
  assert len(m['actual_objects'])==1 and len(m['actual_geometry'])==1 and m['label'],(name,identity)
  assert m['actual_geometry'][0]['label_rect']['w']>0 and m['actual_geometry'][0]['label_rect']['h']>0
  live_counts['expected_material_occurrences']+=1
 for v in row['source_visual_evidence']:
  live_counts['source_visual_occurrences']+=1
  if v['room_visible']:
   live_counts['visible_source_occurrences']+=1
   assert len(v['actual_objects'])==1 and len(v['actual_geometry'])==1,(name,v['id'])
   if v['source_label']:
    live_counts['source_label_occurrences']+=1
    assert label_expectations[(name,v['id'])]['expected_final_label']==v['actual_label'] and v['actual_geometry'][0]['label_rect']['w']>0 and v['actual_geometry'][0]['label_rect']['h']>0
  else:
   live_counts['explicitly_non_room_or_hidden']+=1
   assert v['exclusion']
assert live_counts['expected_material_occurrences']==30
assert live_counts['visible_source_occurrences']>30
counted_checks={'native_executed':54+86+71+data['sequence_contexts']['checks'],'native_passed_original':54+86+71+647,'native_label_expectation_findings':12,'resolved_by_exact_production_label_recheck':12,'focused_readonly_rechecks':226,'note':'Do not sum focused rechecks as independent native tests; they overlap the immutable 35-context capture evidence. Smoke23, counter fixture and standalone liveness are separate.'}
limited=[]
for name,rel in [('r6-sequences-02','proof/corner_sequence_proof.json'),('r6-summary-01','corner-r6-native-qa-summary.json')]:
 p=runs/(prefix+name)/'evidence'/rel
 limited.append({'path':str(p),'sha256':h(p),'limitation':'Superseded as final outcome visual evidence. V2 bypassed RunState physical-membership publication: expected IDs existed only in authority dictionaries while actual app geometry omitted scenario actors/props. Its passed checks are limited Runtime state and same-snapshot fallback geometry diagnostics; not full production outcome rendering. Corrected full live suite uses unchanged production commit/publication and actual rendered membership/label assertions.'})

closing=data['scenarios']['views']['closing_time'];motion=data['motion']
summary={'status':'PASS_SCOPED_NATIVE_QA_PENDING_INDEPENDENT_FINAL_ART_AUDIT','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'package_sha256':expected,'package_root':str(package),'package_files':seal['files'],'unchanged_production_inputs_sha256':logic,'gas_files_preserved':stage['gas_preserved'],'reports':reports,'job_receipts':jobs,'preserved_failed_diagnostics':diags,'superseded_limited_diagnostics':limited,'actual_live_membership_counts':live_counts,'counted_checks':counted_checks,'counts':{'settled_initial_scenarios_and_base_plus_authored_closing':54,'all25_entry_pixels_reduce_motion_register':86,'seven_floor_wrap':71,'sequence_contexts':data['sequence_contexts']['checks']},'sequence_scope':{'aftermath_families':28,'active_work_phases':7,'contexts':[{k:row.get(k) for k in ['scenario_id','kind','phase','outcome','commands','fact','expected_material_ids']} for row in data['sequence_contexts']['case_catalog']['cases']],'method':'QA-owned valid authored Runtime action/fact transactions, followed by unchanged ScenarioEngine commit and RunState physical-membership publication. Actual canvas objects, labels and geometry are asserted for each expected material and every source-sealed room-visible visual. Normal autonomous actor-arrival waits. Production-model outcome visual coverage, not UI end-to-end quest, save, revisit or travel traversal.'},'closing_scope':{k:closing[k] for k in ['authored_hours','clock_before_minute','clock_advance_minutes','clock_result','closed_status','normal_clock_boundary_result','status','note']},'counter_fixture':data['counter'],'motion':{'frames':len(motion['frames']),'first_clock':motion['frames'][0]['clock'],'last_clock':motion['frames'][-1]['clock'],'actual_seconds':motion['actual_clock_span'],'entries':len(motion['animation_inventory']),'full_app_size':[1280,720],'native_art_size':[1800,860],'pointer_note':'Two neutral owned-viewport pointer motions precede recording; no pointer input during capture. No pixel paintout, contrast/brightness or timing boost.'},'png_evidence':pngs,'qa_helper_inputs':helpers,'baseline_canvas_source':{'path':r'E:\CodexQA\BTH\runs\BTH-ENVART-001-r2-baseline-source-01\evidence\worker.log','sha256':h(Path(r'E:\CodexQA\BTH\runs\BTH-ENVART-001-r2-baseline-source-01\evidence\worker.log'))},'target_integration_or_deployment_performed':False,'label_expectation_resolution':'Original full live run executed659 checks with12 source-visual label equality findings and exited1. Read-only226-check source-bound revalidation proves each actual label equals its authored interaction override, matching unchanged production composition. Original receipt remains unmodified.','limits':'Native scoped compatibility and pixel/art proof only. No Web/TEST deployment verification in this worker. Final package PASS belongs to independent auditor/director.'}
p=out/'corner-r6-final-native-qa-summary.json';p.write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'status':summary['status'],'counted_checks':counted_checks,'pngs':len(pngs),'clean_jobs':sum(j['exit_code']==0 for j in jobs.values()),'native_label_diagnostic_jobs':1,'preserved_failed_jobs':len(diags),'path':str(p),'sha256':h(p)}))
