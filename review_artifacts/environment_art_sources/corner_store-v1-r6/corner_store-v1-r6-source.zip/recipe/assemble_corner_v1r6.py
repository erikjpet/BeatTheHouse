import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw,ImageEnhance
sys.dont_write_bytecode=True
sys.path.insert(0,r"D:\Projects\Beat-The-House\.tmp\environment-art-layers\tools")
from bth_qa_storage import Layout,validate_layout
m=json.loads((Path(os.environ["BTH_QA_EVIDENCE_DIR"])/"storage-manifest.json").read_text())
layout=Layout(**{k:Path(v) for k,v in m["paths"].items()},run_id=m["run_id"],token=m["token"],prepared=True,expected_write_bytes=m["expected_write_bytes"],reserve_bytes=m["reserve_bytes"])
root=layout.workspace/"packages/corner_store-v1-r6";validate_layout(layout,extra_write_paths=(root,));assert not root.exists();root.mkdir()
asset=root/"assets/art/environments/corner_store";(asset/"anim").mkdir(parents=True);(asset/"counters").mkdir()
(root/"data/art/environments").mkdir(parents=True)
src=Path(r"E:\CodexQA\BTH\workspaces\BTH-ENVART-ARTIST-20261114\corner_store-v1\source")
sources={}
def read(name,want):
    p=src/name;raw=p.read_bytes();got=hashlib.sha256(raw).hexdigest();assert got==want
    im=Image.open(p);sources[name]={"path":str(p),"sha256":got,"size":list(im.size)};return im
s=read("background-guide-v1.png","1bb9875380477849768c0e6a45a5001e769176f55e8faf871757537e63f6d1ad").convert("RGB").resize((900,430),Image.Resampling.NEAREST)
carton=read("carton-source-v1.png","cb903221fd96163532b80230863198cfc17e354b37be678b19979310a0d08471").convert("RGBA")
guide=layout.workspace/"guides/corner_store_clean_geometry_1800x860.png";assert hashlib.sha256(guide.read_bytes()).hexdigest()=="79ec8437e3da13986fb6032deeaa2c236a52ac844ed50f1e77a8e9021da0c05c"
sources["frozen_geometry"]={"path":str(guide),"sha256":hashlib.sha256(guide.read_bytes()).hexdigest()}
facade=Path(r"D:\Projects\Beat-The-House\.tmp\environment-art-layers\assets\art\travel\exteriors\corner_store.png")
assert hashlib.sha256(facade.read_bytes()).hexdigest()=="66707ca8d4da8dc7977731c42c3ad8ac643cc878752c9b7c69dd691b143ebefa"
sources["actual_facade"]={"path":str(facade),"sha256":hashlib.sha256(facade.read_bytes()).hexdigest()}
b=s.copy()
def brick_patch(rect):
    p=b.load();sp=s.load()
    for y in range(rect[1],rect[3]):
        for x in range(rect[0],rect[2]):p[x,y]=sp[300+(x-300)%28,min(244,y)]
# Remove old generated fixture margins, never leave baked ghosts after modular exact fitting.
for a in ((78,0,100,245),(210,0,234,245),(614,0,636,245),(760,0,782,245),(44,212,298,221),(330,88,590,96),(330,96,338,245),(632,102,817,221),(364,50,494,90),(632,50,742,91)):
    brick_patch(a)
# Restore fascia through the removed sign margins; signs/columns overlay it.
p=b.load();sp=s.load()
for y in range(44,65):
    for a,z in ((364,494),(632,742)):
        for x in range(a,z):p[x,y]=sp[12,y]
# Remove all source tube bodies; the exact10 authored bodies plus10 independent pulses are placed below.
p=b.load()
for y in range(18,34):
    for x in range(900):p[x,y]=sp[x,8+(y-18)%9]
# Matte cool linoleum from clean source floor, no Gas plank copy or global desaturation.
floor=s.crop((0,355,900,430)).resize((900,185),Image.Resampling.NEAREST)
b.paste(floor,(0,245))
# Retain a source baseboard at exact horizon.
b.paste(s.crop((0,255,900,270)).resize((900,7),Image.Resampling.NEAREST),(0,238))
# Exact pillars behind fixtures, ending238, no source270-height extensions.
for source_x,target_x in ((80,78),(212,212),(616,620),(762,758)):
    col=s.crop((source_x,0,source_x+18,270)).resize((18,238),Image.Resampling.NEAREST)
    b.paste(col,(target_x,0))
# Left cabinet retains source outer craft/mint hood; exact authored lips replace the shifted source rows.
for sy0,sy1,dy0,dy1 in ((69,106,64,108),(106,138,108,136),(138,166,136,164),(166,195,164,192),(195,218,192,212)):
    b.paste(s.crop((45,sy0,296,sy1)).resize((258,dy1-dy0),Image.Resampling.NEAREST),(42,dy0))
back=s.crop((60,110,280,132)).resize((235,106),Image.Resampling.NEAREST);b.paste(back,(54,100))
lip=s.crop((54,133,289,141))
lp=lip.load()
for yy in range(1,7):
    for xx in range(lip.width):
        r,g,bl=lp[xx,yy]
        if r>bl*1.03 and r>g*.97 and max(r,g,bl)>80 and min(r,g,bl)<232:
            lp[xx,yy]=(round(r*.26+3),round(g*.25+3),round(bl*.38+4))
for yy in (108,136,164,192):b.paste(lip,(54,yy))
# Only the real pale header face is painted, thin cream outer ridges and mint-white core remain.
bp=b.load()
for yy in range(65,83):
    for xx in range(50,292):
        r,g,bl=bp[xx,yy]
        if r>bl*1.04 and r>g*.97 and max(r,g,bl)>75:
            bp[xx,yy]=(round(r*.26+3),round(g*.25+3),round(bl*.38+4))
# Clerk recess and continuous shelf at142..149, no black clerk-placeholder or baked phone.
recess=s.crop((333,91,586,207)).resize((246,114),Image.Resampling.NEAREST)
b.paste(recess,(338,92))
# Source shelf top is near board145; exact contact strip is reset from authored source lip.
lip=s.crop((347,143,572,152)).resize((218,7),Image.Resampling.NEAREST)
# Quiet source recess material erases any former shifted lip before replaying exact crosspiece.
for y in range(136,154):
    for x in range(350,572):b.putpixel((x,y),s.getpixel((min(570,x),124)))
# Coherent physical split: pale Phone-left, dark Clerk-center/right. Exact crosspiece142..149 stays.
rp=lip.load()
for yy in range(1,7):
    for xx in range(60,218):
        r,g,bl=rp[xx,yy]
        if min(r,g,bl)>54:rp[xx,yy]=(round(r*.27),round(g*.28),round(bl*.43))
b.paste(lip,(352,142))
# Cooler: shelf contact bands136 and190 rather than floating generated positions.
for sy0,sy1,dy0,dy1 in ((103,144,114,136),(144,184,136,190),(184,218,190,208)):
    b.paste(s.crop((633,sy0,814,sy1)).resize((168,dy1-dy0),Image.Resampling.NEAREST),(642,dy0))
# Current small left support, empty of phone: live coin-pusher occupies it.
b.paste(s.crop((167,271,272,352)).resize((100,74),Image.Resampling.NEAREST),(170,270))
# Cyan coin-pusher label needs a dark physical apron; cream top, drawer and legs remain.
bp=b.load()
for yy in range(272,286):
    for xx in range(171,269):
        r,g,bl=bp[xx,yy]
        if max(r,g,bl)>65 and min(r,g,bl)<232:
            bp[xx,yy]=(round(r*.25+3),round(g*.25+3),round(bl*.40+4))
# Four ordinary subdued unbranded closed cartons at existing cluster, no offer icons.
mask=carton.getchannel("A").point(lambda a:255 if a>16 else 0);carton=carton.crop(mask.getbbox()).resize((42,32),Image.Resampling.NEAREST)
carton=ImageEnhance.Brightness(carton.convert("RGB")).enhance(.78).convert("RGBA")
carton.putalpha(read("carton-source-v1.png","cb903221fd96163532b80230863198cfc17e354b37be678b19979310a0d08471").convert("RGBA").crop(mask.getbbox()).resize((42,32),Image.Resampling.NEAREST).getchannel("A"))
shadow=Image.new("RGBA",(900,430),(0,0,0,0));sd=ImageDraw.Draw(shadow)
for i in range(4):sd.ellipse((643+48*i,249,683+48*i,252),fill=(8,6,17,105))
b=Image.alpha_composite(b.convert("RGBA"),shadow).convert("RGB")
for i in range(4):b.paste(carton,(642+48*i,220),carton)
# Full authoritative286-wide solid front; cream left laminate, subdued plum right cabinet for cyan book label.
counter=s.crop((330,207,620,272)).resize((286,48),Image.Resampling.NEAREST).convert("RGBA")
cp=counter.load()
for y in range(6,48):
    for x in range(74,286):
        r,g,bl,a=cp[x,y]
        if min(r,g,bl)>54:cp[x,y]=(round(r*.27),round(g*.28),round(bl*.43),255)
        if x==74 and y>8:cp[x,y]=(25,20,37,255)
counter.putalpha(255);b.paste(counter.convert("RGB"),(338,206))
counter.resize((572,96),Image.Resampling.NEAREST).save(asset/"counters/corner_store_register.png")
# Architectural signs preserve source letter/detail craft; no stock/people baked into them.
signs=[("lotto",(365,51,491,88),(376,42,142,34),"warm"),("beer",(634,51,739,88),(642,56,146,42),"mint")]
animations=[]
for name,box,rect,kind in signs:
    im=s.crop(box).resize((rect[2],rect[3]),Image.Resampling.NEAREST).convert("RGBA")
    pulse=Image.new("RGBA",im.size,(0,0,0,0));ip=im.load();pp=pulse.load()
    for y in range(im.height):
        for x in range(im.width):
            r,g,bl,a=ip[x,y]
            lit=(r>150 and g>120 and bl<r*.9) if kind=="warm" else (g>130 and bl>90 and g>r*1.5)
            if lit:
                pp[x,y]=(r,g,bl,190);ip[x,y]=(round(r*.72),round(g*.72),round(bl*.72),255)
    b.paste(im.convert("RGB"),rect[:2]);pulse.resize((rect[2]*2,rect[3]*2),Image.Resampling.NEAREST).save(asset/f"anim/{name}_pulse.png")
    speed=6.2 if name=="lotto" else 4.6
    animations.append({"id":name+"_pulse","type":"pulse","texture":f"anim/{name}_pulse.png","rect":list(rect),"min_opacity":.08,"max_opacity":.42,"period":2*math.pi/speed,"blend":"add","still":"first"})
# Ten exact tube rects, independent original9rad/s flicker phases. Fullhousing stays fixed, only luminouscore pulses.
tube=s.crop((22,21,83,32)).resize((60,8),Image.Resampling.NEAREST).convert("RGB")
core=Image.new("RGBA",(60,8),(0,0,0,0));tp=tube.load();kp=core.load()
for y in range(8):
    for x in range(60):
        r,g,bl=tp[x,y]
        if min(r,g,bl)>138 and g>=r*.94:
            kp[x,y]=(r,g,bl,220);tp[x,y]=(round(r*.52),round(g*.52),round(bl*.52))
core.resize((120,16),Image.Resampling.NEAREST).save(asset/"anim/tube_core.png")
for i in range(10):
    x=24+84*i;b.paste(tube,(x,22))
    animations.append({"id":f"overhead_tube_{i}","type":"pulse","texture":"anim/tube_core.png","rect":[x,22,60,8],"min_opacity":.33,"max_opacity":.57,"period":2*math.pi/9,"phase":x/9,"blend":"add","still":"first"})
# Full-size authored overhead scan, corrected originalx0/x1/y0/y1 region and speed; no undersized tile.
scan=Image.new("RGBA",(784,52),(0,0,0,0));d=ImageDraw.Draw(scan)
d.line((0,0,783,0),fill=(168,211,201,92),width=2);d.line((0,19,783,19),fill=(133,179,177,50),width=1)
scan.resize((1568,104),Image.Resampling.NEAREST).save(asset/"anim/overhead_scan.png")
animations.append({"id":"overhead_scan","type":"scroll","texture":"anim/overhead_scan.png","rect":[36,20,784,52],"speed":[0,38],"opacity":.30,"blend":"add","still":"hide"})
# Register22px edge glint follows original abs(sin3t) travel, adapted above opaque front, not through holes.
F=10;scanner=Image.new("RGBA",(186*F,2),(0,0,0,0));d=ImageDraw.Draw(scanner)
for f in range(F):
    xx=int(abs(math.sin(math.pi*f/F))*164)+f*186
    d.line((xx,0,xx+21,0),fill=(151,255,218,230),width=1)
    d.line((xx+3,1,xx+18,1),fill=(89,206,192,150),width=1)
scanner.resize((186*2*F,4),Image.Resampling.NEAREST).save(asset/"anim/register_scanner.png")
animations.append({"id":"register_edge_scanner","type":"frames","texture":"anim/register_scanner.png","rect":[372,203,186,2],"frames":F,"fps":F*3/math.pi,"loop":"loop","opacity":.72,"blend":"add","still":"hide"})
# Four tiny glass/trim reflections. Buried two move only to actual visible counter-top band.
star=Image.new("RGBA",(5,5),(0,0,0,0));d=ImageDraw.Draw(star);d.line((0,2,4,2),fill=(151,244,215,180));d.line((2,0,2,4),fill=(172,255,233,180));d.point((2,2),fill=(233,255,242,230))
star.resize((10,10),Image.Resampling.NEAREST).save(asset/"anim/glass_glint.png")
for i,(x,y) in enumerate(((384,203),(478,203),(668,138),(746,144))):
    animations.append({"id":f"glass_glint_{i}","type":"pulse","texture":"anim/glass_glint.png","rect":[x-2,y-2,5,5],"min_opacity":0,"max_opacity":.32,"period":1.8+i*.31,"phase":i*.27,"blend":"add","still":"hide"})
# Common7floor movers, exact original rows/speeds/phases, shop-specific mint/cream/plum reflections.
colors=((130,196,180),(191,180,146),(127,165,201),(174,119,175),(139,203,188),(190,175,142),(127,169,199))
for i,color in enumerate(colors):
    w=72-i*4;im=Image.new("RGBA",(w,2),(0,0,0,0));p=im.load()
    for x in range(w):
        edge=min(1,x/9,(w-1-x)/9)
        if edge<=0:continue
        a=round(110*edge)
        if (x+i*3)%19 in (0,1):a=round(a*.4)
        p[x,0]=(*color,a)
        if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
    im.resize((w*2,4),Image.Resampling.NEAREST).save(asset/f"anim/floor_glint_{i}.png")
    speed=18+i*2.5;y=274+(i%4)*14
    animations.append({"id":f"floor_glint_{i}","type":"mover","texture":f"anim/floor_glint_{i}.png","size":[w,2],"from":[-90,y],"to":[950,y],"duration":1040/speed,"phase":i*137/speed,"opacity":.18,"blend":"add","still":"hide"})
b.save(root/"background-board-review.png");b.resize((1800,860),Image.Resampling.NEAREST).save(asset/"background.png")
manifest={"schema":"bth.environment_art/v1","environment_id":"corner_store","board_size":[900,430],"pixel_scale":2,"background":{"texture":"background.png"},"animations":animations,"counters":{"corner_store_register":{"texture":"counters/corner_store_register.png","bleed":[0,0,0,0]}}}
(root/"data/art/environments/corner_store.json").write_text(json.dumps(manifest,indent=2)+"\n")
(root/"data/art/environments/index.json").write_text(json.dumps({"enabled":["gas_station_casino","corner_store"]},indent=2)+"\n")
changes=["Frozen sources/guide preserved; nearest-only exact900grid assembly then2x final.","Exact shelf/recess/counter/cooler contacts, floor245 and columns238 assembled modularly; no live props/labels/placement moved.","Full286wide572x96 opaque register front; pale Phone-left x338..412 and dark Clerk-center/right x412..624 cabinet faces, with matching recess crosspiece split, preserve pink/cyan/gold label contrast across scenarios.","Four modest unbranded cartons grounded at existing x positions, y220..252, restrained contact shadows. Exact shelf lips108/136/164/192 restored; only affected header/rail faces and lowtableapron darkened for fixed live label contrast. No baked clerk/phone/stock/drinks.","Scanner strip bounded to3720px width with10 phases at original1.047s abs-sine cadence, including exact travel endpoints. All25 motion entries:2 sign pulses,10 independent original-phase tube flickers, fullsize scan,22px abs-sine register glint above front,4 localized sparkles and7 original floor movers.","Register core y203..205 and two formerly buried glints adapted to visible trim; no holes in solidfront or renderer exception.","Gas activation preserved in expanded index; no Gas raster/manifest bytes copied or changed. Trial isolatedQA only, exact runtime/director/technical audit required."]
files={}
for path in sorted(list((root/"assets").rglob("*.png"))+list((root/"data").rglob("*.json"))):
    key=path.relative_to(root).as_posix();data=path.read_bytes();e={"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)}
    if path.suffix==".png":
        im=Image.open(path);e.update(size=list(im.size),mode=im.mode)
        if im.mode=="RGBA":e["alpha_extrema"]=im.getchannel("A").getextrema()
    files[key]=e
sha=hashlib.sha256("\n".join(k+" "+v["sha256"] for k,v in sorted(files.items())).encode()).hexdigest()
seal={"package_id":"corner_store-v1-r6","status":"SEALED_TRIAL_NOT_PASSED","package_sha256":sha,"files":files,"sources":sources,"changes":changes}
(root/"package-seal.json").write_text(json.dumps(seal,indent=2));(root/"edit-record.json").write_text(json.dumps(seal,indent=2))
print(json.dumps({"root":str(root),"package_sha256":sha,"background_sha256":files["assets/art/environments/corner_store/background.png"]["sha256"],"animations":len(animations),"status":"SEALED_TRIAL_NOT_PASSED"}))
