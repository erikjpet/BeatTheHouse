import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
REPO=Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers');sys.path.insert(0,str(REPO/'tools'))
from bth_qa_storage import Layout,validate_layout
from check_environment_art_pack import validate_manifest,counter_rectangles
e=Path(os.environ['BTH_QA_EVIDENCE_DIR']);m=json.loads((e/'storage-manifest.json').read_bytes());l=Layout(**{k:Path(v) for k,v in m['paths'].items()},run_id=m['run_id'],token=m['token'],prepared=True,expected_write_bytes=m['expected_write_bytes'],reserve_bytes=m['reserve_bytes']);w=l.workspace;artist=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-ARTIST-20261114/punchline_club-v1');rawpath=artist/'source/background-guide-v1.png'
def H(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert H(rawpath)=='adfe386e52b21f2a911056504eb23c2df4004d3137eca16f27b719f109ed85fc';raw=Image.open(rawpath).convert('RGB');s=raw.resize((900,430),Image.Resampling.NEAREST);b=s.copy();q=s.copy()
root=w/'packages/punchline_club-v1-r2';validate_layout(l,extra_write_paths=(root,));assert not root.exists();asset=root/'assets/art/environments/punchline_club';(asset/'anim').mkdir(parents=True);(root/'data/art/environments').mkdir(parents=True)
def fit(im,box,size):return im.crop(box).resize(size,Image.Resampling.NEAREST)
def paste_nine(im,sx,sy,tx,ty):
 for yi in range(len(sy)-1):
  for xi in range(len(sx)-1):b.paste(fit(im,(sx[xi],sy[yi],sx[xi+1],sy[yi+1]),(tx[xi+1]-tx[xi],ty[yi+1]-ty[yi])),(tx[xi],ty[yi]))
# Heal only old fixture footprints before moving their source modules. All
# donors stay on the source's SAME masonry course and approximate43px phase.
# New modules cover nearly all of these repairs; no foreign material donor.
old_boxes=[(240,51,659,255),(76,165,140,222),(171,194,230,252),(674,165,738,222),(761,194,822,252),(807,81,887,255),(307,8,520,44)]
def blocked(x,y):return any(x0<=x<x1 and y0<=y<y1 for x0,y0,x1,y1 in old_boxes)
healed=0
for x0,y0,x1,y1 in old_boxes:
 for y in range(y0,y1):
  valid=[x for x in range(900) if not blocked(x,y)]
  assert valid,y
  for x in range(x0,x1):
   candidates=[xx for xx in (x+43*k for k in range(-21,22)) if 0<=xx<900 and not blocked(xx,y)]
   if not candidates:candidates=valid
   xx=min(candidates,key=lambda z:abs(z-x));b.putpixel((x,y),s.getpixel((xx,y)));healed+=1
wall_healed=b.copy()
# Exact original-scale185-row material crop. Existing narrow wall-foot
# transition supplies its first rows; clear foreground grain is not stretched.
floor=raw.crop((7,497,1807,867)).resize((900,185),Image.Resampling.NEAREST);fp=floor.load();floor_repaired=0
for yy in range(9):
 for xx in range(900):
  sx=min(899,int((7+xx*2)*900/raw.width));sy=min(429,int((497+yy*2)*430/raw.height))
  if blocked(sx,sy):fp[xx,yy]=wall_healed.getpixel((sx,sy));floor_repaired+=1
b.paste(floor,(0,245))
# Remove source mic/apron before exact fitting, preventing doubled shifted
# metal/ridges. Cloth repairs use same-column source folds, never UI patches.
for y in range(104,200):
 for x in range(439 if y<125 else 447,460 if y<125 else 453):q.putpixel((x,y),s.getpixel((x+22,y)))
q.paste(s.crop((264,163,636,197)),(264,197))
paste_nine(q,(241,264,631,658),(52,77,232,254),(248,264,636,652),(62,80,230,254))
# Quiet real side wings, preserving original dark red timber grain.
wing=fit(s,(264,233,295,253),(38,50));wp=wing.load()
for y in range(50):
 for x in range(38):
  r,g,bb=wp[x,y];wp[x,y]=(round(r*.55+3),round(g*.42+2),round(bb*.6+3))
b.paste(wing,(264,202));b.paste(wing.transpose(Image.Transpose.FLIP_LEFT_RIGHT),(598,202))
front=fit(s,(296,198,596,253),(296,50));p=front.load()
for y in range(50):
 for x in range(296):
  r,g,bb=p[x,y]
  if y==0:p[x,y]=(min(223,r),min(157,g),min(65,bb))
  elif y<8:p[x,y]=(round(r*.25+6),round(g*.20+3),round(bb*.45+4))
  else:p[x,y]=(round(r*.57+4),round(g*.36+3),round(bb*.65+3))
b.paste(front,(302,202))
# Four compact original round bodies, exact56x56 footprints. No legs/chairs.
circle_boxes=[(76,165,139,221),(171,194,229,252),(674,165,737,221),(761,194,821,252)];centers=[(108,194),(202,222),(704,194),(790,222)]
for i,(box,(cx,cy)) in enumerate(zip(circle_boxes,centers)):
 table=fit(s,box,(56,56));tp=table.load()
 # Clear the old compact emitter ONLY inside its housing column before the
 # same physical lamp is re-fitted below. Keep rim and timber source detail.
 for yy in range(8,35):
  for xx in range(20,36):
   r,g,bb=tp[xx,yy]
   if r>125 and g>70 and g>bb*1.05:tp[xx,yy]=table.getpixel((min(46,xx+13),yy))
 alpha=Image.new('L',(56,56));ImageDraw.Draw(alpha).ellipse((0,0,55,55),fill=255);b.paste(table,(cx-28,cy-28),alpha)
# Fixed central lamps. The second lower housing is dark bronze because the
# measured OpenMic cyan title spans210..236; upper honey core stays207..209.
lamp=fit(s,(102,176,112,197),(6,18));lp=lamp.load()
for yy in range(18):
 for xx in range(6):
  r,g,bb=lp[xx,yy]
  if r>145 and g>85:lp[xx,yy]=(min(245,r),round(g*.68+12),round(bb*.24+15))
for i,(cx,cy) in enumerate(centers):
 im=lamp.copy();ip=im.load()
 if i==1:
  for yy in range(3,18):
   for xx in range(6):
    r,g,bb=ip[xx,yy];ip[xx,yy]=(round(r*.24+5),round(g*.18+4),round(bb*.30+3))
 b.paste(im,(cx-3,cy-15))
# Architectural door fits original footprint; handle is replayed at its exact
# source-guide center after quieting the old source knob within the panel.
door=s.crop((808,82,882,254));dp=door.load()
for yy in range(68,81):
 for xx in range(39,52):dp[xx,yy]=door.getpixel((xx-13,yy))
door=door.resize((64,164),Image.Resampling.NEAREST);b.paste(door,(814,78));knob=fit(s,(850,152,858,160),(6,6));b.paste(knob,(851,153))
# Exact fixed mic: source grille detail on a dark steel face and narrow stem.
stem=fit(s,(448,121,452,198),(3,72));hp=stem.load()
for yy in range(72):
 for xx in range(3):
  r,g,bb=hp[xx,yy];hp[xx,yy]=(round(r*.72),round(g*.69),round(bb*.74))
b.paste(stem,(449,120));head=fit(s,(441,105,459,123),(16,16));hp=head.load()
for yy in range(16):
 for xx in range(16):
  r,g,bb=hp[xx,yy];hp[xx,yy]=(round(r*.65),round(g*.64),round(bb*.70))
b.paste(head,(442,108))
# Actual source glyphs, matched to the measured guide wordmark bounds31925..50642.
text=s.crop((314,17,512,40));gold=Image.new('L',text.size);gp=gold.load()
for yy in range(text.height):
 for xx in range(text.width):
  r,g,bb=text.getpixel((xx,yy));gp[xx,yy]=255 if r>100 and g>65 and r>bb*1.4 and g>bb*1.15 else 0
edge=gold.filter(ImageFilter.MaxFilter(3));glyph=text.convert('RGBA');glyph.putalpha(edge);glyph=glyph.resize((187,17),Image.Resampling.NEAREST);b.paste(glyph,(319,25),glyph)
b.save(root/'background-board-review.png');b.resize((1800,860),Image.Resampling.NEAREST).save(asset/'background.png')
animations=[]
def save2(im,name):im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST).save(asset/'anim'/name)
glow=Image.new('RGBA',(187,17));p=glow.load()
for yy in range(17):
 for xx in range(187):
  r,g,bb=b.getpixel((319+xx,25+yy))
  if r>145 and g>85 and r>bb*1.4:p[xx,yy]=(r,g,bb,175)
save2(glow,'wordmark_pulse.png');animations.append({'id':'authored_wordmark_pulse','type':'pulse','texture':'anim/wordmark_pulse.png','rect':[319,25,187,17],'min_opacity':.08,'max_opacity':.22,'period':4.4,'phase':.6,'blend':'add','still':'first'})
core_counts=[]
for i,(cx,cy) in enumerate(centers[:3]):
 im=Image.new('RGBA',(6,18));p=im.load();n=0
 for yy in range(18):
  for xx in range(6):
   r,g,bb=b.getpixel((cx-3+xx,cy-15+yy))
   if r>120 and g>65 and g>bb*1.3 and (i!=1 or yy<3):p[xx,yy]=(r,g,bb,170);n+=1
 assert n>0,(i,n);core_counts.append(n);name=f'practical_core_{i}.png';save2(im,name);animations.append({'id':f'authored_practical_core_{i}','type':'pulse','texture':'anim/'+name,'rect':[cx-3,cy-15,6,18],'min_opacity':.10,'max_opacity':.27,'period':2.8+i*.55,'phase':i*.77,'blend':'add','still':'first'})
# Director explicitly approved THREE core pulses plus steady fourth: no invented reflection.
rim_count=0
for i,color in enumerate(((182,120,62),(70,125,167),(169,65,129),(193,131,67),(67,132,173),(160,67,135),(187,123,66))):
 width=72-4*i;im=Image.new('RGBA',(width,2));p=im.load()
 for x in range(width):
  a=round(110*max(0,min(1,x/9,(width-1-x)/9)));a=round(a*.4) if (x+3*i)%19 in (0,1) else a;p[x,0]=(*color,a)
  if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
 save2(im,f'floor_glint_{i}.png');speed=18+2.5*i;y=274+(i%4)*14;animations.append({'id':f'floor_glint_{i}','type':'mover','texture':f'anim/floor_glint_{i}.png','size':[width,2],'from':[-90,y],'to':[950,y],'duration':1040/speed,'phase':137*i/speed,'opacity':.16,'blend':'add','still':'hide'})
assert len(animations)==11 and not counter_rectangles(REPO,'punchline_club');manifest={'schema':'bth.environment_art/v1','environment_id':'punchline_club','board_size':[900,430],'pixel_scale':2,'background':{'texture':'background.png'},'animations':animations,'counters':{}};(root/'data/art/environments/punchline_club.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'data/art/environments/index.json').write_text(json.dumps({'enabled':['gas_station_casino','corner_store','back_alley','motel','bar','pawn_shop','jazz_club','punchline_club']},indent=2)+'\n');validate_manifest(manifest,'punchline_club',asset,{})
files={}
for path in sorted(list((root/'assets').rglob('*.png'))+list((root/'data').rglob('*.json'))):
 v={'sha256':H(path),'bytes':path.stat().st_size}
 if path.suffix=='.png':
  im=Image.open(path);v.update(size=list(im.size),mode=im.mode)
  if im.mode=='RGBA':v['alpha_extrema']=list(im.getchannel('A').getextrema())
 files[path.relative_to(root).as_posix()]=v
package_sha=hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(files.items())).encode()).hexdigest();record={'package_id':'punchline_club-v1-r2','status':'SEALED_STATIC_TRIAL_NOT_PASSED','package_sha256':package_sha,'files':files,'sources':{str(rawpath):H(rawpath)},'frozen_generation_inputs':json.loads((artist/'inputs/input-provenance-generation-v1.json').read_bytes()),'notes':['Public comedy identity only. Own crisp plum masonry,burgundy timber/cloth,amber cores and restrained cyan/pink trim. No hidden/private material,motion or cast.','Fixed backdrop24862/404192;curtain26480/372150;central apron302202/29650 with dark side wings264..302/598..636;four56px round bodies at108194/202222/704194/790222;door81478/64164;mic head450116r8/stem450120..192;wordmark measured31925/18717.','All old fixture positions are repaired before exact source modules replay. Same-source same-course masonry donors;no foreign donor.','Original-scale floor crop native[7,497,1800,370] gives exact185board depth from245. Existing thin wall-foot transition retained;only old-source fixture residues in first9board rows repaired from same-course quiet planes. No vertical stretch or repeated floor grain.','Real apron timber203..252 is quiet/detailed,only contactrow202 retains thin warm edge. Full curtain remains dark rich burgundy,not pale spotlight. Dark steel source mic is architecture,not live comic.','Fixed6x18 practical housings. Second lowerface210..225 dark bronze under measured OpenMic cyan title;compact honey upper207..209 remains. Fourth central core stays fixed/static under Ox.','Eleven moving entries: seven retained/consolidated floor helpers plus four newly authored additions (wordmark and three independent cores). Fourth central practical remains static. These are not eleven retained legacy motifs.','R1 was deliberately stopped before sealing: the approved fourth-rim subset yielded zero natural warm source pixels. Director approved the explicit eleven-entry fallback instead of inventing, recoloring or boosting a reflection. R1 board and extraction diagnostic remain immutable; R2 background pixels are identical.','No mapped foreground fronts in public view; no counter/replay PNG,alpha hole or renderer exception.','Actual Base/current6 composition,motion/minpeak/RM/hit/source-context/readability and original mandatory liveness acceptance remain pending.'],'construction_metrics':{'healed_source_footprint_pixels':healed,'old_floor_fixture_pixels_repaired':floor_repaired,'core_source_pixels':core_counts,'fourth_rim_source_pixels':rim_count},'recipe':str(Path(__file__)),'recipe_sha256':H(__file__)};(root/'package-seal.json').write_text(json.dumps(record,indent=2));(root/'edit-record.json').write_text(json.dumps(record,indent=2));print(json.dumps({'package':str(root),'package_sha256':package_sha,'background_sha256':files['assets/art/environments/punchline_club/background.png']['sha256'],'files':len(files),'entries':11,'rim_source_pixels':rim_count,'cores':core_counts,'validator':'PASS'}))
