import sys,tarfile,json,hashlib,shutil
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
sys.path.insert(0,'D:/Projects/Beat-The-House/.tmp/environment-art-layers/tools')
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
w=Path('E:/CodexQA/BTH/workspaces/BTH-ENVART-TEST-WEB-20261114')
l=prepare_layout(plan_layout(root='E:/CodexQA/BTH',workspace=str(w),run_id='BTH-ENVART-INTEGRATION-20261114-public-web-extract-body-01'))
validate_layout(l,extra_write_paths=(w,))
a=w/'.tmp/web-release-74c85e44/source.tar'; count=0
with tarfile.open(a,'r') as tar:
 for m in tar.getmembers():
  rel=PurePosixPath(m.name); assert not rel.is_absolute() and '..' not in rel.parts and (m.isfile() or m.isdir()) and not m.issym() and not m.islnk()
  target=w/m.name; assert target.resolve().is_relative_to(w.resolve())
  if m.isdir():target.mkdir(parents=True,exist_ok=True)
  else:
   target.parent.mkdir(parents=True,exist_ok=True)
   with tar.extractfile(m) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst)
   count+=1
p=json.loads((w/'docs/art/punchline_club_v1_r2_provenance.json').read_text(encoding='utf-8-sig'))
for rel,meta in p['payload_files'].items():assert hashlib.sha256((w/rel).read_bytes()).hexdigest()==meta['sha256'],rel
for rel,h in p['prior_seven_room_source_files_unchanged'].items():assert hashlib.sha256((w/rel).read_bytes()).hexdigest()==h,rel
for rel,h in p['protected_unchanged'].items():assert hashlib.sha256((w/rel).read_bytes()).hexdigest()==h,rel
record={'source_commit':'74c85e44577b34eaf7e9c1f857e62b2c999c1fbc','source_tree':'bbc17de60e039d7807d9dbef838f4f22efb706f3','archive_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'files':count,'public_exact_files':14,'gas_unchanged':True,'protected_unchanged':True}
(l.evidence/'source.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
