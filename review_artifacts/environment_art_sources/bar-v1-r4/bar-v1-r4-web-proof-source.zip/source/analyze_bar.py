"""Read-only raw browser-frame analysis; no per-entry attribution from composites."""
import sys, os, json, math, hashlib
sys.dont_write_bytecode = True
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

WORK = Path(__file__).parent
out = Path(os.environ['BTH_QA_EVIDENCE_DIR'])
manifest = WORK/'inputs/bar-v1-r4/data/art/environments/bar.json'
package = json.loads(manifest.read_text())
union_path = WORK/'inputs/bar_preart_union.json'
union = json.loads(union_path.read_text())
assert package['environment_id'] == 'bar' and len(package['animations']) == 17
reports = []
for spec in sys.argv[1:]:
    raw, scenario = spec.split('|')
    evidence = Path(raw)
    assert evidence.resolve().is_relative_to(Path('E:/CodexQA/BTH/runs'))
    motion = json.loads((evidence/'motion.json').read_text())
    assert motion['input_during_capture'] is False
    first = Image.open(evidence/'frames'/motion['frames'][0]['file']).convert('RGB')
    width, height = first.size
    cyan = [y for y in range(round(height*.10), round(height*.34))
            if (lambda c: c[0]<40 and c[1]>120 and c[2]>120)(first.getpixel((0,y)))]
    if not cyan: raise ValueError('Board separator not observed in raw screenshot')
    oy = max(cyan)+1
    scale = min(width/900, (height-oy)/430)
    ox = (width-900*scale)/2
    def box(r):
        x,y,w,h = r
        return [max(0,math.floor(ox+x*scale)), max(0,math.floor(oy+y*scale)),
                min(width,math.ceil(ox+(x+w)*scale)), min(height,math.ceil(oy+(y+h)*scale))]
    mask_dir = out/('masks-'+evidence.parent.name)
    mask_dir.mkdir(exist_ok=True)
    regions = {}
    for entry in package['animations']:
        rect = [0,entry['from'][1],900,entry['size'][1]] if entry['type']=='mover' else entry['rect']
        b = box(rect)
        mask = Image.new('L', (b[2]-b[0],b[3]-b[1]), 255)
        if entry['type'] not in ('mover','scroll'):
            texture = Image.open(manifest.parents[3]/'assets/art/environments/bar'/entry['texture']).convert('RGBA')
            fw = texture.width//entry.get('frames',1)
            alpha = Image.new('L',(fw,texture.height),0)
            for n in range(entry.get('frames',1)):
                frame = texture.crop((n*fw,0,(n+1)*fw,texture.height)).getchannel('A')
                alpha = Image.fromarray(np.maximum(np.asarray(alpha),np.asarray(frame)))
            mask = alpha.resize(mask.size,Image.Resampling.NEAREST).point(lambda a: 255 if a else 0)
        free = mask.copy()
        draw = ImageDraw.Draw(free)
        for row in union['contexts'][scenario]['rows']:
            for field in ('model_rect','label_rect'):
                if field not in row: continue
                bb = box(row[field])
                if bb[2]>b[0] and bb[0]<b[2] and bb[3]>b[1] and bb[1]<b[3]:
                    draw.rectangle((bb[0]-b[0]-2,bb[1]-b[1]-2,bb[2]-b[0]+2,bb[3]-b[1]+2),fill=0)
        mask.save(mask_dir/(entry['id']+'-source.png'))
        free.save(mask_dir/(entry['id']+'-free.png'))
        regions[entry['id']] = {'box':b,'mask':np.asarray(mask)>0,'free':np.asarray(free)>0,'type':entry['type']}
    bases = {n:np.array(first.crop(r['box']),dtype=np.int16) for n,r in regions.items()}
    maxima = {n:np.zeros(r['mask'].shape,dtype=np.int16) for n,r in regions.items()}
    rows = {n:[] for n in regions}
    for frame in motion['frames']:
        with Image.open(evidence/'frames'/frame['file']) as image:
            rgb = image.convert('RGB')
            for name,region in regions.items():
                pix = np.array(rgb.crop(region['box']),dtype=np.int16)
                delta = np.max(np.abs(pix-bases[name]),axis=2)
                delta = np.where(region['mask'],delta,0)
                maxima[name] = np.maximum(maxima[name],delta)
                rows[name].append({'frame':frame['index'],'file':frame['file'],'elapsed_ms':frame['elapsed_ms'],
                    'changed_pixels':int(np.count_nonzero(delta)),
                    'free_changed_pixels':int(np.count_nonzero(np.where(region['free'],delta,0))),
                    'free_mean_rgb':float(pix[region['free']].mean()) if region['free'].any() else None,
                    'source_mean_rgb':float(pix[region['mask']].mean()) if region['mask'].any() else None})
    stats = {}
    for name,region in regions.items():
        free_delta = np.where(region['free'],maxima[name],0)
        field = 'free_mean_rgb' if region['free'].any() else 'source_mean_rgb'
        stats[name] = {'box':region['box'],'source_mask_pixels':int(region['mask'].sum()),
            'free_mask_pixels':int(region['free'].sum()),
            'temporal_changed_pixels':int(np.count_nonzero(maxima[name])),
            'free_temporal_changed_pixels':int(np.count_nonzero(free_delta)),
            'peak_channel_delta':int(maxima[name].max()),'free_peak_channel_delta':int(free_delta.max()),
            'changed_frames':sum(row['changed_pixels']>0 for row in rows[name]),
            'lowest_sample':min(rows[name],key=lambda r:r[field] or 0),
            'highest_sample':max(rows[name],key=lambda r:r[field] or 0),'samples':rows[name]}
    reports.append({'label':motion['label'],'scenario':scenario,'source_evidence':str(evidence),
        'frames':len(motion['frames']),'duration_ms':motion['duration_ms'],
        'board_geometry':{'origin':[ox,oy],'scale':scale},'mask_directory':str(mask_dir),'regions':stats,
        'limits':['Raw actual screenshot composite observations, no model, clock, scenario or alpha injection.',
          'The full atlas mask can include moving actors and overlapping art. Conservative free masks exclude initial model and name envelopes with two CSS pixels of margin, not all future motion.',
          'Scroll masks cover the translated source envelope rather than a single fixed alpha frame. Two smoke fields overlap; no per-field isolation claim.',
          'Seven floor tracks share four lanes. Retrospective known-speed fitting is corroboration only.',
          'Payday warm_glint_0 is naturally hidden by a live actor. ROI change is not background-glint visibility.',
          'Observed screenshot extrema are samples, not exact mathematical peaks or minima.']})
report = {'schema':'bth.bar-browser-composite/v1','manifest':str(manifest),
          'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
          'union_sha256':hashlib.sha256(union_path.read_bytes()).hexdigest(),'reports':reports}
(out/'bar-composite-motion.json').write_text(json.dumps(report,indent=2))
print(json.dumps([{'label':r['label'],'frames':r['frames'],'duration_ms':r['duration_ms'],
  'regions':{n:{k:v[k] for k in ('source_mask_pixels','free_mask_pixels','temporal_changed_pixels','free_temporal_changed_pixels','peak_channel_delta')} for n,v in r['regions'].items()}} for r in reports]))
