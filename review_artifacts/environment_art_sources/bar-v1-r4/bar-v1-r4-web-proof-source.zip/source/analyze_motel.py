import sys,os,json,math,hashlib
sys.dont_write_bytecode=True
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
out=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
manifest=Path(sys.argv[1]);pack=json.loads(manifest.read_text());assert pack['environment_id']=='motel'
union=json.loads((Path(__file__).parent/'inputs/motel_preart_union.json').read_text())
reports=[]
for spec in sys.argv[2:]:
 raw,scenario=spec.split('|');e=Path(raw);motion=json.loads((e/'motion.json').read_text());assert not motion['input_during_capture']
 first=Image.open(e/'frames'/motion['frames'][0]['file']).convert('RGB');width,height=first.size
 cyan=[y for y in range(round(height*.10),round(height*.34)) if (lambda c:c[0]<40 and c[1]>120 and c[2]>120)(first.getpixel((0,y)))]
 oy=max(cyan)+1;scale=min(width/900,(height-oy)/430);ox=(width-900*scale)/2
 def box(r):
  x,y,ww,hh=r;return [max(0,math.floor(ox+x*scale)),max(0,math.floor(oy+y*scale)),min(width,math.ceil(ox+(x+ww)*scale)),min(height,math.ceil(oy+(y+hh)*scale))]
 regions={}
 for en in pack['animations']:
  rect=[0,en['from'][1],900,en['size'][1]] if en['type']=='mover' else en['rect'];b=box(rect)
  mask=Image.new('L',(b[2]-b[0],b[3]-b[1]),255)
  if en['type']!='mover':
   texture=Image.open(manifest.parents[3]/'assets'/'art'/'environments'/'motel'/en['texture']).convert('RGBA');fw=texture.width//en.get('frames',1)
   alpha=Image.new('L',(fw,texture.height),0)
   for n in range(en.get('frames',1)):
    a=texture.crop((n*fw,0,(n+1)*fw,texture.height)).getchannel('A');alpha=Image.fromarray(np.maximum(np.asarray(alpha),np.asarray(a)))
   mask=alpha.resize(mask.size,Image.Resampling.NEAREST).point(lambda a:255 if a else 0)
  if en['id'].startswith('crt_'):
   free=Image.new('L',mask.size,0);d=ImageDraw.Draw(free)
   for r in union['contexts'][scenario]['crt_glass_outside_drink_source_shapes_and_cup_label_and_vending']:
    bb=box(r);d.rectangle((bb[0]-b[0]+1,bb[1]-b[1]+1,bb[2]-b[0]-2,bb[3]-b[1]-2),fill=255) if bb[2]-bb[0]>3 and bb[3]-bb[1]>3 else None
   mask=Image.fromarray(np.minimum(np.asarray(mask),np.asarray(free)))
  regions[en['id']]={'box':b,'mask':np.asarray(mask)>0,'type':en['type']}
 bases={n:np.array(first.crop(r['box']),dtype=np.int16) for n,r in regions.items()}
 maxima={n:np.zeros(r['mask'].shape,dtype=np.int16) for n,r in regions.items()};rows={n:[] for n in regions}
 for f in motion['frames']:
  with Image.open(e/'frames'/f['file']) as im:
   for n,r in regions.items():
    pix=np.array(im.convert('RGB').crop(r['box']),dtype=np.int16);d=np.max(np.abs(pix-bases[n]),axis=2);d=np.where(r['mask'],d,0);maxima[n]=np.maximum(maxima[n],d)
    rows[n].append({'frame':f['index'],'file':f['file'],'elapsed_ms':f['elapsed_ms'],'changed_pixels':int(np.count_nonzero(d)),'mean_rgb_visible':float(pix[r['mask']].mean()) if r['mask'].any() else None})
 stats={}
 for n,r in regions.items():
  lo=min(rows[n],key=lambda x:x['mean_rgb_visible'] if x['mean_rgb_visible'] is not None else 0);hi=max(rows[n],key=lambda x:x['mean_rgb_visible'] if x['mean_rgb_visible'] is not None else 0)
  stats[n]={'box':r['box'],'source_mask_pixels':int(r['mask'].sum()),'temporal_changed_pixels':int(np.count_nonzero(maxima[n])),'peak_channel_delta':int(maxima[n].max()),'changed_frames':sum(x['changed_pixels']>0 for x in rows[n]),'lowest_sample':lo,'highest_sample':hi,'samples':rows[n]}
 reports.append({'label':motion['label'],'scenario':scenario,'source_evidence':str(e),'frames':len(motion['frames']),'duration_ms':motion['duration_ms'],'board_geometry':{'origin':[ox,oy],'scale':scale},'regions':stats,'limits':['Actual screenshot composite observations only, no injected model/clock/alpha or image boosts.','CRT motifs overlap; source-shaped free-glass/atlas masks show meaningful unoccluded composite change, not isolated attribution. Native exact-package single-entry proof remains separate.','Seven floor tracks share four lanes. Region changes cannot independently prove each track.','Wedding glass_glint_1 can be correctly hidden by the live Clerk.','Extrema are observed screenshot samples, not exact mathematical minima or maxima.']})
(out/'motel-composite-motion.json').write_text(json.dumps({'manifest':str(manifest),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'reports':reports},indent=2))
print(json.dumps([{'label':r['label'],'frames':r['frames'],'duration_ms':r['duration_ms'],'regions':{n:{k:v[k] for k in ('source_mask_pixels','temporal_changed_pixels','peak_channel_delta')} for n,v in r['regions'].items()}} for r in reports]))
