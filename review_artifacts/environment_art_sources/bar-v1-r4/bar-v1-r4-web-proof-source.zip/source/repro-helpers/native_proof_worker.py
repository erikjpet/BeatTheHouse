"""Pinned Windows Python worker: assign its creation handle before first instruction.

No PID lookup, shell, console allocation, or inheritable job handle. Caller owns job.
Construction returns SUSPENDED; caller must explicitly resume after checking it.
"""
import ctypes, msvcrt, os, subprocess, _winapi
from ctypes import wintypes as w

class SuspendedWorker:
 def __init__(self, job, args, *, cwd=None, env=None):
  self.job=job;self._handle=None;self._thread=None;self.pid=None
  self.stdin=None;self.stdout=None;self.returncode=None;self.resumed=False
  fds=[]
  try:
   read_in,write_in=os.pipe();fds.extend((read_in,write_in))
   read_out,write_out=os.pipe();fds.extend((read_out,write_out))
   os.set_inheritable(read_in,True);os.set_inheritable(write_out,True)
   si=subprocess.STARTUPINFO();si.dwFlags=_winapi.STARTF_USESTDHANDLES
   si.hStdInput=msvcrt.get_osfhandle(read_in)
   si.hStdOutput=si.hStdError=msvcrt.get_osfhandle(write_out)
   si.lpAttributeList={'handle_list':[si.hStdInput,si.hStdOutput]}
   # CREATE_SUSPENDED is essential: stdin is only a protocol, not containment.
   hp,ht,pid,_=_winapi.CreateProcess(os.fspath(args[0]),subprocess.list2cmdline(args),None,None,True,
      0x4|subprocess.CREATE_NO_WINDOW,env,os.fspath(cwd) if cwd else None,si)
   self._handle=hp;self._thread=ht;self.pid=pid
   os.close(read_in);fds.remove(read_in);os.close(write_out);fds.remove(write_out)
   job.assign(self)
   if not job.contains(self._handle):raise RuntimeError('Creation handle not in private job')
   self.stdin=os.fdopen(write_in,'w',encoding='utf-8',errors='strict');fds.remove(write_in)
   self.stdout=os.fdopen(read_out,'r',encoding='utf-8',errors='replace');fds.remove(read_out)
  except BaseException:
   if self._handle is not None:
    self.kill();self.wait(timeout=3)
   self.close()
   raise
  finally:
   for fd in fds:os.close(fd)
 def resume(self):
  if self.resumed or self._thread is None:raise RuntimeError('Worker already resumed or closed')
  if not self.job.contains(self._handle):raise RuntimeError('Refusing resume without private membership')
  api=self.job.api;api.ResumeThread.argtypes=[w.HANDLE];api.ResumeThread.restype=w.DWORD
  previous=api.ResumeThread(self._thread)
  if previous!=1:raise RuntimeError('Unexpected suspend count: '+str(previous))
  self.resumed=True;_winapi.CloseHandle(self._thread);self._thread=None
 def poll(self):
  if self.returncode is None and _winapi.WaitForSingleObject(self._handle,0)==_winapi.WAIT_OBJECT_0:
   self.returncode=_winapi.GetExitCodeProcess(self._handle)
  return self.returncode
 def wait(self,timeout=None):
  result=_winapi.WaitForSingleObject(self._handle,_winapi.INFINITE if timeout is None else max(0,int(timeout*1000)))
  if result==_winapi.WAIT_TIMEOUT:raise subprocess.TimeoutExpired('owned worker',timeout)
  if result!=_winapi.WAIT_OBJECT_0:raise RuntimeError('Owned process wait failed: '+str(result))
  self.returncode=_winapi.GetExitCodeProcess(self._handle);return self.returncode
 def kill(self):
  if self.poll() is None:_winapi.TerminateProcess(self._handle,1)
 def close(self):
  # Call only after explicit termination/wait. Never detach an unresolved worker.
  if self._handle is not None and self.poll() is None:raise RuntimeError('Refusing to discard live process handle')
  for stream in (self.stdin,self.stdout):
   if stream is not None and not stream.closed:stream.close()
  for name in ('_thread','_handle'):
   handle=getattr(self,name)
   if handle is not None:_winapi.CloseHandle(handle);setattr(self,name,None)
