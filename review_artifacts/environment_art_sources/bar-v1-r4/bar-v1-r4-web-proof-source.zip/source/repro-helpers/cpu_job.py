"""Task-private CPU capped job. Import does not launch or attach any process."""
import ctypes, importlib.util, os
from ctypes import wintypes as w
from pathlib import Path

_p = Path(__file__).with_name('native_proof_job.py')
_spec = importlib.util.spec_from_file_location('bth_private_job_base', _p)
_base = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_base)

class CpuRate(ctypes.Structure):
    _fields_ = [('flags', w.DWORD), ('rate', w.DWORD)]

class CpuCappedJob(_base.OwnedJob):
    def __init__(self, cpu_rate=1200, memory_bytes=2*1024**3):
        if not 1 <= cpu_rate <= 1500:
            raise ValueError('Private aggregate job cap must be >0 and <=15% host CPU')
        super().__init__()
        try:
            limits = self.query(9, _base.Limits())
            limits.basic.flags = 0x2000 | 0x200 # kill-on-close + aggregate job memory
            limits.jobMemory = memory_bytes
            if not self.api.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
                raise ctypes.WinError(ctypes.get_last_error())
            limit = CpuRate(0x1 | 0x4, cpu_rate) # ENABLE | HARD_CAP; no weight/minimum
            if not self.api.SetInformationJobObject(self.handle, 15, ctypes.byref(limit), ctypes.sizeof(limit)):
                raise ctypes.WinError(ctypes.get_last_error())
            self.verify(cpu_rate, memory_bytes)
        except BaseException:
            self.close()
            raise

    def verify(self, expected_rate=1200, expected_memory=2*1024**3):
        rate = self.query(15, CpuRate())
        limits = self.query(9, _base.Limits())
        if rate.flags != 0x5 or rate.rate != expected_rate:
            raise RuntimeError('CPU hard-cap readback mismatch')
        if limits.basic.flags != (0x2000 | 0x200) or limits.jobMemory != expected_memory:
            raise RuntimeError('Private memory/kill-on-close/breakaway limits mismatch')
        return {'control_flags': rate.flags, 'cpu_rate': rate.rate,
                'aggregate_job_cpu_percent': rate.rate / 100,
                'kill_on_close': True, 'breakaway_allowed': False,
                'job_memory_limit_bytes': limits.jobMemory,
                'active_processes': self.active()}

    def cpu_seconds(self):
        a = self.query(1, _base.Accounting())
        return (a.userTime + a.kernelTime) / 10_000_000

    def owner_membership(self):
        self.api.GetCurrentProcess.restype = w.HANDLE
        handle = self.api.GetCurrentProcess()
        any_job = w.BOOL()
        if not self.api.IsProcessInJob(handle, None, ctypes.byref(any_job)):
            raise ctypes.WinError(ctypes.get_last_error())
        return {'supervisor_in_this_private_job': self.contains(handle),
                'supervisor_in_any_ancestor_job': bool(any_job.value)}
