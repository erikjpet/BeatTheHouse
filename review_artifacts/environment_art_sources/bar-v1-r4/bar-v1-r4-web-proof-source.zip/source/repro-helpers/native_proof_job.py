"""Private Windows kill-on-close job for one explicitly assigned worker tree."""
import ctypes,os,time
from ctypes import wintypes as w
class Basic(ctypes.Structure):
 _fields_=[('processTime',ctypes.c_longlong),('jobTime',ctypes.c_longlong),('flags',w.DWORD),('minWorkingSet',ctypes.c_size_t),('maxWorkingSet',ctypes.c_size_t),('activeProcesses',w.DWORD),('affinity',ctypes.c_size_t),('priority',w.DWORD),('scheduling',w.DWORD)]
class IO(ctypes.Structure):
 _fields_=[(name,ctypes.c_ulonglong) for name in ('readOps','writeOps','otherOps','readBytes','writeBytes','otherBytes')]
class Limits(ctypes.Structure):
 _fields_=[('basic',Basic),('io',IO),('processMemory',ctypes.c_size_t),('jobMemory',ctypes.c_size_t),('peakProcessMemory',ctypes.c_size_t),('peakJobMemory',ctypes.c_size_t)]
class Accounting(ctypes.Structure):
 _fields_=[('userTime',ctypes.c_longlong),('kernelTime',ctypes.c_longlong),('periodUserTime',ctypes.c_longlong),('periodKernelTime',ctypes.c_longlong),('pageFaults',w.DWORD),('totalProcesses',w.DWORD),('activeProcesses',w.DWORD),('terminatedProcesses',w.DWORD)]
class OwnedJob:
 def __init__(self):
  if os.name!='nt':raise RuntimeError('Windows owned-job runner only')
  self.api=ctypes.WinDLL('kernel32',use_last_error=True)
  self.api.CreateJobObjectW.argtypes=[ctypes.c_void_p,w.LPCWSTR];self.api.CreateJobObjectW.restype=w.HANDLE
  self.api.SetInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD];self.api.SetInformationJobObject.restype=w.BOOL
  self.api.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];self.api.AssignProcessToJobObject.restype=w.BOOL
  self.api.QueryInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD,ctypes.c_void_p];self.api.QueryInformationJobObject.restype=w.BOOL
  self.api.TerminateJobObject.argtypes=[w.HANDLE,w.UINT];self.api.TerminateJobObject.restype=w.BOOL
  self.api.CloseHandle.argtypes=[w.HANDLE];self.api.CloseHandle.restype=w.BOOL
  self.api.IsProcessInJob.argtypes=[w.HANDLE,w.HANDLE,ctypes.POINTER(w.BOOL)];self.api.IsProcessInJob.restype=w.BOOL
  self.handle=self.api.CreateJobObjectW(None,None)
  if not self.handle:raise ctypes.WinError(ctypes.get_last_error())
  limit=Limits();limit.basic.flags=0x2000 # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
  if not self.api.SetInformationJobObject(self.handle,9,ctypes.byref(limit),ctypes.sizeof(limit)):
   error=ctypes.WinError(ctypes.get_last_error());self.close();raise error
  try:
   actual=Limits();self.query(9,actual)
   if actual.basic.flags!=0x2000 or self.active()!=0:raise RuntimeError('Private job limits/initial accounting mismatch')
  except BaseException:self.close();raise
 def query(self,kind,value):
  if not self.handle:raise RuntimeError('Private job handle closed')
  if not self.api.QueryInformationJobObject(self.handle,kind,ctypes.byref(value),ctypes.sizeof(value),None):raise ctypes.WinError(ctypes.get_last_error())
  return value
 def active(self):return self.query(1,Accounting()).activeProcesses
 def contains(self,handle):
  if not self.handle:raise RuntimeError('Private job handle closed')
  result=w.BOOL()
  if not self.api.IsProcessInJob(w.HANDLE(int(handle)),self.handle,ctypes.byref(result)):raise ctypes.WinError(ctypes.get_last_error())
  return bool(result.value)
 def assign(self,process):
  if process.resumed:raise RuntimeError('Refusing assignment after execution')
  if not self.api.AssignProcessToJobObject(self.handle,w.HANDLE(int(process._handle))):raise ctypes.WinError(ctypes.get_last_error())
 def drain(self,timeout=5):
  if self.active():self.terminate()
  deadline=time.monotonic()+timeout
  while self.active():
   if time.monotonic()>=deadline:raise RuntimeError('Private job still has active processes')
   time.sleep(.02)
 def pids(self):
  capacity=256;size=8+ctypes.sizeof(ctypes.c_size_t)*capacity;data=ctypes.create_string_buffer(size)
  if not self.api.QueryInformationJobObject(self.handle,3,data,size,None):raise ctypes.WinError(ctypes.get_last_error())
  count=w.DWORD.from_buffer(data,4).value
  if count>capacity:raise RuntimeError('Owned process inventory exceeds bounded capacity')
  return list((ctypes.c_size_t*count).from_buffer(data,8))
 def terminate(self):
  if not self.api.TerminateJobObject(self.handle,1):raise ctypes.WinError(ctypes.get_last_error())
 def close(self):
  if self.handle:self.api.CloseHandle(self.handle);self.handle=None
