import json,hashlib,re
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def admitted_target(work):
    approval=work/'approved-target.json'
    if not approval.is_file():
        raise RuntimeError('PREPARATION ONLY: exact full native auditor PASS source and finalized-stage GO have not been supplied')
    a=json.loads(approval.read_text())
    if a.get('parent_go') is not True or a.get('full_auditor_pass') is not True:
        raise RuntimeError('Full native auditor PASS and parent launch GO are required')
    for key,width in [('source_commit',40),('source_tree',40),('manifest_sha256',64),('html_sha256',64),('package_sha256',64),('native_pass_report_sha256',64)]:
        if not re.fullmatch('[0-9a-f]{'+str(width)+'}',a.get(key,'')):raise ValueError('Exact '+key+' required')
    commit=a['source_commit'];root='https://192.168.0.36:8443/p/beat-the-house/play/test/'
    if a.get('canonical_url')!=root or a.get('immutable_url')!=root+commit+'/index.html':raise ValueError('Unexpected TEST URL')
    artifact=Path(a['finalized_stage']).resolve(strict=True)
    parent_stage=Path('E:/CodexQA/BTH/workspaces/BTH-ENVART-TEST-WEB-20261114').resolve(strict=True)
    if not artifact.is_relative_to(parent_stage):raise ValueError('Stage outside parent admitted E Web workspace')
    raw=(artifact/'build_manifest.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=a['manifest_sha256']:raise ValueError('Stage manifest mismatch')
    manifest=json.loads(raw)
    if manifest.get('source_commit')!=commit or manifest.get('source_tree')!=a['source_tree']:raise ValueError('Stage source identity mismatch')
    if manifest.get('active_art_packages',{}).get('motel')!=a['package_sha256']:raise ValueError('Active Motel package mismatch')
    for name,expected in manifest['files'].items():
        if name!=Path(name).name or name in ('.','..') or '/' in name or '\\' in name:raise ValueError('Unsafe artifact filename')
        p=artifact/name
        if p.stat().st_size!=expected['bytes'] or digest(p)!=expected['sha256']:raise ValueError('Stage artifact mismatch: '+name)
    if a['html_sha256']!=manifest['files']['index.html']['sha256']:raise ValueError('HTML hash mismatch')
    return a,artifact
