# Bar R4 served TEST proof

Final status: scoped actual served Web PASS on source 9ac963f185afbc5c54c604e5f68e8111f598d997. The exact approved target, director final gate, streamed identity and natural browser closure are bound in the final report. The preparation instructions below preserve the original prelaunch gate and remain mandatory for reproduction; the explicit parent GO was received before this run. Historical pending-target files are provenance, not the final admission record.

This workspace is read-only with respect to Beat the House, the art branch and the site. Nothing here is a native acceptance or Web acceptance. Browser launch is closed until the parent supplies `approved-target.json` with explicit GO, the exact full native PASS report and its hash, source commit/tree, finalized E-drive stage, served canonical/immutable URLs, root manifest and HTML hashes, and the exact Bar R4 package hash.

The prepared trial is Bar R4 package `398469b22c7c0eed36220757e79ce0829498aa79f4ecd1ce019df493abb02d39`: 19 payloads, 17 PNGs and 17 animation entries. The index is a package payload; it is not permission to activate the package. Inputs are immutable snapshots of the seal-verified art and source-authoritative initial Base plus seven-scenario union. Original Motel proof sources are retained separately for provenance.

## Execution contract

Use Windows Python at `C:/Users/theep/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe` and Node at `C:/Program Files/nodejs/node.exe`. Each actual worker is launched suspended, assigned to its own 12% CPU / 2 GiB kill-on-close Job, checked for membership, then resumed. The browser Job is independent from short probe Jobs. Never wrap the browser supervisor in an aggregate 2 GiB parent Job. The supervisor only coordinates jobs; it does not run the browser workload in process.

`bar_supervisor.py <unique-prefix>` is the browser launcher. Do not run it before the explicit parent GO. It uses qualified Chromium `C:/Users/theep/AppData/Local/ms-playwright/chromium-1243/chrome-win64/chrome.exe`, Playwright at `D:/Projects/site/node_modules/playwright`, a fresh E-drive profile and E temp/cache. No TLS bypass flags or ignore-HTTPS option are permitted. It launches to about:blank, then waits for sequential `<prefix>-command-<index>.json` files. Commands are immutable one-time files written through `command.py` using a guarded worker. Close the browser via a probe `mode: close` before sending the supervisor `mode: stop`.

`run_capped.py <unique-run-id> <timeout-seconds> <absolute-worker-executable> <arguments...>` runs one bounded worker and records Job resources. It uses the bundled storage plan/prepare/validate gates with the default 4 GiB expected writes plus 20 GiB reserve. No C-drive writable fallback or existing user profiles are admitted.

The browser probe only supplies real mouse/key actions, reads page/config and the disposable QA profile's TEST IndexedDB, and captures raw screenshots. Select every room and scenario through the actual Environment Library UI. Use seed LAYOUT-SURVEY-QA. Do not inject game state, scenarios, clock or animation opacity. Coordinates for a new action must come from observed screenshots. Do not treat reference command coordinates as proof of current UI state.

For final served-file proof, first send `mode: unload`. That navigates from the game to the exact immutable build_manifest.json and records no canvas/config. Then run `verify_served_bar.py <path-to-game-unloaded.json>` as a separate capped worker. It uses normal Python urllib TLS, streams each served file in 1 MiB blocks, hashes all listed bytes, maps the downloaded PCK read-only, checks actual embedded manifest and compiled-art hashes, audits PCK paths, and checks the unchanged NEXT pointer. Never download or hash the whole PCK into the live browser's memory.

## Evidence and interpretation

Use `analyze_bar.py <motion-evidence-folder>|<scenario-id> ...` under a capped worker. It saves exact mask PNGs, raw per-frame observations and composite-change reports. Full alpha-atlas masks can contain moving actors. Conservative masks remove source model/name envelopes, but do not guarantee all later actor positions. For scrolling smoke, the translated envelope is sampled, not a stationary alpha mask. Two smoke fields overlap. Seven floor glints share four lanes; the floor fitter corroborates independently known speeds rather than isolating entries. Hidden Payday warm_glint_0 must never be called visible because its actor ROI changes.

Deliver early raw Base, Wake and Payday screenshots at 1280x720 and 1920x1080 to the director. Complete all seven named current cases, observed bright/dim/minimum samples, supported Reduce Motion and restoration, actual selection/tooltip/return framing, and focused prior-four-room Base motion retention. Native 58 source contexts are separate from Web UI, quest/outcome/save/revisit/travel E2E. Do not claim that broader coverage here.

Retain failures and diagnostics, raw original screenshots, all command JSON, source and helper hashes, per-Job receipts, peak resources and natural versus forced exit. Final source ZIP must include all executable/probe/analyzer/mask/input/command sources and the exact approved target file, but no user profile or save data. Do not upload to Library unless requested.
