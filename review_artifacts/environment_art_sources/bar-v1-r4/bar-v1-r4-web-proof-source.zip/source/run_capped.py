"""One fresh bounded analysis/probe worker, retaining peak resources and cleanup."""
import sys,os,json
sys.dont_write_bytecode=True
from pathlib import Path
WORK=Path(__file__).parent
sys.path.insert(0,str(WORK/'repro-helpers'))
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
from bth_qa_guarded_run import execute
from cpu_job import CpuCappedJob,_base
from native_proof_worker import SuspendedWorker

prefix=sys.argv[1];timeout=int(sys.argv[2]);command=sys.argv[3:]
layout=prepare_layout(plan_layout('E:/CodexQA/BTH',WORK,prefix))
metrics={}
class ObservedJob(CpuCappedJob):
    def close(self):
        if self.handle:
            limits=self.query(9,_base.Limits())
            metrics.update(peak_job_memory_bytes=limits.peakJobMemory,cpu_seconds=self.cpu_seconds(),active_at_release=self.active())
        return super().close()
result=execute(layout,command,timeout=timeout,cpu_rate=1200,
    extra_write_paths=[WORK],job_factory=lambda:ObservedJob(1200,2*1024**3),worker_factory=SuspendedWorker)
result['resource_measurements']=metrics
result['natural_exit']=not result.get('timed_out') and not result.get('error') and result.get('exit_code')==0
validate_layout(layout)
(layout.evidence/'job.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'exit_code':result.get('exit_code'),'timed_out':result.get('timed_out'),
    'error':result.get('error'),'cleanup_errors':result['cleanup_errors'],'resources':metrics,'evidence':str(layout.evidence)}))
raise SystemExit(0 if result['natural_exit'] and not result['cleanup_errors'] and metrics.get('active_at_release')==0 else 1)
