"""Package exact source, inputs, masks, commands, diagnostics and measured reports.

Raw screenshots remain in the owned QA run, indexed by SHA256. The source archive
contains their complete acquisition commands plus every analysis input except the
large raw frame outputs, and can reproduce the acquisition at the bound URL.
"""
import sys,os,json,hashlib,zipfile,datetime
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).parent; ROOT=Path('E:/CodexQA/BTH/runs'); OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def info(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
approval=read(W/'approved-target.json')
identity_path=ROOT/'BTH-ENVART-BARWEB-final-identity-01/evidence/final-served-identity.json'
identity=read(identity_path);assert identity['status']=='PASS_SERVED_BYTES_EMBEDDED_IDENTITY_AND_ART'
browser=read(ROOT/'BTH-ENVART-BARWEB01-browser/evidence/owned-job-receipt.json')
assert browser['exit_code']==0 and browser['active_at_release']==0 and not browser.get('forced_owned_termination') and not browser['cleanup_errors']
browser_closure={'natural_exit':True,'forced_termination':False,'basis':'Browser.close completed in probe50; process was already exited0 before supervisor finally, so raw receipt omits forced_owned_termination. Owned job drained to0, cleanup empty.'}
gate=read(W/'director-final-gate.json');assert gate['source_commit']==identity['source_commit']
runs=sorted(p for p in ROOT.glob('BTH-ENVART-BARWEB*') if p.is_dir() and p!=OUT.parent)
jobs=[];failures=[];observations=[];screens=[];source_files={};console=[]
for run in runs:
 ep=run/'evidence'
 jp=ep/'job.json'
 if jp.exists():
  j=read(jp); item={'run':run.name,'receipt':info(jp),'exit_code':j.get('exit_code'),'timed_out':j.get('timed_out'),
   'error':j.get('error'),'cleanup_errors':j.get('cleanup_errors',[]),'resources':j.get('resource_measurements',{}),
   'natural_exit':not j.get('timed_out') and not j.get('error') and j.get('exit_code')==0}
  jobs.append(item)
  if not item['natural_exit'] or item['cleanup_errors']:failures.append(item)
  cmd=j.get('command',[])
  for idx,arg in enumerate(cmd[:-1]):
   if arg=='-c':source_files['executed-inline-commands/'+run.name+'.txt']=cmd[idx+1].encode()
 op=ep/'observation.json'
 if op.exists():
  ob=read(op); observations.append({'run':run.name,'url':ob.get('url'), 'messages':ob.get('messages',[]),'messagesObserved':ob.get('messagesObserved',[])})
  console.extend({'run':run.name,'message':m} for m in ob.get('messages',[])+ob.get('messagesObserved',[]))
 sp=ep/'save-isolation.json'
 if sp.exists():
  s=read(sp);assert s['all_writes_test_only']
  if run.name=='BTH-ENVART-BARWEB01-probe-50':
   assert s['args'] is None and identity['game_unloaded_before_hashing']['game_canvas_present'] is False
  else:assert s['args']==['--','--bth-art-test']
  assert s['databases']==['/userfs/godot/app_userdata/Beat the House/distribution/web_0_6_1_art_test']
 for p in sorted(ep.rglob('*.png')):
  if 'frames' in p.parts or p.parent==ep:screens.append(info(p))
 # No profile, temp, cache or raw IndexedDB content is packaged.
 for p in sorted(ep.rglob('*')):
  if not p.is_file() or 'frames' in p.parts or p.suffix.lower() in ('.zip','.pck'):continue
  if p.name=='indexeddb-full.json':continue
  if p.suffix.lower()=='.png' and p.parent==ep:continue
  source_files['evidence/'+run.name+'/'+str(p.relative_to(ep)).replace('\\','/')]=p
for p in sorted(W.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts and p.suffix.lower() not in ('.zip','.pyc'):
  source_files['source/'+str(p.relative_to(W)).replace('\\','/')]=p
native=Path(approval['native_pass_report']);source_files['native-approved-pass.json']=native
case_probes={'Base':[6,5],'The Wake':[10,11],'Payday Rush':[13,14],'Fight Night':[16,17],'Lock-In':[19,20],'Darts League Night':[22,23],'Live Band':[25,26],'Dead Tuesday':[28,29]}
cases=[]
for label,indices in case_probes.items():
 cases.append({'scenario':label,'screenshots':[info(ROOT/('BTH-ENVART-BARWEB01-probe-'+str(i))/'evidence/screen.png') for i in indices], 'viewports':[[1280,720],[1920,1080]]})
analysis={}
for short in ('base','priority','fight-lock','other-scenarios','wake-rm','base-rm','restoration'):
 p=ROOT/('BTH-ENVART-BARWEB-'+short+'-analysis-01')/'evidence/bar-composite-motion.json';r=read(p)
 summary=[]
 for item in r['reports']:
  regions=item['regions'];changed={n:v['temporal_changed_pixels'] for n,v in regions.items()}
  assert len(regions)==17
  if short.endswith('-rm'):assert not any(changed.values())
  else:assert all(v>0 for v in changed.values())
  summary.append({'scenario':item['scenario'],'frames':item['frames'],'duration_ms':item['duration_ms'],'changed_pixels_by_source_region':changed,'limits':item['limits']})
 analysis[short]={'report':info(p),'captures':summary}
retention={}
for room,idx in [('gas',42),('corner',44),('back',46),('motel',48)]:
 ep=ROOT/('BTH-ENVART-BARWEB-'+room+'-retention-01')/'evidence';j=read(ep/'job.json');assert j['exit_code']==0
 retention[room]={'screen':info(ROOT/('BTH-ENVART-BARWEB01-probe-'+str(idx))/'evidence/screen.png'),
  'reports':[info(p) for p in ep.glob('*.json') if p.name not in ('job.json','storage-manifest.json','launch-claim.json')],
  'scope':'Actual UI Base at 1280, 32 untouched temporal samples, focused composite retention only.'}
limits=[
 'Only actual Environment Library initial Base and all seven current Bar scenarios were exercised. The 58 native model contexts are not Web UI outcome, save or revisit E2E.',
 'LAYOUT-SURVEY-QA is the sole seed. No clock, scenario, model, animation alpha, or hidden-state injection. Automatic initial scenario narration is not a manually exercised outcome.',
 'Source masks are meaningful emitted-pixel composite observations, not isolated per-entry proof. Smoke fields overlap; seven floor tracks share four lanes. Native source-authoritative single-entry tests supply isolation and exact timing.',
 'Conservative free masks exclude initial source model/name envelopes, not every future actor position. Temporal low-range smoke filtering is declared diagnostic selection, not independent isolation.',
 'Payday warm_glint_0 is naturally covered by tray on 38 of 40 source support pixels; two residual pixels are not meaningful visibility. ROI changes do not establish hidden background-glint visibility.',
 'Darts scorer/exit labels overlap by 33.8001 x 15 board pixels in unchanged pre-art source: scorer [683.2001,307,81.6,15], exit [731,304,126,26]. Lock-In live names also overlap in the baseline. No universal unobstructed-name claim.',
 'Probe 4 is early arrival Base1280 evidence only; settled probe6 is the final1280 counter/name framing proof.',
 'Screenshot extrema are observed samples, not mathematical minima or peaks. Seven known-speed fits corroborate motion/wrap and are not isolated speed measurement.',
 'Read-only verifier did not change source, site, audience, primary worktree, real saves or user profiles. NEXT pointer independently checked; main/source/site/audience preservation remains integrator-owned evidence.',
 'Fresh disposable TEST persistence was observed only; real user saves were never read, copied or migrated. No claim of save/revisit E2E.',
 'Raw frame acquisition outputs are retained at indexed E paths and SHA256-bound separately. Source ZIP includes all code, art/union inputs, masks, commands, expected identities, measurements and diagnostics, not browser profiles or raw IndexedDB records.',
 'Final-summary01 packaging failed because its assertion expected game arguments even in close-probe50 after deliberate unload. Actual game-phase arguments and TEST isolation passed. The original script and failed receipt/log are preserved; the packaging phase check was corrected without rerunning browser captures.'
]
report={'schema':'bth.bar-r4-served-web-qa/v1','status':'PASS_SCOPED_ACTUAL_SERVED_WEB','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_commit':identity['source_commit'],'source_tree':identity['source_tree'],'package_sha256':approval['package_sha256'],
 'native_report':info(native),'normal_tls_identity':identity,'identity_report':info(identity_path),'director_visual_gate':gate,
 'browser_boot_identity':info(ROOT/'BTH-ENVART-BARWEB01-probe-0/evidence/served-browser-identity.json'),
 'scenario_cases':cases,'motion_analysis':analysis,'prior_four_retention':retention,
 'floor_speed_and_wrap':{'evidence_directory':str(ROOT/'BTH-ENVART-BARWEB-floor-analysis-01/evidence'),'frames':200,'duration_ms':91009,'best_fit_matches':7,'scope':'Retrospective known-speed periodic-wrap corroboration; exact native timing remains separate.'},
 'settings_and_framing':{'wake_rm':[33,34],'base_rm':[36],'restoration':[38],'selection_tooltip_camera':[39],'returned_room':[40],'action':'Selected book only; Open Book and outcomes were not clicked.'},
 'save_isolation':{'test_only':True,'args':['--','--bth-art-test'],'mount':'/userfs/godot/app_userdata/Beat the House/distribution/web_0_6_1_art_test','fresh_profile':True,'real_user_data_accessed':False},
 'resources':{'cpu_rate':1200,'memory_cap_bytes':2*1024**3,'expected_write_bytes_per_run':4*1024**3,'reserve_bytes':20*1024**3,'assigned_before_resume':True,'browser_independent_from_probe_jobs':True,'browser':browser,'jobs':jobs},
 'browser_closure':browser_closure,'diagnostic_failures_preserved':failures,'console_messages':console,'limitations':limits,'screenshot_index':'raw-capture-sha256.json'}
raw_index=json.dumps(screens,indent=2).encode();(OUT/'raw-capture-sha256.json').write_bytes(raw_index);source_files['raw-capture-sha256.json']=raw_index
source_files['final-report-before-archive-binding.json']=json.dumps(report,indent=2).encode()
source_files['REPRODUCTION.txt']=b'Use source/README-PROOF.md, approved-target.json, target_gate.py and the command-N JSONs. All actual workers must use the provided assigned-before-resume Job and E storage gate. No TLS bypass, no existing profiles, no hidden state mutation. Run analysis against newly acquired frames, or the SHA256-indexed retained raw E evidence. Original exploratory and diagnostic receipts are preserved. Source archive deliberately excludes real/profile data and generated raw frame bulk.\n'
archive=OUT/'bar-r4-web-proof-source.zip';index={}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,value in sorted(source_files.items()):
  data=value if isinstance(value,bytes) else value.read_bytes();index[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};z.writestr(name,data)
 z.writestr('SOURCE-INDEX.json',json.dumps(index,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,expected in index.items():assert hashlib.sha256(z.read(name)).hexdigest()==expected['sha256']
report['source_archive']=info(archive);report['source_archive']['entries']=len(index)+1
(OUT/'bar-r4-served-web-qa.json').write_text(json.dumps(report,indent=2))
(OUT/'proof-complete.json').write_text(json.dumps({'report':info(OUT/'bar-r4-served-web-qa.json'),'archive':info(archive),'raw_capture_index':info(OUT/'raw-capture-sha256.json')},indent=2))
print(json.dumps(read(OUT/'proof-complete.json')))
