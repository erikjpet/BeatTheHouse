"""Normal-TLS streamed served-byte proof, independent of the browser canvas test."""
import sys, os, json, hashlib, urllib.request, mmap
sys.dont_write_bytecode=True
from pathlib import Path, PurePosixPath
WORK=Path(__file__).parent
sys.path.insert(0,str(WORK/'repro-helpers'))
import audit_pck_manifest
from target_gate import admitted_target

def main():
    approval,stage=admitted_target(WORK)
    out=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
    base=approval['canonical_url']; commit=approval['source_commit']
    # The caller must explicitly unload the game and record that observation first.
    unload=Path(sys.argv[1]); marker=json.loads(unload.read_text())
    assert marker['url'].endswith('/'+commit+'/build_manifest.json')
    assert marker['game_canvas_present'] is False and marker['godot_config_present'] is False
    def read(url):
        with urllib.request.urlopen(url,timeout=40) as response:
            assert response.status==200
            return response.read()
    current=read(base+'current').decode().strip(); assert current==commit
    launcher=read(base); assert b'BTH_ART_TEST_MANAGED_LAUNCHER_V1' in launcher
    raw=read(base+commit+'/build_manifest.json')
    assert hashlib.sha256(raw).hexdigest()==approval['manifest_sha256']
    manifest=json.loads(raw); assert raw==(stage/'build_manifest.json').read_bytes()
    records={}
    for name,expected in manifest['files'].items():
        if name!=Path(name).name or '/' in name or '\\' in name: raise ValueError('Unsafe served filename')
        h=hashlib.sha256();count=0
        dest=(out/'served-index.pck').open('xb') if name=='index.pck' else None
        try:
            with urllib.request.urlopen(base+commit+'/'+name,timeout=40) as response:
                assert response.status==200
                for data in iter(lambda:response.read(1024*1024),b''):
                    h.update(data);count+=len(data)
                    if dest:dest.write(data)
        finally:
            if dest:dest.close()
        assert count==expected['bytes'] and h.hexdigest()==expected['sha256'],name
        records[name]={'sha256':h.hexdigest(),'bytes':count,'status':200}
    with (out/'served-index.pck').open('rb') as file, mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ) as pck:
        directory=audit_pck_manifest.parse_directory(pck,0)
        assert directory and not audit_pck_manifest.audit(directory['entries'])
        assert audit_pck_manifest.u32(pck,20)&~2==0
        entries={e['path']:e for e in directory['entries']}
        assert len(entries)==len(directory['entries'])
        for name,e in entries.items():
            p=PurePosixPath(name)
            assert not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix()==name
            assert e['flags']==0
        entry=entries['build_manifest.json'];assert 0<entry['bytes']<=1024*1024
        start=directory['file_base']+entry['offset'];end=start+entry['bytes']
        assert start>=112 and end<=len(pck)
        embedded=pck[start:end]; em=json.loads(embedded)
        assert hashlib.sha256(embedded).hexdigest()==manifest['embedded_manifest_sha256']
        assert hashlib.md5(embedded).hexdigest()==entry['md5']==manifest['embedded_manifest_md5']
        for key in ('source_commit','source_tree','art_package_sha256','build_version'):
            assert em[key]==manifest[key],key
        (out/'served-embedded-manifest.json').write_bytes(embedded)
        # Verify actual compiled art bytes, not just the root manifest declarations.
        compiled={}
        for name,expected in manifest['compiled_art_sha256'].items():
            e=entries[name]; start=directory['file_base']+e['offset'];end=start+e['bytes']
            assert end<=len(pck)
            h=hashlib.sha256();md5=hashlib.md5()
            for offset in range(start,end,1024*1024):
                block=pck[offset:min(offset+1024*1024,end)];h.update(block);md5.update(block)
            assert h.hexdigest()==expected and md5.hexdigest()==e['md5'],name
            compiled[name]=h.hexdigest()
        for name,expected in manifest['art_source_files'].items():
            if name.endswith('.png'):continue
            e=entries[name];start=directory['file_base']+e['offset'];data=pck[start:start+e['bytes']]
            assert hashlib.sha256(data).hexdigest()==expected and hashlib.md5(data).hexdigest()==e['md5'],name
        enabled_entry=entries['data/art/environments/index.json'];start=directory['file_base']+enabled_entry['offset']
        enabled=json.loads(pck[start:start+enabled_entry['bytes']])['enabled']
        assert enabled==['gas_station_casino','corner_store','back_alley','motel','bar']
    next_pointer=read('https://192.168.0.36:8443/p/beat-the-house/play/dev/current').decode().strip()
    assert next_pointer=='e5152c34bfe146600214fb206ec80a5e3e8a27cb'
    report={'status':'PASS_SERVED_BYTES_EMBEDDED_IDENTITY_AND_ART','canonical_url':base,
        'immutable_url':approval['immutable_url'],'current':current,'source_commit':commit,
        'source_tree':manifest['source_tree'],'manifest_sha256':hashlib.sha256(raw).hexdigest(),
        'embedded_manifest_sha256':manifest['embedded_manifest_sha256'],
        'embedded_manifest_md5':manifest['embedded_manifest_md5'],'active_art_packages':manifest['active_art_packages'],
        'art_source_file_count':len(manifest['art_source_files']),
        'compiled_texture_count':len(compiled),'enabled_rooms':enabled,'files':records,
        'next_pointer':next_pointer,'normal_tls_no_bypass':True,'streamed_1MiB_blocks':True,
        'game_unloaded_before_hashing':marker,'pck_content_audit_files':directory['file_count'],
        'limitations':['Main/source/audience preservation is separately verified by integrator. This read-only check observes NEXT pointer, not Git remote state.']}
    (out/'final-served-identity.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k not in ('files','game_unloaded_before_hashing')}))

if __name__=='__main__':main()
