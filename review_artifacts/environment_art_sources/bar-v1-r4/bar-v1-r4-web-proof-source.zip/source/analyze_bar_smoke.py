import sys,os,json,math,hashlib
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
w=Path(r'E:\CodexQA\BTH\workspaces\BTH-ENVART-BAR-WEB-20261114');out=Path(os.environ['BTH_QA_EVIDENCE_DIR']);e=Path(r'E:\CodexQA\BTH\runs\BTH-ENVART-BARWEB01-probe-6\evidence');motion=json.loads((e/'motion.json').read_text());u=json.loads((w/'inputs/bar_preart_union.json').read_text());scale=594/430;ox=(1280-900*scale)/2;oy=126
box=lambda r:[math.floor(ox+r[0]*scale),math.floor(oy+r[1]*scale),math.ceil(ox+(r[0]+r[2])*scale),math.ceil(oy+(r[1]+r[3])*scale)]
b=box([96,70,424,90]);mask=Image.new('L',(b[2]-b[0],b[3]-b[1]),255);draw=ImageDraw.Draw(mask)
for context in u['contexts'].values():
 for row in context['rows']:
  for field in ('model_rect','label_rect'):
   r=box(row[field]);draw.rectangle((r[0]-b[0]-2,r[1]-b[1]-2,r[2]-b[0]+2,r[3]-b[1]+2),fill=0)
frames=[]
for f in motion['frames']:
 with Image.open(e/'frames'/f['file']) as im:frames.append(np.asarray(im.convert('RGB').crop(b),dtype=np.int16))
stack=np.stack(frames);ranges=np.max(stack.max(axis=0)-stack.min(axis=0),axis=2);source=np.asarray(mask)>0;stable=source&(ranges<=16);changed=stable&(ranges>0)
Image.fromarray(np.uint8(source)*255).save(out/'all-initial-contexts-free-mask.png');Image.fromarray(np.uint8(stable)*255).save(out/'low-range-mask.png')
means=[float(p[stable].mean()) for p in frames];lo=int(np.argmin(means));hi=int(np.argmax(means))
report={'status':'OBSERVED_LOW_AMPLITUDE_COMPOSITE_SMOKE','source':str(e),'box':b,'all8_initial_context_exclusion_pixels':int(source.sum()),'low_range_mask_pixels':int(stable.sum()),'changed_low_range_pixels':int(changed.sum()),'max_delta_retained':int(ranges[stable].max()),'mean_rgb_min':means[lo],'mean_rgb_max':means[hi],'low_frame':motion['frames'][lo],'high_frame':motion['frames'][hi],'limits':['Conservative all-eight initial source model/name exclusions plus retrospective temporal-range<=16 filter. Diagnostic signal selection, not independent per-entry isolation.','Both translated smoke fields overlap; report is their composite smoke-region corroboration. Actor movement excluded where temporal range exceeds16 but low-amplitude live pixels may remain.','Raw screenshots unchanged and unenhanced; exact native single-entry evidence supplies isolation and intended drift speed.']}
(out/'bar-smoke-composite.json').write_text(json.dumps(report,indent=2));(w/'analyze_bar_smoke.py').write_text(Path(__file__).read_text() if '__file__' in globals() else '# The executable source is preserved verbatim in this run job.json command.\n')
print(json.dumps(report))