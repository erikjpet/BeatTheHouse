import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw
sys.path.insert(0,r'D:/Projects/Beat-The-House/.tmp/environment-art-layers/tools')
from bth_qa_storage import Layout,validate_layout
m=json.loads((Path(os.environ['BTH_QA_EVIDENCE_DIR'])/'storage-manifest.json').read_text());l=Layout(**{k:Path(v) for k,v in m['paths'].items()},run_id=m['run_id'],token=m['token'],prepared=True,expected_write_bytes=m['expected_write_bytes'],reserve_bytes=m['reserve_bytes']);w=l.workspace
artist=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-ARTIST-20261114/bar-v1');raw=artist/'source/background-guide-v1.png';h=hashlib.sha256(raw.read_bytes()).hexdigest();assert h=='11a65a14a8dd9d60e371e6b3abb111b132527c76ffc3e65d73b6443148f269f6'
s=Image.open(raw).convert('RGB').resize((900,430),Image.Resampling.NEAREST);b=s.copy();root=w/'packages/bar-v1-r4';validate_layout(l,extra_write_paths=(root,));assert not root.exists();asset=root/'assets/art/environments/bar';(asset/'anim').mkdir(parents=True);(asset/'counters').mkdir();(root/'data/art/environments').mkdir(parents=True)
def fit(box,size):return s.crop(box).resize(size,Image.Resampling.NEAREST)
def patch(box,donor):b.paste(s.crop((donor[0],donor[1],donor[0]+box[2]-box[0],donor[1]+box[3]-box[1])),box[:2])
# Only five board pixels of extra depth are needed. An existing same-scale upper-floor
# strip bridges the old horizon; lower perspective joints stay in their original scale.
b.paste(s.crop((0,251,900,256)),(0,244))
# Restore exposed timber outside the fitted mirror, never alter surrounding sign art.
patch((44,39,555,52),(44,12));patch((44,52,54,175),(28,52));patch((552,52,555,175),(568,52))
# Nine-slice keeps the exact inner support plane as well as the outer rectangle.
sx=(44,70,529,554);sy=(40,67,151,175);tx=(54,72,534,552);ty=(52,70,154,182)
for yi in range(3):
 for xi in range(3):b.paste(fit((sx[xi],sy[yi],sx[xi+1],sy[yi+1]),(tx[xi+1]-tx[xi],ty[yi+1]-ty[yi])),(tx[xi],ty[yi]))
# Exact 548x56 front, real thin warm top and opaque replay. No added bartender/stock.
patch((33,174,38,237),(24,174));patch((586,174,590,237),(590,174));patch((38,174,586,178),(38,19))
front=fit((34,175,589,236),(548,56));front.paste(front.crop((0,2,548,3)),(0,0))
# Confine gold contact highlight to178; preserve detailed warm wood face beneath it.
p=front.load()
for yy in range(2,6):
 for xx in range(548):
  r,g,bl=p[xx,yy];p[xx,yy]=(round(r*.50),round(g*.48),round(bl*.58))
b.paste(front,(38,178))
# Six exact stools. Source protrusions are replaced by adjacent same-row floor/wall.
for oldx,x in zip((103,184,264,344,424,504),(106,186,266,346,426,506)):
 patch((oldx-1,230,oldx+48,244),(550,230))
 patch((oldx+17,244,oldx+31,292),(570,244))
 b.paste(fit((oldx,230,oldx+47,244),(42,12)),(x,230))
 b.paste(fit((oldx+18,244,oldx+30,291),(10,48)),(x+16,242))
# Replay bar over the stool tops exactly as the authored foreground order requires.
b.paste(front,(38,178))
# Pool frame/felt, pendant and booth keep exact current fixture/contact footprints.
patch((595,185,825,188),(595,174));patch((595,188,598,264),(588,188));patch((822,188,825,264),(834,188));patch((595,264,825,266),(595,270))
b.paste(fit((596,186,824,263),(224,76)),(598,188));b.paste(fit((610,198,809,249),(196,48)),(612,200))
# Existing lamp housing108? The full authored pendant is654,124,112,14.
patch((651,122,769,124),(651,114));patch((651,124,654,140),(646,124));patch((766,124,769,140),(773,124));patch((654,138,766,140),(654,141))
b.paste(fit((652,123,769,141),(112,14)),(654,124))
# Keep source wire80..124 and real dartboard; these already follow the guide.
patch((651,301,654,348),(640,301));patch((796,301,800,348),(806,301));patch((654,344,796,348),(654,353))
booth=fit((653,302,797,347),(142,42));b.paste(booth,(654,302));b.paste(fit((664,333,784,347),(110,14)),(670,332))
for oldbox,x in [((667,346,681,386),672),((774,346,786,386),768)]:
 patch(oldbox,(805,346));b.paste(fit(oldbox,(10,38)),(x,346))
# R4 union-checked physical contrast correction, never a floating text backing.
union_path=Path(r'E:/CodexQA/BTH/runs/BTH-ENVART-BAR-20261114-preart-union-02/evidence/bar_preart_union.json');u=json.loads(union_path.read_text());pocket=(736,128,24,4);collisions=[]
def overlaps(a,c):return max(a[0],c[0])<min(a[0]+a[2],c[0]+c[2]) and max(a[1],c[1])<min(a[1]+a[3],c[1]+c[3])
for id,entry in u['object_union'].items():
 for v in entry['variants']:
  for kind in ('label_rect','model_rect'):
   if overlaps(v[kind],pocket):collisions.append({'id':id,'context':v['context'],'kind':kind,'rect':v[kind]})
assert not collisions,collisions
# Entire existing diffuser face is dark bronze glass; preserve original housing top/frame/wire.
bp=b.load()
for yy in range(128,137):
 for xx in range(656,764):
  r,g,bl=bp[xx,yy];bp[xx,yy]=(round(r*.23+7),round(g*.26+5),round(bl*.38+4))
# A compact warm pocket at the verified clear right end, not behind either current title.
for yy in range(128,132):
 for xx in range(736,760):
  r,g,bl=s.getpixel((xx,yy));edge=yy in (128,131) or xx in (736,759)
  bp[xx,yy]=(205,129,39) if edge else ((252,224,137) if (xx+yy)%9 else (230,174,72))
# Suppress source-shaped amber hotspot pixels only in the upper-left glass. Keep ripple structure/hue.
for yy in range(70,106):
 for xx in range(72,221):
  r,g,bl=bp[xx,yy]
  if r>g*1.08 and g>bl*1.3 and r>55:bp[xx,yy]=(round(r*.44),round(g*.43),round(bl*.60))
animations=[]
def save2(im,name):im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST).save(asset/'anim'/name)
# Follow actual painted neon glyphs, not a large rectangular light wash.
for id,box,color,speed,base,peak in [('dive_sign',(616,31,695,67),'pink',4,.10,.34),('cold_beer_sign',(597,82,733,110),'cyan',5.4,.08,.27)]:
 x0,y0,x1,y1=box;im=Image.new('RGBA',(x1-x0,y1-y0));p=im.load()
 for yy in range(y0,y1):
  for xx in range(x0,x1):
   r,g,bl=b.getpixel((xx,yy));ok=(r>125 and r>g*1.65 and bl>75) if color=='pink' else (g>125 and bl>125 and r<g*.85)
   if ok:p[xx-x0,yy-y0]=(r,g,bl,220)
 save2(im,id+'.png');period=math.pi/speed;animations.append({'id':id,'type':'pulse','texture':'anim/'+id+'.png','rect':[x0,y0,x1-x0,y1-y0],'min_opacity':base,'max_opacity':peak,'period':period,'phase':-period/4,'blend':'add','still':'first'})
# Separate exact small sin/cos excursions, crisp native-grid painted balls.
for i,(cx,cy,r,amp,rate,fun) in enumerate([(642,222,5,7,1.5,math.sin),(756,232,4,5,1.7,math.cos)]):
 F=48;ww=2*(amp+r)+1;hh=2*r+1;im=Image.new('RGBA',(ww*F,hh));d=ImageDraw.Draw(im)
 for f in range(F):
  x=round(amp+r+amp*fun(2*math.pi*f/F));off=f*ww;d.ellipse((off+x-r,0,off+x+r,hh-1),fill=(216,220,208,255));d.ellipse((off+x-r+1,1,off+x+r-1,hh-3),fill=(247,244,219,255));d.line((off+x-2,2,off+x,2),fill=(255,255,244,255));d.point((off+x+2,hh-2),fill=(151,166,153,255))
 save2(im,f'pool_ball_{i}.png');animations.append({'id':f'pool_ball_{i}','type':'frames','texture':f'anim/pool_ball_{i}.png','rect':[cx-amp-r,cy-r,ww,hh],'frames':F,'fps':F*rate/(2*math.pi),'loop':'loop','blend':'mix','still':0})
# Approved coherent sparse high-smoke translation, two drifting fields/five ribbons.
for layer,bands,speed in [(0,((4,180,0),(40,148,150),(76,116,280)),(10,.32)),(1,((22,164,70),(58,132,220)),(16,-.26))]:
 im=Image.new('RGBA',(424,90));d=ImageDraw.Draw(im)
 for j,(y,width,start) in enumerate(bands):
  for x in range(width):
   yy=y+round(math.sin((x+j*19)*.028)*2);taper=max(0,min(1,x/18,(width-1-x)/18))
   for dy in range(-3,4):
    a=round(11*taper*(1-abs(dy)/4))
    if (x+17*j+dy)%43 not in (0,1):d.point(((start+x)%424,yy+dy),fill=(87,194,205,a))
 save2(im,f'high_smoke_{layer}.png');animations.append({'id':f'high_smoke_{layer}','type':'scroll','texture':f'anim/high_smoke_{layer}.png','rect':[96,70,424,90],'speed':list(speed),'opacity':.9,'blend':'add','still':'hide'})
# Warm hardware reflections, actual small glass/rim sites, no invented prop.
glint=Image.new('RGBA',(6,6));d=ImageDraw.Draw(glint);d.line((0,3,5,3),fill=(242,184,84,155));d.line((3,1,3,5),fill=(249,215,131,145));d.point((3,3),fill=(255,242,187,220));save2(glint,'warm_glint.png')
wood=Image.new('RGBA',(6,6));wd=ImageDraw.Draw(wood);wd.line((2,0,2,2),fill=(242,184,84,155));wd.line((3,3,3,5),fill=(249,215,131,145));wd.point((2,4),fill=(255,242,187,175));save2(wood,'timber_reflection.png')
for i,(x,y) in enumerate(((98,92),(190,86),(362,92),(780,166))):
 per=math.pi/4.2;animations.append({'id':f'warm_glint_{i}','type':'pulse','texture':('anim/timber_reflection.png' if i==3 else 'anim/warm_glint.png'),'rect':[x-3,y-3,6,6],'min_opacity':.14,'max_opacity':.34,'period':per,'phase':i/4.2-per/4,'blend':'add','still':'hide'})
colors=((177,141,88),(89,165,162),(175,102,147),(193,150,96),(81,159,154),(177,102,144),(194,151,97))
for i,color in enumerate(colors):
 width=72-4*i;im=Image.new('RGBA',(width,2));p=im.load()
 for x in range(width):
  a=round(110*max(0,min(1,x/9,(width-1-x)/9)));a=round(a*.4) if (x+3*i)%19 in (0,1) else a;p[x,0]=(*color,a)
  if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
 save2(im,f'floor_glint_{i}.png');speed=18+2.5*i;y=274+(i%4)*14;animations.append({'id':f'floor_glint_{i}','type':'mover','texture':f'anim/floor_glint_{i}.png','size':[width,2],'from':[-90,y],'to':[950,y],'duration':1040/speed,'phase':137*i/speed,'opacity':.18,'blend':'add','still':'hide'})
assert len(animations)==17
b.save(root/'background-board-review.png');b.resize((1800,860),Image.Resampling.NEAREST).save(asset/'background.png');b.crop((38,178,586,234)).convert('RGBA').resize((1096,112),Image.Resampling.NEAREST).save(asset/'counters/bar_main_counter.png')
manifest={'schema':'bth.environment_art/v1','environment_id':'bar','board_size':[900,430],'pixel_scale':2,'background':{'texture':'background.png'},'animations':animations,'counters':{'bar_main_counter':{'texture':'counters/bar_main_counter.png','bleed':[0,0,0,0]}}}
(root/'data/art/environments/bar.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'data/art/environments/index.json').write_text(json.dumps({'enabled':['gas_station_casino','corner_store','back_alley','motel','bar']},indent=2)+'\n')
files={}
for p in sorted(list((root/'assets').rglob('*.png'))+list((root/'data').rglob('*.json'))):
 data=p.read_bytes();e={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 if p.suffix=='.png':
  im=Image.open(p);e.update(size=list(im.size),mode=im.mode)
  if im.mode=='RGBA':e['alpha_extrema']=list(im.getchannel('A').getextrema())
 files[p.relative_to(root).as_posix()]=e
sha=hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(files.items())).encode()).hexdigest();record={'package_id':'bar-v1-r4','status':'SEALED_TRIAL_NOT_PASSED','package_sha256':sha,'files':files,'sources':{'background-guide-v1.png':{'path':str(raw),'sha256':h,'size':list(Image.open(raw).size)}},'frozen_generation_inputs':json.loads((artist/'inputs/input-provenance.json').read_text()),'changes':['Source-preserving nearest900-grid, exact2x output; local teal/burgundy/amber identity, no Gas material donor.','R2 exact mirror outer54,52,498,130 and inner72,70,462,84 via source-preserving nine-slice;  counter178..234 opaque replay, six stool seat/post footprints230..290, pool188..264/felt200..248, pendant124..138, booth302..384.','Floor244; only five pixels of upper-floor source extension, original deeper texture scale retained.','R3: five broken feathered smoke ribbons in2 drift fields preserve comparable sparse density at alpha<=.035 effective; legacy780166 warm glint follows existing timber grain, not a floating cross. Background and contacts unchanged fromR2.','R4: only existing pendant diffuser and source-shaped upper-left amber-glass reflection changed for actual Wake/Payday contrast. Right-end honey pocket736128244 clear of every Base+7 initial label/model envelope; same fixture/frame/wire. No motion/front/contact changes.','17 entries:2 actual glyph pulses,2 independent sin/cos ball strips,2 sparse high smoke drift fields translating5 ribbons,4 glints,7 local floor movers.','Seven floor movers consolidate common sheen and old lower bob/stripe family per director; no literal dash markers.','No stock,patrons,bakedballs/smoke/glints; current placements/labels/renderer untouched. Actual composite acceptance pending.']};(root/'package-seal.json').write_text(json.dumps(record,indent=2));(root/'edit-record.json').write_text(json.dumps(record,indent=2));print(json.dumps({'package':str(root),'package_sha256':sha,'background_sha256':files['assets/art/environments/bar/background.png']['sha256'],'entries':len(animations),'files':len(files)}))
