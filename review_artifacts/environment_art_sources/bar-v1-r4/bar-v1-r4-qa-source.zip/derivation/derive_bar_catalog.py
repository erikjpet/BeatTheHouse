import copy, hashlib, json, os, re
from pathlib import Path
SRC=Path(r"E:\CodexQA\BTH\workspaces\BTH-ENVART-INTEGRATION-20261114")
OUT=Path(os.environ["BTH_QA_EVIDENCE_DIR"])
SEQ="data/environments/scenario_sequences/env06_7_bars_road.json"
LEG="data/environments/scenarios.json"
SLOTS="data/environments/scenario_slot_layouts.json"
FILES=[SEQ,LEG,SLOTS,"scripts/core/scenario_sequence_catalog.gd","scripts/core/scenario_sequence_runtime.gd","scripts/core/scenario_operation_registry.gd","scripts/core/scenario_layout_resolver.gd","scripts/core/environment_slot_binder.gd","tools/environment_layout_screenshots.gd","tools/envart_back_settled_r3.gd","tools/envart_motel_sequence_proof_r1.gd"]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
hashes={f:sha(SRC/f) for f in FILES}
source=json.loads((SRC/SEQ).read_text(encoding="utf-8-sig"))
legacy=json.loads((SRC/LEG).read_text(encoding="utf-8-sig"))["bar"]
layouts=json.loads((SRC/SLOTS).read_text(encoding="utf-8-sig"))["layouts"]
ids=[x["id"] for x in legacy]
assert len(ids)==7 and len(set(ids))==7
entries={x["scenario_id"]:(n,x) for n,x in enumerate(source["scenarios"]) if x["scenario_id"] in ids}
assert set(entries)==set(ids)
attached={"decision_route","task_station","task_zone"}
families={"scene_ops":"scenes","actor_ops":"actors","interaction_ops":"interactions","service_ops":"services","game_ops":"games","route_ops":"routes"}
def empty(): return {v:{} for v in families.values()}
def op_apply(st,op,ref):
    fam=op["family"]
    if fam not in families: return
    rows=st[families[fam]]; ident=op["stable_object_id"]; kind=op["op"]
    if kind in ("remove","despawn"):
        rows.pop(ident,None); return
    if kind in ("spawn","add","replace"):
        value=copy.deepcopy(op.get("object",op.get("actor",op.get("interaction",{}))))
        value["_source_ref"]=ref; value["_source_ops"]=[{"source_ref":ref,"operation":copy.deepcopy(op)}]
        rows[ident]=value; return
    assert ident in rows, (fam,ident,kind,ref)
    value=rows[ident]
    value["_source_ops"].append({"source_ref":ref,"operation":copy.deepcopy(op)})
    if kind in ("move","set_position"):
        for k in ("anchor_id","zone_id"):
            if k in op: value[k]=op[k]
        if fam=="actor_ops": value["authored_position_route_id"]=op.get("receipt_id","")
    elif kind in ("hide","reveal"): value["visible"]=kind=="reveal"
    elif kind in ("disable","enable"):
        value["enabled"]=kind=="enable"
        if kind=="disable": value["disabled_reason"]=op.get("disabled_reason","Unavailable.")
    elif kind.startswith("set_") and kind[4:] in ("state","appearance","pose","behavior","route"):
        value["route_id" if kind=="set_route" else kind[4:]]=op.get("route_id" if kind=="set_route" else kind[4:],"")
    else: raise AssertionError(("unsupported op",op,ref))
def apply_group(st,group,ref):
    for fam in families:
        for n,op in enumerate(group.get(fam,[])):
            op_apply(st,op,f"{ref}/{fam}/{n}")
def position_key(ident,row):
    return "|".join([ident,str(row.get("anchor_id","")),str(row.get("zone_id","")),str(row.get("authored_position_route_id",""))])
def binding(ident,row,layout):
    key=position_key(ident,row)
    for field in ("scenario_instance_slot_ids","scenario_instance_object_slot_ids"):
        for wanted in (key,ident,"scenario::"+ident):
            if wanted in layout.get(field,{}):
                return {"position_key":key,"slot_id":layout[field][wanted],"authority_field":field,"authority_key":wanted,"art_key":layout.get("scenario_instance_art_keys",{}).get(key)}
    return {"position_key":key,"slot_id":None}
def collect(st,layout):
    materials=[];actors=[];excluded=[];nonvisual=[]
    for family,target in (("scenes",materials),("actors",actors)):
        for ident,row in st[family].items():
            direct=st["interactions"].get(ident,{})
            rec={"id":ident,"source_label":row.get("label",""),"expected_label":direct.get("label",row.get("label","")),"role":row.get("role"),"state":row.get("state"),"appearance":row.get("appearance"),"anchor_id":row.get("anchor_id"),"zone_id":row.get("zone_id"),"visible":row.get("visible",True),"enabled":row.get("enabled",True),"source_ref":row["_source_ref"],"source_operations":row["_source_ops"]}
            if family=="actors":
                rec.update({k:row.get(k) for k in ("actor_id","pose","behavior","route_id","authored_position_route_id")})
            if direct: rec["direct_interaction_label"]=direct.get("label")
            if family=="scenes" and row.get("role") in attached:
                rec["exclusion"]="hosted_station_control" if row.get("role")=="task_station" else "hosted_abstract_control"
                rec["exclusion_source"]="scripts/core/environment_slot_binder.gd:48-50,1129-1150"
                rec["exact_action_host"]=layout.get("scenario_instance_action_host_ids",{}).get("scenario::"+ident)
                rec["action_ids"]=[a["id"] for a in direct.get("available_actions",[])]
                rec["hosting_rule"]="Explicit scenario_instance_action_host_ids when present; otherwise production resolver scoring selects visible enabled physical host. Hosted control labels do not replace the host label."
                excluded.append(rec);continue
            rec["binding"]=binding(ident,row,layout)
            if not row.get("visible",True):
                rec["exclusion"]="source_hidden";rec["exclusion_source"]="scene_ops hide / visible:false; disabled alone is not hidden"
                excluded.append(rec);continue
            if row.get("presentation_mode","room")!="room":
                rec["exclusion"]="source_non_room";excluded.append(rec);continue
            assert rec["binding"]["slot_id"], ("missing source slot",ident,rec["binding"])
            assert rec["expected_label"],ident
            target.append(rec)
    for fam in ("services","games","routes"):
        for ident,row in st[fam].items():
            nonvisual.append({"id":ident,"family":fam,"source_label":row.get("label"),"source_ref":row["_source_ref"],"exclusion":"No scene_ops/actor_ops visual is authored for this semantic record; no independent in-room geometry claim."})
    return {"expected_material_ids":[r["id"] for r in materials],"expected_actor_ids":[r["id"] for r in actors],"material_evidence":materials,"actor_evidence":actors,"excluded_materials":excluded,"excluded_nonvisual_records":nonvisual}
cases=[];alternates=[];decision_routes=[];summaries=[]
for sid in ids:
    index,entry=entries[sid];seq=entry["sequence"];pref=f"{SEQ}#/scenarios/{index}/sequence"
    phase_list=seq["phase_graph"]["phases"];phases={p["id"]:p for p in phase_list}
    layout_candidates=[l for l in layouts if l["scenario_id"]==sid and l["map_id"]=="bar"]
    assert len(layout_candidates)==1
    layout=layout_candidates[0];lidx=layouts.index(layout)
    phase_refs={p["id"]:f"{pref}/phase_graph/phases/{n}" for n,p in enumerate(phase_list)}
    active=[p for p in phase_list if not p.get("terminal",False)]
    paths={seq["phase_graph"]["initial_phase"]:[]};states={};route_evidence={};state=empty()
    for n,p in enumerate(active):
        assert p["id"] in paths,(sid,p["id"])
        apply_group(state,p,phase_refs[p["id"]]);states[p["id"]]=copy.deepcopy(state)
        action_sources={}
        for iid,irow in state["interactions"].items():
            for action in irow.get("available_actions",[]):
                action_sources.setdefault(action["id"],[]).append({"source_id":iid,"interaction_label":irow.get("label"),"source_ref":irow["_source_ref"],"action":copy.deepcopy(action)})
        available=set(action_sources)
        # Primary chain is authored first branch: arrival begin, then work completion.
        primary=p["branches"][0];cond=primary["condition"]
        assert cond["type"]=="command" and cond["command_id"] in available
        for b in p["branches"]:
            c=b["condition"]
            if c["type"]=="command": assert c["command_id"] in available,(sid,p["id"],c)
            elif c["type"]=="fact": assert c["fact_type"] in seq["fact_subscriptions"]
            else: raise AssertionError(("unexpected active branch",sid,p["id"],b))
        route_evidence[p["id"]]=action_sources
        nextid=primary.get("next_phase")
        if nextid and not phases[nextid].get("terminal",False):
            assert nextid not in paths
            paths[nextid]=paths[p["id"]]+[cond["command_id"]]
        identity_phase=entry["authoring"]["seed_evidence"]["identity_decision_phase"]
        case={"scenario_id":sid,"kind":"active_phase","phase":p["id"],"phase_label":p.get("label"),"commands":paths[p["id"]],"source_ref":phase_refs[p["id"]],"phase_roles":["arrival"] if p["id"]=="arrival" else ["work"],"source_ops":p.get("scene_ops",[]),"actor_source_ops":p.get("actor_ops",[]),"authored_interactions":[{"id":i,"source_ref":r["_source_ref"],"label":r.get("label"),"actions":r.get("available_actions",[])} for i,r in state["interactions"].items()],"layout_source_ref":f"{SLOTS}#/layouts/{lidx}"}
        if p["id"]==identity_phase:
            case["phase_roles"].append("identity_decision")
            case["identity_decision_commands"]=entry["authoring"]["seed_evidence"]["identity_decision_verbs"]
        case.update(collect(state,layout));cases.append(case)
    terminal_outcomes={}
    for p in phase_list:
        if p.get("terminal",False):
            assert len(p["branches"])==1 and p["branches"][0]["condition"]["type"]=="always"
            terminal_outcomes[p["id"]]=p["branches"][0]["outcome"]
    assert set(terminal_outcomes.values())==set(seq["aftermath"])
    def finish_route(p,branch):
        commands=list(paths[p["id"]]);condition=branch["condition"];fact=None
        if condition["type"]=="command": commands.append(condition["command_id"])
        else: fact=copy.deepcopy(condition)
        chain=[{"phase":p["id"],"source_ref":phase_refs[p["id"]]+"/branches/"+str(p["branches"].index(branch)),"branch":branch}]
        target=branch["next_phase"]
        while not phases[target].get("terminal",False):
            nxt=phases[target];step=nxt["branches"][0]
            assert fact is None
            commands.append(step["condition"]["command_id"])
            chain.append({"phase":target,"source_ref":phase_refs[target]+"/branches/0","branch":step})
            target=step["next_phase"]
        record={"scenario_id":sid,"from_phase":p["id"],"commands":commands,"terminal_phase":target,"outcome":terminal_outcomes[target],"branch_chain":chain,"terminal_source_ref":phase_refs[target]+"/branches/0","terminal_branch":phases[target]["branches"][0]}
        if fact: record["fact"]=fact
        if condition["type"]=="command":
            record["trigger_action_origins"]=route_evidence[p["id"]][condition["command_id"]]
        return record
    allroutes=[]
    for p in active:
        for branch in p["branches"]:
            record=finish_route(p,branch);allroutes.append(record)
            if branch["condition"].get("command_id") in entry["authoring"]["seed_evidence"]["identity_decision_verbs"]:
                decision_routes.append(record)
    last=active[-1]
    for terminal,outcome in terminal_outcomes.items():
        if terminal=="terminal_success": branch=last["branches"][0]
        elif terminal=="terminal_failure": branch=next(b for b in last["branches"] if b["condition"].get("command_id")=="fail_"+sid)
        elif terminal=="terminal_refused": branch=next(b for b in last["branches"] if b["condition"].get("command_id")=="refuse_"+sid)
        elif terminal=="terminal_interrupted": branch=next(b for b in last["branches"] if b["condition"].get("fact_type")=="travel_departed")
        else: raise AssertionError(terminal)
        route=finish_route(last,branch)
        assert route["outcome"]==outcome
        result=copy.deepcopy(states[last["id"]])
        for oi,op in enumerate(seq["cleanup"]["operations"]): op_apply(result,op,f"{pref}/cleanup/operations/{oi}")
        assert all(not result[f] for f in ("scenes","actors","interactions")),(sid,"cleanup remains")
        aftermath=seq["aftermath"][outcome];aref=f"{pref}/aftermath/{outcome}"
        apply_group(result,aftermath,aref)
        case={"scenario_id":sid,"kind":"aftermath","outcome":outcome,"label":aftermath["label"],"commands":route["commands"],"source_ref":aref,"branch_source":branch,"terminal_phase":terminal,"route_evidence":route,"source_ops":aftermath.get("scene_ops",[]),"actor_source_ops":aftermath.get("actor_ops",[]),"cleanup_source_ref":pref+"/cleanup","layout_source_ref":f"{SLOTS}#/layouts/{lidx}"}
        if "fact" in route:case["fact"]=route["fact"]
        case.update(collect(result,layout));cases.append(case)
        unique={}
        for rt in allroutes:
            if rt["outcome"]==outcome:
                sig=json.dumps([rt["commands"],rt.get("fact")],sort_keys=True)
                unique[sig]=rt
        alternates.extend(unique.values())
    summaries.append({"scenario_id":sid,"display_name":next(r["display_name"] for r in legacy if r["id"]==sid),"active_phases":[p["id"] for p in active],"active_phase_count":len(active),"identity_decision_phase":entry["authoring"]["seed_evidence"]["identity_decision_phase"],"outcomes":list(seq["aftermath"]),"aftermath_family_count":len(seq["aftermath"]),"primary_case_count":len(active)+len(seq["aftermath"]),"legacy_source_ref":f"{LEG}#/bar/{ids.index(sid)}","sequence_source_ref":pref,"layout_source_ref":f"{SLOTS}#/layouts/{lidx}"})
assert len(cases)==58
assert sum(c["kind"]=="active_phase" for c in cases)==30
assert sum(c["kind"]=="aftermath" for c in cases)==28
assert len(decision_routes)==21
allcaseids=[c["scenario_id"]+"__"+c["kind"]+"_"+c.get("outcome",c.get("phase","")) for c in cases]
assert len(set(allcaseids))==58
notes=[
"Source derivation only. No Godot, actual Runtime command, production publication, screenshot, save/revisit or UI-click proof was run by this worker.",
"The primary 58 cases cover each of 30 stable nonterminal arrival/work phases and each of 28 unique authored aftermath families. Seven identity decisions are embedded in arrival/work phases; there is no separate active decision phase in this package.",
"Expected physical IDs are scenario-owned only; production observer must also verify every visible room object in the resolved renderer snapshot, including base objects. No assertion is made that these IDs exhaust the entire room.",
"Primary aftermath routes complete all reachable ordinary work before generic success/fail/refuse/travel fact resolution. All authored direct branch routes, including identity choices and supported pressure facts, are cataloged separately and are not extra aftermath families.",
"Scene disable sets enabled:false but leaves visible unchanged. Disabled fight split table and darts bracket easel stay expected physical room objects. Hide removes in-room expectation for chair, shutters, darts throw line, and speaker stack in later work phases.",
"task_station, task_zone and decision_route roles are hosted controls even when visible:true or named like physical objects. All Dead Tuesday task zones are excluded, with their real actors retained.",
"Expected labels equal an extant direct semantic interaction label when present, otherwise the authored visual label. Attached task labels never replace host labels. Actual resolved renderer/public interaction state remains authoritative and must be verified.",
"Exact hosted target is supplied where the layout explicitly names one. Other task hosts are selected by production resolver scoring against actual base+scenario inventory; no static guessed host is asserted.",
"Aftermath cleanup removes all active scenario scene/actor/interaction records before aftermath operations. Service/game/route semantics without authored scene/actor visuals are not standalone room props.",
"Fact fixtures use inherited _rw06_1_apply_trace_fact with supported producer/payload selection and boundary flushing. This is a valid-runtime-route specification, not evidence of real travel/service/game UI execution.",
"warn_brawlers uses event_bridge for scenario_fight_night_swing_bet / keep_off_the_book and requires catalog-proven event choices in the generated environment. No extra synthetic event mutation is authorized.",
"Preserve source naming mismatches: choose_fight_side -> broken_room; side_chosen <- refuse_bar_fight_night. defer_payday_tabs -> orders_spilled; tabs_deferred <- refuse_bar_payday_rush. Do not relabel or reroute them.",
"Identity verbs mediate_fight_lines, carry_payday_service, uphold_disputed_dart and complete_live_set advance to further work rather than directly resolve aftermath; their alternate routes append the remaining ordinary work.",
"Do not copy Motel's 40-case gate, scenario IDs, separate decision-phase assumption, or safe_exit phase. Bar totals and IDs come from the exact sources below."
]
doc={"source":SEQ,"source_sha256":hashes[SEQ],"scope":"Exact-source-derived Bar scenario physical work/outcome catalog for unchanged production Runtime/commit/publication observer. Not runtime proof.","schema":"envart.bar_sequence_cases/v1","source_workspace":str(SRC),"source_files_sha256":hashes,"scenario_ids":ids,"counts":{"scenarios":7,"active_phase_cases":30,"aftermath_cases":28,"primary_cases":58,"identity_decision_contexts":7,"identity_decision_routes":21,"alternate_routes":len(alternates)},"scenarios":summaries,"cases":cases,"alternate_authored_routes":alternates,"identity_decision_routes":decision_routes,"unsupported_routes":[],"ambiguous_routing":[{"scenario_id":"bar_fight_night","command":"choose_fight_side","actual_source_outcome":"broken_room","similarly_named_family":"side_chosen","that_family_route":"refuse_bar_fight_night"},{"scenario_id":"bar_payday_rush","command":"defer_payday_tabs","actual_source_outcome":"orders_spilled","similarly_named_family":"tabs_deferred","that_family_route":"refuse_bar_payday_rush"}],"notes":notes,"source_refs":[LEG+"#/bar",SEQ+"#/scenarios/0",SLOTS,"scripts/core/environment_slot_binder.gd:1129-1195","scripts/core/scenario_layout_resolver.gd:517-670","scripts/core/scenario_operation_registry.gd:556-649","scripts/core/scenario_sequence_runtime.gd:1410-1483","tools/environment_layout_screenshots.gd:2893-2984"]}
for f,h in hashes.items(): assert sha(SRC/f)==h,("source changed during derivation",f)
output=OUT/"envart_bar_sequence_cases.json"
with output.open("x",encoding="utf-8",newline="\n") as h: json.dump(doc,h,indent=2,ensure_ascii=False);h.write("\n")
summary={"catalog_path":str(output),"catalog_sha256":sha(output),"counts":doc["counts"],"source_sha256":hashes[SEQ],"scenario_counts":[{"scenario":s["scenario_id"],"active":s["active_phase_count"],"aftermath":s["aftermath_family_count"],"total":s["primary_case_count"]} for s in summaries],"excluded_counts":{k:sum(x.get("exclusion")==k for c in cases for x in c["excluded_materials"]) for k in ("hosted_station_control","hosted_abstract_control","source_hidden","source_non_room")},"nonvisual_record_count":sum(len(c["excluded_nonvisual_records"]) for c in cases),"source_hashes":hashes,"limitations":notes,"worker_sha256":sha(Path(__file__))}
with (OUT/"catalog_summary.json").open("x",encoding="utf-8") as h: json.dump(summary,h,indent=2);h.write("\n")
print(json.dumps(summary,indent=2))
