import sys,json,hashlib,urllib.request
from pathlib import Path
sys.dont_write_bytecode=True
out=Path(sys.argv[1]);base='https://192.168.0.36:8443/p/beat-the-house/play/test/';commit='ab0b49deeab019deac7ef30b79b17f86ffbc521d'
def read(url):
 with urllib.request.urlopen(url,timeout=30) as r:
  assert r.status==200
  return r.read()
assert read(base+'current').decode().strip()==commit
launcher=read(base);assert b'BTH_ART_TEST_MANAGED_LAUNCHER_V1' in launcher
raw=read(base+commit+'/build_manifest.json');assert hashlib.sha256(raw).hexdigest()=='b649abdab0bc99582136d0d4c81ff238da14dd3b2a1bbb72b354b34ce9939e26'
m=json.loads(raw);records={}
for name,meta in m['files'].items():
 h=hashlib.sha256();n=0
 with urllib.request.urlopen(base+commit+'/'+name,timeout=30) as r:
  assert r.status==200
  while True:
   data=r.read(1024*1024)
   if not data:break
   h.update(data);n+=len(data)
 assert h.hexdigest()==meta['sha256'] and n==meta['bytes'],name
 records[name]={'sha256':h.hexdigest(),'bytes':n}
site=Path('D:/Projects/site');before=json.loads(Path('E:/CodexQA/BTH/runs/BTH-ENVART-INTEGRATION-20261114-test-promotion-01/evidence/protected_before.json').read_text(encoding='utf-8-sig'));after={k:hashlib.sha256((site/k).read_bytes()).hexdigest() for k in before};assert before==after,'Protected source/audience/home/NEXT bytes changed'
next_pointer=read('https://192.168.0.36:8443/p/beat-the-house/play/dev/current').decode().strip();assert next_pointer=='e5152c34bfe146600214fb206ec80a5e3e8a27cb'
report={'status':'PASS_SERVED_IDENTITY_AND_PROTECTED_LANES','source_commit':commit,'art_package_sha256':m['art_package_sha256'],'build_manifest_sha256':hashlib.sha256(raw).hexdigest(),'test_url':base,'immutable_url':base+commit+'/index.html','default_tls_validation':True,'files':records,'protected_before':before,'protected_after':after,'next_pointer':next_pointer,'browser_visual_scenario_gate':'not run; isolated CUA window binding failed, no alternative user profile used'}
oldbuild=site/'projects/beat-the-house/public/play/test/0c9eeec1202ed9fe4e56bfc1fce8bea2e2daae1c'
assert hashlib.sha256((oldbuild/'build_manifest.json').read_bytes()).hexdigest()=='444aae091e7557c13a9c21eb2be13be28b71a09db929693c9c21a94028792fa0'
assert hashlib.sha256((oldbuild/'index.pck').read_bytes()).hexdigest()=='49389b088b3885418a240b13dbe499bf2ae0f2fb4a41a4b2b09b590f1daefa7e'
report['previous_immutable_build_unchanged']=True
previous=site/'projects/beat-the-house/public/play/test/173b235da9171a5369894bdfb5e9f901d009e018'
assert hashlib.sha256((previous/'build_manifest.json').read_bytes()).hexdigest()=='fa88f8ae701e9a92bf8de58610e0be0b7db0e763c897fe4d9b2ca01d9aa98663'
assert hashlib.sha256((previous/'index.pck').read_bytes()).hexdigest()=='9f4bb6ee211eda7ffe7cb08304e401e857608ef6dcb694b12c37fb652203e361'
report['previous_173_immutable_build_unchanged']=True
previous5=site/'projects/beat-the-house/public/play/test/9ac963f185afbc5c54c604e5f68e8111f598d997'
assert hashlib.sha256((previous5/'build_manifest.json').read_bytes()).hexdigest()=='9e48c8f1b1064c369e5450f7959569f742d9dead67f3bce6502d28f4d35b07c5'
assert hashlib.sha256((previous5/'index.pck').read_bytes()).hexdigest()=='c9bc7c1c47a43dd1cd8dd99241146d45eeddefbe6296ec0d91a17dc653723dc0'
report['previous_9ac_immutable_build_unchanged']=True
(out/'served-proof.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ['files','protected_before','protected_after']}))
