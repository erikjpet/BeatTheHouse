import sys,json,hashlib,re,shutil,datetime
from pathlib import Path
sys.dont_write_bytecode=True
w=Path('E:/CodexQA/BTH/workspaces/BTH-ENVART-TEST-WEB-20261114');root=w/'.tmp/web-release-ab0b49de';s=root/'stage';out=Path(sys.argv[1]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(w/'tools'));import audit_pck_manifest
from prepare_environment_art_build_identity import verify_embedded_identity
identity=json.loads((w/'build_manifest.json').read_text(encoding='utf-8-sig'));assert identity['source_commit']=='ab0b49deeab019deac7ef30b79b17f86ffbc521d';assert identity['art_package_sha256']=='85a22382e63379b340c21121e4d78ad6d82abea17efb8a20ad876afb01cb80a3'
verify=verify_embedded_identity(s/'index.pck',identity);(out/'embedded-verification.json').write_text(json.dumps(verify,indent=2));shutil.copyfile(w/'build_manifest.json',out/'embedded-build-manifest.json')
b=(s/'index.pck').read_bytes();d=audit_pck_manifest.find_directory(b);assert not audit_pck_manifest.audit(d['entries']);entries={e['path']:e for e in d['entries']};assert not [x for x in entries if x.startswith(('review_artifacts/','tools/','docs/'))]
pawn=json.loads((w/'docs/art/pawn_shop_v1_r2_provenance.json').read_text(encoding='utf-8-sig'));old=json.loads((w/'.tmp/web-release-9ac963f1/stage/build_manifest.json').read_text(encoding='utf-8-sig'))
raw={k:{'sha256':v} for k,v in old['art_source_files'].items() if k!='data/art/environments/index.json'};raw.update(pawn['payload_files']);compiled={};links=[]
for rel,meta in raw.items():
 p=w/rel;assert sha(p)==meta['sha256'],rel;md5=hashlib.md5(p.read_bytes()).hexdigest()
 if rel.endswith('.png'):
  text=Path(str(p)+'.import').read_text(encoding='utf-8-sig');path=re.search(r'^path="res://([^"\n]+)"',text,re.M).group(1);ctex=w/path;assert path in entries,path;mdtext=ctex.with_suffix('.md5').read_text(encoding='utf-8-sig');assert re.search(r'source_md5="([0-9a-f]+)"',mdtext).group(1)==md5,rel
  c=ctex.read_bytes();assert hashlib.md5(c).hexdigest()==entries[path]['md5'],path;compiled[path]=sha(ctex);links.append({'source':rel,'source_sha256':sha(p),'source_md5':md5,'compiled':path,'compiled_md5':entries[path]['md5']})
 else:assert entries[rel]['md5']==md5,rel
for rel,h in old['compiled_art_sha256'].items():assert compiled[rel]==h,rel
assert len(raw)==101 and len(compiled)==94
assert sha(w/'scripts/core/persistence_paths.gd')==old['persistence_core_sha256'];assert json.loads((w/'data/art/environments/index.json').read_text())['enabled']==['gas_station_casino','corner_store','back_alley','motel','bar','pawn_shop']
html=(s/'index.html').read_text();assert '--bth-art-test' in html and '/userfs/godot/app_userdata/Beat the House/distribution/web_0_6_1_art_test' in html
active=dict(old['active_art_packages']);active['pawn_shop']=pawn['package_sha256'];m=dict(identity);m.update(source_branch='codex/environment-art-layers',source_archive_sha256=sha(root/'source.tar'),art_audit_report_sha256=pawn['audit_report_sha256'],active_art_packages=active,art_source_files={k:v['sha256'] for k,v in raw.items()},compiled_art_sha256=compiled,native_library_path=old['native_library_path'],native_donor_source_commit=old['native_donor_source_commit'],template_sha256=old['template_sha256'],persistence_core_sha256=old['persistence_core_sha256'],test_args=['--','--bth-art-test'],persistent_paths=old['persistent_paths'],generated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),embedded_manifest_sha256=verify['embedded_manifest_sha256'],embedded_manifest_md5=verify['embedded_manifest_md5'],files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(s.iterdir()) if p.is_file() and p.name!='build_manifest.json'})
(s/'build_manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8');(out/'art-source-import-pck-linkage.json').write_text(json.dumps({'status':'PASS','raw_files':len(raw),'compiled_textures':len(compiled),'prior_five_room_compiled_unchanged':len(old['compiled_art_sha256']),'links':links},indent=2))
oldb=(w/'.tmp/web-release-9ac963f1/stage/index.pck').read_bytes();od=audit_pck_manifest.find_directory(oldb);oe={e['path']:e for e in od['entries']};changed=[]
for name,e in oe.items():
 assert name in entries,name;f=entries[name];x=od['file_base']+e['offset'];y=d['file_base']+f['offset']
 if oldb[x:x+e['bytes']]!=b[y:y+f['bytes']]:changed.append(name)
assert set(changed)=={'build_manifest.json','data/art/environments/index.json','.godot/uid_cache.bin'},changed
added=sorted(entries.keys()-oe.keys());assert len(added)==35;diff={'status':'PASS_EXPECTED_ART_ONLY_DELTA','added':added,'removed':[],'changed':sorted(changed),'unchanged':len(oe)-len(changed)};(out/'pck-diff.json').write_text(json.dumps(diff,indent=2))
assert (w/'build_manifest.json').read_bytes()==(out/'embedded-build-manifest.json').read_bytes();(w/'build_manifest.json').unlink()
print(json.dumps({'status':'PASS_BOUND_PAWN_STAGE','source_commit':m['source_commit'],'manifest_sha256':sha(s/'build_manifest.json'),'html_sha256':sha(s/'index.html'),'pck_sha256':sha(s/'index.pck'),'raw_files':len(raw),'compiled_textures':len(compiled),'prior_unchanged':True,'pck_diff':diff,'embedded':verify}))
