"""Package the exact partial artifact proof; never publish profiles or inventories."""
import sys,os,json,hashlib,zipfile,io,re
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).parent; OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR']); ROOT=Path('E:/CodexQA/BTH')
from artifact_target_gate import admitted_artifacts
a,stage,manifest,gate=admitted_artifacts(W)
E=ROOT/'runs/BTH-ENVART-PAWNWEB-artifact-verify-01/evidence'
source_report=E/'pawn-r2-partial-served-artifact-report.json';report=json.loads(source_report.read_bytes())
assert report['status']=='PARTIAL_ARTIFACT_PASS_LIVE_WEB_NOT_RUN' and report['source_commit']==a['source_commit']
H=lambda b:hashlib.sha256(b).hexdigest()
attachments=re.compile(r'(?:file_[0-9a-f]{24,}|libfile_[A-Za-z0-9_-]+)')
routing=re.compile(r'/root/[a-z][a-z0-9_]*(?:/[a-z][a-z0-9_]*)*')
redactions=[];files={};code_count=pixel_count=0

def metadata(raw,name):
    if Path(name).suffix.lower() not in ('.json','.md','.log','.txt'):return raw
    text=raw.decode('utf8');clean=routing.sub('[internal task reference omitted]',attachments.sub('[native attachment reference omitted]',text))
    if clean==text:return raw
    b=clean.encode('utf8');redactions.append({'file':name,'kind':'metadata_only','original_sha256':H(raw),'copy_sha256':H(b)})
    return b

def nested_bar(raw):
    output=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(raw)) as source,zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as dest:
        for item in source.infolist():
            b=source.read(item.filename);c=metadata(b,'reference-bar/bar-r4-web-proof-source.zip!'+item.filename)
            if item.filename.endswith(('.py','.gd','.cjs','.js','.png')):assert c==b
            dest.writestr(item,c)
    b=output.getvalue();redactions.append({'file':'reference-bar/bar-r4-web-proof-source.zip','kind':'nested_metadata_only_container','original_sha256':H(raw),'copy_sha256':H(b)})
    return b

def add(p,name):
    global code_count,pixel_count
    assert not any(part.lower() in {'profile','indexeddb','cache','home','appdata','localappdata','save_dir','__pycache__'} for part in Path(name).parts),name
    raw=Path(p).read_bytes(); b=nested_bar(raw) if name=='reference-bar/bar-r4-web-proof-source.zip' else metadata(raw,name)
    if name.endswith(('.py','.gd','.cjs','.js')):assert b==raw;code_count+=1
    if name.endswith('.png'):assert b==raw;pixel_count+=1
    if name=='inputs/native/pawn-r2-native-qa-source.zip':assert H(b)=='f3642463d98c0200a332d0b6a2bfee3f832f861b8235126510544afc9bf1e867'
    assert name not in files;files[name]=b

for p in sorted(W.rglob('*')):
    if p.is_file() and p.suffix.lower() in ('.py','.cjs','.json','.md','.png','.zip','.html'):
        name=p.relative_to(W).as_posix();assert name!='approved-target.json';add(p,name)

# Only the owned qualification facts/receipt and authored calibration are public.
# Never copy profiles, CUA inventories, real browser tabs, clipboard data or
# opaque user-session routing. None were written into this worker's evidence.
surface=ROOT/'runs/BTH-ENVART-PAWNWEB-surface-01/evidence'
for name in ('owned-job-receipt.json','cua-qualification-blocker.json','storage-manifest.json','stop-request.json'):
    add(surface/name,'qualification/'+name)
for p in surface.glob('calibration-*.html'):add(p,'qualification/'+p.name)

run_ids=['BTH-ENVART-PAWNWEB-inputs-01','BTH-ENVART-PAWNWEB-inputs-02','BTH-ENVART-PAWNWEB-inputs-03',
 'BTH-ENVART-PAWNWEB-masks-01','BTH-ENVART-PAWNWEB-selfcheck-01','BTH-ENVART-PAWNWEB-selfcheck-02',
 'BTH-ENVART-PAWNWEB-repro-scan-01','BTH-ENVART-PAWNWEB-preparation-seal-01','BTH-ENVART-PAWNWEB-archive-verify-01',
 'BTH-ENVART-PAWNWEB-qualification-plan-01','BTH-ENVART-PAWNWEB-artifact-commit-01','BTH-ENVART-PAWNWEB-artifact-verify-01']
jobs={}
for run in run_ids:
    e=ROOT/'runs'/run/'evidence';j=json.loads((e/'job.json').read_bytes())
    assert j['exit_code']==(1 if run.endswith('inputs-01') else 0) and j['active_at_release']==0
    assert not j['timed_out'] and not j['error'] and not j['cleanup_errors'] and j['assigned_before_execution']
    assert j['limits']['cpu_rate']==1200 and j['limits']['job_memory_limit_bytes']==2*1024**3
    jobs[run]={'exit_code':j['exit_code'],'active_at_release':0,'cleanup_errors':[],
       'natural_termination':not j['timed_out'] and not j['error'],'resources':j['resource_measurements'],'receipt_sha256':H((e/'job.json').read_bytes())}
    for p in e.iterdir():
        if p.is_file() and p.suffix.lower() in ('.json','.log','.html'):
            add(p,'evidence/'+run+'/'+p.name)

for p in (E/'immutable-source').rglob('*'):
    if p.is_file():add(p,'immutable-source/'+p.relative_to(E/'immutable-source').as_posix())
add(Path(a['native_pass_report']),'native-final-pass.json')

# The outward input manifest names the outward metadata copies it contains.
# Original byte hashes are retained so this is not claimed as original metadata.
idx=json.loads(files['input-manifest.json'])
for name,row in idx['files'].items():
    if name in files and H(files[name])!=row['sha256']:
        row['original_sha256']=row['sha256'];row['original_bytes']=row['bytes'];row['sha256']=H(files[name]);row['bytes']=len(files[name]);row['metadata_only_sanitized']=True
old=files['input-manifest.json'];files['input-manifest.json']=json.dumps(idx,indent=2).encode()
if old!=files['input-manifest.json']:redactions.append({'file':'input-manifest.json','kind':'reference_copy_hash_reconciliation','original_sha256':H(old),'copy_sha256':H(files['input-manifest.json'])})

raw_images={name:{'sha256':H(b),'bytes':len(b)} for name,b in files.items() if name.endswith('.png')}
files['raw-source-and-mask-image-sha256.json']=json.dumps(raw_images,indent=2).encode()
files['raw-browser-frame-sha256.json']=json.dumps({'status':'NO_BROWSER_GAME_FRAMES_CAPTURED','files':{}},indent=2).encode()
surface_receipt=json.loads((surface/'owned-job-receipt.json').read_bytes())
assert surface_receipt['active_at_release']==0 and not surface_receipt['cleanup_errors']
report.update({'verified_source_report_sha256':H(source_report.read_bytes()),'verified_source_report_path':str(source_report),
 'completed_worker_jobs':jobs,'qualification_resource_receipt':{
    'sha256':H((surface/'owned-job-receipt.json').read_bytes()),'natural_exit':surface_receipt['natural_exit'],
    'forced_owned_termination':surface_receipt['forced_owned_termination'],'active_at_release':0,
    'peak_job_memory_bytes':surface_receipt['peak_job_memory_bytes'],'cleanup_errors':[]},
 'metadata_copy_changes':redactions,'byte_unchanged_code_files':code_count,'byte_unchanged_PNG_inputs_and_masks':pixel_count,
 'native_source_archive_exact_sha256':'f3642463d98c0200a332d0b6a2bfee3f832f861b8235126510544afc9bf1e867',
 'outward_qualification_scope':'Only owned nonce/window failure facts, authored calibration and capped closure/storage receipts. No CUA inventory, real-profile windows/tabs, clipboard or profile records.',
 'archive_scope':'Executable verification/analyzer/guard sources, exact selected immutable source/config/art, native full QA source, union/source-paint/masks, all relevant commands/receipts/diagnostics. Served PCKs/engine binaries and full 1.147 GB Git source tar are hash-bound and redownloadable from the exact immutable source; not duplicated in this source ZIP.',
 'current_seal_job_receipt':'job.json adjacent to the final report, finalized after this worker exits'})
files['partial-artifact-report.json']=json.dumps(report,indent=2).encode()
fileindex={name:{'sha256':H(b),'bytes':len(b)} for name,b in files.items()}
files['archive-file-sha256.json']=json.dumps(fileindex,indent=2).encode()
for name,b in files.items():
    if Path(name).suffix.lower() in ('.json','.md','.log','.txt'):
        text=b.decode('utf8');assert not attachments.search(text) and not routing.search(text),name
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            for n in z.namelist():
                if n.endswith(('.json','.md','.txt')):
                    text=z.read(n).decode('utf8',errors='ignore');assert not attachments.search(text) and not routing.search(text),name+'!'+n
bundle=OUT/'pawn-r2-partial-web-proof-source.zip'
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,b in files.items():z.writestr(name,b)
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    for name,v in fileindex.items():assert H(z.read(name))==v['sha256']
report['source_archive']={'path':str(bundle),'sha256':H(bundle.read_bytes()),'bytes':bundle.stat().st_size,'files':len(files),'indexed_files':len(fileindex)}
final=OUT/'pawn-r2-partial-web-proof.json';final.write_text(json.dumps(report,indent=2))
(OUT/'archive-file-sha256.json').write_text(json.dumps(fileindex,indent=2))
(OUT/'raw-source-and-mask-image-sha256.json').write_text(json.dumps(raw_images,indent=2))
(OUT/'raw-browser-frame-sha256.json').write_bytes(files['raw-browser-frame-sha256.json'])
print(json.dumps({'status':report['status'],'report':str(final),'report_sha256':H(final.read_bytes()),'archive':report['source_archive'],
 'unchanged_code_files':code_count,'unchanged_PNGs':pixel_count,'metadata_copy_changes':len(redactions),'actual_game_frames':0}))
