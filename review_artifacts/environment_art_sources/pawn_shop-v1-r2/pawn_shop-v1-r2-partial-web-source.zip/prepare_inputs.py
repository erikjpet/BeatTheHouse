"""Freeze verified read-only Pawn sources and original Bar methodology. No game/network."""
import sys, os, json, hashlib, shutil
sys.dont_write_bytecode = True
from pathlib import Path
WORK = Path(__file__).parent
OUT = Path(os.environ['BTH_QA_EVIDENCE_DIR'])
ROOT = Path('E:/CodexQA/BTH')
PACKAGE_SHA = '85a22382e63379b340c21121e4d78ad6d82abea17efb8a20ad876afb01cb80a3'

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''): h.update(b)
    return h.hexdigest()

copied = {}
def copy(src, dest, expected=None):
    src, dest = Path(src), Path(dest)
    digest = sha(src)
    if expected is not None: assert digest == expected, str(src)
    assert dest.resolve().is_relative_to(WORK.resolve())
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists(): assert sha(dest) == digest, str(dest)
    else: shutil.copyfile(src, dest)
    assert sha(dest) == digest
    copied[dest.relative_to(WORK).as_posix()] = {'source': str(src), 'sha256': digest, 'bytes': dest.stat().st_size}

src = ROOT/'workspaces/BTH-ENVART-AUDIT-20261114/packages/pawn_shop-v1-r2'
seal = json.loads((src/'package-seal.json').read_bytes())
assert seal['package_sha256'] == PACKAGE_SHA and len(seal['files']) == 19
assert hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(seal['files'].items())).encode()).hexdigest() == PACKAGE_SHA
for name, row in seal['files'].items(): copy(src/name, WORK/'inputs/pawn_shop-v1-r2'/name, row['sha256'])
copy(src/'package-seal.json', WORK/'inputs/pawn_shop-v1-r2/package-seal.json')
copy(ROOT/'runs/BTH-ENVART-PAWN-20261114-union-01/evidence/pawn_preart_union.json', WORK/'inputs/pawn_preart_union.json', '9ade78efe6ed2e596c7c7911f8d5b76f9906f2148bcacbe0a0810f80049a46d2')
native = ROOT/'runs/BTH-ENVART-PAWNTRIAL-20261114-r2-final-summary-01/evidence'
copy(native/'pawn_r2_native_summary.json', WORK/'inputs/native/pawn_r2_native_summary.json', '6bc9f0951bdf57d552d7574415eafec4199f59853bbed2bab1179cfe60217c57')
copy(native/'qa-source-archive.zip', WORK/'inputs/native/pawn-r2-native-qa-source.zip', 'f3642463d98c0200a332d0b6a2bfee3f832f861b8235126510544afc9bf1e867')
images = json.loads((native/'image-manifest.json').read_bytes())
reports = json.loads((native/'report-manifest.json').read_bytes())
paint = ROOT/'runs/BTH-ENVART-PAWNTRIAL-20261114-r2-source-paint-01/evidence'
painter = paint/'pawn_glint_source_paint.json'
expected = reports[str(painter)]; expected = expected if isinstance(expected, str) else expected['sha256']
copy(painter, WORK/'inputs/source-paint'/painter.name, expected)
paint_data = json.loads(painter.read_bytes())
assert not paint_data['findings'] and len(paint_data['contexts']) == 4
for c in paint_data['contexts']:
    assert c['geometry_equal']
    for item in c['objects']:
        for key in ('body_png','adorn_png'):
            path = paint/item[key]; record = images[str(path)]
            expected = record if isinstance(record,str) else record['sha256']
            copy(path, WORK/'inputs/source-paint'/path.name, expected)
bar = ROOT/'workspaces/BTH-ENVART-BAR-WEB-20261114'
copy(ROOT/'runs/BTH-ENVART-BARWEB-final-summary-02/evidence/bar-r4-served-web-qa.json', WORK/'reference-bar/bar-r4-served-web-qa.json', '02b4c2ed15fd345688857e5f94db933be75ceb8abfd3802e157b062604e2b1c3')
copy(Path('D:/Projects/Beat-The-House/.tmp/environment-art-layers/review_artifacts/environment_art_sources/bar-v1-r4/bar-v1-r4-web-proof-source.zip'), WORK/'reference-bar/bar-r4-web-proof-source.zip', '5b517aed9348a6e4734e98b4c15b01a85bf2c68c315ef6958d5d1c038a09b49e')
for name in ('analyze_back_composite.py','analyze_bar.py','analyze_corner_retention.py','analyze_gas_retention.py','analyze_motel.py','fit_bar_floor_tracks.py','README-PROOF.md','bar_probe.cjs','bar_supervisor.py','verify_served_bar.py'):
    copy(bar/name, WORK/'reference-bar'/name)
assert not (WORK/'approved-target.json').exists()
result = {'status':'PREPARATION_INPUTS_FROZEN_NO_GAME_OR_BROWSER','package_sha256':PACKAGE_SHA,'files':copied,'scope':'Source/painter files are immutable copies. Historical Bar browser sources are reference only, not authority to run standalone automation.'}
(WORK/'input-manifest.json').write_text(json.dumps(result,indent=2))
(OUT/'input-copy-receipt.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'status':result['status'],'files':len(copied),'package_sha256':PACKAGE_SHA}))
