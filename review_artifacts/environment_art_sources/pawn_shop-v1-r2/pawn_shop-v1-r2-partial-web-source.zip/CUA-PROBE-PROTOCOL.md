# Pending actual served TEST capture

This is a preparation protocol, not a completed probe or a launch authorization.
There is deliberately no browser launcher here while the exact-source gate and
native CUA capture/ownership/viewport qualifications remain unresolved.

The current associated Browser skill prohibits standalone Playwright/CDP browser
control. The Bar CJS and supervisor in reference-bar are unchanged historical
methodology only. Do not run them or import their browser automation.

After exact independent native PASS, finalized commit/tree/file hashes,
publication and explicit browser GO, qualify a NEW owned headed Chromium process
with a fresh E profile/cache/temp and its own assigned-before-resume 12% CPU,
2 GiB kill-on-close Job. No real user profile, migration, shared browser session,
security bypass, global process census or unrelated termination is authorized.

Documented native CUA APIs available in this worker:

- cua.listWindows() lists windowId/app/title; these IDs are opaque.
- cua.getApp({windowId: observedId}) selects an exact existing window.
- app.getScreenshot() returns PNG bytes, or region objects with bytes and region
  dimensions; it displays screenshots automatically.
- app.getAXState() reads the selected window's current accessibility state.
- app.click(), app.pressKey(), app.typeText(), and app.setValue() perform UI
  actions using current observed state. Screenshot coordinates need a fresh
  screenshot; use a region's returned screenshotId when multiple regions exist.

Do not infer that the opaque ID equals an HWND, invent a PID method, import a
hidden screenshot helper, or substitute a shell/OS screenshot. No documented
CUA file writer, durable screenshot artifact ID, exact game-client viewport API,
or PID-to-Job verifier has been established. Returned image bytes could be
serialized for a separate artifact transfer, but that transfer has not been
qualified, and bulk serialization must not be represented as completed capture.

When those gaps are resolved, record every CUA action and subsequent observation
in an immutable command/observation log. Use observed coordinates only. Navigate
the canonical TEST root, inspect the effective immutable location and visible
footer, then use the actual Environment Library with LAYOUT-SURVEY-QA. No model,
scenario, clock, animation-speed or alpha injection, and no browser-code evaluate.

Priority capture order is Base, Estate Lot Day, Serial-Check Day, Sal's Mood,
each at actual measured 1280x720 and 1920x1080 client size. Deliver first actual
views promptly. Capture autonomous no-input motion, most clearly exposed Estate
tray high/low samples, meaningful scan outside painted cast/name masks, supported
Base/Estate Reduce Motion and restoration, selection/tooltip/return framing,
and prior-five-room Base retention. Never activate buy/sell or scenario actions.

For each admitted raw capture folder, retain originals in frames/ and write:

- motion.json: source=actual_served_test_cua, label, scenario, duration_ms,
  input_during_capture=false, frames[{index,file,elapsed_ms,sha256}].
- board-geometry.json: x, y, scale, screenshot_size, measured_from_actual_screenshot=true,
  plus the original observation supporting the transform and actual client size.
- the exact frame-transfer receipt proving these PNGs are original CUA bytes.

These are output schemas, not permission to manufacture observations. The
analyzer checks source and hashes, maps immutable masks, and preserves composite
attribution limits. Full frames are never retouched or sharpened.

Close the owned browser through supported UI and record natural/forced closure,
zero active Job members, resources and peak Job memory. Only then run the
streamed served-byte verifier in a separate bounded worker. A manifest-only
HTTP read proves configuration, not a runtime IndexedDB or save/revisit result.
