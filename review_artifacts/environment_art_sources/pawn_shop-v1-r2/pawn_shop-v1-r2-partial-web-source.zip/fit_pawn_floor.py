"""Memory-bounded known-speed support fit; corroboration, never isolated PASS."""
import sys,os,json,math
sys.dont_write_bytecode=True
from pathlib import Path
import numpy as np
from PIL import Image
W=Path(__file__).parent; OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR']); E=Path(sys.argv[1]).resolve(strict=True)
assert E.is_relative_to(Path('E:/CodexQA/BTH/runs').resolve())
motion=json.loads((E/'motion.json').read_bytes()); g=json.loads((E/'board-geometry.json').read_bytes())
assert motion['source']=='actual_served_test_cua' and motion['input_during_capture'] is False and g['measured_from_actual_screenshot'] is True
ox,oy,s=float(g['x']),float(g['y']),float(g['scale']); assert s>0
manifest=json.loads((W/'inputs/pawn_shop-v1-r2/data/art/environments/pawn_shop.json').read_bytes())
entries=[e for e in manifest['animations'] if e['type']=='mover']; assert len(entries)==7
times=[(f['elapsed_ms']-motion['frames'][0]['elapsed_ms'])/1000 for f in motion['frames']]
assert all(b>a for a,b in zip(times,times[1:]))
lanes={}
for y in sorted({e['from'][1] for e in entries}):
    b=(math.floor(ox),math.floor(oy+y*s),math.ceil(ox+900*s),math.ceil(oy+(y+2)*s))
    base=None
    for f in motion['frames']:
        with Image.open(E/'frames'/f['file']) as im:
            pix=np.asarray(im.convert('RGB').crop(b),dtype=np.uint8)
            base=pix.copy() if base is None else np.minimum(base,pix)
    rows=[]
    for f in motion['frames']:
        with Image.open(E/'frames'/f['file']) as im:
            pix=np.asarray(im.convert('RGB').crop(b),dtype=np.int16)
            delta=np.max(np.abs(pix-base.astype(np.int16)),axis=2)
            # High-amplitude changing actors are excluded; untouched raw frames are retained.
            values=np.max(np.where(delta<=15,delta,0),axis=0)
            # The opaque main front covers the first three authored lanes.
            if 262<=y<304:
                values[max(0,math.floor(316*s)):min(len(values),math.ceil(584*s))]=0
            rows.append(np.concatenate(([0],np.cumsum(values))).tolist())
    lanes[y]=rows
results=[]
for entry in entries:
    y=entry['from'][1]; width=entry['size'][0]*s; wrap=(entry['to'][0]-entry['from'][0])*s
    speed=wrap/entry['duration']; lead=entry['from'][0]*s
    def fit(v):
        best={'score':-1,'x_phase':None,'support_samples':[]}
        for x0 in range(0,math.ceil(wrap),3):
            total=0; visible=0; support=[]
            for k,(t,p) in enumerate(zip(times,lanes[y])):
                left=lead+(x0+v*t)%wrap; right=left+width; lo=max(0,round(left)); hi=min(len(p)-1,round(right))
                if hi-lo<width*.7: continue
                mean=(p[hi]-p[lo])/(hi-lo); total+=mean; visible+=1
                if k%15==0: support.append({'frame':k,'elapsed_s':t,'predicted_x':round(left,3),'mean_raw_delta':mean})
            score=total/visible if visible>len(times)*.65 else -1
            if score>best['score']: best={'score':score,'x_phase':x0,'support_samples':support}
        return {'speed_screenshot_px_per_s':v,**best}
    candidates=[fit(speed+d*.5) for d in range(-6,7)]
    results.append({'id':entry['id'],'authored_board_speed':speed/s,'authored_duration':entry['duration'],
       'authored_phase':entry['phase'],'exact_expected_fit':candidates[6],
       'best_observed_fit':max(candidates,key=lambda v:v['score'])})
report={'status':'CORROBORATIVE_FLOOR_SUPPORT_NOT_PER_ENTRY_PASS','source':str(E),'geometry':g,'duration_ms':motion['duration_ms'],'results':results,
 'limits':['Seven movers share four lanes. Fits use independently authored speeds; overlapping movers and live objects can bias results.',
  'Positive raw delta 1..15 separates subtle floor support from high-amplitude changes, without changing any original screenshot.',
  'Capture duration and actual wrap visibility must be reported. Native isolated speed/wrap proof remains separate.']}
(OUT/'pawn-floor-support-fits.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':report['status'],'entries':len(results),'duration_ms':motion['duration_ms']}))
