"""Independent normal-TLS artifact verification. No browser, UI, or runtime DB."""
import sys,os,json,hashlib,urllib.request,mmap,re,tarfile
sys.dont_write_bytecode=True
from pathlib import Path,PurePosixPath
from contextlib import ExitStack
W=Path(__file__).parent; OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
sys.path.insert(0,str(W/'repro-helpers'))
import audit_pck_manifest
from artifact_target_gate import admitted_artifacts
from target_gate import digest,admitted_target,RETAINED,TEST_MOUNT

def require(value,message):
    if not value: raise AssertionError(message)

def get(url):
    with urllib.request.urlopen(url,timeout=45) as response:
        require(response.status==200,url); return response.read()

def fetch_files(base,manifest,prefix):
    rows={}; html=None
    for name,v in manifest['files'].items():
        require(name==Path(name).name and '/' not in name and '\\' not in name,'Unsafe filename')
        sha=hashlib.sha256();count=0;parts=[]
        target=(OUT/(prefix+'-index.pck')).open('xb') if name=='index.pck' else None
        try:
            with urllib.request.urlopen(base+name,timeout=45) as response:
                require(response.status==200,name)
                for block in iter(lambda:response.read(1048576),b''):
                    sha.update(block);count+=len(block)
                    if target: target.write(block)
                    if name=='index.html': parts.append(block)
        finally:
            if target: target.close()
        require(count==v['bytes'] and sha.hexdigest()==v['sha256'],'Served mismatch: '+name)
        rows[name]={'bytes':count,'sha256':sha.hexdigest(),'http_status':200}
        if name=='index.html':
            html=b''.join(parts); (OUT/(prefix+'-index.html')).write_bytes(html)
    return rows,html

def directory(pck):
    d=audit_pck_manifest.parse_directory(pck,0)
    require(d is not None and not audit_pck_manifest.audit(d['entries']),'PCK directory audit')
    require(audit_pck_manifest.u32(pck,20)&~2==0,'Unexpected pack flags')
    entries={e['path']:e for e in d['entries']};require(len(entries)==len(d['entries']),'Duplicate PCK entry')
    for name,e in entries.items():
        p=PurePosixPath(name)
        require(not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix()==name,'Unsafe PCK entry')
        require(e['flags']==0,'PCK entry flags')
        start=d['file_base']+e['offset'];require(start>=112 and start+e['bytes']<=len(pck),'PCK entry range')
    return d,entries

def bounds(d,e):
    start=d['file_base']+e['offset'];return start,start+e['bytes']

def payload_hash(pck,d,e):
    start,end=bounds(d,e);sha=hashlib.sha256();md5=hashlib.md5()
    for at in range(start,end,1048576):
        block=pck[at:min(at+1048576,end)];sha.update(block);md5.update(block)
    require(md5.hexdigest()==e['md5'],'PCK directory MD5 mismatch')
    return sha.hexdigest()

def main():
    a,stage,manifest,gate=admitted_artifacts(W)
    commit=a['source_commit'];base=a['canonical_url'];immutable=base+commit+'/'
    commit_e=Path('E:/CodexQA/BTH/runs/BTH-ENVART-PAWNWEB-artifact-commit-01/evidence')
    git_text=(commit_e/'worker.log').read_text()
    require(git_text.splitlines()[0]=='tree '+a['source_tree'],'Exact Git source tree')
    git_job=json.loads((commit_e/'job.json').read_bytes())
    require(git_job['exit_code']==0 and git_job['active_at_release']==0,'Git inspection Job closure')
    current=get(base+'current').decode().strip();require(current==commit,'Current pointer')
    launcher=get(base);require(b'BTH_ART_TEST_MANAGED_LAUNCHER_V1' in launcher,'Canonical managed launcher marker')
    (OUT/'canonical-launcher.html').write_bytes(launcher)
    raw=get(immutable+'build_manifest.json');require(hashlib.sha256(raw).hexdigest()==a['manifest_sha256'],'Served root manifest')
    require(raw==(stage/'build_manifest.json').read_bytes(),'Stage/served root manifest equality')
    (OUT/'served-build-manifest.json').write_bytes(raw)
    served,html=fetch_files(immutable,manifest,'served')
    match=re.search(rb'const GODOT_CONFIG\s*=\s*(\{.*?\});',html,re.S);require(match is not None,'Served GODOT_CONFIG')
    config=json.loads(match.group(1))
    require(config['args']==['--','--bth-art-test'] and config['persistentPaths']==[TEST_MOUNT],'Served TEST args/mount config')
    (OUT/'served-godot-config.json').write_text(json.dumps(config,indent=2))
    old_commit=a['prior_source_commit'];oldbase=base+old_commit+'/'
    old_raw=get(oldbase+'build_manifest.json');require(hashlib.sha256(old_raw).hexdigest()==a['prior_manifest_sha256'],'Prior immutable manifest')
    prior=json.loads(old_raw);require(prior['source_commit']==old_commit,'Prior identity')
    (OUT/'prior-build-manifest.json').write_bytes(old_raw)
    old_files,_=fetch_files(oldbase,prior,'prior')
    require(old_files['index.pck']['sha256']==a['prior_pck_sha256'],'Prior immutable PCK')
    with ExitStack() as stack:
        file=stack.enter_context((OUT/'served-index.pck').open('rb'));pck=stack.enter_context(mmap.mmap(file.fileno(),0,access=mmap.ACCESS_READ))
        old_file=stack.enter_context((OUT/'prior-index.pck').open('rb'));old_pck=stack.enter_context(mmap.mmap(old_file.fileno(),0,access=mmap.ACCESS_READ))
        d,entries=directory(pck);od,old_entries=directory(old_pck)
        be=entries['build_manifest.json'];start,end=bounds(d,be);embedded=pck[start:end];em=json.loads(embedded)
        require(hashlib.sha256(embedded).hexdigest()==a['embedded_manifest_sha256'],'Embedded SHA')
        require(hashlib.md5(embedded).hexdigest()==be['md5']==a['embedded_manifest_md5'],'Embedded MD5')
        for key in ('source_commit','source_tree','art_package_sha256','build_version'):
            require(em[key]==manifest[key],'Embedded/root '+key)
        (OUT/'served-embedded-manifest.json').write_bytes(embedded)
        compiled={name:payload_hash(pck,d,entries[name]) for name in manifest['compiled_art_sha256']}
        require(compiled==manifest['compiled_art_sha256'] and len(compiled)==94,'Actual compiled art hashes/count')
        for name,expected in manifest['art_source_files'].items():
            if not name.endswith('.png'): require(payload_hash(pck,d,entries[name])==expected,'Actual non-PNG source '+name)
        en=entries['data/art/environments/index.json'];start,end=bounds(d,en);enabled=json.loads(pck[start:end])['enabled']
        require(enabled==list(RETAINED)+['pawn_shop'],'Exact six enabled native-passed rooms')
        prior_compiled=prior['compiled_art_sha256'];require(len(prior_compiled)==77,'Prior compiled count')
        require(all(compiled.get(n)==v for n,v in prior_compiled.items()),'Prior compiled hashes retained')
        added=sorted(set(entries)-set(old_entries));removed=sorted(set(old_entries)-set(entries));changed=[];unchanged=0;equal_bytes=0
        for name in sorted(set(entries)&set(old_entries)):
            e,o=entries[name],old_entries[name]
            same=e['bytes']==o['bytes'] and e['flags']==o['flags']
            if same:
                start,end=bounds(d,e);old_start,_=bounds(od,o)
                for offset in range(0,e['bytes'],1048576):
                    count=min(1048576,e['bytes']-offset)
                    if pck[start+offset:start+offset+count]!=old_pck[old_start+offset:old_start+offset+count]:same=False;break
            if same:unchanged+=1;equal_bytes+=e['bytes']
            else:changed.append(name)
        require(len(entries)==1507 and len(added)==35 and not removed and unchanged==1469,'Prior PCK retention counts')
        require(set(changed)=={'.godot/uid_cache.bin','data/art/environments/index.json','build_manifest.json'},'Unexpected prior entry changes: '+str(changed))
        equivalence={'prior_entries':len(old_entries),'current_entries':len(entries),'identical_existing_entries':unchanged,
           'directly_compared_identical_bytes':equal_bytes,'changed_existing_entries':changed,'added_entries':added,'removed_entries':removed,
           'prior_compiled_textures_identical':len(prior_compiled),'current_compiled_textures':len(compiled)}
        (OUT/'pck-byte-equivalence.json').write_text(json.dumps(equivalence,indent=2))
    # Exact source archive is streamed, not loaded into memory. Extract only
    # verifier-relevant art/persistence/config/source metadata, never profiles.
    archive=stage.parent/'source.tar';require(digest(archive)==manifest['source_archive_sha256'],'Immutable source archive SHA')
    source_dir=OUT/'immutable-source';source_dir.mkdir()
    extra={'scripts/core/persistence_paths.gd','scripts/core/art_contracts.gd','project.godot','export_presets.cfg','AGENTS.md','docs/art/pawn_shop_v1_r2_provenance.json'}
    wanted=set(manifest['art_source_files'])|extra; extracted={};members=0;comment=None
    with tarfile.open(archive,'r|*') as tar:
        for member in tar:
            members+=1;p=PurePosixPath(member.name)
            require(not p.is_absolute() and '..' not in p.parts and '\\' not in member.name and (member.isfile() or member.isdir()),'Unsafe source archive member')
            comment=tar.pax_headers.get('comment',comment)
            if member.isfile() and member.name in wanted:
                target=source_dir/member.name;target.parent.mkdir(parents=True,exist_ok=True)
                sha=hashlib.sha256()
                with tar.extractfile(member) as src,target.open('xb') as dst:
                    for block in iter(lambda:src.read(1048576),b''):sha.update(block);dst.write(block)
                extracted[member.name]=sha.hexdigest()
    require(comment==commit,'Git archive commit binding')
    require(all(extracted.get(n)==v for n,v in manifest['art_source_files'].items()),'101 raw art-source hashes')
    require(len(manifest['art_source_files'])==101,'Raw art count')
    require(extracted['scripts/core/persistence_paths.gd']==manifest['persistence_core_sha256'],'Exact persistence source SHA')
    seal=json.loads((W/'inputs/pawn_shop-v1-r2/package-seal.json').read_bytes())
    require(all(extracted.get(n)==v['sha256'] for n,v in seal['files'].items()),'19 exact Pawn payload source hashes')
    source_record={'archive_sha256':manifest['source_archive_sha256'],'archive_bytes':archive.stat().st_size,'git_archive_comment':comment,
      'source_commit':commit,'source_tree':a['source_tree'],'members_scanned':members,'extracted':extracted,'raw_art_verified':101,'exact_pawn_payloads_verified':19,
      'persistence_source_sha256':extracted['scripts/core/persistence_paths.gd'],'git_commit_inspection_job':str(commit_e/'job.json')}
    (OUT/'immutable-source-proof.json').write_text(json.dumps(source_record,indent=2))
    protected_path=Path('E:/CodexQA/BTH/runs/BTH-ENVART-INTEGRATION-20261114-test-promotion-01/evidence/protected_before.json')
    before=json.loads(protected_path.read_text(encoding='utf-8-sig'));site=Path('D:/Projects/site')
    after={name:digest(site/name) for name in before};require(after==before,'Protected site/audience/NEXT source bytes')
    next_pointer=get('https://192.168.0.36:8443/p/beat-the-house/play/dev/current').decode().strip()
    require(next_pointer=='e5152c34bfe146600214fb206ec80a5e3e8a27cb','NEXT pointer')
    next_raw=get('https://192.168.0.36:8443/p/beat-the-house/play/dev/'+next_pointer+'/build_manifest.json')
    require(hashlib.sha256(next_raw).hexdigest()==before['projects/beat-the-house/public/play/dev/'+next_pointer+'/build_manifest.json'],'Served NEXT manifest')
    (OUT/'protected-lane-byte-proof.json').write_text(json.dumps({'baseline_sha256':digest(protected_path),'before':before,'after':after,'next_pointer':next_pointer,'served_next_manifest_sha256':hashlib.sha256(next_raw).hexdigest()},indent=2))
    _,_,_,final_gate=admitted_artifacts(W)
    report={'status':'PARTIAL_ARTIFACT_PASS_LIVE_WEB_NOT_RUN','source_commit':commit,'source_tree':a['source_tree'],
      'package_sha256':a['package_sha256'],'native_pass_report_sha256':a['native_pass_report_sha256'],'canonical_url':base,'immutable_url':a['immutable_url'],
      'current_pointer':current,'managed_launcher_marker':True,'normal_TLS_validation_no_bypass':True,'stream_block_bytes':1048576,
      'served_manifest_sha256':a['manifest_sha256'],'served_html_sha256':a['html_sha256'],'served_pck_sha256':a['pck_sha256'],
      'served_embedded_manifest_sha256':a['embedded_manifest_sha256'],'served_embedded_manifest_md5':a['embedded_manifest_md5'],
      'served_files_plus_root_manifest':len(served)+1,'served_files':served,'served_config':config,'active_art_packages':manifest['active_art_packages'],
      'raw_art_sources_verified':101,'actual_compiled_art_verified':94,'pck_entries':1507,'enabled_rooms':enabled,
      'prior_immutable':{'source_commit':old_commit,'manifest_sha256':a['prior_manifest_sha256'],'pck_sha256':a['prior_pck_sha256'],
          'served_files_plus_root_manifest':len(old_files)+1,'served_files':old_files},'prior_pck_byte_retention':equivalence,
      'source_archive_sha256':manifest['source_archive_sha256'],'source_commit_tree_read_from_git':True,
      'protected_site_file_count':len(before),'protected_site_bytes_unchanged':True,'next_pointer':next_pointer,'artifact_gate':gate,'final_gate':final_gate,
      'browser_qualification':{'status':'BLOCKED_CUA_WINDOW_OWNERSHIP_BINDING','selected_real_profiles':False,'UI_inputs_sent':False,
       'owned_qualification_receipt_sha256':a['closed_qualification_receipt_sha256'],'owned_job_closed':True},
      'NOT_RUN':['Actual browser canonical redirect/visible footer','Actual 1280/1920 game client sizes','Live four-scenario UI/cast/name framing',
       'Live motion/scan/static alignment/tray extrema','Supported UI Reduce Motion/restoration','Selection/tooltip/return framing',
       'Previous-five-room live composite retention','Runtime IndexedDB access or mounted-path observation','Save/revisit E2E'],
      'limits':['Artifact identity/configuration/source/PCK facts are not runtime UI or IndexedDB observations.',
       'No browser/game attempt or alternative automation was performed for this artifact-only verification.',
       'Prior-room byte retention does not prove live motion or outcome E2E. Native artwork acceptance remains separately scoped.',
       'Main Git branch preservation is not inferred from the read-only NEXT pointer/manifest and protected site-byte checks.']}
    (OUT/'pawn-r2-partial-served-artifact-report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:report[k] for k in ('status','source_commit','source_tree','served_files_plus_root_manifest','raw_art_sources_verified','actual_compiled_art_verified','pck_entries','protected_site_file_count','next_pointer')}))

if __name__=='__main__':main()
