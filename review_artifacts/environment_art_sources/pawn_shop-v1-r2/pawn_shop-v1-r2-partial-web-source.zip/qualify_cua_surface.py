"""Explicitly authorized small native-CUA calibration only; never game admission."""
import sys,os,json,time,threading,secrets,hashlib
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).parent; sys.path.insert(0,str(W/'repro-helpers'))
from bth_qa_storage import plan_layout,prepare_layout,validate_layout,child_environment,check_launch
from cpu_job import CpuCappedJob,_base
from native_proof_worker import SuspendedWorker
assert not (W/'approved-target.json').exists(),'Game admission must stay absent during surface qualification'
run_id=sys.argv[1]
assert run_id.startswith('BTH-ENVART-PAWNWEB-surface-')
layout=prepare_layout(plan_layout('E:/CodexQA/BTH',W,run_id))
nonce=secrets.token_hex(8)
calibration=layout.evidence/('calibration-'+nonce+'.html')
validate_layout(layout)
calibration.write_text((W/'calibration-template.html').read_text().replace('__NONCE__',nonce),encoding='utf8')
env=child_environment(layout,os.environ)
command=[r'C:\Users\theep\AppData\Local\ms-playwright\chromium-1243\chrome-win64\chrome.exe',
 '--user-data-dir='+str(layout.profile),'--disk-cache-dir='+str(layout.cache),'--no-first-run','--no-default-browser-check',
 '--new-window','--window-size=1280,720',calibration.as_uri()]
receipt={'kind':'browser-surface-qualification','status':'STARTING','game_allowed':False,'nonce':nonce,
 'calibration':str(calibration),'calibration_sha256':hashlib.sha256(calibration.read_bytes()).hexdigest(),
 'allowed_content':['authored local calibration','chrome://version','locally encoded captured PNG data URL'],
 'command':command,'storage_manifest':str(layout.manifest_path),'cleanup_errors':[],
 'profile':str(layout.profile),'temp':str(layout.temp),'cache':str(layout.cache),
 'gate_before_job':check_launch(layout,W,env),'resource_samples':[]}
job=worker=thread=None;started=time.monotonic()
try:
 job=CpuCappedJob(1200,2*1024**3);receipt['limits']=job.verify();receipt['owner_membership']=job.owner_membership()
 receipt['gate_before_child']=check_launch(layout,W,env)
 worker=SuspendedWorker(job,command,cwd=str(W),env=env);worker.stdin.close()
 receipt['pid']=worker.pid;receipt['assigned_before_resume']=job.contains(worker._handle) and not worker.resumed
 assert receipt['assigned_before_resume']
 def drain():
  with (layout.evidence/'browser-stdout.log').open('x',encoding='utf8') as f:
   for line in worker.stdout:f.write(line);f.flush()
 thread=threading.Thread(target=drain,daemon=True);thread.start();worker.resume()
 receipt['status']='READY_CALIBRATION_ONLY';validate_layout(layout)
 (layout.evidence/'qualification-ready.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps({'status':receipt['status'],'nonce_title':'BTH PAWN QA '+nonce,'pid':worker.pid,'profile':str(layout.profile),
   'evidence':str(layout.evidence),'stop_file':str(layout.evidence/'stop-request.json')}),flush=True)
 while worker.poll() is None and time.monotonic()-started<600:
  if (layout.evidence/'stop-request.json').exists():receipt['stop_requested']=True;break
  if not receipt['resource_samples'] or time.monotonic()-receipt['resource_samples'][-1]['elapsed_s']-started>15:
   lim=job.query(9,_base.Limits());receipt['resource_samples'].append({'elapsed_s':time.monotonic()-started,
     'peak_job_memory_bytes':lim.peakJobMemory,'cpu_seconds':job.cpu_seconds(),'active_owned_processes':job.active()})
  time.sleep(.2)
 receipt['deadline_reached']=time.monotonic()-started>=600
except BaseException as exc:
 receipt['error']=str(exc);raise
finally:
 if job:
  try:
   receipt['natural_exit']=worker is not None and worker.poll() is not None
   receipt['forced_owned_termination']=worker is not None and worker.poll() is None
   if worker and worker.poll() is None:job.terminate();worker.wait(5)
   lim=job.query(9,_base.Limits());receipt['peak_job_memory_bytes']=lim.peakJobMemory;receipt['cpu_seconds']=job.cpu_seconds()
   job.drain(5);receipt['active_at_release']=job.active()
   if thread:thread.join(5)
   if worker:receipt['exit_code']=worker.poll();worker.close()
  except BaseException as exc:receipt['cleanup_errors'].append(str(exc))
  finally:job.close()
 receipt['status']='CLOSED_CALIBRATION_ONLY';receipt['elapsed_s']=time.monotonic()-started
 validate_layout(layout);(layout.evidence/'owned-job-receipt.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps({'status':receipt['status'],'natural_exit':receipt.get('natural_exit'),'forced_owned_termination':receipt.get('forced_owned_termination'),
   'active_at_release':receipt.get('active_at_release'),'peak_job_memory_bytes':receipt.get('peak_job_memory_bytes'),'cleanup_errors':receipt['cleanup_errors']}),flush=True)
