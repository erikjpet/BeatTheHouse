"""Normal-TLS streamed TEST identity, only after the owned browser has closed."""
import sys,os,json,hashlib,urllib.request,mmap,re
sys.dont_write_bytecode=True
from pathlib import Path,PurePosixPath
W=Path(__file__).parent; sys.path.insert(0,str(W/'repro-helpers'))
import audit_pck_manifest
from target_gate import admitted_target,RETAINED,PACKAGE_SHA,TEST_MOUNT,digest

def main():
    a,stage=admitted_target(W); out=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
    receipt=Path(sys.argv[1]).resolve(strict=True)
    assert receipt.is_relative_to(Path('E:/CodexQA/BTH/runs').resolve())
    closed=json.loads(receipt.read_bytes())
    assert closed['kind']=='browser' and closed['active_at_release']==0 and not closed['cleanup_errors']
    assert closed['source_commit']==a['source_commit'] and closed['assigned_before_resume'] is True
    assert closed['peak_job_memory_bytes']<=2*1024**3
    base=a['canonical_url']; commit=a['source_commit']
    def read(url):
        with urllib.request.urlopen(url,timeout=40) as r:
            assert r.status==200; return r.read()
    current=read(base+'current').decode().strip(); assert current==commit
    launcher=read(base); assert b'BTH_ART_TEST_MANAGED_LAUNCHER_V1' in launcher
    raw=read(base+commit+'/build_manifest.json'); assert hashlib.sha256(raw).hexdigest()==a['manifest_sha256']
    assert raw==(stage/'build_manifest.json').read_bytes(); m=json.loads(raw)
    records={}; html=None
    for name,expected in m['files'].items():
        if name!=Path(name).name or '/' in name or '\\' in name: raise ValueError('Unsafe served name')
        h=hashlib.sha256(); n=0; small=[]
        dest=(out/'served-index.pck').open('xb') if name=='index.pck' else None
        try:
            with urllib.request.urlopen(base+commit+'/'+name,timeout=40) as r:
                assert r.status==200
                for block in iter(lambda:r.read(1048576),b''):
                    h.update(block); n+=len(block)
                    if dest: dest.write(block)
                    if name=='index.html': small.append(block)
        finally:
            if dest: dest.close()
        assert n==expected['bytes'] and h.hexdigest()==expected['sha256'],name
        records[name]={'sha256':h.hexdigest(),'bytes':n,'status':200}
        if name=='index.html': html=b''.join(small).decode()
    cfgmatch=re.search(r'const GODOT_CONFIG\s*=\s*(\{.*?\});',html,re.S)
    assert cfgmatch,'Served GODOT_CONFIG not found'
    config=json.loads(cfgmatch.group(1)); assert config['args']==['--','--bth-art-test'] and config['persistentPaths']==[TEST_MOUNT]
    with (out/'served-index.pck').open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as pck:
        d=audit_pck_manifest.parse_directory(pck,0); assert d and not audit_pck_manifest.audit(d['entries'])
        assert audit_pck_manifest.u32(pck,20)&~2==0
        entries={e['path']:e for e in d['entries']}; assert len(entries)==len(d['entries'])
        for name,e in entries.items():
            p=PurePosixPath(name); assert not p.is_absolute() and '..' not in p.parts and '\\' not in name and p.as_posix()==name
            assert e['flags']==0
        def piece(name):
            e=entries[name]; start=d['file_base']+e['offset']; end=start+e['bytes']; assert start>=112 and end<=len(pck)
            return e,start,end
        e,start,end=piece('build_manifest.json'); assert e['bytes']<=1048576
        embedded=pck[start:end]; em=json.loads(embedded)
        assert hashlib.sha256(embedded).hexdigest()==m['embedded_manifest_sha256']
        assert hashlib.md5(embedded).hexdigest()==e['md5']==m['embedded_manifest_md5']
        for key in ('source_commit','source_tree','art_package_sha256','build_version'): assert em[key]==m[key],key
        (out/'served-embedded-manifest.json').write_bytes(embedded)
        compiled={}
        for name,expected in m['compiled_art_sha256'].items():
            e,start,end=piece(name); sha=hashlib.sha256(); md5=hashlib.md5()
            for pos in range(start,end,1048576):
                block=pck[pos:min(pos+1048576,end)]; sha.update(block); md5.update(block)
            assert sha.hexdigest()==expected and md5.hexdigest()==e['md5'],name
            compiled[name]=sha.hexdigest()
        for name,expected in m['art_source_files'].items():
            if name.endswith('.png'): continue
            e,start,end=piece(name); b=pck[start:end]
            assert hashlib.sha256(b).hexdigest()==expected and hashlib.md5(b).hexdigest()==e['md5'],name
        _,start,end=piece('data/art/environments/index.json'); enabled=json.loads(pck[start:end])['enabled']
        assert enabled==list(RETAINED)+['pawn_shop']
    next_pointer=read('https://192.168.0.36:8443/p/beat-the-house/play/dev/current').decode().strip()
    assert next_pointer=='e5152c34bfe146600214fb206ec80a5e3e8a27cb'
    report={'status':'PASS_SERVED_BYTES_EMBEDDED_IDENTITY_AND_COMPILED_ART','canonical_url':base,'immutable_url':a['immutable_url'],
      'source_commit':commit,'source_tree':m['source_tree'],'current':current,'manifest_sha256':hashlib.sha256(raw).hexdigest(),
      'active_art_packages':m['active_art_packages'],'files':records,'compiled_art_sha256':compiled,'enabled_rooms':enabled,
      'embedded_manifest_sha256':m['embedded_manifest_sha256'],'embedded_manifest_md5':m['embedded_manifest_md5'],
      'served_html_config':config,'next_pointer':next_pointer,'normal_tls_no_bypass':True,'streamed_block_bytes':1048576,
      'closed_browser_receipt':{'path':str(receipt),'sha256':digest(receipt),'natural_exit':closed.get('natural_exit'),'forced_owned_termination':closed.get('forced_owned_termination')},
      'limitations':['This proves served configuration, not an observed runtime mount/IndexedDB access trace.',
         'Visible footer/canonical navigation and actual UI artwork require separate CUA evidence.',
         'Main/source/audience preservation is verified separately by integrator. NEXT pointer check is not Git remote inspection.']}
    (out/'final-served-identity.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'status':report['status'],'source_commit':commit,'served_files':len(records),'compiled_textures':len(compiled)}))
if __name__=='__main__': main()
