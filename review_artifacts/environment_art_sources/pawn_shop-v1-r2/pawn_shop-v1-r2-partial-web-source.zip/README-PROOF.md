# Pawn R2 served TEST verification preparation

Status: preparation only. No browser, game, Web export, served-file network check,
UI action, or save/profile inspection has run. approved-target.json is absent.
The immutable target gate rejects launch until the exact independent auditor
PASS, finalized stage/source/tree/file hashes, publication and parent GO arrive.

Exact trial package: 85a22382e63379b340c21121e4d78ad6d82abea17efb8a20ad876afb01cb80a3.
It has 19 payloads, 15 genuine moving entries, and one one-frame static exact-BG
replay. The static entry is never counted as motion and has no temporal-delta
requirement. Its source has 41,136 opaque plus 73,104 transparent pixels and zero
opaque RGB mismatches against the exact background crop. Both mapped fronts are
opaque exact background crops at main [316,262,268,42] and shelf [600,184,246,28].

The four initial contexts are Base, Estate Lot Day, Serial-Check Day, and Sal's
Mood. Native production-painter alpha inputs are retained separately from the
conservative model/name envelopes. They are actual paint at recorded native
clocks, not a dump of future browser actor state. Estate is the strongest tray
demonstration; Base/Serial/Mood are partly covered. No geometry, labels, alpha,
speeds, cast placement, or production code are changed.

## Work area and bounded commands

Everything created here is under E:/CodexQA/BTH. Use the existing Windows Python
at C:/Users/theep/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe.
run_capped.py takes a unique run ID, timeout in seconds, executable, and arguments.
It plans/prepares/validates storage and assigns each worker before resume to its
own 12% CPU / 2 GiB kill-on-close Job. Default expected writes are 4 GiB plus
20 GiB reserve. Receipts record peak Job memory, CPU seconds, exit and cleanup.
Browser and short probe Jobs must remain independent, never under an aggregate
2 GiB Job. No C-write fallback or real profiles/saves are permitted.

Offline workers already executed:

- prepare_inputs.py: verifies and freezes exact package, union, source-painted
  images, native source ZIP and original/public Bar references.
- prepare_masks.py: makes 226 immutable 2x diagnostic masks across four contexts.
- selfcheck_preparation.py: syntax, copied-input/hash/mask verification, and
  fail-closed target tests. No external test is implied by this PASS.

Prepared, not run against served data:

- analyze_pawn.py <capture-folder>|<scenario-id> ... maps source masks to original
  observed screenshot geometry and reports raw composite deltas and sampled
  extrema, with static/moving roles separated.
- compare_reduce_motion.py <pair-spec.json> keeps full-frame/HUD and room delta
  results distinct. Supported settings/restoration need separate UI observations.
- fit_pawn_floor.py <capture-folder> streams floor strips and fits known speeds
  for corroboration only. It never loads all full-size frames at once.
- verify_served_pawn.py <owned-browser-closed-receipt.json> uses normal urllib TLS,
  streams every served byte in 1 MiB blocks, checks canonical/current/immutable
  identity, all files, embedded PCK identity and actual compiled art bytes. It
  requires the browser Job to be closed first. Served args/mount configuration is
  not a runtime IndexedDB/save-access observation.

CUA-PROBE-PROTOCOL.md records the live capture workflow and exact unresolved API
gaps. The current Browser skill prohibits standalone Playwright/CDP substitution.
No hidden UI/browser APIs, filesystem imports, screenshot helpers, profile
migration, security bypass, invented window handles, or unsupported launch
arguments will be substituted. Historical Bar automation is reference only.

## Reproducibility and diagnostics

The exact public Bar source ZIP is 5b517aed9348a6e4734e98b4c15b01a85bf2c68c315ef6958d5d1c038a09b49e.
The native Pawn source ZIP is f3642463d98c0200a332d0b6a2bfee3f832f861b8235126510544afc9bf1e867.
These source archives preserve runnable code, including legitimate Godot paths
such as /root/RunState. No native source-code redaction is performed.

The first input snapshot intentionally stopped when it was given the raw local
Bar ZIP for a hash belonging to the public metadata-sanitized ZIP. It made no
browser/network action, exited naturally with code 1, and drained its Job. The
original script and failure log remain. The corrected source was read from the
existing art worktree; its exact public hash then matched. Subsequent copies are
idempotently hash-checked, not silently overwritten.

Preparation output is not final native acceptance or actual served Web PASS.
No 24-context native coverage is relabeled UI E2E; no all-30-terminal-route,
buy/sell/quest/outcome, save/revisit or audience/main/NEXT change is claimed.
Final actual captures, if qualified and authorized, need a separately indexed
raw frame bulk and a precise scoped report. No Library upload is performed.
