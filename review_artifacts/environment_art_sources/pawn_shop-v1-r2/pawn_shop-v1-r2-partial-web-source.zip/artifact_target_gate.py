"""Separate artifact-only authority. Never grants browser or game admission."""
import json,re,hashlib
from pathlib import Path
from target_gate import digest,PACKAGE_SHA,RETAINED,ROOT_URL,TEST_MOUNT,admitted_target

def admitted_artifacts(work):
    work=Path(work).resolve()
    assert not (work/'approved-target.json').exists()
    try: admitted_target(work,require_browser=True)
    except RuntimeError as exc:
        assert str(exc).startswith('PREPARATION ONLY:'); denied=str(exc)
    else: raise RuntimeError('Browser gate must remain denied')
    a=json.loads((work/'artifact-approved-target.json').read_bytes())
    assert a['scope']=='artifact_only' and a['parent_artifact_only_go'] is True
    assert a['allow_browser'] is False and a['allow_game'] is False
    for key,width in [('source_commit',40),('source_tree',40),('package_sha256',64),('native_pass_report_sha256',64),
      ('manifest_sha256',64),('html_sha256',64),('pck_sha256',64),('embedded_manifest_sha256',64),('embedded_manifest_md5',32)]:
        assert re.fullmatch('[0-9a-f]{'+str(width)+'}',a[key]),key
    assert a['package_sha256']==PACKAGE_SHA
    p=Path(a['native_pass_report']); assert digest(p)==a['native_pass_report_sha256']
    native=json.loads(p.read_bytes()); assert native['status']=='PASS_NATIVE_ART_PACKAGE' and native['package_sha256']==PACKAGE_SHA
    assert a['canonical_url']==ROOT_URL and a['immutable_url']==ROOT_URL+a['source_commit']+'/index.html'
    stage=Path(a['finalized_stage']).resolve(strict=True)
    assert stage.is_relative_to(Path('E:/CodexQA/BTH/workspaces/BTH-ENVART-TEST-WEB-20261114').resolve())
    raw=(stage/'build_manifest.json').read_bytes(); assert hashlib.sha256(raw).hexdigest()==a['manifest_sha256']
    m=json.loads(raw); assert m['source_commit']==a['source_commit'] and m['source_tree']==a['source_tree']
    assert m['art_audit_report_sha256']==a['native_pass_report_sha256']
    assert m['active_art_packages']=={**RETAINED,'pawn_shop':PACKAGE_SHA}
    assert m['test_args']==['--','--bth-art-test'] and m['persistent_paths']==[TEST_MOUNT]
    assert m['embedded_manifest_sha256']==a['embedded_manifest_sha256'] and m['embedded_manifest_md5']==a['embedded_manifest_md5']
    assert m['files']['index.html']['sha256']==a['html_sha256'] and m['files']['index.pck']['sha256']==a['pck_sha256']
    for name,r in m['files'].items():
        assert name==Path(name).name and '/' not in name and '\\' not in name and name not in ('.','..')
        assert (stage/name).stat().st_size==r['bytes'] and digest(stage/name)==r['sha256'],name
    closed=Path(a['closed_qualification_receipt']); assert digest(closed)==a['closed_qualification_receipt_sha256']
    c=json.loads(closed.read_bytes()); assert c['kind']=='browser-surface-qualification' and c['game_allowed'] is False
    assert c['active_at_release']==0 and not c['cleanup_errors'] and c['assigned_before_resume'] is True
    return a,stage,m,{'artifact_admitted':True,'browser_admission_denied':True,'browser_denial':denied,
      'game_approved_target_present':False,'closed_qualification_receipt_sha256':digest(closed)}
