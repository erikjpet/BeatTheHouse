"""Stream raw screenshot composites through source masks, without modifying frames."""
import sys,os,json,hashlib,math
sys.dont_write_bytecode=True
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
W=Path(__file__).parent; OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
I=json.loads((W/'mask-index.json').read_bytes())

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_mask(record,size,geometry):
    p=W/record['path']; assert sha(p)==record['sha256'],str(p)
    source=Image.open(p).convert('L'); x,y,s=geometry
    return source.transform(size,Image.Transform.AFFINE,(2/s,0,-2*x/s,0,2/s,-2*y/s),Image.Resampling.NEAREST)

reports=[]
for spec in sys.argv[1:]:
    folder,scenario=spec.split('|'); folder=Path(folder).resolve(strict=True)
    assert folder.is_relative_to(Path('E:/CodexQA/BTH/runs').resolve())
    motion=json.loads((folder/'motion.json').read_bytes()); assert motion['input_during_capture'] is False
    assert motion['source']=='actual_served_test_cua' and motion['frames']
    geometry=json.loads((folder/'board-geometry.json').read_bytes())
    assert geometry['measured_from_actual_screenshot'] is True
    g=(float(geometry['x']),float(geometry['y']),float(geometry['scale']))
    assert g[2]>0 and scenario in I['contexts']
    native=I['contexts'][scenario]
    first_path=folder/'frames'/motion['frames'][0]['file']; first=Image.open(first_path).convert('RGB'); size=first.size
    assert list(size)==geometry['screenshot_size']
    maskdir=OUT/(folder.parent.name+'-mapped-masks'); maskdir.mkdir(exist_ok=True)
    regions={}
    for name,r in I['regions'].items():
        source=load_mask(r,size,g); bbox=source.getbbox()
        if bbox is None: raise ValueError('Region mapped entirely outside screenshot: '+name)
        source.save(maskdir/(name+'-source.png'))
        masks={'source':np.asarray(source.crop(bbox))>0}
        for field in ('clear_of_source_paint','not_fully_source_opaque','outside_source_envelopes'):
            mapped=load_mask(native['regions'][name][field],size,g)
            mapped.save(maskdir/(name+'-'+field+'.png'))
            masks[field]=np.asarray(mapped.crop(bbox))>0
        regions[name]={'role':r['role'],'box':bbox,'masks':masks,'base':np.asarray(first.crop(bbox),dtype=np.int16),
                       'peak':np.zeros((bbox[3]-bbox[1],bbox[2]-bbox[0]),dtype=np.uint8),'samples':[]}
    rawindex=[]
    for frame in motion['frames']:
        p=folder/'frames'/frame['file']; assert p.resolve().is_relative_to((folder/'frames').resolve())
        digest=sha(p)
        if 'sha256' in frame: assert digest==frame['sha256']
        rawindex.append({'file':frame['file'],'sha256':digest,'bytes':p.stat().st_size})
        with Image.open(p) as im:
            assert im.size==size
            for name,r in regions.items():
                pix=np.asarray(im.convert('RGB').crop(r['box']),dtype=np.int16)
                d=np.max(np.abs(pix-r['base']),axis=2).astype(np.uint8)
                r['peak']=np.maximum(r['peak'],d)
                fields={}
                for field,mask in r['masks'].items():
                    fields[field]={'changed_pixels':int(np.count_nonzero(d[mask])),
                      'mean_rgb':float(pix[mask].mean()) if mask.any() else None,
                      'peak_channel_delta':int(d[mask].max()) if mask.any() else 0}
                r['samples'].append({'frame':frame['index'],'file':frame['file'],'elapsed_ms':frame['elapsed_ms'],'measurements':fields})
    result={}
    for name,r in regions.items():
        fields={}
        for field,mask in r['masks'].items():
            candidates=[v for v in r['samples'] if v['measurements'][field]['mean_rgb'] is not None]
            fields[field]={'mask_pixels':int(mask.sum()),'temporal_changed_pixels':int(np.count_nonzero(r['peak'][mask])),
              'peak_channel_delta':int(r['peak'][mask].max()) if mask.any() else 0,
              'lowest_sample':min(candidates,key=lambda v:v['measurements'][field]['mean_rgb']) if candidates else None,
              'highest_sample':max(candidates,key=lambda v:v['measurements'][field]['mean_rgb']) if candidates else None}
        result[name]={'role':r['role'],'box':r['box'],'temporal_delta_required':r['role']=='moving','metrics':fields,'samples':r['samples']}
    reports.append({'label':motion['label'],'scenario':scenario,'frames':len(motion['frames']),'duration_ms':motion['duration_ms'],
      'geometry':geometry,'mapped_masks':str(maskdir),'raw_sha256_index':rawindex,'regions':result,
      'source_paint_clock':native['source_object_clock'],'source_route_clock':native['source_route_clock'],
      'limit':'All metrics describe observed composites. Source-painted/native-clock masks are corroboration only, not an assertion that browser actors remained at those exact positions.'})
report={'schema':'bth.pawn-served-composite/v1','status':'OBSERVATIONS_NOT_AUTOMATIC_ART_PASS','mask_index_sha256':sha(W/'mask-index.json'),'reports':reports,
 'limits':I['limits']+['Temporal extrema are observed screenshot samples, not exact mathematical peaks.',
  'One static replay entry is reported separately; its composite may contain later moving effects or actors. It is never counted as motion.',
  'Fractional viewport transforms and analog-clock HUD pixels are retained in originals; no forced full-frame equality or frame retouching.']}
(OUT/'pawn-composite-motion.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':report['status'],'captures':len(reports),'moving_per_capture':15,'static_per_capture':1}))
