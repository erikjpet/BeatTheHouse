"""Compare original RM screenshot pairs; preserve full-frame and room differences."""
import sys,os,json,hashlib,math
sys.dont_write_bytecode=True
from pathlib import Path
import numpy as np
from PIL import Image
out=Path(os.environ['BTH_QA_EVIDENCE_DIR']); spec=Path(sys.argv[1]); data=json.loads(spec.read_bytes()); rows=[]
for case in data['pairs']:
    pa,pb=Path(case['a']),Path(case['b']); a=Image.open(pa).convert('RGB'); b=Image.open(pb).convert('RGB'); assert a.size==b.size
    aa,bb=np.asarray(a,dtype=np.int16),np.asarray(b,dtype=np.int16); d=np.max(np.abs(aa-bb),axis=2)
    x,y,s=case['board_geometry']; bounds=[math.floor(x),math.floor(y),math.ceil(x+900*s),math.ceil(y+430*s)]
    x0,y0,x1,y1=bounds; assert x0>=0 and y0>=0 and x1<=a.width and y1<=a.height
    ys,xs=np.nonzero(d); room=d[y0:y1,x0:x1]
    rows.append({'label':case['label'],'a_sha256':hashlib.sha256(pa.read_bytes()).hexdigest(),'b_sha256':hashlib.sha256(pb.read_bytes()).hexdigest(),
      'full_changed_pixels':int(np.count_nonzero(d)),'full_peak_channel_delta':int(d.max()),
      'full_delta_bbox':[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)] if len(xs) else None,
      'board_bounds':bounds,'board_changed_pixels':int(np.count_nonzero(room)),'board_peak_channel_delta':int(room.max()),
      'note':'No pixel edits. Nonzero full-frame HUD/analog-clock differences remain reported even if room is stationary.'})
report={'status':'OBSERVED_REDUCE_MOTION_PAIRS','pairs':rows,'scope':'Supported settings UI must independently establish RM on/off and restoration. This comparison does not alter clocks or claim save/revisit E2E.'}
(out/'pawn-reduce-motion-pairs.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report))
