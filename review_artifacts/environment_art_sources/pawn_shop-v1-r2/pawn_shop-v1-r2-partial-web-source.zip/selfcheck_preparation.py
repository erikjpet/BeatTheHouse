"""Offline preparation checks only. Deliberately no browser/network/game."""
import sys,os,json,ast,hashlib
sys.dont_write_bytecode=True
from pathlib import Path
from PIL import Image
W=Path(__file__).parent; OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
from target_gate import admitted_target,PACKAGE_SHA
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (W/'approved-target.json').exists()
blocked=[]
for browser in (False,True):
    try: admitted_target(W,require_browser=browser)
    except RuntimeError as e:
        assert str(e).startswith('PREPARATION ONLY:'); blocked.append(str(e))
    else: raise AssertionError('Admission unexpectedly allowed')
sources={}
for p in W.glob('*.py'):
    ast.parse(p.read_bytes(),filename=str(p)); sources[p.name]=sha(p)
inputs=json.loads((W/'input-manifest.json').read_bytes()); assert inputs['package_sha256']==PACKAGE_SHA
for rel,row in inputs['files'].items(): assert sha(W/rel)==row['sha256'],rel
idx=json.loads((W/'mask-index.json').read_bytes()); assert len(idx['regions'])==16 and len(idx['contexts'])==4
assert sum(r['role']=='moving' for r in idx['regions'].values())==15
assert idx['regions']['STATIC_OCCLUSION_fixed_material']['role']=='static_occlusion'
records=[]
def walk(v):
    if isinstance(v,dict):
        if 'path' in v and 'sha256' in v and v['path'].startswith('masks/'): records.append(v)
        for k in v.values(): walk(k)
    elif isinstance(v,list):
        for k in v: walk(k)
walk(idx)
assert len(records)==226
for r in records:
    p=W/r['path']; assert sha(p)==r['sha256']; im=Image.open(p); assert im.mode=='L' and im.size==(1800,860)
plan=json.loads((W/'proof-plan.json').read_bytes()); assert plan['status']=='PREPARATION_ONLY_NO_BROWSER_GAME_OR_SERVED_QA'
assert plan['browser_go_received'] is False and plan['approved_target_created'] is False
result={'status':'PASS_OFFLINE_PREPARATION_ONLY','package_sha256':PACKAGE_SHA,'inputs_reverified':len(inputs['files']),
 'masks_reverified':len(records),'contexts':4,'moving':15,'static':1,'python_sources':sources,'fail_closed_gate_tests':blocked,
 'not_run':['Browser launch','Game launch','Unapproved Web export','Served TEST network verification','Live UI/scenario/motion/RM/retention tests'],
 'limitations':plan['qualification_gaps']}
(OUT/'preparation-selfcheck.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('python_sources','fail_closed_gate_tests','limitations')}))
