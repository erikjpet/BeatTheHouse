# Candidate qualification, still no launch

This supplement does not change the sealed preparation archive or grant launch
permission. Exact-source and qualification GO remain required.

## Causal owned-window selection

An admitted suspended/assigned-before-resume browser launch can use a newly
authored local calibration file with a unique nonce in its filename and title.
The command and exact E profile are recorded by the owned 12% CPU/2 GiB Job
supervisor. CUA lists windows, selects only that unique newly observed title,
and visibly checks chrome://version for the executable, command line and exact
E-profile path. The combination causally connects the selected fresh window to
the owned launch. No opaque windowId is interpreted as HWND or queried as PID.
The direct OS windowId-to-PID relationship remains unclaimed.

## Actual dimensions

calibration-template.html is self-authored diagnostic content, separate from
the game. Substitute a unique nonce into a new admitted E file only at launch.
It visibly reports innerWidth, innerHeight, devicePixelRatio and document client
dimensions. Resize only with documented CUA native window/UI actions. Require
1280x720 and 1920x1080 actual client dimensions and inspect the screenshot pixel
geometry. Do not claim CSS emulation, browser zoom, or a scaled fitted image is
an actual native-size capture. If the display/capture pipeline cannot preserve
the required dimensions, record the exact limitation. No target-game code,
clock, scenario, object position, alpha, or state is injected.

## Candidate original-PNG transfer through ordinary browser UI

getScreenshot() documents Uint8Array PNG bytes, or screenshot-region objects
with bytes. Retain the returned original in the CUA JS session. The pure
pngDataUrl and sha256Bytes helpers use only ordinary in-memory JavaScript. They
have no filesystem, network, OS, browser-evaluate, or screenshot-helper access.
Paste their function declarations into CUA when needed; do not import/require
the helper source from CUA.

After recording the original byte count and SHA256 through nodeRepl.write, open
a new tab in the same owned browser using native CUA key input. Paste the
data:image/png;base64 URL into the observed address field, load it, then use the
browser's normal Save As UI to save the image in the admitted E evidence path.
Confirm the actual Save As type and destination visually. A separate bounded
file verifier must check PNG signature, dimensions, byte count and exact SHA256
against the original CUA byte hash. A page/HTML save, changed PNG bytes, rejected
data URL, oversized paste, incorrect path, or missing file is a qualification
failure, not a completed transfer. Never route it to a remote service.

This is a candidate supported-UI composition, not a tested capability. Qualify
on the harmless calibration screenshot before opening the game. For uninterrupted
autonomous game captures, collect a bounded no-input batch first and perform
save-tab actions only afterward. Do not interleave image saves with a claimed
uninterrupted sequence. Restore the existing game tab without reloading it.

Potential limits to report include per-frame transfer cost, clipboard behavior,
tool/session lifetime, exact 1920 capture support, and any inaccessible save
dialog. No hidden file writer, custom local receiver, CDP or Playwright fallback
is authorized by this plan.
