"""Seal a preparation-only source bundle; metadata-only outward sanitization."""
import sys,os,json,hashlib,zipfile,io,re
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).parent; OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR']); ROOT=Path('E:/CodexQA/BTH')
assert not (W/'approved-target.json').exists()
H=lambda b:hashlib.sha256(b).hexdigest()
redactions=[]
attachment=re.compile(r'file_[0-9a-f]{24,}')
routing=re.compile(r'/root/[a-z][a-z0-9_]*(?:/[a-z][a-z0-9_]*)*')

def clean_text(text):
    return routing.sub('[internal task reference omitted]',attachment.sub('[native attachment reference omitted]',text))

def clean_metadata(raw,name):
    if Path(name).suffix.lower() not in ('.json','.log','.txt','.md'): return raw
    text=raw.decode('utf8'); cleaned=clean_text(text)
    if cleaned!=text:
        result=cleaned.encode('utf8')
        redactions.append({'file':name,'kind':'metadata_only','original_sha256':H(raw),'copy_sha256':H(result)})
        return result
    return raw

def clean_bar_zip(raw):
    output=io.BytesIO(); changed=[]
    with zipfile.ZipFile(io.BytesIO(raw)) as source,zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as dest:
        for item in source.infolist():
            b=source.read(item.filename); c=clean_metadata(b,'reference-bar/bar-r4-web-proof-source.zip!'+item.filename)
            if item.filename.endswith(('.py','.gd','.cjs','.js')): assert c==b
            dest.writestr(item,c)
    result=output.getvalue()
    redactions.append({'file':'reference-bar/bar-r4-web-proof-source.zip','kind':'nested_metadata_only_container','original_sha256':H(raw),'copy_sha256':H(result)})
    return result

files={}
for p in sorted(W.rglob('*')):
    if not p.is_file() or p.suffix.lower() not in ('.py','.cjs','.json','.md','.png','.zip'): continue
    name=p.relative_to(W).as_posix()
    assert not any(part in ('profile','cache','home','appdata','localappdata','save_dir','IndexedDB','__pycache__') for part in p.relative_to(W).parts)
    raw=p.read_bytes()
    b=clean_bar_zip(raw) if name=='reference-bar/bar-r4-web-proof-source.zip' else clean_metadata(raw,name)
    if name=='inputs/native/pawn-r2-native-qa-source.zip': assert b==raw and H(b)=='f3642463d98c0200a332d0b6a2bfee3f832f861b8235126510544afc9bf1e867'
    files[name]=b

# Update only the outward metadata copy so its declared file hashes match the
# metadata-sanitized references actually embedded. Preserve original hashes.
index=json.loads(files['input-manifest.json'])
for name,row in index['files'].items():
    if name in files and H(files[name])!=row['sha256']:
        row['original_sha256']=row['sha256']; row['original_bytes']=row['bytes']
        row['sha256']=H(files[name]); row['bytes']=len(files[name]); row['metadata_only_sanitized']=True
raw=files['input-manifest.json']; files['input-manifest.json']=json.dumps(index,indent=2).encode()
if raw!=files['input-manifest.json']: redactions.append({'file':'input-manifest.json','kind':'reference_copy_hash_reconciliation','original_sha256':H(raw),'copy_sha256':H(files['input-manifest.json'])})

run_ids=['BTH-ENVART-PAWNWEB-inputs-01','BTH-ENVART-PAWNWEB-inputs-02','BTH-ENVART-PAWNWEB-masks-01',
 'BTH-ENVART-PAWNWEB-inputs-03','BTH-ENVART-PAWNWEB-selfcheck-01','BTH-ENVART-PAWNWEB-selfcheck-02','BTH-ENVART-PAWNWEB-repro-scan-01']
jobs={}; peak=0
for run in run_ids:
    e=ROOT/'runs'/run/'evidence'; job=json.loads((e/'job.json').read_bytes()); expected=1 if run.endswith('inputs-01') else 0
    assert job['exit_code']==expected and job['active_at_release']==0 and job['assigned_before_execution'] is True
    assert not job['timed_out'] and not job['error'] and not job['cleanup_errors']
    assert job['limits']['cpu_rate']==1200 and job['limits']['job_memory_limit_bytes']==2*1024**3
    resources=job['resource_measurements']; assert resources['active_at_release']==0
    peak=max(peak,resources['peak_job_memory_bytes'])
    jobs[run]={'exit_code':job['exit_code'],'natural_termination':not job['timed_out'] and not job['error'],
       'assigned_before_execution':True,'active_at_release':0,'peak_job_memory_bytes':resources['peak_job_memory_bytes'],
       'cpu_seconds':resources['cpu_seconds'],'cleanup_errors':[],'job_sha256':H((e/'job.json').read_bytes())}
    for p in e.iterdir():
        if p.is_file() and p.suffix in ('.json','.log'):
            name='receipts/'+run+'/'+p.name; files[name]=clean_metadata(p.read_bytes(),name)

image_index={name:{'sha256':H(raw),'bytes':len(raw)} for name,raw in files.items() if name.endswith('.png')}
(OUT/'raw-source-image-sha256.json').write_text(json.dumps(image_index,indent=2))
(OUT/'raw-browser-frame-sha256.json').write_text(json.dumps({'status':'NO_BROWSER_FRAMES_CAPTURED','files':{}},indent=2))
plan=json.loads((W/'proof-plan.json').read_bytes())
report={'status':'PASS_OFFLINE_PREPARATION_LIVE_WEB_NOT_RUN','package_sha256':plan['trial_package_sha256'],
 'work_area':str(W),'source_commit':None,'source_tree':None,'approved_target_present':False,
 'browser_launched':False,'game_launched':False,'network_verification_run':False,'source_target_site_edits':False,
 'source_masks':{'contexts':4,'moving':15,'static':1,'PNG_masks':226,'static_opaque_pixels':41136,'static_transparent_pixels':73104,'BG_RGB_mismatches':0},
 'inputs_reverified':142,'selfcheck':{'path':'receipts/BTH-ENVART-PAWNWEB-selfcheck-02/preparation-selfcheck.json',
    'sha256':H(files['receipts/BTH-ENVART-PAWNWEB-selfcheck-02/preparation-selfcheck.json'])},
 'jobs':jobs,'highest_completed_worker_peak_bytes':peak,'current_sealing_job_receipt':'job.json adjacent to this report, finalized by supervisor after seal exits',
 'qualification_gaps':plan['qualification_gaps'],'not_claimed':plan['not_claimed'],
 'preserved_diagnostic':'First input copy exited 1 because raw local Bar ZIP was checked against public-copy hash. Correct public path matched; original script/log retained. No browser/network action occurred.',
 'reproduction_hygiene':'Original inputs remain unchanged locally. Outward metadata copies redact native attachment/internal routing references only; code and ordinary Godot NodePaths are byte-for-byte preserved.',
 'redactions':redactions,'raw_source_image_count':len(image_index),'actual_browser_frame_count':0}
files['preparation-report.json']=json.dumps(report,indent=2).encode()
files['raw-source-image-sha256.json']=json.dumps(image_index,indent=2).encode()
files['raw-browser-frame-sha256.json']=(OUT/'raw-browser-frame-sha256.json').read_bytes()
archive_index={name:{'sha256':H(raw),'bytes':len(raw)} for name,raw in files.items()}
files['archive-file-sha256.json']=json.dumps(archive_index,indent=2).encode()
# Only metadata is scanned for private identifiers; code is never rewritten.
for name,raw in files.items():
    if Path(name).suffix.lower() in ('.json','.md','.txt','.log'):
        text=raw.decode('utf8'); assert not attachment.search(text) and not routing.search(text),name
bundle=OUT/'pawn-r2-web-preparation-source.zip'
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in files.items(): z.writestr(name,raw)
report['source_archive']={'path':str(bundle),'sha256':H(bundle.read_bytes()),'bytes':bundle.stat().st_size,'files':len(files)}
(OUT/'pawn-r2-web-preparation-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':report['status'],'source_archive':report['source_archive'],'highest_worker_peak_bytes':peak,'redacted_metadata_records':len(redactions)}))
