"""Fail-closed immutable Pawn TEST admission. Does not create or infer approval."""
import json, hashlib, re
from pathlib import Path
PACKAGE_SHA = '85a22382e63379b340c21121e4d78ad6d82abea17efb8a20ad876afb01cb80a3'
ROOT_URL = 'https://192.168.0.36:8443/p/beat-the-house/play/test/'
RETAINED = {
 'gas_station_casino':'1e9a88be562db041248d4561619d0110d0b267310f42be25acd362bfae64b560',
 'corner_store':'6f1e76d5cb4f44dd73f494e4cf52fcf2eb433a0e849c6ee6bd0c090a36897dcb',
 'back_alley':'f42919a146d4fdc17d7cd120ef926b44f6ccaefabcaf6a8a171e805db2150b68',
 'motel':'4b22c9cfda8ad88f0d989b544c50cc84efd4fc290583a3e87464f9963821b971',
 'bar':'398469b22c7c0eed36220757e79ce0829498aa79f4ecd1ce019df493abb02d39'}
TEST_MOUNT = '/userfs/godot/app_userdata/Beat the House/distribution/web_0_6_1_art_test'

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def admitted_target(work, require_browser=False):
    work=Path(work).resolve()
    path=work/'approved-target.json'
    if not path.is_file(): raise RuntimeError('PREPARATION ONLY: exact independent auditor PASS, finalized source and parent GO have not been supplied')
    a=json.loads(path.read_bytes())
    if a.get('parent_go') is not True or a.get('full_auditor_pass') is not True: raise RuntimeError('Explicit exact-source parent GO and independent full native PASS required')
    if require_browser and (a.get('browser_go') is not True or a.get('browser_surface')!='cua_native_owned_window'):
        raise RuntimeError('Separate explicit browser GO for CUA-controlled owned native window required')
    for key,width in [('source_commit',40),('source_tree',40),('manifest_sha256',64),('html_sha256',64),('package_sha256',64),('native_pass_report_sha256',64)]:
        if not re.fullmatch('[0-9a-f]{'+str(width)+'}',a.get(key,'')): raise ValueError('Exact '+key+' required')
    if a['package_sha256'] != PACKAGE_SHA: raise ValueError('Prepared only for exact Pawn R2')
    native=Path(a['native_pass_report']).resolve(strict=True)
    if digest(native)!=a['native_pass_report_sha256']: raise ValueError('Native PASS report hash mismatch')
    report=json.loads(native.read_bytes())
    if report.get('status')!='PASS_NATIVE_ART_PACKAGE' or report.get('package_sha256')!=PACKAGE_SHA:
        raise ValueError('Independent final native ART PASS report missing; technical/pending reports do not qualify')
    commit=a['source_commit']
    if a.get('canonical_url')!=ROOT_URL or a.get('immutable_url')!=ROOT_URL+commit+'/index.html': raise ValueError('Unexpected TEST destination')
    stage=Path(a['finalized_stage']).resolve(strict=True)
    parent=Path('E:/CodexQA/BTH/workspaces/BTH-ENVART-TEST-WEB-20261114').resolve(strict=True)
    if not stage.is_relative_to(parent): raise ValueError('Stage outside admitted E TEST workspace')
    raw=(stage/'build_manifest.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=a['manifest_sha256']: raise ValueError('Final manifest mismatch')
    m=json.loads(raw)
    if m.get('source_commit')!=commit or m.get('source_tree')!=a['source_tree']: raise ValueError('Final source identity mismatch')
    if m.get('active_art_packages')!={**RETAINED,'pawn_shop':PACKAGE_SHA}: raise ValueError('Unexpected cumulative room/package set')
    if m.get('test_args')!=['--','--bth-art-test'] or m.get('persistent_paths')!=[TEST_MOUNT]: raise ValueError('TEST isolation configuration changed')
    for name,v in m['files'].items():
        if name!=Path(name).name or name in ('.','..') or '/' in name or '\\' in name: raise ValueError('Unsafe stage filename')
        p=stage/name
        if p.stat().st_size!=v['bytes'] or digest(p)!=v['sha256']: raise ValueError('Final stage file mismatch: '+name)
    if m['files']['index.html']['sha256']!=a['html_sha256']: raise ValueError('HTML hash mismatch')
    return a,stage
