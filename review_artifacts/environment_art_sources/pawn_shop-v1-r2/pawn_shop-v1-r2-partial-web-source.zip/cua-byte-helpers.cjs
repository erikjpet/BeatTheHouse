/* Pure in-memory byte helpers. No filesystem, network, browser, or OS APIs. */
function pngDataUrl(bytes) {
  if (!(bytes instanceof Uint8Array)) throw Error('Expected documented screenshot bytes');
  if (bytes.length < 8 || [137,80,78,71,13,10,26,10].some((v,i)=>bytes[i]!==v)) throw Error('Not PNG bytes');
  const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let text='';
  for(let i=0;i<bytes.length;i+=3){
    const a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;
    text+=alphabet[a>>>2]+alphabet[((a&3)<<4)|(b>>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');
  }
  return 'data:image/png;base64,'+text;
}
function sha256Bytes(bytes) {
  if (!(bytes instanceof Uint8Array)) throw Error('Expected bytes');
  const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const length=Math.ceil((bytes.length+9)/64)*64,padded=new Uint8Array(length);padded.set(bytes);padded[bytes.length]=128;
  const dv=new DataView(padded.buffer),bits=bytes.length*8;dv.setUint32(length-8,Math.floor(bits/4294967296));dv.setUint32(length-4,bits>>>0);
  const words=new Uint32Array(64),ror=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let off=0;off<length;off+=64){
    for(let i=0;i<16;i++)words[i]=dv.getUint32(off+i*4);
    for(let i=16;i<64;i++){
      const a=words[i-15],b=words[i-2];
      words[i]=(words[i-16]+(ror(a,7)^ror(a,18)^(a>>>3))+words[i-7]+(ror(b,17)^ror(b,19)^(b>>>10)))>>>0;
    }
    let [a,b,c,d,e,f,g,j]=h;
    for(let i=0;i<64;i++){
      const t1=(j+(ror(e,6)^ror(e,11)^ror(e,25))+((e&f)^(~e&g))+K[i]+words[i])>>>0;
      const t2=((ror(a,2)^ror(a,13)^ror(a,22))+((a&b)^(a&c)^(b&c)))>>>0;
      j=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
    }
    [a,b,c,d,e,f,g,j].forEach((v,i)=>{h[i]=(h[i]+v)>>>0;});
  }
  return h.map(v=>v.toString(16).padStart(8,'0')).join('');
}
// Node exports are for OFFLINE unit tests only. In CUA paste the two pure
// function declarations above directly; no require/import of this file.
if (typeof module!=='undefined') module.exports={pngDataUrl,sha256Bytes};
