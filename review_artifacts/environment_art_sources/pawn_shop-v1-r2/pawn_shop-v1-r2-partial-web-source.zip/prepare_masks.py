"""Source-only 2x support masks from exact Pawn art and native production painters."""
import sys, os, json, hashlib
sys.dont_write_bytecode=True
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
W=Path(__file__).parent; OUT=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
PKG=W/'inputs/pawn_shop-v1-r2'; ART=PKG/'assets/art/environments/pawn_shop'
M=json.loads((PKG/'data/art/environments/pawn_shop.json').read_bytes())
U=json.loads((W/'inputs/pawn_preart_union.json').read_bytes())
P=json.loads((W/'inputs/source-paint/pawn_glint_source_paint.json').read_bytes())
DEST=W/'masks'; DEST.mkdir(exist_ok=True)
SIZE=(1800,860)
STATIC='STATIC_OCCLUSION_fixed_material'
assert len(M['animations'])==16 and sum(e['id']!=STATIC for e in M['animations'])==15
assert len(U['contexts'])==len(P['contexts'])==4 and not P['findings']

def save(im,name):
    path=DEST/name; im.save(path)
    return {'path':path.relative_to(W).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pixels':int(np.count_nonzero(np.asarray(im)))}

def box(r):
    x,y,w,h=r
    return (round(2*x),round(2*y),round(2*(x+w)),round(2*(y+h)))

def rectmask(r):
    im=Image.new('L',SIZE); b=box(r)
    ImageDraw.Draw(im).rectangle((b[0],b[1],b[2]-1,b[3]-1),fill=255)
    return im

def remove(mask,other): return Image.fromarray(np.where(np.asarray(other)>0,0,np.asarray(mask)).astype('uint8'))

bg=Image.open(ART/'background.png').convert('RGBA')
occ=Image.open(ART/'anim/fixed_material_occlusion.png').convert('RGBA')
assert bg.size==SIZE and occ.size==(476,240)
oa=np.asarray(occ); crop=np.asarray(bg.crop((664,196,1140,436)))
assert set(np.unique(oa[:,:,3]))=={0,255}
opaque=oa[:,:,3]==255
assert int(opaque.sum())==41136 and int((~opaque).sum())==73104
assert np.array_equal(oa[:,:,:3][opaque],crop[:,:,:3][opaque])
occ_board=Image.new('L',SIZE); occ_board.paste(occ.getchannel('A'),(664,196))
ids=[e['id'] for e in M['animations']]
assert ids.index('security_scan')<ids.index(STATIC)<ids.index('inspection_tray_breath')
fronts={'pawn_counter':[316,262,268,42],'pawn_estate_shelf':[600,184,246,28]}
front_union=Image.new('L',SIZE)
front_records={}
for name,r in fronts.items():
    im=Image.open(ART/M['counters'][name]['texture']).convert('RGBA')
    assert im.getchannel('A').getextrema()==(255,255)
    assert im.tobytes()==bg.crop(box(r)).tobytes()
    f=rectmask(r); front_union=Image.fromarray(np.maximum(np.asarray(front_union),np.asarray(f)))
    front_records[name]={'rect':r,**save(f,name+'.png')}

regions={}; masks={}
for entry in M['animations']:
    eid=entry['id']; typ=entry['type']
    r=([0,entry['from'][1],900,entry['size'][1]] if typ=='mover' else entry['rect'])
    if typ in ('mover','scroll'): mask=rectmask(r)
    else:
        texture=Image.open(ART/entry['texture']).convert('RGBA'); n=entry.get('frames',1)
        fw=texture.width//n; alpha=np.zeros((texture.height,fw),dtype=np.uint8)
        for i in range(n): alpha=np.maximum(alpha,np.asarray(texture.crop((i*fw,0,(i+1)*fw,texture.height)).getchannel('A')))
        b=box(r); a=Image.fromarray(alpha).resize((b[2]-b[0],b[3]-b[1]),Image.Resampling.NEAREST)
        mask=Image.new('L',SIZE); mask.paste(a.point(lambda v:255 if v else 0),(b[0],b[1]))
    if eid=='security_scan': mask=remove(mask,occ_board)
    if typ=='mover': mask=remove(mask,front_union)
    if eid.startswith('high_air_'):
        # Keep shared high-air envelope separate from stronger sign/scan/tray/glints.
        for other in M['animations']:
            if other['id'].startswith('high_air_') or other['type']=='mover' or other['id']==STATIC: continue
            mask=remove(mask,rectmask(other['rect']))
    masks[eid]=mask
    regions[eid]={'role':'static_occlusion' if eid==STATIC else 'moving','type':typ,'rect':r,**save(mask,eid+'-source.png')}

contexts={}
for c in P['contexts']:
    scenario=c['scenario']; assert c['geometry_equal'] and scenario in U['contexts']
    composite=Image.new('RGBA',SIZE,(0,0,0,0)); referenced=[]
    for obj in c['objects']:
        for key in ('body_png','adorn_png'):
            im=Image.open(W/'inputs/source-paint'/obj[key]).convert('RGBA'); assert im.size==SIZE
            composite=Image.alpha_composite(composite,im); referenced.append(obj[key])
    alpha=composite.getchannel('A'); aa=np.asarray(alpha)
    anypaint=Image.fromarray(np.where(aa>0,255,0).astype('uint8'))
    opaquepaint=Image.fromarray(np.where(aa==255,255,0).astype('uint8'))
    envelopes=Image.new('L',SIZE); draw=ImageDraw.Draw(envelopes)
    for row in U['contexts'][scenario]['rows']:
        for field in ('model_rect','label_rect'):
            if field not in row: continue
            b=box(row[field]); draw.rectangle((b[0]-2,b[1]-2,b[2]+1,b[3]+1),fill=255)
    item={'source_object_clock':c['object_clock'],'source_route_clock':c['route_clock'],'native_geometry_equal':True,
          'paint_files':referenced,'alpha':save(alpha,scenario+'-paint-alpha.png'),
          'any_paint':save(anypaint,scenario+'-paint-any.png'),'opaque_paint':save(opaquepaint,scenario+'-paint-opaque.png'),
          'conservative_envelopes':save(envelopes,scenario+'-model-name-envelopes.png'),'regions':{}}
    for eid,mask in masks.items():
        item['regions'][eid]={'clear_of_source_paint':save(remove(mask,anypaint),scenario+'-'+eid+'-paint-clear.png'),
          'not_fully_source_opaque':save(remove(mask,opaquepaint),scenario+'-'+eid+'-not-opaque.png'),
          'outside_source_envelopes':save(remove(mask,envelopes),scenario+'-'+eid+'-envelope-free.png')}
    contexts[scenario]=item
result={'status':'PREPARED_SOURCE_MASKS_NOT_WEB_ACCEPTANCE','board_size':list(SIZE),'moving_entries':15,'static_entries':1,
        'static_source_proof':{'opaque_pixels':41136,'transparent_pixels':73104,'RGB_mismatches':0,'exact_order':True},
        'regions':regions,'contexts':contexts,'fronts':front_records,
        'limits':['Painter alpha is actual unchanged production paint at the named native clocks, not a live browser-state dump.',
          'Mapped source masks only corroborate browser screenshots when visible source geometry and cast/name placement match. Later actor motion can invalidate paint exclusion.',
          'Conservative model/name envelopes are reported separately and are not claimed to be actual opacity.',
          'Scroll support is the translated envelope. The two air fields overlap, as do some floor lanes; composite change is not isolated per-entry proof.',
          'Static replay is not a moving entry and has no required temporal delta. Actors and later effects can change its composite region.']}
(W/'mask-index.json').write_text(json.dumps(result,indent=2)); (OUT/'mask-preparation.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'status':result['status'],'contexts':len(contexts),'moving':15,'static':1,'files':len(list(DEST.glob('*.png'))),'static_source_proof':result['static_source_proof']}))
