import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw
REPO=Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers')
sys.path.insert(0,str(REPO/'tools'))
from bth_qa_storage import Layout,validate_layout
from check_environment_art_pack import validate_manifest,counter_rectangles
m=json.loads((Path(os.environ['BTH_QA_EVIDENCE_DIR'])/'storage-manifest.json').read_text())
l=Layout(**{k:Path(v) for k,v in m['paths'].items()},run_id=m['run_id'],token=m['token'],prepared=True,expected_write_bytes=m['expected_write_bytes'],reserve_bytes=m['reserve_bytes'])
w=l.workspace; artist=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-ARTIST-20261114/pawn_shop-v1')
root=w/'packages/pawn_shop-v1-r2';validate_layout(l,extra_write_paths=(root,));assert not root.exists()
raw=artist/'source/background-guide-v1.png';floorpath=artist/'source/floor-material-v1.png'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(raw)=='72b0794caeaff74a02d0472259d4da6ea9fe6171b1899279383da368ec68cc01'
assert sha(floorpath)=='e7c878d9e2ce1e33b640dfee6564699b64c5a11447b694a93aee1d817cf4d031'
s=Image.open(raw).convert('RGB').resize((900,430),Image.Resampling.NEAREST)
f=Image.open(floorpath).convert('RGB').resize((900,430),Image.Resampling.NEAREST);b=s.copy()
asset=root/'assets/art/environments/pawn_shop';(asset/'anim').mkdir(parents=True);(asset/'counters').mkdir();(root/'data/art/environments').mkdir(parents=True)
def fit(im,box,size):return im.crop(box).resize(size,Image.Resampling.NEAREST)
def nine(im,sx,sy,tx,ty):
 for yi in range(len(sy)-1):
  for xi in range(len(sx)-1):b.paste(fit(im,(sx[xi],sy[yi],sx[xi+1],sy[yi+1]),(tx[xi+1]-tx[xi],ty[yi+1]-ty[yi])),(tx[xi],ty[yi]))
# Entire floor is a single SAME-SCALE crop, never a stretched old 80px strip.
b.paste(f.crop((0,140,900,324)),(0,246))
# Shorten existing side masonry feet to the true horizon, no invented posts.
for box,at in [((8,222,54,264),(8,222)),((846,222,890,264),(846,222))]:b.paste(fit(s,box,(box[2]-box[0],24)),at)
# Erase only old lower-case protrusion with adjacent existing masonry.
b.paste(s.crop((58,224,275,230)),(58,216))
# Outer frame and inner glass are independently exact, retaining frame wear.
nine(s,(58,76,260,275),(71,87,208,222),(56,72,258,274),(70,86,190,216))
# Rebuild empty pane intervals from source intervals, discarding every misplaced old ridge.
# Exact lips stay at98/126/154/182, source cyan ridges measured102/131/161/191.
for src,dst in [((76,88,260,101),(72,86,258,98)),((76,107,260,129),(72,103,258,126)),((76,136,260,159),(72,131,258,154)),((76,165,260,189),(72,159,258,182)),((76,194,260,208),(72,187,258,190))]:
 b.paste(fit(s,src,(dst[2]-dst[0],dst[3]-dst[1])),dst[:2])
for oldy,y in zip((102,130,160,190),(98,126,154,182)):
 lip=fit(s,(79,oldy,254,oldy+5),(174,5));p=lip.load()
 for yy in range(1,5):
  for xx in range(174):
   r,g,bl=p[xx,yy];p[xx,yy]=(round(r*.68),round(g*.57),round(bl*.62))
 b.paste(lip,(78,y))
# Cage outer/rear lip fit. Original side overshoot is removed with existing brick planes.
b.paste(s.crop((286,90,294,236)),(308,90));b.paste(s.crop((590,90,594,236)),(584,90))
b.paste(fit(s,(309,90,585,229),(268,132)),(316,92))
b.paste(fit(s,(314,228,583,241),(268,12)),(316,224))
# Source transaction frame nine-slice; delete the old tray before mapping glass.
q=s.copy();q.paste(s.crop((358,135,438,153)),(408,150))
nine(q,(344,357,544,559),(120,134,181,195),(342,358,540,556),(116,132,174,190))
# Quiet dusty glass material plane, preserving scratches and local color ramps.
p=b.load()
for yy in range(132,174):
 for xx in range(358,540):
  r,g,bl=p[xx,yy];p[xx,yy]=(round(r*.56),round(g*.56),round(bl*.59))
# Actual compact inspection fixture remains76x16. Dark left aperture supports cyan union.
tray=fit(s,(408,150,487,167),(76,16));p=tray.load()
for yy in range(16):
 for xx in range(76):
  r,g,bl=p[xx,yy];p[xx,yy]=(round(r*.26+9),round(g*.27+7),round(bl*.42+5))
td=ImageDraw.Draw(tray);td.line((1,0,74,0),fill=(128,101,53));td.line((0,1,0,14),fill=(81,73,57));td.line((1,15,74,15),fill=(58,47,40))
td.rectangle((54,4,69,10),fill=(147,96,35));td.line((55,5,68,5),fill=(213,163,69));td.line((55,7,68,7),fill=(195,132,40));b.paste(tray,(408,148))
# Right empty case: exact outer and inner bounds; fore-shelf is replayed last.
nine(s,(612,629,819,836),(72,91,201,222),(612,630,818,836),(72,92,200,222))
b.paste(fit(s,(653,173,796,186),(142,18)),(652,170))
# Broad low field is shallow toe-kick + FLAT rubber work runner, NOT generated fascia.
b.paste(s.crop((58,251,850,261)),(58,236))
runner=fit(s,(60,304,842,343),(792,52));rp=runner.load()
for yy in range(52):
 for xx in range(792):
  r,g,bl=rp[xx,yy];rp[xx,yy]=(round(r*.73),round(g*.72),round(bl*.77))
rd=ImageDraw.Draw(runner);rd.line((0,0,791,0),fill=(32,25,38));rd.line((0,51,791,51),fill=(29,24,34));rd.line((0,0,0,51),fill=(31,26,37));rd.line((791,0,791,51),fill=(31,26,37));b.paste(runner,(58,246))
# Exact dark detailed foregrounds; one restrained top/contact row, no broad gold face.
fronts=[('pawn_counter',(316,262,268,42),(314,261,585,305)),('pawn_estate_shelf',(600,184,246,28),(598,186,848,220))]
for name,(x,y,ww,hh),src in fronts:
 im=fit(s,src,(ww,hh));pp=im.load()
 for yy in range(1,min(7,hh)):
  for xx in range(ww):
   r,g,bl=pp[xx,yy];pp[xx,yy]=(round(r*.48),round(g*.43),round(bl*.60))
 b.paste(im,(x,y))
# Save final static pixels before constructing exact-material clipping replay.
b.save(root/'background-board-review.png');b.resize((1800,860),Image.Resampling.NEAREST).save(asset/'background.png')
animations=[]
def save2(im,name):im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST).save(asset/'anim'/name)
# Sign family follows actual gold glyphs. Cyan BUY SELL TRADE remains static.
im=Image.new('RGBA',(320,68));p=im.load()
for yy in range(68):
 for xx in range(320):
  r,g,bl=b.getpixel((292+xx,42+yy))
  if yy<22 and r>140 and g>90 and r>bl*1.5:p[xx,yy]=(r,g,bl,210)
save2(im,'sals_sign.png');period=math.pi/4
animations.append({'id':'sals_sign','type':'pulse','texture':'anim/sals_sign.png','rect':[292,42,320,68],'min_opacity':.13,'max_opacity':.26,'period':period,'phase':2.92/4-period/4,'blend':'add','still':'first'})
# Continuous2px scan plus19px faint companion; fixed physical mask is NEXT, never scrolling.
scan=Image.new('RGBA',(238,120));sd=ImageDraw.Draw(scan);sd.rectangle((0,0,237,1),fill=(167,213,223,31));sd.line((0,19,237,19),fill=(167,213,223,17));save2(scan,'security_scan.png')
animations.append({'id':'security_scan','type':'scroll','texture':'anim/security_scan.png','rect':[332,98,238,120],'speed':[0,72],'blend':'add','still':'hide'})
occ=Image.new('RGBA',(238,120));op=occ.load();count=0
for yy in range(120):
 for xx in range(238):
  x,y=332+xx,98+yy;r,g,bl=b.getpixel((x,y));inframe=342<=x<556 and 116<=y<190 and not(358<=x<540 and 132<=y<174);in_tray=408<=x<484 and 148<=y<164
  # Source-shaped metallic mesh facets outside window, not object envelopes or label plates.
  mesh=not(342<=x<556 and 116<=y<190) and max(r,g,bl)-min(r,g,bl)<66 and max(r,g,bl)>68
  if inframe or in_tray or mesh:op[xx,yy]=(r,g,bl,255);count+=1
save2(occ,'fixed_material_occlusion.png');animations.append({'id':'STATIC_OCCLUSION_fixed_material','type':'frames','texture':'anim/fixed_material_occlusion.png','rect':[332,98,238,120],'frames':1,'fps':1,'blend':'mix','still':0})
core=Image.new('RGBA',(72,14));cd=ImageDraw.Draw(core);cd.rectangle((52,3,67,9),fill=(255,184,67,180));cd.line((53,4,66,4),fill=(255,237,163,220));cd.line((53,6,66,6),fill=(255,211,111,205));save2(core,'inspection_tray_breath.png')
period=math.pi/3.4;animations.append({'id':'inspection_tray_breath','type':'pulse','texture':'anim/inspection_tray_breath.png','rect':[410,148,72,14],'min_opacity':.20,'max_opacity':.36,'period':period,'phase':-period/4,'blend':'add','still':'first'})
# Five faint high-air ribbons translated to two coherent fields, stepped pixels/no blur.
for layer,bands,speed in [(0,((5,180,0),(41,148,250),(77,116,510)),(10,.28)),(1,((23,164,140),(59,132,420)),(16,-.25))]:
 im=Image.new('RGBA',(760,88));d=ImageDraw.Draw(im)
 for j,(y,ww,start) in enumerate(bands):
  for x in range(ww):
   yy=y+round(math.sin((x+j*17)*.028)*2);taper=max(0,min(1,x/17,(ww-1-x)/17))
   for dy in range(-3,4):
    a=round(5*taper*(1-abs(dy)/4))
    if (x+dy+j)%47 not in (0,1):d.point(((start+x)%760,yy+dy),fill=(79,187,203,a))
 save2(im,f'high_air_{layer}.png');animations.append({'id':f'high_air_{layer}','type':'scroll','texture':f'anim/high_air_{layer}.png','rect':[66,81,760,88],'speed':list(speed),'opacity':.9,'blend':'add','still':'hide'})
glint=Image.new('RGBA',(8,8));gd=ImageDraw.Draw(glint);gd.line((0,4,7,4),fill=(242,199,115,155));gd.line((4,0,4,7),fill=(255,228,156,155));gd.point((4,4),fill=(255,248,203,220));save2(glint,'hardware_glint.png')
for i,(x,y) in enumerate(((150,84),(414,118),(690,154))):
 period=math.pi/4.2;animations.append({'id':f'hardware_glint_{i}','type':'pulse','texture':'anim/hardware_glint.png','rect':[x-4,y-4,8,8],'min_opacity':.18,'max_opacity':.36,'period':period,'phase':i*1.7/4.2-period/4,'blend':'add','still':'hide'})
for i,color in enumerate(((93,170,184),(181,134,65),(161,83,153),(88,166,185),(188,141,73),(152,84,154),(94,168,183))):
 width=72-4*i;im=Image.new('RGBA',(width,2));p=im.load()
 for x in range(width):
  a=round(110*max(0,min(1,x/9,(width-1-x)/9)));a=round(a*.4) if (x+3*i)%19 in (0,1) else a;p[x,0]=(*color,a)
  if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
 save2(im,f'floor_glint_{i}.png');speed=18+2.5*i;y=274+(i%4)*14;animations.append({'id':f'floor_glint_{i}','type':'mover','texture':f'anim/floor_glint_{i}.png','size':[width,2],'from':[-90,y],'to':[950,y],'duration':1040/speed,'phase':137*i/speed,'opacity':.18,'blend':'add','still':'hide'})
for name,(x,y,ww,hh),_ in fronts:b.crop((x,y,x+ww,y+hh)).convert('RGBA').resize((2*ww,2*hh),Image.Resampling.NEAREST).save(asset/'counters'/f'{name}.png')
assert len(animations)==16
manifest={'schema':'bth.environment_art/v1','environment_id':'pawn_shop','board_size':[900,430],'pixel_scale':2,'background':{'texture':'background.png'},'animations':animations,'counters':{name:{'texture':f'counters/{name}.png','bleed':[0,0,0,0]} for name,_,_ in fronts}}
mp=root/'data/art/environments/pawn_shop.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
(root/'data/art/environments/index.json').write_text(json.dumps({'enabled':['gas_station_casino','corner_store','back_alley','motel','bar','pawn_shop']},indent=2)+'\n')
validate_manifest(manifest,'pawn_shop',asset,counter_rectangles(REPO,'pawn_shop'))
files={}
for p in sorted(list((root/'assets').rglob('*.png'))+list((root/'data').rglob('*.json'))):
 e={'sha256':sha(p),'bytes':p.stat().st_size}
 if p.suffix=='.png':
  im=Image.open(p);e.update(size=list(im.size),mode=im.mode)
  if im.mode=='RGBA':e['alpha_extrema']=list(im.getchannel('A').getextrema())
 files[p.relative_to(root).as_posix()]=e
package_sha=hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(files.items())).encode()).hexdigest()
record={'package_id':'pawn_shop-v1-r2','status':'SEALED_TRIAL_NOT_PASSED','package_sha256':package_sha,'files':files,'sources':{str(p):sha(p) for p in (raw,floorpath)},'frozen_generation_inputs':json.loads((artist/'inputs/input-provenance-generation-v1.json').read_text()),'assembly':{'floor_same_scale_crop':[0,140,900,324],'horizon':246,'toe_kick':[58,236,792,10],'flat_runner':[58,246,792,52],'case_lips':[[78,y,174,5] for y in (98,126,154,182)],'window':[342,116,214,74],'inner_glass':[358,132,182,42],'tray':[408,148,76,16],'main_front':[316,262,268,42],'right_front':[600,184,246,28]},'motion_roster':{'moving_entries':15,'static_occlusion_entries':1,'static_id':'STATIC_OCCLUSION_fixed_material','static_alpha_values':[0,255],'static_board_pixels':count,'order':'sign,scan,exact-BG static material replay,tray,air,glints,floor','no_scan_equivalence':'all opaque static replay pixels are exact fitted BG pixels; native no-scan equality pending'},'notes':['Source-preserving exact900 grid to2x. Own plum/cold glass/worn metal/old wood identity; no imported Bar/Gas materials.','Generated raised fascia/deep mat removed. Real toe-kick ends246; single same-scale184px floor crop. Runner is flat rubber texture with no raised face/bevel/step.','Left old source ridges removed before exact98/126/154/182 thin lips. Exact main and right fronts match background crops.','Main+19px companion scroll at72px/s; fixed physical frame/tray/source-shaped mesh exact-BG replay remains stationary. STATIC entry is not moving motif.','Separate compact right amber tray breath within unchanged fixture; left aperture/glass remain quiet for measured cyan Private Appraisal union. Natural live coverage must be proven in actual pixels.','Two faint high fields translate five fluorescent-air ribbons; effective peak5/255*.9=.0176471, not room fog. Seven local dry-floor movers consolidate approved shared reflection families.','No live stock,cast,game labels or baked light motion. Production/placement code unchanged. Actual composite acceptance pending.']}
(root/'package-seal.json').write_text(json.dumps(record,indent=2));(root/'edit-record.json').write_text(json.dumps(record,indent=2));print(json.dumps({'package':str(root),'package_sha256':package_sha,'background_sha256':files['assets/art/environments/pawn_shop/background.png']['sha256'],'files':len(files),'entries':len(animations),'moving':15,'static':1,'static_mask_pixels':count,'validator':'PASS'}))


