# Pawn strict173 pre-art metadata

Unchanged strict173 production app, code, data, placement and art index. Actual Base and each current initial settled scenario. Production practice menu generation, unchanged Engine same-initial-state commit, RunState physical-membership publication and native arrivals. No work/outcome transitions. Observational helpers only. This is PRE-ART layout metadata, not a Pawn art PASS or work/outcome coverage.

Checks:449; findings:0; contexts:4; selected cards:53.

Board900x430;1800x860 replay doubles coordinates. All label/model/hit/footprint rectangles from actual production canvas, not p9 positions or name-length guesses.

Model/body/label/hit rectangles are geometric envelopes, not exact opaque masks. Label cells contain transparent space; text uses alpha0.72 (active0.94), disabled0.56. Hit rectangles are interaction targets, not paint. Sprite shadows/glows may extend beyond model bounds. Free regions are outside reported envelopes, not a final pixel-composite visibility pass. No opaque body-mask claim is made; the named static room primitives come from unchanged source.

All contact definitions are copied as data, not permission to invent visible furniture for support names. Only actual Pawn painted fixtures are in physical_regions. Pawn foreground fronts [316,262,268,42] and [600,184,246,28] are replayed between Behind and Standard; labels are drawn last. Model/front intersections do not measure opaque pixel occlusion.

## Contacts and physical supports
- {"id": "estate_top_shelf", "x0": 54, "x1": 846, "top_y": 70, "front_y": 88, "classes": ["surface_item"]}
- {"id": "scenario_estate_rail", "x0": 326, "x1": 846, "top_y": 70, "front_y": 88, "classes": ["surface_item"]}
- {"id": "estate_left_upper_shelf", "x0": 54, "x1": 300, "top_y": 104, "front_y": 136, "classes": ["surface_item"]}
- {"id": "estate_left_lower_shelf", "x0": 54, "x1": 300, "top_y": 184, "front_y": 212, "classes": ["surface_item"]}
- {"id": "scenario_serial_rail", "x0": 54, "x1": 174, "top_y": 184, "front_y": 212, "classes": ["surface_item"]}
- {"id": "scenario_records_rail", "x0": 174, "x1": 300, "top_y": 184, "front_y": 232, "classes": ["behind_counter_person"]}
- {"id": "estate_center_upper_shelf", "x0": 326, "x1": 574, "top_y": 104, "front_y": 136, "classes": ["surface_item"]}
- {"id": "estate_center_lower_shelf", "x0": 326, "x1": 574, "top_y": 176, "front_y": 204, "classes": ["surface_item"]}
- {"id": "pawn_counter", "x0": 316, "x1": 584, "top_y": 262, "front_y": 304, "classes": ["surface_item", "behind_counter_person"], "foreground_art_id": "pawn_counter"}
- {"id": "estate_right_upper_shelf", "x0": 600, "x1": 846, "top_y": 104, "front_y": 136, "classes": ["surface_item"]}
- {"id": "estate_right_lower_shelf", "x0": 600, "x1": 846, "top_y": 184, "front_y": 212, "classes": ["surface_item", "behind_counter_person"], "foreground_art_id": "pawn_estate_shelf"}
- {"id": "scenario_hold_rail", "x0": 600, "x1": 720, "top_y": 184, "front_y": 212, "classes": ["surface_item"]}

## __none
Capture clock 6.75935461904768; process frame 2491; settled remaining transits 0.
- item:false_bottom_cup: 'False-Bottom Cup'; label[146.6, 62.0, 104.8, 15.0]; model[163.0, 79.0, 72.0, 48.0]; hit[163.0, 79.0, 72.0, 48.0]; layer0; selected title'False-Bottom Cup'.
- item:payment_calendar: 'Payment Calendar'; label[64.6, 36.0, 104.8, 15.0]; model[81.0, 79.0, 72.0, 48.0]; hit[81.0, 79.0, 72.0, 48.0]; layer0; selected title'Payment Calendar'.
- item:payout_pamphlet: 'Payout Pamphlet'; label[758.5, 116.0, 99.0, 15.0]; model[772.0, 133.0, 72.0, 48.0]; hit[772.0, 133.0, 72.0, 48.0]; layer0; selected title'Payout Pamphlet'.
- item:edge_sort_loupe: 'Edge-Sort Loupe'; label[672.5, 184.0, 99.0, 15.0]; model[686.0, 134.0, 72.0, 48.0]; hit[686.0, 134.0, 72.0, 48.0]; layer0; selected title'Edge-Sort Loupe'.
- item:thermos_black_coffee: 'Thermos of Black Coffee'; label[54.0, 184.0, 126.0, 26.0]; model[81.0, 134.0, 72.0, 48.0]; hit[81.0, 134.0, 72.0, 48.0]; layer0; selected title'Thermos of Black Coffee'.
- item:lucky_reel_grease: 'Lucky Reel Grease'; label[143.7, 211.0, 110.6, 15.0]; model[163.0, 135.0, 72.0, 48.0]; hit[163.0, 135.0, 72.0, 48.0]; layer0; selected title'Lucky Reel Grease'.
- event:chatty_clerk: 'Chatty Clerk'; label[407.2, 113.0, 81.6, 15.0]; model[416.0, 130.0, 64.0, 82.0]; hit[416.0, 130.0, 64.0, 82.0]; layer-1; selected title'Chatty Clerk'.
- game:slot: 'Slot'; label[515.9999, 208.0, 48.0, 15.0]; model[510.9999, 225.0, 58.0, 44.0]; hit[517.9999, 224.56, 44.0, 44.0]; layer0; selected title'Slot'.
- staff:pawn_counter_sal: 'Sal'; label[424.0, 288.0, 48.0, 15.0]; model[412.0, 214.0, 72.0, 72.0]; hit[412.0, 214.0, 72.0, 72.0]; layer-1; selected title'Sal'.
- travel:leave: 'Leave'; label[844.0, 341.0, 40.0, 15.0]; model[836.0, 358.0, 64.0, 72.0]; hit[836.0, 358.0, 64.0, 72.0]; layer0; selected title'Leave'.

Authored hidden/hosted exclusions: []

## pawn_shop_estate_lot_day
Capture clock 18.8625832323239; process frame 5739; settled remaining transits 0.
- item:basic_strategy_card: 'Basic Strategy Card'; label[55.9, 62.0, 122.2, 15.0]; model[81.0, 79.0, 72.0, 48.0]; hit[81.0, 79.0, 72.0, 48.0]; layer0; selected title'Basic Strategy Card'.
- item:splitter_token: 'Splitter Token'; label[152.4, 36.0, 93.2, 15.0]; model[163.0, 79.0, 72.0, 48.0]; hit[163.0, 79.0, 72.0, 48.0]; layer0; selected title'Splitter Token'.
- item:cashout_envelope: 'Cashout Envelope'; label[64.6, 184.0, 104.8, 15.0]; model[81.0, 134.0, 72.0, 48.0]; hit[81.0, 134.0, 72.0, 48.0]; layer0; selected title'Cashout Envelope'.
- item:thermos_black_coffee: 'Thermos of Black Coffee'; label[136.0, 211.0, 126.0, 26.0]; model[163.0, 135.0, 72.0, 48.0]; hit[163.0, 135.0, 72.0, 48.0]; layer0; selected title'Thermos of Black Coffee'.
- item:lucky_ladies_compact: 'Lucky Ladies Compact'; label[659.0, 106.0, 126.0, 26.0]; model[686.0, 134.0, 72.0, 48.0]; hit[686.0, 134.0, 72.0, 48.0]; layer0; selected title'Lucky Ladies Compact'.
- item:roadside_map: 'Roadside Map'; label[600.2, 92.0, 81.6, 15.0]; model[605.0, 135.0, 72.0, 48.0]; hit[605.0, 135.0, 72.0, 48.0]; layer0; selected title'Roadside Map'.
- item:false_bottom_cup: 'False-Bottom Cup'; label[622.6, 248.0, 104.8, 15.0]; model[639.0, 198.0, 72.0, 48.0]; hit[639.0, 198.0, 72.0, 48.0]; layer0; selected title'False-Bottom Cup'.
- staff:pawn_counter_sal: 'Sal'; label[424.0, 197.0, 48.0, 15.0]; model[412.0, 214.0, 72.0, 72.0]; hit[412.0, 214.0, 72.0, 72.0]; layer-1; selected title'Sal'.
- event:chain06_sal_estate_item: 'Estate Map'; label[731.0, 247.0, 70.0, 15.0]; model[730.0, 197.0, 72.0, 48.0]; hit[730.0, 197.0, 72.0, 48.0]; layer0; selected title'Estate Map'.
- game:slot: 'Slot'; label[515.9999, 208.0, 48.0, 15.0]; model[510.9999, 225.0, 58.0, 44.0]; hit[517.9999, 224.56, 44.0, 44.0]; layer0; selected title'Slot'.
- scenario::estate_appraiser: 'Estate Appraiser'; label[314.6, 185.0, 104.8, 15.0]; model[331.0, 202.0, 72.0, 80.0]; hit[331.0, 202.0, 72.0, 80.0]; layer-1; selected title'Estate Appraiser'.
- travel:leave: 'Leave'; label[844.0, 341.0, 40.0, 15.0]; model[836.0, 358.0, 64.0, 72.0]; hit[836.0, 358.0, 64.0, 72.0]; layer0; selected title'Leave'.
- scenario::estate_cart: 'Establish the estate provenance'; label[200.0, 185.0, 126.0, 26.0]; model[217.0, 239.0, 92.0, 64.0]; hit[217.0, 239.0, 92.0, 64.0]; layer0; selected title'Establish the estate provenance'.
- scenario::pawn_shop_estate_lot_day_exit: 'Marked clear exit'; label[812.7, 236.0, 71.3, 15.0]; model[836.0, 253.0, 64.0, 72.0]; hit[836.0, 253.0, 64.0, 72.0]; layer0; selected title'Marked clear exit'.
- scenario::provenance_marks: 'Provenance Marks'; label[265.6, 362.0, 104.8, 15.0]; model[282.0, 312.0, 72.0, 48.0]; hit[282.0, 312.0, 72.0, 48.0]; layer0; selected title'Provenance Marks'.

Authored hidden/hosted exclusions: []

## pawn_shop_sals_mood
Capture clock 43.3666666666692; process frame 12120; settled remaining transits 0.
- item:xray_glasses: 'X-Ray Glasses'; label[73.3, 62.0, 87.4, 15.0]; model[81.0, 79.0, 72.0, 48.0]; hit[81.0, 79.0, 72.0, 48.0]; layer0; selected title'X-Ray Glasses'.
- item:tab_detector: 'Tab Detector'; label[158.2, 36.0, 81.6, 15.0]; model[163.0, 79.0, 72.0, 48.0]; hit[163.0, 79.0, 72.0, 48.0]; layer0; selected title'Tab Detector'.
- item:ledger_pencil: 'Ledger Pencil'; label[73.3, 184.0, 87.4, 15.0]; model[81.0, 134.0, 72.0, 48.0]; hit[81.0, 134.0, 72.0, 48.0]; layer0; selected title'Ledger Pencil'.
- item:pawn_receipt_sleeve: 'Pawn Receipt Sleeve'; label[137.9, 211.0, 122.2, 15.0]; model[163.0, 135.0, 72.0, 48.0]; hit[163.0, 135.0, 72.0, 48.0]; layer0; selected title'Pawn Receipt Sleeve'.
- item:neon_players_charm: "Neon Player's Charm"; label[660.9, 117.0, 122.2, 15.0]; model[686.0, 134.0, 72.0, 48.0]; hit[686.0, 134.0, 72.0, 48.0]; layer0; selected title"Neon Player's Charm".
- item:cold_quarters: 'Cold Quarters'; label[764.3, 183.0, 87.4, 15.0]; model[772.0, 133.0, 72.0, 48.0]; hit[772.0, 133.0, 72.0, 48.0]; layer0; selected title'Cold Quarters'.
- staff:pawn_counter_sal: 'Sal'; label[424.0, 288.0, 48.0, 15.0]; model[412.0, 214.0, 72.0, 72.0]; hit[412.0, 214.0, 72.0, 72.0]; layer-1; selected title'Sal'.
- event:chatty_clerk: 'Chatty Clerk'; label[407.2, 113.0, 81.6, 15.0]; model[416.0, 130.0, 64.0, 82.0]; hit[416.0, 130.0, 64.0, 82.0]; layer-1; selected title'Chatty Clerk'.
- game:slot: 'Slot'; label[515.9999, 208.0, 48.0, 15.0]; model[510.9999, 225.0, 58.0, 44.0]; hit[517.9999, 224.56, 44.0, 44.0]; layer0; selected title'Slot'.
- scenario::private_appraisal: 'Private Appraisal'; label[310.7, 138.0, 110.6, 15.0]; model[330.0, 155.0, 72.0, 48.0]; hit[330.0, 155.0, 72.0, 48.0]; layer0; selected title'Private Appraisal'.
- travel:leave: 'Leave'; label[844.0, 341.0, 40.0, 15.0]; model[836.0, 358.0, 64.0, 72.0]; hit[836.0, 358.0, 64.0, 72.0]; layer0; selected title'Leave'.
- scenario::sal_shopkeeper: 'Sal Shopkeeper'; label[319.4, 288.0, 93.2, 15.0]; model[330.0, 206.0, 72.0, 80.0]; hit[330.0, 206.0, 72.0, 80.0]; layer-1; selected title'Sal Shopkeeper'.
- scenario::unfinished_jobs: "Read and answer Sal's shift"; label[385.0, 341.0, 126.0, 26.0]; model[412.0, 291.0, 72.0, 48.0]; hit[412.0, 291.0, 72.0, 48.0]; layer0; selected title"Read and answer Sal's shift".
- scenario::pawn_shop_sals_mood_exit: 'Marked clear exit'; label[812.7, 268.0, 71.3, 15.0]; model[836.0, 285.0, 64.0, 72.0]; hit[836.0, 285.0, 64.0, 72.0]; layer0; selected title'Marked clear exit'.

Authored hidden/hosted exclusions: []

## pawn_shop_serial_check_day
Capture clock 31.2666666666678; process frame 8826; settled remaining transits 0.
- item:lucky_ladies_compact: 'Lucky Ladies Compact'; label[54.0, 51.0, 126.0, 26.0]; model[81.0, 79.0, 72.0, 48.0]; hit[81.0, 79.0, 72.0, 48.0]; layer0; selected title'Lucky Ladies Compact'.
- item:coin_return_shim: 'Coin-Return Shim'; label[146.6, 36.0, 104.8, 15.0]; model[163.0, 79.0, 72.0, 48.0]; hit[163.0, 79.0, 72.0, 48.0]; layer0; selected title'Coin-Return Shim'.
- item:card_counters_notes: "Counter's Notes"; label[67.5, 184.0, 99.0, 15.0]; model[81.0, 134.0, 72.0, 48.0]; hit[81.0, 134.0, 72.0, 48.0]; layer0; selected title"Counter's Notes".
- item:tarot_card: 'Tarot Card'; label[164.0, 118.0, 70.0, 15.0]; model[163.0, 135.0, 72.0, 48.0]; hit[163.0, 135.0, 72.0, 48.0]; layer0; selected title'Tarot Card'.
- item:scratch_pad: 'Scratch Pad'; label[684.1, 117.0, 75.8, 15.0]; model[686.0, 134.0, 72.0, 48.0]; hit[686.0, 134.0, 72.0, 48.0]; layer0; selected title'Scratch Pad'.
- item:weighted_keyring: 'Weighted Keyring'; label[755.6, 183.0, 104.8, 15.0]; model[772.0, 133.0, 72.0, 48.0]; hit[772.0, 133.0, 72.0, 48.0]; layer0; selected title'Weighted Keyring'.
- staff:pawn_counter_sal: 'Sal'; label[424.0, 288.0, 48.0, 15.0]; model[412.0, 214.0, 72.0, 72.0]; hit[412.0, 214.0, 72.0, 72.0]; layer-1; selected title'Sal'.
- event:chatty_clerk: 'Chatty Clerk'; label[407.2, 113.0, 81.6, 15.0]; model[416.0, 130.0, 64.0, 82.0]; hit[416.0, 130.0, 64.0, 82.0]; layer-1; selected title'Chatty Clerk'.
- game:slot: 'Slot'; label[515.9999, 208.0, 48.0, 15.0]; model[510.9999, 225.0, 58.0, 44.0]; hit[517.9999, 224.56, 44.0, 44.0]; layer0; selected title'Slot'.
- scenario::hold_object: 'Wrapped Item Awaiting Serial Check'; label[139.0, 240.0, 126.0, 26.0]; model[166.0, 190.0, 72.0, 48.0]; hit[166.0, 190.0, 72.0, 48.0]; layer0; selected title'Wrapped Item Awaiting Serial Check'.
- travel:leave: 'Leave'; label[844.0, 341.0, 40.0, 15.0]; model[836.0, 358.0, 64.0, 72.0]; hit[836.0, 358.0, 64.0, 72.0]; layer0; selected title'Leave'.
- scenario::serial_station: 'Trace the held serial'; label[59.0, 266.0, 126.0, 26.0]; model[86.0, 190.0, 72.0, 48.0]; hit[86.0, 190.0, 72.0, 48.0]; layer0; selected title'Trace the held serial'.
- scenario::records_clerk: 'Records Clerk'; label[318.3, 188.0, 87.4, 15.0]; model[326.0, 205.0, 72.0, 80.0]; hit[326.0, 205.0, 72.0, 80.0]; layer-1; selected title'Records Clerk'.
- scenario::pawn_shop_serial_check_day_exit: 'Marked clear exit'; label[812.7, 264.0, 71.3, 15.0]; model[836.0, 281.0, 64.0, 72.0]; hit[836.0, 281.0, 64.0, 72.0]; layer0; selected title'Marked clear exit'.

Authored hidden/hosted exclusions: []

## Initial scenario name bands
- pawn_shop_estate_lot_day: scenario::estate_appraiser 'Estate Appraiser' label[314.6, 185.0, 104.8, 15.0] model[331.0, 202.0, 72.0, 80.0].
- pawn_shop_estate_lot_day: scenario::estate_cart 'Establish the estate provenance' label[200.0, 185.0, 126.0, 26.0] model[217.0, 239.0, 92.0, 64.0].
- pawn_shop_estate_lot_day: scenario::pawn_shop_estate_lot_day_exit 'Marked clear exit' label[812.7, 236.0, 71.3, 15.0] model[836.0, 253.0, 64.0, 72.0].
- pawn_shop_estate_lot_day: scenario::provenance_marks 'Provenance Marks' label[265.6, 362.0, 104.8, 15.0] model[282.0, 312.0, 72.0, 48.0].
- pawn_shop_sals_mood: scenario::private_appraisal 'Private Appraisal' label[310.7, 138.0, 110.6, 15.0] model[330.0, 155.0, 72.0, 48.0].
- pawn_shop_sals_mood: scenario::sal_shopkeeper 'Sal Shopkeeper' label[319.4, 288.0, 93.2, 15.0] model[330.0, 206.0, 72.0, 80.0].
- pawn_shop_sals_mood: scenario::unfinished_jobs "Read and answer Sal's shift" label[385.0, 341.0, 126.0, 26.0] model[412.0, 291.0, 72.0, 48.0].
- pawn_shop_sals_mood: scenario::pawn_shop_sals_mood_exit 'Marked clear exit' label[812.7, 268.0, 71.3, 15.0] model[836.0, 285.0, 64.0, 72.0].
- pawn_shop_serial_check_day: scenario::hold_object 'Wrapped Item Awaiting Serial Check' label[139.0, 240.0, 126.0, 26.0] model[166.0, 190.0, 72.0, 48.0].
- pawn_shop_serial_check_day: scenario::serial_station 'Trace the held serial' label[59.0, 266.0, 126.0, 26.0] model[86.0, 190.0, 72.0, 48.0].
- pawn_shop_serial_check_day: scenario::records_clerk 'Records Clerk' label[318.3, 188.0, 87.4, 15.0] model[326.0, 205.0, 72.0, 80.0].
- pawn_shop_serial_check_day: scenario::pawn_shop_serial_check_day_exit 'Marked clear exit' label[812.7, 264.0, 71.3, 15.0] model[836.0, 281.0, 64.0, 72.0].