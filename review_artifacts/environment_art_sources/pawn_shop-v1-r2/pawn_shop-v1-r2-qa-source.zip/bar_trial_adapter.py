import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,json,hashlib,shutil
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'tools'))
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
from bth_qa_guarded_run import execute
t=sys.argv[1:];i=t.index('--') if '--' in t else len(t)
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--timeout',type=int,default=240);p.add_argument('--cold-import',action='store_true');a=p.parse_args(t[:i]);cmd=t[i+1:]
l=prepare_layout(plan_layout(root=r'E:\CodexQA\BTH',workspace=str(W),run_id='BTH-ENVART-BARTRIAL-20261114-'+a.name));validate_layout(l)
proof=json.loads((W/'bar_trial_identity.json').read_text())
for rel,h in proof['production_normalized_hashes'].items():assert hashlib.sha256((W/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==h,rel
for rel,h in proof['retained_accepted_fourroom_hashes'].items():assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==h,rel
for rel,x in proof['files'].items():assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==x['sha256'],rel
shutil.copyfile(__file__,l.evidence/'adapter.py');(l.evidence/'identity.json').write_text(json.dumps(proof,indent=2))
for f in W.glob('tools/envart_bar_*'):
    if f.is_file():shutil.copyfile(f,l.evidence/f.name)
cmd=[x.replace('{workspace}',str(W)).replace('{evidence}',str(l.evidence)) for x in cmd]
if not cmd:print('PREPARED',l.evidence);sys.exit(0)
override=W/'override.cfg';policy=b'[editor]\nimport/use_multiple_threads=false\n\n[threading]\nworker_pool/max_threads=1\n'
if a.cold_import:
    with override.open('xb') as f:f.write(policy)
try:result=execute(l,cmd,timeout=a.timeout)
finally:
    if a.cold_import and override.read_bytes()==policy:override.unlink()
print(json.dumps({k:result.get(k) for k in ['command','exit_code','error','cleanup_errors','timed_out','active_at_release']}));print('EVIDENCE',l.evidence)
sys.exit(0 if result.get('exit_code')==0 and result.get('active_at_release')==0 and not result.get('error') and not result.get('cleanup_errors') and not result.get('timed_out') else 1)
