import sys
sys.dont_write_bytecode=True
import json,hashlib,shutil,os,re
from pathlib import Path
W=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-INTEGRATION-20261114');P=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-AUDIT-20261114/packages/pawn_shop-v1-r2');D=Path(r'E:/CodexQA/BTH/runs/BTH-ENVART-PAWNTRIAL-20261114-derive-01/evidence');O=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((W/'bar_trial_identity.json').read_text());seal=json.loads((P/'package-seal.json').read_text());assert seal['package_sha256']=='85a22382e63379b340c21121e4d78ad6d82abea17efb8a20ad876afb01cb80a3'
for rel,h in old['production_normalized_hashes'].items():assert hashlib.sha256((W/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==h,rel
keep=dict(old['retained_accepted_fourroom_hashes']);keep.update({r:v['sha256'] for r,v in old['files'].items() if r!='data/art/environments/index.json'})
for rel,h in keep.items():assert sha(W/rel)==h,rel
for rel,row in seal['files'].items():assert sha(P/rel)==row['sha256'],rel
assert json.loads((P/'data/art/environments/index.json').read_text())['enabled']==json.loads((W/'data/art/environments/index.json').read_text())['enabled']+['pawn_shop']
assert not (W/'data/art/environments/pawn_shop.json').exists()
for rel,row in seal['files'].items():
    dest=W/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/rel,dest);assert sha(dest)==row['sha256']
for rel,h in keep.items():assert sha(W/rel)==h
proof={'package_sha256':seal['package_sha256'],'files':seal['files'],'production_normalized_hashes':old['production_normalized_hashes'],'retained_accepted_fiveroom_hashes':keep,'baseline_commit':'173b235da9171a5369894bdfb5e9f901d009e018','scope':'QA-only exact PawnR2 trial; no final art PASS, target activation, commit or site update. Previous5 packs retained; no full sync.'}
(W/'pawn_trial_identity.json').write_text(json.dumps(proof,indent=2)+'\n')
a=(W/'bar_trial_adapter.py').read_text().replace('bar_trial_identity','pawn_trial_identity').replace('retained_accepted_fourroom_hashes','retained_accepted_fiveroom_hashes').replace('BTH-ENVART-BARTRIAL-20261114-','BTH-ENVART-PAWNTRIAL-20261114-').replace('tools/envart_bar_','tools/envart_pawn_')
a=a.replace('if a.cold_import:\n    with override.open','if a.cold_import:\n    validate_layout(l,extra_write_paths=(override,))\n    with override.open')
(W/'pawn_trial_adapter.py').write_text(a,encoding='utf-8')
for name in ['envart_pawn_sequence_cases.json','envart_pawn_sequence_proof_r2.gd','envart_pawn_animation_capture_r2.gd']:shutil.copyfile(D/name,W/'tools'/name)
base=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-PAWN-BASELINE-20261114');s=(base/'tools/envart_pawn_preart_metadata_lf_v2.gd').read_text();start=s.index('    var inputs: Dictionary');end=s.index('    root.size =',start);s=s[:start]+s[end:]
s=s.replace('var views: Dictionary = {}','var views: Dictionary = {}\nvar baseline: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("E:/CodexQA/BTH/runs/BTH-ENVART-PAWN-20261114-current-four-01/evidence/pawn_preart_metadata.json"))')
s=s.replace('_check(canvas.get("environment_art_pack")==null,scenario+" unchanged strict173 legacy Pawn fallback")','_check(canvas.get("environment_art_pack")!=null and canvas.get("environment_art_pack").animations.size()==16,scenario+" exact PawnR2 fifteen-moving plus one-static pack active")')
s=s.replace('var view: Dictionary = canvas.call("current_view_snapshot")','var view: Dictionary = canvas.call("current_view_snapshot")\n        _check(JSON.parse_string(JSON.stringify(view["object_layout"]))==baseline["views"][scenario]["actual_view"]["object_layout"],scenario+" exact actual geometry and labels equal strict173 preart baseline")',1)
s=s.replace('Unchanged strict173 production app, code, data, placement and art index.','Unchanged production app, code, data and placement with exact QA-only PawnR2 and prior5 packs.').replace('This is PRE-ART layout metadata','This is EARLY TRIAL layout metadata').replace('PAWN_PREART','PAWN_R2_TRIAL').replace('pawn_preart_metadata.json"),FileAccess.WRITE','pawn_r2_initial_metadata.json"),FileAccess.WRITE')
(W/'tools/envart_pawn_initial_r2.gd').write_text(s,encoding='utf-8')
shutil.copyfile(base/'scripts/ui/pixel_scene_canvas.gd',O/'pixel_scene_canvas.173b235.gd')
shutil.copyfile(W/'pawn_trial_identity.json',O/'pawn_trial_identity.json');shutil.copyfile(P/'package-seal.json',O/'package-seal.json')
print(json.dumps({'staged_files':len(seal['files']),'retained_files':len(keep),'production_unchanged':len(proof['production_normalized_hashes']),'pack_sha':proof['package_sha256']}))