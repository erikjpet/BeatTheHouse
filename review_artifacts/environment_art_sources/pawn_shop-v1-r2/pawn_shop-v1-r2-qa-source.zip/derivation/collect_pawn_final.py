import sys
sys.dont_write_bytecode=True
from pathlib import Path
import os,json,hashlib,zipfile
W=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-INTEGRATION-20261114');R=Path(r'E:/CodexQA/BTH/runs');O=Path(os.environ['BTH_QA_EVIDENCE_DIR']);PREFIX='BTH-ENVART-PAWNTRIAL-20261114-'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ev(n):return R/(PREFIX+n)/'evidence'
def read(run,name):return json.loads((ev(run)/name).read_text())
proof=json.loads((W/'pawn_trial_identity.json').read_text())
assert proof['package_sha256']=='85a22382e63379b340c21121e4d78ad6d82abea17efb8a20ad876afb01cb80a3'
for rel,h in proof['production_normalized_hashes'].items():assert hashlib.sha256((W/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==h,rel
for rel,h in proof['retained_accepted_fiveroom_hashes'].items():assert sha(W/rel)==h,rel
for rel,row in proof['files'].items():assert sha(W/rel)==row['sha256'],rel
base=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-PAWN-BASELINE-20261114');baseid=json.loads((base/'pawn_source_identity.json').read_text())
for rel,h in baseid['files'].items():assert sha(base/rel)==h,rel
assert not (base/'data/art/environments/pawn_shop.json').exists()
initial=read('r2-initial-four-01','pawn_r2_initial_metadata.json');assert not initial['findings'] and initial['checks']==445
catalog=json.loads((W/'tools/envart_pawn_sequence_cases.json').read_text());assert catalog['counts']=={'scenarios':3,'active_phase_cases':6,'aftermath_cases':18,'primary_cases':24,'alternate_routes':30,'base_initial_additional':1}
seqs={k:read('r2-sequence-'+k+'-01','pawn_sequence_live_proof.json') for k in ('estate','serial','mood')}
for d in seqs.values():assert not d['findings'] and len(d['completed'])==8 and all(v['case_passed'] for v in d['views'].values())
allviews=[v for d in seqs.values() for v in d['views'].values()];allselected=[s for v in allviews for s in v['selected_label_evidence']];allvisuals=[s for v in allviews for s in v['source_visual_evidence']]
serial=seqs['serial']['views']['pawn_shop_serial_check_day__active_phase_work'];hidden=next(x for x in serial['source_visual_evidence'] if x['id']=='scenario::serial_station');assert not hidden['room_visible'] and not hidden['actual_objects'] and not hidden['actual_geometry'] and not hidden['present_interaction'] and hidden['source_visual']['visible']==False
estate=seqs['estate']['views']['pawn_shop_estate_lot_day__aftermath_success'];crowding={'legacy_layout_equal':estate['comparison']['layout_equal'],'reduced_legacy_layout_equal':estate['reduce_motion_comparison']['layout_equal'],'objects':[{'id':r['object']['id'],'label':r['object']['label'],'geometry':r['geometry']} for r in estate['actual_canvas_evidence'] if r['object']['id'] in ('scenario::displayed_lot','item:lucky_ladies_compact')],'scope':'Pre-existing live-object/title crowding is unchanged between strict173 legacy and PawnR2. No support, placement, art, label or gameplay correction was made.'};assert crowding['legacy_layout_equal'] and crowding['reduced_legacy_layout_equal']
composite=read('r2-full-composite-01','pawn_full_composite.json');pixels=read('r2-composite-pixels-01','pawn_actual_composite_pixels.json');assert not composite['findings'] and pixels['moving_rows_visible']==60 and pixels['static_rows_stable']==4
rm0=read('r2-full-composite-rm-01','pawn_full_composite_rm.json');rm3=read('r2-full-composite-rm-scenarios-01','pawn_full_composite_rm.json');assert not rm0['findings'] and not rm3['findings'];assert len(rm0['scenarios'])==1 and len(rm3['scenarios'])==3
probe=read('r2-native-probe-01','pawn_animation_probe.json');assert not probe['failures']
static=read('r2-static-proof-01','pawn_static_occlusion.json');assert not static['findings']
alpha=read('r2-tray-alpha-proof-01','pawn_tray_source_painted_occlusion.json');assert not alpha['source_painter_findings'];assert all(x['geometry_equal'] and x['actual_deltas_under_fully_opaque_paint']==0 and x['actual_deltas_outside_native_motif']==0 for x in alpha['rows'])
front=read('r2-counter-replay-01','pawn_counter_replay.json');assert front['ok'] and len(front['cases'])==2
floor=read('r2-floor-wrap-01','floor_wrap_probe.json');scan=read('r2-scan-wrap-01','pawn_scan_wrap.json');place=read('r2-placement-closing-01','pawn_placement_closing.json');assert not floor['failures'] and not scan['findings'] and not place['findings']
liveness=(ev('r2-mandatory-liveness-01')/'worker.log').read_text();assert 'Animation liveness without pointer input: PASS' in liveness
excerpts={k:read(n,'frames/animation_capture.json') for k,n in [('base','r2-animation-base-01'),('estate','r2-animation-estate-02')]}
for x in excerpts.values():assert x['measured_frame_count']==92 and x['actual_clock_span']>=12 and x['reduce_motion']['production_art_texture_pixels_stable']
huddiff=read('r2-rm-difference-clarify-01','rm_fullapp_difference_corrected.json');assert all(x['below_HUD_pixel_identical'] for x in huddiff['pairs'])
jobs={}
for p in sorted(R.glob(PREFIX+'*/evidence/job.json')):
    if p.parent==O:continue
    d=json.loads(p.read_text());assert d.get('active_at_release')==0 and d.get('assigned_before_execution') and not d.get('cleanup_errors') and not d.get('error') and not d.get('timed_out'),str(p)
    assert d['limits']['aggregate_job_cpu_percent']==12.0 and d['limits']['job_memory_limit_bytes']==2147483648
    if d['exit_code']!=0:assert p.parts[-3]==PREFIX+'r2-animation-estate-01' and d['exit_code']==1
    jobs[p.parts[-3]]={'path':str(p),'sha256':sha(p),'exit_code':d['exit_code'],'active_at_release':d['active_at_release'],'assigned_before_execution':d['assigned_before_execution'],'limits':d['limits'],'cleanup_errors':d['cleanup_errors']}
# Bind every immutable report and raw PNG without pretending a model rectangle is source paint.
reports={};images={}
for run in sorted(R.glob(PREFIX+'*')):
    evidence=run/'evidence'
    if evidence==O or not evidence.exists():continue
    for p in evidence.rglob('*.png'):images[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
    for p in evidence.rglob('*.json'):
        if p.name in ('identity.json','source_identity.json'):continue
        reports[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
(O/'image-manifest.json').write_text(json.dumps(images,indent=2)+'\n');(O/'report-manifest.json').write_text(json.dumps(reports,indent=2)+'\n')
# Full runtime source archive based on the proven cumulative archive, plus exact new Pawn payloads/helpers.
oldman=json.loads((R/'BTH-ENVART-BARTRIAL-20261114-r4-final-summary-01/evidence/qa-source-archive-manifest.json').read_text())
sources={rel:W/rel for rel in oldman if not rel.startswith(('baseline/','derivation/'))}
for rel in proof['files']:sources[rel]=W/rel
for p in (W/'tools').glob('envart_pawn_*'):
    if p.is_file():sources[p.relative_to(W).as_posix()]=p
for name in ['pawn_trial_identity.json','pawn_trial_adapter.py']:sources[name]=W/name
sources['baseline/pixel_scene_canvas.173b235.gd']=base/'scripts/ui/pixel_scene_canvas.gd';sources['baseline/pawn_source_identity.json']=base/'pawn_source_identity.json'
for p in ev('prepare-01').glob('*.py'):sources['derivation/'+p.name]=p
manifest={rel:{'sha256':sha(p),'bytes':p.stat().st_size} for rel,p in sorted(sources.items())}
with zipfile.ZipFile(O/'qa-source-archive.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
    for rel,p in sorted(sources.items()):z.write(p,rel)
(O/'qa-source-archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary={'status':'NATIVE_TECHNICAL_PASS_PENDING_FINAL_AUDITOR_ART_ACCEPTANCE','package_sha256':proof['package_sha256'],'sealed_files':len(proof['files']),'moving_entries':15,'static_occlusion_entries':1,'cumulative_prior5_files_verified':len(proof['retained_accepted_fiveroom_hashes']),'production_normalized_files_verified':len(proof['production_normalized_hashes']),'strict_baseline_files_reverified':len(baseid['files']),'c5_raw_overrides_sha256':sha(W/'data/environments/developer_placement_overrides.json'),'initial':{'contexts':4,'checks':initial['checks'],'findings':initial['findings'],'actual_selected_titles':sum(len(v['selected_label_evidence']) for v in initial['views'].values())},'source_contexts':{'counts':catalog['counts'],'catalog_sha256':sha(W/'tools/envart_pawn_sequence_cases.json'),'native_checks':sum(d['checks'] for d in seqs.values()),'findings':[],'actual_selected_title_occurrences':len(allselected),'unique_selected_ids':len({x['id'] for x in allselected}),'Runtime_visual_occurrences':len(allvisuals),'room_visible_Runtime_occurrences':sum(x['room_visible'] for x in allvisuals),'source_hidden_exclusion':{'id':'scenario::serial_station','case':'pawn_shop_serial_check_day__active_phase_work','role':'primary_task','hosted_control':False,'source_hide_ref':'data/environments/scenario_sequences/env06_7_shops_streets.json#/scenarios/10/sequence/phase_graph/phases/1/scene_ops/5','visible':False,'enabled':hidden['source_visual']['enabled'],'presentation_mode':'room','actual_objects':0,'actual_geometry':0,'present_direct_interaction':False,'live_task_object':'scenario::hold_object','live_task_selected_title':'Trace the held serial'},'other_hosted_or_nonroom_exclusions':0,'alternative_routes_source_cataloged_not_executed':30},'legacy_crowding':crowding,'animation':{'native_entry_probe_checks':probe['checks'],'full_composite_checks':composite['checks'],'moving_context_pairs_visible':pixels['moving_rows_visible'],'static_context_pairs_stable':pixels['static_rows_stable'],'full_composite_RM_checks':rm0['checks']+rm3['checks'],'full_composite_RM_entry_context_pairs':64,'excerpts':{k:{'frames':x['measured_frame_count'],'actual_clock_span':x['actual_clock_span'],'native_art_RM_stable':x['reduce_motion']['production_art_texture_pixels_stable'],'raw_fullapp_RM_stable':x['reduce_motion']['full_app_pixels_stable']} for k,x in excerpts.items()},'raw_fullapp_RM_difference':huddiff,'source_painted_tray':alpha},'static_occlusion':static,'two_counter_replay':front,'floor_wrap':{'checks':floor['checks'],'failures':floor['failures']},'scan_wrap':scan,'placement_closing':{'checks':place['checks'],'findings':place['findings'],'open_hours':place['open_hours']},'mandatory_no_pointer_liveness':'PASS','jobs':jobs,'raw_image_count':len(images),'bound_report_count':len(reports),'source_archive_files':len(manifest),'source_archive_zip_sha256':sha(O/'qa-source-archive.zip'),'preserved_diagnostics':['prepare-01 was admitted without a worker; one attempted guard run with its occupied ID was rejected before child creation. Derivation then used a fresh admitted run.','Estate animation attempt01 parsed no scene because the QA observer redeclared an inherited constant. Failed raw receipt preserved, observer-only correction and fresh attempt02 passed.','Base16-entry RM diagnostic and three-scenario48-entry supplement are separate. Inherited old comment mentioning eight contexts is not a coverage claim; actual four contexts/64 pairs are explicitly reconciled here.','First RM difference analysis guessed the wrong HUD element. Corrected RGB-bound receipt identifies only the analog-clock hand pixels; original report preserved and not relied upon.'],'scope_limits':['No final art acceptance, target branch edit, commit, TEST activation, main/NEXT move or site change by this worker.','24 actual contexts cover six stable active phase layouts and18 unique aftermath visual families;30 alternate authored resolution routes are source-cataloged, not executed here.','No UI-click, gameplay/save/revisit, real-service/sweep/travel E2E claim. Supported Runtime command/fact fixtures are followed by unchanged Engine/RunState physical membership publication.','Fixed-clock per-entry pairs and QA transparent production-painter masks complement, and do not substitute for, normal92-frame autonomous Base andEstate excerpts. No asset alpha/speed/contrast amplification, forced actor positions or disabled processing.','Tray is partially covered/attenuated in Base/Serial/Mood with nonzero residuals; Estate is the meaningful exposed demonstration.','All640? No: exact64 RM entry-context pairs and60 moving entry-context pairs. Static replay is never counted as motion.']}
summary['scope_limits'][-1]='Exact64 RM entry-context pairs and60 moving entry-context pairs. Static replay is never counted as motion.'
(O/'pawn_r2_native_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'package_sha256':proof['package_sha256'],'initial_checks':initial['checks'],'source_checks':summary['source_contexts']['native_checks'],'source_cases':24,'actual_selected_title_occurrences':len(allselected),'moving_context_pairs_visible':60,'RM_entry_context_pairs':64,'all_prior_jobs_drained':len(jobs),'source_archive_files':len(manifest),'source_archive_zip_sha256':summary['source_archive_zip_sha256'],'summary_sha256':sha(O/'pawn_r2_native_summary.json'),'raw_images':len(images)}))