import sys
sys.dont_write_bytecode=True
from pathlib import Path
import os,json
W=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-INTEGRATION-20261114');O=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
def put(n,s):
    (W/'tools'/n).write_text(s,encoding='utf-8');(O/n).write_text(s,encoding='utf-8')
def pawn(s):return s.replace('"bar"','"pawn_shop"').replace('bar_','pawn_').replace('Bar','Pawn').replace('BAR','PAWN').replace('r4','r2').replace('==17','==16').replace('17-entry','16-entry').replace('Bar17','Pawn16').replace('Pawn17','Pawn16').replace('all17','all16')
s=(W/'tools/envart_pawn_animation_capture_r2.gd').read_text();s=s.replace('const PreviewCanvasScript :=','const ScenarioEngineScript := preload("res://scripts/core/scenario_engine.gd")\nconst PreviewCanvasScript :=')
mark='    var canvas: Control = app.get("environment_canvas")'
block='''    if scenario != "__none":
        var run_state: Variant = app.get("run_state")
        var candidate: Dictionary = run_state.current_environment.duplicate(true)
        var definition: Dictionary = candidate.get("scenario_sequence_definition",{})
        var current: Dictionary = candidate.get("scenario_sequence_state",{}).duplicate(true)
        var committed: Dictionary = ScenarioEngineScript._commit_sequence_candidate(candidate,candidate.duplicate(true),definition,{"ok":true,"state":current,"errors":[]})
        var resolved: Dictionary = run_state.call("_publish_scenario_membership_candidate",candidate,committed,"qa_initial_same_state") if bool(committed.get("ok",false)) else committed
        if not bool(resolved.get("ok",false)):
            push_error("Normal initial publication failed")
            quit(1)
            return
        app.call("_set_current_screen","ENVIRONMENT")
        app.call("_clear_selected_game_action")
        app.call("_render_environment_screen")
'''
s=s.replace(mark,block+mark,1).replace('    var reduced_view: Dictionary = canvas.call("current_view_snapshot")','    var reduced_arrival := await _settle_production_arrivals(canvas)\n    var reduced_view: Dictionary = canvas.call("current_view_snapshot")').replace('result["reduce_motion"] = {','result["reduce_motion"] = {"natural_arrival":reduced_arrival,')
put('envart_pawn_animation_capture_settled_r2.gd',s)
for reduced in (False,True):
    name='envart_bar_full_composite'+('_rm' if reduced else '')+'_r4.gd';s=pawn((W/'tools'/name).read_text())
    s=s.replace('            solo.animations.append(entry)','            for original_entry in full_pack.animations:\n                if original_entry.id==entry.id or original_entry.id=="STATIC_OCCLUSION_fixed_material":\n                    solo.animations.append(original_entry)')
    s=s.replace('entry.duration*0.5','entry.duration*0.12')
    if not reduced:
        s=s.replace('            _check(ia.get_data()!=ib.get_data(),scenario+"/"+entry.id+" real full-composite pixels change")','            if entry.id=="STATIC_OCCLUSION_fixed_material":\n                _check(ia.get_data()==ib.get_data(),scenario+" static material replay stays pixel-identical")')
        end='    app.queue_free()'
        check='''    for moving_entry in full_pack.animations:
        if moving_entry.id=="STATIC_OCCLUSION_fixed_material":
            continue
        var visible_somewhere := false
        for context in results:
            for row in context["entries"]:
                if row["id"]==moving_entry.id and bool(row["visible_composite_change"]):
                    visible_somewhere = true
        _check(visible_somewhere,moving_entry.id+" actual final-composite motion visible in at least one current context")
'''
        s=s.replace(end,check+end,1)
    s=s.replace('entries.append({"id":entry.id,','entries.append({"role":"static_occlusion" if entry.id=="STATIC_OCCLUSION_fixed_material" else "moving","id":entry.id,')
    s=s.replace('original single-entry art bytes','original single moving-entry bytes plus exact static material replay in production order')
    put('envart_pawn_full_composite'+('_rm' if reduced else '')+'_r2.gd',s)
s=pawn((W/'tools/envart_bar_floor_wrap_r4.gd').read_text());put('envart_pawn_floor_wrap_r2.gd',s)
s=pawn((W/'tools/envart_bar_counter_replay_r4.gd').read_text()).replace('["pawn_main_counter"]','["pawn_counter","pawn_estate_shelf"]');put('envart_pawn_counter_replay_r2.gd',s)
s=pawn((W/'tools/envart_bar_placement_closing_r4.gd').read_text()).replace('hours.get("open_minute")==660 and hours.get("close_minute")==180','hours.get("open_minute")==540 and hours.get("close_minute")==1260').replace('open11AM/close3AM','open9AM/close9PM').replace('posmod(179-','posmod(1259-').replace('open at2:59AM','open at8:59PM').replace('Normal3AM','Normal9PM').replace('clock_to_259','clock_to_2059').replace('clock_to_300','clock_to_2100');put('envart_pawn_placement_closing_r2.gd',s)
s=pawn((W/'tools/envart_bar_glint_masks_r4.gd').read_text()).replace('r2-full-composite-01','r2-full-composite-01').replace('        if ctx["scenario"] not in ["__none","pawn_payday_rush"]:\n            continue\n','').replace('=="warm_glint_0"','=="inspection_tray_breath"');put('envart_pawn_source_paint_r2.gd',s)
# Native isolated-entry proof: exact occluder included in production order, static independently exempt from motion.
s=pawn((W/'tools/envart_bar_animation_probe_r4.gd').read_text()).replace('Exact17animation','Exact16entries (15 moving, one static)')
s=s.replace('        solo.animations.append(entry)','        for original_entry in pack.animations:\n            if original_entry.id==entry.id or original_entry.id=="STATIC_OCCLUSION_fixed_material":\n                solo.animations.append(original_entry)')
s=s.replace('        _check(live_changes,entry.id+" makes an actual visible native-renderer pixel change")','        _check(not live_changes if entry.id=="STATIC_OCCLUSION_fixed_material" else live_changes,entry.id+" declared static or moving renderer behavior")').replace('rows.append({"id":entry.id,','rows.append({"role":"static_occlusion" if entry.id=="STATIC_OCCLUSION_fixed_material" else "moving","id":entry.id,')
put('envart_pawn_animation_probe_r2.gd',s)
print(json.dumps({'prepared_helpers':[p.name for p in O.glob('*.gd')],'no_product_changes':True,'runtime_executed':False}))