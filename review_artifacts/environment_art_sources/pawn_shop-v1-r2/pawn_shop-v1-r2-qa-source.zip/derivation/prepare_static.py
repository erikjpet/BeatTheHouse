import sys
sys.dont_write_bytecode=True
import os
from pathlib import Path
W=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-INTEGRATION-20261114');O=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
s='''extends SceneTree
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const RendererScript := preload("res://scripts/ui/environment_art_renderer.gd")
var checks := 0
var findings: Array[String] = []
var output := ""
func _initialize() -> void:
    output=OS.get_environment("BTH_QA_EVIDENCE_DIR")
    call_deferred("_run")
func _check(ok: bool,label: String) -> void:
    checks+=1
    if not ok:
        findings.append(label)
        push_error(label)
func _image(pack: EnvironmentArtPack,entries: Array,clock: float,reduced: bool) -> Image:
    var test := PackScript.new()
    test.environment_id=pack.environment_id
    test.background=pack.background
    test.background_rect=pack.background_rect
    for entry in entries:
        test.animations.append(entry)
    var renderer := RendererScript.new()
    root.add_child(renderer)
    renderer.configure(test)
    renderer.present(clock,reduced,false)
    for i in range(4):
        await process_frame
        await RenderingServer.frame_post_draw
    var image: Image=(renderer.get("texture") as Texture2D).get_image()
    renderer.free()
    return image
func _run() -> void:
    var pack := PackScript.load_pack("pawn_shop")
    _check(pack!=null,"Exact Pawn pack available")
    if pack==null:
        quit(1)
        return
    _check(pack.animations.size()==16,"Fifteen moving entries and one static replay")
    var scan=pack.animations[1]
    var mask=pack.animations[2]
    _check(scan.id=="security_scan" and mask.id=="STATIC_OCCLUSION_fixed_material" and pack.animations[3].id=="inspection_tray_breath","Exact scan then static physical mask then independent tray draw order")
    _check(mask.kind==PackScript.AnimationKind.FRAMES and mask.frame_count==1 and not mask.additive and not mask.still_hidden,"Static mask is one-frame mixed RGBA retained under RM")
    _check(scan.kind==PackScript.AnimationKind.SCROLL and scan.speed==Vector2(0,72),"Actual scan speed72 vertical")
    var source: Image=mask.texture.get_image()
    var bg_source: Image=pack.background.get_image()
    var start:=Vector2i(mask.rect.position*2)
    var opaque:=0
    var transparent:=0
    var other_alpha:=0
    var source_mismatch:=0
    for y in range(source.get_height()):
        for x in range(source.get_width()):
            var pixel:=source.get_pixel(x,y)
            if pixel.a==0:
                transparent+=1
            elif pixel.a==1:
                opaque+=1
                if pixel!=bg_source.get_pixel(start.x+x,start.y+y):
                    source_mismatch+=1
            else:
                other_alpha+=1
    _check(other_alpha==0 and opaque>0 and transparent>0,"Physical mask alpha is binary with genuine painted gaps")
    _check(source_mismatch==0,"All opaque mask pixels exactly match fixed BG source")
    var base:=await _image(pack,[],0,false)
    var no_scan:=await _image(pack,[mask],0,false)
    var no_scan_late:=await _image(pack,[mask],19.17,false)
    var still:=await _image(pack,[mask],0,true)
    var still_late:=await _image(pack,[mask],19.17,true)
    _check(base.get_data()==no_scan.get_data() and no_scan.get_data()==no_scan_late.get_data(),"Native no-scan replay is pixel-identical to BG and stable")
    _check(base.get_data()==still.get_data() and still.get_data()==still_late.get_data(),"Native Reduce Motion replay exactly matches unchanged BG")
    base.save_png(output.path_join("no_scan_control.png"))
    no_scan.save_png(output.path_join("static_replay_no_scan.png"))
    still.save_png(output.path_join("static_replay_reduce_motion.png"))
    var rows: Array=[]
    for clock in [0.0,0.37,1.63]:
        var raw:=await _image(pack,[scan],clock,false)
        var clipped:=await _image(pack,[scan,mask],clock,false)
        var fixed_mismatch:=0
        var gap_mismatch:=0
        var actual_scan_pixels:=0
        for y in range(source.get_height()):
            for x in range(source.get_width()):
                var actual:=clipped.get_pixel(start.x+x,start.y+y)
                if source.get_pixel(x,y).a==1:
                    if actual!=base.get_pixel(start.x+x,start.y+y):
                        fixed_mismatch+=1
                else:
                    if actual!=raw.get_pixel(start.x+x,start.y+y):
                        gap_mismatch+=1
                    if actual!=base.get_pixel(start.x+x,start.y+y):
                        actual_scan_pixels+=1
        _check(fixed_mismatch==0,"Scan occluded by exact fixed source material at clock"+str(clock))
        _check(gap_mismatch==0 and actual_scan_pixels>0,"Scan remains unchanged and visible through source-painted gaps at clock"+str(clock))
        clipped.save_png(output.path_join("clipped_scan_"+str(rows.size())+".png"))
        rows.append({"clock":clock,"fixed_mismatch":fixed_mismatch,"gap_mismatch":gap_mismatch,"actual_scan_pixels":actual_scan_pixels})
    var result: Dictionary={"checks":checks,"findings":findings,"opaque_mask_pixels":opaque,"transparent_mask_pixels":transparent,"other_alpha_pixels":other_alpha,"source_BG_mismatches":source_mismatch,"rows":rows,"scope":"Native unchanged renderer; exact one-frame binary-alpha fixed BG material replay. Static mask not counted as motion. Native no-scan and RM equivalence, exact draw order, and actual scan preserved in source-painted gaps. No production source or asset edits."}
    var f:=FileAccess.open(output.path_join("pawn_static_occlusion.json"),FileAccess.WRITE)
    f.store_string(JSON.stringify(result,"\\t"))
    f.close()
    print("PAWN_STATIC_OCCLUSION_RESULT ",JSON.stringify(result))
    PackScript.shutdown_loading()
    await process_frame
    quit(0 if findings.is_empty() else 1)
'''
(W/'tools/envart_pawn_static_occlusion_r2.gd').write_text(s,encoding='utf-8');(O/'envart_pawn_static_occlusion_r2.gd').write_text(s,encoding='utf-8')
print('STATIC_PROOF_PREPARED')