import copy, hashlib, json, os, re
from pathlib import Path
SRC=Path(r"E:\CodexQA\BTH\workspaces\BTH-ENVART-INTEGRATION-20261114")
OUT=Path(os.environ["BTH_QA_EVIDENCE_DIR"])
SEQ="data/environments/scenario_sequences/env06_7_shops_streets.json"
LEG="data/environments/scenarios.json"
SLOTS="data/environments/scenario_slot_layouts.json"
FILES=[SEQ,LEG,SLOTS,"scripts/core/scenario_sequence_catalog.gd","scripts/core/scenario_sequence_runtime.gd","scripts/core/scenario_operation_registry.gd","scripts/core/scenario_layout_resolver.gd","scripts/core/environment_slot_binder.gd","tools/environment_layout_screenshots.gd","tools/envart_back_settled_r3.gd","tools/envart_motel_sequence_proof_r1.gd"]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
hashes={f:sha(SRC/f) for f in FILES}
source=json.loads((SRC/SEQ).read_text(encoding="utf-8-sig"))
legacy=json.loads((SRC/LEG).read_text(encoding="utf-8-sig"))["pawn_shop"]
layouts=json.loads((SRC/SLOTS).read_text(encoding="utf-8-sig"))["layouts"]
ids=[x["id"] for x in legacy]
assert ids and len(set(ids))==len(ids)
entries={x["scenario_id"]:(n,x) for n,x in enumerate(source["scenarios"]) if x["scenario_id"] in ids}
assert set(entries)==set(ids)
attached={"decision_route","task_station","task_zone"}
families={"scene_ops":"scenes","actor_ops":"actors","interaction_ops":"interactions",}
def empty(): return {v:{} for v in families.values()}
def op_apply(st,op,ref):
    fam=op["family"]
    if fam not in families: return
    rows=st[families[fam]]; ident=op["stable_object_id"]; kind=op["op"]
    if kind in ("remove","despawn"):
        rows.pop(ident,None); return
    if kind in ("spawn","add","replace"):
        value=copy.deepcopy(op.get("object",op.get("actor",op.get("interaction",{}))))
        value["_source_ref"]=ref; value["_source_ops"]=[{"source_ref":ref,"operation":copy.deepcopy(op)}]
        rows[ident]=value; return
    assert ident in rows, (fam,ident,kind,ref)
    value=rows[ident]
    value["_source_ops"].append({"source_ref":ref,"operation":copy.deepcopy(op)})
    if kind in ("move","set_position"):
        for k in ("anchor_id","zone_id"):
            if k in op: value[k]=op[k]
        if fam=="actor_ops": value["authored_position_route_id"]=op.get("receipt_id","")
    elif kind in ("hide","reveal"): value["visible"]=kind=="reveal"
    elif kind in ("disable","enable"):
        value["enabled"]=kind=="enable"
        if kind=="disable": value["disabled_reason"]=op.get("disabled_reason","Unavailable.")
    elif kind.startswith("set_") and kind[4:] in ("state","appearance","pose","behavior","route"):
        value["route_id" if kind=="set_route" else kind[4:]]=op.get("route_id" if kind=="set_route" else kind[4:],"")
    else: raise AssertionError(("unsupported op",op,ref))
def apply_group(st,group,ref):
    for fam in families:
        for n,op in enumerate(group.get(fam,[])):
            op_apply(st,op,f"{ref}/{fam}/{n}")
def position_key(ident,row):
    return "|".join([ident,str(row.get("anchor_id","")),str(row.get("zone_id","")),str(row.get("authored_position_route_id",""))])
def binding(ident,row,layout):
    key=position_key(ident,row)
    for field in ("scenario_instance_slot_ids","scenario_instance_object_slot_ids"):
        for wanted in (key,ident,"scenario::"+ident):
            if wanted in layout.get(field,{}):
                return {"position_key":key,"slot_id":layout[field][wanted],"authority_field":field,"authority_key":wanted,"art_key":layout.get("scenario_instance_art_keys",{}).get(key)}
    return {"position_key":key,"slot_id":None}
def collect(st,layout):
    materials=[];actors=[];excluded=[];nonvisual=[]
    for family,target in (("scenes",materials),("actors",actors)):
        for ident,row in st[family].items():
            direct=st["interactions"].get(ident,{})
            rec={"id":ident,"source_label":row.get("label",""),"expected_label":direct.get("label",row.get("label","")),"role":row.get("role"),"state":row.get("state"),"appearance":row.get("appearance"),"anchor_id":row.get("anchor_id"),"zone_id":row.get("zone_id"),"visible":row.get("visible",True),"enabled":row.get("enabled",True),"source_ref":row["_source_ref"],"source_operations":row["_source_ops"]}
            if family=="actors":
                rec.update({k:row.get(k) for k in ("actor_id","pose","behavior","route_id","authored_position_route_id")})
            if direct: rec["direct_interaction_label"]=direct.get("label")
            if family=="scenes" and row.get("role") in attached:
                rec["exclusion"]="hosted_station_control" if row.get("role")=="task_station" else "hosted_abstract_control"
                rec["exclusion_source"]="scripts/core/environment_slot_binder.gd:48-50,1129-1150"
                rec["exact_action_host"]=layout.get("scenario_instance_action_host_ids",{}).get("scenario::"+ident)
                rec["action_ids"]=[a["id"] for a in direct.get("available_actions",[])]
                rec["hosting_rule"]="Explicit scenario_instance_action_host_ids when present; otherwise production resolver scoring selects visible enabled physical host. Hosted control labels do not replace the host label."
                excluded.append(rec);continue
            rec["binding"]=binding(ident,row,layout)
            if not row.get("visible",True):
                rec["exclusion"]="source_hidden";rec["exclusion_source"]="scene_ops hide / visible:false; disabled alone is not hidden"
                excluded.append(rec);continue
            if row.get("presentation_mode","room")!="room":
                rec["exclusion"]="source_non_room";excluded.append(rec);continue
            assert rec["binding"]["slot_id"], ("missing source slot",ident,rec["binding"])
            assert rec["expected_label"],ident
            target.append(rec)
    for fam in ():
        for ident,row in st[fam].items():
            nonvisual.append({"id":ident,"family":fam,"source_label":row.get("label"),"source_ref":row["_source_ref"],"exclusion":"No scene_ops/actor_ops visual is authored for this semantic record; no independent in-room geometry claim."})
    return {"expected_material_ids":[r["id"] for r in materials],"expected_actor_ids":[r["id"] for r in actors],"material_evidence":materials,"actor_evidence":actors,"excluded_materials":excluded,"excluded_nonvisual_records":nonvisual}
cases=[];alternates=[];summaries=[]
for sid in ids:
    index,entry=entries[sid];seq=entry['sequence'];pref=f'{SEQ}#/scenarios/{index}/sequence'
    phase_list=seq['phase_graph']['phases']; phases={p['id']:p for p in phase_list}
    active=[p for p in phase_list if not p.get('terminal',False)]
    layouts_for=[l for l in layouts if l['scenario_id']==sid and l['map_id']=='pawn_shop']
    assert len(layouts_for)==1
    layout=layouts_for[0];lidx=layouts.index(layout)
    paths={seq['phase_graph']['initial_phase']:[]};states={}; state=empty(); routes=[]
    refs={p['id']:f'{pref}/phase_graph/phases/{n}' for n,p in enumerate(phase_list)}
    for phase in active:
        pid=phase['id'];assert pid in paths
        apply_group(state,phase,refs[pid]);states[pid]=copy.deepcopy(state)
        actions={}
        for iid,row in state['interactions'].items():
            for action in row.get('available_actions',[]):actions.setdefault(action['id'],[]).append({'source_id':iid,'source_ref':row['_source_ref'],'action':action})
        case={'scenario_id':sid,'kind':'active_phase','phase':pid,'phase_label':phase.get('label'),'commands':paths[pid],'source_ref':refs[pid],'source_ops':phase.get('scene_ops',[]),'actor_source_ops':phase.get('actor_ops',[]),'phase_roles':['arrival' if pid==seq['phase_graph']['initial_phase'] else 'work'],'authored_interactions':[{'id':i,'source_ref':r['_source_ref'],'label':r.get('label'),'actions':r.get('available_actions',[])} for i,r in state['interactions'].items()],'layout_source_ref':f'{SLOTS}#/layouts/{lidx}'}
        case.update(collect(state,layout));cases.append(case)
        for bi,branch in enumerate(phase['branches']):
            cond=branch['condition']; target=phases[branch['next_phase']]; cmds=list(paths[pid]);fact=None
            if cond['type']=='command':
                origins=actions[cond['command_id']];assert origins
                values={json.dumps(a['action'].get('inputs',{}),sort_keys=True) for a in origins};assert len(values)==1
                action=origins[0]['action'];assert action['handler']=='set_local';local=action['inputs'];cmds.append(cond['command_id'])
            elif cond['type']=='fact':
                subs=[x for x in seq['fact_subscriptions'] if x['fact_type']==cond['fact_type'] and x['handler']=='set_local' and x.get('inputs',{}).get('key')=='path'];assert len(subs)==1
                local=subs[0]['inputs'];fact=copy.deepcopy(cond);origins=[]
            elif cond['type']=='local_equals':
                subs=[x for x in seq['fact_subscriptions'] if x['handler']=='set_local' and x.get('inputs',{}).get('key')==cond['key'] and x['inputs'].get('value')==cond['value']];assert len(subs)==1
                sub=subs[0];local=sub['inputs'];fact={'fact_type':sub['fact_type'],'payload_equals':sub.get('payload_equals',{})};origins=[]
            else:raise AssertionError(cond)
            if not target.get('terminal',False):
                assert fact is None and target['id'] not in paths
                paths[target['id']]=cmds;continue
            terminals=[b for b in target['branches'] if b['condition']['type']=='local_equals' and b['condition']['key']==local['key'] and b['condition']['value']==local['value']];assert len(terminals)==1
            route={'scenario_id':sid,'from_phase':pid,'commands':cmds,'terminal_phase':target['id'],'outcome':terminals[0]['outcome'],'branch_source_ref':refs[pid]+'/branches/'+str(bi),'branch':branch,'terminal_source_ref':refs[target['id']]+'/branches/'+str(target['branches'].index(terminals[0])),'terminal_branch':terminals[0],'trigger_action_origins':origins}
            if fact:route['fact']=fact
            routes.append(route)
    assert set(r['outcome'] for r in routes)==set(seq['aftermath'])
    for outcome,aftermath in seq['aftermath'].items():
        options=[r for r in routes if r['outcome']==outcome]
        if outcome=='refused': route=next(r for r in options if r['commands'][-1]=='refuse_sequence')
        else:route=max(options,key=lambda r:len(r['commands']))
        result=copy.deepcopy(states[route['from_phase']]);terminal=phases[route['terminal_phase']]
        apply_group(result,terminal,refs[terminal['id']])
        for oi,op in enumerate(seq['cleanup']['operations']):op_apply(result,op,f'{pref}/cleanup/operations/{oi}')
        assert all(not result[f] for f in ('scenes','actors','interactions'))
        aref=f'{pref}/aftermath/{outcome}';apply_group(result,aftermath,aref)
        case={'scenario_id':sid,'kind':'aftermath','outcome':outcome,'label':aftermath['label'],'commands':route['commands'],'source_ref':aref,'terminal_phase':terminal['id'],'route_evidence':route,'source_ops':aftermath.get('scene_ops',[]),'actor_source_ops':aftermath.get('actor_ops',[]),'cleanup_source_ref':pref+'/cleanup','layout_source_ref':f'{SLOTS}#/layouts/{lidx}','nonvisual_service_operations':aftermath.get('service_ops',[])}
        if 'fact' in route:case['fact']=route['fact']
        case.update(collect(result,layout));case['excluded_nonvisual_records']=[{'operation':op,'exclusion':'Service semantic operation has no independent scene/actor visual; not standalone in-room geometry.'} for op in aftermath.get('service_ops',[])];cases.append(case)
    alternates.extend(routes)
    summaries.append({'scenario_id':sid,'active_phases':[p['id'] for p in active],'active_phase_count':len(active),'aftermath_family_count':len(seq['aftermath']),'primary_case_count':len(active)+len(seq['aftermath']),'resolution_route_count':len(routes),'terminal_phases':[p['id'] for p in phase_list if p.get('terminal',False)],'sequence_source_ref':pref})
caseids=[c['scenario_id']+'__'+c['kind']+'_'+c.get('outcome',c.get('phase','')) for c in cases];assert len(caseids)==len(set(caseids))
counts={'scenarios':len(ids),'active_phase_cases':sum(c['kind']=='active_phase' for c in cases),'aftermath_cases':sum(c['kind']=='aftermath' for c in cases),'primary_cases':len(cases),'alternate_routes':len(alternates),'base_initial_additional':1}
notes=['Source-derived only. No Godot, Runtime transaction, screenshot, publication, UI, save or revisit proof yet.','Each stable active phase and each distinct authored aftermath family is represented once. Resolution is terminal/transient and not falsely counted as a stable work scene.','Other authored resolution routes are cataloged but not claimed executed; primary routes do not exhaust every lifecycle/interaction combination.','Public aftermath uses a matching subscribed public fact and its exact payload predicate, not arbitrary mutation of local path. Travel interruption uses supported travel_departed fact; neither proves an actual service/sweep/travel UI interaction.','Physical expectations cover scenario-owned visuals only; runtime observer must verify all actual room objects and selected-card titles, including base inventory and actors.','Present direct interaction label wins over source visual label; source visual label remains authoritative when no present direct interaction. Hosted labels never replace physical host labels.','Hidden, non-room and hosted controls are excluded only from source-defined evidence; disabled does not mean hidden.','Aftermath cleanup removes active scene/actor/interaction objects before publishing aftermath. Service operations without corresponding scene/actor visuals are not extra props.','Static occlusion replay is one exact-BG fixed material entry, not owner-facing motion. Verify binary alpha, exact BG at opaque pixels, scan-before-mask-before-tray ordering, no-scan equivalence and RM stability separately. Every one of the 15 actual moving entries needs real final-composite visibility in an appropriate current context.']
doc={'schema':'envart.pawn_sequence_cases/v1','source':SEQ,'source_sha256':hashes[SEQ],'source_workspace':str(SRC),'source_files_sha256':hashes,'scenario_ids':ids,'counts':counts,'scenarios':summaries,'cases':cases,'alternate_authored_routes':alternates,'notes':notes,'unsupported_routes':[]}
for f,h in hashes.items():assert sha(SRC/f)==h
path=OUT/'envart_pawn_sequence_cases.json';path.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
# Pawn observer, no copied Bar case count. These are preparatory QA files only.
helper=(SRC/'tools/envart_bar_sequence_proof_r4.gd').read_text().replace('bar','pawn').replace('Bar','Pawn').replace('BAR','PAWN').replace('r4','r2')
helper=helper.replace('"pawn")','"pawn_shop")').replace('cases.size()==58','cases.size()==int(catalog["counts"]["primary_cases"])').replace('cases.size()!=58','cases.size()!=int(catalog["counts"]["primary_cases"])').replace('"full_catalog_count":58','"full_catalog_count":int(catalog["counts"]["primary_cases"])').replace('Exact source-derived 58-case Pawn catalog','Exact source-derived Pawn catalog count').replace('Exact182 baseline','Exact173 baseline')
helper=helper.replace('if argument == "--smoke-pawn-work":\n            cases = cases.filter(func(c): return c["scenario_id"] == "pawn_wake" and c.get("phase", "") == "work_1")','if argument == "--smoke-pawn-work":\n            cases = cases.filter(func(c): return c["scenario_id"] == "pawn_shop_sals_mood" and c.get("phase", "") == "work")')
assert '58' not in helper and 'pawn_wake' not in helper
(OUT/'envart_pawn_sequence_proof_r2.gd').write_text(helper,encoding='utf-8')
# Package-specific preview will be reviewed/validated only after staging gate.
preview=(SRC/'tools/envart_bar_animation_capture_r4.gd').read_text().replace('"bar"','"pawn_shop"').replace('!=17','!=16').replace('Exact Bar17-entry pack required','Exact PawnR2 15-moving plus 1-static pack required')
preview=preview.replace('inventory.append({"id": entry.id,','inventory.append({"role": "static_occlusion" if entry.id == "STATIC_OCCLUSION_fixed_material" else "moving", "id": entry.id,')
(OUT/'envart_pawn_animation_capture_r2.gd').write_text(preview,encoding='utf-8')
summary={'catalog_path':str(path),'catalog_sha256':sha(path),'counts':counts,'scenarios':summaries,'physical_occurrences':sum(len(c['material_evidence'])+len(c['actor_evidence']) for c in cases),'excluded_occurrences':[{'case':c['scenario_id']+'__'+c.get('outcome',c.get('phase','')),'id':r['id'],'reason':r['exclusion']} for c in cases for r in c['excluded_materials']],'selected_label_precedence_cases':[{'case':c['scenario_id']+'__'+c.get('outcome',c.get('phase','')),'id':r['id'],'visual':r['source_label'],'selected':r['expected_label']} for c in cases for r in c['material_evidence']+c['actor_evidence'] if r['source_label']!=r['expected_label']]}
(OUT/'pawn_source_catalog_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))