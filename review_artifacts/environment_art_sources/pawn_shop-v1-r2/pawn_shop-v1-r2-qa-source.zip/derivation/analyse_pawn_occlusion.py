import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,os,hashlib
import numpy as np
from PIL import Image
R=Path(r'E:/CodexQA/BTH/runs');O=Path(os.environ['BTH_QA_EVIDENCE_DIR']);prefix='BTH-ENVART-PAWNTRIAL-20261114-'
def ev(name):return R/(prefix+name)/'evidence'
paintroot=ev('r2-source-paint-01');painter=json.loads((paintroot/'pawn_glint_source_paint.json').read_text());comproot=ev('r2-full-composite-01');comp=json.loads((comproot/'pawn_full_composite.json').read_text());native=ev('r2-native-probe-01')
def rgb(p):return np.asarray(Image.open(p).convert('RGB'),dtype=np.int16)
na=rgb(native/'inspection_tray_breath_live_a.png');nb=rgb(native/'inspection_tray_breath_live_b.png');native_delta=np.any(na!=nb,axis=2)
rows=[]
for ctx in painter['contexts']:
    scenario=ctx['scenario'];cr=next(c for c in comp['scenarios'] if c['scenario']==scenario);entry=next(e for e in cr['entries'] if e['id']=='inspection_tray_breath')
    actual_delta=np.any(rgb(comproot/entry['a'])!=rgb(comproot/entry['b']),axis=2)
    alpha=np.zeros(native_delta.shape,dtype=np.float64);contributors=[]
    for obj in ctx['objects']:
        own=np.zeros(native_delta.shape,dtype=np.float64)
        for key in ['body_png','adorn_png']:
            a=np.asarray(Image.open(paintroot/obj[key]).convert('RGBA'))[:,:,3]/255.0
            own=1-(1-own)*(1-a);alpha=1-(1-alpha)*(1-a)
        count=int(np.count_nonzero(native_delta & (own>0)))
        if count:contributors.append({'object_id':obj['object'].get('id'),'label':obj['object'].get('label'),'source_delta_pixels_touched':count,'source_delta_pixels_opaque':int(np.count_nonzero(native_delta & (own>=1))),'body_png':obj['body_png'],'adorn_png':obj['adorn_png']})
    opaque=native_delta & (alpha>=1);partial=native_delta & (alpha>0)&(alpha<1);clear=native_delta & (alpha==0)
    unexpected=int(np.count_nonzero(actual_delta & ~native_delta));visible_opaque=int(np.count_nonzero(actual_delta & opaque))
    rows.append({'scenario':scenario,'geometry_equal':ctx['geometry_equal'],'native_exposed_tray_delta_pixels':int(native_delta.sum()),'source_painted_opaque_coverage':int(opaque.sum()),'source_painted_partial_coverage':int(partial.sum()),'source_painted_clear_pixels':int(clear.sum()),'actual_final_composite_delta_pixels':int(actual_delta.sum()),'actual_deltas_outside_native_motif':unexpected,'actual_deltas_under_fully_opaque_paint':visible_opaque,'contributors':contributors,'classification':'meaningfully exposed native tray demonstration' if scenario=='pawn_shop_estate_lot_day' else 'partially covered/attenuated, with genuine residual tray pixels visible; not fully invisible'})
result={'source_painter_findings':painter['findings'],'rows':rows,'scope':'Source-painted body and adornment alpha from unchanged production painters, exact actual objects, geometry and per-pair clocks. No model rectangle masquerades as opacity mask. Native isolated tray RGB-delta support compared with actual fixed-context composite; all original images untouched.'}
assert not painter['findings']
assert all(r['geometry_equal'] and r['actual_deltas_outside_native_motif']==0 for r in rows)
(O/'pawn_tray_source_painted_occlusion.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))