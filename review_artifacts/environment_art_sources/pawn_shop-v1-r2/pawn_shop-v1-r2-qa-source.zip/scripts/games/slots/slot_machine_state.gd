class_name SlotMachineState
extends RefCounted

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")

# Canonical persistent slot state schema and normalization.

const SCHEMA_VERSION := 2
const IMMUTABLE_DEFINITION_STATE_KEYS := [
	"reel_strips",
	"bonus_reel_strips",
]
const DUPLICATE_PRESENTATION_STATE_KEYS := [
	"slot_reel_timeline",
	"slot_reel_stop_times",
]
const BET_OPTIONS := [
	{"id": "bet_2", "label": "MIN", "total_credits": 2},
	{"id": "bet_5", "label": "LOW", "total_credits": 5},
	{"id": "bet_10", "label": "MID", "total_credits": 10},
	{"id": "bet_15", "label": "HIGH", "total_credits": 15},
	{"id": "bet_20", "label": "MAX", "total_credits": 20},
]
const BUFFALO_GRAND_PRIZE_STATE_KEY := "buffalo_grand_prize"
const BUFFALO_GRAND_PRIZE_INITIAL_MULTIPLIER_KEY := "buffalo_grand_prize_initial_multiplier"
const BUFFALO_GRAND_PRIZE_SPINS_KEY := "buffalo_grand_prize_spins"
const BUFFALO_GRAND_MIN_INITIAL_MULTIPLIER := 50
const BUFFALO_GRAND_MAX_INITIAL_MULTIPLIER := 70


static func read_machine(environment: Dictionary, game_id: String) -> Dictionary:
	var machine: Variant = _stored_machine(environment, game_id)
	if typeof(machine) != TYPE_DICTIONARY:
		return {}
	return (machine as Dictionary).duplicate(true)


# Zero-copy read for per-frame checks. The returned dictionary is the live
# stored state: callers MUST NOT mutate it or hold it across writes.
static func peek_machine(environment: Dictionary, game_id: String) -> Dictionary:
	var machine: Variant = _stored_machine(environment, game_id)
	if typeof(machine) != TYPE_DICTIONARY:
		return {}
	return machine as Dictionary


static func _stored_machine(environment: Dictionary, game_id: String) -> Variant:
	var states: Variant = environment.get("game_states", {})
	if typeof(states) != TYPE_DICTIONARY:
		return {}
	return (states as Dictionary).get(game_id, {})


static func write_machine(environment: Dictionary, game_id: String, machine: Dictionary) -> void:
	# Replacing one machine must not deep-copy every other fixture in a large
	# casino. The map is copied shallowly and the target value is independently
	# normalized below, preserving ownership without cross-fixture allocation.
	var states_value: Variant = environment.get("game_states", {})
	var states: Dictionary = (states_value as Dictionary).duplicate(false) if typeof(states_value) == TYPE_DICTIONARY else {}
	states[game_id] = normalize(machine)
	environment["game_states"] = states
	_bump_environment_runtime_revision(environment)
# Resolution owns its mutable values and borrows definition-cache arrays. Keep
# those immutable arrays shared instead of normalizing/copying them again.
static func write_runtime_machine(environment: Dictionary, game_id: String, machine: Dictionary) -> void:
	var states_value: Variant = environment.get("game_states", {})
	var states: Dictionary = (states_value as Dictionary).duplicate(false) if typeof(states_value) == TYPE_DICTIONARY else {}
	for key in IMMUTABLE_DEFINITION_STATE_KEYS:
		machine.erase(key)
	# Production SlotGame hands this method a top-level-owned, already-valid v2
	# machine. Re-normalizing here deep-copied active feature graphs that the
	# resolver had just produced. Keep the canonical schema marker and compact
	# the storage-only fields without a second graph traversal.
	machine["schema_version"] = SCHEMA_VERSION
	var normalized: Dictionary = machine
	# The animation plan is authoritative for these values and every
	# presentation consumer already falls back to it. Do not retain a second
	# copy per cabinet.
	for key in DUPLICATE_PRESENTATION_STATE_KEYS:
		normalized.erase(key)
	var active_value: Variant = normalized.get("active_bonus", {})
	if typeof(active_value) == TYPE_DICTIONARY:
		# Reconstructed from the bounded runtime session and immutable board
		# template; never duplicate the static board layout into a save cabinet.
		(active_value as Dictionary).erase("pinball_view")
	states[game_id] = normalized
	environment["game_states"] = states
	_bump_environment_runtime_revision(environment)


static func _bump_environment_runtime_revision(environment: Dictionary) -> void:
	environment["environment_runtime_revision"] = int(environment.get("environment_runtime_revision", 0)) + 1


static func normalize(machine_value: Variant) -> Dictionary:
	var machine: Dictionary = JsonCoerceScript._copy_dict(machine_value)
	return normalize_owned(machine)


static func normalize_owned(machine: Dictionary) -> Dictionary:
	machine["schema_version"] = SCHEMA_VERSION
	machine["format_id"] = str(machine.get("format_id", "classic_3_reel"))
	machine["type_id"] = str(machine.get("type_id", "pinball"))
	machine["math_variant_id"] = str(machine.get("math_variant_id", "standard"))
	machine["cabinet_variant_id"] = str(machine.get("cabinet_variant_id", "neon_magenta"))
	machine["bonus_variant_id"] = str(machine.get("bonus_variant_id", "plain"))
	machine["machine_key"] = str(machine.get("machine_key", "%s:%s:%s:%s:%s" % [
		machine["format_id"],
		machine["type_id"],
		machine["math_variant_id"],
		machine["bonus_variant_id"],
		machine["cabinet_variant_id"],
	]))
	machine["reel_count"] = maxi(1, int(machine.get("reel_count", 3)))
	machine["row_count"] = maxi(1, int(machine.get("row_count", 1)))
	machine["pay_model"] = str(machine.get("pay_model", "single_line"))
	machine["reel_heights"] = JsonCoerceScript._int_array(machine.get("reel_heights", []))
	machine["reel_strips"] = _strip_array(machine.get("reel_strips", []))
	machine["bonus_reel_strips"] = _strip_array(machine.get("bonus_reel_strips", machine.get("reel_strips", [])))
	machine["reel_stops"] = JsonCoerceScript._int_array(machine.get("reel_stops", []))
	machine["last_grid"] = _grid_array(machine.get("last_grid", _blank_grid(int(machine["reel_count"]), int(machine["row_count"]))))
	machine["last_previous_grid"] = _grid_array(machine.get("last_previous_grid", []))
	machine["last_reels"] = JsonCoerceScript._copy_array(machine.get("last_reels", []))
	machine["last_payout"] = maxi(0, int(machine.get("last_payout", 0)))
	machine["last_net"] = int(machine.get("last_net", 0))
	machine["last_stake_cost"] = maxi(0, int(machine.get("last_stake_cost", 0)))
	machine["last_line_payout"] = maxi(0, int(machine.get("last_line_payout", 0)))
	machine["last_classification"] = str(machine.get("last_classification", "idle"))
	machine["last_outcome_id"] = str(machine.get("last_outcome_id", ""))
	machine["previous_result_payout"] = maxi(0, int(machine.get("previous_result_payout", 0)))
	machine["previous_result_net"] = int(machine.get("previous_result_net", 0))
	machine["previous_result_classification"] = str(machine.get("previous_result_classification", "idle"))
	machine["previous_result_reason"] = str(machine.get("previous_result_reason", ""))
	machine["free_spins"] = maxi(0, int(machine.get("free_spins", 0)))
	machine["spin_count"] = maxi(0, int(machine.get("spin_count", 0)))
	machine["coin_in"] = maxi(0, int(machine.get("coin_in", 0)))
	machine["coin_out"] = maxi(0, int(machine.get("coin_out", 0)))
	machine["last_bonus_total"] = maxi(0, int(machine.get("last_bonus_total", 0)))
	machine["last_bonus_mode"] = str(machine.get("last_bonus_mode", ""))
	machine["last_bonus_complete"] = bool(machine.get("last_bonus_complete", false))
	var last_bonus_replay: Dictionary = JsonCoerceScript._copy_dict(machine.get("last_bonus_replay", {}))
	machine["last_bonus_replay"] = _normalize_active_bonus(last_bonus_replay) if not last_bonus_replay.is_empty() else {}
	machine["last_tease_events"] = JsonCoerceScript._copy_array(machine.get("last_tease_events", []))
	machine["last_nudge_offer"] = JsonCoerceScript._copy_dict(machine.get("last_nudge_offer", {}))
	machine["slot_animation_id"] = str(machine.get("slot_animation_id", ""))
	machine["slot_animation_duration_msec"] = maxi(0, int(machine.get("slot_animation_duration_msec", 0)))
	machine["slot_animation_started_msec"] = maxi(0, int(machine.get("slot_animation_started_msec", 0)))
	machine["slot_bonus_trigger_revealed"] = bool(machine.get("slot_bonus_trigger_revealed", false))
	if machine.has("slot_animation_resume_elapsed_msec"):
		machine["slot_animation_resume_elapsed_msec"] = maxi(0, int(machine.get("slot_animation_resume_elapsed_msec", 0)))
	machine["slot_autoplay_active"] = bool(machine.get("slot_autoplay_active", false))
	machine["slot_autoplay_next_msec"] = maxi(0, int(machine.get("slot_autoplay_next_msec", 0)))
	machine["active_bonus"] = _normalize_active_bonus(machine.get("active_bonus", {}))
	machine["bonus_state"] = _normalize_bonus_state(machine.get("bonus_state", {}))
	machine["bet_ladder"] = _normalize_bet_ladder(machine.get("bet_ladder", {}))
	machine["pinball_feature_state"] = JsonCoerceScript._copy_dict(machine.get("pinball_feature_state", {}))
	machine["buffalo_feature_state"] = JsonCoerceScript._copy_dict(machine.get("buffalo_feature_state", {}))
	machine["slot_item_state"] = JsonCoerceScript._copy_dict(machine.get("slot_item_state", {}))
	return machine


static func selected_bet(machine: Dictionary) -> Dictionary:
	var ladder: Dictionary = _normalize_bet_ladder(machine.get("bet_ladder", {}))
	var selected_id := str(ladder.get("selected_id", "bet_2"))
	for option_value in BET_OPTIONS:
		var option: Dictionary = option_value
		if str(option.get("id", "")) == selected_id:
			return option.duplicate(true)
	return (BET_OPTIONS[0] as Dictionary).duplicate(true)


static func set_selected_bet(machine: Dictionary, bet_id: String) -> Dictionary:
	var ladder: Dictionary = _normalize_bet_ladder(machine.get("bet_ladder", {}))
	for option_value in BET_OPTIONS:
		var option: Dictionary = option_value
		if str(option.get("id", "")) == bet_id:
			ladder["selected_id"] = bet_id
			ladder["selected_total"] = int(option.get("total_credits", 2))
			machine["bet_ladder"] = ladder
			return machine
	return machine


static func set_selected_bet_by_index(machine: Dictionary, index: int) -> Dictionary:
	var safe_index := clampi(index, 0, BET_OPTIONS.size() - 1)
	var option: Dictionary = BET_OPTIONS[safe_index]
	return set_selected_bet(machine, str(option.get("id", "bet_2")))
static func seeded_buffalo_bonus_state(rng: RngStream) -> Dictionary:
	var per_bet: Dictionary = {}
	for option_value in BET_OPTIONS:
		var option: Dictionary = option_value
		var bet_id := str(option.get("id", ""))
		var stake := maxi(1, int(option.get("total_credits", 1)))
		var multiplier := BUFFALO_GRAND_MIN_INITIAL_MULTIPLIER
		if rng != null:
			multiplier = rng.randi_range(BUFFALO_GRAND_MIN_INITIAL_MULTIPLIER, BUFFALO_GRAND_MAX_INITIAL_MULTIPLIER)
		per_bet[bet_id] = _normalize_per_bet_bucket({
			BUFFALO_GRAND_PRIZE_STATE_KEY: stake * multiplier,
			BUFFALO_GRAND_PRIZE_INITIAL_MULTIPLIER_KEY: multiplier,
			BUFFALO_GRAND_PRIZE_SPINS_KEY: 0,
		})
	return {"per_bet": per_bet}


static func active_bonus_incomplete(machine: Dictionary) -> bool:
	var active: Dictionary = _normalize_active_bonus(machine.get("active_bonus", {}))
	return bool(active.get("active", false)) and not bool(active.get("complete", false))


static func canonical_geometry(definition: Dictionary, family_id: String, format_id: String) -> Dictionary:
	for format_value in JsonCoerceScript._dictionary_array(definition.get("slot_formats", [])):
		var format: Dictionary = format_value
		if str(format.get("id", "")) != format_id:
			continue
		var geometries: Dictionary = JsonCoerceScript._copy_dict(format.get("geometry", {}))
		var geometry: Dictionary = JsonCoerceScript._copy_dict(geometries.get(family_id, {}))
		if not geometry.is_empty():
			return {
				"reel_count": maxi(1, int(geometry.get("reel_count", 3))),
				"row_count": maxi(1, int(geometry.get("row_count", 1))),
				"pay_model": str(geometry.get("pay_model", format.get("pay_model", "single_line"))),
			}
	return {"reel_count": 3, "row_count": 1, "pay_model": "single_line"}


static func behavior_combo_count(definition: Dictionary) -> int:
	return JsonCoerceScript._dictionary_array(definition.get("slot_formats", [])).size() * JsonCoerceScript._dictionary_array(definition.get("slot_types", [])).size() * JsonCoerceScript._dictionary_array(definition.get("slot_math_variants", [])).size() * JsonCoerceScript._dictionary_array(definition.get("slot_bonus_variants", [])).size()


static func visual_machine_count(definition: Dictionary) -> int:
	return behavior_combo_count(definition) * JsonCoerceScript._dictionary_array(definition.get("slot_cabinet_variants", [])).size()


static func _normalize_bet_ladder(value: Variant) -> Dictionary:
	var ladder: Dictionary = JsonCoerceScript._copy_dict(value)
	var selected_id := str(ladder.get("selected_id", "bet_2"))
	var selected_total := 2
	var found := false
	for option_value in BET_OPTIONS:
		var option: Dictionary = option_value
		if str(option.get("id", "")) == selected_id:
			selected_total = int(option.get("total_credits", 2))
			found = true
			break
	if not found:
		selected_id = "bet_2"
		selected_total = 2
	return {
		"options": BET_OPTIONS.duplicate(true),
		"selected_id": selected_id,
		"selected_total": selected_total,
		"locked": bool(ladder.get("locked", false)),
		"locked_bet_id": str(ladder.get("locked_bet_id", "")),
		"locked_total": maxi(0, int(ladder.get("locked_total", 0))),
	}


static func _normalize_bonus_state(value: Variant) -> Dictionary:
	var source: Dictionary = JsonCoerceScript._copy_dict(value)
	var per_bet: Dictionary = JsonCoerceScript._copy_dict(source.get("per_bet", {}))
	for option_value in BET_OPTIONS:
		var option: Dictionary = option_value
		var bet_id := str(option.get("id", ""))
		per_bet[bet_id] = _normalize_per_bet_bucket(per_bet.get(bet_id, {}))
	return {
		"per_bet": per_bet,
		"gold_buffalo_total_collected": maxi(0, int(source.get("gold_buffalo_total_collected", 0))),
		"gold_buffalo_conversions": maxi(0, int(source.get("gold_buffalo_conversions", 0))),
		"buffalo_grand_prize": maxi(0, int(source.get("buffalo_grand_prize", 0))),
		"must_hit_forces": maxi(0, int(source.get("must_hit_forces", 0))),
		"feature_completions": maxi(0, int(source.get("feature_completions", 0))),
		"neon_players_charm_used": bool(source.get("neon_players_charm_used", false)),
	}


static func _normalize_per_bet_bucket(value: Variant) -> Dictionary:
	var bucket: Dictionary = JsonCoerceScript._copy_dict(value)
	return {
		"gold_buffalo_heads": clampi(int(bucket.get("gold_buffalo_heads", 0)), 0, 1000000),
		"gold_buffalo_max_seen": maxi(0, int(bucket.get("gold_buffalo_max_seen", 0))),
		"must_hit_meter": maxi(100, int(bucket.get("must_hit_meter", 100))),
		"must_hit_ready": bool(bucket.get("must_hit_ready", false)),
		"feature_completion_count": maxi(0, int(bucket.get("feature_completion_count", 0))),
		BUFFALO_GRAND_PRIZE_STATE_KEY: maxi(0, int(bucket.get(BUFFALO_GRAND_PRIZE_STATE_KEY, 0))),
		BUFFALO_GRAND_PRIZE_INITIAL_MULTIPLIER_KEY: maxi(0, int(bucket.get(BUFFALO_GRAND_PRIZE_INITIAL_MULTIPLIER_KEY, 0))),
		BUFFALO_GRAND_PRIZE_SPINS_KEY: maxi(0, int(bucket.get(BUFFALO_GRAND_PRIZE_SPINS_KEY, 0))),
	}
static func _normalize_active_bonus(value: Variant) -> Dictionary:
	var active: Dictionary = JsonCoerceScript._copy_dict(value)
	if active.is_empty():
		return {"active": false, "complete": true}
	active["active"] = bool(active.get("active", false))
	active["complete"] = bool(active.get("complete", not bool(active.get("active", false))))
	# A settled feature is already represented by last_bonus_replay and bonus_state.
	# Keep the compact terminal marker (and any forward-compatible unknown fields)
	# instead of manufacturing every active-session default into persistent state.
	if not bool(active["active"]):
		return active
	active["mode"] = str(active.get("mode", ""))
	active["family"] = str(active.get("family", ""))
	active["visual_replay"] = bool(active.get("visual_replay", false))
	active["bet_id"] = str(active.get("bet_id", ""))
	active["stake"] = maxi(0, int(active.get("stake", 0)))
	active["pending_award"] = maxi(0, int(active.get("pending_award", 0)))
	active["feature_total"] = maxi(0, int(active.get("feature_total", active.get("pending_award", 0))))
	active["awarded"] = maxi(0, int(active.get("awarded", 0)))
	active["remaining_steps"] = maxi(0, int(active.get("remaining_steps", 0)))
	active["total_steps"] = maxi(0, int(active.get("total_steps", 0)))
	active["step_index"] = maxi(0, int(active.get("step_index", 0)))
	active["history"] = JsonCoerceScript._copy_array(active.get("history", []))
	active["choices"] = JsonCoerceScript._copy_array(active.get("choices", []))
	active["shot_queue"] = JsonCoerceScript._copy_array(active.get("shot_queue", []))
	active["locks"] = JsonCoerceScript._copy_array(active.get("locks", []))
	active["launch_power"] = clampi(int(active.get("launch_power", 50)), 0, 100)
	active["launch_angle_degrees"] = clampi(int(active.get("launch_angle_degrees", 0)), -60, 60)
	active["launch_start"] = JsonCoerceScript._copy_dict(active.get("launch_start", {}))
	active["selected_path"] = str(active.get("selected_path", ""))
	active["display_mode"] = str(active.get("display_mode", ""))
	active["selected_lane"] = str(active.get("selected_lane", "center"))
	active["balls_remaining"] = maxi(0, int(active.get("balls_remaining", active.get("remaining_steps", 0))))
	active["respins_remaining"] = maxi(0, int(active.get("respins_remaining", active.get("remaining_steps", 0))))
	active["max_cells"] = maxi(0, int(active.get("max_cells", 0)))
	active["retrigger_count"] = maxi(0, int(active.get("retrigger_count", 0)))
	active["spin_win_total"] = maxi(0, int(active.get("spin_win_total", active.get("feature_total", 0))))
	active["collected_coins"] = JsonCoerceScript._copy_array(active.get("collected_coins", []))
	active["last_collected_coins"] = JsonCoerceScript._copy_array(active.get("last_collected_coins", []))
	active["coins_collected"] = maxi(0, int(active.get("coins_collected", 0)))
	active["coins_since_retrigger"] = maxi(0, int(active.get("coins_since_retrigger", 0)))
	active["coin_total"] = maxi(0, int(active.get("coin_total", 0)))
	active["coin_collect_total"] = maxi(0, int(active.get("coin_collect_total", 0)))
	active["coin_collect_awarded"] = bool(active.get("coin_collect_awarded", false))
	active["coin_reveals"] = JsonCoerceScript._copy_array(active.get("coin_reveals", []))
	active["coin_reveal_total"] = maxi(0, int(active.get("coin_reveal_total", active.get("coin_collect_total", 0))))
	active["last_retrigger_grant"] = maxi(0, int(active.get("last_retrigger_grant", 0)))
	active["retrigger_threshold"] = maxi(1, int(active.get("retrigger_threshold", 3)))
	active["retrigger_grant"] = maxi(1, int(active.get("retrigger_grant", 8)))
	active["max_total_steps"] = maxi(int(active.get("total_steps", 0)), int(active.get("max_total_steps", 60)))
	active["lane_locks"] = maxi(0, int(active.get("lane_locks", 0)))
	active["lit_jackpots"] = maxi(0, int(active.get("lit_jackpots", 0)))
	active["survival_ticks"] = maxi(0, int(active.get("survival_ticks", 0)))
	active["session_cap"] = maxi(0, int(active.get("session_cap", 0)))
	active["grand_prize"] = maxi(0, int(active.get("grand_prize", 0)))
	active["grand_prize_awarded"] = maxi(0, int(active.get("grand_prize_awarded", 0)))
	active["nudge_request"] = clampi(int(active.get("nudge_request", 0)), -4, 4)
	active["feature_scale"] = maxf(0.0, float(active.get("feature_scale", 1.0)))
	active["physics"] = JsonCoerceScript._copy_dict(active.get("physics", {}))
	active["runtime_session_id"] = str(active.get("runtime_session_id", ""))
	active["runtime_seed"] = int(active.get("runtime_seed", 0))
	active["board_id"] = str(active.get("board_id", ""))
	active["pinball_summary"] = JsonCoerceScript._copy_dict(active.get("pinball_summary", {}))
	active["pinball_view"] = JsonCoerceScript._copy_dict(active.get("pinball_view", {}))
	active["pinball_item_effects"] = JsonCoerceScript._copy_dict(active.get("pinball_item_effects", {}))
	active["pinball_item_hooks"] = JsonCoerceScript._copy_array(active.get("pinball_item_hooks", []))
	active["sequencer_state"] = JsonCoerceScript._copy_dict(active.get("sequencer_state", {}))
	active["sequence_events"] = JsonCoerceScript._copy_array(active.get("sequence_events", []))
	active["lit"] = JsonCoerceScript._copy_dict(active.get("lit", {}))
	active["combo_state"] = JsonCoerceScript._copy_dict(active.get("combo_state", {}))
	active["pinball_debug"] = JsonCoerceScript._copy_dict(active.get("pinball_debug", {}))
	active["guided_assist_count"] = maxi(0, int(active.get("guided_assist_count", 0)))
	active["event_log"] = JsonCoerceScript._copy_array(active.get("event_log", []))
	active["trajectory"] = JsonCoerceScript._copy_array(active.get("trajectory", []))
	active["display_event_log"] = JsonCoerceScript._copy_array(active.get("display_event_log", []))
	active["display_trajectory"] = JsonCoerceScript._copy_array(active.get("display_trajectory", []))
	active["animation_duration_msec"] = maxi(0, int(active.get("animation_duration_msec", 0)))
	active["launch_in_progress"] = bool(active.get("launch_in_progress", false))
	active["physics_tick_budget"] = maxi(0, int(active.get("physics_tick_budget", 0)))
	active["physics_frame_index"] = maxi(0, int(active.get("physics_frame_index", 0)))
	active["current_launch_start_event_index"] = maxi(0, int(active.get("current_launch_start_event_index", 0)))
	active["current_launch_start_trajectory_index"] = maxi(0, int(active.get("current_launch_start_trajectory_index", 0)))
	active["live_input"] = JsonCoerceScript._copy_dict(active.get("live_input", {}))
	active["max_active_count"] = maxi(0, int(active.get("max_active_count", 0)))
	active["multiball_started"] = bool(active.get("multiball_started", false))
	active["nudge_used"] = bool(active.get("nudge_used", false))
	active["video_targets"] = JsonCoerceScript._copy_dict(active.get("video_targets", {}))
	active["video_super_jackpot_lit"] = bool(active.get("video_super_jackpot_lit", false))
	active["video_super_jackpots"] = maxi(0, int(active.get("video_super_jackpots", 0)))
	active["video_jackpots"] = maxi(0, int(active.get("video_jackpots", 0)))
	active["video_completed_banks"] = maxi(0, int(active.get("video_completed_banks", 0)))
	active["video_multiball_ready"] = bool(active.get("video_multiball_ready", false))
	active["jackpot_tier"] = str(active.get("jackpot_tier", ""))
	active["feature_phase"] = str(active.get("feature_phase", ""))
	active["collection_meter"] = JsonCoerceScript._copy_dict(active.get("collection_meter", {}))
	active["fill_meter"] = JsonCoerceScript._copy_dict(active.get("fill_meter", {}))
	active["jackpot_ladder"] = JsonCoerceScript._copy_dict(active.get("jackpot_ladder", {}))
	active["last_lock_events"] = JsonCoerceScript._copy_array(active.get("last_lock_events", []))
	active["gateway_type"] = str(active.get("gateway_type", ""))
	active["feature_origin"] = str(active.get("feature_origin", ""))
	active["trophy_pick_active"] = bool(active.get("trophy_pick_active", false))
	active["trophy_choices"] = JsonCoerceScript._copy_array(active.get("trophy_choices", []))
	active["trophy_reveals"] = JsonCoerceScript._copy_array(active.get("trophy_reveals", []))
	active["trophy_selected_path"] = str(active.get("trophy_selected_path", ""))
	active["wheel_angle"] = int(active.get("wheel_angle", 0))
	return active


static func _blank_grid(reel_count: int, row_count: int) -> Array:
	var grid: Array = []
	for _reel_index in range(maxi(1, reel_count)):
		var column: Array = []
		for _row_index in range(maxi(1, row_count)):
			column.append("BLANK")
		grid.append(column)
	return grid


static func _grid_array(value: Variant) -> Array:
	var result: Array = []
	if typeof(value) != TYPE_ARRAY:
		return result
	var source: Array = value as Array
	for column_value in source:
		if typeof(column_value) == TYPE_ARRAY:
			var column: Array = []
			var cells: Array = column_value as Array
			for cell in cells:
				column.append(str(cell))
			result.append(column)
	return result


static func _strip_array(value: Variant) -> Array:
	return _grid_array(value)
