class_name BlackjackGame
extends GameModule

# Full-simulation blackjack module. The shared UI canvas only hosts the surface;
# this module owns shoe state, table rules, side bets, player decisions, and
# cheat detection.

const VisualStyleScript := preload("res://scripts/ui/visual_style.gd")
const CardShoeScript := preload("res://scripts/core/card_shoe.gd")
const TableVisualsScript := preload("res://scripts/games/table_game_visuals.gd")
const PlayingCardRendererScript := preload("res://scripts/games/playing_card_renderer.gd")
const RuntimeScript := preload("res://scripts/core/game_ritual_runtime.gd")
const ActionAuthorityScript := preload("res://scripts/core/blackjack_action_authority.gd")
const ShowdownDuelProjectionScript := preload("res://scripts/core/grand_casino_duel_ritual_projection.gd")
const C_DARK := VisualStyleScript.DARK
const C_PINK := VisualStyleScript.PINK
const C_PINK_2 := VisualStyleScript.PINK_2
const C_CYAN := VisualStyleScript.CYAN
const C_TEAL := VisualStyleScript.TEAL
const C_YELLOW := VisualStyleScript.YELLOW
const C_AMBER := VisualStyleScript.AMBER
const C_ORANGE := VisualStyleScript.ORANGE
const C_WHITE := VisualStyleScript.WHITE
const C_SOFT := VisualStyleScript.SOFT

const RANK_ACE := 14
const DEAL_ANIMATION_CHANNEL := "blackjack_deal"
const BLACKJACK_SETTLE_ACTION := "blackjack_settle"
const ATTENTION_ANIMATION_CHANNEL := "blackjack_attention"
const COUNT_ANIMATION_CHANNEL := "blackjack_count_rhythm"
const PAYOUT_ANIMATION_CHANNEL := "blackjack_payout"
const DEAL_CARD_DURATION_MSEC := 520
const DEAL_CARD_STAGGER_MSEC := 280
const DEAL_OPENING_FIRST_DELAY_MSEC := 120
const DEAL_HOLE_REVEAL_DELAY_MSEC := 180
const DEAL_HOLE_REVEAL_DURATION_MSEC := 520
const DEAL_CARD_SHOE_POS := Vector2(736, 126)
const PAYOUT_ANIMATION_DURATION_MSEC := 1800
const COUNT_ICON_DURATION_MSEC := 3000
const COUNT_ICON_STAGGER_MSEC := 520
const COUNT_ICON_FADE_MSEC := 420
const PATRON_DECISION_START_DELAY_MSEC := 680
const PATRON_DECISION_STEP_DELAY_MSEC := 220
const PATRON_HIT_CARD_DELAY_MSEC := 110
const PATRON_DECISION_HIGHLIGHT_MSEC := 840
const BLACKJACK_MAX_SIDE_BETS := 2
const BLACKJACK_PAYOUT_LABEL := "3:2"
const STRATEGY_DEVIATION_MAX_HEAT := 24
const STRATEGY_DEVIATION_MAX_WATCH := 45
const ORDINARY_STRATEGY_HEAT_MAX := 2
const COUNT_ADVANTAGE_BASE_HEAT := 8
const HOLE_CARD_ADVANTAGE_BASE_HEAT := 12
const COUNTER_SURVEILLANCE_SAMPLE_LIMIT := 24
const COUNTER_SURVEILLANCE_MIN_HANDS := 6
const COUNTER_SURVEILLANCE_CORRELATION_THRESHOLD := 0.58
const COUNTER_SURVEILLANCE_STRONG_CORRELATION := 0.76
const COUNTER_SURVEILLANCE_MAX_MISS_HEAT := 6
const COUNTER_SURVEILLANCE_CAUGHT_BONUS := 6
const COOLERS_CUFFLINKS_ITEM_ID := "coolers_cufflinks"
const BROKEN_CUFFLINKS_ITEM_ID := "broken_cufflinks"
const PLAYER_CARD_SCALE := 0.84
const DEALER_CARD_SCALE := 0.78
const PATRON_CARD_SCALE := 0.43
const PATRON_SEAT_POSITIONS := [Vector2(128, 176), Vector2(272, 130), Vector2(628, 130), Vector2(772, 176)]
const COMPACT_CARD_RANK_PATTERNS := {
	2: ["111", "001", "111", "100", "111"],
	3: ["111", "001", "111", "001", "111"],
	4: ["101", "101", "111", "001", "001"],
	5: ["111", "100", "111", "001", "111"],
	6: ["111", "100", "111", "101", "111"],
	7: ["111", "001", "001", "001", "001"],
	8: ["111", "101", "111", "101", "111"],
	9: ["111", "101", "111", "001", "111"],
	10: ["111", "010", "010", "010", "010"],
	11: ["011", "001", "001", "101", "111"],
	12: ["111", "101", "101", "111", "001"],
	13: ["101", "110", "100", "110", "101"],
	14: ["010", "101", "111", "101", "101"],
}
const BJ_CONSOLE_Y := 342.0
const BJ_CONSOLE_H := 84.0
const BJ_TABLE_BOTTOM := 334.0
const DRAW_DEAL_EVENTS_CACHE_KEY := "_blackjack_draw_deal_events"
const ROURKE_DUEL_VARIANT := "rourke_duel"
const BLACKJACK_RITUAL_ID := "blackjack.standard_table"
const BLACKJACK_RITUAL_CONTRACT := "game_ritual/1"
const BLACKJACK_RITUAL_HANDLER_ID := "blackjack_authority"
const BLACKJACK_CHARGED_DEAL_ACTION := "blackjack_place_bet"
const BLACKJACK_WAGER_PLACE_GESTURE := "blackjack_wager_place_gesture"
const BLACKJACK_CUT_GESTURE := "blackjack_cut_gesture"
const BLACKJACK_WAVE_GESTURE := "blackjack_wave_gesture"
const BLACKJACK_TAP_GESTURE := "blackjack_tap_gesture"
const BLACKJACK_HOST_LEDGER_KEY := "_blackjack_action_authority"
const BLACKJACK_HOST_TRANSIENT_UI_KEYS := [
	"surface_time_msec", "surface_presentation_time_msec", "drunk_scaled_surface_time_msec",
	"selected_action_id", "selected_action_kind", "selected_index",
	"blackjack_gesture_active", "blackjack_gesture_origin",
	"blackjack_gesture_index", "blackjack_gesture_pointer",
]
const COMPATIBILITY_READ_ONLY_ACTIONS := ["play_basic", "blackjack_place_bet", "peek_hole_card", "count_cards"]
const BLACKJACK_GESTURE_ACTIONS := [
	BLACKJACK_WAGER_PLACE_GESTURE,
	BLACKJACK_CUT_GESTURE,
	BLACKJACK_WAVE_GESTURE,
	BLACKJACK_TAP_GESTURE,
]
const BJ_RAIL_POINTS := [
	Vector2(46, 142), Vector2(156, 92), Vector2(334, 76), Vector2(566, 76),
	Vector2(744, 92), Vector2(854, 142), Vector2(822, BJ_TABLE_BOTTOM), Vector2(78, BJ_TABLE_BOTTOM),
]
const BJ_RAIL_COLORS := [Color("#170d17")]
const BJ_OUTER_FELT_POINTS := [
	Vector2(58, 148), Vector2(170, 102), Vector2(342, 86), Vector2(558, 86),
	Vector2(730, 102), Vector2(842, 148), Vector2(808, BJ_TABLE_BOTTOM - 12.0), Vector2(92, BJ_TABLE_BOTTOM - 12.0),
]
const BJ_OUTER_FELT_COLORS := [Color("#3a1830")]
const BJ_FELT_POINTS := [
	Vector2(84, 154), Vector2(190, 116), Vector2(358, 102), Vector2(542, 102),
	Vector2(710, 116), Vector2(816, 154), Vector2(766, 314), Vector2(134, 314),
]
const BJ_FELT_COLORS := [Color("#0a5a48")]
const BJ_CENTER_FELT_POINTS := [
	Vector2(126, 166), Vector2(226, 136), Vector2(372, 120), Vector2(528, 120),
	Vector2(674, 136), Vector2(774, 166), Vector2(736, 292), Vector2(164, 292),
]
const BJ_CENTER_FELT_COLORS := [Color("#063f35")]

var draw_deal_events_cache_id := ""
var draw_deal_events_cache: Array = []
const CHIP_RIM_GEOMETRY_CACHE_LIMIT := 128
var chip_rim_geometry_cache: Dictionary = {}
var draw_dealer_character_style: Dictionary = {}
var draw_patron_character_style: Dictionary = {}


func sealed_action_authority_script() -> Script:
	return ActionAuthorityScript


func defers_embedded_action_presentation_refresh(run_state: RunState, _environment: Dictionary) -> bool:
	# Settlement publishes its authoritative result before returning. Building the
	# complete Foundation/HUD presentation in that same input callback can consume
	# an entire visible frame on a mature run, so hand the presentation to the
	# guarded next-frame path. Tutorial boundaries stay synchronous for the coach.
	return run_state != null and not run_state.is_tutorial_run()


func surface_action_uses_lightweight_ui_state(_surface_action: String) -> bool:
	return true


func surface_action_ui_state_keys() -> Array:
	return BLACKJACK_HOST_TRANSIENT_UI_KEYS


func checkpoint_surface_ui_state_for_save_requires_ui_state() -> bool:
	# The sealed table ledger, not Foundation's retained presentation dictionary,
	# is the durable Blackjack session.
	return false


func restored_surface_ui_state(run_state: RunState, environment: Dictionary) -> Dictionary:
	if run_state == null or _is_rourke_duel(run_state, environment):
		return {}
	var table := _table_state_preview(run_state, environment)
	var state_key := transient_state_key_context()
	if state_key != get_id() and not state_key.begins_with("%s:" % get_id()):
		state_key = get_id()
	var binding := RunState.action_authority_table_binding(state_key, environment)
	var ledger := ActionAuthorityScript.validate_persisted_ledger_cow(table.get(BLACKJACK_HOST_LEDGER_KEY, {}), binding)
	if ledger.is_empty() or not bool(ledger.get("initialized", false)) or not _local_copy_dict(ledger.get("pending_delivery", {})).is_empty():
		return {}
	var session := _local_copy_dict(ledger.get("session", {}))
	if _has_dealt_hand(session):
		return {}
	var pending_wager := int(session.get("selected_stake", 0))
	return {"selected_stake": pending_wager} if pending_wager > 0 else {}


func embedded_action_view_patch(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	# The Blackjack surface projection is the complete post-action table view. Send
	# it directly to the live canvas after a sealed action instead of rebuilding the
	# surrounding Foundation snapshot, room context, and game-entry presentation.
	var patch := surface_state(run_state, environment, ui_state)
	patch["surface_action_realtime_refresh_required"] = false
	return patch


func sealed_action_authority_contract() -> Dictionary:
	return {
		"resolve_proposal_method": ActionAuthorityScript.RESOLVE_PROPOSAL_METHOD,
		"wager_cost_proposal_method": ActionAuthorityScript.WAGER_COST_PROPOSAL_METHOD,
		"trusted_candidate_resolve_method": &"_blackjack_resolve_candidate",
		"trusted_candidate_wager_method": &"_blackjack_wager_cost_candidate",
		# Ordinary Blackjack resolution mutates only its bound table. Bind and replay
		# that table plus the exact account/risk inputs instead of serializing a late
		# run's world, travel history, and unrelated machines for every settlement.
		# Rourke keeps fully isolated run candidates and broader run evidence;
		# Crew and scenario-bound actions retain the full snapshot proof.
		"compact_authority_evidence_method": &"_blackjack_authority_evidence",
		"compact_authority_evidence_predicate_method": &"_blackjack_compact_authority_allowed",
		"compact_authority_full_replay_predicate_method": &"_blackjack_full_authority_replay_required",
		"compact_authority_native_json_predicate_method": &"_blackjack_full_authority_replay_required",
		"prepared_surface_direct_resolve_predicate_method": &"_blackjack_prepared_direct_resolve_allowed",
		"restore_recovery_session_method": &"_blackjack_restore_recovery_session",
		"trusted_candidate_structural_replay_match": true,
		# The current response and its predecessor cover synchronous duplicate input
		# and automatic recovery. Retaining four complete two-boundary hands made every
		# later click re-hash old shoes, hands, patrons, and animation payloads.
		"active_replay_limit": 2,
		# Ordinary Deal and terminal hand controls run on an exact, independently
		# replayed table candidate. When no scenario turn can reject, publish that
		# accepted table directly instead of cloning the accumulated run around it.
		"in_place_nonrejecting_commit": true,
		"in_place_nonrejecting_commit_predicate_method": &"_blackjack_in_place_commit_allowed",
		"host_auto_tick_method": ActionAuthorityScript.HOST_AUTO_TICK_METHOD,
		"surface_intent_key": ActionAuthorityScript.SURFACE_INTENT_KEY,
		"surface_intent_index_key": ActionAuthorityScript.SURFACE_INTENT_INDEX_KEY,
		# Failed deliveries restore the prior table automatically. Blackjack never
		# asks the player to understand or operate the transaction recovery layer.
		"automatic_pending_recovery": true,
		"retry_surface_actions": [],
		"cancel_surface_actions": [],
		"proposal_requires_apply_key": ActionAuthorityScript.PROPOSAL_REQUIRES_APPLY_KEY,
		"authoritative_result_marker": "",
		"place_bet_action": ActionAuthorityScript.PLACE_BET_ACTION,
		"host_pointer_intent": false,
		# Count pulses, non-terminal card decisions, and the count-reveal stage of
		# settlement alter only the authenticated session. Economic/terminal variants
		# automatically fall back to the transaction path.
		"in_place_session_intents": [
			"blackjack_count_icon", BLACKJACK_SETTLE_ACTION, "blackjack_hit", "blackjack_stand",
			"blackjack_double", "blackjack_split", "blackjack_surrender", "blackjack_distraction", "blackjack_peek",
		],
		"in_place_session_intent_predicate_method": &"_blackjack_in_place_session_intent_allowed",
		"in_place_session_intent_method": &"_blackjack_in_place_session_intent_command",
		"in_place_session_surface_patch_method": &"_blackjack_in_place_session_surface_patch",
		"skip_environment_turn_actions": ["count_cards"],
	}


func blackjack_ritual_contract() -> Dictionary:
	# This is a Blackjack-owned consumer declaration. It deliberately contains no
	# executable handler reference and does not import a shared ritual runtime.
	var action_ids := [
		"blackjack_chip", "blackjack_correct_bet", "blackjack_remove_chip", "blackjack_undo_bet",
		"blackjack_clear_bet", "blackjack_max_bet", "blackjack_repeat_bet",
		"blackjack_rebet", "blackjack_side_bet", "blackjack_deal", BLACKJACK_SETTLE_ACTION, BLACKJACK_CHARGED_DEAL_ACTION,
		"blackjack_hit", "blackjack_stand", "blackjack_double",
		"blackjack_split", "blackjack_surrender", "play_basic",
	]
	var action_declarations: Array = []
	for action_id in action_ids:
		action_declarations.append({"action_id": action_id, "handler_id": BLACKJACK_RITUAL_HANDLER_ID, "parameters": {}})
	return {
		"contract": BLACKJACK_RITUAL_CONTRACT,
		"ritual_id": BLACKJACK_RITUAL_ID,
		"initial_phase": "wagering",
		"ritual_phases": [
			_blackjack_ritual_phase("wagering", ["blackjack_chip", "blackjack_correct_bet", "blackjack_remove_chip", "blackjack_undo_bet", "blackjack_clear_bet", "blackjack_max_bet", "blackjack_repeat_bet", "blackjack_rebet", "blackjack_side_bet", "blackjack_deal", BLACKJACK_CHARGED_DEAL_ACTION], [{"id": "confirm_to_deal", "condition": {"kind": "accepted_action", "action_id": BLACKJACK_CHARGED_DEAL_ACTION}, "next_phase": "initial_deal", "operations": []}]),
			_blackjack_ritual_phase("initial_deal", [], [{"id": "deal_to_player", "condition": {"kind": "public_state_equals", "key": "deal_staged", "value": true}, "next_phase": "player_turn", "operations": []}]),
			_blackjack_ritual_phase("player_turn", ["blackjack_hit", "blackjack_stand", "blackjack_double", "blackjack_split", "blackjack_surrender"], [{"id": "player_to_dealer", "condition": {"kind": "public_state_equals", "key": "hand_complete", "value": true}, "next_phase": "dealer_procedure", "operations": []}]),
			_blackjack_ritual_phase("dealer_procedure", ["play_basic"], [{"id": "dealer_to_settlement", "condition": {"kind": "authoritative_result_present"}, "next_phase": "settlement", "operations": []}]),
			_blackjack_ritual_phase("settlement", [BLACKJACK_SETTLE_ACTION], [{"id": "settlement_to_wagering", "condition": {"kind": "public_state_equals", "key": "payout_staged", "value": true}, "next_phase": "wagering", "operations": []}]),
		],
		"action_declarations": action_declarations,
		"staged_commitment": {
			"pending_collection": "pending_items",
			"working_collection": "working_items",
			"resolution_collection": "item_resolutions",
			"funds_authority": "game_rules",
			"actions": [
				{"id": "blackjack_chip", "effect": "add_or_increment_one"},
				{"id": "blackjack_correct_bet", "effect": "correct_one_pending_amount"},
				{"id": "blackjack_remove_chip", "effect": "remove_one_pending_item"},
				{"id": "blackjack_undo_bet", "effect": "reverse_last_pending_edit"},
				{"id": "blackjack_clear_bet", "effect": "remove_all_pending_items"},
				{"id": "blackjack_repeat_bet", "effect": "copy_last_eligible_commitment"},
				{"id": "blackjack_rebet", "effect": "copy_eligible_resolved_items"},
				{"id": BLACKJACK_CHARGED_DEAL_ACTION, "effect": "authorize_pending_set"},
			],
			"readable_totals": ["available_funds", "pending_total", "at_risk_total", "returned_stake", "payout", "net_change"],
		},
		"pointer_verbs": [
			_blackjack_gesture_contract("place", BLACKJACK_WAGER_PLACE_GESTURE, "blackjack_chip", "wagering", "return_to_source"),
			_blackjack_gesture_contract("hold", BLACKJACK_CUT_GESTURE, "blackjack_deal", "wagering", "restore_focus"),
			_blackjack_gesture_contract("drag", BLACKJACK_WAVE_GESTURE, "blackjack_stand", "player_turn", "restore_focus"),
			_blackjack_gesture_contract("hold", BLACKJACK_TAP_GESTURE, "blackjack_hit", "player_turn", "restore_focus"),
		],
		"actors": [
			_blackjack_actor_contract("dealer.primary", "dealer", "station.dealer", ["idle", "dealing", "watching", "drawing", "settling"], ["open", "working", "attentive", "paying"]),
			_blackjack_actor_contract("neighbour.0", "neighbour", "seat.0", ["seated", "leaning", "reacting"], ["idle", "playing", "watching"]),
			_blackjack_actor_contract("neighbour.1", "neighbour", "seat.1", ["seated", "leaning", "reacting"], ["idle", "playing", "watching"]),
			_blackjack_actor_contract("neighbour.2", "neighbour", "seat.2", ["seated", "leaning", "reacting"], ["idle", "playing", "watching"]),
			_blackjack_actor_contract("neighbour.3", "neighbour", "seat.3", ["seated", "leaning", "reacting"], ["idle", "playing", "watching"]),
			_blackjack_actor_contract("pit.primary", "pit", "pit.rail", ["absent", "rail", "close"], ["idle", "watching", "intervening"]),
		],
		"scene_objects": [
			_blackjack_object_contract("shoe.primary", "shoe.anchor", {"space": "design", "x": 686, "y": 92, "w": 92, "h": 92}, ["ready", "dealing", "cut_due"], ["enabled", "locked"]),
			_blackjack_object_contract("discard_rack.primary", "discard.anchor", {"space": "design", "x": 674, "y": 188, "w": 70, "h": 28}, ["empty", "used", "full"], ["passive"]),
			_blackjack_object_contract("wager.player", "wager.anchor", {"space": "design", "x": 414, "y": 276, "w": 76, "h": 62}, ["editable", "placed", "at_risk", "settled"], ["editable", "locked"]),
			_blackjack_object_contract("dealer.hole_card", "dealer_hand.anchor", {"space": "design", "x": 386, "y": 158, "w": 112, "h": 62}, ["concealed", "revealed"], ["read_only"]),
			_blackjack_object_contract("rail.open_space", "rail.open_space", {"space": "design", "x": 790, "y": 208, "w": 68, "h": 44}, ["open", "guarded", "narrow"], ["enabled", "blocked"]),
		],
		"energy": {
			"initial_tier": "quiet",
			"tiers": [
				{"id": "quiet", "actor_operations": [{"target": "dealer.primary", "behavior": "open"}], "object_operations": [{"target": "wager.player", "state": "editable"}], "interaction_operations": [], "audio_cues": []},
				{"id": "engaged", "actor_operations": [{"target": "dealer.primary", "behavior": "working"}], "object_operations": [{"target": "wager.player", "state": "at_risk"}], "interaction_operations": [], "audio_cues": []},
				{"id": "watched", "actor_operations": [{"target": "pit.primary", "behavior": "watching"}], "object_operations": [{"target": "wager.player", "state": "at_risk"}], "interaction_operations": [{"target": "peek.region", "state": "guarded"}], "audio_cues": []},
				{"id": "hot", "actor_operations": [{"target": "pit.primary", "behavior": "intervening"}], "object_operations": [{"target": "rail.open_space", "state": "narrow"}], "interaction_operations": [{"target": "peek.region", "state": "blocked"}], "audio_cues": []},
			],
		},
		"game_facts": [
			{"fact_type": "blackjack.commitment_accepted", "fact_version": 1, "boundary": "action", "visibility": "public", "payload": {"total_wager": "int"}},
			{"fact_type": "blackjack.hand_resolved", "fact_version": 1, "boundary": "action", "visibility": "public", "payload": {"net_change": "int", "outcomes": "string_array"}},
			{"fact_type": "blackjack.heat_changed", "fact_version": 1, "boundary": "action", "visibility": "public", "payload": {"heat": "int", "tier": "string"}},
		],
		"ritual_persistence": {
			"authoritative_serialized": ["table", "shoe", "session", "wager_debited", "phase_boundary", "last_result"],
			"derived_projection": ["actors", "scene_objects", "energy", "hit_regions", "readable_totals"],
			"transient_presentation": ["gesture_origin", "gesture_active", "animation_progress", "hover", "focus"],
			"one_shot_receipted": ["deal_audio", "reveal_audio", "settlement_audio", "payout_animation"],
			"save_boundaries": ["wagering", "initial_deal", "player_turn", "dealer_procedure", "settlement"],
			"restore_policy": "restore_legal_phase_without_replay",
		},
		"handler_registry": [{
			"handler_id": BLACKJACK_RITUAL_HANDLER_ID,
			"version": 1,
			"accepted_actions": action_ids,
			"accepted_operations": [],
			"inputs": {"phase_id": "string"},
			"outputs": {"public_projection": "qualified_id"},
			"authority": "blackjack_game_rules",
			"persisted_state": ["table", "session", "wager_debited", "last_result"],
			"transient_state": ["gesture_origin", "animation_progress"],
			"rng": {"owner": "blackjack_game_rules", "stream": "existing_action_stream", "consumption": "accepted_authoritative_action_only"},
			"emitted_facts": ["blackjack.commitment_accepted", "blackjack.hand_resolved", "blackjack.heat_changed"],
			"rejection": "side_effect_free",
		}],
		"declared_targets": {
			"anchors": ["station.dealer", "seat.0", "seat.1", "seat.2", "seat.3", "pit.rail", "shoe.anchor", "discard.anchor", "wager.anchor", "dealer_hand.anchor", "rail.open_space"],
			"regions": ["chip.rail", "wager.circle", "shoe.region", "player_hand.region", "player_wave.region", "peek.region"],
			"sealed_host_targets": [],
		},
	}


func _blackjack_ritual_phase(phase_id: String, permitted_actions: Array, transitions: Array) -> Dictionary:
	return {"id": phase_id, "entry_conditions": [], "permitted_actions": permitted_actions, "entry_operations": [], "transitions": transitions, "terminal": false}


func _blackjack_gesture_contract(verb: String, gesture_id: String, action_id: String, phase_id: String, return_policy: String) -> Dictionary:
	var equivalent_target_selection := "cycle" if gesture_id == BLACKJACK_WAGER_PLACE_GESTURE else "focus"
	return {
		"id": gesture_id,
		"verb": verb,
		"source_region": "chip.rail" if verb == "place" else "shoe.region" if gesture_id == BLACKJACK_CUT_GESTURE else "player_hand.region",
		"target_regions": ["wager.circle"] if verb == "place" else ["shoe.region"] if gesture_id == BLACKJACK_CUT_GESTURE else ["player_wave.region"] if gesture_id == BLACKJACK_WAVE_GESTURE else ["player_hand.region"],
		"bounds": {"space": "design", "min_distance": 22 if verb == "place" else 42 if gesture_id == BLACKJACK_WAVE_GESTURE else 0, "max_distance": 520},
		"phases": [phase_id],
		"accepted_action": action_id,
		"rejection": return_policy,
		"rejection_effects": [],
		"equivalents": {
			"keyboard": {"action_id": action_id, "target_selection": equivalent_target_selection},
			"controller": {"action_id": action_id, "target_selection": equivalent_target_selection},
			"reduced_motion": {"action_id": action_id, "target_selection": equivalent_target_selection, "staging": "instant"},
		},
	}


func _blackjack_actor_contract(actor_id: String, role: String, anchor: String, poses: Array, behaviors: Array) -> Dictionary:
	return {"id": actor_id, "role": role, "anchor": anchor, "poses": poses, "behavior_states": behaviors, "initial_pose": str(poses[0]), "initial_behavior": str(behaviors[0]), "fact_reactions": []}


func _blackjack_object_contract(object_id: String, anchor: String, bounds: Dictionary, visual_states: Array, functional_states: Array) -> Dictionary:
	return {"id": object_id, "anchor": anchor, "bounds": bounds, "z_layer": "gameplay", "visual_states": visual_states, "functional_states": functional_states, "initial_visual_state": str(visual_states[0]), "initial_functional_state": str(functional_states[0]), "hit_regions": [], "text_safety_regions": []}


func blackjack_ritual_deal_envelope(session: Dictionary, environment: Dictionary) -> Dictionary:
	var session_id := _blackjack_ritual_safe_id(str(session.get("session_id", "%s:%s:0" % [get_id(), str(environment.get("id", "table"))])))
	var ordinal := maxi(0, int(session.get("cards_consumed", 0)) + int(session.get("active_hand_index", 0)))
	var boundary_id := "blackjack:wagering:%d" % ordinal
	var command_id := "%s:deal:%d" % [session_id, ordinal]
	var request_key := "%s:request" % command_id
	var receipt_key := "%s:command" % command_id
	var operation_receipt_key := "%s:binding" % command_id
	var authenticated_action := {
		"origin_owner_id": BLACKJACK_RITUAL_ID,
		"stable_action_id": BLACKJACK_CHARGED_DEAL_ACTION,
		"operation_receipt_key": operation_receipt_key,
		"boundary_id": boundary_id,
		"fingerprint": ("%s|%s|%s|%s" % [BLACKJACK_RITUAL_ID, BLACKJACK_CHARGED_DEAL_ACTION, operation_receipt_key, boundary_id]).sha256_text(),
	}
	var boundary := {
		"boundary_id": boundary_id,
		"kind": "command",
		"ritual_id": BLACKJACK_RITUAL_ID,
		"session_id": session_id,
		"phase_id": "wagering",
		"ordinal": ordinal,
		"cause_receipt_key": receipt_key,
	}
	var envelope := {
		"envelope_version": 1,
		"ritual_id": BLACKJACK_RITUAL_ID,
		"session_id": session_id,
		"command_id": command_id,
		"request_key": request_key,
		"action_id": BLACKJACK_CHARGED_DEAL_ACTION,
		"expected_phase": "wagering",
		"source_id": "shoe.primary",
		"target_id": "wager.player",
		"parameters": {},
		"authenticated_action": authenticated_action,
		"boundary": boundary,
		"receipt_key": receipt_key,
		"content_fingerprint": "",
	}
	envelope["content_fingerprint"] = _blackjack_ritual_envelope_fingerprint(envelope)
	return envelope


func blackjack_ritual_deal_envelope_authorized(envelope: Dictionary, current_phase: String = "wagering") -> bool:
	var expected_keys := ["action_id", "authenticated_action", "boundary", "command_id", "content_fingerprint", "envelope_version", "expected_phase", "parameters", "receipt_key", "request_key", "ritual_id", "session_id", "source_id", "target_id"]
	var actual_keys := envelope.keys()
	actual_keys.sort()
	expected_keys.sort()
	if actual_keys != expected_keys or int(envelope.get("envelope_version", 0)) != 1:
		return false
	if str(envelope.get("ritual_id", "")) != BLACKJACK_RITUAL_ID or str(envelope.get("action_id", "")) != BLACKJACK_CHARGED_DEAL_ACTION:
		return false
	if str(envelope.get("expected_phase", "")) != current_phase or current_phase != "wagering":
		return false
	if str(envelope.get("source_id", "")) != "shoe.primary" or str(envelope.get("target_id", "")) != "wager.player":
		return false
	if typeof(envelope.get("parameters", null)) != TYPE_DICTIONARY or not (envelope.get("parameters", {}) as Dictionary).is_empty():
		return false
	for id_field in ["session_id", "command_id", "request_key", "receipt_key"]:
		if not _blackjack_ritual_id_is_safe(str(envelope.get(id_field, ""))):
			return false
	if str(envelope.get("content_fingerprint", "")) != _blackjack_ritual_envelope_fingerprint(envelope):
		return false
	var authenticated_action: Dictionary = envelope.get("authenticated_action", {}) if typeof(envelope.get("authenticated_action", {})) == TYPE_DICTIONARY else {}
	var expected_authenticated_keys := ["boundary_id", "fingerprint", "operation_receipt_key", "origin_owner_id", "stable_action_id"]
	var authenticated_keys := authenticated_action.keys()
	authenticated_keys.sort()
	expected_authenticated_keys.sort()
	if authenticated_keys != expected_authenticated_keys:
		return false
	if str(authenticated_action.get("origin_owner_id", "")) != BLACKJACK_RITUAL_ID or str(authenticated_action.get("stable_action_id", "")) != BLACKJACK_CHARGED_DEAL_ACTION:
		return false
	if not _blackjack_ritual_id_is_safe(str(authenticated_action.get("operation_receipt_key", ""))) or not _blackjack_ritual_sha256_is_valid(str(authenticated_action.get("fingerprint", ""))):
		return false
	var boundary: Dictionary = envelope.get("boundary", {}) if typeof(envelope.get("boundary", {})) == TYPE_DICTIONARY else {}
	var expected_boundary_keys := ["boundary_id", "cause_receipt_key", "kind", "ordinal", "phase_id", "ritual_id", "session_id"]
	var boundary_keys := boundary.keys()
	boundary_keys.sort()
	expected_boundary_keys.sort()
	if boundary_keys != expected_boundary_keys:
		return false
	if str(boundary.get("kind", "")) != "command" or str(boundary.get("phase_id", "")) != current_phase or int(boundary.get("ordinal", -1)) < 0:
		return false
	if str(boundary.get("ritual_id", "")) != BLACKJACK_RITUAL_ID or str(boundary.get("session_id", "")) != str(envelope.get("session_id", "")):
		return false
	if str(boundary.get("cause_receipt_key", "")) != str(envelope.get("receipt_key", "")) or str(boundary.get("boundary_id", "")) != str(authenticated_action.get("boundary_id", "")):
		return false
	var contract := blackjack_ritual_contract()
	var declared_handler := ""
	for declaration_value in contract.get("action_declarations", []):
		if typeof(declaration_value) == TYPE_DICTIONARY and str((declaration_value as Dictionary).get("action_id", "")) == BLACKJACK_CHARGED_DEAL_ACTION:
			declared_handler = str((declaration_value as Dictionary).get("handler_id", ""))
			break
	if declared_handler != BLACKJACK_RITUAL_HANDLER_ID:
		return false
	for handler_value in contract.get("handler_registry", []):
		if typeof(handler_value) == TYPE_DICTIONARY:
			var handler: Dictionary = handler_value
			if str(handler.get("handler_id", "")) == declared_handler:
				return (handler.get("accepted_actions", []) as Array).has(BLACKJACK_CHARGED_DEAL_ACTION)
	return false


func _blackjack_ritual_envelope_fingerprint(envelope: Dictionary) -> String:
	var fingerprint_source := envelope.duplicate(true)
	fingerprint_source.erase("content_fingerprint")
	return JSON.stringify(fingerprint_source, "", true).sha256_text()


func _blackjack_ritual_safe_id(value: String) -> String:
	var normalized := ""
	for character in value.to_lower():
		if character in "abcdefghijklmnopqrstuvwxyz0123456789_.:-":
			normalized += character
		else:
			normalized += "-"
	return normalized.left(192) if not normalized.is_empty() else "blackjack"


func _blackjack_ritual_id_is_safe(value: String) -> bool:
	return not value.is_empty() and value.length() <= 192 and value == _blackjack_ritual_safe_id(value)


func _blackjack_ritual_sha256_is_valid(value: String) -> bool:
	if value.length() != 64 or value != value.to_lower():
		return false
	for character in value:
		if not character in "0123456789abcdef":
			return false
	return true


func enter(run_state: RunState, environment: Dictionary) -> Dictionary:
	var result: Dictionary = super.enter(run_state, environment)
	var table: Dictionary = _table_state_preview(run_state, environment)
	if _is_rourke_duel(run_state, environment):
		var duel := run_state.grand_casino_duel_status()
		result["message"] = str(duel.get("last_bark", "Sit down. Five hands. Then the door decides."))
		return result
	if bool(table.get("barred", false)):
		result["message"] = str(table.get("barred_reason", "The dealer refuses to let you play this table after the cheating confrontation."))
		return result
	var side_bets: Array = _side_bet_labels(_available_side_bets(table))
	var rules: Dictionary = _table_rules(table)
	result["message"] = "%s watches the shoe. Side bets: %s. Blackjack pays %s; dealer %s soft 17; insurance opens on an ace." % [
		str(table.get("dealer_name", "The dealer")),
		", ".join(side_bets) if not side_bets.is_empty() else "none",
		BLACKJACK_PAYOUT_LABEL,
		"hits" if bool(rules.get("dealer_hits_soft_17", false)) else "stands on",
	]
	return result


func legal_actions(run_state: RunState, environment: Dictionary) -> Array:
	if bool(_table_state_preview(run_state, environment).get("barred", false)):
		return []
	return super.legal_actions(run_state, environment)


func cheat_actions(run_state: RunState, environment: Dictionary) -> Array:
	if bool(_table_state_preview(run_state, environment).get("barred", false)):
		return []
	return super.cheat_actions(run_state, environment)


func actions(run_state: RunState, environment: Dictionary) -> Dictionary:
	var result: Dictionary = super.actions(run_state, environment)
	result["stake_floor"] = _surface_stake_floor(run_state, environment)
	result["stake_ceiling"] = _surface_stake_ceiling(run_state, environment)
	result["base_stake_ceiling"] = _blackjack_base_stake_ceiling(run_state, environment)
	result["economy_stake_ceiling"] = _surface_stake_ceiling(run_state, environment)
	result["economy_pressure_applied"] = false
	return result


func generate_environment_state(run_state: RunState, environment: Dictionary, rng: RngStream) -> Dictionary:
	var deck_count_options: Array = [2, 3, 4, 6]
	var deck_count: int = int(rng.pick(deck_count_options, 6))
	var shoe: Array = _build_shoe(deck_count, rng)
	var cut_remaining := CardShoeScript.cut_card_remaining(deck_count)
	# Act 1 tables intentionally model common shoe variants: S17/H17, DAS/no
	# DAS, split to 3-4 hands, and late surrender.
	var rule_variants: Array = [
		{"dealer_hits_soft_17": false, "double_after_split": true, "split_aces_one_card": false, "max_split_hands": 4, "late_surrender": true},
		{"dealer_hits_soft_17": true, "double_after_split": true, "split_aces_one_card": false, "max_split_hands": 3, "late_surrender": false},
		{"dealer_hits_soft_17": false, "double_after_split": true, "split_aces_one_card": false, "max_split_hands": 4, "late_surrender": true},
	]
	var rules: Dictionary = (rng.pick(rule_variants, rule_variants[0]) as Dictionary).duplicate(true)
	var side_bet_min: int = 2
	var side_bet_max: int = BLACKJACK_MAX_SIDE_BETS
	var side_bet_count: int = rng.randi_range(side_bet_min, side_bet_max)
	var side_bets: Array = rng.pick_many(_side_bet_catalog(), side_bet_count)
	var security: Dictionary = environment.get("security_profile", {}) if typeof(environment.get("security_profile", {})) == TYPE_DICTIONARY else {}
	var strictness := str(security.get("strictness", "low"))
	var catch_base := 10
	match strictness:
		"high":
			catch_base = 18
		"boss":
			catch_base = 22
		"private", "uneven":
			catch_base = 14
		_:
			catch_base = 9
	var dealer_profile: Dictionary = _generate_dealer_profile(rng, catch_base)
	var patrons: Array = _generate_table_patrons(rng, int(environment.get("depth", 0)))
	var distractions: Array = _generate_table_distractions(rng)
	var table_limit := maxi(25, GameModule.stake_ceiling_for_game(environment, get_id(), run_state.wager_capacity_for_game(get_id(), environment) if run_state != null else 25))
	var chip_denominations := [1, 5, 10, 25]
	if table_limit >= 60:
		chip_denominations.append(50)
	if table_limit >= 150:
		chip_denominations.append(100)
	var state := {
		"schema": "blackjack_table_state",
		"version": 2,
		"table_name": str(rng.pick(["Neon Felt", "Back Room 21", "Hot Shoe", "Midnight Double"], "Neon Felt")),
		"dealer_name": str(rng.pick(["Mara", "Lee", "Rook", "Vega", "June"], "Mara")),
		"deck_count": deck_count,
		"shoe": shoe,
		"shoe_cursor": 0,
		"cut_card_at": deck_count * CardShoeScript.CARDS_PER_DECK - cut_remaining,
		"cut_card_remaining": cut_remaining,
		"shoe_remaining": shoe.size(),
		"shoe_composition": CardShoeScript.remaining_composition(shoe),
		"shoe_label": CardShoeScript.shoe_label(deck_count),
		"count_efficiency": CardShoeScript.count_efficiency_label(deck_count),
		"hands_played": 0,
		"running_count": 0,
		"recorded_running_count": 0,
		"shoe_generation": 1,
		"recorded_count_shoe_generation": 0,
		"count_accuracy_streak": 0,
		"counter_observation_hands": 0,
		"counter_observation_samples": [],
		"counter_evidence_points": 0,
		"counter_miss_streak": 0,
		"counter_last_assessment": {},
		"rules": rules,
		"side_bets": side_bets,
		"dealer_profile": dealer_profile,
		"patrons": patrons,
		"distractions": distractions,
		"chip_denominations": chip_denominations,
		"table_layout": "immersive_blackjack",
		"dealer_catch_base": catch_base,
		"catch_heat": catch_base + 8,
		"strategy_deviation_strikes": 0,
		"strategy_watch_pressure": 0,
		"last_result": {},
		"table_round_timer_started_msec": 0,
	}
	return _configure_rourke_duel_table(state, run_state, environment)


func environment_state_generated(run_state: RunState, environment: Dictionary, generated_state: Dictionary) -> void:
	_apply_grand_casino_dealer_assignment(generated_state, run_state, environment)


func _configure_rourke_duel_table(table: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if not _is_rourke_duel(run_state, environment):
		return table
	var duel := run_state.grand_casino_duel_status()
	var terms := run_state.grand_casino_duel_terms()
	var attempt := maxi(1, int(duel.get("attempt", run_state.narrative_flags.get("grand_casino_showdown_attempt", 1))))
	var table_rng := run_state.create_rng("grand_casino_duel").fork("attempt:%d:table" % attempt)
	var deck_count := 2
	var shoe := _build_shoe(deck_count, table_rng)
	table["boss_variant"] = ROURKE_DUEL_VARIANT
	table["table_name"] = "Rourke's House Table"
	table["dealer_name"] = "Rourke"
	table["deck_count"] = deck_count
	table["shoe"] = shoe
	table["shoe_cursor"] = 0
	table["shoe_remaining"] = shoe.size()
	table["shoe_composition"] = CardShoeScript.remaining_composition(shoe)
	table["shoe_label"] = CardShoeScript.shoe_label(deck_count)
	table["count_efficiency"] = CardShoeScript.count_efficiency_label(deck_count)
	table["cut_card_at"] = shoe.size()
	table["cut_card_remaining"] = 0
	table["rules"] = {
		"dealer_hits_soft_17": false,
		"double_after_split": false,
		"split_aces_one_card": true,
		"max_split_hands": 1,
		"late_surrender": false,
	}
	table["side_bets"] = []
	table["patrons"] = []
	table["distractions"] = []
	table["counting_enabled"] = false
	table["dealer_catch_base"] = clampi(
		int(_local_copy_dict(terms.get("rules", {})).get("player_cheat_detection_base", 55))
		+ int(terms.get("rourke_aggression", 1)) * 5,
		55,
		95
	)
	table["catch_heat"] = 0
	table["dealer_profile"] = {
		"style_id": "rourke",
		"tell": "His eyes stay on your hands.",
		"body_language": "Still shoulders; one thumb on the shoe.",
		"attention": 100,
		"blink_offset": int(table_rng.randi_range(0, 900)),
		"uniform_accent": "house_gold",
	}
	return table


func _is_rourke_duel(run_state: RunState, environment: Dictionary) -> bool:
	if run_state == null:
		return false
	var flags: Dictionary = environment.get("local_narrative_flags", {}) if typeof(environment.get("local_narrative_flags", {})) == TYPE_DICTIONARY else {}
	return str(flags.get("blackjack_boss_variant", "")) == ROURKE_DUEL_VARIANT and run_state.grand_casino_duel_active(environment)


func surface_state(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	var table: Dictionary = _surface_table_state(run_state, environment)
	var session: Dictionary = _normalized_session(run_state, environment, ui_state, table)
	var wager_currency := GameModule.presentation_currency_for_game(run_state, get_id(), environment)
	var now_msec := int(ui_state.get("surface_time_msec", Time.get_ticks_msec()))
	session["surface_time_msec"] = now_msec
	var presentation_msec := _blackjack_presentation_time_msec(session, now_msec)
	session["surface_presentation_time_msec"] = presentation_msec
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	var active_hand: Dictionary = hands[active_index] if active_index >= 0 and active_index < hands.size() else {}
	var active_cards: Array = _card_array(active_hand.get("cards", []))
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	var last_result: Dictionary = _local_copy_dict(table.get("last_result", {}))
	var dealt := _has_dealt_hand(session)
	var barred := bool(table.get("barred", false))
	if not dealt and not last_result.is_empty():
		var result_patron_hands: Array = _hand_array(last_result.get("patron_hands", []))
		if not result_patron_hands.is_empty():
			session["patron_hands"] = result_patron_hands
	var patron_hands: Array = _hand_array(session.get("patron_hands", []))
	var showdown_dealer_cards: Array = _card_array(last_result.get("dealer_cards", []))
	var display_dealer_cards: Array = dealer_cards
	if display_dealer_cards.is_empty() and not showdown_dealer_cards.is_empty():
		display_dealer_cards = showdown_dealer_cards
	var dealer_view: Array = _dealer_view(display_dealer_cards, bool(session.get("dealer_hole_visible", false)) or dealer_cards.is_empty())
	var total_info: Dictionary = _hand_total_info(active_cards)
	var selected_stake: int = _effective_table_stake(_session_stake(int(ui_state.get("selected_stake", session.get("selected_stake", 1))), session), session, run_state, environment)
	var available_side_bets: Array = _available_side_bets_for_session(table, session)
	for i in range(available_side_bets.size()):
		var available_bet: Dictionary = available_side_bets[i]
		available_bet = _item_adjusted_side_bet_for_surface(available_bet, run_state)
		available_bet["surface_enabled"] = _side_bet_can_toggle_now(available_bet, session) and not barred
		available_side_bets[i] = available_bet
	var active_side_bets: Array = _valid_side_bet_ids_for_session(_string_array(session.get("blackjack_side_bets", [])), table, session)
	session["blackjack_side_bets"] = active_side_bets
	var side_bet_stakes: Dictionary = {}
	for side_bet in available_side_bets:
		var side_bet_id := str(side_bet.get("id", ""))
		side_bet_stakes[side_bet_id] = _side_bet_stake(selected_stake, side_bet, run_state)
	var patrons: Array = GameModule.patrons_with_talk_focus(_patrons_for_surface(table, session), ui_state.get("focused_talk_speaker", {}))
	var snitch_pressure := _patron_snitch_risk_from_patrons(patrons)
	var dealer_focus: Dictionary = _dealer_focus_state(table, session, run_state, snitch_pressure)
	var distraction_active: bool = bool(dealer_focus.get("peek_window_open", bool(dealer_focus.get("lookaway_active", false))))
	var ambient_event: Dictionary = _ambient_table_event(table, session)
	var deal_active_id := str(session.get("deal_animation_id", table.get("last_deal_animation_id", "")))
	var deal_started_msec := int(session.get("deal_started_msec", table.get("last_deal_started_msec", 0)))
	var deal_events: Array = _deal_animation_event_array(session.get("deal_animation_events", table.get("last_deal_animation_events", [])))
	var patron_action_source: Variant = session.get("patron_action_events", []) if dealt else table.get("last_patron_action_events", [])
	var patron_action_events: Array = _patron_action_event_array(patron_action_source)
	if not dealt and not last_result.is_empty() and patron_action_events.is_empty():
		patron_action_events = _patron_action_event_array(last_result.get("patron_action_events", []))
	var deal_duration_msec := maxi(_deal_animation_duration_msec(deal_events), _patron_action_animation_duration_msec(patron_action_events))
	if deal_events.is_empty() and patron_action_events.is_empty():
		deal_active_id = ""
		deal_started_msec = 0
	var attention_active_id := str(session.get("dealer_lookaway_id", ""))
	var attention_started_msec := int(session.get("dealer_lookaway_started_msec", 0))
	var attention_duration_msec := int(session.get("dealer_lookaway_duration_msec", 0))
	var count_challenge: Dictionary = _local_copy_dict(session.get("count_challenge", {}))
	var count_active := not count_challenge.is_empty() and not bool(session.get("count_answered", false))
	var round_complete := dealt and _all_hands_complete(session)
	var dealer_blackjack_pending := dealt and _dealer_has_blackjack(dealer_cards)
	var dealer_focus_runtime: Dictionary = {
		"dealer_lookaway_started_msec": attention_started_msec,
		"dealer_lookaway_duration_msec": attention_duration_msec,
		"dealer_distraction_noise": int(session.get("dealer_distraction_noise", 0)),
		"dealer_distraction_cover": int(session.get("dealer_distraction_cover", 0)),
		"count_active": count_active,
		"count_attention_risk": int(count_challenge.get("dealer_attention_risk", 0)),
		"strategy_attention_boost": int(session.get("strategy_attention_boost", 0)),
	}
	var table_notice := _table_notice_for_session(session, table)
	var payout_active_id := str(last_result.get("payout_animation_id", ""))
	var payout_started_msec := _blackjack_payout_started_msec(last_result, deal_started_msec, deal_duration_msec)
	# Deal and payout channels run on the presentation clock so their liveness
	# must be decided against that same clock. Comparing them with the simulation
	# clock could disable a payout before the canvas had presented its first frame.
	var deal_animation_active := not deal_active_id.is_empty() and deal_started_msec > 0 and presentation_msec - deal_started_msec >= 0 and presentation_msec - deal_started_msec < deal_duration_msec
	var payout_animation_active := not payout_active_id.is_empty() and payout_started_msec > 0 and presentation_msec - payout_started_msec >= 0 and presentation_msec - payout_started_msec < PAYOUT_ANIMATION_DURATION_MSEC
	var timer_active := not dealt and not barred and not deal_animation_active and not payout_animation_active and (run_state == null or not run_state.is_tutorial_run())
	var round_timer := GameModule.table_round_timer_status_peek(table, now_msec, "Next hand") if timer_active else {}
	if timer_active and bool(round_timer.get("active", false)) and table_notice == "Slide chips, choose side bets, then press DEAL.":
		var timer_seconds := int(round_timer.get("remaining_seconds", 0))
		if timer_seconds > 0:
			table_notice = "Place chips or watch; next hand in %ds." % timer_seconds
		else:
			table_notice = "Place chips or watch the next hand."
	var chip_denominations: Array = _chip_denominations(table)
	if table_notice.is_empty():
		table_notice = _table_notice_for_session(session, table)
	if barred:
		table_notice = str(table.get("barred_reason", "The dealer has barred you from this blackjack table."))
	if not dealt and not last_result.is_empty():
		table_notice = str(last_result.get("summary", ""))
	elif table_notice.is_empty() and not last_result.is_empty():
		table_notice = str(last_result.get("summary", ""))
	var persisted_recorded_count := int(table.get("recorded_running_count", 0))
	var hand_count_delta := int(session.get("count_delta", 0))
	var live_recorded_count := _recorded_count_for_surface(table, session)
	var live_true_count := _true_count_for_surface(table, session)
	var between_hands := not dealt and not last_result.is_empty()
	var between_hands_count_visible := between_hands and bool(table.get("counting_enabled", false))
	var rules_for_surface: Dictionary = _table_rules(table)
	var effective_stake_ceiling := _max_table_stake_for_blackjack(session, table, run_state, environment)
	var effective_floor := _surface_stake_floor(run_state, environment)
	var wager_blocked := not dealt and not barred and not _is_rourke_duel(run_state, environment) and effective_stake_ceiling < effective_floor
	var wager_blocked_reason := "Minimum wager $%d; $%d available." % [effective_floor, maxi(0, effective_stake_ceiling)] if wager_blocked else ""
	if wager_blocked and last_result.is_empty() and not deal_animation_active and not payout_animation_active:
		table_notice = wager_blocked_reason
	if not dealt and not bool(session.get("locked_stake", false)):
		selected_stake = effective_floor if effective_stake_ceiling < effective_floor else clampi(selected_stake, effective_floor, effective_stake_ceiling)
		session["selected_stake"] = selected_stake
	var main_wager_cost := _main_wager_cost(selected_stake, session)
	var total_wager_cost := _wager_cost_from_session(selected_stake, session, table, run_state)
	var shoe_remaining_value := _shoe_remaining(table)
	var shoe_label_value := str(table.get("shoe_label", CardShoeScript.shoe_label(int(table.get("deck_count", 6)))))
	var spec := GameModule.surface_spec({
		"surface_renderer": "blackjack",
		"wager_currency": wager_currency,
		"surface_renderer_opaque": true,
		"surface_time_msec": now_msec,
		"surface_presentation_time_msec": presentation_msec,
		"surface_life": "immersive_table",
		"surface_cast": "dealer_table",
		"surface_controls_native": true,
		"surface_stake_controls_required": true,
		"surface_embeds_outcomes": true,
		"surface_animates_idle": true,
		# The deliberately stepped low-detail cast keeps the dealer and patrons
		# visibly alive without rebuilding the full table 60 times per second.
		# Any active deal, attention, count, or payout channel leaves this mode and
		# returns to the full 60 FPS surface cadence.
		"surface_native_low_detail_idle": true,
		"surface_native_idle_animation_fps": 15.0,
		"surface_web_idle_animation_fps": 12.0,
		"surface_dynamic_overlay_channels": [DEAL_ANIMATION_CHANNEL, ATTENTION_ANIMATION_CHANNEL, COUNT_ANIMATION_CHANNEL, PAYOUT_ANIMATION_CHANNEL],
		"surface_realtime_state_refresh": false,
		"money_presentation_animation_channel": DEAL_ANIMATION_CHANNEL,
		"surface_ui_protected_regions": _blackjack_ui_protected_regions(count_challenge),
		"surface_ui_preference_keys": ["blackjack_side_bets"],
		"surface_action_blocks": [{
			"actions": ["blackjack_deal", BLACKJACK_SETTLE_ACTION, "blackjack_hit", "blackjack_stand", "blackjack_double", "blackjack_split", "blackjack_surrender"],
			"while_animation": DEAL_ANIMATION_CHANNEL,
			"reason": "Let the cards finish moving before choosing the next play.",
		}],
		"surface_hover_ui_protected_regions": [
			_blackjack_ui_rect(236, 202, 428, 108, "blackjack_side_bet"),
		],
		"surface_state_labels": _surface_state_labels(table, session),
		"surface_animation_channels": [
			GameModule.surface_animation_channel(
				DEAL_ANIMATION_CHANNEL,
				deal_active_id,
				deal_duration_msec,
				deal_started_msec,
				{
					"active": deal_animation_active,
					"clock_source": "presentation",
					"metadata": {"event_count": deal_events.size()},
				}
			),
			GameModule.surface_animation_channel(
				ATTENTION_ANIMATION_CHANNEL,
				attention_active_id,
				attention_duration_msec,
				attention_started_msec,
				{"clock_source": "surface"}
			),
			GameModule.surface_animation_channel(
				COUNT_ANIMATION_CHANNEL,
				str(count_challenge.get("challenge_id", "")),
				0 if count_active else 2600,
				int(count_challenge.get("started_msec", 0)),
				{"clock_source": "surface"}
			),
			GameModule.surface_animation_channel(
				PAYOUT_ANIMATION_CHANNEL,
				payout_active_id,
				PAYOUT_ANIMATION_DURATION_MSEC if not payout_active_id.is_empty() else 0,
				payout_started_msec,
				{"active": payout_animation_active, "clock_source": "presentation"}
			),
		],
		"phase": "barred" if barred else "settling" if round_complete else "decision" if dealt else "betting",
		"table_barred": barred,
		"barred_reason": str(table.get("barred_reason", "")),
		"table_name": str(table.get("table_name", "Blackjack")),
		"dealer_name": str(table.get("dealer_name", "Dealer")),
		"dealer_profile": _local_copy_dict(table.get("dealer_profile", {})),
		"dealer_focus": dealer_focus,
		"dealer_focus_runtime": dealer_focus_runtime,
		"ambient_table_event": ambient_event,
		"hands_played": int(table.get("hands_played", 0)),
		"patrons": patrons,
		"patron_wager_action": "blackjack_patron_bet",
		"patron_hands": patron_hands,
		"patron_action_events": patron_action_events,
		"deal_animation_id": deal_active_id,
		"deal_started_msec": deal_started_msec,
		"deal_animation_events": deal_events,
		"deal_animation_duration_msec": deal_duration_msec,
		"payout_animation_id": payout_active_id,
		"payout_started_msec": payout_started_msec,
		"last_result": last_result,
		"showdown_active": between_hands,
		"between_hands": between_hands,
		"between_hands_count_visible": between_hands_count_visible,
		"between_hands_recorded_running_count": persisted_recorded_count,
		"showdown_player_hands": _hand_array(last_result.get("player_hands", [])),
		"showdown_dealer_cards": showdown_dealer_cards,
		"result_message": str(last_result.get("summary", "")),
		"table_notice": table_notice,
		"table_round_timer": round_timer,
		"active_hand_status": _active_hand_status_text(session),
		"round_complete": round_complete,
		"settle_available": round_complete or dealer_blackjack_pending,
		"dealer_blackjack_pending": dealer_blackjack_pending,
		"distractions": _dictionary_array(table.get("distractions", [])),
		"chip_denominations": chip_denominations,
		"selected_stake": selected_stake,
		"minimum_wager": effective_floor,
		"wager_blocked": wager_blocked,
		"wager_blocked_reason": wager_blocked_reason,
		"stake_ceiling": effective_stake_ceiling,
		"economy_stake_ceiling": effective_stake_ceiling,
		"chip_stack": _chip_stack_for_stake(selected_stake, chip_denominations),
		"rules": rules_for_surface,
		"table_rules_text": _table_rules_text_from_values(rules_for_surface, total_wager_cost, shoe_label_value, shoe_remaining_value),
		"player_hands": hands,
		"dealer": dealer_view,
		"dealer_cards": display_dealer_cards,
		"dealer_hole_visible": bool(session.get("dealer_hole_visible", false)),
		"active_hand_index": active_index,
		"blackjack_total": int(total_info.get("total", 0)),
		"blackjack_soft": bool(total_info.get("soft", false)),
		"basic_strategy_advice": _basic_strategy_advice(session, table, run_state),
		"count_hint": _count_hint(run_state, table, session),
		"crew_play_status": run_state.crew_play_active_status(get_id(), environment) if run_state != null else [],
		"counting_enabled": bool(table.get("counting_enabled", false)),
		"table_modifier": _table_summary(table),
		"side_bets_available": available_side_bets,
		"side_bets_active": active_side_bets,
		"side_bet_stakes": side_bet_stakes,
		"main_wager_cost": main_wager_cost,
		"total_wager_cost": total_wager_cost,
		"can_deal": not dealt and not barred and not wager_blocked,
		"can_hit": _can_hit(session) and not barred,
		"can_stand": _can_stand(session) and not barred,
		"can_double": _can_double(session, table, selected_stake, run_state) and not barred,
		"can_split": _can_split(session, table, selected_stake, run_state) and not barred,
		"can_surrender": _can_surrender(session, table) and not barred,
		"can_change_side_bets": _can_change_side_bets(session) and not barred,
		"peek_window_open": distraction_active,
		"peek_available": dealt and not bool(session.get("dealer_hole_visible", false)) and not barred,
		"peek_dangerous": dealt and not distraction_active and not bool(session.get("dealer_hole_visible", false)) and not barred,
		"snitch_pressure": snitch_pressure,
		"strategy_watch_pressure": int(table.get("strategy_watch_pressure", 0)),
		"strategy_deviation_score": int(session.get("strategy_deviation_score", 0)),
		"strategy_confronted": bool(session.get("strategy_confronted", false)),
		"count_challenge": count_challenge,
		"count_answered": bool(session.get("count_answered", false)),
		"count_correct": bool(session.get("count_correct", false)),
		"count_delta": int(session.get("count_delta", 0)),
		"count_hand_delta": hand_count_delta,
		"count_declared_delta": int(session.get("count_declared_delta", 0)),
		"count_perfect": bool(session.get("count_perfect", false)),
		"persisted_recorded_running_count": persisted_recorded_count,
		"recorded_running_count": live_recorded_count,
		"persisted_running_count": int(table.get("running_count", 0)),
		"running_count": live_true_count,
		"shoe_remaining": shoe_remaining_value,
		"shoe_label": shoe_label_value,
		"deck_count": int(table.get("deck_count", 6)),
		"cut_card_remaining": int(table.get("cut_card_remaining", CardShoeScript.cut_card_remaining(int(table.get("deck_count", 6))))),
		"count_efficiency": str(table.get("count_efficiency", CardShoeScript.count_efficiency_label(int(table.get("deck_count", 6))))),
		"shoe_composition": _local_copy_dict(table.get("shoe_composition", CardShoeScript.remaining_composition(table.get("shoe", [])))),
		"native_selected_surface_actions": _selected_surface_actions(ui_state, session),
		"surface_action_bindings": {
			"legal": {"action": "blackjack_deal", "index": 0, "ritual_gesture_id": BLACKJACK_CUT_GESTURE, "target_selection": "focus", "target_id": "shoe.primary"},
			"cheat": {"action": "blackjack_count_toggle", "index": 0},
			"surface_stake_down": {"action": "blackjack_clear_bet", "index": 0},
			"surface_stake_up": {"action": "blackjack_chip", "index": 0, "ritual_gesture_id": BLACKJACK_WAGER_PLACE_GESTURE, "target_selection": "cycle", "target_id": "wager.player"},
			"surface_stake_max": {"action": "blackjack_max_bet", "index": 0},
		},
		"ritual_equivalent_bindings": {
			BLACKJACK_WAGER_PLACE_GESTURE: {"action": "blackjack_chip", "target_id": "wager.player", "target_selection": ["focus", "cycle"], "keyboard_binding": "surface_stake_up", "controller_binding": "surface_stake_up", "reduced_motion_staging": "instant"},
			BLACKJACK_CUT_GESTURE: {"action": "blackjack_deal", "target_id": "shoe.primary", "target_selection": ["focus"], "keyboard_binding": "legal", "controller_binding": "legal", "reduced_motion_staging": "instant"},
			BLACKJACK_TAP_GESTURE: {"action": "blackjack_hit", "target_id": "player_hand.region", "target_selection": ["focus", "cycle"], "keyboard_binding": "focused_surface_region", "controller_binding": "focused_surface_region", "reduced_motion_staging": "instant"},
			BLACKJACK_WAVE_GESTURE: {"action": "blackjack_stand", "target_id": "player_hand.region", "target_selection": ["focus", "cycle"], "keyboard_binding": "focused_surface_region", "controller_binding": "focused_surface_region", "reduced_motion_staging": "instant"},
		},
		"surface_audio": GameModule.surface_audio_spec({
			"profile_id": "blackjack_table",
			"selection_seed": run_state.seed_value if run_state != null else 1,
			"action_cues": {
				"blackjack_chip": "blackjack_chip",
				"blackjack_correct_bet": "blackjack_chip",
				"blackjack_remove_chip": "blackjack_chip",
				"blackjack_undo_bet": "blackjack_chip",
				"blackjack_repeat_bet": "blackjack_chip",
				"blackjack_rebet": "blackjack_chip",
				"blackjack_patron_bet": "blackjack_chip",
				"blackjack_clear_bet": "blackjack_chip",
				"blackjack_max_bet": "blackjack_chip",
				"surface_stake_up": "blackjack_chip",
				"surface_stake_down": "blackjack_chip",
				"surface_stake_max": "blackjack_chip",
				"blackjack_deal": "blackjack_deal",
				BLACKJACK_SETTLE_ACTION: "blackjack_deal",
				"blackjack_hit": "blackjack_hit",
				"blackjack_stand": "blackjack_stand",
				"blackjack_double": "blackjack_double",
				"blackjack_split": "blackjack_split",
				"blackjack_surrender": "blackjack_surrender",
				"blackjack_side_bet": "blackjack_side_bet",
				"blackjack_distraction": "blackjack_distraction",
				"blackjack_patron_cover": "blackjack_distraction",
				"blackjack_peek": "blackjack_peek",
				"blackjack_count": "blackjack_count",
				"blackjack_count_toggle": "blackjack_count_toggle",
				"blackjack_count_icon": "blackjack_count_icon",
			},
			"state_sync": {
				"method": "blackjack_table_state",
				"deal_animation_channel": DEAL_ANIMATION_CHANNEL,
				"payout_animation_channel": PAYOUT_ANIMATION_CHANNEL,
			},
		}),
	})
	if not _is_rourke_duel(run_state, environment):
		spec["ritual_contract"] = BLACKJACK_RITUAL_CONTRACT
		spec["ritual_id"] = BLACKJACK_RITUAL_ID
		spec["ritual_projection"] = _blackjack_ritual_projection(
			run_state,
			environment,
			table,
			session,
			spec,
			deal_animation_active,
			payout_animation_active
		)
	return _rourke_duel_surface_state(spec, run_state, environment, session, table, deal_animation_active, payout_animation_active)


func _blackjack_ritual_projection(run_state: RunState, environment: Dictionary, table: Dictionary, session: Dictionary, spec: Dictionary, deal_animation_active: bool, payout_animation_active: bool) -> Dictionary:
	var dealt := _has_dealt_hand(session)
	var round_complete := dealt and _all_hands_complete(session)
	var dealer_blackjack_pending := dealt and _dealer_has_blackjack(_card_array(session.get("dealer_cards", [])))
	var phase_id := "wagering"
	if deal_animation_active:
		phase_id = "initial_deal"
	elif dealt and (round_complete or dealer_blackjack_pending):
		phase_id = "dealer_procedure"
	elif dealt:
		phase_id = "player_turn"
	elif payout_animation_active:
		phase_id = "settlement"
	var available_funds := maxi(0, run_state.wager_balance_for_game(get_id(), environment)) if run_state != null else 0
	var selected_stake := maxi(0, int(spec.get("selected_stake", 0)))
	var pending_items: Array = []
	if phase_id == "wagering" and selected_stake > 0:
		pending_items.append(_blackjack_commitment_item("wager.main", "wager.player", selected_stake, "Main wager", "selected_chip", int(session.get("wager_edit_ordinal", 0)), true, ""))
		var side_stakes := _local_copy_dict(spec.get("side_bet_stakes", {}))
		for side_id in _string_array(spec.get("side_bets_active", [])):
			var side_amount := maxi(0, int(side_stakes.get(side_id, 0)))
			if side_amount > 0:
				pending_items.append(_blackjack_commitment_item("wager.side.%s" % side_id, "wager.side.%s" % side_id, side_amount, str(side_id).replace("_", " ").capitalize(), "selected_side_wager", int(session.get("wager_edit_ordinal", 0)), true, ""))
	var working_items: Array = []
	if dealt:
		var hands := _hand_array(session.get("player_hands", []))
		for hand_index in range(hands.size()):
			var hand: Dictionary = hands[hand_index]
			var hand_amount := selected_stake * maxi(1, int(hand.get("wager_multiplier", 1)))
			working_items.append(_blackjack_commitment_item("hand.%d" % hand_index, "player_hand.%d" % hand_index, hand_amount, "Hand %d" % (hand_index + 1), "accepted_main_wager", hand_index, false, "Decision locked to this hand"))
		for side_id in _string_array(session.get("blackjack_side_bets", [])):
			var side_definition := _side_bet_definition(side_id)
			var side_amount := _side_bet_stake(selected_stake, side_definition, run_state)
			working_items.append(_blackjack_commitment_item("wager.side.%s" % side_id, "wager.side.%s" % side_id, side_amount, str(side_definition.get("label", side_id)), "accepted_side_wager", 0, false, "Resolves with this hand"))
	var last_result := _local_copy_dict(table.get("last_result", {}))
	var item_resolutions := _blackjack_item_resolutions(last_result)
	var settlement_totals := _blackjack_settlement_totals(item_resolutions, last_result)
	var heat := run_state.suspicion_level_for_environment_id(str(environment.get("id", ""))) if run_state != null else 0
	var energy_tier := "hot" if heat >= 70 else "watched" if heat >= 40 else "engaged" if dealt or payout_animation_active else "quiet"
	var dealer_behavior := "paying" if phase_id == "settlement" else "drawing" if phase_id == "dealer_procedure" else "dealing" if phase_id == "initial_deal" else "watching" if heat >= 40 else "idle"
	var actors: Array = [{
		"id": "dealer.primary",
		"role": "dealer",
		"pose": dealer_behavior,
		"behavior": dealer_behavior,
		"anchor": "station.dealer",
		"visible": true,
		"authority": "game_rules",
	}]
	var patrons := _dictionary_array(spec.get("patrons", []))
	for patron_index in range(patrons.size()):
		var patron: Dictionary = patrons[patron_index]
		actors.append({
			"id": "neighbour.%d" % patron_index,
			"role": "neighbour",
			"pose": "leaning" if energy_tier in ["watched", "hot"] else "seated",
			"behavior": "playing" if dealt else "watching" if heat >= 40 else "idle",
			"anchor": "seat.%d" % patron_index,
			"visible": true,
			"authority": "none",
			"source_patron_id": str(patron.get("id", "seat_%d" % patron_index)),
		})
	actors.append({
		"id": "pit.primary",
		"role": "pit",
		"pose": "close" if energy_tier == "hot" else "rail" if energy_tier == "watched" else "absent",
		"behavior": "intervening" if energy_tier == "hot" else "watching" if energy_tier == "watched" else "idle",
		"anchor": "pit.rail",
		"visible": energy_tier in ["watched", "hot"],
		"authority": "heat_projection",
	})
	var shoe_remaining := maxi(0, int(spec.get("shoe_remaining", 0)))
	var cut_remaining := maxi(0, int(spec.get("cut_card_remaining", 0)))
	var shoe_state := "cut_due" if shoe_remaining <= cut_remaining else "dealing" if phase_id in ["initial_deal", "dealer_procedure"] else "ready"
	var at_risk_total := _blackjack_commitment_total(working_items)
	if dealt:
		at_risk_total = maxi(at_risk_total, _session_debited_wager(session))
	return {
		"contract": BLACKJACK_RITUAL_CONTRACT,
		"ritual_id": BLACKJACK_RITUAL_ID,
		"phase_id": phase_id,
		"boundary_id": _blackjack_ritual_boundary_id(phase_id, session, last_result),
		"pending_items": pending_items,
		"working_items": working_items,
		"item_resolutions": item_resolutions,
		"readable_totals": {
			"available_funds": available_funds,
			"pending_total": _blackjack_commitment_total(pending_items),
			"at_risk_total": at_risk_total,
			"returned_stake": int(settlement_totals.get("returned_stake", 0)),
			"payout": int(settlement_totals.get("payout", 0)),
			"net_change": int(last_result.get("round_net_delta", last_result.get("bankroll_delta", 0))),
		},
		"actors": actors,
		"scene_objects": [
			{"id": "shoe.primary", "visual": shoe_state, "functional": "locked" if phase_id == "settlement" else "enabled", "visible": true, "enabled": phase_id != "settlement"},
			{"id": "discard_rack.primary", "visual": "empty" if shoe_remaining >= int(table.get("deck_count", 1)) * CardShoeScript.CARDS_PER_DECK else "full" if shoe_remaining <= cut_remaining else "used", "functional": "passive", "visible": true, "enabled": false},
			{"id": "wager.player", "visual": "settled" if phase_id == "settlement" else "at_risk" if dealt else "placed", "functional": "locked" if dealt else "editable", "visible": true, "enabled": not dealt},
			{"id": "dealer.hole_card", "visual": "revealed" if bool(session.get("dealer_hole_visible", false)) else "concealed", "functional": "read_only", "visible": dealt, "enabled": false},
			{"id": "rail.open_space", "visual": "narrow" if energy_tier == "hot" else "guarded" if energy_tier == "watched" else "open", "functional": "blocked" if energy_tier == "hot" else "enabled", "visible": true, "enabled": energy_tier != "hot"},
		],
		"energy_tier": energy_tier,
		"heat": heat,
		"action_states": _blackjack_ritual_action_states(spec, phase_id),
		"gesture_actions": BLACKJACK_GESTURE_ACTIONS.duplicate(),
	}


func _blackjack_commitment_item(item_id: String, target_id: String, amount: int, label: String, source: String, edit_ordinal: int, eligible: bool, disabled_reason: String) -> Dictionary:
	var safe_amount := maxi(0, amount)
	return {
		"item_id": item_id,
		"target_id": target_id,
		"denomination": safe_amount,
		"amount": safe_amount,
		"source": source,
		"edit_ordinal": maxi(0, edit_ordinal),
		"eligibility": eligible,
		"disabled_reason": disabled_reason,
		"label": label,
		"editable": eligible,
	}


func _blackjack_commitment_total(items: Array) -> int:
	var total := 0
	for item_value in items:
		if typeof(item_value) == TYPE_DICTIONARY:
			total += maxi(0, int((item_value as Dictionary).get("amount", 0)))
	return total


func _blackjack_item_resolutions(last_result: Dictionary) -> Array:
	var resolutions: Array = []
	var hand_results := _dictionary_array(last_result.get("hand_results", []))
	for hand_index in range(hand_results.size()):
		var hand: Dictionary = hand_results[hand_index]
		var wager := maxi(0, int(hand.get("wager", 0)))
		var delta := int(hand.get("bankroll_delta", 0))
		var outcome := str(hand.get("outcome", "push"))
		var returned_stake := _blackjack_returned_stake(wager, delta, outcome)
		resolutions.append({
			"item_id": "hand.%d" % hand_index,
			"authoritative_result_id": _blackjack_authoritative_result_id(last_result, "hand.%d" % hand_index),
			"stake_disposition": _blackjack_stake_disposition(outcome),
			"outcome": outcome,
			"stake": wager,
			"returned_stake": returned_stake,
			"payout": maxi(0, delta),
			"net_change": delta,
			"public_explanation": _blackjack_resolution_reason(outcome),
			"reason": _blackjack_resolution_reason(outcome),
		})
	for side_value in _dictionary_array(last_result.get("side_bet_results", [])):
		var side: Dictionary = side_value
		var wager := maxi(0, int(side.get("stake", 0)))
		var delta := int(side.get("bankroll_delta", 0))
		var won := bool(side.get("won", false))
		resolutions.append({
			"item_id": "wager.side.%s" % str(side.get("id", "unknown")),
			"authoritative_result_id": _blackjack_authoritative_result_id(last_result, "wager.side.%s" % str(side.get("id", "unknown"))),
			"stake_disposition": "returned_with_profit" if won else "collected",
			"outcome": "win" if won else "lose",
			"stake": wager,
			"returned_stake": wager if won else 0,
			"payout": maxi(0, delta),
			"net_change": delta,
			"public_explanation": str(side.get("detail", "Side wager settled")),
			"reason": str(side.get("detail", "Side wager settled")),
		})
	return resolutions


func _blackjack_authoritative_result_id(last_result: Dictionary, item_id: String) -> String:
	var stored_result_id := _blackjack_ritual_safe_id(str(last_result.get("payout_animation_id", last_result.get("result_id", ""))))
	if not stored_result_id.is_empty() and stored_result_id != "blackjack":
		return "%s:%s" % [stored_result_id, item_id]
	var result_ordinal := maxi(0, int(last_result.get("resolved_at_msec", last_result.get("timestamp_msec", 0))))
	return "blackjack.result.%d:%s" % [result_ordinal, item_id]


func _blackjack_stake_disposition(outcome: String) -> String:
	if outcome == "surrender":
		return "partially_returned"
	if outcome == "push":
		return "returned"
	if outcome in ["blackjack", "dealer_bust", "win"]:
		return "returned_with_profit"
	return "collected"


func _blackjack_returned_stake(wager: int, delta: int, outcome: String) -> int:
	if outcome == "surrender":
		return maxi(0, wager + delta)
	if outcome in ["push", "blackjack", "dealer_bust", "win"]:
		return wager
	return 0


func _blackjack_resolution_reason(outcome: String) -> String:
	match outcome:
		"blackjack": return "Natural blackjack pays 3:2."
		"dealer_blackjack": return "Dealer natural takes the wager."
		"dealer_bust": return "Dealer bust returns stake and pays even money."
		"win": return "Player total beats dealer; stake returns with even-money payout."
		"lose": return "Dealer total beats player; wager is collected."
		"bust": return "Player bust; wager is collected before dealer draw."
		"surrender": return "Late surrender returns the unlost half of the stake."
		_: return "Equal totals push and return the stake."


func _blackjack_settlement_totals(resolutions: Array, last_result: Dictionary) -> Dictionary:
	var returned_stake := 0
	var payout := 0
	for resolution_value in resolutions:
		if typeof(resolution_value) != TYPE_DICTIONARY:
			continue
		var resolution: Dictionary = resolution_value
		returned_stake += maxi(0, int(resolution.get("returned_stake", 0)))
		payout += maxi(0, int(resolution.get("payout", 0)))
	return {
		"returned_stake": returned_stake,
		"payout": payout,
		"settlement_return_delta": int(last_result.get("bankroll_delta", 0)),
	}


func _blackjack_ritual_boundary_id(phase_id: String, session: Dictionary, last_result: Dictionary) -> String:
	var ordinal := int(session.get("cards_consumed", 0)) + int(session.get("active_hand_index", 0))
	if phase_id == "settlement":
		ordinal = int(last_result.get("resolved_at_msec", last_result.get("timestamp_msec", ordinal)))
	return "blackjack:%s:%d" % [phase_id, maxi(0, ordinal)]


func _blackjack_ritual_action_states(spec: Dictionary, phase_id: String) -> Dictionary:
	return {
		"blackjack_deal": _blackjack_ritual_action_state(bool(spec.get("can_deal", false)) and phase_id == "wagering", "Deal is available only after legal chips are staged."),
		BLACKJACK_SETTLE_ACTION: _blackjack_ritual_action_state(bool(spec.get("settle_available", false)), "Settle is available only after the hand is complete."),
		"blackjack_hit": _blackjack_ritual_action_state(bool(spec.get("can_hit", false)) and phase_id == "player_turn", "Hit is available only on the active unfinished hand."),
		"blackjack_stand": _blackjack_ritual_action_state(bool(spec.get("can_stand", false)) and phase_id == "player_turn", "Stand is available only on the active unfinished hand."),
		"blackjack_double": _blackjack_ritual_action_state(bool(spec.get("can_double", false)) and phase_id == "player_turn", "Double requires an eligible two-card hand and enough funds."),
		"blackjack_split": _blackjack_ritual_action_state(bool(spec.get("can_split", false)) and phase_id == "player_turn", "Split requires an eligible pair, hand capacity, and enough funds."),
		"blackjack_surrender": _blackjack_ritual_action_state(bool(spec.get("can_surrender", false)) and phase_id == "player_turn", "Late surrender is unavailable on this hand or table."),
	}


func _blackjack_ritual_action_state(enabled: bool, disabled_reason: String) -> Dictionary:
	return {"enabled": enabled, "disabled_reason": "" if enabled else disabled_reason}


func _rourke_duel_surface_state(spec: Dictionary, run_state: RunState, environment: Dictionary, session: Dictionary, table: Dictionary, deal_animation_active: bool, payout_animation_active: bool) -> Dictionary:
	if not _is_rourke_duel(run_state, environment):
		return spec
	var duel := run_state.grand_casino_duel_status()
	var terms := run_state.grand_casino_duel_terms()
	var edge := run_state.grand_casino_duel_current_edge()
	var callouts: Array = []
	for edge_value in _dictionary_array(terms.get("edge_catalog", [])):
		var edge_entry: Dictionary = edge_value
		callouts.append({
			"id": str(edge_entry.get("id", "")),
			"label": str(edge_entry.get("callout_label", edge_entry.get("label", "Call it"))),
		})
	var ante := maxi(1, int(duel.get("ante", 20)))
	spec["boss_variant"] = ROURKE_DUEL_VARIANT
	spec["boss_duel_active"] = true
	spec["boss_player_stack"] = maxi(0, int(duel.get("player_stack", 0)))
	spec["boss_rourke_stack"] = maxi(0, int(duel.get("rourke_stack", 0)))
	spec["boss_hand_number"] = mini(int(duel.get("hand_index", 0)) + 1, int(duel.get("hand_limit", 5)))
	spec["boss_hand_limit"] = int(duel.get("hand_limit", 5))
	spec["boss_bark"] = str(duel.get("last_bark", "Rourke waits for the cut."))
	spec["boss_tell"] = str(edge.get("tell", "Rourke gives nothing away.")) if bool(edge.get("active", false)) and not bool(edge.get("stripped", false)) else "Rourke gives nothing away."
	spec["boss_callouts"] = callouts
	spec["boss_callout_used"] = bool(edge.get("called", false))
	spec["selected_stake"] = ante
	spec["main_wager_cost"] = ante
	spec["total_wager_cost"] = ante
	spec["surface_stake_controls_required"] = false
	spec["surface_ui_preference_keys"] = []
	spec["side_bets_available"] = []
	spec["side_bets_active"] = []
	spec["distractions"] = []
	spec["patrons"] = []
	spec["can_split"] = false
	spec["can_surrender"] = false
	spec["can_double"] = _can_double(session, table, ante, run_state)
	spec["table_rules_text"] = "Five fixed-ante hands. Final stack margin decides the door."
	spec["table_notice"] = str(session.get("table_notice", duel.get("last_bark", "Rourke cuts the cards.")))
	spec["surface_ui_protected_regions"] = _rourke_duel_ui_protected_regions()
	# Game7 is presentation-only here. The frozen Blackjack projection remains
	# untouched; this additive adapter consumes a closed projection fingerprinted
	# to the live public duel state and carries no crew/world or settlement input.
	var blackjack_projection := _blackjack_ritual_projection(run_state, environment, table, session, spec, deal_animation_active, payout_animation_active)
	var duel_fingerprint: String = ShowdownDuelProjectionScript.public_duel_fingerprint(duel)
	var hands := _dictionary_array(duel.get("hands", []))
	var duel_authority := {
		"duel_id": "grand_casino_showdown",
		"route_id": "pit_boss_showdown",
		"attempt": maxi(0, int(duel.get("attempt", 0))),
		"result_serial": hands.size(),
		"authoritative_result_ref": "duel:%d:hand:%d:%s" % [maxi(0, int(duel.get("attempt", 0))), hands.size(), str(duel.get("status", "active"))],
		"duel_content_fingerprint": duel_fingerprint,
		"current_edge": edge,
	}
	var showdown_projection: Dictionary = ShowdownDuelProjectionScript.sealed_product_projection(
		duel,
		str(blackjack_projection.get("phase_id", "")),
		duel_authority
	)
	if ShowdownDuelProjectionScript.verify_product_projection(showdown_projection, duel, str(blackjack_projection.get("phase_id", "")), duel_authority):
		spec["showdown_duel_projection"] = showdown_projection
		spec["ritual_actors"] = [showdown_projection.get("rourke_actor", {})]
		spec["ritual_scene_objects"] = _showdown_duel_scene_objects(showdown_projection)
	return spec


func _surface_table_state(run_state: RunState, environment: Dictionary) -> Dictionary:
	# Rendering is read-only. Normal play stores a normalized table, so borrow it
	# instead of cloning the full shoe/session/patron graph for every surface patch.
	# Tutorial repair, migrated tables, and a newly rotated Grand Casino dealer
	# retain the conservative preview normalization path.
	var stored := _peek_table_state(environment)
	if stored.is_empty() \
			or str(stored.get("schema", "")) != "blackjack_table_state" \
			or int(stored.get("version", 0)) < 2 \
			or (run_state != null and run_state.is_tutorial_run()):
		return _table_state_preview(run_state, environment)
	if run_state != null and not _is_rourke_duel(run_state, environment):
		var assignment := run_state.grand_casino_staff_member_for_game_preview(get_id(), environment)
		var assignment_id := str(assignment.get("id", "")).strip_edges()
		if not assignment_id.is_empty() and (
				str(stored.get("staff_assignment_id", "")) != assignment_id
				or int(stored.get("staff_assignment_day", 0)) != maxi(1, int(assignment.get("day", run_state.game_day())))
		):
			return _table_state_preview(run_state, environment)
	return stored


func table_approach_talk_snapshot(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	# Action-boundary dialogue needs only the visible patrons and completed-hand
	# count. Avoid constructing cards, side bets, animation channels, count hints,
	# audio, and controls solely to decide whether a patron may speak.
	var table := _surface_table_state(run_state, environment)
	var session := _normalized_session(run_state, environment, ui_state, table)
	return {
		"patrons": GameModule.patrons_with_talk_focus(_patrons_for_surface(table, session), ui_state.get("focused_talk_speaker", {})),
		"hands_played": int(table.get("hands_played", 0)),
	}


func _showdown_duel_scene_objects(projection: Dictionary) -> Array:
	var room := _local_copy_dict(projection.get("room_state", {}))
	if room.is_empty(): return []
	return [
		{"id":"showdown.table","visual":str(room.get("table_state", "active")),"functional":"locked","visible":true,"enabled":false},
		{"id":"showdown.rail","visual":str(room.get("rail_state", "open")),"functional":"projection","visible":true,"enabled":false},
		{"id":"showdown.exit","visual":str(room.get("exit_state", "blocked")),"functional":"locked","visible":true,"enabled":false},
	]


func _rourke_duel_ui_protected_regions() -> Array:
	return [
		_blackjack_ui_rect(18, 10, 860, 78),
		_blackjack_ui_rect(18, BJ_CONSOLE_Y + 4.0, 860, BJ_CONSOLE_H - 8.0),
		_blackjack_ui_rect(586, 286, 292, 50),
	]


func wager_activity_incomplete(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> bool:
	var table := _table_state_preview(run_state, environment)
	return _has_dealt_hand(_normalized_session(run_state, environment, ui_state, table))


func _blackjack_ui_protected_regions(count_challenge: Dictionary) -> Array:
	var regions := [
		_blackjack_ui_rect(24, 14, 286, 58),
		_blackjack_ui_rect(332, 18, 236, 48),
		_blackjack_ui_rect(646, 12, 232, 74),
		_blackjack_ui_rect(18, BJ_CONSOLE_Y + 8.0, 242, BJ_CONSOLE_H - 16.0),
		_blackjack_ui_rect(272, BJ_CONSOLE_Y + 8.0, 302, BJ_CONSOLE_H - 16.0),
		_blackjack_ui_rect(586, BJ_CONSOLE_Y + 8.0, 292, BJ_CONSOLE_H - 16.0),
		_blackjack_ui_rect(692, 294, 168, 34),
	]
	if not count_challenge.is_empty():
		regions.append(_blackjack_ui_rect(620, 74, 150, 30))
	return regions


func _blackjack_ui_rect(x: float, y: float, width: float, height: float, hover_action: String = "", hover_index: int = -1) -> Dictionary:
	var rect := {
		"x": x,
		"y": y,
		"w": width,
		"h": height,
	}
	if not hover_action.is_empty():
		rect["action"] = hover_action
		if hover_index >= 0:
			rect["index"] = hover_index
	return rect


func draw_surface(surface, surface_state: Dictionary, _render_context: Dictionary = {}) -> bool:
	if str(surface_state.get("surface_renderer", "")) != "blackjack":
		return false
	if surface.surface_animation_active(DEAL_ANIMATION_CHANNEL):
		_prepare_draw_deal_events_cache(surface_state)
	surface.surface_begin_design_space(surface.surface_board_size())
	_draw_blackjack_room(surface, surface_state)
	if bool(surface_state.get("boss_duel_active", false)):
		_draw_showdown_duel_room_staging(surface, surface_state)
	_draw_blackjack_table(surface, surface_state)
	if not bool(surface_state.get("boss_duel_active", false)):
		_draw_table_patrons(surface, surface_state)
	_draw_dealer_station(surface, surface_state)
	_draw_player_station(surface, surface_state)
	_draw_blackjack_table_notice(surface, surface_state)
	_draw_blackjack_round_timer(surface, surface_state)
	if bool(surface_state.get("boss_duel_active", false)):
		_draw_rourke_duel_hud(surface, surface_state)
	else:
		_draw_blackjack_ambient_event(surface, surface_state)
		_draw_chip_rack(surface, surface_state)
	_draw_table_actions(surface, surface_state)
	_draw_basic_strategy_advice(surface, surface_state)
	_draw_blackjack_result_board(surface, surface_state)
	if not bool(surface_state.get("boss_duel_active", false)):
		_draw_side_bet_rule_overlay(surface, surface_state)
	_draw_deal_animation(surface, surface_state)
	_draw_chip_payout_animation(surface, surface_state)
	_draw_count_challenge(surface, surface_state)
	_draw_crew_play_status(surface, surface_state)
	if not bool(surface_state.get("boss_duel_active", false)):
		_draw_blackjack_ritual_layer(surface, surface_state)
	return true


func _draw_blackjack_ritual_layer(surface, surface_state: Dictionary) -> void:
	var projection := _draw_dict_view(surface_state.get("ritual_projection", {}))
	if projection.is_empty():
		return
	var phase_id := str(projection.get("phase_id", "wagering"))
	var energy_tier := str(projection.get("energy_tier", "quiet"))
	var totals := _draw_dict_view(projection.get("readable_totals", {}))
	var available_funds := int(totals.get("available_funds", 0))
	var returned_stake := int(totals.get("returned_stake", 0))
	var payout := int(totals.get("payout", 0))
	if not bool(surface_state.get("boss_duel_active", false)) and surface.surface_animation_active(DEAL_ANIMATION_CHANNEL):
		if bool(surface_state.get("between_hands", false)):
			var accepted_return := int(_draw_dict_view(surface_state.get("last_result", {})).get("bankroll_delta", 0))
			available_funds = maxi(0, available_funds - accepted_return)
		returned_stake = 0
		payout = 0
	var accent := C_PINK if energy_tier == "hot" else C_YELLOW if energy_tier == "watched" else C_TEAL if energy_tier == "engaged" else C_CYAN
	var phase_rect := Rect2(28, 120, 164, 20)
	TableVisualsScript._draw_neon_panel(surface, phase_rect, accent, 0.13)
	surface.surface_label("RITUAL  %s" % phase_id.replace("_", " ").to_upper().left(16), phase_rect.position + Vector2(8, 13), 8, accent)
	var money_rect := Rect2(246, 300, 408, 12)
	surface.draw_rect(money_rect, Color("#071612"))
	surface.draw_rect(money_rect, Color(accent.r, accent.g, accent.b, 0.38), false, 1)
	var wager_currency := _blackjack_surface_currency(surface_state)
	surface.surface_label_centered("AVAILABLE %s   PENDING %s   AT RISK %s   RETURN %s   PAYS %s" % [
		PlayerTextScript.format_currency_amount(wager_currency, available_funds, true),
		PlayerTextScript.format_currency_amount(wager_currency, int(totals.get("pending_total", 0)), true),
		PlayerTextScript.format_currency_amount(wager_currency, int(totals.get("at_risk_total", 0)), true),
		PlayerTextScript.format_currency_amount(wager_currency, returned_stake, true),
		PlayerTextScript.format_currency_amount(wager_currency, payout, true),
	], money_rect, 6, C_WHITE)
	var pit_actor: Dictionary = {}
	for actor_value in _draw_array_view(projection.get("actors", [])):
		var actor: Dictionary = actor_value
		if str(actor.get("id", "")) == "pit.primary":
			pit_actor = actor
			break
	if bool(pit_actor.get("visible", false)):
		var pit_clock := TableVisualsScript._surface_clock(surface) + 1.7
		var pit_motion := _blackjack_between_hand_character_motion(pit_clock, 0.64)
		var pit_pos := Vector2(826, 226 if energy_tier == "hot" else 202)
		var pit_style := {
			"name": "PIT",
			"skin": Color("#c49371"),
			"hair": Color("#171022"),
			"jacket": Color("#261827"),
			"accent": accent,
			"pose": ["wrist_check", "arms_folded", "lookaround"][int(pit_motion.get("gesture_index", 0))],
			"eye_offset": -2.0,
			"body_bob": float(pit_motion.get("body_bob", 0.0)),
			"head_x": float(pit_motion.get("head_x", 0.0)),
			"head_y": float(pit_motion.get("head_y", 0.0)),
			"gesture_amount": float(pit_motion.get("gesture_amount", 0.0)),
			"gesture_side": int(pit_motion.get("gesture_side", 0)),
		}
		_draw_table_character(surface, pit_style, pit_pos, 0.70, pit_clock)
		surface.draw_line(Vector2(790, 230), Vector2(858, 230), Color(accent.r, accent.g, accent.b, 0.48), 3.0)
	var discard_state := "empty"
	for object_value in _draw_array_view(projection.get("scene_objects", [])):
		var object_state: Dictionary = object_value
		if str(object_state.get("id", "")) == "discard_rack.primary":
			discard_state = str(object_state.get("visual", "empty"))
			break
	var discard_rect := Rect2(674, 188, 70, 28)
	surface.draw_rect(discard_rect, Color("#15101a"))
	surface.draw_rect(discard_rect, Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.42), false, 1)
	surface.surface_label_centered("DISCARD %s" % discard_state.to_upper(), discard_rect, 7, C_SOFT)
	if phase_id == "wagering":
		surface.surface_add_hold_hit(Rect2(686, 92, 92, 92), BLACKJACK_CUT_GESTURE, 0)
		surface.surface_label("DRAG CHIP TO YOU / HOLD SHOE TO CUT", Vector2(622, 246), 7, C_SOFT)
	elif phase_id == "player_turn":
		surface.surface_add_hold_hit(Rect2(318, 214, 270, 58), BLACKJACK_TAP_GESTURE, 0)
		surface.surface_add_drag_hit(Rect2(318, 274, 270, 34), BLACKJACK_WAVE_GESTURE, 0)
		surface.surface_label("TAP HAND FOR CARD / WAVE ACROSS TO STAND", Vector2(622, 246), 7, C_SOFT)


func _prepare_draw_deal_events_cache(surface_state: Dictionary) -> void:
	var deal_active_id := str(surface_state.get("deal_animation_id", ""))
	if deal_active_id.is_empty():
		draw_deal_events_cache_id = ""
		draw_deal_events_cache = []
		return
	if draw_deal_events_cache_id == deal_active_id:
		return
	draw_deal_events_cache_id = deal_active_id
	draw_deal_events_cache = _deal_animation_event_array(surface_state.get("deal_animation_events", []))


func surface_uses_auto_tick() -> bool:
	return true


func surface_needs_auto_tick(ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> bool:
	# This is queried every frame. Keep the active-count path read-only and
	# allocation-free; action boundaries already synchronize newly dealt cards.
	var table: Dictionary = _peek_table_state(environment)
	if table.is_empty():
		return false
	return _blackjack_auto_tick_predicate(ui_state, run_state, environment, table, _surface_time_for_count(ui_state))


func _blackjack_host_needs_auto_tick(surface_time_msec: int, run_state: RunState, environment: Dictionary) -> bool:
	# Foundation calls this every frame. Read the canonical table, ledger, and
	# session in place; the subsequent auto-intent boundary owns every mutation.
	var table: Dictionary = _peek_table_state(environment)
	if table.is_empty():
		return false
	var ledger_value: Variant = table.get(BLACKJACK_HOST_LEDGER_KEY, null)
	if typeof(ledger_value) != TYPE_DICTIONARY:
		return false
	var ledger: Dictionary = ledger_value as Dictionary
	var pending_value: Variant = ledger.get("pending_delivery", null)
	if typeof(pending_value) == TYPE_DICTIONARY and not (pending_value as Dictionary).is_empty():
		return false
	var session_value: Variant = ledger.get("session", null)
	if typeof(session_value) != TYPE_DICTIONARY:
		return false
	return _blackjack_auto_tick_predicate(session_value as Dictionary, run_state, environment, table, surface_time_msec)


func _blackjack_auto_tick_predicate(session: Dictionary, run_state: RunState, environment: Dictionary, table: Dictionary, now_msec: int) -> bool:
	var raw_challenge: Variant = session.get("count_challenge", {})
	if typeof(raw_challenge) == TYPE_DICTIONARY and not (raw_challenge as Dictionary).is_empty() and not bool(session.get("count_answered", false)):
		var challenge: Dictionary = raw_challenge as Dictionary
		if _count_has_new_misses(challenge, now_msec):
			return true
	var dealt := _has_dealt_hand(session)
	var dealer_cards_value: Variant = session.get("dealer_cards", [])
	var dealer_cards: Array = dealer_cards_value as Array if typeof(dealer_cards_value) == TYPE_ARRAY else []
	if dealt and (_all_hands_complete(session) or _dealer_has_blackjack(dealer_cards)):
		if _tutorial_grand_casino_manual_settlement(run_state, environment):
			return false
		if bool(session.get("presentation_timing_enforced", false)):
			if _deal_presentation_active(session, now_msec):
				return false
			if _count_settlement_bubbles_pending(session, now_msec):
				return false
		return true
	if dealt or bool(table.get("barred", false)):
		return false
	# The guided table advances only from an explicit DEAL. Timed count misses and
	# completed-hand settlement above remain live, but an idle lesson can never
	# deal the next hand out from under a first-time player.
	if run_state != null and run_state.is_tutorial_run():
		return false
	if _blackjack_table_motion_active(table, now_msec):
		return false
	var timer := GameModule.table_round_timer_status_peek(table, now_msec, "Next hand")
	if bool(timer.get("active", false)):
		return bool(timer.get("due", false))
	var last_result_value: Variant = table.get("last_result", null)
	return typeof(last_result_value) == TYPE_DICTIONARY and not (last_result_value as Dictionary).is_empty()


func surface_auto_tick_state_keys() -> Array:
	return [
		"player_hands",
		"blackjack_hands",
		"dealer_cards",
		"dealer",
		"blackjack_sit_out",
		"count_challenge",
		"count_answered",
		"counting_enabled",
		"deal_animation_id",
		"deal_started_msec",
		"deal_animation_events",
		"settlement_count_revealed",
		"settlement_pending",
		"presentation_timing_enforced",
	]


func surface_auto_action_command(ui_state: Dictionary, run_state: RunState, environment: Dictionary, _surface_status: Dictionary = {}) -> Dictionary:
	var table: Dictionary = _table_state(run_state, environment)
	var next_state: Dictionary = _normalized_session(run_state, environment, ui_state, table)
	var notice: String = _update_live_count_state(next_state, table, run_state, true)
	if not notice.is_empty():
		return _message_command(next_state, notice)
	if _has_dealt_hand(next_state) and (_all_hands_complete(next_state) or _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", [])))):
		if _tutorial_grand_casino_manual_settlement(run_state, environment):
			return {"handled": false}
		if bool(next_state.get("presentation_timing_enforced", false)):
			var now_msec := _surface_time_for_count(next_state)
			if _deal_presentation_active(next_state) or _count_settlement_bubbles_pending(next_state, now_msec):
				return {"handled": false}
		return _settle_completed_round_command(next_state, int(next_state.get("active_hand_index", 0)), _terminal_round_message(next_state), table, run_state)
	if _has_dealt_hand(next_state) or bool(table.get("barred", false)):
		return {"handled": false}
	if run_state != null and run_state.is_tutorial_run():
		return {"handled": false}
	var now_msec := int(ui_state.get("surface_time_msec", Time.get_ticks_msec()))
	if _blackjack_table_motion_active(table, now_msec):
		return {"handled": false}
	var timer := GameModule.table_round_timer_status_peek(table, now_msec, "Next hand")
	if not bool(timer.get("active", false)):
		var last_result: Dictionary = _local_copy_dict(table.get("last_result", {}))
		if last_result.is_empty():
			return {"handled": false}
		timer = GameModule.table_round_timer_status(table, now_msec, "Next hand")
		_update_environment_table(environment, table)
		return {"handled": false}
	if not bool(timer.get("due", false)):
		return {"handled": false}
	next_state["blackjack_sit_out"] = true
	next_state["blackjack_side_bets"] = []
	next_state["selected_stake"] = 1
	GameModule.reset_table_round_timer(table)
	_update_environment_table(environment, table)
	return GameModule.surface_command({
		"handled": true,
		"ui_state": _compact_session_for_ui(next_state),
		"action_id": "play_basic",
		"action_kind": "legal",
		"direct_resolve": true,
		"skip_stake_validation": true,
		"preserve_surface_ui_state": false,
		"message": "The dealer deals the next hand; you watch without wagering.",
	})


func _tutorial_grand_casino_manual_settlement(run_state: RunState, environment: Dictionary) -> bool:
	return run_state != null \
		and run_state.is_tutorial_run() \
		and str(environment.get("archetype_id", "")) == RunState.GRAND_CASINO_ARCHETYPE_ID \
		and not _is_rourke_duel(run_state, environment)


func _blackjack_table_motion_active(table: Dictionary, now_msec: int) -> bool:
	var last_result: Dictionary = _local_copy_dict(table.get("last_result", {}))
	var deal_started := int(table.get("last_deal_started_msec", 0))
	var deal_events: Array = _deal_animation_event_array(table.get("last_deal_animation_events", []))
	var patron_action_events: Array = _patron_action_event_array(table.get("last_patron_action_events", []))
	var deal_duration := maxi(_deal_animation_duration_msec(deal_events), _patron_action_animation_duration_msec(patron_action_events))
	if deal_started > 0:
		var deal_elapsed := now_msec - deal_started
		if deal_elapsed >= 0 and deal_elapsed < deal_duration:
			return true
	var payout_started := _blackjack_payout_started_msec(last_result, deal_started, deal_duration)
	if payout_started > 0:
		var payout_elapsed := now_msec - payout_started
		if payout_elapsed >= 0 and payout_elapsed < PAYOUT_ANIMATION_DURATION_MSEC:
			return true
	return false


func surface_action_command(surface_action: String, index: int, confirm_requested: bool, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if _is_rourke_duel(run_state, environment):
		return _rourke_duel_surface_action_command(surface_action, index, confirm_requested, ui_state, run_state, environment)
	return _blackjack_surface_action_command(surface_action, index, confirm_requested, ui_state, run_state, environment)


func surface_pointer_uses_lightweight_ui_state(surface_action: String) -> bool:
	# Blackjack's authoritative in-progress hand is carried by the existing UI
	# session seam. Gesture boundaries therefore need that compact full session.
	return false


func blackjack_ritual_equivalent_command(input_kind: String, gesture_id: String, target_selection: String, target_id: String, target_index: int, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if not input_kind in ["keyboard", "controller", "reduced_motion"]:
		return _message_command(ui_state.duplicate(true), "Unsupported ritual input; nothing changed.")
	var state := surface_state(run_state, environment, ui_state)
	var bindings: Dictionary = state.get("ritual_equivalent_bindings", {}) if typeof(state.get("ritual_equivalent_bindings", {})) == TYPE_DICTIONARY else {}
	var binding: Dictionary = bindings.get(gesture_id, {}) if typeof(bindings.get(gesture_id, {})) == TYPE_DICTIONARY else {}
	if binding.is_empty() or not (binding.get("target_selection", []) as Array).has(target_selection):
		return _message_command(ui_state.duplicate(true), "That ritual target selection is unavailable; nothing changed.")
	if str(binding.get("target_id", "")) != target_id:
		return _message_command(ui_state.duplicate(true), "That ritual target belongs to another object; nothing changed.")
	if target_index < 0:
		return _message_command(ui_state.duplicate(true), "No ritual target is selected; nothing changed.")
	var action_id := str(binding.get("action", ""))
	if action_id.is_empty():
		return _message_command(ui_state.duplicate(true), "That ritual input has no authoritative action; nothing changed.")
	var command := _blackjack_surface_action_command(action_id, target_index, false, ui_state, run_state, environment)
	command["ritual_input_kind"] = input_kind
	command["ritual_target_selection"] = target_selection
	command["ritual_target_id"] = target_id
	command["ritual_reduced_motion"] = input_kind == "reduced_motion"
	return command


func surface_pointer_command(surface_action: String, index: int, pointer_phase: String, board_position: Vector2, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if not surface_action in BLACKJACK_GESTURE_ACTIONS or _is_rourke_duel(run_state, environment):
		return {"handled": false}
	var next_state := ui_state.duplicate(false)
	var active_key := "blackjack_gesture_active"
	var origin_key := "blackjack_gesture_origin"
	var index_key := "blackjack_gesture_index"
	if pointer_phase == "begin":
		next_state[active_key] = surface_action
		next_state[origin_key] = board_position
		next_state[index_key] = index
		return GameModule.surface_command({"handled": true, "ui_state": next_state, "preserve_surface_ui_state": true}, true)
	if pointer_phase == "cancel":
		_blackjack_clear_gesture_state(next_state)
		return GameModule.surface_command({"handled": true, "ui_state": next_state, "preserve_surface_ui_state": true, "message": "Gesture cancelled; no chips or cards moved."}, true)
	if str(next_state.get(active_key, "")) != surface_action:
		return GameModule.surface_command({"handled": true, "ui_state": next_state, "preserve_surface_ui_state": true, "message": "That gesture did not begin on an available Blackjack object."}, true)
	if pointer_phase == "move":
		next_state["blackjack_gesture_pointer"] = board_position
		return GameModule.surface_command({"handled": true, "ui_state": next_state, "preserve_surface_ui_state": true}, true)
	if pointer_phase != "end":
		return GameModule.surface_command({"handled": true, "ui_state": next_state, "preserve_surface_ui_state": true}, true)
	var origin: Vector2 = next_state.get(origin_key, board_position)
	var gesture_index := int(next_state.get(index_key, index))
	var phase_id := str(_local_copy_dict(surface_state(run_state, environment, next_state).get("ritual_projection", {})).get("phase_id", "wagering"))
	var valid := false
	var semantic_action := ""
	var invalid_message := "Incomplete gesture; nothing changed."
	match surface_action:
		BLACKJACK_WAGER_PLACE_GESTURE:
			var travel_distance := origin.distance_to(board_position)
			var tapped_chip := travel_distance <= 12.0
			var dragged_to_wager := travel_distance >= 22.0 and Rect2(414, 276, 76, 62).has_point(board_position)
			valid = phase_id == "wagering" and (tapped_chip or dragged_to_wager)
			semantic_action = "blackjack_chip"
			invalid_message = "Return the chip to the rail or place it inside your wager circle."
		BLACKJACK_CUT_GESTURE:
			valid = phase_id == "wagering" and Rect2(686, 92, 92, 92).has_point(board_position)
			semantic_action = "blackjack_deal"
			invalid_message = "Hold and release on the shoe to offer the cut; no wager was charged."
		BLACKJACK_WAVE_GESTURE:
			valid = phase_id == "player_turn" and origin.distance_to(board_position) >= 54.0 and absf(board_position.x - origin.x) >= 42.0
			semantic_action = "blackjack_stand"
			invalid_message = "Wave clearly across the active hand to stand; the hand remains live."
		BLACKJACK_TAP_GESTURE:
			valid = phase_id == "player_turn" and Rect2(318, 214, 270, 96).has_point(board_position)
			semantic_action = "blackjack_hit"
			invalid_message = "Tap and release inside the active hand to request a card."
	_blackjack_clear_gesture_state(next_state)
	if not valid:
		return GameModule.surface_command({"handled": true, "ui_state": next_state, "preserve_surface_ui_state": true, "message": invalid_message}, true)
	var semantic_command := _blackjack_surface_action_command(semantic_action, gesture_index, false, next_state, run_state, environment)
	semantic_command["blackjack_surface_intent"] = semantic_action
	semantic_command["blackjack_surface_intent_index"] = gesture_index
	return semantic_command


func _blackjack_clear_gesture_state(ui_state: Dictionary) -> void:
	ui_state.erase("blackjack_gesture_active")
	ui_state.erase("blackjack_gesture_origin")
	ui_state.erase("blackjack_gesture_index")
	ui_state.erase("blackjack_gesture_pointer")


func coach_state(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	var count_challenge: Dictionary = ui_state.get("count_challenge", {}) if typeof(ui_state.get("count_challenge", {})) == TYPE_DICTIONARY else {}
	var cheats: Dictionary = ui_state.get("cheats_used", {}) if typeof(ui_state.get("cheats_used", {})) == TYPE_DICTIONARY else {}
	var count_icons: Array = count_challenge.get("icons", []) if typeof(count_challenge.get("icons", [])) == TYPE_ARRAY else []
	var clicked_icons: Array = count_challenge.get("clicked_icons", []) if typeof(count_challenge.get("clicked_icons", [])) == TYPE_ARRAY else []
	var surface_action_anchors: Array = []
	var table := _table_state_preview(run_state, environment)
	var hand_active := _has_dealt_hand(ui_state)
	var hands_played := int(table.get("hands_played", 0))
	var previous_wager := int(_local_copy_dict(table.get("last_result", {})).get("main_stake", 0))
	var pending_wager := _effective_table_stake(int(ui_state.get("selected_stake", 1)), ui_state, run_state, environment)
	var distractions: Array = _dictionary_array(table.get("distractions", []))
	for index in range(mini(distractions.size(), 3)):
		var distraction: Dictionary = distractions[index]
		var distraction_id := str(distraction.get("id", "")).strip_edges()
		if not distraction_id.is_empty():
			surface_action_anchors.append({
				"id": "blackjack_distraction:%s" % distraction_id,
				"action": "blackjack_distraction",
				"index": index,
			})
	return {
		"hands_played": hands_played,
		"hand_active": hand_active,
		"between_hands": not hand_active and not _local_copy_dict(table.get("last_result", {})).is_empty(),
		"wager_raised": not hand_active and previous_wager > 0 and pending_wager > previous_wager,
		"counting_enabled": bool(ui_state.get("counting_enabled", table.get("counting_enabled", false))),
		"count_started": not count_challenge.is_empty(),
		"count_all_selected": not count_icons.is_empty() and clicked_icons.size() >= count_icons.size(),
		"count_answered": bool(ui_state.get("count_answered", table.get("tutorial_count_completed", false))),
		"count_perfect": bool(ui_state.get("count_perfect", table.get("tutorial_count_perfect", false))),
		"tutorial_count_completed": bool(table.get("tutorial_count_completed", false)),
		"lookaway_started": not str(ui_state.get("dealer_lookaway_id", "")).is_empty(),
		"peek_used": bool(cheats.get("peek_hole_card", false)),
		"surface_action_anchors": surface_action_anchors,
	}


func _blackjack_surface_action_command(surface_action: String, index: int, confirm_requested: bool, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	var table: Dictionary = _table_state_preview(run_state, environment)
	var next_state: Dictionary = _normalized_session(run_state, environment, ui_state, table)
	var selected_stake: int = _effective_table_stake(_session_stake(int(ui_state.get("selected_stake", next_state.get("selected_stake", 1))), next_state), next_state, run_state, environment)
	# The ordinary host range clamps against bankroll, but Blackjack's visible main
	# wager also reserves every active side bet. Reapply that exact table-specific
	# ceiling at the command boundary so a stale selection cannot be sealed above
	# the wager the felt currently presents as affordable.
	if not _has_dealt_hand(next_state) and not bool(next_state.get("locked_stake", false)):
		var effective_floor := _surface_stake_floor(run_state, environment)
		var effective_ceiling := _max_table_stake_for_blackjack(next_state, table, run_state, environment)
		selected_stake = effective_floor if effective_ceiling < effective_floor else clampi(selected_stake, effective_floor, effective_ceiling)
		next_state["selected_stake"] = selected_stake
	_update_live_count_state(next_state, table, run_state, true)
	if bool(table.get("barred", false)):
		return _message_command(next_state, str(table.get("barred_reason", "The dealer refuses to let you play this blackjack table.")))
	match surface_action:
		"blackjack_chip":
			return _chip_bet_command(index, next_state, table, run_state, environment, selected_stake)
		"blackjack_correct_bet":
			return _correct_chip_bet_command(index, next_state, table, run_state, environment)
		"blackjack_remove_chip":
			return _remove_chip_bet_command(index, next_state, table, run_state, environment, selected_stake)
		"blackjack_undo_bet":
			return _undo_blackjack_wager_command(index, next_state, table, run_state, environment)
		"blackjack_repeat_bet", "blackjack_rebet":
			return _repeat_blackjack_wager_command(index, next_state, table, run_state, environment, surface_action == "blackjack_rebet")
		"blackjack_patron_bet":
			return _patron_bet_command(index, next_state, table, run_state, environment)
		"blackjack_clear_bet":
			if _has_dealt_hand(next_state):
				return _message_command(next_state, "Main bets are locked until the hand settles.")
			_blackjack_push_wager_edit(next_state)
			var min_bet := _surface_stake_floor(run_state, environment)
			next_state["selected_stake"] = min_bet
			next_state["blackjack_side_bets"] = []
			next_state.erase("table_social_alignment")
			return _wager_edit_command(next_state, index, min_bet, "Bet cleared to the table minimum.")
		"blackjack_max_bet":
			if _has_dealt_hand(next_state):
				return _message_command(next_state, "Main bets are locked until the hand settles.")
			_blackjack_push_wager_edit(next_state)
			var max_bet := _max_table_stake_for_blackjack(next_state, table, run_state, environment)
			next_state["selected_stake"] = max_bet
			next_state.erase("table_social_alignment")
			return _wager_edit_command(next_state, index, max_bet, "Chips pushed to the edge of your bankroll.")
		"blackjack_deal":
			if _has_dealt_hand(next_state):
				if not _all_hands_complete(next_state) and not _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
					if _count_settlement_preview_required(next_state):
						_stand_all_hands(next_state)
						return _settle_completed_round_command(next_state, index, "You wave off the hand. Dealer reveals and settles.", table, run_state)
					if str(next_state.get("selected_action_id", "")) == "play_basic" and str(next_state.get("selected_action_kind", "")) == "legal":
						_stand_all_hands(next_state)
						return _settle_completed_round_command(next_state, index, "You wave off the hand. Dealer reveals and settles.", table, run_state)
					return _action_command("play_basic", "legal", confirm_requested, next_state, index, "Basic play selected. Click again to stand and settle, or use the live hand buttons.", true)
				return _settle_completed_round_command(next_state, index, _terminal_round_message(next_state), table, run_state)
			var ritual_envelope := blackjack_ritual_deal_envelope(next_state, environment)
			if not blackjack_ritual_deal_envelope_authorized(ritual_envelope, "wagering"):
				return _message_command(next_state, "The dealer cannot authenticate that wager boundary; no wager was charged.")
			var dealt_state := next_state.duplicate(true)
			_start_initial_hand(dealt_state, table, selected_stake, run_state)
			var projected_cost: int = _wager_cost_from_session(selected_stake, dealt_state, table, run_state)
			if projected_cost > maxi(0, run_state.wager_capacity_for_game(get_id(), environment) if run_state != null else projected_cost):
				return _message_command(next_state, "You do not have enough bankroll for those chips and side bets.")
			if run_state != null and projected_cost >= maxi(0, run_state.wager_capacity_for_game(get_id(), environment)):
				return GameModule.surface_command({
					"handled": true,
					"ui_state": _compact_session_for_ui(next_state),
					"action_id": BLACKJACK_CHARGED_DEAL_ACTION,
					"action_kind": "legal",
					"ritual_command": ritual_envelope,
					"ritual_handler_id": BLACKJACK_RITUAL_HANDLER_ID,
					"direct_resolve": true,
					"preserve_surface_ui_state": true,
					"selected_index": index,
					"message": "Confirm the all-in blackjack wager.",
				})
			var command := _opening_deal_command(dealt_state, index, _opening_deal_notice(dealt_state, table))
			command["action_id"] = BLACKJACK_CHARGED_DEAL_ACTION
			command["action_kind"] = "legal"
			command["ritual_command"] = ritual_envelope
			command["ritual_handler_id"] = BLACKJACK_RITUAL_HANDLER_ID
			command["direct_resolve"] = true
			command["preserve_surface_ui_state"] = true
			return GameModule.surface_command(command)
		BLACKJACK_SETTLE_ACTION:
			if not _has_dealt_hand(next_state):
				return _message_command(next_state, "There is no active hand to settle.")
			if not _all_hands_complete(next_state) and not _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
				return _message_command(next_state, "Finish the active hand before settlement.")
			return _settle_completed_round_command(next_state, index, _terminal_round_message(next_state), table, run_state)
		"blackjack_distraction":
			return _start_distraction_command(index, next_state, table, run_state)
		"blackjack_patron_cover":
			return _cover_patron_command(index, next_state, table)
		"blackjack_count_toggle":
			return _toggle_counting_command(index, next_state, table, environment, run_state)
		"blackjack_hit":
			if _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
				return _settle_completed_round_command(next_state, index, "Dealer reveals blackjack before another card can leave the shoe.", table, run_state)
			if not _can_hit(next_state):
				return _message_command(next_state, "That hand cannot take another card.")
			var hit_hand_index := int(next_state.get("active_hand_index", 0))
			var hit_strategy_notice := _record_strategy_deviation(next_state, table, run_state, "hit")
			_deal_to_active_hand(next_state, table)
			_autoadvance_finished_hands(next_state, table)
			_sync_count_challenge_icons(next_state, run_state)
			if _all_hands_complete(next_state):
				var terminal_hit_message := _terminal_round_message(next_state)
				if not hit_strategy_notice.is_empty():
					terminal_hit_message = "%s %s" % [terminal_hit_message, hit_strategy_notice]
				return _settle_completed_round_command(next_state, index, terminal_hit_message, table, run_state)
			return _message_command(next_state, _append_strategy_notice(_post_hand_action_message(next_state, hit_hand_index, "Hit"), hit_strategy_notice))
		"blackjack_stand":
			if not _has_dealt_hand(next_state):
				return _message_command(next_state, "Place your chips and press Deal first.")
			if _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
				return _settle_completed_round_command(next_state, index, "Dealer reveals blackjack before play continues.", table, run_state)
			if _all_hands_complete(next_state):
				return _settle_completed_round_command(next_state, index, _terminal_round_message(next_state), table, run_state)
			var stood_hand_index := int(next_state.get("active_hand_index", 0))
			var stand_strategy_notice := _record_strategy_deviation(next_state, table, run_state, "stand")
			if _can_stand(next_state):
				_stand_active_hand(next_state)
			if _all_hands_complete(next_state):
				var terminal_stand_message := _terminal_round_message(next_state)
				if not stand_strategy_notice.is_empty():
					terminal_stand_message = "%s %s" % [terminal_stand_message, stand_strategy_notice]
				return _settle_completed_round_command(next_state, index, terminal_stand_message, table, run_state)
			return _message_command(next_state, _append_strategy_notice(_post_hand_action_message(next_state, stood_hand_index, "Stand"), stand_strategy_notice))
		"blackjack_double":
			if _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
				return _settle_completed_round_command(next_state, index, "Dealer reveals blackjack before the double can play.", table, run_state)
			if not _can_double(next_state, table, selected_stake, run_state):
				return _message_command(next_state, "Double is not available on this hand.")
			var doubled_hand_index := int(next_state.get("active_hand_index", 0))
			var double_strategy_notice := _record_strategy_deviation(next_state, table, run_state, "double")
			_double_active_hand(next_state, table)
			_autoadvance_finished_hands(next_state, table)
			_sync_count_challenge_icons(next_state, run_state)
			return _additional_hand_wager_command(next_state, index, _append_strategy_notice(_post_hand_action_message(next_state, doubled_hand_index, "Double"), double_strategy_notice))
		"blackjack_split":
			if _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
				return _settle_completed_round_command(next_state, index, "Dealer reveals blackjack before the split can play.", table, run_state)
			if not _can_split(next_state, table, selected_stake, run_state):
				return _message_command(next_state, "Split is not available on this hand.")
			var split_strategy_notice := _record_strategy_deviation(next_state, table, run_state, "split")
			_split_active_hand(next_state, table)
			_sync_count_challenge_icons(next_state, run_state)
			return _additional_hand_wager_command(next_state, index, _append_strategy_notice("Pair split. Each hand gets its own decision.", split_strategy_notice))
		"blackjack_surrender":
			if _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
				return _settle_completed_round_command(next_state, index, "Dealer has blackjack; surrender is not available.", table, run_state)
			if not _can_surrender(next_state, table):
				return _message_command(next_state, "Late surrender is not available on this hand.")
			var surrendered_hand_index := int(next_state.get("active_hand_index", 0))
			var surrender_strategy_notice := _record_strategy_deviation(next_state, table, run_state, "surrender")
			_surrender_active_hand(next_state)
			return _settle_completed_round_command(next_state, index, _append_strategy_notice(_post_hand_action_message(next_state, surrendered_hand_index, "Surrender"), surrender_strategy_notice), table, run_state)
		"blackjack_side_bet":
			return _toggle_side_bet_command(index, next_state, table, run_state, ui_state)
		"blackjack_peek":
			if not _has_dealt_hand(next_state):
				return _message_command(next_state, "Place your chips and deal before trying to read the hole card.")
			if bool(next_state.get("dealer_hole_visible", false)):
				return _message_command(next_state, "Hole card already exposed.")
			var peek_window_open := _dealer_peek_window_open(table, next_state, run_state)
			var cheats: Dictionary = _local_copy_dict(next_state.get("cheats_used", {}))
			next_state["peek_had_window"] = peek_window_open
			next_state["peek_snitch_risk"] = _patron_snitch_risk(table, next_state)
			cheats["peek_hole_card"] = true
			next_state["cheats_used"] = cheats
			if not peek_window_open:
				next_state["peek_caught_watching"] = true
				next_state["dealer_hole_visible"] = false
				return _action_command("peek_hole_card", "cheat", true, next_state, index, "The dealer catches your eyes on the hole card.", true, run_state != null and run_state.is_tutorial_run(), true)
			next_state["dealer_hole_visible"] = true
			_sync_count_challenge_icons(next_state, run_state)
			# Peek changes information inside the current hand; it is not a hand
			# settlement. Preserve that exact session so the player can use the read and
			# finish with Hit or Stand before another tutorial lesson becomes eligible.
			return _action_command("peek_hole_card", "cheat", confirm_requested, next_state, index, "You catch a glimpse of the down card. The dealer may notice.", false, true)
		"blackjack_count":
			return _toggle_counting_command(index, next_state, table, environment, run_state)
		"blackjack_count_icon":
			return _hit_count_icon(index, next_state, table, run_state)
	return {"handled": false}


func _blackjack_in_place_session_intent_command(surface_action: String, index: int, _confirm_requested: bool, session: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if surface_action == "blackjack_distraction":
		var table := _peek_table_state(environment)
		return _start_distraction_command(index, session, table, run_state)
	if surface_action == "blackjack_count_icon":
		var table := _peek_table_state(environment)
		if table.is_empty():
			return _message_command(session, "The count pulse is no longer available.")
		return _hit_count_icon(index, session, table, run_state)
	if not surface_action in [BLACKJACK_SETTLE_ACTION, "blackjack_hit", "blackjack_stand", "blackjack_double", "blackjack_split", "blackjack_surrender", "blackjack_peek"]:
		return {"handled": false}
	# The ordinary hand buttons first transform only the authenticated session.
	# Foundation stages non-terminal results directly in that ledger. A card that
	# completes the round returns a resolve command, which Foundation detects and
	# reruns through the isolated wager/settlement transaction before publishing.
	return _blackjack_surface_action_command(surface_action, index, _confirm_requested if surface_action == "blackjack_peek" else false, session, run_state, environment)


func _blackjack_in_place_session_surface_patch(session: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	# Session-only decisions must become visible on the same input boundary. A
	# complete Foundation refresh rebuilds the environment, HUD, dialogue and
	# action panels before the canvas sees the new card, producing a player-visible
	# hitch and consuming most of the short deal animation. Project only the fields
	# that a live decision can change and let the host apply them atomically.
	var table := _peek_table_state(environment)
	if table.is_empty():
		return {}
	var now_msec := int(session.get("surface_time_msec", Time.get_ticks_msec()))
	var presentation_msec := _blackjack_presentation_time_msec(session, now_msec)
	var hands := _hand_array(session.get("player_hands", []))
	var active_index := clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	var active_hand: Dictionary = hands[active_index] if active_index < hands.size() else {}
	var active_cards := _card_array(active_hand.get("cards", []))
	var dealer_cards := _card_array(session.get("dealer_cards", []))
	var deal_id := str(session.get("deal_animation_id", ""))
	var deal_started_msec := int(session.get("deal_started_msec", 0))
	var deal_events := _deal_animation_event_array(session.get("deal_animation_events", []))
	var patron_hands := _hand_array(session.get("patron_hands", []))
	var patron_action_events := _patron_action_event_array(session.get("patron_action_events", []))
	var deal_duration_msec := maxi(_deal_animation_duration_msec(deal_events), _patron_action_animation_duration_msec(patron_action_events))
	var deal_active := not deal_id.is_empty() and deal_started_msec > 0 \
			and presentation_msec >= deal_started_msec \
			and presentation_msec < deal_started_msec + deal_duration_msec
	var challenge := _local_copy_dict(session.get("count_challenge", {}))
	var count_active := not challenge.is_empty() and not bool(session.get("count_answered", false))
	var dealt := _has_dealt_hand(session)
	var barred := bool(table.get("barred", false))
	var round_complete := dealt and _all_hands_complete(session)
	var dealer_blackjack_pending := dealt and _dealer_has_blackjack(dealer_cards)
	var attention_id := str(session.get("dealer_lookaway_id", ""))
	var attention_started_msec := int(session.get("dealer_lookaway_started_msec", 0))
	var attention_duration_msec := int(session.get("dealer_lookaway_duration_msec", 0))
	var last_result := _local_copy_dict(table.get("last_result", {}))
	var between_hands := not dealt and not last_result.is_empty()
	var counting_enabled := bool(session.get("counting_enabled", table.get("counting_enabled", false)))
	var payout_id := str(last_result.get("payout_animation_id", ""))
	var payout_started_msec := _blackjack_payout_started_msec(last_result, deal_started_msec, deal_duration_msec)
	var payout_active := not payout_id.is_empty() and payout_started_msec > 0 \
			and presentation_msec >= payout_started_msec \
			and presentation_msec < payout_started_msec + PAYOUT_ANIMATION_DURATION_MSEC
	var total_info := _hand_total_info(active_cards)
	var selected_stake := _effective_table_stake(_session_stake(int(session.get("selected_stake", 1)), session), session, run_state, environment)
	return {
		"dealer_focus_runtime": {
			"dealer_lookaway_started_msec": attention_started_msec,
			"dealer_lookaway_duration_msec": attention_duration_msec,
			"dealer_distraction_noise": int(session.get("dealer_distraction_noise", 0)),
			"dealer_distraction_cover": int(session.get("dealer_distraction_cover", 0)),
			"count_active": count_active,
			"count_attention_risk": int(challenge.get("dealer_attention_risk", 0)),
			"strategy_attention_boost": int(session.get("strategy_attention_boost", 0)),
		},
		"surface_time_msec": now_msec,
		"surface_presentation_time_msec": presentation_msec,
		"surface_ui_protected_regions": _blackjack_ui_protected_regions(challenge),
		"money_presentation_animation_channel": DEAL_ANIMATION_CHANNEL,
		"surface_animation_channels": [
			GameModule.surface_animation_channel(DEAL_ANIMATION_CHANNEL, deal_id, deal_duration_msec, deal_started_msec, {
				"active": deal_active,
				"clock_source": "presentation",
				"metadata": {"event_count": deal_events.size()},
			}),
			GameModule.surface_animation_channel(ATTENTION_ANIMATION_CHANNEL, attention_id, attention_duration_msec, attention_started_msec, {"clock_source": "surface"}),
			GameModule.surface_animation_channel(COUNT_ANIMATION_CHANNEL, str(challenge.get("challenge_id", "")), 0 if count_active else 2600, int(challenge.get("started_msec", 0)), {"clock_source": "surface"}),
			GameModule.surface_animation_channel(PAYOUT_ANIMATION_CHANNEL, payout_id, PAYOUT_ANIMATION_DURATION_MSEC if not payout_id.is_empty() else 0, payout_started_msec, {"active": payout_active, "clock_source": "presentation"}),
		],
		"phase": "barred" if barred else "settling" if round_complete else "decision" if dealt else "betting",
		"between_hands": between_hands,
		"between_hands_count_visible": between_hands and counting_enabled,
		"between_hands_recorded_running_count": int(table.get("recorded_running_count", 0)),
		"table_barred": barred,
		"barred_reason": str(table.get("barred_reason", "")),
		"player_hands": hands,
		"patron_hands": patron_hands,
		"patron_action_events": patron_action_events,
		"dealer": _dealer_view(dealer_cards, bool(session.get("dealer_hole_visible", false))),
		"dealer_cards": dealer_cards,
		"dealer_hole_visible": bool(session.get("dealer_hole_visible", false)),
		"active_hand_index": active_index,
		"blackjack_total": int(total_info.get("total", 0)),
		"blackjack_soft": bool(total_info.get("soft", false)),
		"deal_animation_id": deal_id,
		"deal_started_msec": deal_started_msec,
		"deal_animation_events": deal_events,
		"deal_animation_duration_msec": deal_duration_msec,
		"table_notice": _table_notice_for_session(session, table),
		"active_hand_status": _active_hand_status_text(session),
		"round_complete": round_complete,
		"settle_available": round_complete or dealer_blackjack_pending,
		"dealer_blackjack_pending": dealer_blackjack_pending,
		"selected_stake": selected_stake,
		"can_deal": not dealt and not barred,
		"can_hit": _can_hit(session) and not barred,
		"can_stand": _can_stand(session) and not barred,
		"can_double": _can_double(session, table, selected_stake, run_state) and not barred,
		"can_split": _can_split(session, table, selected_stake, run_state) and not barred,
		"can_surrender": _can_surrender(session, table) and not barred,
		"can_change_side_bets": _can_change_side_bets(session) and not barred,
		"basic_strategy_advice": _basic_strategy_advice(session, table, run_state),
		"count_hint": _count_hint(run_state, table, session),
		"counting_enabled": counting_enabled,
		"count_challenge": challenge,
		"count_answered": bool(session.get("count_answered", false)),
		"count_correct": bool(session.get("count_correct", false)),
		"count_perfect": bool(session.get("count_perfect", false)),
		"count_delta": int(session.get("count_delta", 0)),
		"count_hand_delta": int(session.get("count_delta", 0)),
		"count_declared_delta": int(session.get("count_declared_delta", 0)),
		"native_selected_surface_actions": _selected_surface_actions(session, session),
	}


func _blackjack_in_place_session_intent_allowed(surface_action: String, run_state: RunState, environment: Dictionary) -> bool:
	if run_state == null or _is_rourke_duel(run_state, environment):
		return false
	if surface_action in ["blackjack_split", "blackjack_double"]:
		return false
	var table := _peek_table_state(environment)
	var ledger_value: Variant = table.get(BLACKJACK_HOST_LEDGER_KEY, null)
	if typeof(ledger_value) != TYPE_DICTIONARY:
		return true
	var session_value: Variant = (ledger_value as Dictionary).get("session", null)
	if typeof(session_value) != TYPE_DICTIONARY:
		return true
	var session := session_value as Dictionary
	if surface_action != BLACKJACK_SETTLE_ACTION:
		# A decision that will finish the last live hand must cross the wager/result
		# boundary. Send it there immediately instead of first executing the same
		# decision as a session-only preview and then throwing that work away.
		if _blackjack_decision_will_settle(surface_action, session, table, run_state):
			return false
		return true
	# Only the non-economic reveal/wait variants use the cheap session path. Once
	# the reveal exists, route the click directly to the sealed payout transaction
	# instead of running the same command once as a preflight and then again there.
	if not _has_dealt_hand(session) or (not _all_hands_complete(session) and not _dealer_has_blackjack(_card_array(session.get("dealer_cards", [])))):
		return true
	if bool(session.get("presentation_timing_enforced", false)) and _deal_presentation_active(session):
		return true
	return _count_settlement_preview_required(session)


func _blackjack_decision_will_settle(surface_action: String, session: Dictionary, table: Dictionary, run_state: RunState) -> bool:
	if not _has_dealt_hand(session):
		return false
	if _dealer_has_blackjack(_card_array(session.get("dealer_cards", []))):
		return surface_action in ["blackjack_hit", "blackjack_stand", "blackjack_double", "blackjack_split"]
	if surface_action == "blackjack_surrender":
		return _can_surrender(session, table)
	if not surface_action in ["blackjack_stand", "blackjack_double"]:
		return false
	var active_index := int(session.get("active_hand_index", 0))
	var hands_value: Variant = session.get("player_hands", [])
	if typeof(hands_value) != TYPE_ARRAY:
		return false
	var hands := hands_value as Array
	if active_index < 0 or active_index >= hands.size():
		return false
	for hand_index in range(hands.size()):
		if hand_index == active_index:
			continue
		var hand_value: Variant = hands[hand_index]
		if typeof(hand_value) != TYPE_DICTIONARY:
			return false
		var hand := hand_value as Dictionary
		if not bool(hand.get("stood", false)) and _hand_total(_card_array(hand.get("cards", []))) < 21:
			return false
	var stake := maxi(1, int(session.get("locked_stake", session.get("selected_stake", 1))))
	return _can_stand(session) if surface_action == "blackjack_stand" else _can_double(session, table, stake, run_state)


func _rourke_duel_surface_action_command(surface_action: String, index: int, confirm_requested: bool, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	var table := _table_state(run_state, environment)
	var next_state := _normalized_session(run_state, environment, ui_state, table)
	var duel := run_state.grand_casino_duel_status()
	var ante := maxi(1, int(duel.get("ante", 20)))
	next_state["boss_duel_session"] = true
	next_state["selected_stake"] = ante
	next_state["locked_stake"] = ante
	var command: Dictionary
	match surface_action:
		"blackjack_deal":
			if _has_dealt_hand(next_state):
				if not _all_hands_complete(next_state):
					_stand_all_hands(next_state)
				command = _settle_completed_round_command(next_state, index, "Rourke turns the hole card and settles the hand.", table, run_state)
			else:
				var deal_time_msec := int(next_state.get("surface_time_msec", run_state.grand_casino_duel_action_time_msec()))
				_start_initial_hand(next_state, table, ante, run_state, deal_time_msec)
				command = _opening_deal_command(next_state, index, str(run_state.grand_casino_duel_status().get("last_bark", "Rourke deals.")))
		BLACKJACK_SETTLE_ACTION:
			if not _has_dealt_hand(next_state):
				command = _message_command(next_state, "There is no active hand to settle.")
			elif not _all_hands_complete(next_state) and not _dealer_has_blackjack(_card_array(next_state.get("dealer_cards", []))):
				command = _message_command(next_state, "Finish the active hand before settlement.")
			else:
				command = _settle_completed_round_command(next_state, index, "Rourke turns the hole card and settles the hand.", table, run_state)
		"blackjack_boss_callout":
			if not _has_dealt_hand(next_state):
				command = _message_command(next_state, "See the cards before you call Rourke's move.")
			else:
				var catalog := _dictionary_array(run_state.grand_casino_duel_terms().get("edge_catalog", []))
				if index < 0 or index >= catalog.size():
					command = _message_command(next_state, "That call is not available.")
				else:
					var call := run_state.grand_casino_duel_call_out(str((catalog[index] as Dictionary).get("id", "")))
					if bool(call.get("correct", false)):
						_restore_rourke_edge_session(next_state)
						if bool(next_state.get("counting_enabled", false)):
							_start_count_challenge(next_state, table, run_state, int(next_state.get("surface_time_msec", 0)))
					command = _message_command(next_state, str(call.get("message", "Rourke marks the call.")))
		"blackjack_peek":
			if not _has_dealt_hand(next_state):
				command = _message_command(next_state, "Deal before trying to read Rourke's hole card.")
			elif bool(next_state.get("dealer_hole_visible", false)):
				command = _message_command(next_state, "The hole card is already exposed.")
			else:
				var cheats := _local_copy_dict(next_state.get("cheats_used", {}))
				cheats["peek_hole_card"] = true
				next_state["cheats_used"] = cheats
				next_state["dealer_hole_visible"] = true
				command = _message_command(next_state, "You steal a look. Rourke watches your hands.")
		_:
			command = _blackjack_surface_action_command(surface_action, index, confirm_requested, next_state, run_state, environment)
	# The Rourke hand is owned by the serialized duel rather than the ordinary
	# table host ledger. Keep every dealt intermediate state durable at the same
	# surface-action boundary that produced it so save/exit/revisit can reopen the
	# exact cards, pending animation, edge call, and settlement state.
	var command_ui: Dictionary = _local_copy_dict(command.get("ui_state", {}))
	if bool(command.get("handled", false)) and _has_dealt_hand(command_ui):
		run_state.persist_grand_casino_duel_session(command_ui)
	return command


func resolve(action_id: String, stake: int, run_state: RunState, environment: Dictionary, rng: RngStream) -> Dictionary:
	return _blackjack_compatibility_simulation(action_id, stake, run_state, environment, rng, {})


func resolve_with_context(action_id: String, stake: int, run_state: RunState, environment: Dictionary, rng: RngStream, ui_state: Dictionary = {}) -> Dictionary:
	return _blackjack_compatibility_simulation(action_id, stake, run_state, environment, rng, ui_state)


func _blackjack_compatibility_simulation(action_id: String, stake: int, run_state: RunState, environment: Dictionary, rng: RngStream, ui_state: Dictionary) -> Dictionary:
	# Legacy probes may simulate Blackjack locally, but this API carries no live
	# authority. It snapshots the caller inputs, resolves only detached copies,
	# and returns a receipt-free result that GameModule.apply_result rejects.
	if run_state == null or rng == null:
		return _empty_result(action_id, stake, environment, "Blackjack simulation requires serialized run and RNG inputs.")
	# Standard compatibility actions use the proven read-only core against the
	# live RunState and a detached environment graph. Crew and Rourke paths can
	# author run-owned state, so they retain the full detached restore fallback.
	var simulation_run_state := run_state
	var simulation_environment := _blackjack_compatibility_environment_snapshot(run_state.current_environment)
	var read_only_core := _blackjack_compatibility_read_only_core_allowed(action_id, run_state)
	if not read_only_core:
		var candidate := RunState.new()
		candidate.from_dict(run_state.to_save_snapshot())
		simulation_run_state = candidate
		simulation_environment = candidate.current_environment
	var simulation_rng := RngStream.new()
	simulation_rng.restore(rng.snapshot())
	var resolution_ui_state := ui_state.duplicate(true)
	if not resolution_ui_state.has("surface_time_msec"):
		resolution_ui_state["surface_time_msec"] = GameModule.deterministic_time_msec(simulation_run_state, {})
	# The compatibility environment above already owns its detached table. Let
	# normalization update that private graph in place instead of cloning the
	# complete shoe and table payload a second time before every ordinary hand.
	var result := _resolve_blackjack_proposal_core(action_id, stake, simulation_run_state, simulation_environment, simulation_rng, resolution_ui_state, read_only_core, read_only_core)
	result.erase("blackjack_proposal_requires_apply")
	result.erase("blackjack_host_apply_receipt")
	result.erase("blackjack_host_content_fingerprint")
	result["blackjack_compatibility_simulation"] = true
	result["blackjack_authoritative"] = false
	return result


func _blackjack_compatibility_environment_snapshot(environment: Dictionary) -> Dictionary:
	# Ordinary compatibility simulations are read-only, but they still need a
	# detached Blackjack table because normalization and dealing mutate that
	# table. Copying the complete environment also cloned every unrelated game,
	# ticket mask, room payload, and event record before each hand. Detach only
	# the game-state map and this table; every other environment value is merely
	# observed by the proposal core.
	var snapshot := environment.duplicate(false)
	var source_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var detached_states := source_states.duplicate(false)
	var table_value: Variant = source_states.get(get_id(), {})
	if typeof(table_value) == TYPE_DICTIONARY:
		detached_states[get_id()] = _duplicate_table_with_immutable_authority(table_value as Dictionary)
	snapshot["game_states"] = detached_states
	return snapshot


func _blackjack_compatibility_read_only_core_allowed(action_id: String, run_state: RunState) -> bool:
	if run_state == null or not COMPATIBILITY_READ_ONLY_ACTIONS.has(action_id):
		return false
	return not _is_rourke_duel(run_state, run_state.current_environment)


func _blackjack_resolve_proposal(action_id: String, stake: int, run_snapshot: Dictionary, rng_snapshot: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	# This is a pure proposal boundary: serialized values enter, serialized values
	# leave, and no live Foundation object can be retained or mutated by the game.
	var proposal_input := {
		"action_id": action_id,
		"stake": stake,
		"run_snapshot": run_snapshot,
		"rng_snapshot": rng_snapshot,
		"ui_state": ui_state,
	}
	var input_fingerprint := RuntimeScript.canonical_fingerprint(proposal_input)
	var candidate := RunState.new()
	candidate.from_dict(run_snapshot)
	var rng := RngStream.new()
	rng.restore(rng_snapshot)
	var result := _blackjack_resolve_candidate(action_id, stake, candidate, rng, ui_state)
	var proposal := {
		"ok": bool(result.get("ok", false)),
		"input_fingerprint": input_fingerprint,
		"result": result.duplicate(true),
		"run_snapshot": candidate.to_save_snapshot(),
		"rng_snapshot": rng.snapshot(),
	}
	proposal["output_fingerprint"] = RuntimeScript.canonical_fingerprint(proposal)
	return proposal


func _blackjack_compact_authority_allowed(candidate: RunState, action_id: String, _stake: int, _ui_state: Dictionary = {}) -> bool:
	if candidate == null or action_id.begins_with("crew_play:"):
		return false
	# Pal's protected tutorial Peek records its one-time warning on the run's
	# narrative flags. The compact replay candidate deliberately aliases broad
	# run collections, so this exceptional action must retain the full isolated
	# transaction path instead of letting the first replay mark the second one.
	if action_id == "peek_hole_card" \
			and candidate.blackjack_tutorial_peek_reprieve_eligible(action_id, candidate.current_environment):
		return false
	if _blackjack_full_authority_replay_required(candidate):
		return not candidate.scenario_sequence_present()
	return true


func _blackjack_full_authority_replay_required(candidate: RunState) -> bool:
	# The room variant survives the last hand clearing the active-duel flags.
	# Its terminal proposal still needs the same broad evidence and isolation.
	if candidate == null:
		return false
	var flags := _local_copy_dict(candidate.current_environment.get("local_narrative_flags", {}))
	return str(flags.get("blackjack_boss_variant", "")) == ROURKE_DUEL_VARIANT


func _blackjack_prepared_direct_resolve_allowed(candidate: RunState, action_id: String) -> bool:
	return action_id == "play_basic" and _blackjack_full_authority_replay_required(candidate) and not candidate.is_tutorial_run() \
		and _blackjack_compact_authority_allowed(candidate, action_id, 0)


func _blackjack_restore_recovery_session(candidate: RunState, session: Dictionary) -> void:
	# Rourke owns a serialized duel session in addition to the table ledger. Both
	# must return to the same pre-intent cards when a pending delivery is cancelled.
	if _blackjack_full_authority_replay_required(candidate):
		candidate.persist_grand_casino_duel_session(session)


func _blackjack_in_place_commit_allowed(action_id: String, run_state: RunState, environment: Dictionary) -> bool:
	if run_state == null or _is_rourke_duel(run_state, environment):
		return false
	var table := _peek_table_state(environment)
	var ledger_value: Variant = table.get(BLACKJACK_HOST_LEDGER_KEY, null)
	if typeof(ledger_value) != TYPE_DICTIONARY or not bool((ledger_value as Dictionary).get("initialized", false)):
		# First entry also normalizes the persisted table/authority boundary. Keep that
		# one-time setup detached so save/retry callers can reconstruct it exactly.
		return false
	# These are the only surface/provider ids that can reach an ordinary wager or
	# completed-hand settlement. Crew actions and Pal's tutorial Peek keep the full
	# detached transaction because they may mutate broader RunState collections.
	return action_id in [
		"blackjack_deal", BLACKJACK_SETTLE_ACTION, "blackjack_hit", "blackjack_stand",
		"blackjack_double", "blackjack_split", "blackjack_surrender",
		BLACKJACK_CHARGED_DEAL_ACTION, "play_basic",
	]


func _blackjack_authority_evidence(candidate: RunState, action_id: String, stake: int, ui_state: Dictionary = {}) -> Dictionary:
	if not _blackjack_compact_authority_allowed(candidate, action_id, stake, ui_state):
		return {}
	if _blackjack_full_authority_replay_required(candidate):
		# Rourke changes narrative, inventory, Crew, accounting and terminal roots,
		# all of which remain in this proof. Large world storage is projected out;
		# required room configuration and reputation state are bound separately.
		# Both accepted and replay candidates nevertheless own the complete graph.
		var snapshot := candidate.to_action_snapshot_without_world()
		snapshot.erase("music_tempo_state")
		snapshot.erase("music_choreography_state")
		var crew: Dictionary = snapshot.get("crew_state", {}).duplicate(false)
		crew.erase("a")
		crew.erase("z")
		snapshot["crew_state"] = crew
		var environment: Dictionary = snapshot.get("current_environment", {}).duplicate(false)
		environment.erase("environment_runtime_revision")
		var states: Dictionary = environment.get("game_states", {}).duplicate(false)
		var state_key := transient_state_key_context().strip_edges()
		if state_key.is_empty(): state_key = get_id()
		var table: Dictionary = states.get(state_key, {}).duplicate(false)
		table.erase(ActionAuthorityScript.LEDGER_KEY)
		table.erase(ActionAuthorityScript.PENDING_APPLY_RECEIPT_KEY)
		states[state_key] = table
		environment["game_states"] = states
		snapshot["current_environment"] = environment
		var reputation: Dictionary = {}
		if candidate.town_state != null and candidate.town_state.living_world != null:
			var network := candidate.town_state.living_world
			# A taken-out-back ending records a reputation incident. Bind its full
			# mutable ledger and the exact topology/type inputs used for propagation.
			reputation = {
				"action_index": network.action_index,
				"node_metadata": network.node_metadata,
				"edges": network.edges,
				"reputation_type_registry": network.reputation_type_registry,
				"reputation_incidents": network.reputation_incidents,
				"reputation_sequence": network.reputation_sequence,
				"current_node_id": candidate.current_world_node_id(),
			}
		return {"rourke_run_state": snapshot, "room_context": _blackjack_authority_room_context(candidate), "town_reputation": reputation}
	var environment := candidate.current_environment
	# The sealed host has already materialized and normalized the bound table before
	# asking for compact evidence. Evidence is read-only and immediately
	# canonicalized, so borrow its immutable nested values and detach only the root
	# from which authority metadata is removed. Falling back to the preview keeps
	# direct/headless callers with an unmaterialized table on the conservative path.
	var stored_table := _peek_table_state(environment)
	var table := stored_table.duplicate(false) if not stored_table.is_empty() else _table_state_preview(candidate, environment).duplicate(false)
	# Delivery, replay, and apply receipts authenticate themselves. Keeping that
	# growing history in the gameplay proof would make every later hand slower
	# even though no prior receipt can change the cards or settlement.
	table.erase(ActionAuthorityScript.LEDGER_KEY)
	table.erase(ActionAuthorityScript.PENDING_APPLY_RECEIPT_KEY)
	var environment_evidence := {
		"id": environment.get("id", ""),
		"archetype_id": environment.get("archetype_id", ""),
		"depth": environment.get("depth", 0),
		"turns": environment.get("turns", 0),
		"economic_profile": environment.get("economic_profile", {}),
		"security_profile": environment.get("security_profile", {}),
		"local_narrative_flags": environment.get("local_narrative_flags", {}),
		"game_states": {get_id(): table},
	}
	# Staffing can fall back to the authored main-floor room when the current room
	# has no rotation config. Preserve only that configuration context, never the
	# unrelated machines retained inside those rooms.
	var room_context := _blackjack_authority_room_context(candidate)
	return {
		"version": 1,
		"game_id": get_id(),
		"account_checkpoint": candidate.action_authority_checkpoint_fingerprint(),
		"bankroll": candidate.bankroll,
		"grand_casino_chips": candidate.grand_casino_chips,
		"rng_seed": candidate.rng_seed,
		"rng_state": candidate.rng_state,
		"simulation_msec": candidate.simulation_msec,
		"game_clock_minutes": candidate.game_clock_minutes,
		"seed_text": candidate.seed_text,
		"seed_value": candidate.seed_value,
		"run_status": candidate.run_status,
		"economic_state": candidate.economic_state,
		"challenge_config": candidate.challenge_config,
		"inventory": candidate.inventory,
		"active_item_id": candidate.active_item_id,
		"suspicion": candidate.suspicion,
		"baseline_luck": candidate.baseline_luck,
		"drunk_level": candidate.drunk_level,
		"alcoholic_level": candidate.alcoholic_level,
		"narrative_flags": candidate.narrative_flags,
		"crew_play_state": candidate.crew_play_state,
		"grand_casino_staffing": candidate.grand_casino_staffing,
		"grand_casino_room_context": room_context,
		"rourke_current_room": candidate.rourke_current_room,
		"rourke_current_spot": candidate.rourke_current_spot,
		"rourke_facing": candidate.rourke_facing,
		"rourke_off_floor_actions": candidate.rourke_off_floor_actions,
		"environment": environment_evidence,
	}


func foreground_blocks_environment_runtime(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> bool:
	var session: Dictionary = ui_state
	if _is_rourke_duel(run_state, environment):
		session = run_state.grand_casino_duel_session_readonly()
	else:
		var states_value: Variant = environment.get("game_states", {})
		if typeof(states_value) == TYPE_DICTIONARY:
			var table_value: Variant = (states_value as Dictionary).get(get_id(), {})
			if typeof(table_value) == TYPE_DICTIONARY:
				var ledger_value: Variant = (table_value as Dictionary).get(BLACKJACK_HOST_LEDGER_KEY, {})
				if typeof(ledger_value) == TYPE_DICTIONARY and bool((ledger_value as Dictionary).get("initialized", false)):
					var session_value: Variant = (ledger_value as Dictionary).get("session", {})
					if typeof(session_value) == TYPE_DICTIONARY:
						session = session_value as Dictionary
	var hands_value: Variant = session.get("player_hands", [])
	var dealer_value: Variant = session.get("dealer_cards", [])
	if typeof(hands_value) != TYPE_ARRAY or (hands_value as Array).is_empty() \
			or typeof(dealer_value) != TYPE_ARRAY or (dealer_value as Array).is_empty():
		return false
	return not _all_hands_complete(session)


func _blackjack_authority_room_context(candidate: RunState) -> Dictionary:
	var context: Dictionary = {}
	for room_id_value in candidate.grand_casino_room_states.keys():
		var room_value: Variant = candidate.grand_casino_room_states.get(room_id_value)
		if typeof(room_value) != TYPE_DICTIONARY:
			continue
		var room := room_value as Dictionary
		context[str(room_id_value)] = {
			"id": room.get("id", ""),
			"archetype_id": room.get("archetype_id", ""),
			"local_narrative_flags": room.get("local_narrative_flags", {}),
		}
	return context


func _blackjack_resolve_candidate(action_id: String, stake: int, candidate: RunState, rng: RngStream, ui_state: Dictionary = {}) -> Dictionary:
	# Proposal replay may never consult wall time. A normal rendered surface owns
	# this clock explicitly; headless, restored, and direct host settlements can
	# legitimately omit it. Bind that missing transient value to the sealed
	# candidate's simulation clock, which is already covered by run_snapshot and
	# therefore produces the same proposal on fail-closed replay.
	var resolution_ui_state := ui_state.duplicate(true)
	if not resolution_ui_state.has("surface_time_msec"):
		resolution_ui_state["surface_time_msec"] = GameModule.deterministic_time_msec(candidate, {})
	# The host gives each accepted/replay execution its own detached Blackjack
	# table. Settlement can normalize and update that private table in place instead
	# of deep-copying the shoe, patrons, session, and animation payload twice more.
	# Other action families retain their existing defensive paths below.
	var result := _resolve_blackjack_proposal_core(
		action_id,
		stake,
		candidate,
		candidate.current_environment,
		rng,
		resolution_ui_state,
		false,
		action_id == "play_basic"
	)
	var clean_duel_cashout := bool(result.get("blackjack_boss_duel", false)) \
		and str(result.get("grand_casino_duel_outcome", "")) == "walk_out_clean" \
		and candidate.is_terminal() \
		and int(candidate.narrative_flags.get("grand_casino_duel_cashed_chip_amount", 0)) > 0
	if bool(result.get("ok", false)) and (action_id.begins_with("crew_play:") or clean_duel_cashout):
		_rebind_pending_authority_checkpoint(candidate)
	return result


# Crew plays and a clean-duel cashout apply their money directly to the detached
# candidate. Keep the already sealed pending
# delivery intact while rebinding its restore checkpoint to those canonical
# balances; otherwise the proposal's own save/load validation discards the
# ledger before the host can verify and commit it.
func _rebind_pending_authority_checkpoint(run_state: RunState) -> void:
	if run_state == null:
		return
	var environment := run_state.current_environment
	var game_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var table: Dictionary = game_states.get(get_id(), {}) if typeof(game_states.get(get_id(), {})) == TYPE_DICTIONARY else {}
	var binding := "%s:%s:%s" % [get_id(), str(environment.get("id", "unknown")), str(environment.get("archetype_id", "unknown"))]
	var ledger := ActionAuthorityScript.validate_persisted_ledger(table.get(BLACKJACK_HOST_LEDGER_KEY, {}), binding)
	if ledger.is_empty() or (ledger.get("pending_delivery", {}) as Dictionary).is_empty():
		return
	ledger["checkpoint_fingerprint"] = run_state.action_authority_checkpoint_fingerprint()
	table[BLACKJACK_HOST_LEDGER_KEY] = ledger
	_update_environment_table(environment, table)


func _resolve_blackjack_proposal_core(action_id: String, stake: int, run_state: RunState, environment: Dictionary, rng: RngStream, ui_state: Dictionary = {}, read_only_run_state: bool = false, owns_table_state: bool = false) -> Dictionary:
	if read_only_run_state and (not _blackjack_compatibility_read_only_core_allowed(action_id, run_state) or _is_rourke_duel(run_state, environment)):
		return _empty_result(action_id, stake, environment, "That blackjack action requires a detached authoritative candidate.")
	if action_id.begins_with("crew_play:"):
		return super.resolve_with_context(action_id, stake, run_state, environment, rng, ui_state)
	if _is_rourke_duel(run_state, environment):
		return _resolve_rourke_duel_hand(action_id, run_state, environment, ui_state)
	if action_id == "blackjack_place_bet":
		return _resolve_place_bet(stake, run_state, environment, rng, ui_state, read_only_run_state)
	if action_id == "peek_hole_card" or action_id == "count_cards":
		return _resolve_cheat_only(action_id, run_state, environment, rng, ui_state, read_only_run_state)
	if action_id != "play_basic":
		return _empty_result(action_id, stake, environment, "That blackjack action is not available.")
	var result_msec := GameModule.deterministic_time_msec(run_state, ui_state)
	var presentation_msec := _blackjack_presentation_time_msec(ui_state, result_msec)
	var table: Dictionary = _table_state(run_state, environment, read_only_run_state, owns_table_state)
	if bool(table.get("barred", false)):
		return _empty_result(action_id, stake, environment, str(table.get("barred_reason", "The dealer refuses to let you play this blackjack table.")))
	var session: Dictionary = _normalized_session(run_state, environment, ui_state, table)
	var sit_out := bool(session.get("blackjack_sit_out", false))
	if sit_out:
		session["blackjack_side_bets"] = []
	if not _has_dealt_hand(session):
		_start_initial_hand(session, table, maxi(1, stake), run_state, result_msec)
	if not _all_hands_complete(session):
		_stand_all_hands(session)
	var table_stake := 0 if sit_out else _session_stake(stake, session)
	var total_wager: int = 0 if sit_out else _wager_cost_from_session(table_stake, session, table, run_state)
	if total_wager > maxi(0, run_state.wager_balance_for_game(get_id(), environment)):
		var debited_wager := _session_debited_wager(session)
		if total_wager - debited_wager > maxi(0, run_state.wager_balance_for_game(get_id(), environment)):
			return _empty_result(action_id, stake, environment, "You do not have enough bankroll for that table action.")

	session["dealer_hole_visible"] = true
	var dealer_cards: Array = _dealer_final_cards(session, table)
	var patron_hands: Array = _hand_array(session.get("patron_hands", []))
	var hands: Array = _hand_array(session.get("player_hands", []))
	var hand_results: Array = []
	var main_delta := 0
	for hand_value in hands:
		var hand: Dictionary = hand_value
		var settled: Dictionary = _settle_hand(hand, dealer_cards, maxi(1, table_stake))
		if sit_out:
			settled["bankroll_delta"] = 0
			settled["wager"] = 0
			settled["sat_out"] = true
		hand_results.append(settled)
		main_delta += int(settled.get("bankroll_delta", 0))

	var side_results: Array = [] if sit_out else _settle_side_bets(session, table, dealer_cards, table_stake, run_state)
	var side_delta := 0
	for side_result_value in side_results:
		if typeof(side_result_value) == TYPE_DICTIONARY:
			side_delta += int((side_result_value as Dictionary).get("bankroll_delta", 0))

	if not bool(session.get("count_answered", false)) and not _local_copy_dict(session.get("count_challenge", {})).is_empty():
		_sync_count_challenge_icons(session, run_state, result_msec)
		_finalize_count_challenge(session, run_state, result_msec)
	_persist_tutorial_count_lesson_result(table, session, run_state, environment)
	var cheat: Dictionary = {} if sit_out else _cheat_detection_for_hand(session, table, run_state, environment, rng, table_stake)
	var cufflinks_broke := _coolers_cufflinks_absorbed_failed_peek(action_id, cheat, run_state)
	var raw_suspicion_delta: int = int(cheat.get("suspicion_delta", 0))
	if cufflinks_broke:
		raw_suspicion_delta = 0
	var suspicion_delta: int = run_state.alcohol_adjusted_suspicion_delta(raw_suspicion_delta) if raw_suspicion_delta > 0 else raw_suspicion_delta
	suspicion_delta = run_state.blackjack_suspicion_delta_before_backoff(suspicion_delta) if suspicion_delta > 0 else suspicion_delta
	# A basic-strategy mistake may add a trace of local heat, but it must not
	# cascade into the security penalties reserved for actual advantage play.
	var security_pressure: Dictionary = run_state.security_action_pressure("cheat", stake, run_state.suspicion_level() + suspicion_delta) if suspicion_delta > 0 and bool(cheat.get("advantage_play", false)) else {}
	var security_bankroll_delta: int = int(security_pressure.get("bankroll_delta", 0))
	var security_message := str(security_pressure.get("message", ""))

	var item_adjustment: Dictionary = {} if sit_out else _blackjack_item_adjustment(main_delta, side_delta, session, run_state, table_stake)
	main_delta += int(item_adjustment.get("main_delta", 0))
	side_delta += int(item_adjustment.get("side_delta", 0))
	var debited_wager_total := 0 if sit_out else _session_debited_wager(session)
	var settlement_return_delta := main_delta + side_delta + debited_wager_total
	var bankroll_delta: int = settlement_return_delta + security_bankroll_delta
	var round_net_delta := main_delta + side_delta + security_bankroll_delta

	var used_cards: Array = _cards_used_for_counting(hands, dealer_cards, patron_hands)
	var patron_action_events: Array = _patron_action_event_array(session.get("patron_action_events", []))
	var actual_count_delta: int = _count_cards_delta(used_cards)
	# The durable shoe count is derived from the cards the canonical table dealt.
	# Caller challenge payload may describe presentation/click progress, but it can
	# never author the persisted count (or inject an arbitrary declared delta).
	var count_record_delta: int = actual_count_delta if bool(session.get("count_answered", false)) else 0
	var message := _blackjack_result_message(hand_results, side_results, main_delta, side_delta, cheat, item_adjustment, security_message)
	if suspicion_delta > 0 and run_state.is_grand_casino_environment(environment) and bool(cheat.get("pit_boss_watched", false)) \
			and message.find("Rourke") == -1 and message.find("Security") == -1 and message.find("staff") == -1:
		message = "%s Rourke's floor staff marks the play." % message
	if cufflinks_broke:
		message = "%s Cooler's Cufflinks absorb the peek heat and break." % message
	if sit_out:
		message = "You watch the blackjack hand without wagering. %s" % message
	var result_action_kind := "legal"
	if bool(cheat.get("used_peek", false)) or bool(cheat.get("used_count", false)):
		result_action_kind = "cheat"
	elif bool(cheat.get("advantage_play", false)):
		result_action_kind = "risky"
	_update_table_after_hand(table, session, dealer_cards, actual_count_delta, count_record_delta, rng, presentation_msec, cheat)
	if not sit_out:
		_apply_patron_rapport_after_blackjack(table, session, table_stake, round_net_delta)
	table["last_result"] = _blackjack_last_result_payload(FunctionOptions.BlackjackResultOptions.from({
		"message": message, "hand_results": hand_results, "side_results": side_results,
		"main_delta": main_delta, "side_delta": side_delta, "bankroll_delta": bankroll_delta,
		"suspicion_delta": suspicion_delta, "dealer_cards": dealer_cards, "player_hands": hands,
		"patron_hands": patron_hands, "patron_action_events": patron_action_events, "cheat": cheat,
		"result_msec": presentation_msec, "round_net_delta_value": round_net_delta,
	}))
	(table["last_result"] as Dictionary)["main_stake"] = table_stake
	(table["last_result"] as Dictionary)["side_bet_ids"] = _string_array(session.get("blackjack_side_bets", []))
	(table["last_result"] as Dictionary)["total_wager"] = total_wager
	# A sealed candidate already stores this exact private table dictionary. Its
	# accepted result may remain in place; ordinary/live callers still cross the
	# defensive storage-copy boundary.
	if not owns_table_state:
		_update_environment_table(environment, table)

	var story_entry := {
		"type": "game_action",
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": result_action_kind,
		"stake": table_stake,
		"total_wager": total_wager,
		"wager_debited": debited_wager_total,
		"settlement_return_delta": settlement_return_delta,
		"sat_out": sit_out,
		"bankroll_delta": bankroll_delta,
		# Durable display metadata only; monetary instructions remain unchanged.
		"currency": GameModule.presentation_currency_for_game(run_state, get_id(), environment),
		"currency_delta": bankroll_delta,
		"round_net_delta": round_net_delta,
		"outcome_bankroll_delta": round_net_delta,
		"main_delta": main_delta,
		"side_delta": side_delta,
		"suspicion_delta": suspicion_delta,
		"dealer_caught_cheat": bool(cheat.get("caught", false)),
		"coolers_cufflinks_broke": cufflinks_broke,
		"dealer_strategy_confronted": bool(cheat.get("strategy_confronted", false)),
		"strategy_deviation_count": (_dictionary_array(cheat.get("strategy_deviation_events", []))).size(),
		"dealer_total": int(_hand_total_info(dealer_cards).get("total", 0)),
		"hand_results": hand_results,
		"side_bet_results": side_results,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
		"pit_boss_watched": bool(cheat.get("pit_boss_watched", false)),
		"pit_boss_heat_bonus": int(cheat.get("pit_boss_heat_bonus", 0)),
		"security_message": security_message,
	}
	var deltas := GameModule.empty_result_deltas()
	deltas["bankroll_delta"] = bankroll_delta
	deltas["suspicion_delta"] = suspicion_delta
	if cufflinks_broke:
		deltas["inventory_remove"] = [COOLERS_CUFFLINKS_ITEM_ID]
		deltas["inventory_add"] = [BROKEN_CUFFLINKS_ITEM_ID]
	deltas["story_log"] = [story_entry]
	deltas["messages"] = [message]
	deltas["ended"] = bool(security_pressure.get("ended", false))
	var result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": result_action_kind,
		"stake": table_stake,
		"bankroll_delta": bankroll_delta,
		"suspicion_delta": suspicion_delta,
		"deltas": deltas,
		"won": round_net_delta > 0,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
		"message": message,
	})
	# Keep the committed return private until the existing final-card channel ends.
	result["hold_money_for_presentation"] = true
	result["blackjack_player_hands"] = hands
	result["blackjack_dealer"] = dealer_cards
	result["blackjack_patron_hands"] = patron_hands
	result["blackjack_patron_action_events"] = patron_action_events
	result["blackjack_hand_results"] = hand_results
	result["blackjack_side_bet_results"] = side_results
	result["blackjack_main_delta"] = main_delta
	result["blackjack_side_bet_delta"] = side_delta
	result["blackjack_wager_debited"] = debited_wager_total
	result["blackjack_settlement_return_delta"] = settlement_return_delta
	result["blackjack_round_net_delta"] = round_net_delta
	result["outcome_bankroll_delta"] = round_net_delta
	result["blackjack_sat_out"] = sit_out
	result["blackjack_cheat_caught"] = bool(cheat.get("caught", false))
	result["blackjack_coolers_cufflinks_broke"] = cufflinks_broke
	result["blackjack_strategy_deviation_events"] = _dictionary_array(cheat.get("strategy_deviation_events", []))
	result["blackjack_strategy_confronted"] = bool(cheat.get("strategy_confronted", false))
	result["blackjack_pit_boss_watched"] = bool(cheat.get("pit_boss_watched", false))
	result["blackjack_pit_boss_heat_bonus"] = int(cheat.get("pit_boss_heat_bonus", 0))
	result["blackjack_running_count"] = int(table.get("running_count", 0))
	result["blackjack_recorded_count"] = int(table.get("recorded_running_count", 0))
	result["blackjack_counter_surveillance"] = _local_copy_dict(cheat.get("counter_surveillance", {}))
	_apply_blackjack_authority_result(run_state, result, rng)
	return result


func _resolve_rourke_duel_hand(action_id: String, run_state: RunState, environment: Dictionary, ui_state: Dictionary) -> Dictionary:
	if action_id != "play_basic":
		return _empty_result(action_id, 0, environment, "Rourke is waiting for the hand to settle.")
	var table := _table_state(run_state, environment)
	var session := _normalized_session(run_state, environment, ui_state, table)
	var presentation_msec := _blackjack_presentation_time_msec(ui_state, run_state.grand_casino_duel_action_time_msec())
	if not _has_dealt_hand(session):
		return _empty_result(action_id, 0, environment, "Deal a hand before settling Rourke's table.")
	if not _all_hands_complete(session):
		_stand_all_hands(session)
	session["dealer_hole_visible"] = true
	var dealer_cards := _dealer_final_cards(session, table)
	var hands := _hand_array(session.get("player_hands", []))
	var duel := run_state.grand_casino_duel_status()
	var terms := run_state.grand_casino_duel_terms()
	var ante := maxi(1, int(duel.get("ante", 20)))
	var hand_results: Array = []
	var transfer := 0
	for hand_value in hands:
		var settled := _settle_hand(hand_value as Dictionary, dealer_cards, ante)
		hand_results.append(settled)
		transfer += int(settled.get("bankroll_delta", 0))
	if not bool(session.get("count_answered", false)) and not _local_copy_dict(session.get("count_challenge", {})).is_empty():
		var action_msec := run_state.grand_casino_duel_action_time_msec()
		_sync_count_challenge_icons(session, run_state, action_msec)
		_finalize_count_challenge(session, run_state, action_msec)
	var cheats := _local_copy_dict(session.get("cheats_used", {}))
	var used_player_cheat := (
		bool(cheats.get("peek_hole_card", false))
		or bool(cheats.get("count_cards", false))
		or bool(session.get("count_attempted", false))
		or bool(session.get("count_answered", false))
	)
	var caught := false
	var catch_chance := 0
	if used_player_cheat:
		var rules := _local_copy_dict(terms.get("rules", {}))
		catch_chance = clampi(
			int(rules.get("player_cheat_detection_base", 55))
			+ int(terms.get("rourke_aggression", 1)) * int(rules.get("player_cheat_detection_per_aggression", 5))
			+ int(terms.get("rourke_cheat_level", 0)) * int(rules.get("player_cheat_detection_per_cheat_level", 5)),
			2,
			95
		)
		catch_chance = run_state.crew_play_adjust_detection_chance(catch_chance, environment)
		var attempt := maxi(1, int(duel.get("attempt", 1)))
		var hand_index := maxi(0, int(duel.get("hand_index", 0)))
		var detection_rng := run_state.create_rng("grand_casino_duel").fork("attempt:%d:hand:%d:player_cheat_detection" % [attempt, hand_index])
		caught = detection_rng.randi_range(1, 100) <= catch_chance
	var caught_penalty := maxi(0, int(_local_copy_dict(terms.get("rules", {})).get("player_cheat_caught_penalty", 18))) if caught else 0
	var net_transfer := clampi(transfer - caught_penalty, -maxi(0, int(duel.get("player_stack", 0))), maxi(0, int(duel.get("rourke_stack", 0))))
	var short_stack := net_transfer != transfer - caught_penalty
	var outcome_word := "wins" if transfer > 0 else "loses" if transfer < 0 else "pushes"
	var message := "The hand %s %d duel chips." % [outcome_word, absi(transfer)]
	if caught:
		message = "%s Rourke catches the move and takes %d more." % [message, caught_penalty]
	if short_stack:
		outcome_word = "wins" if net_transfer > 0 else "loses" if net_transfer < 0 else "pushes"
		message = "The hand %s %d duel chips in total." % [outcome_word, absi(net_transfer)]
		if caught:
			message += " Rourke catches the move; the available stack limits the total."
	var hand_index_for_rng := maxi(0, int(duel.get("hand_index", 0)))
	var settlement_rng := run_state.create_rng("grand_casino_duel").fork("attempt:%d:hand:%d:settlement" % [maxi(1, int(duel.get("attempt", 1))), hand_index_for_rng])
	var used_cards := _cards_used_for_counting(hands, dealer_cards, [])
	var actual_count_delta := _count_cards_delta(used_cards)
	_update_table_after_hand(table, session, dealer_cards, actual_count_delta, actual_count_delta if bool(session.get("count_answered", false)) else 0, settlement_rng, presentation_msec)
	table["last_result"] = _blackjack_last_result_payload(FunctionOptions.BlackjackResultOptions.from({
		"message": message, "hand_results": hand_results, "side_results": [], "main_delta": net_transfer if short_stack else transfer,
		"side_delta": 0, "bankroll_delta": net_transfer, "suspicion_delta": 0,
		"dealer_cards": dealer_cards, "player_hands": hands, "patron_hands": [],
		"patron_action_events": [], "cheat": {"caught": caught}, "result_msec": presentation_msec,
		"round_net_delta_value": net_transfer,
	}))
	_update_environment_table(environment, table)
	var applied := run_state.apply_grand_casino_duel_hand({
		"transfer": transfer,
		"caught_penalty": caught_penalty,
		"player_cheat_used": used_player_cheat,
		"player_cheat_caught": caught,
		"catch_chance": catch_chance,
		"hand_results": hand_results,
		"dealer_total": int(_hand_total_info(dealer_cards).get("total", 0)),
		"message": message,
	})
	var next_duel := _local_copy_dict(applied.get("state", run_state.grand_casino_duel_status()))
	var result_deltas := GameModule.empty_result_deltas()
	result_deltas["ended"] = run_state.is_terminal()
	result_deltas["messages"] = [message]
	var result := GameModule.build_action_result({
		"ok": bool(applied.get("ok", false)),
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": "cheat" if used_player_cheat else "legal",
		"stake": ante,
		"bankroll_delta": 0,
		"suspicion_delta": 0,
		"deltas": result_deltas,
		"won": transfer - caught_penalty > 0,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
		"message": message,
		"ended": run_state.is_terminal(),
	})
	result["blackjack_boss_duel"] = true
	result["blackjack_player_hands"] = hands
	result["blackjack_dealer"] = dealer_cards
	result["blackjack_hand_results"] = hand_results
	result["blackjack_cheat_caught"] = caught
	result["grand_casino_duel_status"] = next_duel
	result["grand_casino_duel_outcome"] = str(next_duel.get("outcome", ""))
	result["preserve_surface_ui_state"] = false
	if run_state.is_terminal():
		result["state"] = GameModule.RESULT_ENDED
	return result


func wager_cost_for_context(action_id: String, stake: int, run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> int:
	return 0


func _blackjack_wager_cost_proposal(action_id: String, stake: int, run_snapshot: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	var candidate := RunState.new()
	candidate.from_dict(run_snapshot)
	var cost := _blackjack_wager_cost_candidate(action_id, stake, candidate, ui_state)
	return {
		"cost": cost,
		"input_fingerprint": RuntimeScript.canonical_fingerprint({"action_id": action_id, "stake": stake, "run_snapshot": run_snapshot, "ui_state": ui_state}),
	}


func _blackjack_wager_cost_candidate(action_id: String, stake: int, candidate: RunState, ui_state: Dictionary = {}) -> int:
	var environment := candidate.current_environment
	if action_id != "play_basic" and action_id != "blackjack_place_bet":
		return 0
	# Rourke's fixed ante belongs to the duel's internal player/Rourke stacks.
	# Charging the normal cash/chip wager again at hand settlement can reject a
	# completed hand and leave the player trapped behind the SETTLE control.
	if _is_rourke_duel(candidate, environment):
		return 0
	var table: Dictionary = _table_state_preview(candidate, environment)
	if bool(table.get("barred", false)):
		return 0
	var session: Dictionary = _normalized_session(candidate, environment, ui_state, table)
	if bool(session.get("blackjack_sit_out", false)):
		return 0
	var total_wager := _wager_cost_from_session(_session_stake(stake, session), session, table, candidate)
	return maxi(0, total_wager - _session_debited_wager(session))


func _resolve_place_bet(stake: int, run_state: RunState, environment: Dictionary, rng: RngStream, ui_state: Dictionary, read_only_run_state: bool = false) -> Dictionary:
	var result_msec := GameModule.deterministic_time_msec(run_state, ui_state)
	var table: Dictionary = _table_state(run_state, environment, read_only_run_state)
	if bool(table.get("barred", false)):
		return _empty_result("blackjack_place_bet", stake, environment, str(table.get("barred_reason", "The dealer refuses to let you play this blackjack table.")))
	var session: Dictionary = _normalized_session(run_state, environment, ui_state, table)
	var incremental := bool(session.get("incremental_hand_wager", false)) and _has_dealt_hand(session) and _session_debited_wager(session) > 0
	session.erase("incremental_hand_wager")
	if not _has_dealt_hand(session):
		_start_initial_hand(session, table, maxi(1, stake), run_state, result_msec)
	if bool(session.get("blackjack_sit_out", false)):
		session["bankroll_wager_debited"] = true
		session["wager_debited"] = 0
		return _place_bet_result(run_state, environment, rng, session, 0, "You watch this blackjack hand without wagering.", incremental)
	var table_stake := _session_stake(stake, session)
	var total_wager := _wager_cost_from_session(table_stake, session, table, run_state)
	var already_debited := _session_debited_wager(session)
	var debit := maxi(0, total_wager - already_debited)
	if debit <= 0:
		session["bankroll_wager_debited"] = true
		session["wager_debited"] = maxi(already_debited, total_wager)
		return _place_bet_result(run_state, environment, rng, session, 0, "Blackjack wager is already on the felt.", incremental)
	if debit > maxi(0, run_state.wager_balance_for_game(get_id(), environment) if run_state != null else debit):
		return _empty_result("blackjack_place_bet", stake, environment, "You do not have enough bankroll for that table action.")
	session["bankroll_wager_debited"] = true
	session["wager_debited"] = already_debited + debit
	var message := "Blackjack wager placed: $%d on the felt." % int(session.get("wager_debited", debit))
	return _place_bet_result(run_state, environment, rng, session, -debit, message, incremental)


func _place_bet_result(run_state: RunState, environment: Dictionary, rng: RngStream, session: Dictionary, bankroll_delta: int, message: String, incremental: bool = false) -> Dictionary:
	var deltas := GameModule.empty_result_deltas()
	deltas["bankroll_delta"] = bankroll_delta
	deltas["messages"] = [message]
	deltas["story_log"] = [{
		"type": "game_action",
		"game_id": get_id(),
		"action_id": "blackjack_place_bet",
		"action_kind": "legal",
		"stake": int(session.get("locked_stake", session.get("selected_stake", 0))),
		"total_wager": int(session.get("wager_debited", 0)),
		"bankroll_delta": bankroll_delta,
		# Durable display metadata only; monetary instructions remain unchanged.
		"currency": GameModule.presentation_currency_for_game(run_state, get_id(), environment),
		"currency_delta": bankroll_delta,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
	}]
	var result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": "blackjack_place_bet",
		"action_kind": "legal",
		"stake": int(session.get("locked_stake", session.get("selected_stake", 0))),
		"bankroll_delta": bankroll_delta,
		"deltas": deltas,
		"won": false,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
		"message": message,
	})
	result["blackjack_incremental_hand_wager"] = incremental
	result["ui_state"] = _compact_session_for_ui(session.duplicate(true))
	result["preserve_surface_ui_state"] = true
	result["surface_embeds_outcomes"] = true
	result["blackjack_wager_debited"] = int(session.get("wager_debited", 0))
	if run_state != null and run_state.wager_balance_for_game(get_id(), environment) + bankroll_delta <= 0 and _has_dealt_hand(session):
		result["defer_bankroll_zero_failure"] = true
	_apply_blackjack_authority_result(run_state, result, rng)
	return result


func environment_object_state(run_state: RunState, environment: Dictionary) -> Dictionary:
	var table: Dictionary = _table_state_preview(run_state, environment)
	if table.is_empty():
		return {}
	var shoe_remaining: int = _shoe_remaining(table)
	var side_bets: Array = _side_bet_labels(_available_side_bets(table))
	var patrons: Array = _dictionary_array(table.get("patrons", []))
	var barred := bool(table.get("barred", false))
	var heat_text := "barred" if barred else "watched" if run_state != null and run_state.suspicion_level() >= 50 else "open"
	var shoe_label := str(table.get("shoe_label", CardShoeScript.shoe_label(int(table.get("deck_count", 6)))))
	var efficiency := str(table.get("count_efficiency", CardShoeScript.count_efficiency_label(int(table.get("deck_count", 6)))))
	var status_summary := str(table.get("barred_reason", "Blackjack table barred for cheating.")) if barred else "%s: %d cards; %d patrons; count %+d." % [shoe_label.capitalize(), shoe_remaining, patrons.size(), int(table.get("recorded_running_count", 0))]
	var effect_summary := "Blackjack barred. Other games in the room remain available, but staff suspicion is near max." if barred else "Dealer %s. Count efficiency %s. Side bets: %s." % [str(table.get("dealer_name", "Dealer")), efficiency, ", ".join(side_bets) if not side_bets.is_empty() else "none"]
	var badge := "BARRED" if barred else "COUNT %+d" % int(table.get("recorded_running_count", 0))
	return {
		"runtime_state": {
			"hands_played": int(table.get("hands_played", 0)),
			"shoe_remaining": shoe_remaining,
			"deck_count": int(table.get("deck_count", 6)),
			"cut_card_remaining": int(table.get("cut_card_remaining", CardShoeScript.cut_card_remaining(int(table.get("deck_count", 6))))),
			"recorded_running_count": int(table.get("recorded_running_count", 0)),
			"patron_count": patrons.size(),
		},
		"visual_state": {
			"status": heat_text,
			"side_bets": side_bets,
			"shoe_remaining": shoe_remaining,
			"shoe_label": shoe_label,
			"count_efficiency": efficiency,
			"patrons": patrons.size(),
			"dealer": str(table.get("dealer_name", "Dealer")),
		},
		"status_summary": status_summary,
		"effect_summary": effect_summary,
		"state_badge": badge,
	}


func _resolve_cheat_only(action_id: String, run_state: RunState, environment: Dictionary, rng: RngStream, ui_state: Dictionary, read_only_run_state: bool = false) -> Dictionary:
	var table: Dictionary = _table_state(run_state, environment, read_only_run_state)
	if bool(table.get("barred", false)):
		return _empty_result(action_id, 0, environment, str(table.get("barred_reason", "The dealer refuses to let you play this blackjack table.")))
	var session: Dictionary = _normalized_session(run_state, environment, ui_state, table)
	var result_msec := GameModule.deterministic_time_msec(run_state, ui_state)
	if action_id == "peek_hole_card":
		var cheats: Dictionary = _local_copy_dict(session.get("cheats_used", {}))
		cheats["peek_hole_card"] = true
		session["peek_had_window"] = bool(session.get("peek_had_window", false)) or _dealer_peek_window_open(table, session, run_state)
		session["peek_snitch_risk"] = _patron_snitch_risk(table, session)
		session["cheats_used"] = cheats
		if bool(session.get("peek_caught_watching", false)) or not bool(session.get("peek_had_window", false)):
			return _resolve_watched_peek_confrontation(table, session, run_state, environment, rng, result_msec)
	elif action_id == "count_cards":
		if _local_copy_dict(session.get("count_challenge", {})).is_empty():
			_start_count_challenge(session, table, run_state, result_msec)
		if not bool(session.get("count_answered", false)):
			_finalize_count_challenge(session, run_state, result_msec)
		_persist_tutorial_count_lesson_result(table, session, run_state, environment)
		_update_environment_table(environment, table)
	# Locking the player's answer is an input boundary, not an observable casino
	# verdict. Assess it once when the hand settles, alongside the wager and play
	# decisions; doing it here as well used to charge the same count twice.
	var cheat: Dictionary = {
		"suspicion_delta": 0,
		"caught": false,
		"message": "The count is recorded; the hand still has to play out.",
		"used_peek": false,
		"used_count": action_id == "count_cards",
		"counter_surveillance": {},
	} if action_id == "count_cards" else _cheat_detection_for_hand(session, table, run_state, environment, rng, _session_stake(maxi(1, int(ui_state.get("selected_stake", 1))), session))
	var cufflinks_broke := _coolers_cufflinks_absorbed_failed_peek(action_id, cheat, run_state)
	var raw_suspicion_delta: int = maxi(1, int(cheat.get("suspicion_delta", 0))) if action_id == "peek_hole_card" else maxi(0, int(cheat.get("suspicion_delta", 0)))
	if cufflinks_broke:
		raw_suspicion_delta = 0
	var pit_boss_status := run_state.pit_boss_watch_status(environment) if run_state != null else {}
	var pit_boss_watched := bool(cheat.get("pit_boss_watched", pit_boss_status.get("watched", false)))
	var pit_boss_heat_bonus := int(cheat.get("pit_boss_heat_bonus", pit_boss_status.get("cheat_heat_bonus", 0)))
	var suspicion_delta: int = run_state.alcohol_adjusted_suspicion_delta(raw_suspicion_delta) if raw_suspicion_delta > 0 else raw_suspicion_delta
	suspicion_delta = run_state.blackjack_suspicion_delta_before_backoff(suspicion_delta) if suspicion_delta > 0 else suspicion_delta
	var security_pressure: Dictionary = run_state.security_action_pressure("cheat", maxi(1, int(ui_state.get("selected_stake", 1))), run_state.suspicion_level() + suspicion_delta) if suspicion_delta > 0 else {}
	var bankroll_delta := int(security_pressure.get("bankroll_delta", 0))
	var security_message := str(security_pressure.get("message", ""))
	var message := str(cheat.get("message", "The dealer narrows their eyes."))
	if cufflinks_broke:
		message = "%s Cooler's Cufflinks take the heat, then snap." % message
	if not security_message.is_empty():
		message = "%s %s" % [message, security_message]
	var deltas := GameModule.empty_result_deltas()
	deltas["bankroll_delta"] = bankroll_delta
	deltas["suspicion_delta"] = suspicion_delta
	if cufflinks_broke:
		deltas["inventory_remove"] = [COOLERS_CUFFLINKS_ITEM_ID]
		deltas["inventory_add"] = [BROKEN_CUFFLINKS_ITEM_ID]
	deltas["messages"] = [message]
	deltas["story_log"] = [{
		"type": "game_action",
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": "cheat",
		"bankroll_delta": bankroll_delta,
		# Durable display metadata only; monetary instructions remain unchanged.
		"currency": GameModule.presentation_currency_for_game(run_state, get_id(), environment),
		"currency_delta": bankroll_delta,
		"suspicion_delta": suspicion_delta,
		"base_suspicion_delta": raw_suspicion_delta,
		"dealer_caught_cheat": bool(cheat.get("caught", false)),
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
		"pit_boss_watched": pit_boss_watched,
		"pit_boss_heat_bonus": pit_boss_heat_bonus,
		"coolers_cufflinks_broke": cufflinks_broke,
		"security_message": security_message,
	}]
	deltas["ended"] = bool(security_pressure.get("ended", false))
	var result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": "cheat",
		"stake": 0,
		"bankroll_delta": bankroll_delta,
		"suspicion_delta": suspicion_delta,
		"deltas": deltas,
		"won": false,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
		"message": message,
		"pit_boss_watched": pit_boss_watched,
		"pit_boss_heat_bonus": pit_boss_heat_bonus,
		"base_suspicion_delta": raw_suspicion_delta,
	})
	if action_id == "count_cards":
		result["blackjack_count_answered"] = bool(session.get("count_answered", false))
		result["blackjack_count_delta"] = int(session.get("count_delta", 0))
		result["preserve_surface_ui_state"] = true
		result["blackjack_surface_ui_state"] = session.duplicate(true)
	elif action_id == "peek_hole_card":
		result["preserve_surface_ui_state"] = true
		result["blackjack_surface_ui_state"] = session.duplicate(true)
	result["blackjack_pit_boss_watched"] = pit_boss_watched
	result["blackjack_pit_boss_heat_bonus"] = pit_boss_heat_bonus
	result["blackjack_coolers_cufflinks_broke"] = cufflinks_broke
	_apply_blackjack_authority_result(run_state, result, rng)
	return result


func _resolve_watched_peek_confrontation(table: Dictionary, session: Dictionary, run_state: RunState, environment: Dictionary, rng: RngStream, result_msec: int = 0) -> Dictionary:
	var table_stake := _session_stake(maxi(1, int(session.get("selected_stake", session.get("locked_stake", 1)))), session)
	var tutorial_practice_protected := run_state != null \
		and run_state.blackjack_tutorial_peek_reprieve_eligible("peek_hole_card", environment)
	var first_tutorial_warning := tutorial_practice_protected \
		and not bool(run_state.narrative_flags.get("tutorial_blackjack_peek_reprieve_used", false))
	# Every caught Peek before the real counting lesson is complete keeps the
	# practice hand playable. The dealer's authored warning is still spoken once,
	# but a resumed or repeated Peek can no longer fall through to the old barred
	# table / skipped Count path.
	var confiscated_bet := 0 if tutorial_practice_protected else maxi(1, _wager_cost_from_session(table_stake, session, table, run_state))
	var current_heat := run_state.suspicion_level_for_environment_id(str(environment.get("id", ""))) if run_state != null else 0
	var raw_heat := rng.randi_range(60, 80) if rng != null else 70
	var desired_applied_heat := maxi(0, mini(raw_heat, RunState.BLACKJACK_BACKOFF_HEAT - current_heat))
	var heat_delta := _base_suspicion_for_applied_cap(desired_applied_heat, run_state)
	var applied_heat_preview := run_state.alcohol_adjusted_suspicion_delta(heat_delta) if run_state != null else heat_delta
	var pit_boss_status := run_state.pit_boss_watch_status(environment) if run_state != null else {}
	var pit_boss_watched := bool(pit_boss_status.get("watched", false))
	var pit_boss_heat_bonus := int(pit_boss_status.get("cheat_heat_bonus", 0)) if bool(pit_boss_status.get("active", false)) else 0
	var dealer_name := str(table.get("dealer_name", "The dealer"))
	var message := "%s catches the peek cold, sweeps your bet, and tells you the blackjack table is closed to you for cheating." % dealer_name
	if tutorial_practice_protected:
		message = "%s catches the bad peek, but leaves this practice hand and the table open so you can finish learning." % dealer_name
	var pit_boss_summary := str(pit_boss_status.get("summary", "")) if bool(pit_boss_status.get("active", false)) else ""
	if not pit_boss_summary.is_empty():
		message = "%s %s" % [message, pit_boss_summary]
	var cufflinks_broke := run_state != null and run_state.inventory.has(COOLERS_CUFFLINKS_ITEM_ID)
	if cufflinks_broke:
		heat_delta = 0
		applied_heat_preview = 0
		message = "%s Cooler's Cufflinks catch the heat, then snap into useless metal." % message
	table["barred"] = not tutorial_practice_protected
	if tutorial_practice_protected:
		table.erase("barred_reason")
		table.erase("barred_at_hand")
		table.erase("barred_confiscated_bet")
		table.erase("barred_scope")
		table.erase("barred_heat_delta")
		if first_tutorial_warning:
			run_state.narrative_flags["tutorial_blackjack_peek_reprieve_used"] = true
	else:
		table["barred_reason"] = "%s will not deal to you again after the caught hole-card peek." % dealer_name
		table["barred_at_hand"] = int(table.get("hands_played", 0))
		table["barred_confiscated_bet"] = confiscated_bet
		table["barred_scope"] = "blackjack_table"
		table["barred_heat_delta"] = applied_heat_preview
	table["last_patron_action_events"] = []
	table["last_result"] = {
		"headline": "REPRIEVED" if tutorial_practice_protected else "BARRED",
		"summary": message,
		"bankroll_delta": -confiscated_bet,
		"suspicion_delta": applied_heat_preview,
		"dealer_cards": _card_array(session.get("dealer_cards", [])),
		"player_hands": _hand_array(session.get("player_hands", [])),
		"hand_results": [],
		"side_bet_results": [],
		"caught": true,
		"watched_peek": true,
		"confiscated_bet": confiscated_bet,
		"resolved_at_msec": result_msec,
	}
	_update_environment_table(environment, table)
	var story_entry := {
		"type": "game_action",
		"game_id": get_id(),
		"action_id": "peek_hole_card",
		"stake": table_stake,
		"total_wager": confiscated_bet,
		"bankroll_delta": -confiscated_bet,
		# Durable display metadata only; monetary instructions remain unchanged.
		"currency": GameModule.presentation_currency_for_game(run_state, get_id(), environment),
		"currency_delta": -confiscated_bet,
		"suspicion_delta": applied_heat_preview,
		"base_suspicion_delta": heat_delta,
		"dealer_caught_cheat": true,
		"blackjack_table_barred": not tutorial_practice_protected,
		"blackjack_tutorial_peek_reprieve": tutorial_practice_protected,
		"coolers_cufflinks_broke": cufflinks_broke,
		"pit_boss_watched": pit_boss_watched,
		"pit_boss_heat_bonus": pit_boss_heat_bonus,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
	}
	var deltas := GameModule.empty_result_deltas()
	deltas["bankroll_delta"] = -confiscated_bet
	deltas["suspicion_delta"] = heat_delta
	if cufflinks_broke:
		deltas["inventory_remove"] = [COOLERS_CUFFLINKS_ITEM_ID]
		deltas["inventory_add"] = [BROKEN_CUFFLINKS_ITEM_ID]
	deltas["story_log"] = [story_entry]
	deltas["messages"] = [message]
	var result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": "peek_hole_card",
		"action_kind": "cheat",
		"stake": table_stake,
		"bankroll_delta": -confiscated_bet,
		"suspicion_delta": heat_delta,
		"deltas": deltas,
		"won": false,
		"environment_id": environment.get("id", ""),
		"environment_archetype_id": environment.get("archetype_id", ""),
		"message": message,
		"pit_boss_watched": pit_boss_watched,
		"pit_boss_heat_bonus": pit_boss_heat_bonus,
		"base_suspicion_delta": heat_delta,
	})
	result["blackjack_table_barred"] = not tutorial_practice_protected
	result["blackjack_tutorial_peek_reprieve"] = tutorial_practice_protected
	result["blackjack_dealer_name"] = dealer_name
	if first_tutorial_warning:
		result["tutorial_dialogue_request"] = {
			"dialogue_id": "tutorial_blackjack_dealer_reprieve",
			"node_id": "warning",
			"queue_key": "tutorial_intervention:peek_reprieve",
			"source_kind": "tutorial_intervention",
			"speaker": dealer_name,
		}
	result["blackjack_watched_peek"] = true
	result["blackjack_confiscated_bet"] = confiscated_bet
	result["blackjack_coolers_cufflinks_broke"] = cufflinks_broke
	result["blackjack_pit_boss_watched"] = pit_boss_watched
	result["blackjack_pit_boss_heat_bonus"] = pit_boss_heat_bonus
	result["dealer_caught_cheat"] = true
	result["defer_bankroll_zero_failure"] = true
	if tutorial_practice_protected:
		result["preserve_surface_ui_state"] = true
		result["blackjack_surface_ui_state"] = session.duplicate(true)
	_apply_blackjack_authority_result(run_state, result, rng)
	return result


func _apply_blackjack_authority_result(run_state: RunState, result: Dictionary, rng: RngStream) -> void:
	# FoundationMain applies the result to its detached candidate only after it
	# has validated the complete proposal and staged an exact one-use receipt.
	result["blackjack_proposal_requires_apply"] = true


func _base_suspicion_for_applied_cap(desired_applied_heat: int, run_state: RunState) -> int:
	desired_applied_heat = maxi(0, desired_applied_heat)
	if run_state == null or desired_applied_heat <= 0:
		return desired_applied_heat
	for candidate in range(desired_applied_heat, -1, -1):
		if run_state.alcohol_adjusted_suspicion_delta(candidate) <= desired_applied_heat:
			return candidate
	return 0


func _draw_blackjack_room(surface, surface_state: Dictionary) -> void:
	var clock := TableVisualsScript._surface_clock(surface)
	var low_detail := TableVisualsScript._surface_low_detail_idle(surface)
	var board_size: Vector2 = surface.surface_board_size()
	surface.draw_rect(Rect2(Vector2.ZERO, board_size), Color("#05060a"))
	surface.draw_rect(Rect2(0, 0, board_size.x, 82), Color("#101427"))
	surface.draw_rect(Rect2(0, 82, board_size.x, BJ_CONSOLE_Y - 82.0), Color("#070810"))
	surface.draw_rect(Rect2(0, BJ_CONSOLE_Y, board_size.x, maxf(0.0, board_size.y - BJ_CONSOLE_Y)), Color("#07070d"))
	surface.draw_rect(Rect2(0, 78, board_size.x, 3), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.62))
	surface.draw_rect(Rect2(0, BJ_CONSOLE_Y - 3.0, board_size.x, 3), Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.42))
	if not low_detail:
		TableVisualsScript._draw_surface_light_cone(surface, Vector2(176, 78), Vector2(190, 238), C_CYAN, 0.065)
		TableVisualsScript._draw_surface_light_cone(surface, Vector2(724, 78), Vector2(188, 238), C_PINK, 0.070)
		TableVisualsScript._draw_surface_scan_bands(surface, 0, int(board_size.x), 0, 146, C_CYAN, 0.040, 1.6)
		TableVisualsScript._draw_neon_panel(surface, Rect2(24, 14, 286, 58), C_CYAN, 0.16 + absf(sin(clock * 2.1)) * 0.04)
		TableVisualsScript._draw_neon_panel(surface, Rect2(332, 18, 236, 48), C_PINK, 0.12 + absf(sin(clock * 1.7)) * 0.04)
		TableVisualsScript._draw_security_mirror(surface, Rect2(606, 16, 68, 50), C_PINK)
		TableVisualsScript._draw_watch_camera_surface(surface, Vector2(584, 42), C_PINK)
	else:
		surface.draw_rect(Rect2(24, 14, 286, 58), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.12), false, 1)
		surface.draw_rect(Rect2(332, 18, 236, 48), Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.10), false, 1)
	surface.surface_title(str(surface_state.get("table_name", "Blackjack")).to_upper().left(18), Vector2(36, 42), C_CYAN)
	var rules_text := str(surface_state.get("table_rules_text", ""))
	if rules_text.is_empty():
		rules_text = _table_rules_text(surface_state)
	surface.surface_label(rules_text.left(42), Vector2(42, 62), 10, C_SOFT)
	surface.surface_label(_blackjack_shoe_status_text(surface_state), Vector2(344, 48), 12, C_SOFT)


func _blackjack_shoe_status_text(surface_state: Dictionary) -> String:
	var shoe_status := "shoe %d" % int(surface_state.get("shoe_remaining", 0))
	if bool(surface_state.get("between_hands_count_visible", false)):
		shoe_status += "   YOUR COUNT %+d" % int(surface_state.get("between_hands_recorded_running_count", 0))
	elif bool(surface_state.get("counting_enabled", false)):
		# Preserve the live-hand player count that this HUD already showed. The
		# between-hands branch above deliberately switches to the persisted count.
		shoe_status += "   YOUR COUNT %+d" % int(surface_state.get("recorded_running_count", 0))
	return shoe_status


func _draw_blackjack_table(surface, surface_state: Dictionary) -> void:
	var clock := TableVisualsScript._surface_clock(surface)
	var low_detail := TableVisualsScript._surface_low_detail_idle(surface)
	surface.draw_polygon(BJ_RAIL_POINTS, BJ_RAIL_COLORS)
	surface.draw_polygon(BJ_OUTER_FELT_POINTS, BJ_OUTER_FELT_COLORS)
	surface.draw_polygon(BJ_FELT_POINTS, BJ_FELT_COLORS)
	surface.draw_polygon(BJ_CENTER_FELT_POINTS, BJ_CENTER_FELT_COLORS)
	surface.draw_rect(Rect2(116, 316, 672, 5), Color(C_YELLOW.r, C_YELLOW.g, C_YELLOW.b, 0.30))
	if not low_detail:
		for i in range(7):
			var y := 134 + i * 20
			surface.draw_line(Vector2(144 + i * 5, y), Vector2(756 - i * 5, y + 3), Color(C_TEAL.r, C_TEAL.g, C_TEAL.b, 0.035), 1)
		surface.draw_rect(Rect2(140, 308, 620, 2), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.16 + absf(sin(clock * 2.4)) * 0.08))
	else:
		surface.draw_rect(Rect2(140, 308, 620, 2), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.14))
	_draw_betting_arc(surface, Vector2(450, 306), 374, C_YELLOW)
	_draw_seat_marker(surface, _player_hand_base_position(0), "H1", bool(surface_state.get("active_hand_index", 0) == 0))
	_draw_seat_marker(surface, _player_hand_base_position(1), "H2", bool(surface_state.get("active_hand_index", 0) == 1))
	_draw_seat_marker(surface, _player_hand_base_position(2), "H3", bool(surface_state.get("active_hand_index", 0) == 2))
	_draw_seat_marker(surface, _player_hand_base_position(3), "H4", bool(surface_state.get("active_hand_index", 0) == 3))
	surface.surface_label_centered("BLACKJACK PAYS 3 TO 2", Rect2(332, 148, 236, 18), 13, Color(C_YELLOW.r, C_YELLOW.g, C_YELLOW.b, 0.72))
	surface.surface_label_centered("INSURANCE PAYS 2:1", Rect2(348, 172, 204, 16), 10, Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.52))
	surface.surface_label_centered("NO MID-HAND MERCY", Rect2(356, 196, 190, 14), 9, Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.42))


func _draw_dealer_station(surface, surface_state: Dictionary) -> void:
	# Cadence may change between hand phases; the cast's identity and articulated
	# expressions always use the same painter, including during decisions.
	var focus: Dictionary = _dealer_focus_for_surface_state(surface, surface_state)
	var profile: Dictionary = surface_state.get("dealer_profile", {}) if typeof(surface_state.get("dealer_profile", {})) == TYPE_DICTIONARY else {}
	var looking_away := bool(focus.get("lookaway_active", false))
	var peek_window := bool(focus.get("peek_window_open", looking_away))
	var blink := bool(focus.get("blink", false))
	var eye_offset := float(focus.get("eye_offset", 0.0))
	var idle := TableVisualsScript._surface_clock(surface) + float(int(profile.get("blink_offset", 0))) / 1000.0
	var attention_color := C_PINK if int(focus.get("peek_danger", 0)) >= 70 else C_YELLOW if int(focus.get("peek_danger", 0)) >= 42 else C_TEAL
	surface.draw_rect(Rect2(352, 54, 196, 104), Color("#0b0d16"))
	surface.draw_rect(Rect2(352, 54, 196, 104), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.18), false, 1)
	TableVisualsScript._draw_dealer_gaze(surface, focus, Vector2(450, 91))
	draw_dealer_character_style.clear()
	draw_dealer_character_style["name"] = str(surface_state.get("dealer_name", "Dealer"))
	draw_dealer_character_style["skin"] = Color("#d8b18a")
	draw_dealer_character_style["hair"] = Color("#2a1a25")
	draw_dealer_character_style["jacket"] = Color("#1b2230")
	draw_dealer_character_style["accent"] = attention_color
	draw_dealer_character_style["role"] = "dealer"
	var dealer_pose := "lookaway" if peek_window else "watching"
	if _blackjack_between_hand_cast_active(surface_state) and not peek_window:
		var dealer_motion := _blackjack_between_hand_character_motion(idle, float(int(profile.get("blink_offset", 0))) / 3700.0)
		dealer_pose = ["counter_tap", "card_check", "wrist_check"][int(dealer_motion.get("gesture_index", 0))]
		draw_dealer_character_style["body_bob"] = float(dealer_motion.get("body_bob", 0.0))
		draw_dealer_character_style["head_x"] = float(dealer_motion.get("head_x", 0.0))
		draw_dealer_character_style["head_y"] = float(dealer_motion.get("head_y", 0.0))
		draw_dealer_character_style["gesture_amount"] = float(dealer_motion.get("gesture_amount", 0.0))
		draw_dealer_character_style["gesture_side"] = int(dealer_motion.get("gesture_side", 0))
	draw_dealer_character_style["pose"] = dealer_pose
	draw_dealer_character_style["eye_offset"] = eye_offset
	draw_dealer_character_style["blink"] = blink
	draw_dealer_character_style["holding_card"] = surface.surface_animation_active(DEAL_ANIMATION_CHANNEL)
	draw_dealer_character_style["uniform_accent"] = str(profile.get("uniform_accent", ""))
	_draw_table_character(surface, draw_dealer_character_style, Vector2(450, 156), 1.06, idle)
	var meter := clampi(int(focus.get("attention_meter", 0)), 0, 100)
	TableVisualsScript._draw_status_meter(surface, Rect2(566, 92, 118, 9), meter, "dealer %s" % str(focus.get("status", "watching")), C_PINK if meter >= 70 else C_YELLOW if meter >= 42 else C_TEAL)
	TableVisualsScript._draw_status_meter(surface, Rect2(566, 116, 118, 6), int(focus.get("peek_danger", 0)), str(focus.get("gaze_phase", "read")).left(20), attention_color)
	if peek_window:
		TableVisualsScript._draw_neon_panel(surface, Rect2(566, 130, 122, 22), C_TEAL, 0.28)
		var peek_label: String = "PEEK %.1fs" % (float(int(focus.get("lookaway_remaining_msec", 0))) / 1000.0) if looking_away else "PEEK WINDOW"
		surface.surface_label_centered(peek_label, Rect2(570, 134, 114, 14), 11, C_TEAL)
	else:
		surface.surface_label(str(focus.get("body_language", focus.get("tell", ""))).left(26), Vector2(566, 142), 9, C_SOFT)
	_draw_card_row_for_table(surface, surface_state, _draw_array_view(surface_state.get("dealer", [])), Vector2(386, 158), "dealer", 0, DEALER_CARD_SCALE)
	_draw_shoe(surface, Vector2(706, 112), int(surface_state.get("shoe_remaining", 0)))


func _draw_table_patrons(surface, surface_state: Dictionary) -> void:
	var patrons: Array = surface_state.get("patrons", []) if typeof(surface_state.get("patrons", [])) == TYPE_ARRAY else []
	var clock := TableVisualsScript._surface_clock(surface)
	for i in range(patrons.size()):
		if typeof(patrons[i]) != TYPE_DICTIONARY:
			continue
		var patron: Dictionary = patrons[i]
		var base_pos := _patron_seat_position(i)
		var patron_clock := clock + float(int(patron.get("animation_offset", 0))) / 1000.0
		var phase := fmod(patron_clock / 2.2, 1.0)
		var bob := sin(phase * PI * 2.0) * (2.0 if bool(patron.get("watching_player", false)) else 1.0)
		var lean := float(patron.get("lean", 0.0))
		var pos := base_pos + Vector2(lean, bob)
		var watching := bool(patron.get("watching_player", false))
		var covered := bool(patron.get("covered", false))
		var risk := int(patron.get("active_snitch_risk", 0))
		var threshold := int(patron.get("snitch_threshold", 30))
		var tell_active := watching and (risk >= threshold or (phase > 0.58 and phase < 0.82))
		var accent := C_PINK if watching else C_TEAL if covered else C_SOFT
		var patron_motion := _blackjack_between_hand_character_motion(patron_clock, float(i) * 0.37)
		draw_patron_character_style.clear()
		draw_patron_character_style["name"] = str(patron.get("name", "Seat"))
		draw_patron_character_style["skin"] = Color("#c49371")
		draw_patron_character_style["hair"] = TableVisualsScript._patron_hair_color(patron)
		draw_patron_character_style["jacket"] = TableVisualsScript._patron_jacket_color(patron)
		draw_patron_character_style["accent"] = accent
		draw_patron_character_style["role"] = "patron"
		var patron_pose := "covered" if covered else "snitch" if tell_active else "idle"
		if _blackjack_between_hand_cast_active(surface_state) and not covered and not tell_active:
			patron_pose = ["chin_touch", "adjust_cuff", "rub_hands"][int(patron_motion.get("gesture_index", 0))]
			draw_patron_character_style["body_bob"] = float(patron_motion.get("body_bob", 0.0))
			draw_patron_character_style["head_x"] = float(patron_motion.get("head_x", 0.0))
			draw_patron_character_style["head_y"] = float(patron_motion.get("head_y", 0.0))
			draw_patron_character_style["gesture_amount"] = float(patron_motion.get("gesture_amount", 0.0))
			draw_patron_character_style["gesture_side"] = int(patron_motion.get("gesture_side", 0))
		draw_patron_character_style["pose"] = patron_pose
		draw_patron_character_style["eye_offset"] = -2.0 if covered else 2.0 if watching else 0.0
		draw_patron_character_style["blink"] = phase > 0.92
		draw_patron_character_style["holding_card"] = false
		draw_patron_character_style["silhouette"] = str(patron.get("silhouette", "coat"))
		_draw_table_character(surface, draw_patron_character_style, pos + Vector2(0, 52), 0.86, patron_clock)
		if tell_active:
			TableVisualsScript._draw_neon_panel(surface, Rect2(pos.x - 36, pos.y - 46, 72, 20), accent, 0.22)
			surface.surface_label(str(patron.get("tell", "watching")).left(11), pos + Vector2(-30, -32), 8, accent)
			surface.draw_line(pos + Vector2(0, -24), Vector2(450, 284), Color(accent.r, accent.g, accent.b, 0.18), 1.0)
		var risk_width := clampf(float(risk) / 60.0, 0.0, 1.0) * 46.0
		surface.draw_rect(Rect2(pos.x - 28, pos.y + 61, 56, 5), Color("#070810"))
		surface.draw_rect(Rect2(pos.x - 28, pos.y + 61, risk_width, 5), accent)
		surface.surface_label(str(patron.get("behavior", ("%d" % risk) if watching else "busy" if covered else str(patron.get("mood", "")).left(7))).left(12), pos + Vector2(-30, 78), 9, accent)
		var patron_chip_count := clampi(int(patron.get("chip_stack", 0)) / 20, 1, 4)
		for chip_index in range(patron_chip_count):
			_draw_casino_chip(surface, pos + Vector2(30, 42 - float(chip_index) * 3.0 * 0.42), 5, 11.0 * 0.42, 0.92, false)
		TableVisualsScript.draw_patron_wager_badge(surface, surface_state, patron, pos, i)
		_draw_patron_hand(surface, surface_state, patron, i)
		surface.surface_label("cover", pos + Vector2(-18, 92), 8, Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.62))
		surface.surface_add_invisible_hit(Rect2(pos.x - 34, pos.y - 24, 68, 94), "blackjack_patron_cover", i)


func _blackjack_between_hand_cast_active(surface_state: Dictionary) -> bool:
	return bool(surface_state.get("between_hands", false)) or str(surface_state.get("phase", "")) == "betting"


func _blackjack_between_hand_character_motion(clock: float, phase_offset: float = 0.0) -> Dictionary:
	# Each gesture returns to its resting pose before the next one is selected, so
	# the low-cadence cast moves continuously without popping between arm poses.
	var gesture_clock := maxf(0.0, clock) / 2.8 + phase_offset
	var gesture_phase := fposmod(gesture_clock, 1.0)
	var breath_clock := maxf(0.0, clock) * 2.15 + phase_offset * TAU
	return {
		"body_bob": sin(breath_clock) * 1.35,
		"head_x": sin(breath_clock * 0.47) * 0.8,
		"head_y": sin(breath_clock + 0.72) * 0.9,
		"gesture_amount": sin(gesture_phase * PI),
		"gesture_index": posmod(int(floor(gesture_clock)), 3),
		"gesture_side": -1 if posmod(int(floor(gesture_clock)), 2) == 0 else 1,
	}


func surface_motion_signature(surface, surface_state: Dictionary) -> Dictionary:
	var clock := TableVisualsScript._surface_clock(surface)
	var dealer_motion := _blackjack_between_hand_character_motion(clock)
	var patron_signatures: Array = []
	var patrons: Array = surface_state.get("patrons", []) if typeof(surface_state.get("patrons", [])) == TYPE_ARRAY else []
	for patron_index in range(patrons.size()):
		if typeof(patrons[patron_index]) != TYPE_DICTIONARY:
			continue
		var patron: Dictionary = patrons[patron_index]
		var patron_clock := clock + float(int(patron.get("animation_offset", 0))) / 1000.0
		var motion := _blackjack_between_hand_character_motion(patron_clock, float(patron_index) * 0.37)
		patron_signatures.append([
			int(round(float(motion.get("body_bob", 0.0)) * 1000.0)),
			int(round(float(motion.get("head_x", 0.0)) * 1000.0)),
			int(round(float(motion.get("gesture_amount", 0.0)) * 1000.0)),
		])
	return {
		"between_hand_cast_active": _blackjack_between_hand_cast_active(surface_state),
		"dealer_motion": [
			int(round(float(dealer_motion.get("body_bob", 0.0)) * 1000.0)),
			int(round(float(dealer_motion.get("head_x", 0.0)) * 1000.0)),
			int(round(float(dealer_motion.get("gesture_amount", 0.0)) * 1000.0)),
		],
		"patron_motion": patron_signatures,
	}


func _draw_patron_hand(surface, surface_state: Dictionary, patron: Dictionary, patron_index: int) -> void:
	var patron_cards: Array = _draw_array_view(patron.get("cards", []))
	if patron_cards.is_empty():
		return
	var action_event := _patron_active_action_event(surface, surface_state, patron_index)
	var card_start := _patron_hand_base_position(patron_index)
	if TableVisualsScript._surface_low_detail_idle(surface):
		_draw_compact_patron_card_row(surface, surface_state, patron_cards, card_start, patron_index)
	else:
		_draw_card_row_for_table(surface, surface_state, patron_cards, card_start, "patron", patron_index, PATRON_CARD_SCALE)
	var total := _hand_total(patron_cards)
	var total_color := C_ORANGE if total > 21 else C_YELLOW if total == 21 else C_SOFT
	surface.surface_label("%d" % total, card_start + Vector2(62, 29), 8, total_color)
	_draw_patron_move_badge(surface, card_start + Vector2(-3, -23), patron, action_event)


func _surface_low_detail_idle(surface) -> bool:
	return TableVisualsScript._surface_low_detail_idle(surface)


func _draw_compact_patron_card_row(surface, surface_state: Dictionary, cards: Array, start: Vector2, patron_index: int) -> void:
	var spacing := 54.0 * PATRON_CARD_SCALE
	for card_index in range(cards.size()):
		if _card_waiting_for_deal_animation(surface, surface_state, "patron", patron_index, card_index):
			continue
		_draw_compact_patron_card(surface, cards[card_index], start + Vector2(float(card_index) * spacing, 0), PATRON_CARD_SCALE)


func _draw_compact_patron_card(surface, card_value: Variant, pos: Vector2, scale_value: float) -> void:
	var card: Dictionary = card_value if typeof(card_value) == TYPE_DICTIONARY else {}
	var rect := Rect2(pos, Vector2(42, 60) * scale_value)
	if bool(card.get("hidden", false)):
		PlayingCardRendererScript.draw_card_back(surface, rect)
		return
	# Background hands need a readable rank and suit, but creating a general-purpose
	# text control for every tiny card dominates Web canvas time. This 3x5 pixel
	# rank retains the information entirely through draw primitives.
	surface.draw_rect(rect, Color("#ddd6c8"))
	surface.draw_rect(Rect2(rect.position + Vector2(1, 1), rect.size - Vector2(2, 2)), Color("#fffaf0"))
	surface.draw_rect(rect, Color("#251b2a"), false, 1.0)
	var rank := clampi(int(card.get("rank", 2)), 2, 14)
	var suit := int(card.get("suit", 0))
	var ink := C_PINK if suit == 1 or suit == 3 else C_DARK
	var pattern: Array = COMPACT_CARD_RANK_PATTERNS.get(rank, COMPACT_CARD_RANK_PATTERNS[2])
	var pixel := 2.0 if rect.size.y >= 24.0 else 1.0
	var rank_origin := rect.position + Vector2(3, 3)
	for row_index in range(pattern.size()):
		var row := str(pattern[row_index])
		for column_index in range(mini(3, row.length())):
			if row.substr(column_index, 1) == "1":
				surface.draw_rect(Rect2(rank_origin + Vector2(column_index, row_index) * pixel, Vector2(pixel, pixel)), ink)
	PlayingCardRendererScript.draw_suit(surface, rect.position + Vector2(rect.size.x * 0.66, rect.size.y * 0.69), suit, ink, maxf(0.20, scale_value * 0.52))


func _patron_active_action_event(surface, surface_state: Dictionary, patron_index: int) -> Dictionary:
	if not surface.surface_animation_active(DEAL_ANIMATION_CHANNEL):
		return {}
	var elapsed_msec := float(surface.surface_elapsed(DEAL_ANIMATION_CHANNEL)) * 1000.0
	for event_value in _patron_action_event_array(surface_state.get("patron_action_events", [])):
		var event: Dictionary = event_value
		if int(event.get("patron_index", -1)) != patron_index:
			continue
		var start := float(event.get("delay_msec", 0))
		var duration := float(event.get("duration_msec", PATRON_DECISION_HIGHLIGHT_MSEC))
		if elapsed_msec >= start and elapsed_msec <= start + duration:
			var progress := clampf((elapsed_msec - start) / maxf(1.0, duration), 0.0, 1.0)
			event["progress"] = progress
			return event
	return {}


func _draw_patron_move_badge(surface, pos: Vector2, patron: Dictionary, active_event: Dictionary) -> void:
	var label := str(active_event.get("label", patron.get("hand_action_label", "")))
	if label.is_empty():
		return
	var reason := str(active_event.get("reason", patron.get("hand_action_reason", "")))
	var action := str(active_event.get("action", patron.get("hand_action", "")))
	var peek_informed := bool(active_event.get("peek_informed", patron.get("hand_peek_informed", false)))
	var active := not active_event.is_empty()
	var accent := C_YELLOW if peek_informed else C_TEAL if action == "hit" else C_CYAN
	var pulse := 0.26 + absf(sin(TableVisualsScript._surface_clock(surface) * 5.2)) * 0.12 if active else 0.10
	var rect_width := 76.0 if peek_informed else 58.0
	var rect := Rect2(pos, Vector2(rect_width, 18))
	TableVisualsScript._draw_neon_panel(surface, rect, accent, pulse)
	surface.surface_label(label.left(10), rect.position + Vector2(6, 12), 8, accent)
	if active and not reason.is_empty():
		surface.surface_label(reason.left(17), rect.position + Vector2(4, -4), 7, C_SOFT)


func _draw_player_station(surface, surface_state: Dictionary, include_betting_chrome: bool = true) -> void:
	var hands: Array = _draw_array_view(surface_state.get("player_hands", []))
	var result: Dictionary = _draw_dict_view(surface_state.get("last_result", {}))
	var showdown_hands: Array = _draw_array_view(result.get("player_hands", []))
	var display_hands: Array = hands if not hands.is_empty() else showdown_hands
	var showing_showdown := hands.is_empty() and not showdown_hands.is_empty()
	var active_index: int = int(surface_state.get("active_hand_index", 0))
	_draw_player_forearms(surface, surface_state)
	var result_hands: Array = _draw_array_view(result.get("hand_results", []))
	for i in range(display_hands.size()):
		var hand: Dictionary = display_hands[i]
		var pos: Vector2 = _player_hand_base_position(i)
		var active := i == active_index and not showing_showdown
		var cards: Array = _draw_array_view(hand.get("cards", []))
		var cards_revealed := _hand_cards_revealed_for_deal(surface, surface_state, "player", i, cards)
		_draw_card_row_for_table(surface, surface_state, cards, pos, "player", i, PLAYER_CARD_SCALE)
		var hand_label := "H%d" % [i + 1]
		if cards_revealed:
			hand_label = "H%d %s" % [i + 1, _hand_label(hand)]
		surface.surface_label(hand_label, pos + Vector2(-4, -8), 10, C_TEAL if active else C_SOFT)
		if cards_revealed:
			_draw_hand_state_badge(surface, pos + Vector2(6, -30), hand, active)
		if i < result_hands.size() and not _settlement_reveal_waiting(surface, surface_state):
			_draw_hand_result_badge(surface, pos + Vector2(6, 54), result_hands[i])
	if showing_showdown:
		surface.surface_label_centered("SHOWDOWN HELD ON FELT", Rect2(342, 226, 216, 16), 10, C_YELLOW)
	if include_betting_chrome and display_hands.is_empty():
		TableVisualsScript._draw_neon_panel(surface, Rect2(346, 236, 208, 36), C_CYAN, 0.12)
		var hint := "Minimum $%d" % int(surface_state.get("minimum_wager", 1)) if bool(surface_state.get("wager_blocked", false)) else "slide chips, then deal"
		surface.surface_label_centered(hint, Rect2(358, 246, 184, 16), 13, C_SOFT)
	if include_betting_chrome:
		_draw_player_wager_chips(surface, surface_state)
		_draw_side_bet_felt(surface, surface_state)


func _draw_player_wager_chips(surface, surface_state: Dictionary) -> void:
	var center := Vector2(452, 310)
	var stack: Array = surface_state.get("chip_stack", []) if typeof(surface_state.get("chip_stack", [])) == TYPE_ARRAY else []
	if bool(surface_state.get("wager_blocked", false)): stack = []
	_draw_chip_stack(surface, center, stack, 0.58)
	surface.draw_rect(Rect2(center - Vector2(24, 20), Vector2(48, 46)), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.72), false, 1)
	surface.surface_label_centered("YOU", Rect2(center + Vector2(-18, 22), Vector2(36, 10)), 7, C_CYAN)


func _draw_hand_state_badge(surface, pos: Vector2, hand: Dictionary, active: bool) -> void:
	var cards: Array = _draw_array_view(hand.get("cards", []))
	if cards.is_empty():
		return
	var total := _hand_total(cards)
	var text := ""
	var accent := C_SOFT
	if bool(hand.get("surrendered", false)):
		text = "SURRENDER"
		accent = C_ORANGE
	elif total > 21:
		text = "BUST"
		accent = C_ORANGE
	elif total == 21:
		text = "21 LOCKED"
		accent = C_YELLOW
	elif bool(hand.get("stood", false)):
		text = "STAND"
		accent = C_CYAN
	elif active:
		text = "LIVE"
		accent = C_TEAL
	if text.is_empty():
		return
	surface.surface_label(text, pos + Vector2(2, 10), 8, accent)


func _draw_blackjack_table_notice(surface, surface_state: Dictionary) -> void:
	var notice := str(surface_state.get("table_notice", ""))
	# The final summary also contains dealer totals and settlement amounts.
	# Keep this secondary copy behind the result board's existing reveal gate.
	if _settlement_reveal_waiting(surface, surface_state):
		notice = "Cards still moving; settlement follows."
	elif not str(surface_state.get("deal_animation_id", "")).is_empty() \
			and not _deal_animation_event_array(surface_state.get("deal_animation_events", [])).is_empty() \
			and surface.surface_animation_active(DEAL_ANIMATION_CHANNEL):
		notice = "Let the cards finish moving before choosing the next play."
	if notice.is_empty():
		notice = str(surface_state.get("active_hand_status", ""))
	if notice.is_empty():
		return
	var rect := Rect2(238, 314, 424, 26)
	var accent := C_ORANGE if notice.to_lower().find("bust") >= 0 else C_YELLOW if notice.to_lower().find("blackjack") >= 0 else C_TEAL
	TableVisualsScript._draw_neon_panel(surface, rect, accent, 0.18)
	surface.surface_label_centered(notice.left(78), Rect2(rect.position + Vector2(8, 5), rect.size - Vector2(16, 8)), 11, accent)


func _draw_blackjack_round_timer(surface, surface_state: Dictionary) -> void:
	TableVisualsScript.draw_round_timer_panel(surface, surface_state.get("table_round_timer", {}), Rect2(668, 294, 112, 30), C_CYAN)


func _draw_blackjack_ambient_event(surface, surface_state: Dictionary) -> void:
	var event: Dictionary = _ambient_table_event_for_surface(surface, surface_state)
	if event.is_empty():
		return
	var accent := C_CYAN
	match str(event.get("accent", "cyan")):
		"pink":
			accent = C_PINK
		"yellow":
			accent = C_YELLOW
		"teal":
			accent = C_TEAL
		"orange":
			accent = C_ORANGE
	var rect := Rect2(28, 88, 190, 26)
	TableVisualsScript._draw_neon_panel(surface, rect, accent, 0.12 + float(event.get("intensity", 0.0)) * 0.10)
	surface.surface_label(str(event.get("label", "table motion")).to_upper().left(18), rect.position + Vector2(8, 12), 8, accent)
	surface.surface_label(str(event.get("detail", "")).left(24), rect.position + Vector2(8, 23), 7, C_SOFT)


func _draw_player_forearms(surface, surface_state: Dictionary) -> void:
	var clock := TableVisualsScript._surface_clock(surface)
	var active_index := int(surface_state.get("active_hand_index", 0))
	var left_hand := _player_hand_base_position(active_index) + Vector2(-32, 48)
	var right_hand := _player_hand_base_position(active_index) + Vector2(96, 50)
	var sleeve_y: float = surface.surface_board_size().y - 4.0
	var sleeve := Color("#171022")
	var skin := Color("#c49371")
	var tremor := sin(clock * 4.0) * 2.0
	surface.draw_line(Vector2(270, sleeve_y), left_hand + Vector2(tremor, 0), sleeve, 14.0)
	surface.draw_line(Vector2(630, sleeve_y), right_hand + Vector2(-tremor, 0), sleeve, 14.0)
	surface.draw_line(Vector2(270, sleeve_y), left_hand + Vector2(tremor, 0), Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.32), 3.0)
	surface.draw_line(Vector2(630, sleeve_y), right_hand + Vector2(-tremor, 0), Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.28), 3.0)
	surface.draw_rect(Rect2(left_hand + Vector2(-7 + tremor, -4), Vector2(14, 10)), skin)
	surface.draw_rect(Rect2(right_hand + Vector2(-7 - tremor, -4), Vector2(14, 10)), skin)


func _draw_hand_result_badge(surface, pos: Vector2, result: Dictionary) -> void:
	var outcome := str(result.get("outcome", "push")).replace("_", " ")
	var delta := int(result.get("bankroll_delta", 0))
	var accent := C_TEAL if delta > 0 else C_ORANGE if delta < 0 else C_YELLOW
	var rect := Rect2(pos, Vector2(72, 20))
	TableVisualsScript._draw_neon_panel(surface, rect, accent, 0.16)
	surface.surface_label(outcome.left(10), rect.position + Vector2(6, 12), 8, accent)
	surface.surface_label("%+d" % delta, rect.position + Vector2(44, 12), 8, accent)


func _draw_side_bet_felt(surface, surface_state: Dictionary) -> void:
	var side_bets: Array = _draw_array_view(surface_state.get("side_bets_available", []))
	var active: Array = _draw_array_view(surface_state.get("side_bets_active", []))
	var stakes: Dictionary = _draw_dict_view(surface_state.get("side_bet_stakes", {}))
	var panel := Rect2(272, BJ_CONSOLE_Y + 8.0, 302, BJ_CONSOLE_H - 16.0)
	TableVisualsScript._draw_neon_panel(surface, panel, C_PINK_2, 0.08)
	surface.surface_label("SIDE BETS", panel.position + Vector2(10, 15), 10, C_SOFT)
	if side_bets.is_empty():
		surface.surface_label_centered("none on this table", Rect2(panel.position + Vector2(12, 32), Vector2(panel.size.x - 24, 18)), 11, Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.58))
		return
	for i in range(mini(side_bets.size(), BLACKJACK_MAX_SIDE_BETS)):
		var bet: Dictionary = side_bets[i]
		var col := i % 2
		var row := int(i / 2)
		var rect := Rect2(panel.position.x + 12.0 + float(col) * 146.0, panel.position.y + 24.0 + float(row) * 30.0, 134, 24)
		var bet_id := str(bet.get("id", ""))
		var selected := active.has(bet_id)
		var enabled := bool(bet.get("surface_enabled", bool(surface_state.get("can_change_side_bets", false))))
		var accent := C_YELLOW if selected else C_SOFT
		surface.draw_rect(rect, Color(accent.r, accent.g, accent.b, 0.15 if selected else 0.06))
		surface.draw_rect(rect, accent if enabled else Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.24), false, 1)
		surface.surface_label(str(bet.get("label", bet_id)).left(14), rect.position + Vector2(6, 15), 9, accent)
		surface.surface_label("$%d" % int(stakes.get(bet_id, 1)), rect.position + Vector2(104, 15), 9, accent)
		if enabled:
			surface.surface_add_hit(rect, "blackjack_side_bet", i)


func _draw_side_bet_rule_overlay(surface, surface_state: Dictionary) -> void:
	var side_bets: Array = _draw_array_view(surface_state.get("side_bets_available", []))
	if side_bets.is_empty():
		return
	var target_index := -1
	for i in range(mini(side_bets.size(), BLACKJACK_MAX_SIDE_BETS)):
		if bool(surface.surface_region_hovered("blackjack_side_bet", i)):
			target_index = i
			break
	if target_index < 0 or target_index >= side_bets.size():
		return
	var target: Dictionary = side_bets[target_index]
	var bet_id := str(target.get("id", ""))
	var active: Array = _draw_array_view(surface_state.get("side_bets_active", []))
	var selected := active.has(bet_id)
	var accent := C_YELLOW if selected else C_PINK_2
	var rect := Rect2(236, 202, 428, 108)
	TableVisualsScript._draw_neon_panel(surface, rect, accent, 0.24)
	surface.draw_rect(rect.grow(1), Color(0.0, 0.0, 0.0, 0.22), false, 1)
	surface.surface_label("SIDE BET RULES", rect.position + Vector2(12, 15), 9, C_SOFT)
	surface.surface_label(str(target.get("label", bet_id)).to_upper().left(28), rect.position + Vector2(12, 31), 14, accent)
	surface.surface_label(str(target.get("summary", "")).left(54), rect.position + Vector2(12, 47), 8, C_SOFT)
	var rules: Array = _draw_array_view(target.get("rules", _side_bet_definition(bet_id).get("rules", [])))
	var payouts: Array = _draw_array_view(target.get("payouts", _side_bet_definition(bet_id).get("payouts", [])))
	var y := rect.position.y + 64.0
	for i in range(mini(rules.size(), 2)):
		surface.surface_label("- %s" % str(rules[i]).left(58), Vector2(rect.position.x + 14.0, y), 8, C_WHITE)
		y += 12.0
	var payout_text := ", ".join(payouts).left(72)
	if not payout_text.is_empty():
		surface.surface_label("PAYS: %s" % payout_text, Vector2(rect.position.x + 14.0, rect.position.y + rect.size.y - 10.0), 8, C_YELLOW)


func _draw_chip_rack(surface, surface_state: Dictionary) -> void:
	var rack := Rect2(18, BJ_CONSOLE_Y + 8.0, 242, BJ_CONSOLE_H - 16.0)
	surface.draw_rect(rack, Color("#120b14"))
	surface.draw_rect(rack, Color(C_YELLOW.r, C_YELLOW.g, C_YELLOW.b, 0.28), false, 1)
	surface.surface_label("CHIP RAIL", rack.position + Vector2(12, 15), 10, C_SOFT)
	var wager_blocked := bool(surface_state.get("wager_blocked", false))
	var wager_label := "MIN $%d" % int(surface_state.get("minimum_wager", 1)) if wager_blocked else "BET $%d" % int(surface_state.get("selected_stake", 1))
	surface.surface_label(wager_label, rack.position + Vector2(112, 15), 12, C_YELLOW)
	var chips: Array = surface_state.get("chip_denominations", []) if typeof(surface_state.get("chip_denominations", [])) == TYPE_ARRAY else []
	var chip_origin := rack.position + Vector2(22.0, 34.0)
	var chip_spacing := 22.0
	for i in range(chips.size()):
		var chip_center := chip_origin + Vector2(float(i) * chip_spacing, 0.0)
		_draw_chip_button(surface, chip_center, int(chips[i]), BLACKJACK_WAGER_PLACE_GESTURE, i, not wager_blocked)
		var remove_rect := Rect2(chip_center.x - 7, chip_center.y + 10, 14, 10)
		_draw_table_button(surface, remove_rect, "", "blackjack_remove_chip", i, C_SOFT, true)
		surface.draw_line(remove_rect.position + Vector2(3, 5), remove_rect.end - Vector2(3, 5), C_SOFT, 1.0)
	_draw_table_button(surface, Rect2(rack.position.x + 154, rack.position.y + 25, 40, 16), "CLR", "blackjack_clear_bet", 0, C_SOFT, true)
	_draw_table_button(surface, Rect2(rack.position.x + 200, rack.position.y + 25, 36, 16), "MAX", "blackjack_max_bet", 0, C_YELLOW, not wager_blocked)
	_draw_table_button(surface, Rect2(rack.position.x + 154, rack.position.y + 47, 26, 16), "UNDO", "blackjack_undo_bet", 0, C_CYAN, true)
	_draw_table_button(surface, Rect2(rack.position.x + 184, rack.position.y + 47, 26, 16), "RPT", "blackjack_repeat_bet", 0, C_CYAN, true)
	_draw_table_button(surface, Rect2(rack.position.x + 214, rack.position.y + 47, 22, 16), "RE", "blackjack_rebet", 0, C_TEAL, true)


func _draw_table_actions(surface, surface_state: Dictionary) -> void:
	var panel := Rect2(586, BJ_CONSOLE_Y + 8.0, 292, BJ_CONSOLE_H - 16.0)
	# The legal-action snapshot can outlive a presentation frame. Match the
	# canvas's live deal-animation input block when drawing lit hit regions.
	var deal_actions_ready: bool = not surface.surface_animation_active(DEAL_ANIMATION_CHANNEL)
	TableVisualsScript._draw_neon_panel(surface, panel, C_CYAN, 0.10)
	if bool(surface_state.get("boss_duel_active", false)):
		_draw_rourke_duel_actions(surface, surface_state, panel)
		return
	surface.surface_label("HAND ACTIONS", panel.position + Vector2(10, 15), 10, C_SOFT)
	if bool(surface_state.get("table_barred", false)):
		surface.surface_label("TABLE CLOSED", panel.position + Vector2(14, 42), 16, C_PINK)
		surface.surface_label(str(surface_state.get("barred_reason", "Dealer refuses action.")).left(38), panel.position + Vector2(14, 62), 8, C_SOFT)
		return
	var snitch := int(surface_state.get("snitch_pressure", 0))
	surface.surface_label("Snitch %d" % snitch, panel.position + Vector2(210, 15), 9, C_PINK if snitch > 0 else C_SOFT)
	var counting_enabled := bool(surface_state.get("counting_enabled", false))
	_draw_table_button(surface, Rect2(panel.position.x + 112, panel.position.y + 7, 88, 16), "COUNT ON" if counting_enabled else "COUNT OFF", "blackjack_count_toggle", 0, C_PINK_2 if counting_enabled else C_SOFT, true, counting_enabled)
	if bool(surface_state.get("can_deal", false)) or bool(surface_state.get("wager_blocked", false)):
		_draw_table_button(surface, Rect2(panel.position.x + 14, panel.position.y + 28, 132, 38), "DEAL", "blackjack_deal", 0, C_YELLOW, deal_actions_ready and bool(surface_state.get("can_deal", false)), surface.surface_native_action_selected("blackjack_deal"))
		if bool(surface_state.get("wager_blocked", false)):
			surface.surface_label("MIN $%d" % int(surface_state.get("minimum_wager", 1)), panel.position + Vector2(154, 40), 9, C_ORANGE)
			if not _settlement_reveal_waiting(surface, surface_state) and not surface.surface_animation_active(PAYOUT_ANIMATION_CHANNEL):
				surface.surface_label("HAVE $%d" % maxi(0, int(surface_state.get("stake_ceiling", 0))), panel.position + Vector2(154, 54), 8, C_SOFT)
	else:
		surface.surface_add_invisible_hit(Rect2(panel.position.x + 14, panel.position.y + 7, 84, 16), "blackjack_deal", 0)
		_draw_table_button(surface, Rect2(panel.position.x + 12, panel.position.y + 24, 84, 26), "HIT", "blackjack_hit", 0, C_TEAL, deal_actions_ready and bool(surface_state.get("can_hit", false)))
		var stand_rect := Rect2(panel.position.x + 104, panel.position.y + 24, 84, 26)
		_draw_table_button(surface, stand_rect, "STAND", "blackjack_stand", 0, C_CYAN, deal_actions_ready and bool(surface_state.get("can_stand", false)), surface.surface_native_action_selected("blackjack_stand"))
		_draw_table_button(surface, Rect2(panel.position.x + 196, panel.position.y + 24, 72, 26), "DOUBLE", "blackjack_double", 0, C_YELLOW, deal_actions_ready and bool(surface_state.get("can_double", false)))
		_draw_table_button(surface, Rect2(panel.position.x + 12, panel.position.y + 54, 84, 22), "SPLIT", "blackjack_split", 0, C_AMBER, deal_actions_ready and bool(surface_state.get("can_split", false)))
		var focus := _dealer_focus_for_surface_state(surface, surface_state)
		var peek_available := bool(surface_state.get("peek_available", false))
		var peek_dangerous := peek_available and not bool(focus.get("peek_window_open", false)) and not bool(surface_state.get("dealer_hole_visible", false))
		_draw_table_button(surface, Rect2(panel.position.x + 104, panel.position.y + 54, 84, 22), "PEEK", "blackjack_peek", 0, C_PINK if peek_dangerous else C_TEAL, peek_available, surface.surface_native_action_selected("blackjack_peek"))
		if bool(surface_state.get("settle_available", false)):
			_draw_table_button(surface, Rect2(panel.position.x + 196, panel.position.y + 54, 72, 22), "SETTLE", BLACKJACK_SETTLE_ACTION, 0, C_YELLOW, deal_actions_ready, surface.surface_native_action_selected(BLACKJACK_SETTLE_ACTION))
		elif bool(surface_state.get("can_surrender", false)):
			_draw_table_button(surface, Rect2(panel.position.x + 196, panel.position.y + 54, 72, 22), "SURRENDER", "blackjack_surrender", 0, C_ORANGE, deal_actions_ready and bool(surface_state.get("can_surrender", false)))
	var distractions: Array = _draw_array_view(surface_state.get("distractions", []))
	var strip := Rect2(692, 294, 168, 34)
	TableVisualsScript._draw_neon_panel(surface, strip, C_TEAL, 0.08)
	surface.surface_label("LOOKAWAY", strip.position + Vector2(8, 14), 8, C_SOFT)
	for i in range(mini(distractions.size(), 3)):
		var distraction: Dictionary = distractions[i]
		var label := str(distraction.get("label", "Distract")).replace(" ", "").to_upper().left(5)
		_draw_table_button(surface, Rect2(strip.position.x + 64 + i * 34, strip.position.y + 8, 30, 18), label, "blackjack_distraction", i, C_TEAL, true)


func _draw_rourke_duel_hud(surface, surface_state: Dictionary) -> void:
	var hud := Rect2(18, 12, 860, 62)
	TableVisualsScript._draw_neon_panel(surface, hud, C_YELLOW, 0.12)
	var projection := _draw_dict_view(surface_state.get("showdown_duel_projection", {}))
	if projection.is_empty():
		surface.surface_label("ROURKE'S TABLE", hud.position + Vector2(14, 18), 13, C_YELLOW)
		surface.surface_label("HAND %d / %d" % [int(surface_state.get("boss_hand_number", 1)), int(surface_state.get("boss_hand_limit", 5))], hud.position + Vector2(14, 40), 10, C_SOFT)
		surface.surface_label("YOU  %d" % int(surface_state.get("boss_player_stack", 0)), hud.position + Vector2(178, 29), 18, C_CYAN)
		surface.surface_label("ROURKE  %d" % int(surface_state.get("boss_rourke_stack", 0)), hud.position + Vector2(326, 29), 18, C_PINK)
		surface.surface_label(str(surface_state.get("boss_bark", "Rourke waits.")).left(42), hud.position + Vector2(510, 22), 10, C_WHITE)
		surface.surface_label(str(surface_state.get("boss_tell", "")).left(48), hud.position + Vector2(510, 42), 9, C_SOFT)
		return
	var actor := _draw_dict_view(projection.get("rourke_actor", {}))
	var room := _draw_dict_view(projection.get("room_state", {}))
	var phase_id := str(projection.get("phase_id", "commitment"))
	var actor_state := str(actor.get("behavior_state", "arrival"))
	surface.surface_label("ROURKE'S TABLE", hud.position + Vector2(14, 18), 13, C_YELLOW)
	surface.surface_label("%s  HAND %d/%d" % [phase_id.replace("_", " ").to_upper().left(12), int(surface_state.get("boss_hand_number", 1)), int(surface_state.get("boss_hand_limit", 5))], hud.position + Vector2(14, 40), 9, C_SOFT)
	surface.surface_label("YOU  %d" % int(surface_state.get("boss_player_stack", 0)), hud.position + Vector2(178, 29), 18, C_CYAN)
	surface.surface_label("ROURKE  %d" % int(surface_state.get("boss_rourke_stack", 0)), hud.position + Vector2(326, 29), 18, C_PINK)
	surface.surface_label(str(surface_state.get("boss_bark", "Rourke waits.")).left(34), hud.position + Vector2(510, 20), 9, C_WHITE)
	surface.surface_label("%s / %s / SECURITY %s" % [actor_state.replace("_", " ").to_upper(), str(room.get("crowd_state", "full")).replace("_", " ").to_upper(), str(room.get("security_state", "low")).to_upper()], hud.position + Vector2(510, 38), 8, C_YELLOW)
	surface.surface_label(str(surface_state.get("boss_tell", "")).left(42), hud.position + Vector2(510, 53), 8, C_SOFT)


func _draw_showdown_duel_room_staging(surface, surface_state: Dictionary) -> void:
	var projection := _draw_dict_view(surface_state.get("showdown_duel_projection", {}))
	if projection.is_empty(): return
	var clock := TableVisualsScript._surface_clock(surface)
	var room := _draw_dict_view(projection.get("room_state", {}))
	var crowd_state := str(room.get("crowd_state", "full"))
	var crowd_count := 8 if crowd_state == "full" else 5 if crowd_state == "thinning" else 7 if crowd_state in ["celebrating", "hostile"] else 0
	var crowd_color := C_ORANGE if crowd_state == "hostile" else C_YELLOW if crowd_state == "celebrating" else C_SOFT
	for index in range(crowd_count):
		var crowd_phase := clock * (1.55 + float(index % 3) * 0.12) + float(index) * 0.83
		var x := 76.0 + float(index) * 106.0 + sin(crowd_phase * 0.53) * 1.5
		var y := 104.0 + (8.0 if index % 2 == 0 else 0.0) + sin(crowd_phase) * 2.0
		surface.draw_circle(Vector2(x, y), 5.0, Color(crowd_color.r, crowd_color.g, crowd_color.b, 0.42))
		surface.draw_rect(Rect2(x - 4.0, y + 5.0, 8.0, 13.0), Color(crowd_color.r, crowd_color.g, crowd_color.b, 0.25))
	var security_state := str(room.get("security_state", "low"))
	var security_count := 2 if security_state == "high" else 1 if security_state == "present" else 0
	for index in range(security_count):
		var guard_phase := clock * 1.32 + float(index) * 1.9
		var guard_x := 688.0 + float(index) * 46.0 + sin(guard_phase * 0.41) * 1.2
		var guard_y := 88.0 + sin(guard_phase) * 1.4
		surface.draw_rect(Rect2(guard_x, guard_y, 18, 34), Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.28))
		surface.draw_circle(Vector2(guard_x + 9.0, guard_y - 5.0), 7.0, Color(C_PINK.r, C_PINK.g, C_PINK.b, 0.42))
	if crowd_count > 0:
		surface.surface_label(crowd_state.replace("_", " ").to_upper(), Vector2(36, 112), 8, crowd_color)


func _draw_rourke_duel_actions(surface, surface_state: Dictionary, panel: Rect2) -> void:
	var deal_actions_ready: bool = not surface.surface_animation_active(DEAL_ANIMATION_CHANNEL)
	surface.surface_label("DUEL ACTIONS", panel.position + Vector2(10, 15), 10, C_SOFT)
	var counting_enabled := bool(surface_state.get("counting_enabled", false))
	_draw_table_button(surface, Rect2(panel.position.x + 184, panel.position.y + 6, 92, 18), "COUNT ON" if counting_enabled else "COUNT OFF", "blackjack_count_toggle", 0, C_PINK_2 if counting_enabled else C_SOFT, true, counting_enabled)
	if bool(surface_state.get("can_deal", false)):
		_draw_table_button(surface, Rect2(panel.position.x + 12, panel.position.y + 28, 116, 38), "DEAL", "blackjack_deal", 0, C_YELLOW, deal_actions_ready)
	else:
		_draw_table_button(surface, Rect2(panel.position.x + 8, panel.position.y + 28, 62, 24), "HIT", "blackjack_hit", 0, C_TEAL, deal_actions_ready and bool(surface_state.get("can_hit", false)))
		_draw_table_button(surface, Rect2(panel.position.x + 74, panel.position.y + 28, 62, 24), "STAND", "blackjack_stand", 0, C_CYAN, deal_actions_ready and bool(surface_state.get("can_stand", false)))
		_draw_table_button(surface, Rect2(panel.position.x + 140, panel.position.y + 28, 62, 24), "DOUBLE", "blackjack_double", 0, C_YELLOW, deal_actions_ready and bool(surface_state.get("can_double", false)))
		_draw_table_button(surface, Rect2(panel.position.x + 206, panel.position.y + 28, 70, 24), "PEEK", "blackjack_peek", 0, C_PINK, bool(surface_state.get("peek_available", false)))
		if bool(surface_state.get("settle_available", false)):
			_draw_table_button(surface, Rect2(panel.position.x + 206, panel.position.y + 54, 70, 18), "SETTLE", BLACKJACK_SETTLE_ACTION, 0, C_YELLOW, deal_actions_ready)
	var callouts_value: Variant = surface_state.get("boss_callouts", [])
	var callouts: Array = callouts_value as Array if typeof(callouts_value) == TYPE_ARRAY else []
	for i in range(mini(callouts.size(), 2)):
		if typeof(callouts[i]) != TYPE_DICTIONARY:
			continue
		var callout: Dictionary = callouts[i] as Dictionary
		var enabled := not bool(surface_state.get("boss_callout_used", false)) and not bool(surface_state.get("can_deal", false))
		_draw_table_button(surface, Rect2(590 + i * 142, 294, 136, 28), str(callout.get("label", "CALL")).to_upper().left(16), "blackjack_boss_callout", i, C_ORANGE, enabled)


func _draw_basic_strategy_advice(surface, surface_state: Dictionary) -> void:
	var advice: Dictionary = _draw_dict_view(surface_state.get("basic_strategy_advice", {}))
	if not bool(advice.get("visible", false)):
		return
	var rect := Rect2(662, 88, 198, 44)
	var accent := C_YELLOW
	TableVisualsScript._draw_neon_panel(surface, rect, accent, 0.18)
	surface.draw_rect(rect.grow(1.0), Color(accent.r, accent.g, accent.b, 0.34), false, 1)
	surface.draw_circle(rect.position + Vector2(24, 22), 14, Color(accent.r, accent.g, accent.b, 0.24))
	surface.draw_circle(rect.position + Vector2(24, 22), 14, accent, false, 2)
	surface.surface_label_centered("BOOK", Rect2(rect.position + Vector2(7, 16), Vector2(34, 12)), 8, C_WHITE)
	surface.surface_label("BASIC STRATEGY", rect.position + Vector2(48, 14), 8, C_SOFT)
	surface.surface_label(str(advice.get("label", "")).to_upper().left(18), rect.position + Vector2(48, 30), 14, accent)
	var reason := str(advice.get("summary", ""))
	if not reason.is_empty():
		surface.surface_label(reason.left(28), rect.position + Vector2(122, 30), 8, C_SOFT)


func _draw_deal_animation(surface, surface_state: Dictionary) -> void:
	if not surface.surface_animation_active(DEAL_ANIMATION_CHANNEL):
		return
	var events: Array = _surface_deal_animation_events(surface_state)
	if events.is_empty():
		events.append(_deal_animation_event({"rank": 2, "suit": 0, "hidden": true}, "player", 0, 0, DEAL_CARD_SHOE_POS, _player_hand_card_target(0, 0), 0, PLAYER_CARD_SCALE, "card"))
	var elapsed_msec := float(surface.surface_elapsed(DEAL_ANIMATION_CHANNEL)) * 1000.0
	for event_value in events:
		var event: Dictionary = event_value
		var delay := float(event.get("delay_msec", 0))
		var duration := maxf(1.0, float(event.get("duration_msec", DEAL_CARD_DURATION_MSEC)))
		if elapsed_msec < delay or elapsed_msec > delay + duration:
			continue
		var t := clampf((elapsed_msec - delay) / duration, 0.0, 1.0)
		var eased := 1.0 - pow(1.0 - t, 3.0)
		var start := _event_vector(event.get("from", []), DEAL_CARD_SHOE_POS)
		var target := _event_vector(event.get("to", []), Vector2(454, 224))
		var lift := -18.0 * sin(t * PI)
		var wiggle := sin((t * PI * 2.0) + float(event.get("delay_msec", 0)) * 0.01) * 2.0
		var pos := start.lerp(target, eased) + Vector2(wiggle, lift)
		var scale := float(event.get("scale", 0.62))
		surface.draw_rect(Rect2(pos + Vector2(4, 5) * scale, Vector2(42, 60) * scale), Color(0, 0, 0, 0.22))
		if str(event.get("zone", "")) == "patron" and TableVisualsScript._surface_low_detail_idle(surface):
			_draw_compact_patron_card(surface, event.get("card", {}), pos, scale)
		else:
			_draw_card(surface, event.get("card", {}), pos, scale)


func _draw_chip_payout_animation(surface, surface_state: Dictionary) -> void:
	var result: Dictionary = _draw_dict_view(surface_state.get("last_result", {}))
	if result.is_empty():
		return
	if _settlement_reveal_waiting(surface, surface_state):
		return
	if not surface.surface_animation_active(PAYOUT_ANIMATION_CHANNEL):
		return
	var elapsed_msec := float(surface.surface_elapsed(PAYOUT_ANIMATION_CHANNEL)) * 1000.0
	var t := clampf(elapsed_msec / float(PAYOUT_ANIMATION_DURATION_MSEC), 0.0, 1.0)
	var eased := 1.0 - pow(1.0 - t, 3.0)
	var settlement_delta := int(result.get("bankroll_delta", 0))
	var delta := int(result.get("round_net_delta", settlement_delta))
	var main_delta := int(result.get("main_delta", delta))
	var side_delta := int(result.get("side_delta", 0))
	var source := Vector2(622, 116)
	var target := Vector2(206, BJ_CONSOLE_Y + 58.0)
	if delta < 0:
		source = Vector2(450, 306)
		target = Vector2(622, 116)
	elif delta == 0:
		source = Vector2(450, 306)
		target = Vector2(450, 306)
	var chip_values: Array = _chip_denominations({})
	var stack: Array = _chip_stack_for_stake(maxi(1, abs(delta)), chip_values)
	var draw_count := 0
	for entry_value in stack:
		var entry: Dictionary = entry_value
		var value := int(entry.get("value", 1))
		var count := clampi(int(entry.get("count", 1)), 1, 6)
		for i in range(count):
			if draw_count >= 7:
				break
			var delay := float(draw_count) * 110.0
			var local_t := clampf((elapsed_msec - delay) / 820.0, 0.0, 1.0)
			var local_eased := 1.0 - pow(1.0 - local_t, 3.0)
			var arc := -34.0 * sin(local_t * PI)
			var jitter := Vector2(float((draw_count % 3) - 1) * 8.0, float(draw_count % 2) * 5.0)
			var pos := source.lerp(target + jitter, local_eased) + Vector2(0, arc)
			_draw_casino_chip(surface, pos, value, 13.0, clampf(0.18 + local_t, 0.18, 1.0), false)
			draw_count += 1
		if draw_count >= 7:
			break
	var label_rect := Rect2(312, 290, 276, 34)
	var accent := C_TEAL if delta > 0 else C_ORANGE if delta < 0 else C_YELLOW
	TableVisualsScript._draw_neon_panel(surface, label_rect, accent, 0.18 * (1.0 - clampf(t - 0.68, 0.0, 1.0)))
	var wager_currency := _blackjack_surface_currency(surface_state, result)
	var label := "PUSH: %s RETURN" % PlayerTextScript.currency_account_label(wager_currency)
	if delta > 0:
		label = "DEALER PAYS %s" % _blackjack_signed_currency_amount(wager_currency, delta)
	elif delta < 0:
		label = "DEALER COLLECTS %s" % PlayerTextScript.format_currency_amount(wager_currency, abs(delta), true)
	if side_delta != 0:
		label += " / SIDE %s" % _blackjack_signed_currency_amount(wager_currency, side_delta)
	elif main_delta != delta:
		label += " / MAIN %s" % _blackjack_signed_currency_amount(wager_currency, main_delta)
	if settlement_delta != delta:
		label += " / RETURN %s" % _blackjack_signed_currency_amount(wager_currency, settlement_delta)
	surface.surface_label_centered(label.left(42), label_rect.grow(-5), 12, accent)


func _draw_card_row_for_table(surface, surface_state: Dictionary, cards: Array, start: Vector2, zone: String, hand_index: int = 0, scale: float = 1.0) -> void:
	var spacing := 54.0 * scale
	if cards.size() > 1:
		if zone == "player":
			spacing = minf(spacing, 86.0 / float(cards.size() - 1))
		elif zone == "dealer":
			spacing = minf(spacing, 176.0 / float(cards.size() - 1))
	for i in range(cards.size()):
		if _card_waiting_for_deal_animation(surface, surface_state, zone, hand_index, i):
			continue
		_draw_card(surface, cards[i], start + Vector2(float(i) * spacing, 0), scale)


func _hand_cards_revealed_for_deal(surface, surface_state: Dictionary, zone: String, hand_index: int, cards: Array) -> bool:
	for i in range(cards.size()):
		if _card_waiting_for_deal_animation(surface, surface_state, zone, hand_index, i):
			return false
	return true


func _settlement_reveal_waiting(surface, surface_state: Dictionary) -> bool:
	if _draw_dict_view(surface_state.get("last_result", {})).is_empty():
		return false
	if not surface.surface_animation_active(DEAL_ANIMATION_CHANNEL):
		return false
	return not _surface_deal_animation_events(surface_state).is_empty()


func _card_waiting_for_deal_animation(surface, surface_state: Dictionary, zone: String, hand_index: int, card_index: int) -> bool:
	if not surface.surface_animation_active(DEAL_ANIMATION_CHANNEL):
		return false
	var elapsed_msec := float(surface.surface_elapsed(DEAL_ANIMATION_CHANNEL)) * 1000.0
	for event_value in _surface_deal_animation_events(surface_state):
		var event: Dictionary = event_value
		if str(event.get("zone", "")) != zone:
			continue
		if int(event.get("hand_index", -1)) != hand_index:
			continue
		if int(event.get("card_index", -1)) != card_index:
			continue
		var reveal_at := float(event.get("delay_msec", 0)) + float(event.get("duration_msec", DEAL_CARD_DURATION_MSEC)) * 0.92
		return elapsed_msec < reveal_at
	return false


func _dealer_focus_for_surface_state(surface, surface_state: Dictionary) -> Dictionary:
	var runtime: Dictionary = surface_state.get("dealer_focus_runtime", {}) if typeof(surface_state.get("dealer_focus_runtime", {})) == TYPE_DICTIONARY else {}
	if runtime.is_empty():
		return surface_state.get("dealer_focus", {}) if typeof(surface_state.get("dealer_focus", {})) == TYPE_DICTIONARY else {}
	var profile: Dictionary = surface_state.get("dealer_profile", {}) if typeof(surface_state.get("dealer_profile", {})) == TYPE_DICTIONARY else {}
	var base_attention: int = int(profile.get("attention_base", 24))
	var heat: int = int(surface_state.get("suspicion_level", 0))
	var started := int(runtime.get("dealer_lookaway_started_msec", 0))
	var duration := int(runtime.get("dealer_lookaway_duration_msec", 0))
	var now := int(surface.call("surface_simulation_time_msec")) if surface != null and surface.has_method("surface_simulation_time_msec") else int(surface_state.get("surface_time_msec", Time.get_ticks_msec()))
	var active := started > 0 and duration > 0 and now >= started and now <= started + duration
	var remaining := maxi(0, started + duration - now) if active else 0
	var cycle_msec := maxi(900, int(320000 / maxi(45, int(profile.get("gaze_speed", 95)))))
	var phase := float((now + int(profile.get("blink_offset", 0))) % cycle_msec) / float(cycle_msec)
	var sweep := sin(phase * PI * 2.0)
	var scan_attention := int((0.5 + 0.5 * sweep) * 18.0)
	var count_pressure := 0 if not bool(runtime.get("count_active", false)) else int(float(int(runtime.get("count_attention_risk", 0))) / 4.0)
	var strategy_pressure := clampi(int(surface_state.get("strategy_watch_pressure", 0)) + int(runtime.get("strategy_attention_boost", 0)), 0, STRATEGY_DEVIATION_MAX_WATCH)
	var attention := clampi(base_attention + int(float(heat) * 0.35) + scan_attention + count_pressure + strategy_pressure + int(runtime.get("dealer_distraction_noise", 0)), 0, 100)
	if active:
		attention = clampi(attention - 44 - int(runtime.get("dealer_distraction_cover", 0)), 0, 100)
	var blink := phase > 0.94 and phase < 0.985
	var watching_player := not active and phase >= 0.18 and phase <= 0.46
	var focus_snapshot: Dictionary = surface_state.get("dealer_focus", {}) if typeof(surface_state.get("dealer_focus", {})) == TYPE_DICTIONARY else {}
	var peek_window_percent := clampi(int(focus_snapshot.get("peek_window_percent", 100)), 10, 100)
	var window_half_width := 0.08 * (float(peek_window_percent) / 100.0)
	var read_start := 0.62 - window_half_width
	var read_end := 0.62 + window_half_width
	var read_window := active or (attention < 58 and phase > read_start and phase < read_end)
	var peek_danger := clampi(attention + (0 if active else int(abs(sweep) * 16.0)) + int(int(surface_state.get("snitch_pressure", 0)) / 4.0), 0, 100)
	var peek_window_open := active or (read_window and not watching_player and peek_danger <= 62)
	var gaze_phase := "looking away" if active else "blink" if blink else "watching you" if watching_player else "hole card loose" if peek_window_open else "open read" if read_window else str(profile.get("read_style", "slow sweep"))
	var body_language := "shoulder turned" if active else "eyes on your chips" if watching_player else "checks payout tray" if peek_window_open or phase > 0.70 else "tracks the felt"
	return {
		"lookaway_active": active,
		"lookaway_remaining_msec": remaining,
		"attention_meter": attention,
		"status": "looking away" if active else "locked on" if attention >= 70 else "watching",
		"tell": str(profile.get("tell", "watches hands more than faces")),
		"gaze_phase": gaze_phase,
		"body_language": body_language,
		"read_window": read_window,
		"watching_player": watching_player,
		"peek_window_open": peek_window_open,
		"scan_phase": phase,
		"count_pressure": count_pressure,
		"strategy_pressure": strategy_pressure,
		"peek_danger": peek_danger,
		"peek_window_percent": peek_window_percent,
		"eye_offset": -0.65 if active else sweep,
		"blink": blink,
	}


func _ambient_table_event_for_surface(surface, surface_state: Dictionary) -> Dictionary:
	if str(surface_state.get("phase", "")) == "betting":
		return {}
	var now_msec := int(TableVisualsScript._surface_clock(surface) * 1000.0)
	var cycle_msec := 4200
	var phase := float(now_msec % cycle_msec) / float(cycle_msec)
	if phase > 0.42:
		return {}
	var catalog: Array = [
		{"label": "chip shuffle", "detail": "seat stack clicks", "accent": "yellow"},
		{"label": "pit glance", "detail": "security looks over", "accent": "pink"},
		{"label": "shoe tap", "detail": "dealer checks tray", "accent": "teal"},
		{"label": "patron tell", "detail": "someone leans in", "accent": "orange"},
		{"label": "felt chatter", "detail": "table noise rises", "accent": "cyan"},
	]
	var table_key: String = "%s:%d:%d" % [str(surface_state.get("table_name", "blackjack")), int(surface_state.get("hands_played", 0)), int(now_msec / cycle_msec)]
	var event_seed: int = abs(JsonCoerceScript._stable_hash(table_key))
	var index: int = event_seed % catalog.size()
	var event: Dictionary = (catalog[index] as Dictionary).duplicate(true)
	event["phase"] = phase
	event["intensity"] = sin(clampf(phase / 0.42, 0.0, 1.0) * PI)
	return event


func _draw_betting_arc(surface, center: Vector2, width: float, accent: Color) -> void:
	for i in range(9):
		var x := center.x - width * 0.5 + float(i) * width / 8.0
		var y := center.y - absf(float(i) - 4.0) * 3.5
		surface.draw_rect(Rect2(x - 1, y - 1, 2, 2), Color(accent.r, accent.g, accent.b, 0.30))


func _draw_seat_marker(surface, pos: Vector2, label: String, active: bool) -> void:
	var color := C_TEAL if active else Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.32)
	surface.surface_label_centered(label, Rect2(pos + Vector2(-11, -25), Vector2(30, 12)), 8, color)


func _draw_table_character(surface, style: Dictionary, foot: Vector2, scale_value: float, clock: float) -> void:
	var accent: Color = style.get("accent", C_CYAN) if typeof(style.get("accent", C_CYAN)) == TYPE_COLOR else C_CYAN
	var skin: Color = style.get("skin", Color("#c49371")) if typeof(style.get("skin", Color("#c49371"))) == TYPE_COLOR else Color("#c49371")
	var hair: Color = style.get("hair", Color("#171022")) if typeof(style.get("hair", Color("#171022"))) == TYPE_COLOR else Color("#171022")
	var jacket: Color = style.get("jacket", Color("#1d2030")) if typeof(style.get("jacket", Color("#1d2030"))) == TYPE_COLOR else Color("#1d2030")
	var pose := str(style.get("pose", "idle"))
	var sway := sin(clock * 1.8) * 2.0 * scale_value
	var lean := 4.0 * scale_value if pose == "snitch" else -4.0 * scale_value if pose == "covered" or pose == "lookaway" else 0.0
	var pos := foot + Vector2(sway + lean, float(style.get("body_bob", 0.0)) * scale_value)
	var head_shift := Vector2(float(style.get("head_x", 0.0)), float(style.get("head_y", 0.0))) * scale_value
	var head := Rect2(pos + Vector2(-12, -78) * scale_value + head_shift, Vector2(24, 24) * scale_value)
	var body := Rect2(pos + Vector2(-23, -54) * scale_value, Vector2(46, 52) * scale_value)
	surface.draw_rect(Rect2(pos.x - 25 * scale_value, pos.y - 6 * scale_value, 50 * scale_value, 5 * scale_value), Color(0, 0, 0, 0.34))
	surface.draw_rect(body, Color("#05060a"))
	surface.draw_rect(Rect2(body.position + Vector2(4, 5) * scale_value, body.size - Vector2(8, 9) * scale_value), jacket)
	surface.draw_rect(Rect2(pos + Vector2(-18, -56) * scale_value, Vector2(36, 6) * scale_value), accent)
	var gesture_amount := clampf(float(style.get("gesture_amount", 1.0)), 0.0, 1.0)
	var gesture_side := int(style.get("gesture_side", 0))
	TableVisualsScript._draw_character_arm(surface, pos, scale_value, accent, pose, true, skin, gesture_amount, gesture_side)
	TableVisualsScript._draw_character_arm(surface, pos, scale_value, accent, pose, false, skin, gesture_amount, gesture_side)
	surface.draw_rect(head, skin)
	surface.draw_rect(Rect2(head.position, Vector2(head.size.x, 8 * scale_value)), hair)
	TableVisualsScript._draw_character_face(surface, head, scale_value, float(style.get("eye_offset", 0.0)), bool(style.get("blink", false)), pose)
	if str(style.get("silhouette", "")) == "cap":
		surface.draw_rect(Rect2(head.position + Vector2(-3, -3) * scale_value, Vector2(head.size.x + 8 * scale_value, 5 * scale_value)), hair)
	elif str(style.get("silhouette", "")) == "glasses":
		surface.draw_rect(Rect2(head.position + Vector2(4, 10) * scale_value, Vector2(6, 4) * scale_value), Color("#05060a"), false, 1)
		surface.draw_rect(Rect2(head.position + Vector2(14, 10) * scale_value, Vector2(6, 4) * scale_value), Color("#05060a"), false, 1)
	elif str(style.get("silhouette", "")) == "rings":
		surface.draw_rect(Rect2(pos + Vector2(-30, -22) * scale_value, Vector2(6, 4) * scale_value), C_YELLOW)
	if bool(style.get("holding_card", false)):
		_draw_card(surface, {"rank": 2, "suit": 0, "hidden": true}, pos + Vector2(-34, -35) * scale_value, 0.28 * scale_value)
	var name := str(style.get("name", ""))
	if not name.is_empty():
		surface.surface_label(name.left(10), pos + Vector2(-26, 10) * scale_value, int(10 * scale_value), accent)


func _draw_blackjack_result_board(surface, surface_state: Dictionary) -> void:
	var result: Dictionary = _draw_dict_view(surface_state.get("last_result", {}))
	var rect := Rect2(18, 12, 232, 74)
	if result.is_empty():
		TableVisualsScript._draw_neon_panel(surface, rect, C_CYAN, 0.10)
		surface.surface_label("TABLE READ", rect.position + Vector2(10, 18), 12, C_CYAN)
		surface.surface_label("eyes + snitches", rect.position + Vector2(10, 36), 9, C_SOFT)
		return
	if _settlement_reveal_waiting(surface, surface_state):
		TableVisualsScript._draw_neon_panel(surface, rect, C_YELLOW, 0.16)
		surface.surface_label("DEALER REVEAL", rect.position + Vector2(10, 18), 12, C_YELLOW)
		surface.surface_label("cards still moving", rect.position + Vector2(10, 38), 9, C_SOFT)
		surface.surface_label("settlement follows", rect.position + Vector2(10, 58), 8, C_SOFT)
		return
	var delta := int(result.get("round_net_delta", result.get("bankroll_delta", 0)))
	var heat := int(result.get("suspicion_delta", 0))
	var accent := C_TEAL if delta > 0 else C_ORANGE if delta < 0 else C_YELLOW
	if bool(result.get("caught", false)):
		accent = C_PINK
	TableVisualsScript._draw_neon_panel(surface, rect, accent, 0.22)
	surface.surface_label(str(result.get("headline", "RESULT")).left(18), rect.position + Vector2(10, 18), 12, accent)
	var wager_currency := _blackjack_surface_currency(surface_state, result)
	surface.surface_label(_blackjack_signed_currency_amount(wager_currency, delta), rect.position + Vector2(10, 38), 12, C_TEAL if delta >= 0 else C_ORANGE)
	surface.surface_label("heat %+d" % heat, rect.position + Vector2(128, 38), 9, C_PINK if heat > 0 else C_SOFT)
	var dealer_total := int(result.get("dealer_total", 0))
	var hand_results: Array = _draw_array_view(result.get("hand_results", []))
	var hand_bits: Array = []
	for i in range(mini(hand_results.size(), 4)):
		var hand_result: Dictionary = hand_results[i]
		hand_bits.append("H%d %d %s" % [i + 1, int(hand_result.get("player_total", 0)), str(hand_result.get("outcome", "push")).replace("_", " ").left(8)])
	var compare := "Dealer %d" % dealer_total
	if not hand_bits.is_empty():
		compare += " vs %s" % " / ".join(hand_bits)
	var side_line := _side_bet_result_line(_draw_array_view(result.get("side_bet_results", [])))
	if not side_line.is_empty():
		compare = side_line
	surface.surface_label(compare.left(38), rect.position + Vector2(10, 58), 8, C_SOFT)


func _blackjack_surface_currency(surface_state: Dictionary, result: Dictionary = {}) -> String:
	var settlement := _draw_dict_view(result.get("settlement", {}))
	var currency := str(settlement.get("currency", result.get("currency", surface_state.get("wager_currency", "cash")))).strip_edges().to_lower()
	return "chips" if currency == "chips" else "cash"


func _blackjack_signed_currency_amount(currency: String, amount: int) -> String:
	if currency.strip_edges().to_lower() == "chips":
		var noun := "CHIP" if absi(amount) == 1 else "CHIPS"
		return "%+d %s" % [amount, noun]
	return "$%+d" % amount


func _side_bet_result_line(side_results: Array) -> String:
	if side_results.is_empty():
		return ""
	var parts: Array = []
	var net_delta := 0
	for side_value in side_results:
		if typeof(side_value) != TYPE_DICTIONARY:
			continue
		var side: Dictionary = side_value
		var label := str(side.get("label", side.get("id", "Side"))).left(12)
		var delta := int(side.get("bankroll_delta", 0))
		net_delta += delta
		var detail := str(side.get("detail", "miss")).replace("_", " ").left(12)
		parts.append("%s %s %+d" % [label, detail, delta])
	if parts.is_empty():
		return ""
	return "Side %+d: %s" % [net_delta, " / ".join(parts).left(25)]


func _draw_shoe(surface, pos: Vector2, remaining: int) -> void:
	surface.draw_rect(Rect2(pos, Vector2(78, 46)), Color("#1b1d28"))
	surface.draw_rect(Rect2(pos + Vector2(8, 6), Vector2(62, 34)), Color("#0a0c14"))
	for i in range(4):
		surface.draw_rect(Rect2(pos + Vector2(12 + i * 4, 10 + i * 2), Vector2(42, 24)), Color("#f4ead5"))
	surface.draw_rect(Rect2(pos, Vector2(78, 46)), C_CYAN, false, 1)
	surface.surface_label("SHOE %d" % remaining, pos + Vector2(6, 60), 10, C_SOFT)


func _draw_table_button(surface, rect: Rect2, label: String, action: String, index: int, accent: Color, enabled: bool = true, selected: bool = false) -> void:
	var hovered: bool = bool(surface.surface_region_hovered(action, index))
	var fill := Color(accent.r, accent.g, accent.b, 0.26 if selected else 0.18 if hovered else 0.10)
	if not enabled:
		fill = Color(0.03, 0.03, 0.06, 0.72)
	surface.draw_rect(rect, fill)
	surface.draw_rect(rect, C_WHITE if hovered and enabled else accent if enabled else Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.30), false, 2 if hovered or selected else 1)
	var label_size := 9 if rect.size.y <= 18.0 else 11
	surface.surface_label_centered(label.left(16), rect.grow(-3), label_size, accent if enabled else Color(C_SOFT.r, C_SOFT.g, C_SOFT.b, 0.46))
	if selected:
		surface.surface_draw_ready_badge(rect, "READY")
	if enabled:
		surface.surface_add_exact_hit(rect, action, index)


func _draw_chip_button(surface, center: Vector2, value: int, action: String, index: int, enabled: bool = true) -> void:
	var hovered := bool(surface.surface_region_hovered(action, index))
	_draw_casino_chip(surface, center, value, 9.0, 1.0 if enabled else 0.35, hovered and enabled)
	if enabled: surface.surface_add_drag_hit(Rect2(center - Vector2(10, 10), Vector2(20, 20)), action, index)


func _draw_chip_stack(surface, pos: Vector2, stack_value: Variant, scale: float = 1.0) -> void:
	var stack: Array = stack_value if typeof(stack_value) == TYPE_ARRAY else []
	var y := 0.0
	for entry_value in stack:
		if typeof(entry_value) != TYPE_DICTIONARY:
			continue
		var entry: Dictionary = entry_value
		var value := int(entry.get("value", 1))
		var count := clampi(int(entry.get("count", 1)), 1, 8)
		for i in range(count):
			var chip_pos := pos + Vector2(0, y - float(i) * 3.0 * scale)
			_draw_casino_chip(surface, chip_pos, value, 11.0 * scale, 0.92, false)
		y -= float(count + 1) * 3.0 * scale


func _draw_casino_chip(surface, center: Vector2, value: int, radius: float, alpha: float = 1.0, selected: bool = false) -> void:
	var color := _chip_color(value)
	var rim := C_WHITE if selected else Color("#f7f1d0")
	surface.draw_circle(center + Vector2(2, 3), radius, Color(0, 0, 0, 0.28 * alpha))
	surface.draw_circle(center, radius, Color(color.r, color.g, color.b, 0.95 * alpha))
	surface.draw_circle(center, radius * 0.78, Color(rim.r, rim.g, rim.b, 0.86 * alpha), false, maxf(1.0, radius * 0.12))
	var rim_points := _cached_chip_rim_geometry(center, radius)
	var rim_color := Color(rim.r, rim.g, rim.b, 0.88 * alpha)
	var rim_width := maxf(1.0, radius * 0.10)
	if surface.has_method("draw_multiline"):
		surface.draw_multiline(rim_points, rim_color, rim_width)
	else:
		# Existing lightweight audit surfaces can replay the same segment pairs.
		for point_index in range(0, rim_points.size(), 2):
			surface.draw_line(rim_points[point_index], rim_points[point_index + 1], rim_color, rim_width)
	surface.draw_circle(center, radius * 0.50, Color("#101018"))
	surface.draw_circle(center, radius * 0.50, Color(color.r, color.g, color.b, 0.42 * alpha), false, maxf(1.0, radius * 0.08))
	if radius >= 8.0:
		var label_size := clampi(int(radius * 0.58), 6, 11)
		surface.surface_label_centered("$%d" % value, Rect2(center - Vector2(radius * 0.62, radius * 0.34), Vector2(radius * 1.24, radius * 0.68)), label_size, C_WHITE)


func _chip_color(value: int) -> Color:
	if value >= 25:
		return C_PINK_2
	if value >= 10:
		return C_TEAL
	if value >= 5:
		return C_YELLOW
	return C_WHITE


func _patron_seat_position(index: int) -> Vector2:
	return PATRON_SEAT_POSITIONS[clampi(index, 0, PATRON_SEAT_POSITIONS.size() - 1)]


func _draw_count_challenge(surface, surface_state: Dictionary) -> void:
	var challenge_value: Variant = surface_state.get("count_challenge", {})
	if typeof(challenge_value) != TYPE_DICTIONARY or (challenge_value as Dictionary).is_empty():
		return
	# The snapshot clock is intentionally static between actions. Bubble motion
	# must use the canvas' live simulation clock, which advances without forcing
	# an expensive full blackjack state rebuild every frame.
	var challenge: Dictionary = challenge_value as Dictionary
	var now_msec := int(surface.call("surface_simulation_time_msec")) if surface != null and surface.has_method("surface_simulation_time_msec") else _surface_time_for_count(surface_state)
	var icons_value: Variant = challenge.get("icons", [])
	var icons: Array = icons_value as Array if typeof(icons_value) == TYPE_ARRAY else []
	var clicked_value: Variant = challenge.get("clicked_icons", [])
	var clicked: Array = clicked_value as Array if typeof(clicked_value) == TYPE_ARRAY else []
	var missed_value: Variant = challenge.get("missed_icons", [])
	var missed: Array = missed_value as Array if typeof(missed_value) == TYPE_ARRAY else []
	var resolved_times_value: Variant = challenge.get("resolved_icon_msec", {})
	var resolved_times: Dictionary = resolved_times_value as Dictionary if typeof(resolved_times_value) == TYPE_DICTIONARY else {}
	var visual_miss_count := missed.size()
	for icon_value in icons:
		if typeof(icon_value) != TYPE_DICTIONARY:
			continue
		var icon: Dictionary = icon_value as Dictionary
		var icon_id := str(icon.get("id", ""))
		if icon_id.is_empty() or clicked.has(icon_id) or missed.has(icon_id):
			continue
		var spawn := int(icon.get("spawn_msec", now_msec))
		var duration := int(icon.get("duration_msec", COUNT_ICON_DURATION_MSEC))
		if now_msec > spawn + duration:
			visual_miss_count += 1
	# The hand delta starts over on every deal. The badge represents the running
	# count for the entire shoe, so it must include the count carried from prior
	# hands and only return to zero when the shoe is shuffled.
	var hand_delta := int(surface_state.get("count_delta", int(challenge.get("recorded_delta", 0))))
	var current_count := int(surface_state.get(
		"recorded_running_count",
		int(challenge.get("recorded_running_count_start", 0)) + hand_delta
	))
	var badge := Rect2(620, 74, 150, 30)
	surface.draw_rect(badge, Color(0.02, 0.025, 0.045, 0.72))
	surface.draw_rect(badge, Color(C_PINK_2.r, C_PINK_2.g, C_PINK_2.b, 0.34), false, 1)
	surface.surface_label("COUNT %+d" % current_count, badge.position + Vector2(12, 20), 14, C_YELLOW)
	if visual_miss_count > 0 or int(challenge.get("bad_hits", 0)) > 0:
		surface.surface_label("MISS %d / BAD %d" % [visual_miss_count, int(challenge.get("bad_hits", 0))], badge.position + Vector2(90, 19), 8, C_ORANGE)
	for i in range(icons.size()):
		if typeof(icons[i]) != TYPE_DICTIONARY:
			continue
		var icon: Dictionary = icons[i] as Dictionary
		var icon_id := str(icon.get("id", "icon_%d" % i))
		var spawn := int(icon.get("spawn_msec", int(challenge.get("started_msec", now_msec))))
		var duration := int(icon.get("duration_msec", COUNT_ICON_DURATION_MSEC))
		var age := now_msec - spawn
		var clicked_icon := clicked.has(icon_id)
		var missed_icon := missed.has(icon_id) or (not clicked_icon and age > duration)
		var active := age >= 0 and age <= duration and not clicked_icon and not missed_icon and not bool(surface_state.get("count_answered", false))
		var preview := age < 0 and age >= -360
		var fade_elapsed := -1
		if clicked_icon or missed_icon:
			fade_elapsed = now_msec - int(resolved_times.get(icon_id, spawn + duration))
		var fading := (clicked_icon or missed_icon) and fade_elapsed >= 0 and fade_elapsed <= COUNT_ICON_FADE_MSEC
		if not active and not fading and not preview:
			continue
		var phase := clampf(float(age) / float(maxi(1, duration)), 0.0, 1.0)
		var pos := Vector2(float(icon.get("x", 320.0)), float(icon.get("y", 164.0)))
		pos += Vector2(0, sin((float(now_msec - spawn) / 360.0) + float(i)) * 4.0)
		var value := int(icon.get("count_value", 0))
		var accent := C_TEAL if value > 0 else C_PINK_2 if value < 0 else C_SOFT
		var alpha := 0.28 if preview else 0.95 - phase * 0.42
		if clicked_icon:
			accent = C_YELLOW
			alpha = 0.86 * (1.0 - float(fade_elapsed) / float(COUNT_ICON_FADE_MSEC))
		elif missed_icon:
			accent = C_ORANGE
			alpha = 0.62 * (1.0 - float(fade_elapsed) / float(COUNT_ICON_FADE_MSEC))
		_draw_count_pulse_icon(surface, pos, value, accent, alpha, clicked_icon, missed_icon)
		if active:
			surface.surface_add_exact_hover_hit(Rect2(pos - Vector2(22, 22), Vector2(44, 44)), "blackjack_count_icon", i)


func _draw_count_pulse_icon(surface, center: Vector2, value: int, accent: Color, alpha: float, clicked: bool, missed: bool) -> void:
	var radius := 18.0
	surface.draw_circle(center + Vector2(2, 3), radius + 2.0, Color(0, 0, 0, 0.28 * alpha))
	surface.draw_circle(center, radius, Color(accent.r, accent.g, accent.b, 0.26 * alpha))
	surface.draw_circle(center, radius, Color(accent.r, accent.g, accent.b, 0.88 * alpha), false, 2)
	var label := "+1" if value > 0 else "-1" if value < 0 else "0"
	surface.surface_label_centered(label, Rect2(center - Vector2(17, 9), Vector2(34, 18)), 13, C_WHITE)
	if clicked:
		surface.surface_label_centered("HIT", Rect2(center - Vector2(18, 22), Vector2(36, 10)), 7, C_YELLOW)
	elif missed:
		surface.surface_label_centered("MISS", Rect2(center - Vector2(20, 22), Vector2(40, 10)), 7, C_ORANGE)


func _table_state(run_state: RunState, environment: Dictionary, observational: bool = false, owns_table_state: bool = false) -> Dictionary:
	var game_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var table: Dictionary = game_states.get(get_id(), {}) if typeof(game_states.get(get_id(), {})) == TYPE_DICTIONARY else {}
	if table.is_empty():
		table = _fallback_state(run_state, environment)
		game_states[get_id()] = table
		environment["game_states"] = game_states
	_apply_grand_casino_dealer_assignment(table, run_state, environment, observational)
	var normalized := _normalize_table_state(table, owns_table_state)
	# Peek is a mandatory guided-run lesson, so its real setup controls cannot be
	# sampled out of the table. Repair both newly generated tables and resumed
	# saves whose old random distraction roll omitted DRINK PASS. Keep this scoped
	# to Pal's underground table; normal blackjack retains the complete random
	# distraction catalog and distribution.
	if _ensure_tutorial_peek_distractions(normalized, run_state, environment):
		_update_environment_table(environment, normalized)
	return normalized


func _table_state_preview(run_state: RunState, environment: Dictionary) -> Dictionary:
	var game_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var stored: Variant = game_states.get(get_id(), {})
	var table: Dictionary = _duplicate_table_with_immutable_authority(stored as Dictionary) if typeof(stored) == TYPE_DICTIONARY and not (stored as Dictionary).is_empty() else _fallback_state(run_state, environment)
	_apply_grand_casino_dealer_assignment(table, run_state, environment, true)
	var normalized := _normalize_table_state(table)
	# Tutorial repair is also a projection here. Action boundaries persist it via
	# _table_state(); passive activation must never rewrite a resumed save.
	_ensure_tutorial_peek_distractions(normalized, run_state, environment)
	return normalized


func _apply_grand_casino_dealer_assignment(table: Dictionary, run_state: RunState, environment: Dictionary, observational: bool = false) -> void:
	if run_state == null:
		return
	if _is_rourke_duel(run_state, environment):
		return
	var assignment := run_state.grand_casino_staff_member_for_game_preview(get_id(), environment) if observational else run_state.grand_casino_staff_member_for_game(get_id(), environment)
	var assignment_id := str(assignment.get("id", "")).strip_edges()
	if assignment_id.is_empty():
		return
	var assignment_day := maxi(1, int(assignment.get("day", run_state.game_day())))
	var previous_id := str(table.get("staff_assignment_id", "")).strip_edges()
	table["staff_assignment_day"] = assignment_day
	if previous_id == assignment_id:
		return
	var profile_rng := run_state.grand_casino_staff_profile_rng(get_id(), assignment_id, assignment_day)
	var profile := _generate_dealer_profile(profile_rng, int(table.get("dealer_catch_base", 10)))
	profile["name"] = str(assignment.get("name", "Dealer"))
	profile["identity_id"] = assignment_id
	profile["style_id"] = str(assignment.get("style_id", "mara"))
	table["dealer_name"] = str(assignment.get("name", "Dealer"))
	table["dealer_profile"] = profile
	table["staff_assignment_id"] = assignment_id
	if not previous_id.is_empty():
		table["strategy_deviation_strikes"] = 0
		table["strategy_watch_pressure"] = 0
		table["strategy_last_notice"] = ""


func _generate_dealer_profile(rng: RngStream, catch_base: int) -> Dictionary:
	var tells: Array = [
		"checks the discard tray",
		"watches hands more than faces",
		"glances at the pit boss",
		"protects the hole card with one thumb",
	]
	var read_styles: Array = ["slow sweep", "sharp eye flick", "tray check", "chip count", "pit glance"]
	return {
		"posture": str(rng.pick(["upright", "leaning", "quiet", "sharp"], "upright")),
		"tell": str(rng.pick(tells, tells[0])),
		"attention_base": clampi(catch_base + rng.randi_range(4, 18), 10, 60),
		"patience": rng.randi_range(2, 5),
		"uniform_accent": str(rng.pick(["cyan tie", "pink cuffs", "gold pin", "black vest"], "cyan tie")),
		"read_style": str(rng.pick(read_styles, read_styles[0])),
		"gaze_speed": rng.randi_range(70, 135),
		"blink_offset": rng.randi_range(0, 2600),
		"strategy_scrutiny": rng.randi_range(8, 16),
		"strategy_threshold": rng.randi_range(3, 5),
		"strategy_response": str(rng.pick(["watch", "heat", "both"], "watch")),
	}


func _generate_table_patrons(rng: RngStream, depth: int) -> Array:
	var names: Array = ["Nix", "Sal", "Dove", "Milo", "Anika", "Trent", "June", "Vale"]
	var moods: Array = ["chatty", "quiet", "suspicious", "tilted", "friendly"]
	var styles: Array = ["flat_main", "side_action", "big_stack", "minimum"]
	var chip_colors: Array = ["cyan", "teal", "yellow", "pink", "orange"]
	var tells: Array = ["leans in", "side eye", "chip stare", "phone glance", "drink sip", "soft nod"]
	var count: int = rng.randi_range(1, clampi(2 + depth, 2, 4))
	var picked_names: Array = rng.pick_many(names, count)
	var patrons: Array = []
	for i in range(count):
		var mood := str(rng.pick(moods, "quiet"))
		var snitch_risk := rng.randi_range(8, 28)
		if mood == "suspicious":
			snitch_risk += 14
		elif mood == "friendly" or mood == "chatty":
			snitch_risk -= 5
		patrons.append({
			"id": "patron_%d" % i,
			"name": str(picked_names[i] if i < picked_names.size() else "Patron"),
			"seat": i,
			"mood": mood,
			"bet_style": str(rng.pick(styles, styles[0])),
			"cosmetic_bet": int(rng.pick([5, 10, 15, 25, 40], 10)),
			"rapport": rng.randi_range(42, 62),
			"chip_color": str(chip_colors[i % chip_colors.size()]),
			"snitch_risk": clampi(snitch_risk, 4, 46),
			"chip_stack": rng.randi_range(12, 90),
			"watching": rng.randi_range(0, 100) >= 32,
			"silhouette": str(rng.pick(["cap", "glasses", "coat", "rings"], "coat")),
			"tell": str(rng.pick(tells, tells[0])),
			"temper": str(rng.pick(["nosy", "careless", "loyal", "sharp"], "careless")),
			"seat_style": str(rng.pick(["vest", "jacket", "open"], "open")),
			"animation_offset": rng.randi_range(0, 3600),
			"snitch_threshold": rng.randi_range(18, 52),
		})
	return patrons


func _generate_table_distractions(rng: RngStream) -> Array:
	var catalog := _table_distraction_catalog()
	return rng.pick_many(catalog, rng.randi_range(2, 3))


func _table_distraction_catalog() -> Array:
	return [
		{"id": "chip_spill", "label": "Chip Spill", "summary": "short window; patrons look down", "duration_msec": 2600, "cover": 10, "noise": 7},
		{"id": "payout_question", "label": "Payout Ask", "summary": "medium window; dealer checks felt", "duration_msec": 3400, "cover": 6, "noise": 4},
		{"id": "pit_glance", "label": "Pit Glance", "summary": "long window; higher table heat", "duration_msec": 4200, "cover": 4, "noise": 10},
		{"id": "drink_pass", "label": "Drink Pass", "summary": "covers patrons; brief dealer gap", "duration_msec": 3000, "cover": 16, "noise": 6},
	]


func _ensure_tutorial_peek_distractions(table: Dictionary, run_state: RunState, environment: Dictionary) -> bool:
	if run_state == null \
			or not run_state.is_tutorial_run() \
			or str(environment.get("archetype_id", "")) != "small_underground_casino":
		return false
	var distractions := _dictionary_array(table.get("distractions", []))
	var existing_ids: Array[String] = []
	for distraction_value in distractions:
		var distraction: Dictionary = distraction_value
		var distraction_id := str(distraction.get("id", "")).strip_edges()
		if not distraction_id.is_empty() and not existing_ids.has(distraction_id):
			existing_ids.append(distraction_id)
	var required_ids := ["drink_pass", "chip_spill"]
	if existing_ids.size() >= 2 and existing_ids[0] == required_ids[0] and existing_ids[1] == required_ids[1]:
		return false
	var by_id := {}
	for distraction_value in _table_distraction_catalog():
		var distraction: Dictionary = distraction_value
		by_id[str(distraction.get("id", ""))] = distraction.duplicate(true)
	for distraction_value in distractions:
		var distraction: Dictionary = distraction_value
		var distraction_id := str(distraction.get("id", "")).strip_edges()
		if not distraction_id.is_empty():
			by_id[distraction_id] = distraction.duplicate(true)
	var repaired: Array = []
	for required_id in required_ids:
		repaired.append((by_id.get(required_id, {}) as Dictionary).duplicate(true))
	for distraction_value in distractions:
		var distraction: Dictionary = distraction_value
		if repaired.size() >= 3:
			break
		var distraction_id := str(distraction.get("id", "")).strip_edges()
		if required_ids.has(distraction_id):
			continue
		repaired.append(distraction.duplicate(true))
	table["distractions"] = repaired
	table["tutorial_peek_distractions_repaired"] = true
	return true


func _default_table_rng(table: Dictionary, suffix: String) -> RngStream:
	var rng := RngStream.new()
	rng.configure(JsonCoerceScript._stable_hash("%s:%s:%s" % [get_id(), str(table.get("table_name", "blackjack")), suffix]))
	return rng


func _normalize_dealer_profile(value: Variant, table: Dictionary) -> Dictionary:
	var profile: Dictionary = value if typeof(value) == TYPE_DICTIONARY else {}
	if profile.is_empty():
		profile = _generate_dealer_profile(_default_table_rng(table, "dealer"), int(table.get("dealer_catch_base", 10)))
	profile["posture"] = str(profile.get("posture", "upright"))
	profile["tell"] = str(profile.get("tell", "watches hands more than faces"))
	profile["attention_base"] = clampi(int(profile.get("attention_base", int(table.get("dealer_catch_base", 10)) + 12)), 8, 70)
	profile["patience"] = clampi(int(profile.get("patience", 3)), 1, 6)
	profile["uniform_accent"] = str(profile.get("uniform_accent", "cyan tie"))
	profile["read_style"] = str(profile.get("read_style", "slow sweep"))
	profile["gaze_speed"] = clampi(int(profile.get("gaze_speed", 95)), 45, 180)
	profile["blink_offset"] = maxi(0, int(profile.get("blink_offset", 0)))
	profile["strategy_scrutiny"] = clampi(int(profile.get("strategy_scrutiny", 10)), 0, 30)
	profile["strategy_threshold"] = clampi(int(profile.get("strategy_threshold", 4)), 1, 8)
	var strategy_response := str(profile.get("strategy_response", "watch"))
	if not ["watch", "heat", "both"].has(strategy_response):
		strategy_response = "watch"
	profile["strategy_response"] = strategy_response
	return profile


func _normalize_distractions(value: Variant, table: Dictionary) -> Array:
	var distractions: Array = _dictionary_array(value)
	if distractions.is_empty():
		distractions = _generate_table_distractions(_default_table_rng(table, "distractions"))
	var result: Array = []
	for distraction_value in distractions:
		var distraction: Dictionary = distraction_value
		var id := str(distraction.get("id", "distraction_%d" % result.size()))
		result.append({
			"id": id,
			"label": str(distraction.get("label", id.replace("_", " ").capitalize())),
			"summary": str(distraction.get("summary", "opens a peek window")),
			"duration_msec": clampi(int(distraction.get("duration_msec", 3000)), 1200, 6000),
			"cover": clampi(int(distraction.get("cover", 8)), 0, 30),
			"noise": clampi(int(distraction.get("noise", 5)), 0, 30),
		})
	return result


func _normalize_patrons(value: Variant, table: Dictionary) -> Array:
	var patrons: Array = _dictionary_array(value)
	if patrons.is_empty() and not table.has("patrons"):
		patrons = _generate_table_patrons(_default_table_rng(table, "patrons"), 0)
	var result: Array = []
	for i in range(patrons.size()):
		var patron: Dictionary = patrons[i]
		var id := str(patron.get("id", "patron_%d" % i))
		result.append({
			"id": id,
			"name": str(patron.get("name", "Patron")),
			"seat": int(patron.get("seat", i)),
			"mood": str(patron.get("mood", "quiet")),
			"bet_style": str(patron.get("bet_style", "flat_main")),
			"cosmetic_bet": maxi(1, int(patron.get("cosmetic_bet", maxi(1, int(patron.get("chip_stack", 20)) / 3)))),
			"rapport": clampi(int(patron.get("rapport", 50)), 0, 100),
			"chip_color": str(patron.get("chip_color", "cyan")),
			"snitch_risk": clampi(int(patron.get("snitch_risk", 18)), 0, 60),
			"chip_stack": maxi(0, int(patron.get("chip_stack", 20))),
			"watching": bool(patron.get("watching", true)),
			"silhouette": str(patron.get("silhouette", "coat")),
			"tell": str(patron.get("tell", "leans in")),
			"temper": str(patron.get("temper", "careless")),
			"seat_style": str(patron.get("seat_style", "open")),
			"animation_offset": maxi(0, int(patron.get("animation_offset", i * 620))),
			"snitch_threshold": clampi(int(patron.get("snitch_threshold", 30)), 4, 70),
		})
	return result


func _chip_denominations(table: Dictionary) -> Array:
	var values: Array = []
	var source: Array = table.get("chip_denominations", []) if typeof(table.get("chip_denominations", [])) == TYPE_ARRAY else []
	for value in source:
		var chip_value := maxi(1, int(value))
		if not values.has(chip_value):
			values.append(chip_value)
	if values.is_empty():
		values = [1, 5, 10, 25]
	values.sort()
	return values


func _normalize_table_state(table: Dictionary, owns_table_state: bool = false) -> Dictionary:
	# Sealed proposal candidates own their complete bound table graph. Reusing that
	# graph is safe because neither candidate can escape until both executions have
	# matched; all other callers keep the defensive deep copy.
	var normalized := table if owns_table_state else _duplicate_table_with_immutable_authority(table)
	normalized["schema"] = str(normalized.get("schema", "blackjack_table_state"))
	normalized["version"] = maxi(2, int(normalized.get("version", 2)))
	normalized["deck_count"] = clampi(int(normalized.get("deck_count", 6)), 1, 8)
	var deck_count := int(normalized.get("deck_count", 6))
	var shoe: Array = []
	var shoe_value: Variant = normalized.get("shoe", [])
	if typeof(shoe_value) == TYPE_ARRAY:
		shoe = shoe_value as Array
	if shoe.is_empty():
		var rng := RngStream.new()
		rng.configure(JsonCoerceScript._stable_hash(str(normalized.get("table_name", "blackjack"))))
		shoe = _build_shoe(deck_count, rng)
	normalized["shoe"] = shoe
	normalized["shoe_cursor"] = 0
	var total_cards := deck_count * CardShoeScript.CARDS_PER_DECK
	var default_cut_remaining := CardShoeScript.cut_card_remaining(deck_count)
	if not normalized.has("cut_card_remaining"):
		var cut_card_at := int(normalized.get("cut_card_at", total_cards - default_cut_remaining))
		normalized["cut_card_remaining"] = clampi(total_cards - cut_card_at, 1, total_cards)
	else:
		normalized["cut_card_remaining"] = clampi(int(normalized.get("cut_card_remaining", default_cut_remaining)), 1, total_cards)
	normalized["cut_card_at"] = total_cards - int(normalized.get("cut_card_remaining", default_cut_remaining))
	normalized["shoe_remaining"] = shoe.size()
	var composition: Dictionary = normalized.get("shoe_composition", {}) if typeof(normalized.get("shoe_composition", {})) == TYPE_DICTIONARY else {}
	if composition.is_empty() or int(composition.get("total", -1)) != shoe.size():
		composition = CardShoeScript.remaining_composition(shoe)
	normalized["shoe_composition"] = composition
	normalized["shoe_label"] = CardShoeScript.shoe_label(deck_count)
	normalized["count_efficiency"] = CardShoeScript.count_efficiency_label(deck_count)
	if typeof(normalized.get("rules", {})) != TYPE_DICTIONARY:
		normalized["rules"] = {}
	normalized["side_bets"] = _normalize_side_bets(normalized.get("side_bets", []))
	normalized["dealer_profile"] = _normalize_dealer_profile(normalized.get("dealer_profile", {}), normalized)
	normalized["patrons"] = _normalize_patrons(normalized.get("patrons", []), normalized)
	normalized["distractions"] = _normalize_distractions(normalized.get("distractions", []), normalized)
	normalized["chip_denominations"] = _chip_denominations(normalized)
	normalized["table_layout"] = str(normalized.get("table_layout", "immersive_blackjack"))
	normalized["running_count"] = int(normalized.get("running_count", 0))
	normalized["recorded_running_count"] = int(normalized.get("recorded_running_count", 0))
	normalized["shoe_generation"] = maxi(1, int(normalized.get("shoe_generation", 1)))
	normalized["recorded_count_shoe_generation"] = maxi(0, int(normalized.get("recorded_count_shoe_generation", 0)))
	normalized["counting_enabled"] = bool(normalized.get("counting_enabled", false))
	normalized["counter_observation_hands"] = maxi(0, int(normalized.get("counter_observation_hands", 0)))
	normalized["counter_observation_samples"] = _counter_observation_samples(normalized.get("counter_observation_samples", []))
	normalized["counter_evidence_points"] = clampi(int(normalized.get("counter_evidence_points", 0)), 0, 100)
	normalized["counter_miss_streak"] = maxi(0, int(normalized.get("counter_miss_streak", 0)))
	normalized["counter_last_assessment"] = _local_copy_dict(normalized.get("counter_last_assessment", {}))
	normalized["barred"] = bool(normalized.get("barred", false))
	normalized["barred_reason"] = str(normalized.get("barred_reason", ""))
	normalized["strategy_deviation_strikes"] = maxi(0, int(normalized.get("strategy_deviation_strikes", 0)))
	normalized["strategy_watch_pressure"] = clampi(int(normalized.get("strategy_watch_pressure", 0)), 0, STRATEGY_DEVIATION_MAX_WATCH)
	normalized["strategy_last_notice"] = str(normalized.get("strategy_last_notice", ""))
	normalized["table_round_timer_started_msec"] = int(normalized.get("table_round_timer_started_msec", 0))
	return normalized


func _normalized_session(run_state: RunState, environment: Dictionary, ui_state: Dictionary, table: Dictionary) -> Dictionary:
	var host_ledger: Dictionary = table.get(BLACKJACK_HOST_LEDGER_KEY, {}) if typeof(table.get(BLACKJACK_HOST_LEDGER_KEY, {})) == TYPE_DICTIONARY else {}
	var host_session_initialized := bool(host_ledger.get("initialized", false))
	var session: Dictionary = run_state.grand_casino_duel_session() if _is_rourke_duel(run_state, environment) else (host_ledger.get("session", {}) as Dictionary).duplicate(true) if host_session_initialized and typeof(host_ledger.get("session", {})) == TYPE_DICTIONARY else {}
	for key in ui_state.keys():
		# Once the table host has initialized its durable session, caller UI is
		# presentation-only. Cards, phase, wager debit, cheats and shoe data are
		# always read from the saved host session.
		if not host_session_initialized or _is_rourke_duel(run_state, environment) or BLACKJACK_HOST_TRANSIENT_UI_KEYS.has(str(key)):
			session[str(key)] = ui_state[key]
	if _is_rourke_duel(run_state, environment):
		var duel := run_state.grand_casino_duel_status()
		session["boss_duel_session"] = true
		session["selected_stake"] = maxi(1, int(duel.get("ante", 20)))
		session["locked_stake"] = maxi(1, int(duel.get("ante", 20)))
		session["blackjack_side_bets"] = []
	var hands: Array = _hand_array(session.get("player_hands", session.get("blackjack_hands", [])))
	var dealer_cards: Array = _card_array(session.get("dealer_cards", session.get("dealer", [])))
	var patron_hands: Array = _hand_array(session.get("patron_hands", []))
	var cards_consumed: int = int(session.get("cards_consumed", 0))
	var session_shoe: Array = []
	if typeof(session.get("shoe", [])) == TYPE_ARRAY:
		session_shoe = _card_array(session.get("shoe", []))
	session["player_hands"] = hands
	session["dealer_cards"] = dealer_cards
	session["patron_hands"] = patron_hands
	session["cards_consumed"] = cards_consumed
	if session_shoe.is_empty() and not bool(session.get("shoe_refilled_during_hand", false)):
		session.erase("shoe")
		session["shoe_remaining"] = _shoe_remaining_for_cursor(table, cards_consumed)
	else:
		session["shoe"] = session_shoe
		session["shoe_remaining"] = session_shoe.size()
	session["active_hand_index"] = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	session["dealer_hole_visible"] = bool(session.get("dealer_hole_visible", false))
	var initial_player_cards: Array = _card_array(session.get("initial_player_cards", []))
	if initial_player_cards.is_empty() and not hands.is_empty():
		var opening_hand: Dictionary = hands[0]
		initial_player_cards = _first_cards(_card_array(opening_hand.get("cards", [])), 2)
	var initial_dealer_cards: Array = _card_array(session.get("initial_dealer_cards", []))
	if initial_dealer_cards.is_empty():
		initial_dealer_cards = _first_cards(dealer_cards, 2)
	session["initial_player_cards"] = initial_player_cards
	session["initial_dealer_cards"] = initial_dealer_cards
	session["blackjack_side_bets"] = _valid_side_bet_ids_for_session(_string_array(session.get("blackjack_side_bets", session.get("side_bets", []))), table, session)
	if typeof(session.get("cheats_used", {})) != TYPE_DICTIONARY:
		session["cheats_used"] = {}
	if typeof(session.get("count_challenge", {})) != TYPE_DICTIONARY:
		session["count_challenge"] = {}
	if typeof(session.get("strategy_deviation_events", [])) != TYPE_ARRAY:
		session["strategy_deviation_events"] = []
	session["strategy_deviation_score"] = maxi(0, int(session.get("strategy_deviation_score", 0)))
	session["strategy_attention_boost"] = clampi(int(session.get("strategy_attention_boost", 0)), 0, STRATEGY_DEVIATION_MAX_WATCH)
	session["strategy_confronted"] = bool(session.get("strategy_confronted", false))
	session["strategy_confrontation_heat"] = maxi(0, int(session.get("strategy_confrontation_heat", 0)))
	session["counting_enabled"] = bool(session.get("counting_enabled", table.get("counting_enabled", false)))
	if typeof(session.get("patron_cover", {})) != TYPE_DICTIONARY:
		session["patron_cover"] = {}
	session["dealer_lookaway_started_msec"] = int(session.get("dealer_lookaway_started_msec", 0))
	session["dealer_lookaway_duration_msec"] = int(session.get("dealer_lookaway_duration_msec", 0))
	session["dealer_lookaway_id"] = str(session.get("dealer_lookaway_id", ""))
	session["dealer_distraction_id"] = str(session.get("dealer_distraction_id", ""))
	session["dealer_distraction_noise"] = int(session.get("dealer_distraction_noise", 0))
	session["blackjack_sit_out"] = bool(session.get("blackjack_sit_out", false))
	if session.has("locked_stake"):
		session["locked_stake"] = maxi(1, int(session.get("locked_stake", 1)))
	if session.has("selected_stake"):
		session["selected_stake"] = maxi(1, int(session.get("selected_stake", 1)))
	if not session.has("session_id"):
		session["session_id"] = "%s:%s:%d" % [get_id(), str(environment.get("id", "")), int(table.get("hands_played", 0))]
	return session


func _initial_deal(session: Dictionary, table: Dictionary) -> Dictionary:
	var sit_out := bool(session.get("blackjack_sit_out", false))
	var player_cards: Array = []
	var dealer_cards: Array = []
	if sit_out:
		dealer_cards = _draw_cards_from_session(session, table, 2)
		while dealer_cards.size() < 2:
			dealer_cards.append({"rank": 2, "suit": dealer_cards.size() % 4, "deck": 0})
	else:
		var opening_cards: Array = _draw_cards_from_session(session, table, 4)
		while opening_cards.size() < 4:
			opening_cards.append({"rank": 2, "suit": opening_cards.size() % 4, "deck": 0})
		player_cards = [opening_cards[0], opening_cards[2]]
		dealer_cards = [opening_cards[1], opening_cards[3]]
	var patron_hands: Array = []
	var patrons: Array = _dictionary_array(table.get("patrons", []))
	for i in range(patrons.size()):
		var patron: Dictionary = patrons[i]
		var cards: Array = _draw_cards_from_session(session, table, 2)
		patron_hands.append({
			"patron_id": str(patron.get("id", "patron_%d" % i)),
			"name": str(patron.get("name", "Patron")),
			"seat": int(patron.get("seat", i)),
			"temper": str(patron.get("temper", "careless")),
			"cards": cards,
			"wager_multiplier": 1,
			"stood": false,
			"doubled": false,
			"split": false,
			"blackjack_eligible": false,
			"terminal_reason": "",
		})
	var player_hands: Array = []
	if not sit_out:
		player_hands.append({
			"cards": player_cards,
			"wager_multiplier": 1,
			"stood": false,
			"doubled": false,
			"split": false,
			"blackjack_eligible": true,
		})
	return {
		"player_hands": player_hands,
		"dealer_cards": dealer_cards,
		"patron_hands": patron_hands,
		"cards_consumed": int(session.get("cards_consumed", 0)),
	}


func _has_dealt_hand(session: Dictionary) -> bool:
	var dealer_cards_value: Variant = session.get("dealer_cards", [])
	if typeof(dealer_cards_value) != TYPE_ARRAY or (dealer_cards_value as Array).is_empty():
		return false
	var player_hands_value: Variant = session.get("player_hands", [])
	return (typeof(player_hands_value) == TYPE_ARRAY and not (player_hands_value as Array).is_empty()) or bool(session.get("blackjack_sit_out", false))


func _start_initial_hand(session: Dictionary, table: Dictionary, stake: int = 1, run_state: RunState = null, result_msec: int = -1) -> void:
	if _has_dealt_hand(session):
		return
	var boss_duel := bool(session.get("boss_duel_session", false)) and run_state != null
	if boss_duel:
		var duel := run_state.grand_casino_duel_status()
		var hand_rng := run_state.create_rng("grand_casino_duel").fork("attempt:%d:hand:%d:draws" % [
			maxi(1, int(duel.get("attempt", 1))),
			maxi(0, int(duel.get("hand_index", 0))),
		])
		session["shoe"] = _build_shoe(int(table.get("deck_count", 2)), hand_rng)
		session["shoe_refilled_during_hand"] = true
	else:
		session.erase("shoe")
	session["cards_consumed"] = 0
	session["shoe_emergency_shuffle_count"] = 0
	if not boss_duel:
		session["shoe_refilled_during_hand"] = false
	var initial: Dictionary = _initial_deal(session, table)
	var hands: Array = _hand_array(initial.get("player_hands", []))
	var dealer_cards: Array = _card_array(initial.get("dealer_cards", []))
	var patron_hands: Array = _hand_array(initial.get("patron_hands", []))
	_stabilize_tutorial_peek_opening(hands, dealer_cards, table, run_state)
	session["player_hands"] = hands
	session["dealer_cards"] = dealer_cards
	session["patron_hands"] = patron_hands
	session["patron_action_events"] = []
	session["settlement_deal_animation_events"] = []
	session["cards_consumed"] = int(initial.get("cards_consumed", 4))
	if not boss_duel:
		session.erase("shoe")
		session["shoe_remaining"] = _shoe_remaining_for_cursor(table, int(session.get("cards_consumed", 0)))
	else:
		session["shoe_remaining"] = _card_array(session.get("shoe", [])).size()
	session["active_hand_index"] = 0
	session["moves_made"] = false
	session["locked_stake"] = maxi(1, stake)
	session["selected_stake"] = maxi(1, stake)
	if not hands.is_empty():
		var opening_hand: Dictionary = hands[0]
		session["initial_player_cards"] = _first_cards(_card_array(opening_hand.get("cards", [])), 2)
	else:
		session["initial_player_cards"] = []
	session["initial_dealer_cards"] = _first_cards(dealer_cards, 2)
	if boss_duel:
		_apply_rourke_edge_to_session(session, run_state.grand_casino_duel_current_edge())
		hands = _hand_array(session.get("player_hands", []))
		dealer_cards = _card_array(session.get("dealer_cards", []))
		if not hands.is_empty():
			session["initial_player_cards"] = _first_cards(_card_array((hands[0] as Dictionary).get("cards", [])), 2)
		session["initial_dealer_cards"] = _first_cards(dealer_cards, 2)
	_mark_deal_animation(session, "initial", _initial_deal_animation_events(hands, dealer_cards, patron_hands), result_msec)
	if bool(table.get("counting_enabled", false)):
		_start_count_challenge(session, table, run_state)


# The guided second hand teaches a timed interaction. A random opening natural
# settles before the player can create the lookaway and leaves the lesson aimed
# at a control that no longer exists. Preserve the same four cards and shoe
# consumption, but pair them into the first deterministic non-natural layout.
# Normal runs and every post-Peek tutorial hand retain the exact shoe order.
func _stabilize_tutorial_peek_opening(hands: Array, dealer_cards: Array, table: Dictionary, run_state: RunState) -> void:
	if run_state == null \
			or not run_state.is_tutorial_run() \
			or str(run_state.current_environment.get("archetype_id", "")) != "small_underground_casino" \
			or int(table.get("hands_played", 0)) < 1:
		return
	var completed: Dictionary = run_state.narrative_flags.get("tutorial_lessons_completed", {}) if typeof(run_state.narrative_flags.get("tutorial_lessons_completed", {})) == TYPE_DICTIONARY else {}
	if bool(completed.get("tutorial_blackjack_peek", false)) or hands.is_empty() or dealer_cards.size() < 2:
		return
	var player_hand: Dictionary = hands[0]
	var player_cards: Array = _card_array(player_hand.get("cards", []))
	if player_cards.size() < 2 or (not _is_natural_blackjack(player_hand) and not _dealer_has_blackjack(dealer_cards)):
		return
	var opening_cards: Array = [player_cards[0], player_cards[1], dealer_cards[0], dealer_cards[1]]
	for first_index in range(opening_cards.size()):
		for second_index in range(first_index + 1, opening_cards.size()):
			var candidate_player := [opening_cards[first_index], opening_cards[second_index]]
			var candidate_dealer: Array = []
			for card_index in range(opening_cards.size()):
				if card_index != first_index and card_index != second_index:
					candidate_dealer.append(opening_cards[card_index])
			var candidate_hand := player_hand.duplicate(true)
			candidate_hand["cards"] = candidate_player
			if _is_natural_blackjack(candidate_hand) or _dealer_has_blackjack(candidate_dealer):
				continue
			player_hand["cards"] = candidate_player
			hands[0] = player_hand
			dealer_cards.assign(candidate_dealer)
			return


func _draw_card_from_session(session: Dictionary, table: Dictionary) -> Dictionary:
	var cards: Array = _draw_cards_from_session(session, table, 1)
	if cards.is_empty():
		return {"rank": 2, "suit": 0, "deck": 0}
	return (cards[0] as Dictionary).duplicate(true) # SA2_PER_FRAME_OK: shoe mutation helper, not rendering/per-frame.


func _draw_cards_from_session(session: Dictionary, table: Dictionary, count: int) -> Array:
	var drawn: Array = []
	var target_count := maxi(0, count)
	if _draw_cards_from_table_cursor(session, table, target_count, drawn):
		return drawn
	while drawn.size() < target_count:
		var shoe: Array = _card_array(session.get("shoe", []))
		if shoe.is_empty():
			_refill_session_shoe(session, table)
			shoe = _card_array(session.get("shoe", []))
			if shoe.is_empty():
				break
		var draw_result: Dictionary = CardShoeScript.draw_cards(shoe, target_count - drawn.size())
		var draw_cards: Array = _card_array(draw_result.get("cards", []))
		drawn.append_array(draw_cards)
		session["shoe"] = _card_array(draw_result.get("shoe", []))
		session["cards_consumed"] = int(session.get("cards_consumed", 0)) + draw_cards.size()
		session["shoe_remaining"] = CardShoeScript.remaining_count(session.get("shoe", []))
		if draw_cards.is_empty():
			break
	return drawn


func _draw_cards_from_table_cursor(session: Dictionary, table: Dictionary, target_count: int, drawn: Array) -> bool:
	if bool(session.get("shoe_refilled_during_hand", false)):
		return false
	if typeof(session.get("shoe", [])) == TYPE_ARRAY and not (session.get("shoe", []) as Array).is_empty():
		return false
	var table_shoe_value: Variant = table.get("shoe", [])
	if typeof(table_shoe_value) != TYPE_ARRAY:
		return false
	var table_shoe: Array = table_shoe_value as Array
	var cursor: int = clampi(int(session.get("cards_consumed", 0)), 0, table_shoe.size())
	while drawn.size() < target_count and cursor < table_shoe.size():
		var card_value: Variant = table_shoe[cursor]
		cursor += 1
		if typeof(card_value) == TYPE_DICTIONARY:
			drawn.append((card_value as Dictionary).duplicate(true)) # SA2_PER_FRAME_OK: shoe mutation helper, not rendering/per-frame.
	session["cards_consumed"] = cursor
	session["shoe_remaining"] = maxi(0, table_shoe.size() - cursor)
	return drawn.size() >= target_count


func _refill_session_shoe(session: Dictionary, table: Dictionary) -> void:
	var refill_index := int(session.get("shoe_emergency_shuffle_count", 0)) + 1
	var rng := RngStream.new()
	rng.configure(JsonCoerceScript._stable_hash("%s:%s:%d:%d" % [
		str(table.get("table_name", "blackjack")),
		str(session.get("session_id", "")),
		int(table.get("hands_played", 0)),
		refill_index,
	]))
	session["shoe"] = _build_shoe(int(table.get("deck_count", 6)), rng)
	session["shoe_remaining"] = CardShoeScript.remaining_count(session.get("shoe", []))
	session["shoe_emergency_shuffle_count"] = refill_index
	session["shoe_refilled_during_hand"] = true


func _shoe_remaining_for_cursor(table: Dictionary, cards_consumed: int) -> int:
	var table_shoe_value: Variant = table.get("shoe", [])
	if typeof(table_shoe_value) != TYPE_ARRAY:
		return 0
	var table_shoe: Array = table_shoe_value as Array
	return maxi(0, table_shoe.size() - clampi(cards_consumed, 0, table_shoe.size()))


func _remaining_shoe_after_session(table: Dictionary, session: Dictionary) -> Array:
	var session_shoe: Array = _card_array(session.get("shoe", []))
	if not session_shoe.is_empty() or bool(session.get("shoe_refilled_during_hand", false)):
		return session_shoe
	var table_shoe_value: Variant = table.get("shoe", [])
	var remaining: Array = []
	if typeof(table_shoe_value) != TYPE_ARRAY:
		return remaining
	var table_shoe: Array = table_shoe_value as Array
	var cursor: int = clampi(int(session.get("cards_consumed", 0)), 0, table_shoe.size())
	for i in range(cursor, table_shoe.size()):
		var card_value: Variant = table_shoe[i]
		if typeof(card_value) == TYPE_DICTIONARY:
			remaining.append((card_value as Dictionary).duplicate(true))
	return remaining


func _compact_session_for_ui(ui_state: Dictionary) -> Dictionary:
	if not bool(ui_state.get("shoe_refilled_during_hand", false)) and not bool(ui_state.get("boss_duel_session", false)):
		ui_state.erase("shoe")
		if ui_state.has("cards_consumed"):
			ui_state["shoe_remaining"] = maxi(0, int(ui_state.get("shoe_remaining", 0)))
	return ui_state


func _apply_rourke_edge_to_session(session: Dictionary, edge: Dictionary) -> void:
	if not bool(edge.get("active", false)) or bool(edge.get("stripped", false)):
		return
	var hands := _hand_array(session.get("player_hands", []))
	var dealer := _card_array(session.get("dealer_cards", []))
	var shoe := _card_array(session.get("shoe", []))
	if hands.is_empty() or dealer.size() < 2 or shoe.is_empty():
		return
	session["boss_edge_original"] = {
		"player_hands": hands.duplicate(true),
		"dealer_cards": dealer.duplicate(true),
		"shoe": shoe.duplicate(true),
	}
	var high_index := _rourke_shoe_card_index(shoe, true)
	var low_index := _rourke_shoe_card_index(shoe, false)
	match str(edge.get("id", "")):
		"deck_stack":
			var player_hand: Dictionary = hands[0]
			var player_cards := _card_array(player_hand.get("cards", []))
			if not player_cards.is_empty() and low_index >= 0:
				var replaced_player: Dictionary = player_cards[0]
				player_cards[0] = shoe[low_index]
				shoe[low_index] = replaced_player
				player_hand["cards"] = player_cards
				hands[0] = player_hand
			if high_index >= 0:
				var replaced_upcard: Dictionary = dealer[0]
				dealer[0] = shoe[high_index]
				shoe[high_index] = replaced_upcard
		"hole_swap":
			if high_index >= 0:
				var replaced_hole: Dictionary = dealer[1]
				dealer[1] = shoe[high_index]
				shoe[high_index] = replaced_hole
	session["player_hands"] = hands
	session["dealer_cards"] = dealer
	session["shoe"] = shoe
	session["boss_edge_applied"] = str(edge.get("id", ""))


func _restore_rourke_edge_session(session: Dictionary) -> void:
	var original := _local_copy_dict(session.get("boss_edge_original", {}))
	if original.is_empty():
		return
	session["player_hands"] = _hand_array(original.get("player_hands", []))
	session["dealer_cards"] = _card_array(original.get("dealer_cards", []))
	session["shoe"] = _card_array(original.get("shoe", []))
	var hands := _hand_array(session.get("player_hands", []))
	if not hands.is_empty():
		session["initial_player_cards"] = _first_cards(_card_array((hands[0] as Dictionary).get("cards", [])), 2)
	session["initial_dealer_cards"] = _first_cards(_card_array(session.get("dealer_cards", [])), 2)
	session["count_challenge"] = {}
	session["count_answered"] = false
	session.erase("boss_edge_original")
	session.erase("boss_edge_applied")


func _rourke_shoe_card_index(shoe: Array, highest: bool) -> int:
	var best_index := -1
	var best_value := -1 if highest else 99
	for i in range(shoe.size()):
		if typeof(shoe[i]) != TYPE_DICTIONARY:
			continue
		var value := mini(10, int((shoe[i] as Dictionary).get("rank", 2)))
		if (highest and value > best_value) or (not highest and value < best_value):
			best_value = value
			best_index = i
	return best_index


func _first_cards(cards: Array, count: int) -> Array:
	var result: Array = []
	var limit: int = mini(maxi(0, count), cards.size())
	for i in range(limit):
		if typeof(cards[i]) == TYPE_DICTIONARY:
			result.append((cards[i] as Dictionary).duplicate(true))
	return result


func _build_shoe(deck_count: int, rng: RngStream) -> Array:
	return CardShoeScript.build_shoe(deck_count, rng)


func _deal_animation_event_array(value: Variant) -> Array:
	var events: Array = []
	for event_value in _dictionary_array(value):
		var event: Dictionary = event_value
		event["zone"] = str(event.get("zone", "player"))
		event["hand_index"] = int(event.get("hand_index", 0))
		event["card_index"] = int(event.get("card_index", 0))
		event["delay_msec"] = maxi(0, int(event.get("delay_msec", 0)))
		event["duration_msec"] = maxi(80, int(event.get("duration_msec", DEAL_CARD_DURATION_MSEC)))
		event["scale"] = maxf(0.35, float(event.get("scale", 0.62)))
		event["card"] = _local_copy_dict(event.get("card", {}))
		event["from"] = _event_point(_event_vector(event.get("from", []), DEAL_CARD_SHOE_POS))
		event["to"] = _event_point(_event_vector(event.get("to", []), Vector2(454, 224)))
		event["label"] = str(event.get("label", "card"))
		events.append(event)
	return events


func _surface_deal_animation_events(surface_state: Dictionary) -> Array:
	if str(surface_state.get("deal_animation_id", "")) == draw_deal_events_cache_id:
		return draw_deal_events_cache
	if surface_state.has(DRAW_DEAL_EVENTS_CACHE_KEY):
		var cached_value: Variant = surface_state.get(DRAW_DEAL_EVENTS_CACHE_KEY, [])
		if typeof(cached_value) != TYPE_ARRAY:
			return []
		var cached_events: Array = cached_value as Array
		return cached_events
	return _deal_animation_event_array(surface_state.get("deal_animation_events", []))


func _deal_animation_duration_msec(events: Array) -> int:
	var duration := 0
	for event_value in events:
		if typeof(event_value) != TYPE_DICTIONARY:
			continue
		var event: Dictionary = event_value
		duration = maxi(duration, int(event.get("delay_msec", 0)) + int(event.get("duration_msec", DEAL_CARD_DURATION_MSEC)) + 120)
	return duration


func _deal_presentation_active(session: Dictionary, now_msec: int = -1) -> bool:
	var animation_id := str(session.get("deal_animation_id", ""))
	if animation_id.is_empty():
		return false
	var events := _deal_animation_event_array(session.get("deal_animation_events", []))
	if events.is_empty():
		return false
	var started_msec := int(session.get("deal_started_msec", 0))
	if started_msec <= 0:
		return false
	now_msec = _blackjack_presentation_time_msec(session, now_msec)
	var duration_msec := _deal_animation_duration_msec(events)
	return now_msec >= started_msec and now_msec < started_msec + duration_msec


func _count_settlement_bubbles_pending(session: Dictionary, now_msec: int = -1) -> bool:
	if not bool(session.get("settlement_count_revealed", false)) or bool(session.get("count_answered", false)):
		return false
	var challenge_value: Variant = session.get("count_challenge", {})
	if typeof(challenge_value) != TYPE_DICTIONARY:
		return false
	var challenge: Dictionary = challenge_value as Dictionary
	if challenge.is_empty():
		return false
	now_msec = _surface_time_for_count(session, now_msec)
	var clicked := _string_array(challenge.get("clicked_icons", []))
	var missed := _string_array(challenge.get("missed_icons", []))
	for icon_value in _dictionary_array(challenge.get("icons", [])):
		var icon: Dictionary = icon_value
		var icon_id := str(icon.get("id", ""))
		if icon_id.is_empty() or clicked.has(icon_id) or missed.has(icon_id):
			continue
		var spawn_msec := int(icon.get("spawn_msec", now_msec))
		var duration_msec := int(icon.get("duration_msec", COUNT_ICON_DURATION_MSEC))
		if now_msec <= spawn_msec + duration_msec:
			return true
	return false


func _patron_action_event_array(value: Variant) -> Array:
	var events: Array = []
	for event_value in _dictionary_array(value):
		var event: Dictionary = event_value
		var action := str(event.get("action", "stand"))
		if not ["hit", "stand"].has(action):
			action = "stand"
		events.append({
			"patron_index": maxi(0, int(event.get("patron_index", 0))),
			"patron_id": str(event.get("patron_id", "")),
			"name": str(event.get("name", "Patron")),
			"action": action,
			"label": str(event.get("label", action.to_upper())),
			"reason": str(event.get("reason", "")),
			"total_before": maxi(0, int(event.get("total_before", 0))),
			"total_after": maxi(0, int(event.get("total_after", event.get("total_before", 0)))),
			"dealer_known_total": maxi(0, int(event.get("dealer_known_total", 0))),
			"peek_informed": bool(event.get("peek_informed", false)),
			"delay_msec": maxi(0, int(event.get("delay_msec", 0))),
			"duration_msec": maxi(120, int(event.get("duration_msec", PATRON_DECISION_HIGHLIGHT_MSEC))),
		})
	return events


func _patron_action_animation_duration_msec(events: Array) -> int:
	var duration := 0
	for event_value in events:
		if typeof(event_value) != TYPE_DICTIONARY:
			continue
		var event: Dictionary = event_value
		duration = maxi(duration, int(event.get("delay_msec", 0)) + int(event.get("duration_msec", PATRON_DECISION_HIGHLIGHT_MSEC)) + 120)
	return duration


func _settlement_next_deal_delay_msec(session: Dictionary, deal_events: Array) -> int:
	var delay := 0
	for event_value in deal_events:
		if typeof(event_value) != TYPE_DICTIONARY:
			continue
		var event: Dictionary = event_value
		delay = maxi(delay, int(event.get("delay_msec", 0)) + int(event.get("duration_msec", DEAL_CARD_DURATION_MSEC)))
	for event_value in _patron_action_event_array(session.get("patron_action_events", [])):
		var action_event: Dictionary = event_value
		delay = maxi(delay, int(action_event.get("delay_msec", 0)) + int(action_event.get("duration_msec", PATRON_DECISION_HIGHLIGHT_MSEC)))
	return delay + (PATRON_DECISION_STEP_DELAY_MSEC if delay > 0 else 0)


func _event_point(pos: Vector2) -> Array:
	return [pos.x, pos.y]


func _event_vector(value: Variant, fallback: Vector2) -> Vector2:
	if typeof(value) == TYPE_VECTOR2:
		return value
	if typeof(value) == TYPE_ARRAY:
		var parts: Array = value
		if parts.size() >= 2:
			return Vector2(float(parts[0]), float(parts[1]))
	if typeof(value) == TYPE_DICTIONARY:
		var dict: Dictionary = value
		return Vector2(float(dict.get("x", fallback.x)), float(dict.get("y", fallback.y)))
	return fallback


func _deal_animation_event(card_value: Variant, zone: String, hand_index: int, card_index: int, from_pos: Vector2, to_pos: Vector2, delay_msec: int, scale: float, label: String, duration_msec: int = DEAL_CARD_DURATION_MSEC) -> Dictionary:
	var card: Dictionary = _local_copy_dict(card_value)
	if card.is_empty():
		card = {"rank": 2, "suit": 0, "hidden": true}
	return {
		"zone": zone,
		"hand_index": hand_index,
		"card_index": card_index,
		"card": card,
		"from": _event_point(from_pos),
		"to": _event_point(to_pos),
		"delay_msec": maxi(0, delay_msec),
		"duration_msec": maxi(80, duration_msec),
		"scale": scale,
		"label": label,
	}


func _player_hand_base_position(hand_index: int) -> Vector2:
	var base_positions: Array = [Vector2(338, 248), Vector2(458, 248), Vector2(248, 282), Vector2(568, 282)]
	return base_positions[clampi(hand_index, 0, base_positions.size() - 1)]


func _player_hand_card_target(hand_index: int, card_index: int) -> Vector2:
	return _player_hand_base_position(hand_index) + Vector2(float(card_index) * 54.0 * PLAYER_CARD_SCALE, 0)


func _dealer_card_target(card_index: int) -> Vector2:
	return Vector2(386, 158) + Vector2(float(card_index) * 54.0 * DEALER_CARD_SCALE, 0)


func _patron_hand_card_target(patron_index: int, card_index: int) -> Vector2:
	return _patron_hand_base_position(patron_index) + Vector2(float(card_index) * 54.0 * PATRON_CARD_SCALE, 0)


func _patron_hand_base_position(patron_index: int) -> Vector2:
	var base := _patron_seat_position(patron_index)
	return base + Vector2(-28, 26)


func _initial_deal_animation_events(hands: Array, dealer_cards: Array, patron_hands: Array = []) -> Array:
	var events: Array = []
	var cards: Array = []
	if not hands.is_empty():
		var first_hand: Dictionary = hands[0]
		cards = _card_array(first_hand.get("cards", []))
	if cards.size() > 0:
		events.append(_deal_animation_event(cards[0], "player", 0, 0, DEAL_CARD_SHOE_POS, _player_hand_card_target(0, 0), DEAL_OPENING_FIRST_DELAY_MSEC, PLAYER_CARD_SCALE, "player first"))
	var dealer_delay := DEAL_OPENING_FIRST_DELAY_MSEC + DEAL_CARD_STAGGER_MSEC
	if cards.is_empty():
		dealer_delay = DEAL_OPENING_FIRST_DELAY_MSEC
	if dealer_cards.size() > 0:
		events.append(_deal_animation_event(dealer_cards[0], "dealer", 0, 0, DEAL_CARD_SHOE_POS, _dealer_card_target(0), dealer_delay, DEALER_CARD_SCALE, "dealer upcard"))
	if cards.size() > 1:
		events.append(_deal_animation_event(cards[1], "player", 0, 1, DEAL_CARD_SHOE_POS, _player_hand_card_target(0, 1), DEAL_OPENING_FIRST_DELAY_MSEC + DEAL_CARD_STAGGER_MSEC * 2, PLAYER_CARD_SCALE, "player second"))
	var hole_delay := DEAL_OPENING_FIRST_DELAY_MSEC + DEAL_CARD_STAGGER_MSEC * 3
	if cards.is_empty():
		hole_delay = DEAL_OPENING_FIRST_DELAY_MSEC + DEAL_CARD_STAGGER_MSEC
	if dealer_cards.size() > 1:
		var hole: Dictionary = (dealer_cards[1] as Dictionary).duplicate(true)
		hole["hidden"] = true
		events.append(_deal_animation_event(hole, "dealer", 0, 1, DEAL_CARD_SHOE_POS, _dealer_card_target(1), hole_delay, DEALER_CARD_SCALE, "hole card"))
	var delay := DEAL_OPENING_FIRST_DELAY_MSEC + DEAL_CARD_STAGGER_MSEC * 4
	if cards.is_empty():
		delay = DEAL_OPENING_FIRST_DELAY_MSEC + DEAL_CARD_STAGGER_MSEC * 2
	for patron_index in range(patron_hands.size()):
		var patron_hand: Dictionary = patron_hands[patron_index]
		var patron_cards: Array = _card_array(patron_hand.get("cards", []))
		for card_index in range(mini(patron_cards.size(), 2)):
			events.append(_deal_animation_event(patron_cards[card_index], "patron", patron_index, card_index, DEAL_CARD_SHOE_POS, _patron_hand_card_target(patron_index, card_index), delay, PATRON_CARD_SCALE, "patron card"))
			delay += int(float(DEAL_CARD_STAGGER_MSEC) * 0.72)
	return events


func _mark_deal_animation(session: Dictionary, suffix: String, events: Array = [], result_msec: int = -1) -> void:
	var started_msec := _blackjack_presentation_time_msec(session, result_msec)
	session["deal_animation_id"] = "%s:%s:%d" % [get_id(), suffix, started_msec]
	session["deal_started_msec"] = started_msec
	session["deal_animation_events"] = _deal_animation_event_array(events)


func _deal_to_active_hand(session: Dictionary, table: Dictionary) -> void:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if active_index < 0 or active_index >= hands.size():
		return
	var hand: Dictionary = hands[active_index]
	var cards: Array = _card_array(hand.get("cards", []))
	cards.append(_draw_card_from_session(session, table))
	var new_card_index := cards.size() - 1
	var new_card: Dictionary = (cards[new_card_index] as Dictionary).duplicate(true)
	hand["cards"] = cards
	hand["blackjack_eligible"] = false
	_mark_deal_animation(session, "hand_%d_card_%d" % [active_index, cards.size()], [
		_deal_animation_event(new_card, "player", active_index, new_card_index, DEAL_CARD_SHOE_POS, _player_hand_card_target(active_index, new_card_index), 0, PLAYER_CARD_SCALE, "hit card")
	])
	var total := _hand_total(cards)
	if _is_bust(cards):
		hand["stood"] = true
		hand["terminal_reason"] = "bust"
	elif total == 21:
		hand["stood"] = true
		hand["terminal_reason"] = "21"
	hands[active_index] = hand
	session["player_hands"] = hands
	session["moves_made"] = true


func _stand_active_hand(session: Dictionary) -> void:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if active_index >= 0 and active_index < hands.size():
		var hand: Dictionary = hands[active_index]
		hand["stood"] = true
		if str(hand.get("terminal_reason", "")).is_empty():
			hand["terminal_reason"] = "stand"
		hands[active_index] = hand
	session["player_hands"] = hands
	session["moves_made"] = true
	_advance_active_hand(session)


func _surrender_active_hand(session: Dictionary) -> void:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if active_index >= 0 and active_index < hands.size():
		var hand: Dictionary = hands[active_index]
		hand["stood"] = true
		hand["surrendered"] = true
		hand["terminal_reason"] = "surrender"
		hands[active_index] = hand
	session["player_hands"] = hands
	session["moves_made"] = true
	_advance_active_hand(session)


func _double_active_hand(session: Dictionary, table: Dictionary) -> void:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if active_index < 0 or active_index >= hands.size():
		return
	var hand: Dictionary = hands[active_index]
	hand["wager_multiplier"] = 2
	hand["doubled"] = true
	hands[active_index] = hand
	session["player_hands"] = hands
	_deal_to_active_hand(session, table)
	hands = _hand_array(session.get("player_hands", []))
	if active_index >= 0 and active_index < hands.size():
		hand = hands[active_index]
		hand["stood"] = true
		if str(hand.get("terminal_reason", "")).is_empty():
			hand["terminal_reason"] = "double"
		hands[active_index] = hand
	session["player_hands"] = hands
	session["moves_made"] = true
	_advance_active_hand(session)


func _split_active_hand(session: Dictionary, table: Dictionary) -> void:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if active_index < 0 or active_index >= hands.size():
		return
	var hand: Dictionary = hands[active_index]
	var cards: Array = _card_array(hand.get("cards", []))
	if cards.size() != 2:
		return
	var first_draw: Dictionary = _draw_card_from_session(session, table)
	var second_draw: Dictionary = _draw_card_from_session(session, table)
	var first_hand := {
		"cards": [cards[0], first_draw],
		"wager_multiplier": 1,
		"stood": false,
		"doubled": false,
		"split": true,
		"blackjack_eligible": _card_rank_value(cards[0]) == RANK_ACE,
	}
	var second_hand := {
		"cards": [cards[1], second_draw],
		"wager_multiplier": 1,
		"stood": false,
		"doubled": false,
		"split": true,
		"blackjack_eligible": _card_rank_value(cards[1]) == RANK_ACE,
	}
	hands.remove_at(active_index)
	hands.insert(active_index, second_hand)
	hands.insert(active_index, first_hand)
	session["player_hands"] = hands
	session["active_hand_index"] = active_index
	session["split_count"] = int(session.get("split_count", 0)) + 1
	var first_cards: Array = _card_array(first_hand.get("cards", []))
	var second_cards: Array = _card_array(second_hand.get("cards", []))
	var split_events: Array = [
		_deal_animation_event(cards[1], "player", active_index + 1, 0, _player_hand_card_target(active_index, 1), _player_hand_card_target(active_index + 1, 0), 0, PLAYER_CARD_SCALE, "split slide", 300),
	]
	if first_cards.size() > 1:
		split_events.append(_deal_animation_event(first_cards[1], "player", active_index, 1, DEAL_CARD_SHOE_POS, _player_hand_card_target(active_index, 1), 130, PLAYER_CARD_SCALE, "split first draw"))
	if second_cards.size() > 1:
		split_events.append(_deal_animation_event(second_cards[1], "player", active_index + 1, 1, DEAL_CARD_SHOE_POS, _player_hand_card_target(active_index + 1, 1), 315, PLAYER_CARD_SCALE, "split second draw"))
	_mark_deal_animation(session, "split_%d_%d" % [active_index, int(session.get("split_count", 0))], split_events)
	session["moves_made"] = true
	_autoadvance_finished_hands(session, table)


func _autoadvance_finished_hands(session: Dictionary, table: Dictionary) -> void:
	var _rules: Dictionary = _table_rules(table)
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = int(session.get("active_hand_index", 0))
	if active_index >= 0 and active_index < hands.size():
		var active: Dictionary = hands[active_index]
		var total := _hand_total(_card_array(active.get("cards", [])))
		if bool(active.get("stood", false)) or total >= 21:
			active["stood"] = true
			if str(active.get("terminal_reason", "")).is_empty():
				active["terminal_reason"] = "bust" if total > 21 else "21" if total == 21 else "stand"
			hands[active_index] = active
			session["player_hands"] = hands
			_advance_active_hand(session)


func _advance_active_hand(session: Dictionary) -> void:
	var hands: Array = _hand_array(session.get("player_hands", []))
	for i in range(hands.size()):
		var hand: Dictionary = hands[i]
		if not bool(hand.get("stood", false)) and not _is_bust(_card_array(hand.get("cards", []))):
			session["active_hand_index"] = i
			return
	session["active_hand_index"] = maxi(0, hands.size() - 1)


func _stand_all_hands(session: Dictionary) -> void:
	var hands: Array = _hand_array(session.get("player_hands", []))
	for i in range(hands.size()):
		var hand: Dictionary = hands[i]
		hand["stood"] = true
		if str(hand.get("terminal_reason", "")).is_empty():
			hand["terminal_reason"] = "stand"
		hands[i] = hand
	session["player_hands"] = hands
	session["active_hand_index"] = maxi(0, hands.size() - 1)


func _dealer_final_cards(session: Dictionary, table: Dictionary) -> Array:
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	# A counting settlement preview already played the complete dealer/patron
	# reveal. Resolution must reuse those cards without dealing or animating them
	# a second time behind the payout.
	if bool(session.get("settlement_preview_complete", false)):
		session["settlement_deal_animation_events"] = []
		return dealer_cards
	var rules: Dictionary = _table_rules(table)
	var settlement_events: Array = _dealer_hole_reveal_animation_events(dealer_cards)
	if _dealer_has_blackjack(dealer_cards):
		session["settlement_deal_animation_events"] = settlement_events
		session["dealer_cards"] = dealer_cards
		return dealer_cards
	settlement_events.append_array(_play_patron_hands_for_settlement(session, table))
	var dealer_draw_needed := false
	for hand_value in _hand_array(session.get("player_hands", [])):
		var hand: Dictionary = hand_value
		if not bool(hand.get("surrendered", false)) and not _is_natural_blackjack(hand):
			dealer_draw_needed = true
			break
	if not dealer_draw_needed:
		for patron_hand_value in _hand_array(session.get("patron_hands", [])):
			var patron_hand: Dictionary = patron_hand_value
			if not bool(patron_hand.get("surrendered", false)) and not _is_natural_blackjack(patron_hand):
				dealer_draw_needed = true
				break
	if not dealer_draw_needed:
		session["settlement_deal_animation_events"] = settlement_events
		session["dealer_cards"] = dealer_cards
		return dealer_cards
	var dealer_draw_base_delay := _settlement_next_deal_delay_msec(session, settlement_events)
	var dealer_draw_index := 0
	while true:
		var info: Dictionary = _hand_total_info(dealer_cards)
		var total: int = int(info.get("total", 0))
		var soft: bool = bool(info.get("soft", false))
		# Dealer line is table-driven: S17 stops here, H17 takes one more card.
		var should_hit := total < 17 or (total == 17 and soft and bool(rules.get("dealer_hits_soft_17", false)))
		if not should_hit:
			break
		dealer_cards.append(_draw_card_from_session(session, table))
		var new_card_index := dealer_cards.size() - 1
		var new_card: Dictionary = (dealer_cards[new_card_index] as Dictionary).duplicate(true)
		settlement_events.append(_deal_animation_event(new_card, "dealer", 0, new_card_index, DEAL_CARD_SHOE_POS, _dealer_card_target(new_card_index), dealer_draw_base_delay + dealer_draw_index * 145, DEALER_CARD_SCALE, "dealer draw"))
		dealer_draw_index += 1
	session["settlement_deal_animation_events"] = settlement_events
	session["dealer_cards"] = dealer_cards
	return dealer_cards


func _dealer_hole_reveal_animation_events(dealer_cards: Array) -> Array:
	if dealer_cards.size() < 2 or typeof(dealer_cards[1]) != TYPE_DICTIONARY:
		return []
	var hole_card: Dictionary = (dealer_cards[1] as Dictionary).duplicate(true)
	hole_card.erase("hidden")
	return [
		_deal_animation_event(
			hole_card,
			"dealer",
			0,
			1,
			_dealer_card_target(1),
			_dealer_card_target(1),
			DEAL_HOLE_REVEAL_DELAY_MSEC,
			DEALER_CARD_SCALE,
			"hole reveal",
			DEAL_HOLE_REVEAL_DURATION_MSEC
		)
	]


func _play_patron_hands_for_settlement(session: Dictionary, table: Dictionary) -> Array:
	var events: Array = []
	var action_events: Array = []
	var patron_hands: Array = _hand_array(session.get("patron_hands", []))
	session["patron_action_events"] = []
	if patron_hands.is_empty():
		return events
	var decision_delay := PATRON_DECISION_START_DELAY_MSEC
	for patron_index in range(patron_hands.size()):
		var hand: Dictionary = patron_hands[patron_index]
		var cards: Array = _card_array(hand.get("cards", []))
		while not cards.is_empty() and not _is_bust(cards):
			var decision: Dictionary = _patron_decision_for_hand(cards, hand, patron_index, session)
			var action := str(decision.get("action", "stand"))
			var total_before := _hand_total(cards)
			action_events.append(_patron_action_event(hand, patron_index, action, total_before, total_before, decision, decision_delay))
			decision_delay += PATRON_DECISION_STEP_DELAY_MSEC
			if action != "hit":
				break
			cards.append(_draw_card_from_session(session, table))
			var new_card_index := cards.size() - 1
			var new_card: Dictionary = (cards[new_card_index] as Dictionary).duplicate(true)
			var total_after := _hand_total(cards)
			var hit_event: Dictionary = action_events[action_events.size() - 1]
			hit_event["total_after"] = total_after
			action_events[action_events.size() - 1] = hit_event
			var card_delay := maxi(0, decision_delay - PATRON_DECISION_STEP_DELAY_MSEC + PATRON_HIT_CARD_DELAY_MSEC)
			events.append(_deal_animation_event(new_card, "patron", patron_index, new_card_index, DEAL_CARD_SHOE_POS, _patron_hand_card_target(patron_index, new_card_index), card_delay, PATRON_CARD_SCALE, "patron hit"))
			decision_delay = maxi(decision_delay, card_delay + DEAL_CARD_DURATION_MSEC + 120)
			if total_after >= 21:
				break
		hand["cards"] = cards
		hand["stood"] = true
		var total := _hand_total(cards)
		if total > 21:
			hand["terminal_reason"] = "bust"
		elif total == 21:
			hand["terminal_reason"] = "21"
		elif str(hand.get("terminal_reason", "")).is_empty():
			hand["terminal_reason"] = "stand"
		hand["last_action"] = "hit" if _patron_hand_hit_count(action_events, patron_index) > 0 else "stand"
		hand["last_action_label"] = str(_latest_patron_action_event(action_events, patron_index).get("label", str(hand.get("last_action", "stand")).to_upper()))
		hand["last_decision_reason"] = str(_latest_patron_action_event(action_events, patron_index).get("reason", ""))
		hand["peek_informed"] = bool(_latest_patron_action_event(action_events, patron_index).get("peek_informed", false))
		patron_hands[patron_index] = hand
	session["patron_hands"] = patron_hands
	session["patron_action_events"] = _patron_action_event_array(action_events)
	return events


func _patron_decision_for_hand(cards: Array, hand: Dictionary, patron_index: int, session: Dictionary) -> Dictionary:
	var baseline_hit := _patron_should_hit(cards, hand, patron_index)
	var total := _hand_total(cards)
	if cards.is_empty() or total > 21:
		return {"action": "stand", "reason": "locked", "peek_informed": false}
	if not _strategy_hole_card_advantage_active(session):
		return {
			"action": "hit" if baseline_hit else "stand",
			"reason": _patron_baseline_reason(hand, patron_index),
			"peek_informed": false,
		}
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	if dealer_cards.size() < 2:
		return {
			"action": "hit" if baseline_hit else "stand",
			"reason": _patron_baseline_reason(hand, patron_index),
			"peek_informed": false,
		}
	var dealer_total := _hand_total(_first_cards(dealer_cards, 2))
	if dealer_total >= 17 and dealer_total <= 21 and total < dealer_total:
		if total <= _patron_peek_chase_limit(hand, patron_index):
			return {
				"action": "hit",
				"reason": "known dealer %d beats %d" % [dealer_total, total],
				"peek_informed": true,
				"dealer_known_total": dealer_total,
			}
		return {
			"action": "stand",
			"reason": "won't chase dealer %d" % dealer_total,
			"peek_informed": true,
			"dealer_known_total": dealer_total,
		}
	if dealer_total >= 12 and dealer_total <= 16 and total >= 12:
		return {
			"action": "stand",
			"reason": "dealer stiff %d" % dealer_total,
			"peek_informed": true,
			"dealer_known_total": dealer_total,
		}
	return {
		"action": "hit" if baseline_hit else "stand",
		"reason": _patron_baseline_reason(hand, patron_index),
		"peek_informed": false,
		"dealer_known_total": dealer_total,
	}


func _patron_action_event(hand: Dictionary, patron_index: int, action: String, total_before: int, total_after: int, decision: Dictionary, delay_msec: int) -> Dictionary:
	var label := "HIT" if action == "hit" else "STAND"
	if bool(decision.get("peek_informed", false)):
		label = "PEEK %s" % label
	return {
		"patron_index": patron_index,
		"patron_id": str(hand.get("patron_id", "patron_%d" % patron_index)),
		"name": str(hand.get("name", "Patron")),
		"action": action,
		"label": label,
		"reason": str(decision.get("reason", "")),
		"total_before": total_before,
		"total_after": total_after,
		"dealer_known_total": int(decision.get("dealer_known_total", 0)),
		"peek_informed": bool(decision.get("peek_informed", false)),
		"delay_msec": delay_msec,
		"duration_msec": PATRON_DECISION_HIGHLIGHT_MSEC,
	}


func _latest_patron_action_event(events: Array, patron_index: int) -> Dictionary:
	for i in range(events.size() - 1, -1, -1):
		if typeof(events[i]) != TYPE_DICTIONARY:
			continue
		var event: Dictionary = events[i]
		if int(event.get("patron_index", -1)) == patron_index:
			return event
	return {}


func _patron_hand_hit_count(events: Array, patron_index: int) -> int:
	var hits := 0
	for event_value in events:
		if typeof(event_value) != TYPE_DICTIONARY:
			continue
		var event: Dictionary = event_value
		if int(event.get("patron_index", -1)) == patron_index and str(event.get("action", "")) == "hit":
			hits += 1
	return hits


func _patron_baseline_reason(hand: Dictionary, patron_index: int) -> String:
	var temper := str(hand.get("temper", "careless"))
	if temper == "sharp" or patron_index % 3 == 1:
		return "sharp table read"
	if temper == "nosy":
		return "nosy table read"
	return "table habit"


func _patron_peek_chase_limit(hand: Dictionary, patron_index: int) -> int:
	var temper := str(hand.get("temper", "careless"))
	if temper == "sharp" or patron_index % 3 == 1:
		return 18
	if temper == "nosy":
		return 17
	return 16


func _patron_should_hit(cards: Array, hand: Dictionary, patron_index: int) -> bool:
	if cards.is_empty() or _is_bust(cards):
		return false
	var total := _hand_total(cards)
	if total <= 11:
		return true
	if total >= 17:
		return false
	var temper := str(hand.get("temper", "careless"))
	var stand_total := 16
	if temper == "sharp" or patron_index % 3 == 1:
		stand_total = 17
	elif temper == "nosy":
		stand_total = 15
	return total < stand_total


func _settle_hand(hand: Dictionary, dealer_cards: Array, base_stake: int) -> Dictionary:
	var cards: Array = _card_array(hand.get("cards", []))
	var wager: int = maxi(1, base_stake) * maxi(1, int(hand.get("wager_multiplier", 1)))
	var player_total: int = _hand_total(cards)
	var dealer_total: int = _hand_total(dealer_cards)
	var player_blackjack: bool = _is_natural_blackjack(hand)
	var dealer_blackjack: bool = _dealer_has_blackjack(dealer_cards)
	var dealer_bust: bool = dealer_total > 21
	var outcome := "push"
	var delta := 0
	if bool(hand.get("surrendered", false)):
		outcome = "surrender"
		delta = -int(ceil(float(wager) * 0.5))
	elif player_blackjack and dealer_blackjack:
		outcome = "push"
	elif player_blackjack:
		outcome = "blackjack"
		# Naturals pay 3:2 in this sim. Bankroll is whole-dollar, so odd chip
		# wagers floor the half-dollar instead of switching to a 6:5 table.
		delta = maxi(1, int(floor(float(wager) * 1.5)))
	elif dealer_blackjack:
		outcome = "dealer_blackjack"
		delta = -wager
	elif player_total > 21:
		outcome = "bust"
		delta = -wager
	elif dealer_bust:
		outcome = "dealer_bust"
		delta = wager
	elif player_total > dealer_total:
		outcome = "win"
		delta = wager
	elif player_total < dealer_total:
		outcome = "lose"
		delta = -wager
	return {
		"outcome": outcome,
		"bankroll_delta": delta,
		"wager": wager,
		"player_total": player_total,
		"dealer_total": dealer_total,
		"doubled": bool(hand.get("doubled", false)),
		"split": bool(hand.get("split", false)),
		"surrendered": bool(hand.get("surrendered", false)),
		"blackjack": player_blackjack,
	}


func _settle_side_bets(session: Dictionary, table: Dictionary, dealer_cards: Array, stake: int, run_state: RunState) -> Array:
	var results: Array = []
	var active_ids: Array = _string_array(session.get("blackjack_side_bets", []))
	if active_ids.is_empty():
		return results
	var hands: Array = _hand_array(session.get("player_hands", []))
	if hands.is_empty():
		return results
	var first_hand: Dictionary = hands[0]
	var initial_player_cards: Array = _card_array(session.get("initial_player_cards", []))
	if initial_player_cards.is_empty():
		initial_player_cards = _first_cards(_card_array(first_hand.get("cards", [])), 2)
	var initial_dealer_cards: Array = _card_array(session.get("initial_dealer_cards", []))
	if initial_dealer_cards.is_empty():
		initial_dealer_cards = _first_cards(dealer_cards, 2)
	var available: Array = _available_side_bets_for_session(table, session)
	for bet in available:
		var bet_id := str(bet.get("id", ""))
		if not active_ids.has(bet_id):
			continue
		var bet_stake: int = _side_bet_stake(stake, bet, run_state)
		var dealer_cards_for_bet: Array = dealer_cards if bet_id == "buster" else initial_dealer_cards
		var settled: Dictionary = _side_bet_result(bet, initial_player_cards, dealer_cards_for_bet, bet_stake, run_state)
		results.append(settled)
	return results


func _side_bet_result(bet: Dictionary, player_cards: Array, dealer_cards: Array, bet_stake: int, run_state: RunState) -> Dictionary:
	var bet_id := str(bet.get("id", ""))
	var payout_mult := 0
	var detail := "miss"
	match bet_id:
		"perfect_pairs":
			var pair: Dictionary = _perfect_pairs_payout(player_cards)
			payout_mult = int(pair.get("payout", 0))
			detail = str(pair.get("detail", "miss"))
		"twenty_one_three":
			var combo: Dictionary = _twenty_one_three_payout(player_cards, dealer_cards)
			payout_mult = int(combo.get("payout", 0))
			detail = str(combo.get("detail", "miss"))
		"lucky_ladies":
			var ladies: Dictionary = _lucky_ladies_payout(player_cards, dealer_cards)
			payout_mult = int(ladies.get("payout", 0))
			detail = str(ladies.get("detail", "miss"))
		"royal_match":
			var royal: Dictionary = _royal_match_payout(player_cards)
			payout_mult = int(royal.get("payout", 0))
			detail = str(royal.get("detail", "miss"))
		"insurance":
			var insurance: Dictionary = _insurance_payout(dealer_cards)
			payout_mult = int(insurance.get("payout", 0))
			detail = str(insurance.get("detail", "miss"))
		"buster":
			var buster: Dictionary = _buster_payout(dealer_cards)
			payout_mult = int(buster.get("payout", 0))
			detail = str(buster.get("detail", "miss"))
	var payout_multiplier := 1
	if bet_id == "lucky_ladies":
		payout_multiplier = maxi(1, _item_effect_total("blackjack_lucky_ladies_payout_multiplier", run_state))
		if payout_mult > 0 and payout_multiplier > 1:
			payout_mult *= payout_multiplier
			detail = "%s, compact doubled" % detail
	var bonus_mult: int = _item_effect_total("blackjack_side_bet_bonus", run_state)
	if payout_mult > 0:
		payout_mult += bonus_mult
	var loss_reduction: int = _item_effect_total("blackjack_side_bet_loss_reduction", run_state)
	var delta := (bet_stake * payout_mult) if payout_mult > 0 else -maxi(0, bet_stake - loss_reduction)
	return {
		"id": bet_id,
		"label": str(bet.get("label", bet_id)),
		"stake": bet_stake,
		"payout_mult": payout_mult,
		"item_payout_multiplier": payout_multiplier,
		"bankroll_delta": delta,
		"won": payout_mult > 0,
		"detail": detail,
	}


func _counter_observation_samples(value: Variant) -> Array:
	var samples: Array = []
	if typeof(value) != TYPE_ARRAY:
		return samples
	for sample_value in value as Array:
		if typeof(sample_value) != TYPE_DICTIONARY:
			continue
		var sample := sample_value as Dictionary
		var bet := maxi(1, int(sample.get("bet", 1)))
		samples.append({
			"count": clampi(int(sample.get("count", 0)), -52, 52),
			"bet": bet,
		})
	while samples.size() > COUNTER_SURVEILLANCE_SAMPLE_LIMIT:
		samples.pop_front()
	return samples


func _counter_bet_count_correlation(samples: Array) -> float:
	if samples.size() < 3:
		return 0.0
	var count_mean := 0.0
	var bet_mean := 0.0
	for sample_value in samples:
		var sample: Dictionary = sample_value
		count_mean += float(sample.get("count", 0))
		bet_mean += float(sample.get("bet", 1))
	count_mean /= float(samples.size())
	bet_mean /= float(samples.size())
	var covariance := 0.0
	var count_variance := 0.0
	var bet_variance := 0.0
	for sample_value in samples:
		var sample: Dictionary = sample_value
		var count_offset := float(sample.get("count", 0)) - count_mean
		var bet_offset := float(sample.get("bet", 1)) - bet_mean
		covariance += count_offset * bet_offset
		count_variance += count_offset * count_offset
		bet_variance += bet_offset * bet_offset
	if count_variance <= 0.0001 or bet_variance <= 0.0001:
		return 0.0
	return clampf(covariance / sqrt(count_variance * bet_variance), -1.0, 1.0)


# Casinos cannot see a mental running count. They can see wagers and decisions,
# then compare those observations with the shoe over time. This assessment keeps
# that distinction explicit: accurate flat betting is invisible; a count-shaped
# wager ramp, a sustained bet/count correlation, or repeated visible misses adds
# evidence. The bounded window is long enough to cover many hands without making
# save size or assessment cost grow with session length.
func _counter_surveillance_for_hand(session: Dictionary, table: Dictionary, stake: int) -> Dictionary:
	var challenge: Dictionary = _local_copy_dict(session.get("count_challenge", {}))
	var missed_count := (_string_array(challenge.get("missed_icons", []))).size()
	var bad_hits := maxi(0, int(challenge.get("bad_hits", 0)))
	var target_delta := int(challenge.get("target_delta", 0))
	var declared_delta := int(session.get("count_delta", challenge.get("recorded_delta", 0)))
	var count_distance: int = absi(target_delta - declared_delta)
	var error_units := clampi(maxi(missed_count + bad_hits, count_distance), 0, 8)
	if not bool(session.get("count_correct", false)) and error_units == 0:
		error_units = 1

	var samples := _counter_observation_samples(table.get("counter_observation_samples", []))
	var previous: Dictionary = samples[-1] if not samples.is_empty() else {}
	var true_count := clampi(int(table.get("running_count", 0)), -52, 52)
	var wager := maxi(1, stake)
	samples.append({"count": true_count, "bet": wager})
	while samples.size() > COUNTER_SURVEILLANCE_SAMPLE_LIMIT:
		samples.pop_front()
	var observed_hands := maxi(0, int(table.get("counter_observation_hands", 0))) + 1
	var previous_bet := maxi(1, int(previous.get("bet", wager)))
	var previous_count := int(previous.get("count", true_count))
	var bet_delta := wager - previous_bet
	var bet_signal_heat := 0
	var signal_reasons: Array[String] = []
	if not previous.is_empty():
		var meaningful_increase := bet_delta >= maxi(2, int(ceil(float(previous_bet) * 0.50)))
		var meaningful_decrease := -bet_delta >= maxi(2, int(ceil(float(previous_bet) * 0.40)))
		if true_count >= 2 and meaningful_increase:
			bet_signal_heat = 2 + mini(2, int(floor(float(true_count) / 2.0)))
			if wager >= previous_bet * 2:
				bet_signal_heat += 1
			signal_reasons.append("the wager rose with a favorable shoe")
		elif previous_count >= 2 and true_count <= 0 and meaningful_decrease:
			bet_signal_heat = 2
			signal_reasons.append("the wager fell as the shoe cooled")
		elif true_count - previous_count >= 2 and meaningful_increase:
			bet_signal_heat = 1
			signal_reasons.append("the wager tracked a rising count")

	var min_bet := wager
	var max_bet := wager
	for sample_value in samples:
		var sample: Dictionary = sample_value
		var sample_bet := maxi(1, int(sample.get("bet", 1)))
		min_bet = mini(min_bet, sample_bet)
		max_bet = maxi(max_bet, sample_bet)
	var bet_spread := float(max_bet) / float(maxi(1, min_bet))
	var correlation := _counter_bet_count_correlation(samples)
	var correlation_heat := 0
	if bet_delta != 0 and observed_hands >= COUNTER_SURVEILLANCE_MIN_HANDS and samples.size() >= COUNTER_SURVEILLANCE_MIN_HANDS and bet_spread >= 2.0:
		if correlation >= COUNTER_SURVEILLANCE_STRONG_CORRELATION and bet_spread >= 3.0:
			correlation_heat = 3
			signal_reasons.append("surveillance confirms a strong count-to-bet pattern")
		elif correlation >= COUNTER_SURVEILLANCE_CORRELATION_THRESHOLD:
			correlation_heat = 1
			signal_reasons.append("surveillance sees a developing count-to-bet pattern")

	var prior_miss_streak := maxi(0, int(table.get("counter_miss_streak", 0)))
	var miss_streak := prior_miss_streak + 1 if error_units > 0 else 0
	var miss_heat := 0
	if error_units > 0:
		miss_heat = mini(COUNTER_SURVEILLANCE_MAX_MISS_HEAT, 1 + maxi(0, error_units - 1) * 2 + mini(2, prior_miss_streak))
		signal_reasons.append("visible count errors draw dealer attention")

	var evidence_add := bet_signal_heat + correlation_heat + (2 if miss_streak >= 2 else 1 if error_units > 0 else 0)
	var evidence_points := clampi(int(table.get("counter_evidence_points", 0)) + evidence_add, 0, 100)
	var significant_pattern := bet_signal_heat >= 3 or correlation_heat >= 3 or (miss_streak >= 2 and miss_heat >= 3)
	var catch_chance := 0
	if observed_hands >= COUNTER_SURVEILLANCE_MIN_HANDS and (bet_signal_heat > 0 or correlation_heat > 0):
		catch_chance = clampi(4 + evidence_points / 2 + bet_signal_heat * 3 + correlation_heat * 4, 0, 58)
	elif miss_streak >= 3:
		catch_chance = clampi(3 + evidence_points / 3, 0, 24)
	var heat := clampi(bet_signal_heat + correlation_heat + miss_heat, 0, 10)
	return {
		"observed_hands": observed_hands,
		"samples": samples,
		"true_count_at_bet": true_count,
		"current_bet": wager,
		"previous_bet": previous_bet,
		"bet_delta": bet_delta,
		"bet_spread": bet_spread,
		"correlation": correlation,
		"bet_signal_heat": bet_signal_heat,
		"correlation_heat": correlation_heat,
		"miss_heat": miss_heat,
		"error_units": error_units,
		"missed_icons": missed_count,
		"bad_hits": bad_hits,
		"miss_streak": miss_streak,
		"evidence_add": evidence_add,
		"evidence_points": evidence_points,
		"heat": heat,
		"catch_chance": catch_chance,
		"significant_pattern": significant_pattern,
		"signal_reasons": signal_reasons,
	}


func _cheat_detection_for_hand(session: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary, rng: RngStream, stake: int) -> Dictionary:
	var cheats: Dictionary = _local_copy_dict(session.get("cheats_used", {}))
	var used_peek: bool = bool(cheats.get("peek_hole_card", false))
	var used_count: bool = bool(cheats.get("count_cards", false)) or bool(session.get("count_attempted", false)) or bool(session.get("count_answered", false))
	var strategy_events: Array = _dictionary_array(session.get("strategy_deviation_events", []))
	var used_strategy := not strategy_events.is_empty()
	if not used_peek and not used_count and not used_strategy:
		return {"suspicion_delta": 0, "caught": false, "message": ""}
	var base_heat := 0
	var catch_chance := 0
	var ordinary_strategy_count := 0
	var count_advantage_score := 0
	var hole_card_advantage_score := 0
	var counter_surveillance: Dictionary = {}
	for event_value in strategy_events:
		var event: Dictionary = event_value
		var information_source := str(event.get("information_source", "ordinary"))
		var event_score := maxi(1, int(event.get("score", 1)))
		match information_source:
			"count":
				count_advantage_score += event_score
			"hole_card":
				hole_card_advantage_score += event_score
			_:
				ordinary_strategy_count += 1
	var advantage_strategy_score := count_advantage_score + hole_card_advantage_score
	if used_peek:
		catch_chance = maxi(catch_chance, int(table.get("dealer_catch_base", 10)))
		var snitch_risk: int = _patron_snitch_risk(table, session)
		var dealer_focus: Dictionary = _dealer_focus_state(table, session, run_state, snitch_risk)
		base_heat += 5
		catch_chance += 8
		if bool(session.get("peek_had_window", false)):
			catch_chance -= 10
			base_heat = maxi(1, base_heat - 3)
		else:
			base_heat += 14
			catch_chance += 28
		catch_chance += int(float(int(dealer_focus.get("attention_meter", 0))) / 8.0)
		if snitch_risk > 0:
			base_heat += int(ceil(float(snitch_risk) / 12.0))
			catch_chance += int(ceil(float(snitch_risk) / 4.0))
	if used_count:
		counter_surveillance = _counter_surveillance_for_hand(session, table, stake)
		base_heat += int(counter_surveillance.get("heat", 0))
		catch_chance = maxi(catch_chance, int(counter_surveillance.get("catch_chance", 0)))
		if int(counter_surveillance.get("heat", 0)) > 0:
			base_heat += _item_effect_total("blackjack_count_heat_delta", run_state)
	if used_strategy:
		var profile: Dictionary = _local_copy_dict(table.get("dealer_profile", {}))
		var response := str(profile.get("strategy_response", "watch"))
		var scrutiny := clampi(int(profile.get("strategy_scrutiny", 10)), 0, 30)
		if ordinary_strategy_count > 0:
			# A player who simply does not know the book receives only a faint signal.
			base_heat += mini(ORDINARY_STRATEGY_HEAT_MAX, ordinary_strategy_count)
			catch_chance += mini(6, ordinary_strategy_count * 2 + int(float(scrutiny) / 12.0))
		if count_advantage_score > 0:
			base_heat += COUNT_ADVANTAGE_BASE_HEAT + count_advantage_score * 3
			catch_chance = maxi(catch_chance, int(table.get("dealer_catch_base", 10)))
			catch_chance += 14 + count_advantage_score * 8 + int(float(scrutiny) / 3.0)
		if hole_card_advantage_score > 0:
			base_heat += HOLE_CARD_ADVANTAGE_BASE_HEAT + hole_card_advantage_score * 4
			catch_chance = maxi(catch_chance, int(table.get("dealer_catch_base", 10)))
			catch_chance += 20 + hole_card_advantage_score * 9 + int(float(scrutiny) / 2.0)
		if advantage_strategy_score > 0 and response == "heat":
			base_heat += 5
		elif advantage_strategy_score > 0 and response == "both":
			base_heat += 3
		if bool(session.get("strategy_confronted", false)):
			base_heat += clampi(int(session.get("strategy_confrontation_heat", 0)), 0, STRATEGY_DEVIATION_MAX_HEAT)
			catch_chance += 20 if advantage_strategy_score > 0 else 4
	var count_pattern_exposed := bool(counter_surveillance.get("significant_pattern", false))
	var blatant_advantage_play := used_peek or count_pattern_exposed or advantage_strategy_score > 0
	if blatant_advantage_play:
		base_heat += run_state.security_risk_bonus("cheat")
		catch_chance += run_state.security_risk_bonus("cheat") * 2
	var pit_boss: Dictionary = run_state.pit_boss_watch_status(environment)
	var pit_boss_heat_bonus := 0
	if blatant_advantage_play and bool(pit_boss.get("active", false)):
		pit_boss_heat_bonus = int(pit_boss.get("cheat_heat_bonus", 0))
		catch_chance += pit_boss_heat_bonus
		base_heat += pit_boss_heat_bonus
	# Universal concealment gear reduces visible heat from any risky blackjack
	# behavior. Keep an accurate, flat-bet mental count at zero, but do not skip
	# the modifier merely because a first visible count error has not yet grown
	# into a sustained surveillance pattern.
	if base_heat > 0:
		base_heat += _item_effect_total("cheat_suspicion_delta", run_state)
	if used_peek:
		base_heat += _item_effect_total("blackjack_peek_heat_delta", run_state)
	catch_chance += _item_effect_total("blackjack_dealer_catch_chance", run_state)
	catch_chance = run_state.crew_play_adjust_detection_chance(clampi(catch_chance, 0, 95), environment)
	var strategy_confronted := bool(session.get("strategy_confronted", false))
	var caught := strategy_confronted or rng.randi_range(1, 100) <= catch_chance
	var heat := maxi(0, base_heat)
	if caught:
		var catch_heat_bonus := maxi(6, int(table.get("catch_heat", 18)))
		if used_count and not used_peek and hole_card_advantage_score <= 0:
			catch_heat_bonus = COUNTER_SURVEILLANCE_CAUGHT_BONUS + mini(3, int(counter_surveillance.get("evidence_points", 0)) / 20)
		if not blatant_advantage_play:
			catch_heat_bonus = 1
		heat += catch_heat_bonus
	heat = run_state.crew_play_adjust_suspicion(heat, get_id(), environment)
	var message := "The dealer confronts the off-book line." if strategy_confronted else "The dealer clocks the move." if caught else "The risky move slides by."
	if used_count and not caught and int(counter_surveillance.get("heat", 0)) == 0 and advantage_strategy_score == 0 and not used_peek:
		message = "The count stays mental; the dealer sees an ordinary wager."
	elif used_count and bool(session.get("count_correct", false)) and advantage_strategy_score > 0:
		message = "%s The count lands clean, but the information-driven play gives it away." % message
	elif used_count and bool(session.get("count_correct", false)):
		message = "%s The count lands clean." % message
	elif used_count:
		message = "%s The count drifts." % message
	if used_strategy and not strategy_confronted:
		message = "%s The odd strategy line is noted." % message
	return {
		"suspicion_delta": heat,
		"caught": caught,
		"catch_chance": catch_chance,
		"message": message,
		"used_peek": used_peek,
		"used_count": used_count,
		"used_strategy_deviation": used_strategy,
		"ordinary_strategy_count": ordinary_strategy_count,
		"count_advantage_score": count_advantage_score,
		"hole_card_advantage_score": hole_card_advantage_score,
		"advantage_play": blatant_advantage_play,
		"strategy_confronted": strategy_confronted,
		"strategy_deviation_events": strategy_events,
		"counter_surveillance": counter_surveillance,
		"pit_boss_watched": bool(pit_boss.get("watched", false)),
		"pit_boss_heat_bonus": pit_boss_heat_bonus,
		"stake": stake,
	}


func _blackjack_item_adjustment(main_delta: int, side_delta: int, session: Dictionary, run_state: RunState, stake: int) -> Dictionary:
	# Passive blackjack item effects are resolved here after main and side-bet
	# payouts are known. New result modifiers should add one effect key instead
	# of branching through the hand settlement flow.
	var main_adjust := 0
	var side_adjust := 0
	var cheats: Dictionary = _local_copy_dict(session.get("cheats_used", {}))
	if main_delta > 0:
		main_adjust += run_state.luck_payout_bonus(stake, true) if run_state != null else 0
		main_adjust += _item_effect_total("win_bonus", run_state)
		main_adjust += _item_effect_total("blackjack_win_bonus", run_state)
		if bool(session.get("count_correct", false)):
			main_adjust += _item_effect_total("blackjack_count_edge_bonus", run_state)
	elif main_delta < 0:
		main_adjust += mini(-main_delta, _item_effect_total("loss_reduction", run_state))
		main_adjust += mini(maxi(0, -main_delta - main_adjust), _item_effect_total("blackjack_loss_reduction", run_state))
		if bool(cheats.get("peek_hole_card", false)):
			main_adjust += mini(maxi(0, -main_delta - main_adjust), _item_effect_total("blackjack_peek_loss_reduction", run_state))
	if side_delta > 0:
		side_adjust += _item_effect_total("blackjack_side_bet_flat_bonus", run_state)
	return {
		"main_delta": main_adjust,
		"side_delta": side_adjust,
		"summary": "Blackjack gear adjusted the result." if main_adjust != 0 or side_adjust != 0 else "",
		"stake": stake,
	}


func _persist_counter_surveillance(table: Dictionary, cheat: Dictionary) -> void:
	var assessment_value: Variant = cheat.get("counter_surveillance", {})
	if typeof(assessment_value) != TYPE_DICTIONARY or (assessment_value as Dictionary).is_empty():
		return
	var assessment := assessment_value as Dictionary
	table["counter_observation_hands"] = maxi(0, int(assessment.get("observed_hands", table.get("counter_observation_hands", 0))))
	table["counter_observation_samples"] = _counter_observation_samples(assessment.get("samples", []))
	table["counter_evidence_points"] = clampi(int(assessment.get("evidence_points", table.get("counter_evidence_points", 0))), 0, 100)
	table["counter_miss_streak"] = maxi(0, int(assessment.get("miss_streak", 0)))
	# Keep the diagnostic payload compact and save-safe. The full sample window is
	# already stored separately; last assessment is for UI/test explainability.
	table["counter_last_assessment"] = {
		"true_count_at_bet": int(assessment.get("true_count_at_bet", 0)),
		"current_bet": int(assessment.get("current_bet", 0)),
		"previous_bet": int(assessment.get("previous_bet", 0)),
		"bet_delta": int(assessment.get("bet_delta", 0)),
		"bet_spread": float(assessment.get("bet_spread", 1.0)),
		"correlation": float(assessment.get("correlation", 0.0)),
		"error_units": int(assessment.get("error_units", 0)),
		"heat": int(assessment.get("heat", 0)),
		"catch_chance": int(assessment.get("catch_chance", 0)),
		"evidence_points": int(assessment.get("evidence_points", 0)),
		"significant_pattern": bool(assessment.get("significant_pattern", false)),
	}


func _update_table_after_hand(table: Dictionary, session: Dictionary, dealer_cards: Array, actual_count_delta: int, count_record_delta: int, rng: RngStream, result_msec: int = 0, cheat: Dictionary = {}) -> void:
	var deck_count := int(table.get("deck_count", 6))
	var cut_card_remaining := int(table.get("cut_card_remaining", CardShoeScript.cut_card_remaining(deck_count)))
	var remaining_shoe: Array = _remaining_shoe_after_session(table, session)
	table["hands_played"] = int(table.get("hands_played", 0)) + 1
	GameModule.reset_table_round_timer(table)
	table["running_count"] = int(table.get("running_count", 0)) + actual_count_delta
	_persist_counter_surveillance(table, cheat)
	if bool(session.get("count_answered", false)):
		table["recorded_running_count"] = int(table.get("recorded_running_count", 0)) + count_record_delta
		table["recorded_count_shoe_generation"] = maxi(1, int(table.get("shoe_generation", 1)))
	if bool(session.get("count_correct", false)):
		table["count_accuracy_streak"] = int(table.get("count_accuracy_streak", 0)) + 1
	elif bool(session.get("count_answered", false)):
		table["count_accuracy_streak"] = 0
	var strategy_events: Array = _dictionary_array(session.get("strategy_deviation_events", []))
	var strategy_score := maxi(0, int(session.get("strategy_deviation_score", 0)))
	var profile: Dictionary = _local_copy_dict(table.get("dealer_profile", {}))
	var advantage_strategy_score := 0
	for event_value in strategy_events:
		var event: Dictionary = event_value
		if str(event.get("information_source", "ordinary")) != "ordinary":
			advantage_strategy_score += maxi(1, int(event.get("score", 1)))
	if strategy_score > 0:
		# Ordinary mistakes can cause a brief look this hand, but only decisions
		# that reveal count/hole-card knowledge build persistent table scrutiny.
		table["strategy_deviation_strikes"] = maxi(0, int(table.get("strategy_deviation_strikes", 0))) + advantage_strategy_score
		var response := str(profile.get("strategy_response", "watch"))
		var watch_add := clampi(int(session.get("strategy_attention_boost", 0)), 0, STRATEGY_DEVIATION_MAX_WATCH) if advantage_strategy_score > 0 else 0
		if response == "heat":
			watch_add = int(ceil(float(watch_add) * 0.45))
		elif response == "both":
			watch_add = int(ceil(float(watch_add) * 0.70))
		table["strategy_watch_pressure"] = clampi(int(table.get("strategy_watch_pressure", 0)) + watch_add, 0, STRATEGY_DEVIATION_MAX_WATCH)
		table["strategy_last_notice"] = "Dealer questioned %d information-driven play%s." % [strategy_events.size(), "" if strategy_events.size() == 1 else "s"] if advantage_strategy_score > 0 else "Dealer noted an ordinary off-book play."
		if bool(session.get("strategy_confronted", false)):
			profile["attention_base"] = clampi(int(profile.get("attention_base", 12)) + 3, 8, 70)
			table["dealer_profile"] = profile
	else:
		table["strategy_watch_pressure"] = clampi(int(table.get("strategy_watch_pressure", 0)) - 2, 0, STRATEGY_DEVIATION_MAX_WATCH)
	if remaining_shoe.is_empty() or remaining_shoe.size() <= cut_card_remaining:
		var shuffle_rng := rng.fork("blackjack_shuffle:%d" % int(table.get("hands_played", 0)))
		remaining_shoe = _build_shoe(deck_count, shuffle_rng)
		table["shoe_cursor"] = 0
		table["running_count"] = 0
		table["recorded_running_count"] = 0
		table["shoe_generation"] = maxi(1, int(table.get("shoe_generation", 1))) + 1
		table["recorded_count_shoe_generation"] = 0
		table["last_shuffle_hand"] = int(table.get("hands_played", 0))
		table["last_result"] = {"summary": "Shoe shuffled.", "dealer_cards": dealer_cards}
	else:
		table["shoe_cursor"] = 0
		table["last_result"] = {"summary": "Hand settled.", "dealer_cards": dealer_cards}
	table["shoe"] = remaining_shoe
	table["shoe_remaining"] = CardShoeScript.remaining_count(remaining_shoe)
	table["shoe_composition"] = CardShoeScript.remaining_composition(remaining_shoe)
	table["cut_card_remaining"] = clampi(cut_card_remaining, 1, deck_count * CardShoeScript.CARDS_PER_DECK)
	table["cut_card_at"] = deck_count * CardShoeScript.CARDS_PER_DECK - int(table.get("cut_card_remaining", cut_card_remaining))
	table["shoe_label"] = CardShoeScript.shoe_label(deck_count)
	table["count_efficiency"] = CardShoeScript.count_efficiency_label(deck_count)
	table["last_deal_animation_id"] = "%s:%d" % [get_id(), int(table.get("hands_played", 0))]
	table["last_deal_started_msec"] = maxi(0, result_msec)
	table["last_deal_animation_events"] = _deal_animation_event_array(session.get("settlement_deal_animation_events", []))
	table["last_patron_action_events"] = _patron_action_event_array(session.get("patron_action_events", []))


func _update_environment_table(environment: Dictionary, table: Dictionary) -> void:
	var game_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	game_states[get_id()] = _duplicate_table_with_immutable_authority(table)
	environment["game_states"] = game_states


# Authority operations use copy-on-write containers and never mutate cached
# response or journal values in place. Preserve those immutable values across
# the table's otherwise defensive deep copy so repeated play does not clone the
# complete replay window every time the table is normalized or stored.
func _duplicate_table_with_immutable_authority(table: Dictionary) -> Dictionary:
	var source := table.duplicate(false)
	var authority_value: Variant = source.get(BLACKJACK_HOST_LEDGER_KEY, null)
	source.erase(BLACKJACK_HOST_LEDGER_KEY)
	var copy := source.duplicate(true)
	if typeof(authority_value) == TYPE_DICTIONARY:
		copy[BLACKJACK_HOST_LEDGER_KEY] = (authority_value as Dictionary).duplicate(false)
	return copy


func _action_command(action_id: String, action_kind: String, confirm_requested: bool, ui_state: Dictionary, index: int, message: String, resolve_when_selected: bool, preserve_surface_ui_state: bool = false, force_resolve: bool = false) -> Dictionary:
	var already_selected := str(ui_state.get("selected_action_id", "")) == action_id and str(ui_state.get("selected_action_kind", "")) == action_kind
	if not message.is_empty():
		ui_state["table_notice"] = message
	var compact_state: Dictionary = _compact_session_for_ui(ui_state)
	return GameModule.surface_command({
		"handled": true,
		"ui_state": compact_state,
		"action_id": action_id,
		"action_kind": action_kind,
		"resolve": force_resolve or confirm_requested or (already_selected and resolve_when_selected),
		# Resolving Peek already carries a sealed delivery and exact stake. Do not
		# rebuild the whole room/action selection just before consuming it.
		"direct_resolve": action_id == "peek_hole_card" and (force_resolve or confirm_requested or (already_selected and resolve_when_selected)),
		"preserve_surface_ui_state": preserve_surface_ui_state,
		"selected_index": index,
		"message": message,
	})


func _additional_hand_wager_command(session: Dictionary, index: int, message: String) -> Dictionary:
	# Keep the existing paid hand, shoe, sibling and ritual phase. Only the
	# difference from wager_debited is charged by the sealed placement resolver.
	session["incremental_hand_wager"] = true
	var command := _action_command(BLACKJACK_CHARGED_DEAL_ACTION, "legal", true, session, index, message, true, true, true)
	command["direct_resolve"] = true
	command["skip_stake_validation"] = true
	return command


func _opening_deal_command(ui_state: Dictionary, index: int, message: String) -> Dictionary:
	if not message.is_empty():
		ui_state["table_notice"] = message
	# Interactive surfaces always carry the simulation clock. Headless rules
	# probes may omit it and should remain free to advance actions synchronously.
	ui_state["presentation_timing_enforced"] = ui_state.has("surface_time_msec")
	var compact_state: Dictionary = _compact_session_for_ui(ui_state)
	return GameModule.surface_command({
		"handled": true,
		"ui_state": compact_state,
		"selected_index": index,
		"message": message,
	})


func _message_command(ui_state: Dictionary, message: String) -> Dictionary:
	if not message.is_empty():
		ui_state["table_notice"] = message
	var compact_state: Dictionary = _compact_session_for_ui(ui_state)
	return GameModule.surface_command({
		"handled": true,
		"ui_state": compact_state,
		"selected_index": int(ui_state.get("active_hand_index", 0)),
		"message": message,
	})


func _wager_edit_command(ui_state: Dictionary, index: int, stake: int, message: String) -> Dictionary:
	# A successful draft edit replaces any notice about the preceding wager.
	# Keep the raw session and existing stake payload, including edit history.
	ui_state["table_notice"] = message
	return GameModule.surface_command({
		"handled": true,
		"ui_state": ui_state,
		"set_stake": stake,
		"selected_index": index,
		"message": message,
	})


func _settle_completed_round_command(ui_state: Dictionary, index: int, message: String, table: Dictionary, run_state: RunState) -> Dictionary:
	if bool(ui_state.get("presentation_timing_enforced", false)) and _deal_presentation_active(ui_state):
		ui_state["round_terminal"] = true
		ui_state["settlement_pending"] = true
		var reveal_message := "%s Cards finish moving before the payout." % message
		ui_state["table_notice"] = reveal_message
		return _message_command(ui_state, reveal_message)
	if _count_settlement_preview_required(ui_state):
		_prepare_count_settlement_preview(ui_state, table, run_state)
		var preview_message := "Dealer reveals the table. Count every exposed card, then settle."
		ui_state["table_notice"] = preview_message
		return _message_command(ui_state, preview_message)
	ui_state["dealer_hole_visible"] = true
	ui_state["round_terminal"] = true
	ui_state["settlement_pending"] = true
	ui_state["table_notice"] = message
	var command := _action_command("play_basic", "legal", true, ui_state, index, message, true, false, true)
	command["skip_stake_validation"] = true
	return command


func _count_settlement_preview_required(ui_state: Dictionary) -> bool:
	if bool(ui_state.get("count_answered", false)) or bool(ui_state.get("settlement_count_revealed", false)):
		return false
	if _local_copy_dict(ui_state.get("count_challenge", {})).is_empty():
		return false
	return bool(ui_state.get("counting_enabled", false)) or bool(ui_state.get("count_attempted", false))


func _prepare_count_settlement_preview(ui_state: Dictionary, table: Dictionary, run_state: RunState) -> void:
	var now_msec := _surface_time_for_count(ui_state)
	var presentation_msec := _blackjack_presentation_time_msec(ui_state, now_msec)
	var challenge_before: Dictionary = _local_copy_dict(ui_state.get("count_challenge", {}))
	var existing_icon_ids: Array = []
	for icon_value in _dictionary_array(challenge_before.get("icons", [])):
		var existing_icon: Dictionary = icon_value
		existing_icon_ids.append(str(existing_icon.get("id", "")))
	ui_state["dealer_hole_visible"] = true
	ui_state["round_terminal"] = true
	ui_state["settlement_pending"] = true
	ui_state["settlement_count_revealed"] = true
	_dealer_final_cards(ui_state, table)
	var settlement_events := _deal_animation_event_array(ui_state.get("settlement_deal_animation_events", []))
	var reveal_duration_msec := _deal_animation_duration_msec(settlement_events)
	if not settlement_events.is_empty():
		_mark_deal_animation(ui_state, "count_settlement_preview", settlement_events, presentation_msec)
	_sync_count_challenge_icons(ui_state, run_state, now_msec)
	# Newly revealed cards create bubbles only after their card motion completes.
	# This leaves the terminal hand readable and prevents payout from replacing
	# bubbles that have not appeared yet.
	var challenge: Dictionary = _local_copy_dict(ui_state.get("count_challenge", {}))
	var icons := _dictionary_array(challenge.get("icons", []))
	var terminal_icon_index := 0
	for i in range(icons.size()):
		var icon: Dictionary = icons[i]
		if existing_icon_ids.has(str(icon.get("id", ""))):
			continue
		icon["spawn_msec"] = now_msec + reveal_duration_msec + 120 + terminal_icon_index * COUNT_ICON_STAGGER_MSEC
		icons[i] = icon
		terminal_icon_index += 1
	challenge["icons"] = icons
	ui_state["count_challenge"] = challenge
	ui_state["settlement_preview_complete"] = true


func _toggle_counting_command(index: int, ui_state: Dictionary, table: Dictionary, environment: Dictionary, run_state: RunState) -> Dictionary:
	var enabled := not bool(table.get("counting_enabled", false))
	table["counting_enabled"] = enabled
	ui_state["counting_enabled"] = enabled
	if enabled:
		if _has_dealt_hand(ui_state) and _local_copy_dict(ui_state.get("count_challenge", {})).is_empty() and not bool(ui_state.get("count_answered", false)):
			_start_count_challenge(ui_state, table, run_state)
		_update_environment_table(environment, table)
		var challenge: Dictionary = _local_copy_dict(ui_state.get("count_challenge", {}))
		var message := "Counting armed for this table. Symbols appear only for +1 and -1 cards."
		if _has_dealt_hand(ui_state) and (_dictionary_array(challenge.get("icons", []))).is_empty():
			message = "Counting armed. Neutral cards are tracked; symbols appear when countable cards reveal."
		return GameModule.surface_command({
			"handled": true,
			"ui_state": _compact_session_for_ui(ui_state),
			"selected_index": index,
			"message": message,
		})
	ui_state["count_challenge"] = {}
	ui_state["count_answered"] = false
	ui_state["count_correct"] = false
	ui_state["count_perfect"] = false
	ui_state["count_delta"] = 0
	ui_state["count_declared_delta"] = 0
	table["recorded_running_count"] = 0
	table["recorded_count_shoe_generation"] = 0
	_update_environment_table(environment, table)
	return GameModule.surface_command({
		"handled": true,
		"ui_state": _compact_session_for_ui(ui_state),
		"selected_index": index,
		"message": "Counting disarmed for this table.",
	})


func _session_stake(stake: int, session: Dictionary) -> int:
	return maxi(1, int(session.get("locked_stake", stake)))


func _opening_deal_notice(session: Dictionary, _table: Dictionary) -> String:
	if bool(session.get("blackjack_sit_out", false)):
		return "You sit out this hand. The dealer deals the table without your wager."
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	var hand: Dictionary = _active_hand(session)
	var cards: Array = _card_array(hand.get("cards", []))
	if _dealer_has_blackjack(dealer_cards):
		if not dealer_cards.is_empty() and _card_rank_value(dealer_cards[0]) == RANK_ACE:
			return "Dealer shows an ace. Insurance is open; settle before any hit."
		return "Dealer checks the hole card. Blackjack is pending; settle the hand."
	if _is_natural_blackjack(hand):
		return "BLACKJACK. Settle to reveal the dealer and pay 3:2."
	return "Cards are out. Play the live hand: hit, stand, double, or split."


func _table_notice_for_session(session: Dictionary, table: Dictionary) -> String:
	var notice := str(session.get("table_notice", ""))
	var count_notice := str(session.get("count_live_notice", ""))
	if not notice.is_empty() and not count_notice.is_empty() and notice != count_notice:
		return "%s %s" % [count_notice, notice]
	if not notice.is_empty():
		return notice
	if not count_notice.is_empty():
		return count_notice
	if not _has_dealt_hand(session):
		return "Slide chips, choose side bets, then press DEAL."
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	if _dealer_has_blackjack(dealer_cards):
		return _opening_deal_notice(session, table)
	if _all_hands_complete(session):
		return _terminal_round_message(session)
	return _active_hand_status_text(session)


func _active_hand_status_text(session: Dictionary) -> String:
	if not _has_dealt_hand(session):
		return "No hand in play."
	var hands: Array = _hand_array(session.get("player_hands", []))
	if hands.is_empty():
		return "No hand in play."
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if _all_hands_complete(session):
		return _terminal_round_message(session)
	var hand: Dictionary = hands[active_index]
	var cards: Array = _card_array(hand.get("cards", []))
	var total := _hand_total(cards)
	var soft := bool(_hand_total_info(cards).get("soft", false))
	if bool(hand.get("surrendered", false)):
		return "Hand %d surrendered." % (active_index + 1)
	if total > 21:
		return "BUST: Hand %d totals %d." % [active_index + 1, total]
	if total == 21:
		return "Hand %d is locked at 21." % (active_index + 1)
	if bool(hand.get("stood", false)):
		return "Hand %d stands on %d." % [active_index + 1, total]
	return "Hand %d live: %s%d." % [active_index + 1, "soft " if soft else "", total]


func _terminal_round_message(session: Dictionary) -> String:
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	if bool(session.get("blackjack_sit_out", false)) and _hand_array(session.get("player_hands", [])).is_empty():
		return "You sat out. Dealer reveals and settles the table."
	if _dealer_has_blackjack(dealer_cards):
		return "Dealer reveals blackjack. The hand settles immediately."
	var hands: Array = _hand_array(session.get("player_hands", []))
	if hands.size() == 1:
		var hand: Dictionary = hands[0]
		var total := _hand_total(_card_array(hand.get("cards", [])))
		if bool(hand.get("surrendered", false)):
			return "SURRENDER: half the wager is returned; the hand settles now."
		if _is_natural_blackjack(hand):
			return "BLACKJACK. Dealer reveals the hole card and pays 3:2 unless they also have it."
		if total > 21:
			return "BUST: your hand totals %d. Dealer takes the wager now." % total
		if total == 21:
			return "21 locked. Dealer reveals and settles now."
	if _all_player_hands_busted(session):
		return "All player hands busted. Dealer takes the completed wagers."
	return "All player hands are complete. Dealer reveals and settles now."


func _post_hand_action_message(session: Dictionary, hand_index: int, action_label: String) -> String:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var safe_index := clampi(hand_index, 0, maxi(0, hands.size() - 1))
	var hand: Dictionary = hands[safe_index] if safe_index >= 0 and safe_index < hands.size() else {}
	var total := _hand_total(_card_array(hand.get("cards", [])))
	var prefix := "%s: Hand %d" % [action_label, safe_index + 1]
	if bool(hand.get("surrendered", false)):
		prefix = "SURRENDER: Hand %d gives up half the wager." % (safe_index + 1)
	elif total > 21:
		prefix = "BUST: Hand %d totals %d." % [safe_index + 1, total]
	elif total == 21:
		prefix = "Hand %d reaches 21." % (safe_index + 1)
	elif bool(hand.get("stood", false)):
		prefix = "%s stands on %d." % [prefix, total]
	else:
		prefix = "%s totals %d." % [prefix, total]
	var active_index := int(session.get("active_hand_index", 0))
	if active_index != safe_index and active_index >= 0 and active_index < hands.size():
		prefix += " Hand %d is live." % (active_index + 1)
	return prefix


func _append_strategy_notice(message: String, strategy_notice: String) -> String:
	if strategy_notice.is_empty():
		return message
	if message.is_empty():
		return strategy_notice
	return "%s %s" % [message, strategy_notice]


func _record_strategy_deviation(session: Dictionary, table: Dictionary, run_state: RunState, chosen_action: String) -> String:
	var event: Dictionary = _strategy_deviation_for_action(session, table, run_state, chosen_action)
	if event.is_empty():
		return ""
	var events: Array = _dictionary_array(session.get("strategy_deviation_events", []))
	events.append(event)
	session["strategy_deviation_events"] = events
	var score := maxi(1, int(event.get("score", 1)))
	session["strategy_deviation_score"] = maxi(0, int(session.get("strategy_deviation_score", 0))) + score
	var information_source := str(event.get("information_source", "ordinary"))
	var profile: Dictionary = _local_copy_dict(table.get("dealer_profile", {}))
	var scrutiny := clampi(int(profile.get("strategy_scrutiny", 10)), 0, 30)
	var attention_add := 1 if information_source == "ordinary" else clampi(score * 4 + int(ceil(float(scrutiny) / 5.0)), 4, 20)
	session["strategy_attention_boost"] = clampi(int(session.get("strategy_attention_boost", 0)) + attention_add, 0, STRATEGY_DEVIATION_MAX_WATCH)
	var threshold := clampi(int(profile.get("strategy_threshold", 4)), 1, 8)
	var current_advantage_score := 0
	for recorded_value in events:
		var recorded: Dictionary = recorded_value
		if str(recorded.get("information_source", "ordinary")) != "ordinary":
			current_advantage_score += maxi(1, int(recorded.get("score", 1)))
	var cumulative_score := maxi(0, int(table.get("strategy_deviation_strikes", 0))) + current_advantage_score
	if cumulative_score >= threshold and not bool(session.get("strategy_confronted", false)):
		session["strategy_confronted"] = true
		var response := str(profile.get("strategy_response", "watch"))
		var heat := 4 + score + int(ceil(float(scrutiny) / 8.0))
		if response == "heat":
			heat += 8 + score * 2
		elif response == "both":
			heat += 5 + score
		session["strategy_confrontation_heat"] = clampi(int(session.get("strategy_confrontation_heat", 0)) + heat, 0, STRATEGY_DEVIATION_MAX_HEAT)
		return "The dealer pauses on the %s: \"That call was too cute. I'm watching you.\"" % str(event.get("chosen", chosen_action))
	if information_source == "count":
		return "The dealer notes how precisely the %s tracks the shoe." % str(event.get("chosen", chosen_action))
	if information_source == "hole_card":
		return "The dealer notes how precisely the %s tracks the down card." % str(event.get("chosen", chosen_action))
	return "The dealer briefly notes the off-book %s." % str(event.get("chosen", chosen_action))


func _strategy_deviation_for_action(session: Dictionary, table: Dictionary, run_state: RunState, chosen_action: String) -> Dictionary:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if active_index < 0 or active_index >= hands.size():
		return {}
	var hand: Dictionary = hands[active_index]
	var cards: Array = _card_array(hand.get("cards", []))
	if cards.is_empty() or _is_bust(cards):
		return {}
	var recommended := _basic_strategy_action(session, table, run_state)
	if recommended.is_empty() or recommended == chosen_action:
		return {}
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	var information_source := "ordinary"
	var benefit: Dictionary = {}
	if _strategy_hole_card_advantage_active(session):
		benefit = _strategy_deviation_benefit(chosen_action, recommended, cards, dealer_cards)
		if not benefit.is_empty():
			information_source = "hole_card"
	if benefit.is_empty() and _strategy_count_advantage_active(session, table):
		benefit = _strategy_count_deviation_benefit(chosen_action, recommended, cards, dealer_cards, _recorded_count_for_surface(table, session))
		if not benefit.is_empty():
			information_source = "count"
	if benefit.is_empty():
		benefit = {"score": 1, "reason": "ordinary departure from basic strategy"}
	return {
		"hand_index": active_index,
		"chosen": chosen_action,
		"recommended": recommended,
		"score": int(benefit.get("score", 1)),
		"reason": str(benefit.get("reason", "")),
		"information_source": information_source,
		"player_total": _hand_total(cards),
		"dealer_known_total": _hand_total(dealer_cards),
		"timestamp_msec": GameModule.deterministic_time_msec(run_state, session),
	}


func _strategy_hole_card_advantage_active(session: Dictionary) -> bool:
	var cheats: Dictionary = _local_copy_dict(session.get("cheats_used", {}))
	return bool(cheats.get("peek_hole_card", false)) and bool(session.get("dealer_hole_visible", false)) and not bool(session.get("peek_caught_watching", false))


func _strategy_count_advantage_active(session: Dictionary, table: Dictionary) -> bool:
	if not bool(session.get("counting_enabled", false)) and not bool(session.get("count_attempted", false)):
		return false
	var challenge: Dictionary = _local_copy_dict(session.get("count_challenge", {}))
	if challenge.is_empty() or int(challenge.get("bad_hits", 0)) > 0 or not _string_array(challenge.get("missed_icons", [])).is_empty():
		return false
	var icons: Array = _dictionary_array(challenge.get("icons", []))
	var clicked: Array = _string_array(challenge.get("clicked_icons", []))
	if icons.is_empty() or clicked.size() < icons.size():
		return false
	var tolerance := maxi(0, int(challenge.get("tolerance", 0)))
	var recorded_delta := int(challenge.get("recorded_delta", session.get("count_delta", 0)))
	if abs(recorded_delta - int(challenge.get("target_delta", 0))) > tolerance:
		return false
	return abs(_recorded_count_for_surface(table, session)) >= 2


func _strategy_count_deviation_benefit(chosen_action: String, recommended: String, player_cards: Array, dealer_cards: Array, running_count: int) -> Dictionary:
	if dealer_cards.is_empty():
		return {}
	var player_total := int(_hand_total_info(player_cards).get("total", 0))
	var dealer_value := _dealer_strategy_value(dealer_cards[0] as Dictionary)
	if running_count >= 2:
		if chosen_action == "stand" and ["hit", "surrender"].has(recommended) and player_total >= 12 and player_total <= 16:
			return {"score": 2 if running_count >= 4 else 1, "reason": "a high count supports standing into the dealer upcard"}
		if chosen_action == "double" and recommended == "hit" and player_total >= 9 and player_total <= 11:
			return {"score": 2 if running_count >= 4 else 1, "reason": "a high count supports an otherwise aggressive double"}
		if chosen_action == "split" and recommended != "split" and player_total >= 16:
			return {"score": 2, "reason": "a high count supports an otherwise unusual split"}
	elif running_count <= -2:
		if chosen_action == "hit" and recommended == "stand" and player_total >= 12 and player_total <= 16 and dealer_value >= 2 and dealer_value <= 6:
			return {"score": 2 if running_count <= -4 else 1, "reason": "a low count supports drawing against a weak dealer card"}
	return {}


func _strategy_deviation_benefit(chosen_action: String, recommended: String, player_cards: Array, dealer_cards: Array) -> Dictionary:
	if dealer_cards.size() < 2:
		return {}
	var player_info: Dictionary = _hand_total_info(player_cards)
	var player_total := int(player_info.get("total", 0))
	var dealer_total := _hand_total(_first_cards(dealer_cards, 2))
	if player_total > 21 or dealer_total > 21:
		return {}
	var card_chase := ["hit", "double", "split"].has(chosen_action)
	var standing_loses := dealer_total >= 17 and dealer_total <= 21 and player_total < dealer_total
	var standing_pushes := dealer_total >= 17 and dealer_total <= 21 and player_total == dealer_total
	var dealer_weak_known := dealer_total >= 12 and dealer_total <= 16
	var score := 1
	var reason := ""
	if card_chase and ["stand", "surrender"].has(recommended) and standing_loses:
		score = 2 if player_total >= 17 else 1
		reason = "known dealer total beats the standing hand"
	elif chosen_action == "surrender" and recommended != "surrender" and standing_loses:
		score = 1
		reason = "known dealer total makes surrender unusually attractive"
	elif chosen_action == "stand" and ["hit", "double", "surrender"].has(recommended) and dealer_weak_known and player_total >= 12 and player_total <= 16:
		score = 1
		reason = "known dealer hole card turns a visible strong upcard into a stiff hand"
	elif chosen_action == "double" and recommended == "hit" and dealer_weak_known and player_total >= 9 and player_total <= 11:
		score = 1
		reason = "known dealer hole card exposes a weak made hand"
	elif chosen_action == "split" and recommended != "split" and dealer_weak_known:
		score = 1
		reason = "known dealer weakness makes an odd split look too precise"
	elif card_chase and recommended == "stand" and standing_pushes and player_total >= 17:
		score = 1
		reason = "known push invites an otherwise strange draw"
	if reason.is_empty():
		return {}
	return {"score": score, "reason": reason}


func _basic_strategy_action(session: Dictionary, table: Dictionary, run_state: RunState) -> String:
	var hand: Dictionary = _active_hand(session)
	var cards: Array = _card_array(hand.get("cards", []))
	if cards.is_empty():
		return ""
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	if dealer_cards.is_empty():
		return ""
	var dealer_value := _dealer_strategy_value(dealer_cards[0] as Dictionary)
	var selected_stake := _session_stake(maxi(1, int(session.get("selected_stake", session.get("locked_stake", 1)))), session)
	if _can_surrender(session, table) and not bool(_hand_total_info(cards).get("soft", false)):
		var hard_total := _hand_total(cards)
		if hard_total == 16 and dealer_value >= 9:
			return "surrender"
		if hard_total == 15 and dealer_value == 10:
			return "surrender"
	if _can_split(session, table, selected_stake, run_state):
		var split_action := _pair_strategy_action(cards, dealer_value, table)
		if not split_action.is_empty():
			return split_action
	var info: Dictionary = _hand_total_info(cards)
	if bool(info.get("soft", false)) and cards.size() <= 3:
		return _soft_strategy_action(int(info.get("total", 0)), dealer_value, _can_double(session, table, selected_stake, run_state))
	return _hard_strategy_action(int(info.get("total", 0)), dealer_value, _can_double(session, table, selected_stake, run_state))


func _basic_strategy_advice(session: Dictionary, table: Dictionary, run_state: RunState) -> Dictionary:
	if run_state == null or _item_effect_total("blackjack_basic_strategy_card", run_state) <= 0:
		return {"visible": false}
	var action := _basic_strategy_action(session, table, run_state)
	if action.is_empty():
		return {"visible": false}
	var hand: Dictionary = _active_hand(session)
	var cards: Array = _card_array(hand.get("cards", []))
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	var total_info: Dictionary = _hand_total_info(cards)
	var dealer_label := "dealer ?"
	if not dealer_cards.is_empty():
		dealer_label = "dealer %s" % _card_rank_label(_card_rank_value(dealer_cards[0]))
	var total_label := "soft %d" % int(total_info.get("total", 0)) if bool(total_info.get("soft", false)) else "%d" % int(total_info.get("total", 0))
	return {
		"visible": true,
		"action": action,
		"label": _book_action_label(action),
		"summary": "%s vs %s" % [total_label, dealer_label],
	}


func _book_action_label(action: String) -> String:
	match action:
		"hit":
			return "Hit"
		"stand":
			return "Stand"
		"double":
			return "Double"
		"split":
			return "Split"
		"surrender":
			return "Surrender"
		_:
			return action.capitalize()


func _card_rank_label(rank: int) -> String:
	match rank:
		RANK_ACE:
			return "A"
		13:
			return "K"
		12:
			return "Q"
		11:
			return "J"
		_:
			return "%d" % mini(rank, 10)


func _pair_strategy_action(cards: Array, dealer_value: int, table: Dictionary) -> String:
	if cards.size() != 2:
		return ""
	var first_rank := _card_rank_value(cards[0])
	var second_rank := _card_rank_value(cards[1])
	if first_rank != second_rank:
		return ""
	var rules: Dictionary = _table_rules(table)
	var das := bool(rules.get("double_after_split", true))
	var pair_value := 11 if first_rank == RANK_ACE else mini(first_rank, 10)
	if pair_value == 11 or pair_value == 8:
		return "split"
	if pair_value == 10:
		return "stand"
	if pair_value == 9:
		return "split" if [2, 3, 4, 5, 6, 8, 9].has(dealer_value) else "stand"
	if pair_value == 7:
		return "split" if dealer_value >= 2 and dealer_value <= 7 else "hit"
	if pair_value == 6:
		return "split" if dealer_value >= 2 and dealer_value <= 6 else "hit"
	if pair_value == 5:
		return "double" if dealer_value >= 2 and dealer_value <= 9 else "hit"
	if pair_value == 4:
		return "split" if das and dealer_value >= 5 and dealer_value <= 6 else "hit"
	if pair_value == 2 or pair_value == 3:
		return "split" if dealer_value >= 2 and dealer_value <= 7 else "hit"
	return ""


func _soft_strategy_action(total: int, dealer_value: int, double_available: bool) -> String:
	if total >= 19:
		return "stand"
	if total == 18:
		if dealer_value >= 3 and dealer_value <= 6:
			return "double" if double_available else "stand"
		if dealer_value == 2 or dealer_value == 7 or dealer_value == 8:
			return "stand"
		return "hit"
	if total == 17:
		return "double" if double_available and dealer_value >= 3 and dealer_value <= 6 else "hit"
	if total == 15 or total == 16:
		return "double" if double_available and dealer_value >= 4 and dealer_value <= 6 else "hit"
	if total == 13 or total == 14:
		return "double" if double_available and dealer_value >= 5 and dealer_value <= 6 else "hit"
	return "hit"


func _hard_strategy_action(total: int, dealer_value: int, double_available: bool) -> String:
	if total >= 17:
		return "stand"
	if total >= 13 and total <= 16:
		return "stand" if dealer_value >= 2 and dealer_value <= 6 else "hit"
	if total == 12:
		return "stand" if dealer_value >= 4 and dealer_value <= 6 else "hit"
	if total == 11:
		return "double" if double_available else "hit"
	if total == 10:
		return "double" if double_available and dealer_value >= 2 and dealer_value <= 9 else "hit"
	if total == 9:
		return "double" if double_available and dealer_value >= 3 and dealer_value <= 6 else "hit"
	return "hit"


func _dealer_strategy_value(card: Dictionary) -> int:
	var rank := _card_rank_value(card)
	if rank == RANK_ACE:
		return 11
	return mini(rank, 10)


func _all_player_hands_busted(session: Dictionary) -> bool:
	var hands: Array = _hand_array(session.get("player_hands", []))
	if hands.is_empty():
		return false
	for hand_value in hands:
		var hand: Dictionary = hand_value
		if not _is_bust(_card_array(hand.get("cards", []))):
			return false
	return true


func _chip_bet_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary, selected_stake: int) -> Dictionary:
	if _has_dealt_hand(ui_state):
		return _message_command(ui_state, "Main bets are locked until the hand settles.")
	var chips: Array = _chip_denominations(table)
	if index < 0 or index >= chips.size():
		return _message_command(ui_state, "That chip is not in your rack.")
	var chip_value: int = int(chips[index])
	var min_bet := _surface_stake_floor(run_state, environment)
	var max_stake: int = _max_table_stake_for_blackjack(ui_state, table, run_state, environment)
	var next_stake: int = min_bet if max_stake < min_bet else clampi(maxi(min_bet, selected_stake) + chip_value, min_bet, max_stake)
	_blackjack_push_wager_edit(ui_state)
	ui_state["selected_stake"] = next_stake
	ui_state.erase("table_social_alignment")
	return _wager_edit_command(ui_state, index, next_stake, "You slide a $%d chip forward. Bet $%d." % [chip_value, next_stake])


func _correct_chip_bet_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if _has_dealt_hand(ui_state):
		return _message_command(ui_state, "Main bets are locked until the hand settles.")
	var chips := _chip_denominations(table)
	if index < 0 or index >= chips.size():
		return _message_command(ui_state, "That chip is not in your rack.")
	var min_bet := _surface_stake_floor(run_state, environment)
	var max_bet := _max_table_stake_for_blackjack(ui_state, table, run_state, environment)
	var corrected_stake := clampi(int(chips[index]), min_bet, maxi(min_bet, max_bet))
	if corrected_stake == int(ui_state.get("selected_stake", min_bet)):
		return _message_command(ui_state, "That exact main wager is already staged.")
	_blackjack_push_wager_edit(ui_state)
	ui_state["selected_stake"] = corrected_stake
	ui_state.erase("table_social_alignment")
	return _wager_edit_command(ui_state, index, corrected_stake, "Main wager corrected to one $%d stack." % corrected_stake)


func _remove_chip_bet_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary, selected_stake: int) -> Dictionary:
	if _has_dealt_hand(ui_state):
		return _message_command(ui_state, "Main bets are locked until the hand settles.")
	var chips := _chip_denominations(table)
	if index < 0 or index >= chips.size():
		return _message_command(ui_state, "That chip is not in your rack.")
	var chip_value := int(chips[index])
	var min_bet := _surface_stake_floor(run_state, environment)
	var next_stake := maxi(min_bet, selected_stake - chip_value)
	if next_stake == selected_stake:
		return _message_command(ui_state, "The main wager is already at the table minimum.")
	_blackjack_push_wager_edit(ui_state)
	ui_state["selected_stake"] = next_stake
	ui_state.erase("table_social_alignment")
	return _wager_edit_command(ui_state, index, next_stake, "You pull one $%d chip back. Bet $%d." % [chip_value, next_stake])


func _blackjack_push_wager_edit(ui_state: Dictionary) -> void:
	var history: Array = ui_state.get("blackjack_wager_history", []).duplicate(true) if typeof(ui_state.get("blackjack_wager_history", [])) == TYPE_ARRAY else []
	history.append({
		"selected_stake": maxi(1, int(ui_state.get("selected_stake", 1))),
		"side_bets": _string_array(ui_state.get("blackjack_side_bets", [])),
	})
	while history.size() > 12:
		history.pop_front()
	ui_state["blackjack_wager_history"] = history


func _undo_blackjack_wager_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if _has_dealt_hand(ui_state):
		return _message_command(ui_state, "Wager edits are locked until the hand settles.")
	var history: Array = ui_state.get("blackjack_wager_history", []).duplicate(true) if typeof(ui_state.get("blackjack_wager_history", [])) == TYPE_ARRAY else []
	if history.is_empty():
		return _message_command(ui_state, "There is no pending wager edit to undo.")
	var previous: Dictionary = history.pop_back() if typeof(history.back()) == TYPE_DICTIONARY else {}
	var min_bet := _surface_stake_floor(run_state, environment)
	var max_bet := _max_table_stake_for_blackjack(ui_state, table, run_state, environment)
	var restored_stake := clampi(int(previous.get("selected_stake", min_bet)), min_bet, maxi(min_bet, max_bet))
	ui_state["selected_stake"] = restored_stake
	ui_state["blackjack_side_bets"] = _valid_side_bet_ids_for_session(_string_array(previous.get("side_bets", [])), table, ui_state)
	ui_state["blackjack_wager_history"] = history
	ui_state.erase("table_social_alignment")
	return _wager_edit_command(ui_state, index, restored_stake, "Last pending edit undone. Bet $%d." % restored_stake)


func _repeat_blackjack_wager_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary, rebet: bool) -> Dictionary:
	if _has_dealt_hand(ui_state):
		return _message_command(ui_state, "Repeat and re-bet are available between hands.")
	var last_result := _local_copy_dict(table.get("last_result", {}))
	if last_result.is_empty() or int(last_result.get("main_stake", 0)) <= 0:
		return _message_command(ui_state, "No resolved Blackjack wager is available to repeat.")
	_blackjack_push_wager_edit(ui_state)
	var min_bet := _surface_stake_floor(run_state, environment)
	var max_bet := _max_table_stake_for_blackjack(ui_state, table, run_state, environment)
	var repeated_stake := clampi(int(last_result.get("main_stake", min_bet)), min_bet, maxi(min_bet, max_bet))
	ui_state["selected_stake"] = repeated_stake
	ui_state["blackjack_side_bets"] = _valid_side_bet_ids_for_session(_string_array(last_result.get("side_bet_ids", [])), table, ui_state)
	var repeated_cost := _wager_cost_from_session(repeated_stake, ui_state, table, run_state)
	var capacity := run_state.wager_capacity_for_game(get_id(), environment) if run_state != null else repeated_cost
	if repeated_cost > capacity:
		ui_state["blackjack_side_bets"] = []
		repeated_cost = _wager_cost_from_session(repeated_stake, ui_state, table, run_state)
	if repeated_cost > capacity:
		return _undo_blackjack_wager_command(index, ui_state, table, run_state, environment)
	ui_state.erase("table_social_alignment")
	return _wager_edit_command(ui_state, index, repeated_stake, "%s wager staged: $%d total risk. Press Deal to confirm." % ["Resolved" if rebet else "Previous", repeated_cost])


func _patron_bet_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if _has_dealt_hand(ui_state):
		return _message_command(ui_state, "Patron chip calls are only available before the deal.")
	var fade := index >= 100
	var patron_index := index % 100
	var patrons := _dictionary_array(table.get("patrons", []))
	if patron_index < 0 or patron_index >= patrons.size():
		return _message_command(ui_state, "That blackjack seat is empty.")
	var patron: Dictionary = patrons[patron_index]
	var wager := _blackjack_patron_wager(patron, table)
	_blackjack_push_wager_edit(ui_state)
	var min_bet := _surface_stake_floor(run_state, environment)
	var max_bet := _max_table_stake_for_blackjack(ui_state, table, run_state, environment)
	var target_stake := int(wager.get("stake", min_bet))
	var active_side_bets := _string_array(ui_state.get("blackjack_side_bets", []))
	var available_side_bets := _available_side_bets_for_session(table, ui_state)
	var side_id := str(wager.get("side_bet_id", ""))
	if fade:
		match str(wager.get("style", "")):
			"side_action", "big_stack":
				target_stake = min_bet
				active_side_bets = []
			"minimum":
				target_stake = maxi(min_bet, target_stake * 3)
				if not available_side_bets.is_empty():
					active_side_bets = [str((available_side_bets[0] as Dictionary).get("id", ""))]
			_:
				target_stake = maxi(min_bet, target_stake * 2)
	else:
		if str(wager.get("style", "")) == "side_action" and not side_id.is_empty():
			if not active_side_bets.has(side_id):
				active_side_bets.append(side_id)
		elif str(wager.get("style", "")) != "side_action" and not side_id.is_empty():
			if not active_side_bets.has(side_id):
				active_side_bets.append(side_id)
	target_stake = clampi(target_stake, min_bet, max_bet)
	ui_state["selected_stake"] = target_stake
	ui_state["blackjack_side_bets"] = _valid_side_bet_ids_for_session(active_side_bets, table, ui_state)
	var total_cost := _wager_cost_from_session(target_stake, ui_state, table, run_state)
	if run_state != null and total_cost > run_state.wager_capacity_for_game(get_id(), environment):
		ui_state["blackjack_side_bets"] = []
		target_stake = clampi(min_bet, 1, max_bet)
		ui_state["selected_stake"] = target_stake
		total_cost = _wager_cost_from_session(target_stake, ui_state, table, run_state)
		if total_cost > run_state.wager_capacity_for_game(get_id(), environment):
			return _message_command(ui_state, "You do not have the bankroll to take that blackjack table action.")
	ui_state["table_social_alignment"] = {
		"game": "blackjack",
		"patron_id": str(patron.get("id", "patron_%d" % patron_index)),
		"patron_name": str(patron.get("name", "Patron")),
		"stance": "against" if fade else "with",
		"style": str(wager.get("style", "")),
		"stake": target_stake,
		"side_bets": ui_state["blackjack_side_bets"],
	}
	return _wager_edit_command(ui_state, patron_index, target_stake, "%s %s's blackjack posture. Main $%d, total risk $%d." % ["Fading" if fade else "Following", str(patron.get("name", "Patron")), target_stake, total_cost])


func _blackjack_patron_wager(patron: Dictionary, table: Dictionary) -> Dictionary:
	var style := str(patron.get("bet_style", "flat_main"))
	var base_stake := maxi(1, int(patron.get("cosmetic_bet", maxi(1, int(patron.get("chip_stack", 20)) / 3))))
	var side_bets := _available_side_bets(table)
	var side_id := ""
	if not side_bets.is_empty():
		side_id = str((side_bets[0] as Dictionary).get("id", ""))
	var label := "MAIN"
	match style:
		"side_action":
			label = "SIDE"
		"big_stack":
			label = "PRESS"
			base_stake = maxi(base_stake, int(patron.get("chip_stack", 20)))
		"minimum":
			label = "MIN"
			base_stake = maxi(1, int(ceil(float(base_stake) * 0.5)))
		_:
			label = "MAIN"
	return {
		"id": style,
		"label": label,
		"stake": base_stake,
		"style": style,
		"side_bet_id": side_id if style == "side_action" else "",
	}


func _apply_patron_rapport_after_blackjack(table: Dictionary, session: Dictionary, table_stake: int, bankroll_delta: int) -> void:
	var patrons := _dictionary_array(table.get("patrons", []))
	if patrons.is_empty():
		return
	var alignment := _local_copy_dict(session.get("table_social_alignment", {}))
	var active_side_bets := _string_array(session.get("blackjack_side_bets", []))
	for i in range(patrons.size()):
		var patron: Dictionary = patrons[i]
		var wager := _blackjack_patron_wager(patron, table)
		var style := str(wager.get("style", "flat_main"))
		var patron_stake := maxi(1, int(wager.get("stake", 1)))
		var same := false
		var against := false
		match style:
			"side_action":
				same = not active_side_bets.is_empty()
				against = active_side_bets.is_empty()
			"big_stack":
				same = table_stake >= int(ceil(float(patron_stake) * 0.75))
				against = table_stake <= maxi(1, int(floor(float(patron_stake) * 0.4)))
			"minimum":
				same = table_stake <= maxi(1, patron_stake)
				against = table_stake >= patron_stake * 2
			_:
				same = abs(table_stake - patron_stake) <= maxi(2, int(ceil(float(patron_stake) * 0.25)))
				against = abs(table_stake - patron_stake) >= maxi(5, patron_stake)
		var delta := 0
		if same:
			delta += 2
		if against:
			delta -= 2
		if str(alignment.get("patron_id", "")) == str(patron.get("id", "patron_%d" % i)):
			delta += 4 if str(alignment.get("stance", "")) == "with" else -4
		if delta != 0:
			if bankroll_delta > 0 and same:
				delta += 1
			if bankroll_delta > 0 and against:
				delta -= 1
			patron["rapport"] = clampi(int(patron.get("rapport", 50)) + delta, 0, 100)
			patron["last_social_delta"] = delta
			patron["last_social_stance"] = "with" if delta > 0 else "against"
		else:
			patron["last_social_delta"] = 0
			patron["last_social_stance"] = "neutral"
		patrons[i] = patron
	table["patrons"] = patrons


func _max_table_stake_for_blackjack(session: Dictionary, table: Dictionary, run_state: RunState, environment: Dictionary = {}) -> int:
	var bankroll: int = _surface_stake_ceiling(run_state, environment)
	var probe: Dictionary = session.duplicate(true)
	var low := 1
	var high := bankroll
	var best := 1
	# Side-bet costs can round by stake, but total wager cost remains monotonic.
	# Binary search avoids a per-dollar scan when bankrolls get large.
	while low <= high:
		var stake := int(floor(float(low + high) * 0.5))
		if _wager_cost_from_session(stake, probe, table, run_state) <= bankroll:
			best = stake
			low = stake + 1
		else:
			high = stake - 1
	return best


func _effective_table_stake(stake: int, session: Dictionary, run_state: RunState, environment: Dictionary) -> int:
	if session.has("locked_stake"):
		return _session_stake(stake, session)
	var min_bet := _surface_stake_floor(run_state, environment)
	var max_bet := _surface_stake_ceiling(run_state, environment)
	if max_bet < min_bet:
		return min_bet
	return clampi(maxi(1, stake), min_bet, max_bet)


func _blackjack_original_stake_ceiling(run_state: RunState, environment: Dictionary) -> int:
	if run_state == null:
		return 1
	return maxi(1, GameModule.stake_ceiling_for_game(environment, get_id(), run_state.wager_capacity_for_game(get_id(), environment)))


func _blackjack_base_stake_ceiling(run_state: RunState, environment: Dictionary) -> int:
	var base_ceiling := _blackjack_original_stake_ceiling(run_state, environment)
	var multiplier := maxi(1, _item_effect_total("blackjack_table_limit_multiplier", run_state))
	return maxi(1, base_ceiling * multiplier)


func _surface_stake_ceiling(run_state: RunState, environment: Dictionary) -> int:
	if run_state == null:
		return 1
	var base_ceiling: int = _blackjack_base_stake_ceiling(run_state, environment)
	var wager_ceiling: int = run_state.wager_stake_ceiling(base_ceiling)
	return maxi(1, mini(wager_ceiling, run_state.wager_capacity_for_game(get_id(), environment)))


func _surface_stake_floor(run_state: RunState, environment: Dictionary) -> int:
	if run_state == null:
		return 1
	var profile: Dictionary = environment.get("economic_profile", {}) if typeof(environment.get("economic_profile", {})) == TYPE_DICTIONARY else {}
	var floor := maxi(1, GameModule.stake_floor_for_game(environment, get_id(), int(profile.get("stake_floor", 1))))
	if _item_effect_total("blackjack_table_minimum_to_previous_max", run_state) > 0:
		floor = maxi(floor, _blackjack_original_stake_ceiling(run_state, environment))
	return floor


func _start_distraction_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState = null) -> Dictionary:
	var distractions: Array = _dictionary_array(table.get("distractions", []))
	if index < 0 or index >= distractions.size():
		return _message_command(ui_state, "That distraction is not available at this table.")
	var distraction: Dictionary = distractions[index]
	var now := _session_time_msec(ui_state)
	var distraction_id := str(distraction.get("id", "distraction"))
	ui_state["dealer_lookaway_started_msec"] = now
	var duration_msec := int(distraction.get("duration_msec", 2800))
	# The guided run opens Pal's required explanation after the real distraction
	# starts. Give a first-time player enough time to read that instruction and
	# still act on the production Peek window; normal-run timing is untouched.
	if run_state != null and run_state.is_tutorial_run():
		duration_msec = maxi(duration_msec, 15000)
	ui_state["dealer_lookaway_duration_msec"] = duration_msec
	ui_state["dealer_lookaway_id"] = "%s:%s:%d" % [get_id(), distraction_id, now]
	ui_state["dealer_distraction_id"] = distraction_id
	ui_state["dealer_distraction_noise"] = int(distraction.get("noise", 0))
	ui_state["dealer_distraction_cover"] = int(distraction.get("cover", 0))
	return _message_command(ui_state, "%s opens a short peek window." % str(distraction.get("label", "Distraction")))


func _cover_patron_command(index: int, ui_state: Dictionary, table: Dictionary) -> Dictionary:
	var patrons: Array = _dictionary_array(table.get("patrons", []))
	if index < 0 or index >= patrons.size():
		return _message_command(ui_state, "That seat is empty.")
	var patron: Dictionary = patrons[index]
	var patron_id := str(patron.get("id", "patron_%d" % index))
	var cover: Dictionary = _local_copy_dict(ui_state.get("patron_cover", {}))
	cover[patron_id] = {
		"started_msec": _session_time_msec(ui_state),
		"duration_msec": 5200,
		"cover": 22,
	}
	ui_state["patron_cover"] = cover
	return _message_command(ui_state, "%s is busy watching your table talk." % str(patron.get("name", "Patron")))


func _toggle_side_bet_command(index: int, ui_state: Dictionary, table: Dictionary, run_state: RunState, source_state: Dictionary) -> Dictionary:
	var available: Array = _available_side_bets_for_session(table, ui_state)
	if index < 0 or index >= available.size():
		return _message_command(ui_state, "That side bet is not on this table.")
	var bet: Dictionary = available[index]
	if not _side_bet_can_toggle_now(bet, ui_state):
		return _message_command(ui_state, "That side bet is locked for this hand.")
	_blackjack_push_wager_edit(ui_state)
	var bet_id := str(bet.get("id", ""))
	var active: Array = _string_array(ui_state.get("blackjack_side_bets", []))
	if active.has(bet_id):
		active.erase(bet_id)
	else:
		active.append(bet_id)
	ui_state["blackjack_side_bets"] = active
	ui_state.erase("table_social_alignment")
	var cost: int = _wager_cost_from_session(_session_stake(int(source_state.get("selected_stake", ui_state.get("selected_stake", 1))), ui_state), ui_state, table, run_state)
	return _message_command(ui_state, "%s %s. Total risk $%d." % [str(bet.get("label", bet_id)), "removed" if not active.has(bet_id) else "added", cost])


# Count stays local by design: it is a multi-icon card-identity state machine,
# not the scalar timing window shared by holdout, controlled roll, and past-post.
func _count_icon_duration_msec(run_state: RunState) -> int:
	var duration_msec := clampi(COUNT_ICON_DURATION_MSEC + _item_effect_total("blackjack_count_window_msec", run_state), 1800, 4600)
	# As with the tutorial Peek, Pal's required explanation opens after the real
	# timed interaction begins. Preserve normal difficulty while making the
	# fixed guided run readable before its bubbles expire.
	if run_state != null and run_state.is_tutorial_run():
		return maxi(duration_msec, 30000)
	return duration_msec


func _start_count_challenge(ui_state: Dictionary, table: Dictionary, run_state: RunState, now_msec: int = -1) -> void:
	var cards: Array = _visible_count_challenge_cards(ui_state)
	var icons: Array = []
	var now := _surface_time_for_count(ui_state, now_msec)
	var icon_duration := _count_icon_duration_msec(run_state)
	var challenge_id := "%s:count:%d" % [get_id(), now]
	var icon_serial := 0
	for i in range(cards.size()):
		var card_value: Variant = cards[i]
		var card: Dictionary = card_value
		card["_count_tracking_key"] = _count_icon_card_key(card)
		var count_value := _count_value_for_card(card)
		if count_value == 0:
			continue
		var seed: int = abs(JsonCoerceScript._stable_hash("%s:%s:%d" % [challenge_id, _count_icon_card_key(card), i]))
		var icon_pos := _count_icon_position_for_card(card, seed)
		icons.append({
			"id": "%s:%d" % [challenge_id, icon_serial],
			"card": card.duplicate(true),
			"count_value": count_value,
			"spawn_msec": now + 420 + icons.size() * COUNT_ICON_STAGGER_MSEC,
			"duration_msec": icon_duration,
			"x": icon_pos.x,
			"y": icon_pos.y,
		})
		icon_serial += 1
	var target_delta: int = _count_cards_delta(cards)
	var tracked_keys: Array = []
	for tracked_card_value in cards:
		if typeof(tracked_card_value) == TYPE_DICTIONARY:
			tracked_keys.append(_count_icon_card_key(tracked_card_value as Dictionary))
	ui_state["count_challenge"] = {
		"challenge_id": challenge_id,
		"cards": cards,
		"icons": icons,
		"tracked_card_keys": tracked_keys,
		"icon_serial": icon_serial,
		"clicked_icons": [],
		"missed_icons": [],
		"resolved_icon_msec": {},
		"bad_hits": 0,
		"correct_hits": 0,
		"target_delta": target_delta,
		"tolerance": maxi(0, _item_effect_total("blackjack_count_tolerance", run_state)) \
			+ (run_state.crew_play_effect_int("spotter", "blackjack_count_tolerance", 0) if run_state != null else 0),
		"dealer_attention_risk": clampi(18 + icons.size() * 5 - _item_effect_total("blackjack_count_cover", run_state), 4, 78),
		"recorded_delta": 0,
		"recorded_running_count_start": int(table.get("recorded_running_count", 0)),
		"running_count_start": int(table.get("running_count", 0)),
		"started_msec": now,
	}
	var cheats: Dictionary = _local_copy_dict(ui_state.get("cheats_used", {}))
	cheats["count_cards"] = true
	ui_state["cheats_used"] = cheats
	ui_state["count_attempted"] = true
	ui_state["count_answered"] = false
	ui_state["count_correct"] = false
	ui_state["count_perfect"] = false
	ui_state["count_delta"] = 0
	ui_state["count_declared_delta"] = 0


func _visible_count_challenge_cards(session: Dictionary) -> Array:
	var cards: Array = []
	var dealer_cards: Array = _card_array(session.get("dealer_cards", []))
	if not dealer_cards.is_empty():
		var dealer_up: Dictionary = (dealer_cards[0] as Dictionary).duplicate(true)
		dealer_up["_count_identity_key"] = _raw_count_icon_card_key(dealer_up)
		dealer_up["_count_source_key"] = "dealer:0:%s" % _raw_count_icon_card_key(dealer_up)
		cards.append(dealer_up)
	var hands: Array = _hand_array(session.get("player_hands", []))
	for hand_index in range(hands.size()):
		var hand_value: Variant = hands[hand_index]
		var hand: Dictionary = hand_value
		var hand_cards: Array = _card_array(hand.get("cards", []))
		for card_index in range(hand_cards.size()):
			var card_value: Variant = hand_cards[card_index]
			if typeof(card_value) == TYPE_DICTIONARY:
				var player_card: Dictionary = (card_value as Dictionary).duplicate(true)
				player_card["_count_identity_key"] = _raw_count_icon_card_key(player_card)
				player_card["_count_source_key"] = "player:%d:%d:%s" % [hand_index, card_index, _raw_count_icon_card_key(player_card)]
				cards.append(player_card)
	var patron_hands: Array = _hand_array(session.get("patron_hands", []))
	for patron_index in range(patron_hands.size()):
		var patron_hand: Dictionary = patron_hands[patron_index]
		var patron_cards: Array = _card_array(patron_hand.get("cards", []))
		for card_index in range(patron_cards.size()):
			var card_value: Variant = patron_cards[card_index]
			if typeof(card_value) == TYPE_DICTIONARY:
				var patron_card: Dictionary = (card_value as Dictionary).duplicate(true)
				patron_card["_count_identity_key"] = _raw_count_icon_card_key(patron_card)
				patron_card["_count_source_key"] = "patron:%d:%d:%s" % [patron_index, card_index, _raw_count_icon_card_key(patron_card)]
				cards.append(patron_card)
	if bool(session.get("dealer_hole_visible", false)) and dealer_cards.size() > 1:
		for dealer_index in range(1, dealer_cards.size()):
			var dealer_reveal: Dictionary = (dealer_cards[dealer_index] as Dictionary).duplicate(true)
			dealer_reveal["_count_identity_key"] = _raw_count_icon_card_key(dealer_reveal)
			dealer_reveal["_count_source_key"] = "dealer:%d:%s" % [dealer_index, _raw_count_icon_card_key(dealer_reveal)]
			cards.append(dealer_reveal)
	return cards


func _hit_count_icon(index: int, ui_state: Dictionary, table: Dictionary, _run_state: RunState) -> Dictionary:
	_sync_count_challenge_icons(ui_state, _run_state)
	var challenge: Dictionary = _local_copy_dict(ui_state.get("count_challenge", {}))
	if challenge.is_empty():
		return _message_command(ui_state, "Start the count first.")
	if bool(ui_state.get("count_answered", false)):
		return _message_command(ui_state, "Count already recorded.")
	var now_msec := _surface_time_for_count(ui_state)
	challenge = _refresh_count_challenge_misses(challenge, now_msec)
	var icons: Array = _dictionary_array(challenge.get("icons", []))
	if index < 0 or index >= icons.size():
		challenge["bad_hits"] = int(challenge.get("bad_hits", 0)) + 1
		challenge["dealer_attention_risk"] = clampi(int(challenge.get("dealer_attention_risk", 24)) + 10, 0, 100)
		ui_state["count_challenge"] = challenge
		return _message_command(ui_state, "You reach for a count marker that is not there.")
	var icon: Dictionary = icons[index]
	var icon_id := str(icon.get("id", "icon_%d" % index))
	var clicked: Array = _string_array(challenge.get("clicked_icons", []))
	var missed: Array = _string_array(challenge.get("missed_icons", []))
	var resolved_times: Dictionary = _local_copy_dict(challenge.get("resolved_icon_msec", {}))
	if clicked.has(icon_id):
		ui_state["count_challenge"] = challenge
		return _message_command(ui_state, "That count pulse is already locked.")
	if missed.has(icon_id):
		challenge["bad_hits"] = int(challenge.get("bad_hits", 0)) + 1
		challenge["dealer_attention_risk"] = clampi(int(challenge.get("dealer_attention_risk", 24)) + 8, 0, 100)
		ui_state["count_challenge"] = challenge
		return _message_command(ui_state, "Too late. That card already slipped the count.")
	var spawn := int(icon.get("spawn_msec", now_msec))
	var duration := int(icon.get("duration_msec", COUNT_ICON_DURATION_MSEC))
	if now_msec < spawn or now_msec > spawn + duration:
		challenge["bad_hits"] = int(challenge.get("bad_hits", 0)) + 1
		challenge["dealer_attention_risk"] = clampi(int(challenge.get("dealer_attention_risk", 24)) + 8, 0, 100)
		ui_state["count_challenge"] = challenge
		return _message_command(ui_state, "The timing is off. The dealer's eyes flick to your hands.")
	clicked.append(icon_id)
	var delta := int(ui_state.get("count_delta", int(challenge.get("recorded_delta", 0)))) + int(icon.get("count_value", 0))
	challenge["clicked_icons"] = clicked
	resolved_times[icon_id] = now_msec
	challenge["resolved_icon_msec"] = resolved_times
	challenge["recorded_delta"] = delta
	challenge["correct_hits"] = int(challenge.get("correct_hits", 0)) + 1
	ui_state["count_delta"] = delta
	ui_state["count_declared_delta"] = delta
	ui_state["count_challenge"] = challenge
	var command := _message_command(ui_state, "Count pulse %+d locked. Hand delta %+d; shoe count %+d." % [
		int(icon.get("count_value", 0)),
		delta,
		int(table.get("recorded_running_count", 0)) + delta,
	])
	# The host has already staged the complete sealed session. Patch the rendered
	# pulse state directly so a hover claim does not rebuild the entire Foundation
	# screen before drawing the fade/count change.
	command["surface_state_patch"] = {
		"count_challenge": challenge.duplicate(true),
		"count_delta": delta,
		"count_declared_delta": delta,
	}
	return command


func _refresh_count_challenge_misses(challenge: Dictionary, now_msec: int) -> Dictionary:
	var next_challenge := challenge.duplicate(true)
	var clicked: Array = _string_array(next_challenge.get("clicked_icons", []))
	var missed: Array = _string_array(next_challenge.get("missed_icons", []))
	var resolved_times: Dictionary = _local_copy_dict(next_challenge.get("resolved_icon_msec", {}))
	var added := 0
	var added_risk := 0
	for icon_value in _dictionary_array(next_challenge.get("icons", [])):
		var icon: Dictionary = icon_value
		var icon_id := str(icon.get("id", ""))
		if icon_id.is_empty() or clicked.has(icon_id) or missed.has(icon_id):
			continue
		var spawn := int(icon.get("spawn_msec", now_msec))
		var duration := int(icon.get("duration_msec", COUNT_ICON_DURATION_MSEC))
		if now_msec > spawn + duration:
			missed.append(icon_id)
			resolved_times[icon_id] = now_msec
			added += 1
			added_risk += 8
	if added > 0:
		next_challenge["missed_icons"] = missed
		next_challenge["resolved_icon_msec"] = resolved_times
		next_challenge["misses"] = int(next_challenge.get("misses", 0)) + added
		next_challenge["dealer_attention_risk"] = clampi(int(next_challenge.get("dealer_attention_risk", 24)) + added_risk, 0, 100)
	return next_challenge


func _mark_unresolved_count_icons_missed(challenge: Dictionary, now_msec: int) -> Dictionary:
	var next_challenge := challenge.duplicate(true)
	var clicked: Array = _string_array(next_challenge.get("clicked_icons", []))
	var missed: Array = _string_array(next_challenge.get("missed_icons", []))
	var resolved_times: Dictionary = _local_copy_dict(next_challenge.get("resolved_icon_msec", {}))
	var added := 0
	var added_risk := 0
	for icon_value in _dictionary_array(next_challenge.get("icons", [])):
		var icon: Dictionary = icon_value
		var icon_id := str(icon.get("id", ""))
		if icon_id.is_empty() or clicked.has(icon_id) or missed.has(icon_id):
			continue
		missed.append(icon_id)
		resolved_times[icon_id] = now_msec
		added += 1
		added_risk += 8
	if added > 0:
		next_challenge["missed_icons"] = missed
		next_challenge["resolved_icon_msec"] = resolved_times
		next_challenge["misses"] = int(next_challenge.get("misses", 0)) + added
		next_challenge["dealer_attention_risk"] = clampi(int(next_challenge.get("dealer_attention_risk", 24)) + added_risk, 0, 100)
	return next_challenge


func _count_missed_nonzero_icons(challenge: Dictionary) -> int:
	var missed: Array = _string_array(challenge.get("missed_icons", []))
	if missed.is_empty():
		return 0
	var count := 0
	for icon_value in _dictionary_array(challenge.get("icons", [])):
		var icon: Dictionary = icon_value
		if missed.has(str(icon.get("id", ""))) and int(icon.get("count_value", 0)) != 0:
			count += 1
	return count


func _sync_count_challenge_icons(ui_state: Dictionary, run_state: RunState, now_msec: int = -1) -> int:
	var challenge: Dictionary = _local_copy_dict(ui_state.get("count_challenge", {}))
	if challenge.is_empty() or bool(ui_state.get("count_answered", false)):
		return 0
	var cards: Array = _dictionary_array(challenge.get("cards", []))
	var icons: Array = _dictionary_array(challenge.get("icons", []))
	var tracked_keys: Array = _string_array(challenge.get("tracked_card_keys", []))
	var available_keys_by_identity: Dictionary = {}
	for card_value in cards:
		if typeof(card_value) != TYPE_DICTIONARY:
			continue
		var tracked_card: Dictionary = card_value as Dictionary
		var tracked_key := _count_icon_card_key(tracked_card)
		if not tracked_keys.has(tracked_key):
			tracked_keys.append(tracked_key)
		var identity_key := _count_icon_identity_key(tracked_card)
		var identity_keys: Array = available_keys_by_identity.get(identity_key, [])
		identity_keys.append(tracked_key)
		available_keys_by_identity[identity_key] = identity_keys
	now_msec = _surface_time_for_count(ui_state, now_msec)
	var icon_duration := _count_icon_duration_msec(run_state)
	var challenge_id := str(challenge.get("challenge_id", "%s:count:%d" % [get_id(), now_msec]))
	var serial := int(challenge.get("icon_serial", icons.size()))
	var added := 0
	var claimed_existing_keys: Dictionary = {}
	for card_value in _visible_count_challenge_cards(ui_state):
		if typeof(card_value) != TYPE_DICTIONARY:
			continue
		var card: Dictionary = (card_value as Dictionary).duplicate(true)
		var source_key := str(card.get("_count_source_key", _count_icon_card_key(card)))
		var key := ""
		var identity_keys: Array = available_keys_by_identity.get(_count_icon_identity_key(card), [])
		for candidate_value in identity_keys:
			var candidate := str(candidate_value)
			if candidate == source_key and not claimed_existing_keys.has(candidate):
				key = candidate
				break
		if key.is_empty():
			for candidate_value in identity_keys:
				var candidate := str(candidate_value)
				if not claimed_existing_keys.has(candidate):
					key = candidate
					break
		if not key.is_empty():
			claimed_existing_keys[key] = true
		else:
			key = source_key
			var disambiguator := 2
			while tracked_keys.has(key):
				key = "%s#%d" % [source_key, disambiguator]
				disambiguator += 1
		card["_count_tracking_key"] = key
		if tracked_keys.has(key):
			continue
		tracked_keys.append(key)
		cards.append(card.duplicate(true))
		var count_value := _count_value_for_card(card)
		if count_value == 0:
			continue
		while _count_icon_id_is_used(icons, "%s:%d" % [challenge_id, serial]):
			serial += 1
		var seed: int = abs(JsonCoerceScript._stable_hash("%s:%s:%d" % [challenge_id, key, serial]))
		var icon_pos := _count_icon_position_for_card(card, seed)
		icons.append({
			"id": "%s:%d" % [challenge_id, serial],
			"card": card.duplicate(true),
			"count_value": count_value,
			"spawn_msec": now_msec + 240 + added * COUNT_ICON_STAGGER_MSEC,
			"duration_msec": icon_duration,
			"x": icon_pos.x,
			"y": icon_pos.y,
		})
		serial += 1
		added += 1
	challenge["cards"] = cards
	challenge["icons"] = icons
	challenge["tracked_card_keys"] = tracked_keys
	challenge["icon_serial"] = serial
	challenge["target_delta"] = _count_cards_delta(cards)
	ui_state["count_challenge"] = challenge
	return added


func _count_has_new_misses(challenge: Dictionary, now_msec: int) -> bool:
	if challenge.is_empty():
		return false
	var icons_value: Variant = challenge.get("icons", [])
	if typeof(icons_value) != TYPE_ARRAY:
		return false
	var clicked_value: Variant = challenge.get("clicked_icons", [])
	var clicked: Array = clicked_value as Array if typeof(clicked_value) == TYPE_ARRAY else []
	var missed_value: Variant = challenge.get("missed_icons", [])
	var missed: Array = missed_value as Array if typeof(missed_value) == TYPE_ARRAY else []
	for icon_value in icons_value as Array:
		if typeof(icon_value) != TYPE_DICTIONARY:
			continue
		var icon: Dictionary = icon_value as Dictionary
		var icon_id := str(icon.get("id", ""))
		if icon_id.is_empty() or clicked.has(icon_id) or missed.has(icon_id):
			continue
		var spawn := int(icon.get("spawn_msec", now_msec))
		var duration := int(icon.get("duration_msec", COUNT_ICON_DURATION_MSEC))
		if now_msec > spawn + duration:
			return true
	return false


func _update_live_count_state(ui_state: Dictionary, _table: Dictionary, run_state: RunState, announce: bool = true) -> String:
	var challenge: Dictionary = _local_copy_dict(ui_state.get("count_challenge", {}))
	if challenge.is_empty() or bool(ui_state.get("count_answered", false)):
		ui_state.erase("count_live_notice")
		return ""
	_sync_count_challenge_icons(ui_state, run_state)
	challenge = _local_copy_dict(ui_state.get("count_challenge", {}))
	var missed_before: int = (_string_array(challenge.get("missed_icons", []))).size()
	var now_msec := _surface_time_for_count(ui_state)
	challenge = _refresh_count_challenge_misses(challenge, now_msec)
	var missed_after: int = (_string_array(challenge.get("missed_icons", []))).size()
	ui_state["count_challenge"] = challenge
	if missed_after <= missed_before:
		ui_state.erase("count_live_notice")
		return ""
	var new_misses: int = missed_after - missed_before
	var notice := "A count symbol slips by. Dealer attention rises." if new_misses == 1 else "%d count symbols slip by. Dealer attention rises." % new_misses
	if announce:
		ui_state["count_live_notice"] = notice
		ui_state["table_notice"] = notice
	return notice


func _finalize_count_challenge(ui_state: Dictionary, run_state: RunState, now_msec: int = -1) -> void:
	now_msec = _surface_time_for_count(ui_state, now_msec)
	_sync_count_challenge_icons(ui_state, run_state, now_msec)
	var challenge: Dictionary = _local_copy_dict(ui_state.get("count_challenge", {}))
	if challenge.is_empty():
		return
	challenge = _refresh_count_challenge_misses(challenge, now_msec)
	challenge = _mark_unresolved_count_icons_missed(challenge, now_msec)
	var target := int(challenge.get("target_delta", 0))
	var declared := int(ui_state.get("count_delta", int(challenge.get("recorded_delta", 0))))
	var clicked: Array = _string_array(challenge.get("clicked_icons", []))
	var missed: Array = _string_array(challenge.get("missed_icons", []))
	var icons: Array = _dictionary_array(challenge.get("icons", []))
	var tolerance := maxi(0, int(challenge.get("tolerance", 0)))
	var bad_hits := int(challenge.get("bad_hits", 0))
	var missed_value_count := _count_missed_nonzero_icons(challenge)
	var correct: bool = abs(declared - target) <= tolerance and missed_value_count == 0 and bad_hits == 0
	var perfect: bool = correct and clicked.size() == icons.size()
	challenge["finalized_msec"] = now_msec
	challenge["final_delta"] = declared
	challenge["correct"] = correct
	challenge["perfect"] = perfect
	ui_state["count_challenge"] = challenge
	ui_state["count_answered"] = true
	ui_state["count_correct"] = correct
	ui_state["count_perfect"] = perfect
	ui_state["count_delta"] = declared
	ui_state["count_declared_delta"] = declared


func _persist_tutorial_count_lesson_result(table: Dictionary, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> void:
	if run_state == null \
			or not run_state.is_tutorial_run() \
			or str(environment.get("archetype_id", "")) != "small_underground_casino" \
			or int(table.get("hands_played", 0)) < 2 \
			or not bool(ui_state.get("count_answered", false)):
		return
	# Surface state is intentionally discarded after a settled hand. Store the
	# lesson proof on the table so Coach observes the completed third-hand count
	# at the following boundary instead of losing it with the transient bubbles.
	table["tutorial_count_completed"] = true
	table["tutorial_count_perfect"] = bool(ui_state.get("count_perfect", false))


func _surface_time_for_count(ui_state: Dictionary, now_msec: int = -1) -> int:
	if now_msec >= 0:
		return now_msec
	if ui_state.has("surface_time_msec"):
		return maxi(0, int(ui_state.get("surface_time_msec", 0)))
	return Time.get_ticks_msec()


# Finite card and payout motion belongs to the presentation clock: it remains
# live while Pal freezes tutorial logic. Peek windows, count bubbles, and every
# automatic action continue to use surface_time_msec and therefore stay frozen.
func _blackjack_presentation_time_msec(ui_state: Dictionary, fallback_msec: int = -1) -> int:
	if ui_state.has("surface_presentation_time_msec"):
		# Saved Blackjack sessions from older builds can retain the presentation
		# timestamp from the action that dealt the card. Never let that stale value
		# move a later explicit boundary backwards and keep settlement waiting forever.
		return maxi(1, maxi(int(ui_state.get("surface_presentation_time_msec", 0)), fallback_msec))
	if fallback_msec >= 0:
		return maxi(1, fallback_msec)
	if ui_state.has("surface_time_msec"):
		return maxi(1, int(ui_state.get("surface_time_msec", 0)))
	return Time.get_ticks_msec()


func _blackjack_payout_started_msec(last_result: Dictionary, deal_started_msec: int, deal_duration_msec: int) -> int:
	if last_result.is_empty():
		return 0
	var resolved_msec := int(last_result.get("resolved_at_msec", last_result.get("timestamp_msec", 0)))
	if deal_started_msec <= 0 or deal_duration_msec <= 0:
		return resolved_msec
	# The payout follows the actual final-card reveal. Basing it on resolution plus
	# a duration assumes both clocks began together, which is not true after a
	# restored hand or a delayed authority handoff and can consume the whole payout
	# window while the reveal is still on screen.
	return maxi(resolved_msec, deal_started_msec + deal_duration_msec)


func _count_icon_card_key(card: Dictionary) -> String:
	var tracking_key := str(card.get("_count_tracking_key", ""))
	if not tracking_key.is_empty():
		return tracking_key
	var source_key := str(card.get("_count_source_key", ""))
	if not source_key.is_empty():
		return source_key
	return _count_icon_identity_key(card)


func _count_icon_identity_key(card: Dictionary) -> String:
	var identity_key := str(card.get("_count_identity_key", ""))
	if not identity_key.is_empty():
		return identity_key
	return _raw_count_icon_card_key(card)


func _count_icon_id_is_used(icons: Array, icon_id: String) -> bool:
	for icon_value in icons:
		if typeof(icon_value) == TYPE_DICTIONARY and str((icon_value as Dictionary).get("id", "")) == icon_id:
			return true
	return false


func _count_icon_position_for_card(card: Dictionary, seed: int) -> Vector2:
	var source_key := str(card.get("_count_source_key", ""))
	var parts := source_key.split(":")
	if parts.size() >= 2:
		match str(parts[0]):
			"dealer":
				return _dealer_card_target(int(parts[1])) + Vector2(18, -20)
			"player":
				if parts.size() >= 3:
					return _player_hand_card_target(int(parts[1]), int(parts[2])) + Vector2(20, -18)
			"patron":
				if parts.size() >= 3:
					return _patron_hand_card_target(int(parts[1]), int(parts[2])) + Vector2(10, -13)
	return Vector2(190.0 + float(seed % 500), 118.0 + float((int(seed / 17) % 128)))


func _raw_count_icon_card_key(card: Dictionary) -> String:
	return "%d:%d:%d" % [int(card.get("rank", 2)), int(card.get("suit", 0)), int(card.get("deck", 0))]


func _count_value_for_card(card: Dictionary) -> int:
	var rank: int = _card_rank_value(card)
	if rank >= 2 and rank <= 6:
		return 1
	if rank == 10 or rank == 11 or rank == 12 or rank == 13 or rank == RANK_ACE:
		return -1
	return 0


func _selected_surface_actions(ui_state: Dictionary, session: Dictionary) -> Array:
	var selected: Array = []
	var action_id := str(ui_state.get("selected_action_id", ""))
	var action_kind := str(ui_state.get("selected_action_kind", ""))
	if action_id == "play_basic" and action_kind == "legal":
		selected.append("blackjack_deal")
		if _has_dealt_hand(session):
			selected.append("blackjack_stand")
	if action_id == "peek_hole_card" and action_kind == "cheat":
		selected.append("blackjack_peek")
	if bool(session.get("counting_enabled", false)):
		selected.append("blackjack_count_toggle")
	if bool(session.get("dealer_hole_visible", false)):
		selected.append("blackjack_peek")
	return selected


func _can_hit(session: Dictionary) -> bool:
	var hand: Dictionary = _active_hand(session)
	if hand.is_empty() or bool(hand.get("stood", false)) or bool(hand.get("doubled", false)):
		return false
	var cards: Array = _card_array(hand.get("cards", []))
	return _hand_total(cards) < 21


func _can_stand(session: Dictionary) -> bool:
	var hand: Dictionary = _active_hand(session)
	if hand.is_empty() or bool(hand.get("stood", false)) or bool(hand.get("doubled", false)):
		return false
	var cards: Array = _card_array(hand.get("cards", []))
	var total := _hand_total(cards)
	return total > 0 and total < 21


func _can_double(session: Dictionary, table: Dictionary, stake: int = 1, run_state: RunState = null) -> bool:
	var hand: Dictionary = _active_hand(session)
	if hand.is_empty() or bool(hand.get("stood", false)) or bool(hand.get("doubled", false)):
		return false
	var cards: Array = _card_array(hand.get("cards", []))
	if cards.size() != 2:
		return false
	if bool(hand.get("split", false)) and not bool(_table_rules(table).get("double_after_split", true)):
		return false
	if not _can_afford_extra_main_wager(session, table, run_state, stake, 1):
		return false
	return _hand_total(cards) < 21


func _can_split(session: Dictionary, table: Dictionary, stake: int = 1, run_state: RunState = null) -> bool:
	var hands: Array = _hand_array(session.get("player_hands", []))
	# Re-splitting non-ace pairs is allowed until the table's max hand count.
	if hands.size() >= int(_table_rules(table).get("max_split_hands", 4)):
		return false
	var hand: Dictionary = _active_hand(session)
	if hand.is_empty() or bool(hand.get("stood", false)):
		return false
	var cards: Array = _card_array(hand.get("cards", []))
	return cards.size() == 2 and _card_split_value(cards[0]) == _card_split_value(cards[1]) and _can_afford_extra_main_wager(session, table, run_state, stake, 1)


func _can_surrender(session: Dictionary, table: Dictionary) -> bool:
	if not bool(_table_rules(table).get("late_surrender", true)):
		return false
	# Surrender is late surrender only: the opening hand before any other move,
	# unavailable after splits/doubles/hits and after a dealer blackjack check.
	if bool(session.get("moves_made", false)) or int(session.get("split_count", 0)) > 0:
		return false
	var hands: Array = _hand_array(session.get("player_hands", []))
	if hands.size() != 1:
		return false
	var hand: Dictionary = _active_hand(session)
	if hand.is_empty() or bool(hand.get("stood", false)) or bool(hand.get("doubled", false)) or bool(hand.get("split", false)):
		return false
	if _dealer_has_blackjack(_card_array(session.get("dealer_cards", []))):
		return false
	return _card_array(hand.get("cards", [])).size() == 2


func _can_afford_extra_main_wager(session: Dictionary, table: Dictionary, run_state: RunState, stake: int, extra_units: int) -> bool:
	if bool(session.get("boss_duel_session", false)):
		return true
	if run_state == null:
		return true
	var projected_cost: int = _wager_cost_from_session(stake, session, table, run_state) + maxi(1, stake) * maxi(0, extra_units)
	var additional_cost := maxi(0, projected_cost - _session_debited_wager(session))
	return additional_cost <= maxi(0, run_state.wager_capacity_for_game(get_id()))


func _can_change_side_bets(session: Dictionary) -> bool:
	return not bool(session.get("moves_made", false)) and int(session.get("split_count", 0)) <= 0


func _side_bet_can_toggle_now(bet: Dictionary, session: Dictionary) -> bool:
	if not _can_change_side_bets(session):
		return false
	if not _has_dealt_hand(session):
		return true
	return str(bet.get("id", "")) == "insurance"


func _all_hands_complete(session: Dictionary) -> bool:
	var hands_value: Variant = session.get("player_hands", [])
	var hands: Array = hands_value as Array if typeof(hands_value) == TYPE_ARRAY else []
	if hands.is_empty():
		var dealer_cards_value: Variant = session.get("dealer_cards", [])
		return bool(session.get("blackjack_sit_out", false)) and typeof(dealer_cards_value) == TYPE_ARRAY and not (dealer_cards_value as Array).is_empty()
	for hand_value in hands:
		if typeof(hand_value) != TYPE_DICTIONARY:
			return false
		var hand: Dictionary = hand_value as Dictionary
		if bool(hand.get("stood", false)):
			continue
		var cards_value: Variant = hand.get("cards", [])
		var cards: Array = cards_value as Array if typeof(cards_value) == TYPE_ARRAY else []
		if _hand_total(cards) >= 21:
			continue
		return false
	return true


func _active_hand(session: Dictionary) -> Dictionary:
	var hands: Array = _hand_array(session.get("player_hands", []))
	var active_index: int = clampi(int(session.get("active_hand_index", 0)), 0, maxi(0, hands.size() - 1))
	if active_index < 0 or active_index >= hands.size():
		return {}
	return (hands[active_index] as Dictionary).duplicate(true)


func _main_wager_cost(stake: int, session: Dictionary) -> int:
	if bool(session.get("blackjack_sit_out", false)):
		return 0
	var cost := 0
	var hands: Array = _hand_array(session.get("player_hands", []))
	if hands.is_empty():
		return maxi(1, stake)
	for hand_value in hands:
		var hand: Dictionary = hand_value
		cost += maxi(1, stake) * maxi(1, int(hand.get("wager_multiplier", 1)))
	return cost


func _wager_cost_from_session(stake: int, session: Dictionary, table: Dictionary, run_state: RunState) -> int:
	# Blackjack wager cost is deliberately session-derived because splits,
	# doubles, insurance, and side bets change risk after the initial stake.
	var cost: int = _main_wager_cost(stake, session)
	var active_ids: Array = _string_array(session.get("blackjack_side_bets", []))
	for bet in _available_side_bets_for_session(table, session):
		var bet_id := str((bet as Dictionary).get("id", ""))
		if active_ids.has(bet_id):
			var side_stake: int = _side_bet_stake(stake, bet, run_state)
			var reduction: int = _item_effect_total("blackjack_side_bet_loss_reduction", run_state)
			cost += maxi(0, side_stake - reduction)
	return cost


func _session_debited_wager(session: Dictionary) -> int:
	if not bool(session.get("bankroll_wager_debited", false)):
		return 0
	return maxi(0, int(session.get("wager_debited", 0)))


func _side_bet_stake(stake: int, bet: Dictionary, run_state: RunState) -> int:
	var bet_id := str(bet.get("id", ""))
	if bet_id == "insurance":
		return maxi(1, int(ceil(float(maxi(1, stake)) * 0.5)))
	var base_stake := maxi(1, int(ceil(float(maxi(1, stake)) * 0.25)))
	if bet_id == "lucky_ladies":
		base_stake *= maxi(1, _item_effect_total("blackjack_lucky_ladies_stake_multiplier", run_state))
	return base_stake


func _side_bet_catalog() -> Array:
	return [
		{"id": "perfect_pairs", "label": "Perfect Pairs", "summary": "Pair first two cards; suited pair pays big", "rules": ["Your first two cards must share a rank.", "Result is checked from the original deal only."], "payouts": ["mixed pair 5:1", "colored pair 10:1", "perfect pair 25:1"]},
		{"id": "twenty_one_three", "label": "21+3", "summary": "Your two plus dealer upcard as poker hand", "rules": ["Your first two cards plus dealer upcard form a 3-card poker hand.", "Only the opening upcard is used."], "payouts": ["flush 5:1", "straight 10:1", "trips 30:1", "straight flush 40:1", "suited trips 100:1"]},
		{"id": "lucky_ladies", "label": "Lucky Ladies", "summary": "First two cards total 20; queens pay more", "rules": ["Your first two cards must total 20.", "Queen bonuses use the opening two cards."], "payouts": ["twenty 4:1", "suited twenty 10:1", "suited queens 125:1", "queen hearts plus dealer blackjack 200:1"]},
		{"id": "royal_match", "label": "Royal Match", "summary": "Suited first two; suited KQ pays big", "rules": ["Your first two cards must share a suit.", "King-queen suited upgrades the win."], "payouts": ["suited match 3:1", "royal match 25:1"]},
		{"id": "insurance", "label": "Insurance", "summary": "Dealer blackjack pays 2:1", "rules": ["Only offered when dealer upcard is an ace.", "Costs half the main wager."], "payouts": ["dealer blackjack 2:1", "dealer safe loses"]},
		{"id": "buster", "label": "Buster", "summary": "Dealer busts; more dealer cards pay more", "rules": ["Wins only if the dealer busts.", "Payout improves with longer dealer bust hands."], "payouts": ["dealer bust 2:1", "5-card bust 8:1", "6-card bust 25:1", "7-card bust 100:1"]},
	]


func _normalize_side_bets(value: Variant) -> Array:
	var source: Array = _dictionary_array(value)
	if source.is_empty():
		source = _side_bet_catalog().slice(0, BLACKJACK_MAX_SIDE_BETS)
	var result: Array = []
	for bet_value in source:
		if result.size() >= BLACKJACK_MAX_SIDE_BETS:
			break
		var bet: Dictionary = bet_value
		var bet_id := str(bet.get("id", ""))
		if bet_id.is_empty() or _side_bet_index_in_list(result, bet_id) >= 0:
			continue
		var normalized: Dictionary = _side_bet_definition(bet_id)
		for key in bet.keys():
			normalized[str(key)] = bet[key]
		if _string_array(normalized.get("rules", [])).is_empty():
			normalized["rules"] = _side_bet_definition(bet_id).get("rules", [])
		if _string_array(normalized.get("payouts", [])).is_empty():
			normalized["payouts"] = _side_bet_definition(bet_id).get("payouts", [])
		result.append(normalized)
	if result.is_empty():
		result = _side_bet_catalog().slice(0, BLACKJACK_MAX_SIDE_BETS)
	return result


func _side_bet_definition(bet_id: String) -> Dictionary:
	for bet_value in _side_bet_catalog():
		if typeof(bet_value) == TYPE_DICTIONARY and str((bet_value as Dictionary).get("id", "")) == bet_id:
			return (bet_value as Dictionary).duplicate(true)
	return {"id": bet_id, "label": bet_id.replace("_", " ").capitalize(), "summary": "Opening side bet", "rules": ["Settles from blackjack table state."], "payouts": ["see table result"]}


func _side_bet_index_in_list(side_bets: Array, bet_id: String) -> int:
	for i in range(side_bets.size()):
		if typeof(side_bets[i]) == TYPE_DICTIONARY and str((side_bets[i] as Dictionary).get("id", "")) == bet_id:
			return i
	return -1


func _available_side_bets(table: Dictionary) -> Array:
	return _normalize_side_bets(table.get("side_bets", []))


func _available_side_bets_for_session(table: Dictionary, session: Dictionary) -> Array:
	var result: Array = []
	for bet_value in _available_side_bets(table):
		var bet: Dictionary = bet_value
		if _side_bet_currently_available(bet, session):
			result.append(bet)
	if _insurance_offer_available(session) and _side_bet_index_in_list(result, "insurance") < 0:
		result.append(_side_bet_definition("insurance"))
	return result


func _item_adjusted_side_bet_for_surface(bet: Dictionary, run_state: RunState) -> Dictionary:
	var adjusted := bet.duplicate(true)
	if str(adjusted.get("id", "")) != "lucky_ladies":
		return adjusted
	var stake_multiplier := maxi(1, _item_effect_total("blackjack_lucky_ladies_stake_multiplier", run_state))
	var payout_multiplier := maxi(1, _item_effect_total("blackjack_lucky_ladies_payout_multiplier", run_state))
	if stake_multiplier <= 1 and payout_multiplier <= 1:
		return adjusted
	adjusted["item_boosted"] = true
	adjusted["summary"] = "Compact active: double stake, double listed payouts"
	adjusted["rules"] = ["Costs twice the normal side bet.", "Wins pay double Lucky Ladies odds."]
	adjusted["payouts"] = ["twenty 8:1", "suited twenty 20:1", "suited queens 250:1", "queen hearts plus dealer blackjack 400:1"]
	return adjusted


func _side_bet_currently_available(bet: Dictionary, session: Dictionary) -> bool:
	var bet_id := str(bet.get("id", ""))
	if bet_id == "insurance":
		return _insurance_offer_available(session)
	return true


func _insurance_offer_available(session: Dictionary) -> bool:
	var dealer_cards: Array = _card_array(session.get("initial_dealer_cards", session.get("dealer_cards", [])))
	return not dealer_cards.is_empty() and _card_rank_value(dealer_cards[0]) == RANK_ACE


func _valid_side_bet_ids_for_session(ids: Array, table: Dictionary, session: Dictionary) -> Array:
	var valid := {}
	for bet in _available_side_bets_for_session(table, session):
		valid[str((bet as Dictionary).get("id", ""))] = true
	var result: Array = []
	for id_value in ids:
		var id := str(id_value)
		if valid.has(id) and not result.has(id):
			result.append(id)
	return result


func _perfect_pairs_payout(player_cards: Array) -> Dictionary:
	if player_cards.size() < 2 or _card_rank_value(player_cards[0]) != _card_rank_value(player_cards[1]):
		return {"payout": 0, "detail": "miss"}
	var suit_a := _card_suit_value(player_cards[0])
	var suit_b := _card_suit_value(player_cards[1])
	var suit_a_red := suit_a == 1 or suit_a == 2
	var suit_b_red := suit_b == 1 or suit_b == 2
	var same_color := suit_a_red == suit_b_red
	if suit_a == suit_b:
		return {"payout": 25, "detail": "perfect pair"}
	if same_color:
		return {"payout": 10, "detail": "colored pair"}
	return {"payout": 5, "detail": "mixed pair"}


func _twenty_one_three_payout(player_cards: Array, dealer_cards: Array) -> Dictionary:
	if player_cards.size() < 2 or dealer_cards.is_empty():
		return {"payout": 0, "detail": "miss"}
	var cards: Array = [player_cards[0], player_cards[1], dealer_cards[0]]
	var flush := _same_suit(cards)
	var trips := _same_rank(cards)
	var straight := _three_card_straight(cards)
	if trips and flush:
		return {"payout": 100, "detail": "suited trips"}
	if straight and flush:
		return {"payout": 40, "detail": "straight flush"}
	if trips:
		return {"payout": 30, "detail": "three of a kind"}
	if straight:
		return {"payout": 10, "detail": "straight"}
	if flush:
		return {"payout": 5, "detail": "flush"}
	return {"payout": 0, "detail": "miss"}


func _lucky_ladies_payout(player_cards: Array, dealer_cards: Array) -> Dictionary:
	if player_cards.size() < 2 or _card_blackjack_value(player_cards[0]) + _card_blackjack_value(player_cards[1]) != 20:
		return {"payout": 0, "detail": "miss"}
	var both_queens := _card_rank_value(player_cards[0]) == 12 and _card_rank_value(player_cards[1]) == 12
	var suited := _card_suit_value(player_cards[0]) == _card_suit_value(player_cards[1])
	if both_queens and _card_suit_value(player_cards[0]) == 1 and _card_suit_value(player_cards[1]) == 1 and _dealer_has_blackjack(dealer_cards):
		return {"payout": 200, "detail": "queen hearts with dealer blackjack"}
	if both_queens and suited:
		return {"payout": 125, "detail": "suited queens"}
	if suited:
		return {"payout": 10, "detail": "suited twenty"}
	return {"payout": 4, "detail": "twenty"}


func _royal_match_payout(player_cards: Array) -> Dictionary:
	if player_cards.size() < 2 or _card_suit_value(player_cards[0]) != _card_suit_value(player_cards[1]):
		return {"payout": 0, "detail": "miss"}
	var ranks: Array = [_card_rank_value(player_cards[0]), _card_rank_value(player_cards[1])]
	if ranks.has(13) and ranks.has(12):
		return {"payout": 25, "detail": "royal match"}
	return {"payout": 3, "detail": "suited match"}


func _insurance_payout(dealer_cards: Array) -> Dictionary:
	if dealer_cards.is_empty() or _card_rank_value(dealer_cards[0]) != RANK_ACE:
		return {"payout": 0, "detail": "dealer upcard not ace"}
	return {"payout": 2 if _dealer_has_blackjack(dealer_cards) else 0, "detail": "dealer blackjack" if _dealer_has_blackjack(dealer_cards) else "dealer safe"}


func _buster_payout(dealer_cards: Array) -> Dictionary:
	if _hand_total(dealer_cards) <= 21:
		return {"payout": 0, "detail": "dealer did not bust"}
	var count := dealer_cards.size()
	if count >= 7:
		return {"payout": 100, "detail": "seven-card dealer bust"}
	if count == 6:
		return {"payout": 25, "detail": "six-card dealer bust"}
	if count == 5:
		return {"payout": 8, "detail": "five-card dealer bust"}
	return {"payout": 2, "detail": "dealer bust"}


func _table_rules(table: Dictionary) -> Dictionary:
	var rules: Dictionary = table.get("rules", {}) if typeof(table.get("rules", {})) == TYPE_DICTIONARY else {}
	return {
		"dealer_hits_soft_17": bool(rules.get("dealer_hits_soft_17", false)),
		"double_after_split": bool(rules.get("double_after_split", false)) if int(rules.get("max_split_hands", 4)) == 1 else true,
		"split_aces_one_card": bool(rules.get("split_aces_one_card", false)),
		"max_split_hands": clampi(int(rules.get("max_split_hands", 4)), 2, 4),
		"late_surrender": bool(rules.get("late_surrender", true)),
		"blackjack_payout": BLACKJACK_PAYOUT_LABEL,
		"insurance_policy": "offered_on_dealer_ace",
	}


func _table_summary(table: Dictionary) -> String:
	var rules: Dictionary = _table_rules(table)
	return "%s blackjack, %s, count %s, %s, split to %d, dealer %s soft 17%s, insurance on ace." % [
		BLACKJACK_PAYOUT_LABEL,
		str(table.get("shoe_label", CardShoeScript.shoe_label(int(table.get("deck_count", 6))))),
		str(table.get("count_efficiency", CardShoeScript.count_efficiency_label(int(table.get("deck_count", 6))))),
		"DAS" if bool(rules.get("double_after_split", true)) else "no DAS",
		int(rules.get("max_split_hands", 4)),
		"hits" if bool(rules.get("dealer_hits_soft_17", false)) else "stands on",
		", surrender" if bool(rules.get("late_surrender", true)) else "",
	]


func _table_rules_text(surface_state: Dictionary) -> String:
	var rules: Dictionary = surface_state.get("rules", {}) if typeof(surface_state.get("rules", {})) == TYPE_DICTIONARY else {}
	return _table_rules_text_from_values(
		rules,
		int(surface_state.get("total_wager_cost", 0)),
		str(surface_state.get("shoe_label", "shoe")),
		int(surface_state.get("shoe_remaining", 0))
	)


func _table_rules_text_from_values(rules: Dictionary, total_wager_cost: int, shoe_label: String, shoe_remaining: int) -> String:
	return "%s %s %s split%d%s Ins / Risk $%d / %s %d" % [
		str(rules.get("blackjack_payout", BLACKJACK_PAYOUT_LABEL)),
		"H17" if bool(rules.get("dealer_hits_soft_17", false)) else "S17",
		"DAS" if bool(rules.get("double_after_split", true)) else "noDAS",
		int(rules.get("max_split_hands", 4)),
		" / LS" if bool(rules.get("late_surrender", true)) else "",
		total_wager_cost,
		shoe_label,
		shoe_remaining,
	]


func _session_time_msec(session: Dictionary) -> int:
	if session.has("surface_time_msec"):
		return maxi(0, int(session.get("surface_time_msec", 0)))
	return Time.get_ticks_msec()


func _dealer_lookaway_active(session: Dictionary) -> bool:
	var started := int(session.get("dealer_lookaway_started_msec", 0))
	var duration := int(session.get("dealer_lookaway_duration_msec", 0))
	if started <= 0 or duration <= 0:
		return false
	var now := _session_time_msec(session)
	return now >= started and now <= started + duration


func _dealer_peek_window_open(table: Dictionary, session: Dictionary, run_state: RunState) -> bool:
	return bool(_dealer_focus_state(table, session, run_state).get("peek_window_open", false))


func _dealer_focus_state(table: Dictionary, session: Dictionary, run_state: RunState, patron_snitch_risk: int = -1) -> Dictionary:
	var profile: Dictionary = _local_copy_dict(table.get("dealer_profile", {}))
	var base_attention: int = int(profile.get("attention_base", int(table.get("dealer_catch_base", 10)) + 12))
	var heat: int = run_state.suspicion_level() if run_state != null else 0
	var started := int(session.get("dealer_lookaway_started_msec", 0))
	var duration := int(session.get("dealer_lookaway_duration_msec", 0))
	var now := _session_time_msec(session)
	var active := started > 0 and duration > 0 and now >= started and now <= started + duration
	var remaining := maxi(0, started + duration - now) if active else 0
	var cycle_msec := maxi(900, int(320000 / maxi(45, int(profile.get("gaze_speed", 95)))))
	var phase := float((now + int(profile.get("blink_offset", 0))) % cycle_msec) / float(cycle_msec)
	var sweep := sin(phase * PI * 2.0)
	var scan_attention := int((0.5 + 0.5 * sweep) * 18.0)
	var challenge: Dictionary = _local_copy_dict(session.get("count_challenge", {}))
	var count_pressure := 0 if challenge.is_empty() or bool(session.get("count_answered", false)) else int(float(int(challenge.get("dealer_attention_risk", 0))) / 4.0)
	var strategy_pressure := clampi(int(table.get("strategy_watch_pressure", 0)) + int(session.get("strategy_attention_boost", 0)), 0, STRATEGY_DEVIATION_MAX_WATCH)
	var attention := clampi(base_attention + int(float(heat) * 0.35) + scan_attention + count_pressure + strategy_pressure + int(session.get("dealer_distraction_noise", 0)), 0, 100)
	if active:
		attention = clampi(attention - 44 - int(session.get("dealer_distraction_cover", 0)), 0, 100)
	var blink := phase > 0.94 and phase < 0.985
	var watching_player := not active and phase >= 0.18 and phase <= 0.46
	var peek_window_percent := 100
	var peek_window_effect := _item_effect_total("blackjack_peek_window_percent", run_state)
	if peek_window_effect > 0:
		peek_window_percent = clampi(peek_window_effect, 10, 100)
	var window_half_width := 0.08 * (float(peek_window_percent) / 100.0)
	var read_start := 0.62 - window_half_width
	var read_end := 0.62 + window_half_width
	var read_window := active or (attention < 58 and phase > read_start and phase < read_end)
	var snitch_risk := patron_snitch_risk if patron_snitch_risk >= 0 else _patron_snitch_risk(table, session)
	var peek_danger := clampi(attention + (0 if active else int(abs(sweep) * 16.0)) + int(snitch_risk / 4.0), 0, 100)
	var peek_window_open := active or (read_window and not watching_player and peek_danger <= 62)
	var gaze_phase := "looking away" if active else "blink" if blink else "watching you" if watching_player else "hole card loose" if peek_window_open else "open read" if read_window else str(profile.get("read_style", "slow sweep"))
	var body_language := "shoulder turned" if active else "eyes on your chips" if watching_player else "checks payout tray" if peek_window_open or phase > 0.70 else "tracks the felt"
	return {
		"lookaway_active": active,
		"lookaway_remaining_msec": remaining,
		"attention_meter": attention,
		"status": "looking away" if active else "locked on" if attention >= 70 else "watching",
		"tell": str(profile.get("tell", "watches hands more than faces")),
		"distraction_id": str(session.get("dealer_distraction_id", "")),
		"gaze_phase": gaze_phase,
		"body_language": body_language,
		"read_window": read_window,
		"watching_player": watching_player,
		"peek_window_open": peek_window_open,
		"scan_phase": phase,
		"count_pressure": count_pressure,
		"strategy_pressure": strategy_pressure,
		"peek_danger": peek_danger,
		"peek_window_percent": peek_window_percent,
		"eye_offset": -0.65 if active else sweep,
		"blink": blink,
	}


func _ambient_table_event(table: Dictionary, session: Dictionary) -> Dictionary:
	if not _has_dealt_hand(session):
		return {}
	var now := _session_time_msec(session)
	var cycle_msec := 4200
	var phase := float(now % cycle_msec) / float(cycle_msec)
	if phase > 0.42:
		return {}
	var catalog: Array = [
		{"label": "chip shuffle", "detail": "seat stack clicks", "accent": "yellow"},
		{"label": "pit glance", "detail": "security looks over", "accent": "pink"},
		{"label": "shoe tap", "detail": "dealer checks tray", "accent": "teal"},
		{"label": "patron tell", "detail": "someone leans in", "accent": "orange"},
		{"label": "felt chatter", "detail": "table noise rises", "accent": "cyan"},
	]
	var table_key: String = "%s:%d:%d" % [str(table.get("table_name", "blackjack")), int(table.get("hands_played", 0)), int(now / cycle_msec)]
	var event_seed: int = abs(JsonCoerceScript._stable_hash(table_key))
	var index: int = event_seed % catalog.size()
	var event: Dictionary = (catalog[index] as Dictionary).duplicate(true)
	event["phase"] = phase
	event["intensity"] = sin(clampf(phase / 0.42, 0.0, 1.0) * PI)
	return event


func _active_distraction_cover(session: Dictionary) -> int:
	if not _dealer_lookaway_active(session):
		return 0
	return maxi(0, int(session.get("dealer_distraction_cover", 0)))


func _patron_cover_active(session: Dictionary, patron_id: String) -> bool:
	var cover: Dictionary = _local_copy_dict(session.get("patron_cover", {}))
	var entry: Dictionary = _local_copy_dict(cover.get(patron_id, {}))
	if entry.is_empty():
		return false
	var started := int(entry.get("started_msec", 0))
	var duration := int(entry.get("duration_msec", 0))
	return started > 0 and duration > 0 and _session_time_msec(session) <= started + duration


func _patron_cover_amount(session: Dictionary, patron_id: String) -> int:
	if not _patron_cover_active(session, patron_id):
		return 0
	var cover: Dictionary = _local_copy_dict(session.get("patron_cover", {}))
	var entry: Dictionary = _local_copy_dict(cover.get(patron_id, {}))
	return maxi(0, int(entry.get("cover", 0)))


func _patrons_for_surface(table: Dictionary, session: Dictionary) -> Array:
	var patrons: Array = []
	var distraction_cover: int = _active_distraction_cover(session)
	var now := _session_time_msec(session)
	var patron_hands: Array = _hand_array(session.get("patron_hands", []))
	var source_patrons: Array = _dictionary_array(table.get("patrons", []))
	for patron_index in range(source_patrons.size()):
		var patron_value: Variant = source_patrons[patron_index]
		var patron: Dictionary = patron_value
		var patron_id := str(patron.get("id", ""))
		var covered := _patron_cover_active(session, patron_id)
		var rapport_adjust := int((50 - clampi(int(patron.get("rapport", 50)), 0, 100)) / 5)
		var risk := maxi(0, int(patron.get("snitch_risk", 0)) + rapport_adjust - distraction_cover - _patron_cover_amount(session, patron_id))
		var phase := float((now + int(patron.get("animation_offset", 0))) % 2200) / 2200.0
		var watching := bool(patron.get("watching", true)) and risk > 0 and not covered
		var threshold := int(patron.get("snitch_threshold", 30))
		var tell_active := watching and (risk >= threshold or (phase > 0.58 and phase < 0.82))
		var lean := (float(risk) / 60.0) * 5.0
		if covered:
			lean = -4.0
		var behavior := "covered" if covered else "snitch tell" if tell_active else "watching" if watching else str(patron.get("mood", "quiet"))
		patron["covered"] = covered
		patron["watching_player"] = watching
		patron["active_snitch_risk"] = risk
		patron["behavior_phase"] = phase
		patron["tell_active"] = tell_active
		patron["lean"] = lean
		patron["behavior"] = behavior
		patron["visible_bet"] = _blackjack_patron_wager(patron, table)
		var hand: Dictionary = _patron_hand_for_id(patron_hands, patron_id, patron_index)
		if not hand.is_empty():
			patron["cards"] = _card_array(hand.get("cards", []))
			patron["hand_total"] = _hand_total(_card_array(hand.get("cards", [])))
			patron["hand_status"] = str(hand.get("terminal_reason", ""))
			patron["hand_action"] = str(hand.get("last_action", ""))
			patron["hand_action_label"] = str(hand.get("last_action_label", ""))
			patron["hand_action_reason"] = str(hand.get("last_decision_reason", ""))
			patron["hand_peek_informed"] = bool(hand.get("peek_informed", false))
		patrons.append(patron)
	return patrons


func _patron_hand_for_id(patron_hands: Array, patron_id: String, fallback_index: int) -> Dictionary:
	for hand_value in patron_hands:
		if typeof(hand_value) != TYPE_DICTIONARY:
			continue
		var hand: Dictionary = hand_value
		if str(hand.get("patron_id", "")) == patron_id:
			return hand.duplicate(true)
	if fallback_index >= 0 and fallback_index < patron_hands.size() and typeof(patron_hands[fallback_index]) == TYPE_DICTIONARY:
		return (patron_hands[fallback_index] as Dictionary).duplicate(true)
	return {}


func _patron_snitch_risk_from_patrons(patrons: Array) -> int:
	var total := 0
	for patron_value in patrons:
		if typeof(patron_value) != TYPE_DICTIONARY:
			continue
		var patron: Dictionary = patron_value
		if bool(patron.get("watching_player", false)):
			total += int(patron.get("active_snitch_risk", 0))
	return total


func _patron_snitch_risk(table: Dictionary, session: Dictionary) -> int:
	return _patron_snitch_risk_from_patrons(_patrons_for_surface(table, session))


func _chip_stack_for_stake(stake: int, chip_values: Array) -> Array:
	var sorted_values: Array = chip_values.duplicate()
	sorted_values.sort()
	sorted_values.reverse()
	var remaining := maxi(0, stake)
	var stack: Array = []
	for value in sorted_values:
		var chip_value := maxi(1, int(value))
		var count := int(floor(float(remaining) / float(chip_value)))
		if count <= 0:
			continue
		stack.append({"value": chip_value, "count": count})
		remaining -= count * chip_value
	return stack


func _surface_state_labels(table: Dictionary, session: Dictionary) -> Array:
	return [
		{"label": "Shoe", "value": "%s %d" % [str(table.get("shoe_label", CardShoeScript.shoe_label(int(table.get("deck_count", 6))))), _shoe_remaining(table)]},
		{"label": "Count", "value": "%+d" % _recorded_count_for_surface(table, session)},
		{"label": "Side bets", "value": str((_string_array(session.get("blackjack_side_bets", []))).size())},
	]


func _count_hint(run_state: RunState, table: Dictionary, session: Dictionary) -> String:
	var recorded := _recorded_count_for_surface(table, session)
	var spotter_line := ""
	if run_state != null and run_state.crew_play_active("spotter"):
		spotter_line = " Switch signals confidence within one."
	if bool(session.get("count_correct", false)):
		return ("Recorded count %+d." % recorded) + spotter_line
	if bool(session.get("count_answered", false)):
		return ("Recorded dirty count %+d; true shoe may disagree." % recorded) + spotter_line
	if not _local_copy_dict(session.get("count_challenge", {})).is_empty():
		return ("Live hand delta %+d; shoe count %+d." % [int(session.get("count_delta", 0)), recorded]) + spotter_line
	if run_state != null and run_state.suspicion_level() >= 65:
		return "The dealer is tracking your eyes."
	if recorded >= 4:
		return "High recorded count. Big cards remain."
	if recorded <= -4:
		return "Low recorded count. Shoe runs small."
	return "Count is neutral unless you can track it."


func _draw_crew_play_status(surface, state: Dictionary) -> void:
	var statuses := _draw_array_view(state.get("crew_play_status", []))
	if statuses.is_empty():
		return
	var labels: Array = []
	for status in statuses:
		labels.append("%s · %d" % [str(status.get("display_name", "PLAY")).to_upper(), int(status.get("remaining_boundaries", 0))])
	var rect := Rect2(620, 4, 268, 18)
	surface.draw_rect(rect, Color(C_CYAN.r, C_CYAN.g, C_CYAN.b, 0.16))
	surface.draw_rect(rect, C_CYAN, false, 1)
	surface.surface_label_centered("  ".join(labels), rect.grow(-2), 8, C_CYAN)


func _recorded_count_for_surface(table: Dictionary, session: Dictionary) -> int:
	return int(table.get("recorded_running_count", 0)) + int(session.get("count_delta", 0))


func _true_count_for_surface(table: Dictionary, session: Dictionary) -> int:
	var challenge: Dictionary = _local_copy_dict(session.get("count_challenge", {}))
	var live_delta := int(challenge.get("target_delta", 0)) if not challenge.is_empty() else 0
	return int(table.get("running_count", 0)) + live_delta


func _blackjack_result_message(hand_results: Array, side_results: Array, main_delta: int, side_delta: int, cheat: Dictionary, item_adjustment: Dictionary, security_message: String) -> String:
	var hand_details: Array = []
	var dealer_total := 0
	for hand_value in hand_results:
		var hand: Dictionary = hand_value
		dealer_total = int(hand.get("dealer_total", dealer_total))
		hand_details.append(_blackjack_hand_result_detail(hand, hand_details.size()))
	var side_details: Array = []
	for side_value in side_results:
		var side: Dictionary = side_value
		side_details.append(_blackjack_side_result_detail(side))
	var message := "No player wager. Main %+d" % main_delta
	if not hand_details.is_empty():
		message = "Dealer %d. %s. Main %+d" % [dealer_total, "; ".join(hand_details), main_delta]
	if side_delta != 0:
		message += ". Side %+d" % side_delta
	if not side_details.is_empty():
		message += " (%s)" % "; ".join(side_details).left(96)
	if bool(cheat.get("strategy_confronted", false)):
		message += ". Dealer challenges the off-book line."
	elif bool(cheat.get("caught", false)):
		message += ". Caught cheating; heat spikes."
	elif int(cheat.get("suspicion_delta", 0)) > 0:
		message += ". Risky play adds heat."
	var gear := str(item_adjustment.get("summary", ""))
	if not gear.is_empty():
		message += " %s" % gear
	if not security_message.is_empty():
		message += " %s" % security_message
	return message


func _blackjack_hand_result_detail(hand: Dictionary, hand_index: int) -> String:
	var outcome := str(hand.get("outcome", "push"))
	var player_total := int(hand.get("player_total", 0))
	var dealer_total := int(hand.get("dealer_total", 0))
	var wager := maxi(1, int(hand.get("wager", 1)))
	var delta := int(hand.get("bankroll_delta", 0))
	var prefix := "H%d" % (hand_index + 1)
	match outcome:
		"blackjack":
			return "%s blackjack pays %s on $%d (%+d)" % [prefix, BLACKJACK_PAYOUT_LABEL, wager, delta]
		"dealer_blackjack":
			return "%s dealer blackjack beats %d (%+d)" % [prefix, player_total, delta]
		"bust":
			return "%s busts at %d (%+d)" % [prefix, player_total, delta]
		"dealer_bust":
			return "%s dealer bust pays %d (%+d)" % [prefix, player_total, delta]
		"win":
			return "%s %d beats %d (%+d)" % [prefix, player_total, dealer_total, delta]
		"lose":
			return "%s %d loses to %d (%+d)" % [prefix, player_total, dealer_total, delta]
		"surrender":
			return "%s late surrender returns half of $%d (%+d)" % [prefix, wager, delta]
		_:
			return "%s push %d-%d (%+d)" % [prefix, player_total, dealer_total, delta]


func _blackjack_side_result_detail(side: Dictionary) -> String:
	var label := str(side.get("label", side.get("id", "Side bet")))
	var detail := str(side.get("detail", "settled"))
	var delta := int(side.get("bankroll_delta", 0))
	return "%s %s %+d" % [label, detail, delta]


func _blackjack_last_result_payload(options: FunctionOptions.BlackjackResultOptions) -> Dictionary:
	var message := str(options.values.get("message", ""))
	var hand_results: Array = options.values.get("hand_results", [])
	var side_results: Array = options.values.get("side_results", [])
	var main_delta := int(options.values.get("main_delta", 0))
	var side_delta := int(options.values.get("side_delta", 0))
	var bankroll_delta := int(options.values.get("bankroll_delta", 0))
	var suspicion_delta := int(options.values.get("suspicion_delta", 0))
	var dealer_cards: Array = options.values.get("dealer_cards", [])
	var player_hands: Array = options.values.get("player_hands", [])
	var patron_hands: Array = options.values.get("patron_hands", [])
	var patron_action_events: Array = options.values.get("patron_action_events", [])
	var cheat: Dictionary = options.values.get("cheat", {})
	var result_msec := int(options.values.get("result_msec", 0))
	var round_net_delta_value: Variant = options.values.get("round_net_delta_value", null)
	var resolved_at := maxi(0, result_msec)
	var round_net_delta := main_delta + side_delta if round_net_delta_value == null else int(round_net_delta_value)
	var headline := "PUSH"
	if round_net_delta > 0:
		headline = "PLAYER PAID"
	elif round_net_delta < 0:
		headline = "HOUSE TAKES"
	if bool(cheat.get("caught", false)):
		headline = "HEAT SPIKE"
	var outcome_labels: Array = []
	for hand_value in hand_results:
		if typeof(hand_value) == TYPE_DICTIONARY:
			outcome_labels.append(str((hand_value as Dictionary).get("outcome", "push")).replace("_", " "))
	var side_wins: Array = []
	for side_value in side_results:
		if typeof(side_value) == TYPE_DICTIONARY and bool((side_value as Dictionary).get("won", false)):
			side_wins.append(str((side_value as Dictionary).get("label", "")))
	return {
		"summary": message,
		"headline": headline,
		"main_delta": main_delta,
		"side_delta": side_delta,
		"bankroll_delta": bankroll_delta,
		"round_net_delta": round_net_delta,
		"suspicion_delta": suspicion_delta,
		"dealer_total": int(_hand_total_info(dealer_cards).get("total", 0)),
		"dealer_cards": _card_array(dealer_cards),
		"player_hands": _hand_array(player_hands),
		"patron_hands": _hand_array(patron_hands),
		"patron_action_events": _patron_action_event_array(patron_action_events),
		"hand_results": _dictionary_array(hand_results),
		"side_bet_results": _dictionary_array(side_results),
		"outcomes": outcome_labels,
		"side_wins": side_wins,
		"caught": bool(cheat.get("caught", false)),
		"catch_chance": int(cheat.get("catch_chance", 0)),
		"strategy_confronted": bool(cheat.get("strategy_confronted", false)),
		"strategy_deviation_events": _dictionary_array(cheat.get("strategy_deviation_events", [])),
		"resolved_at_msec": resolved_at,
		"timestamp_msec": resolved_at,
		"payout_animation_id": "%s:payout:%d:%d" % [get_id(), resolved_at, round_net_delta],
	}


func _cards_used_for_counting(hands: Array, dealer_cards: Array, patron_hands: Array = []) -> Array:
	var used: Array = []
	for hand_value in hands:
		var hand: Dictionary = hand_value
		for card in _card_array(hand.get("cards", [])):
			used.append(card)
	for patron_hand_value in patron_hands:
		var patron_hand: Dictionary = patron_hand_value
		for card in _card_array(patron_hand.get("cards", [])):
			used.append(card)
	for card in dealer_cards:
		if typeof(card) == TYPE_DICTIONARY:
			used.append((card as Dictionary).duplicate(true))
	return used


func _count_cards_delta(cards: Array) -> int:
	var delta := 0
	for card_value in cards:
		if typeof(card_value) != TYPE_DICTIONARY:
			continue
		var rank: int = _card_rank_value(card_value)
		if rank >= 2 and rank <= 6:
			delta += 1
		elif rank == 10 or rank == 11 or rank == 12 or rank == 13 or rank == RANK_ACE:
			delta -= 1
	return delta


func _hand_total(cards: Array) -> int:
	return int(_hand_total_info(cards).get("total", 0))


func _hand_total_info(cards: Array) -> Dictionary:
	var total := 0
	var aces := 0
	for card_value in cards:
		if typeof(card_value) != TYPE_DICTIONARY:
			continue
		var rank: int = _card_rank_value(card_value)
		if rank == RANK_ACE:
			total += 11
			aces += 1
		else:
			total += mini(rank, 10)
	var soft := aces > 0
	while total > 21 and aces > 0:
		total -= 10
		aces -= 1
	soft = aces > 0
	return {"total": total, "soft": soft}


func _is_bust(cards: Array) -> bool:
	return _hand_total(cards) > 21


func _is_natural_blackjack(hand: Dictionary) -> bool:
	var cards := _card_array(hand.get("cards", []))
	if cards.size() != 2 or _hand_total(cards) != 21:
		return false
	# Active saves from the old rule carry explicit false on every split hand.
	# Recognize only an Ace-origin two-card split; settled history is untouched.
	var split_ace := bool(hand.get("split", false)) and _card_rank_value(cards[0]) == RANK_ACE \
		and not bool(hand.get("doubled", false)) and not bool(hand.get("surrendered", false))
	return bool(hand.get("blackjack_eligible", false)) or split_ace


func _dealer_has_blackjack(dealer_cards: Array) -> bool:
	return dealer_cards.size() == 2 and _hand_total(dealer_cards) == 21


func _hand_label(hand: Dictionary) -> String:
	var cards: Array = _card_array(hand.get("cards", []))
	var total: int = _hand_total(cards)
	var flags: Array = []
	if bool(hand.get("doubled", false)):
		flags.append("double")
	if bool(hand.get("split", false)):
		flags.append("split")
	if bool(hand.get("surrendered", false)):
		flags.append("surrender")
	elif total > 21:
		flags.append("bust")
	elif bool(hand.get("stood", false)):
		flags.append("stood")
	return "%d%s" % [total, " / " + ", ".join(flags) if not flags.is_empty() else ""]


func _dealer_view(dealer_cards: Array, reveal_hole: bool) -> Array:
	var dealer_view: Array = []
	for i in range(dealer_cards.size()):
		var card: Dictionary = (dealer_cards[i] as Dictionary).duplicate(true)
		if i == 1 and not reveal_hole:
			card["hidden"] = true
		dealer_view.append(card)
	return dealer_view


func _draw_card(surface, card_value: Variant, pos: Vector2, scale: float = 1.0) -> void:
	PlayingCardRendererScript.draw_card(surface, card_value, Rect2(pos, Vector2(42, 60) * scale))


func _same_suit(cards: Array) -> bool:
	if cards.is_empty():
		return false
	var suit: int = _card_suit_value(cards[0])
	for card in cards:
		if _card_suit_value(card) != suit:
			return false
	return true


func _same_rank(cards: Array) -> bool:
	if cards.is_empty():
		return false
	var rank: int = _card_rank_value(cards[0])
	for card in cards:
		if _card_rank_value(card) != rank:
			return false
	return true


func _three_card_straight(cards: Array) -> bool:
	var ranks: Array = []
	for card in cards:
		var rank: int = _card_rank_value(card)
		ranks.append(1 if rank == RANK_ACE else rank)
		if rank == RANK_ACE:
			ranks.append(14)
	ranks.sort()
	for i in range(ranks.size() - 2):
		var a: int = int(ranks[i])
		var b: int = int(ranks[i + 1])
		var c: int = int(ranks[i + 2])
		if a + 1 == b and b + 1 == c:
			return true
	return false


func _card_rank_value(card_value: Variant) -> int:
	if typeof(card_value) != TYPE_DICTIONARY:
		return 2
	return int((card_value as Dictionary).get("rank", 2))


func _card_suit_value(card_value: Variant) -> int:
	if typeof(card_value) != TYPE_DICTIONARY:
		return 0
	return int((card_value as Dictionary).get("suit", 0))


func _card_blackjack_value(card_value: Variant) -> int:
	var rank: int = _card_rank_value(card_value)
	return 11 if rank == RANK_ACE else mini(rank, 10)


func _card_split_value(card_value: Variant) -> int:
	var rank: int = _card_rank_value(card_value)
	return RANK_ACE if rank == RANK_ACE else mini(rank, 10)


func _shoe_remaining(table: Dictionary) -> int:
	return CardShoeScript.remaining_count(table.get("shoe", []))


func _side_bet_labels(side_bets: Array) -> Array:
	var labels: Array = []
	for value in side_bets:
		if typeof(value) == TYPE_DICTIONARY:
			labels.append(str((value as Dictionary).get("label", (value as Dictionary).get("id", ""))))
	return labels


func _item_effect_total(key: String, run_state: RunState) -> int:
	# Shared item lookup for blackjack-specific effect keys. It supports both
	# direct effect entries and family-scoped entries for future table games.
	if library == null or run_state == null:
		return 0
	var total := 0
	for inventory_entry in run_state.inventory:
		var item_id := _inventory_item_id(inventory_entry)
		if item_id.is_empty():
			continue
		var item := library.item(item_id)
		if item.is_empty():
			continue
		var effect: Dictionary = item.get("effect", {}) if typeof(item.get("effect", {})) == TYPE_DICTIONARY else {}
		total += int(effect.get(key, 0))
		var families: Dictionary = effect.get("families", {}) if typeof(effect.get("families", {})) == TYPE_DICTIONARY else {}
		var family_effect: Dictionary = families.get(get_family(), {}) if typeof(families.get(get_family(), {})) == TYPE_DICTIONARY else {}
		total += int(family_effect.get(key, 0))
	return total


func _coolers_cufflinks_absorbed_failed_peek(action_id: String, cheat: Dictionary, run_state: RunState) -> bool:
	if run_state == null or not ["peek_hole_card", "play_basic"].has(action_id):
		return false
	if not run_state.inventory.has(COOLERS_CUFFLINKS_ITEM_ID):
		return false
	return bool(cheat.get("used_peek", false)) and bool(cheat.get("caught", false))


func _hand_array(value: Variant) -> Array:
	var result: Array = []
	if typeof(value) != TYPE_ARRAY:
		return result
	for entry in value:
		if typeof(entry) != TYPE_DICTIONARY:
			continue
		var hand: Dictionary = (entry as Dictionary).duplicate(true)
		hand["cards"] = _card_array(hand.get("cards", []))
		hand["wager_multiplier"] = maxi(1, int(hand.get("wager_multiplier", 1)))
		hand["stood"] = bool(hand.get("stood", false))
		hand["doubled"] = bool(hand.get("doubled", false))
		hand["split"] = bool(hand.get("split", false))
		hand["surrendered"] = bool(hand.get("surrendered", false))
		hand["blackjack_eligible"] = bool(hand.get("blackjack_eligible", not bool(hand.get("split", false))))
		hand["terminal_reason"] = str(hand.get("terminal_reason", ""))
		result.append(hand)
	return result


func _card_array(value: Variant) -> Array:
	return _dictionary_array(value)


func _local_copy_dict(value: Variant) -> Dictionary:
	if typeof(value) != TYPE_DICTIONARY:
		return {}
	return (value as Dictionary).duplicate(true)


# Surface-state collections are immutable for the duration of a draw. These
# zero-copy views keep animated hands, actors, side bets, and settlement records
# off the allocator without changing any renderer output.
static func _draw_dict_view(value: Variant) -> Dictionary:
	return value as Dictionary if typeof(value) == TYPE_DICTIONARY else {}


static func _draw_array_view(value: Variant) -> Array:
	return value as Array if typeof(value) == TYPE_ARRAY else []


func round_net_feedback_delta(result: Dictionary) -> Variant:
	if str(result.get("game_id", result.get("source_id", ""))) != "blackjack" \
			or bool(result.get("applied_currency_unknown", false)) \
			or not GameModule.applied_currency_settlement(result).is_empty():
		return null
	for key in ["outcome_bankroll_delta", "round_net_delta", "blackjack_round_net_delta"]:
		if result.has(key):
			var value: Variant = result[key]
			return int(value) if _feedback_value_is_integer(value) else null
	return null


func round_net_feedback_lead(result: Dictionary) -> String:
	var net: Variant = round_net_feedback_delta(result)
	if net == null:
		return ""
	var currency := str(result.get("currency", ""))
	if currency == "chips":
		return "Blackjack net: %+d chips." % int(net)
	if currency == "cash":
		return "Blackjack net: $%+d." % int(net)
	return ""


func story_is_unwagered_observation(entry: Dictionary) -> bool:
	if str(entry.get("type", "")) != "game_action" or str(entry.get("game_id", "")) != "blackjack" or not bool(entry.get("sat_out", false)):
		return false
	# Watching the next automatic hand must not replace the last paid outcome.
	# Retain any money, Heat, security or terminal consequence as a real result.
	if bool(entry.get("ended", false)) or bool(entry.get("dealer_caught_cheat", false)) \
			or not str(entry.get("security_message", "")).is_empty() or entry.has("applied_currency_settlement"):
		return false
	for key in ["bankroll_delta", "currency_delta", "chips_delta", "cash_delta", "round_net_delta", "outcome_bankroll_delta", "blackjack_round_net_delta", "suspicion_delta", "stake", "wager_debited", "total_wager", "settlement_return_delta", "main_delta", "side_delta", "nominal_bankroll_delta"]:
		if entry.has(key) and (not _feedback_value_is_integer(entry[key]) or int(entry[key]) != 0):
			return false
	var settlement := JsonCoerceScript._copy_dict(entry.get("settlement", {}))
	if settlement.has("delta") and (not _feedback_value_is_integer(settlement.delta) or int(settlement.delta) != 0):
		return false
	return true


func story_is_unmeasured_penalty(entry: Dictionary) -> bool:
	var room := str(entry.get("environment_archetype_id", entry.get("environment_id", "")))
	return str(entry.get("game_id", "")) == "blackjack" and int(entry.get("bankroll_delta", 0)) <= 0 \
			and bool(entry.get("dealer_caught_cheat", false)) \
			and (room == "grand_casino" or room.begins_with("grand_casino_"))


func _feedback_value_is_integer(value: Variant) -> bool:
	return typeof(value) in [TYPE_INT, TYPE_FLOAT] and is_finite(float(value)) and float(value) == float(int(value))

func restored_surface_stake(ui_state: Dictionary) -> int:
	return int(ui_state.get("selected_stake", 0))

func uses_round_net_feedback() -> bool:
	return true

func story_feedback_keys() -> Array:
	return ["round_net_delta", "outcome_bankroll_delta", "blackjack_round_net_delta"]

func unmeasured_penalty_message(entry: Dictionary, nominal: int) -> String:
	var label := "Caught peeking" if str(entry.get("action_id", "")) == "peek_hole_card" else "Blackjack penalty"
	return "%s. Recorded penalty: %d chips. The actual applied loss was not recorded in this older save." % [label, absi(nominal)]

func settled_round_message() -> String:
	return "Blackjack hand settled."

func terminal_checkpoint_uses_web_phases(environment: Dictionary) -> bool:
	var flags := JsonCoerceScript._copy_dict(environment.get("local_narrative_flags", {}))
	return str(flags.get("blackjack_boss_variant", "")) == "rourke_duel"


func _cached_chip_rim_geometry(center: Vector2, radius: float) -> PackedVector2Array:
	var key := Vector3(center.x, center.y, radius)
	if chip_rim_geometry_cache.has(key):
		return chip_rim_geometry_cache[key]
	var points := PackedVector2Array()
	for index in range(12):
		var angle := (float(index) / 12.0) * PI * 2.0
		var direction := Vector2(cos(angle), sin(angle))
		points.append(center + direction * radius * 0.70)
		points.append(center + direction * radius * 0.98)
	if chip_rim_geometry_cache.size() >= CHIP_RIM_GEOMETRY_CACHE_LIMIT:
		chip_rim_geometry_cache.erase(chip_rim_geometry_cache.keys()[0])
	chip_rim_geometry_cache[key] = points
	return points
