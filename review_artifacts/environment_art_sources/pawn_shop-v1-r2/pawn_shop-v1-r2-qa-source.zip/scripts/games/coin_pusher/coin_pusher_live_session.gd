class_name CoinPusherLiveSession
extends RefCounted

const CoinPusherSolverScript := preload("res://scripts/games/coin_pusher/coin_pusher_solver_api.gd")
const SNAPSHOT_SCHEMA := "coin_pusher_settled_v3"
const SNAPSHOT_VERSION := 3
const FIXED_HZ := 60
const DROP_RELEASE_INTERVAL_TICKS := 20
const MAX_CATCH_UP_TICKS := 4
const MAX_SETTLE_TICKS := 1200
# Retain a small recent consumed prefix for diagnostics, then release it in one
# batch. At 60 accepted moves per second, keeping the full history retained
# about 19 MB after 30,000 inputs despite the solver consuming every event.
const INPUT_TRACE_COMPACT_MIN_CONSUMED := 1024
# The renderer's packed native batch keeps a published frame bounded. The old
# 1.1-second Web throttle predated that path and made the cabinet visibly update
# at less than one frame per second even when the solver itself stayed healthy.
const WEB_PRESENTATION_INTERVAL_MSEC := 33

static var _native_cache_generation := 0


static func begin(machine: Dictionary, machine_definition: Dictionary, seed: int, start_motor_on_open: bool = false) -> Dictionary:
	_native_cache_generation += 1
	if typeof(machine.get("simulation", {})) != TYPE_DICTIONARY \
			or str((machine.get("simulation", {}) as Dictionary).get("schema", "")) != CoinPusherSolverScript.SCHEMA:
		var snapshot: Dictionary = machine.get("settled_state", {}) if typeof(machine.get("settled_state", {})) == TYPE_DICTIONARY else {}
		if str(snapshot.get("schema", "")) == SNAPSHOT_SCHEMA:
			machine["simulation"] = restore_snapshot(snapshot, machine_definition)
			machine["motor_started"] = bool(snapshot.get("motor_started", int(snapshot.get("version", 1)) < 3))
			machine["selected_nozzle_id"] = str(snapshot.get("selected_nozzle_id", ""))
			machine["drop_queue"] = (snapshot.get("drop_queue", []) as Array).duplicate(true) if typeof(snapshot.get("drop_queue", [])) == TYPE_ARRAY else []
			machine["variation_state"] = (snapshot.get("sub_game", {}) as Dictionary).duplicate(true) if typeof(snapshot.get("sub_game", {})) == TYPE_DICTIONARY else {}
			var alarm: Dictionary = snapshot.get("alarm", {}) if typeof(snapshot.get("alarm", {})) == TYPE_DICTIONARY else {}
			machine["tell_rung"] = int(alarm.get("tell_rung", machine.get("tell_rung", 0)))
			machine["tell_decay_remaining_ticks"] = int(alarm.get("tell_decay_remaining_ticks", machine.get("tell_decay_remaining_ticks", 0)))
			machine["alarm_tolerance_remaining"] = int(alarm.get("tolerance", machine.get("alarm_tolerance_remaining", 0)))
			machine["locked_down"] = bool(alarm.get("night_lock", machine.get("locked_down", false)))
	var simulation: Dictionary = machine.get("simulation", {}) if typeof(machine.get("simulation", {})) == TYPE_DICTIONARY else {}
	if not simulation.has("carriage_x"):
		var apparatus: Dictionary = machine_definition.get("apparatus", {}) if typeof(machine_definition.get("apparatus", {})) == TYPE_DICTIONARY else {}
		var rail: Dictionary = apparatus.get("rail", {}) if typeof(apparatus.get("rail", {})) == TYPE_DICTIONARY else {}
		var geometry: Dictionary = machine_definition.get("geometry", {}) if typeof(machine_definition.get("geometry", {})) == TYPE_DICTIONARY else {}
		simulation["carriage_x"] = int(rail.get("default_x", int(geometry.get("width", 100000)) / 2))
	if not simulation.has("selected_hole"):
		simulation["selected_hole"] = 0
	if not simulation.has("collected_count"):
		simulation["collected_count"] = 0
	if not simulation.has("collected_value"):
		simulation["collected_value"] = 0
	if not simulation.has("cup_consumed_count"):
		simulation["cup_consumed_count"] = 0
	if not simulation.has("cup_consumed_value"):
		simulation["cup_consumed_value"] = 0
	if not machine.has("motor_started"):
		machine["motor_started"] = false
	if start_motor_on_open:
		# The cabinet is frozen only while absent. Re-entry always resumes its
		# continuously stroking platform unless a hard alarm locked the machine.
		machine["motor_started"] = not bool(machine.get("locked_down", false))
		if bool(machine.get("motor_started", false)):
			simulation["skill_stop_engaged"] = false
	var run_rate := int(simulation.get("motor_run_rate_fp", CoinPusherSolverScript.FP))
	var motor_should_run := bool(machine.get("motor_started", false)) \
			and not bool(machine.get("locked_down", false)) \
			and not bool(simulation.get("skill_stop_engaged", false))
	simulation["motor_target_rate_fp"] = run_rate if motor_should_run else 0
	if typeof(machine.get("drop_queue", [])) != TYPE_ARRAY:
		machine["drop_queue"] = []
	if not machine.has("selected_nozzle_id") or str(machine.get("selected_nozzle_id", "")).is_empty():
		machine["selected_nozzle_id"] = _default_nozzle_id(machine_definition, simulation)
	var rng := RngStream.new()
	rng.configure(seed)
	var opening_views := _presentation_body_views(simulation)
	machine["live_session"] = {
		"open": true,
		"input_locked": false,
		"last_clock_msec": -1,
		"accumulator_units": 0,
		"input_trace": [],
		"input_cursor": 0,
		"input_count": 0,
		"rng": rng.snapshot(),
		"start_snapshot": CoinPusherSolverScript.canonical_digest(simulation),
		"liveness_ticks": 0,
		"durable_ready": true,
		"durable_dirty": false,
		"last_persisted_tick": int(simulation.get("tick", 0)),
		# Presentation-only tick pair. These public views let the renderer
		# interpolate exact contact results without reading solver internals or
		# reconstructing a previous position from velocity.
		"presentation_previous_bodies": opening_views.duplicate(true),
		"presentation_current_bodies": opening_views,
		"presentation_previous_packed": PackedInt64Array(),
		"presentation_current_packed": PackedInt64Array(),
		"presentation_feature_count": _presentation_feature_count(opening_views),
		"presentation_previous_face_y": int(simulation.get("face_y", 0)),
		"presentation_current_face_y": int(simulation.get("face_y", 0)),
		"presentation_view_serial": 0,
		"presentation_last_publish_msec": -1,
		"presentation_audio_serial": 0,
		# Empty authority ticks dominate a live cabinet. Reuse these private
		# presentation-only arrays so the Web main thread does not create two
		# short-lived containers on every 60 Hz tick. Non-empty audio results are
		# copied before publication, so a later clear can never mutate canvas state.
		"presentation_audio_scratch": [],
		"presentation_audio_kind_scratch": [],
		"presentation_motion": {},
		# A fresh authority gets a new generation even when deterministic fixture
		# re-entry deliberately reuses the same seed.
		"native_cache_key": "live:%s:%s" % [seed, _native_cache_generation],
		"native_cache_reset": true,
		# Reused only across synchronous native calls. The native cache drops its
		# read-only call-context reference before returning, so these containers can
		# be cleared and refilled without retaining input or RNG objects.
		"native_step_config_scratch": {},
		"native_trace_slice_scratch": [],
		"native_body_state_dirty": false,
		"native_steady_without_motor": false,
		"native_steady_with_motor": false,
	}
	return machine["live_session"]


static func queue_input(machine: Dictionary, input: Dictionary) -> Dictionary:
	var simulation: Dictionary = machine.get("simulation", {}) if typeof(machine.get("simulation", {})) == TYPE_DICTIONARY else {}
	var session: Dictionary = machine.get("live_session", {}) if typeof(machine.get("live_session", {})) == TYPE_DICTIONARY else {}
	if session.is_empty() or bool(session.get("input_locked", false)):
		return {}
	return _append_input(simulation, session, input)


static func _append_input(simulation: Dictionary, session: Dictionary, input: Dictionary) -> Dictionary:
	var event := input.duplicate(true)
	event["tick"] = int(simulation.get("tick", 0))
	var trace: Array = session["input_trace"]
	session["input_count"] = maxi(int(session.get("input_count", 0)), trace.size()) + 1
	trace.append(event)
	# Controls acknowledge immediately through their action patch. Dense coin
	# views keep the cadence of the last actual publication: resetting that clock
	# for every input would postpone them forever during continuous rail motion.
	session["durable_ready"] = false
	session["durable_dirty"] = true
	return event


static func presentation_publish_due(machine: Dictionary, now_msec: int) -> bool:
	if not OS.has_feature("web"):
		return true
	var session_value: Variant = machine.get("live_session")
	var session: Dictionary = session_value if typeof(session_value) == TYPE_DICTIONARY else {}
	if session.is_empty():
		return true
	var last_publish_msec := int(session.get("presentation_last_publish_msec", -1))
	return last_publish_msec < 0 or now_msec - last_publish_msec >= WEB_PRESENTATION_INTERVAL_MSEC


static func total_input_count(machine: Dictionary) -> int:
	var session: Dictionary = machine.get("live_session", {})
	var trace: Array = session.get("input_trace", [])
	return maxi(int(session.get("input_count", 0)), trace.size())


static func mark_presentation_published(machine: Dictionary, now_msec: int) -> void:
	var session_value: Variant = machine.get("live_session")
	var session: Dictionary = session_value if typeof(session_value) == TYPE_DICTIONARY else {}
	if not session.is_empty():
		session["presentation_last_publish_msec"] = now_msec


static func enqueue_drops(machine: Dictionary, request: Dictionary, count: int) -> int:
	var simulation: Dictionary = machine.get("simulation", {}) if typeof(machine.get("simulation", {})) == TYPE_DICTIONARY else {}
	var session: Dictionary = machine.get("live_session", {}) if typeof(machine.get("live_session", {})) == TYPE_DICTIONARY else {}
	if simulation.is_empty() or session.is_empty() or (bool(session.get("input_locked", false)) and not bool(request.get("bonus_origin", false))):
		return 0
	var accepted := maxi(0, count)
	if accepted <= 0:
		return 0
	var item := request.duplicate(true)
	item["remaining"] = accepted
	item["next_emit_tick"] = maxi(int(simulation.get("tick", 0)), int(item.get("next_emit_tick", simulation.get("tick", 0))))
	item["nozzle_id"] = str(item.get("nozzle_id", machine.get("selected_nozzle_id", _default_nozzle_id(_machine_definition(simulation), simulation))))
	var queue: Array = machine.get("drop_queue", []) if typeof(machine.get("drop_queue", [])) == TYPE_ARRAY else []
	queue.append(item)
	machine["drop_queue"] = queue
	machine["motor_started"] = true
	if not bool(simulation.get("skill_stop_engaged", false)):
		var run_rate := int(simulation.get("motor_run_rate_fp", CoinPusherSolverScript.FP))
		simulation["motor_target_rate_fp"] = run_rate
	session["durable_ready"] = false
	session["durable_dirty"] = true
	return accepted


static func advance(machine: Dictionary, now_msec: int, capture_presentation: bool = true) -> Dictionary:
	var session_value: Variant = machine.get("live_session")
	var simulation_value: Variant = machine.get("simulation")
	var session: Dictionary = session_value if typeof(session_value) == TYPE_DICTIONARY else {}
	var simulation: Dictionary = simulation_value if typeof(simulation_value) == TYPE_DICTIONARY else {}
	if session.is_empty() or simulation.is_empty() or not bool(session.get("open", false)) or bool(session.get("settling_out", false)):
		return {"ticks": 0, "events": []}
	var previous := int(session.get("last_clock_msec", -1))
	if previous < 0:
		session["last_clock_msec"] = now_msec
		return {"ticks": 0, "events": []}
	# Retain the entire hitch in the accumulator. Per-frame work stays capped,
	# but subsequent frames drain the backlog without deleting simulation time.
	var elapsed := maxi(0, now_msec - previous)
	session["last_clock_msec"] = now_msec
	var units := int(session.get("accumulator_units", 0)) + elapsed * FIXED_HZ
	# The throttled single-threaded Web runtime must not turn a missed frame into
	# a self-sustaining multi-tick hitch. A two-tick drain plus the host and canvas
	# work exceeds the active-frame budget on the locked 4x-CPU profile. Keep
	# every elapsed unit in the accumulator, but present at most one authoritative
	# tick per browser frame;
	# native builds retain the wider catch-up window.
	var catch_up_limit := 1 if OS.has_feature("web") else MAX_CATCH_UP_TICKS
	var due := mini(catch_up_limit, units / 1000)
	if due <= 0:
		session["accumulator_units"] = units
		return {"ticks": 0, "events": []}
	var stepped := _step_traced_ticks(machine, due, capture_presentation)
	units -= due * 1000
	session["accumulator_units"] = units
	_compact_consumed_input_trace(session)
	return {"ticks": due, "events": stepped.get("events", []), "backlog_ticks": units / 1000}


static func _compact_consumed_input_trace(session: Dictionary) -> void:
	var cursor := int(session.get("input_cursor", 0))
	if cursor < INPUT_TRACE_COMPACT_MIN_CONSUMED:
		return
	var trace: Array = session.get("input_trace", [])
	if cursor > trace.size():
		return
	session["input_count"] = maxi(int(session.get("input_count", 0)), trace.size())
	# Normal advance owns this boundary after the synchronous solver call has
	# released its input context. Preserve every future event and its order. The
	# exit settlement path keeps its existing drain/trace ownership unchanged.
	session["input_trace"] = trace.slice(cursor) if cursor < trace.size() else []
	session["input_cursor"] = 0


static func begin_chunked_settle(machine: Dictionary) -> Dictionary:
	var session: Dictionary = machine.get("live_session", {}) if typeof(machine.get("live_session", {})) == TYPE_DICTIONARY else {}
	if session.is_empty():
		return {"started": false, "done": true}
	session["input_locked"] = true
	session["settling_out"] = true
	session["settle_ticks"] = 0
	session["backlog_drain_ticks"] = 0
	session["exit_work_ticks"] = 0
	# Inputs are authored at the current solver tick. Drain that complete boundary
	# before imposing the exit-only motor release, otherwise a pending engaged=true
	# skill-stop event can be replayed after the release and freeze settlement.
	var trace: Array = session.get("input_trace", []) if typeof(session.get("input_trace", [])) == TYPE_ARRAY else []
	var pending_before := maxi(0, trace.size() - int(session.get("input_cursor", 0)))
	var drain_result := {"events": []}
	var drain_ticks := 0
	if pending_before > 0:
		drain_result = _step_traced_ticks(machine, 1)
		drain_ticks = 1
		var accumulator_units := int(session.get("accumulator_units", 0))
		session["accumulator_units"] = maxi(0, accumulator_units - mini(1000, accumulator_units))
		session["backlog_drain_ticks"] = 1
		session["exit_work_ticks"] = 1
	CoinPusherSolverScript.set_skill_stop(machine.get("simulation", {}), false)
	sync_native_body_state(machine)
	return {
		"started": true,
		"done": false,
		"input_drain_ticks": drain_ticks,
		"pending_inputs_drained": pending_before,
		"events": drain_result.get("events", []),
	}


static func advance_chunked_settle(machine: Dictionary, tick_budget: int = 8) -> Dictionary:
	var session: Dictionary = machine.get("live_session", {}) if typeof(machine.get("live_session", {})) == TYPE_DICTIONARY else {}
	var simulation: Dictionary = machine.get("simulation", {}) if typeof(machine.get("simulation", {})) == TYPE_DICTIONARY else {}
	if session.is_empty() or simulation.is_empty():
		return {"done": true, "ticks": 0}
	var budget := maxi(1, tick_budget)
	var exit_work_ticks := int(session.get("exit_work_ticks", 0))
	var remaining_work := maxi(0, MAX_SETTLE_TICKS - exit_work_ticks)
	if remaining_work <= 0:
		return {"done": true, "ticks": 0, "total_ticks": exit_work_ticks, "settle_ticks": int(session.get("settle_ticks", 0)), "bounded": true, "events": []}
	budget = mini(budget, remaining_work)
	var accumulator_units := int(session.get("accumulator_units", 0))
	var trace: Array = session.get("input_trace", []) if typeof(session.get("input_trace", [])) == TYPE_ARRAY else []
	var has_pending_input := int(session.get("input_cursor", 0)) < trace.size()
	if accumulator_units >= 1000 or has_pending_input:
		var backlog_ticks := accumulator_units / 1000
		var drain_ticks := mini(mini(MAX_CATCH_UP_TICKS, budget), maxi(1 if has_pending_input else 0, backlog_ticks))
		var stepped := _step_traced_ticks(machine, drain_ticks)
		session["accumulator_units"] = maxi(0, accumulator_units - mini(backlog_ticks, drain_ticks) * 1000)
		session["backlog_drain_ticks"] = int(session.get("backlog_drain_ticks", 0)) + drain_ticks
		exit_work_ticks += drain_ticks
		session["exit_work_ticks"] = exit_work_ticks
		return {"done": exit_work_ticks >= MAX_SETTLE_TICKS, "ticks": drain_ticks, "total_ticks": exit_work_ticks, "settle_ticks": int(session.get("settle_ticks", 0)), "backlog_ticks": int(session.get("accumulator_units", 0)) / 1000, "draining_backlog": true, "bounded": true, "events": stepped.get("events", [])}
	# Backlog ticks may leave the compact native cache authoritative. Publish
	# before direct settlement reads or reloads the script body array.
	sync_native_body_state(machine)
	var used := int(session.get("settle_ticks", 0))
	var ticks := budget
	var events: Array = []
	if ticks > 0 and not CoinPusherSolverScript.all_steady(simulation, not bool(machine.get("locked_down", false))):
		var step_result := CoinPusherSolverScript.step_ticks(simulation, {"motor_enabled": not bool(machine.get("locked_down", false))}, ticks)
		events = step_result.get("events", []) if typeof(step_result.get("events", [])) == TYPE_ARRAY else []
		used += ticks
		session["settle_ticks"] = used
	exit_work_ticks += ticks
	session["exit_work_ticks"] = exit_work_ticks
	var done := CoinPusherSolverScript.all_steady(simulation, not bool(machine.get("locked_down", false))) or exit_work_ticks >= MAX_SETTLE_TICKS
	return {"done": done, "ticks": ticks, "total_ticks": exit_work_ticks, "settle_ticks": used, "bounded": exit_work_ticks <= MAX_SETTLE_TICKS, "events": events}


static func freeze_after_chunked_settle(machine: Dictionary, settle_ticks: int) -> Dictionary:
	sync_native_body_state(machine)
	var simulation: Dictionary = machine.get("simulation", {}) if typeof(machine.get("simulation", {})) == TYPE_DICTIONARY else {}
	if simulation.is_empty():
		return machine.get("settled_state", {})
	var snapshot := make_snapshot(simulation, machine)
	machine["settled_state"] = snapshot
	machine["last_snapshot_bytes"] = JSON.stringify(snapshot).to_utf8_buffer().size()
	machine["last_settle_ticks"] = settle_ticks
	machine.erase("simulation")
	machine.erase("live_session")
	return snapshot


static func make_snapshot(simulation: Dictionary, machine: Dictionary = {}) -> Dictionary:
	var bytes := PackedByteArray()
	var extras: Array = []
	var provenance_sidecar := {}
	var multiplier_nibbles := PackedByteArray()
	var has_multipliers := false
	var compact_count := 0
	var previous_id := 0
	for body_value in simulation.get("bodies", []):
		var body: Dictionary = body_value
		var kind := str(body.get("kind", "coin"))
		var metadata: Dictionary = body.get("meta", {}) if typeof(body.get("meta", {})) == TYPE_DICTIONARY else {}
		var compact_coin := kind == "coin" and str(metadata.get("item_id", "")).is_empty()
		if not compact_coin:
			extras.append(_settled_body(body))
			continue
		var numeric_id := int(str(body.get("id", "body_00000")).get_slice("_", 1))
		_append_varuint(bytes, _zigzag_encode(numeric_id - previous_id))
		previous_id = numeric_id
		var flags := 0
		if str(body.get("support_kind", "")) == "platform":
			flags |= 1
		if bool(body.get("carried_sleep", false)):
			flags |= 2
		if bool(metadata.get("opening", false)):
			flags |= 4
		var x := clampi(_quantize_100(int(body.get("x", 0))), 0, 1023)
		var y := clampi(_quantize_100(int(body.get("y", 0))), 0, 1023)
		var z := clampi(_quantize_100(int(body.get("z", 0))), 0, 511)
		_append_u32(bytes, x | (y << 10) | (z << 20) | (flags << 29))
		var provenance: Dictionary = metadata.get("provenance", {}) if typeof(metadata.get("provenance", {})) == TYPE_DICTIONARY else {}
		var ridge_multiplier := clampi(int(provenance.get("ridge_multiplier", 0)) if str(provenance.get("variation_id", "")) == "jackpot_ridge" else 0, 0, 15)
		var default_nonpaying := not provenance.is_empty() and str(provenance.get("variation_id", "")) != "jackpot_ridge" \
				and int(provenance.get("ridge_multiplier", 1)) == 1 and provenance.keys().all(func(key: Variant) -> bool: return str(key) in ["variation_id", "ridge_multiplier"])
		has_multipliers = has_multipliers or ridge_multiplier > 0
		if compact_count % 2 == 0:
			multiplier_nibbles.append(ridge_multiplier)
		else:
			multiplier_nibbles[multiplier_nibbles.size() - 1] = int(multiplier_nibbles[multiplier_nibbles.size() - 1]) | (ridge_multiplier << 4)
		if not provenance.is_empty() and ridge_multiplier == 0 and not default_nonpaying:
			provenance_sidecar[str(numeric_id)] = provenance.duplicate(true)
		compact_count += 1
	var packed_tray := _pack_tray(simulation.get("tray_ledger", []))
	var snapshot := {
		"schema": SNAPSHOT_SCHEMA,
		"version": SNAPSHOT_VERSION,
		"machine_id": str(simulation.get("machine_id", "")),
		"phase_fp": int(simulation.get("phase_fp", 0)),
		"stroke_cycle_serial": int(simulation.get("stroke_cycle_serial", 0)),
		"carriage_x": int(simulation.get("carriage_x", 50000)),
		"selected_hole": int(simulation.get("selected_hole", 0)),
		"motor_rate_fp": int(simulation.get("motor_rate_fp", 0)),
		"motor_target_rate_fp": int(simulation.get("motor_target_rate_fp", 0)),
		"motor_run_rate_fp": int(simulation.get("motor_run_rate_fp", CoinPusherSolverScript.FP)),
		"skill_stop_engaged": bool(simulation.get("skill_stop_engaged", false)),
		"motor_started": bool(machine.get("motor_started", true)),
		"selected_nozzle_id": str(machine.get("selected_nozzle_id", "")),
		"drop_queue": (machine.get("drop_queue", []) as Array).duplicate(true) if typeof(machine.get("drop_queue", [])) == TYPE_ARRAY else [],
		"next_body_id": int(simulation.get("next_body_id", 1)),
		"coin_count": compact_count,
		"coin_blob": Marshalls.raw_to_base64(bytes) if not bytes.is_empty() else "",
		"coin_multiplier_blob": Marshalls.raw_to_base64(multiplier_nibbles) if has_multipliers else "",
		"coin_provenance": provenance_sidecar,
		"extra_bodies": extras,
		"tray_count": int(packed_tray.get("count", 0)),
		"tray_coin_blob": str(packed_tray.get("coin_blob", "")),
		"tray_extras": packed_tray.get("extras", []),
		"cup_consumed_count": int(simulation.get("cup_consumed_count", 0)),
		"cup_consumed_value": int(simulation.get("cup_consumed_value", 0)),
		"target_last_capture": (simulation.get("target_last_capture", {}) as Dictionary).duplicate(true) if typeof(simulation.get("target_last_capture", {})) == TYPE_DICTIONARY else {},
		"sub_game": (machine.get("variation_state", {}) as Dictionary).duplicate(true) if typeof(machine.get("variation_state", {})) == TYPE_DICTIONARY else {},
		"alarm": {
			"tell_rung": int(machine.get("tell_rung", 0)),
			"tell_decay_remaining_ticks": int(machine.get("tell_decay_remaining_ticks", 0)),
			"tolerance": int(machine.get("alarm_tolerance_remaining", 0)),
			"night_lock": bool(machine.get("locked_down", false)),
		},
	}
	return snapshot


static func restore_snapshot(snapshot: Dictionary, machine_definition: Dictionary) -> Dictionary:
	var rng := RngStream.new()
	rng.configure(1)
	var simulation := CoinPusherSolverScript.create_machine(rng, machine_definition, 0)
	simulation["phase_fp"] = int(snapshot.get("phase_fp", 0))
	simulation["stroke_cycle_serial"] = int(snapshot.get("stroke_cycle_serial", 0))
	var period := maxi(1, int((machine_definition.get("stroke", {}) as Dictionary).get("period_ticks", 240)))
	var phase := posmod(int(simulation["phase_fp"]) / CoinPusherSolverScript.FP, period)
	simulation["face_y"] = CoinPusherSolverScript.face_y_for_phase(machine_definition, phase)
	simulation["previous_face_y"] = int(simulation["face_y"])
	simulation["carriage_x"] = int(snapshot.get("carriage_x", 50000))
	simulation["selected_hole"] = int(snapshot.get("selected_hole", 0))
	simulation["motor_rate_fp"] = int(snapshot.get("motor_rate_fp", CoinPusherSolverScript.FP))
	simulation["motor_target_rate_fp"] = int(snapshot.get("motor_target_rate_fp", CoinPusherSolverScript.FP))
	simulation["motor_run_rate_fp"] = int(snapshot.get("motor_run_rate_fp", CoinPusherSolverScript.FP))
	simulation["skill_stop_engaged"] = bool(snapshot.get("skill_stop_engaged", false))
	simulation["next_body_id"] = int(snapshot.get("next_body_id", 1))
	var bodies: Array = []
	var raw := Marshalls.base64_to_raw(str(snapshot.get("coin_blob", "")))
	var cursor := 0
	if int(snapshot.get("version", 1)) >= 2:
		var previous_id := 0
		var sidecar: Dictionary = snapshot.get("coin_provenance", {}) if typeof(snapshot.get("coin_provenance", {})) == TYPE_DICTIONARY else {}
		var multipliers := Marshalls.base64_to_raw(str(snapshot.get("coin_multiplier_blob", "")))
		for coin_index in range(maxi(0, int(snapshot.get("coin_count", 0)))):
			var decoded := _read_varuint(raw, cursor)
			cursor = int(decoded.get("cursor", cursor))
			var body_id := previous_id + _zigzag_decode(int(decoded.get("value", 0)))
			previous_id = body_id
			if cursor + 3 >= raw.size():
				break
			var packed := _read_u32(raw, cursor)
			cursor += 4
			var flags := (packed >> 29) & 7
			var metadata := {"value": 1}
			if (flags & 4) != 0:
				metadata["opening"] = true
			if typeof(sidecar.get(str(body_id), {})) == TYPE_DICTIONARY and not (sidecar.get(str(body_id), {}) as Dictionary).is_empty():
				metadata["provenance"] = (sidecar.get(str(body_id), {}) as Dictionary).duplicate(true)
			elif coin_index / 2 < multipliers.size():
				var multiplier := (int(multipliers[coin_index / 2]) >> (4 if coin_index % 2 == 1 else 0)) & 15
				if multiplier > 0:
					metadata["provenance"] = {"variation_id": "jackpot_ridge", "ridge_multiplier": multiplier}
			bodies.append(_restored_body("body_%05d" % body_id, "coin", (packed & 1023) * 100, ((packed >> 10) & 1023) * 100, ((packed >> 20) & 511) * 100, metadata, machine_definition, "platform" if (flags & 1) != 0 else "deck", (flags & 2) != 0))
	else:
		while cursor + 8 < raw.size():
			var body_id := _read_u16(raw, cursor)
			cursor += 2
			var x := _read_u16(raw, cursor) * 100
			cursor += 2
			var y := _read_u16(raw, cursor) * 100
			cursor += 2
			var z := _read_u16(raw, cursor) * 100
			cursor += 2
			var flags := int(raw[cursor])
			cursor += 1
			bodies.append(_restored_body("body_%05d" % body_id, "coin", x, y, z, {}, machine_definition, "platform" if (flags & 1) != 0 else "deck", (flags & 2) != 0))
	for body_value in snapshot.get("extra_bodies", []):
		if typeof(body_value) == TYPE_DICTIONARY:
			bodies.append(_restore_extra(body_value as Dictionary, machine_definition))
	simulation["bodies"] = bodies
	var restored_tray: Array = _restore_tray(snapshot)
	simulation["opening_body_count"] = bodies.size() + restored_tray.size() + int(snapshot.get("cup_consumed_count", 0))
	simulation["accepted_inserts"] = 0
	simulation["collected_count"] = 0
	simulation["collected_value"] = 0
	simulation["cup_consumed_count"] = int(snapshot.get("cup_consumed_count", 0))
	simulation["cup_consumed_value"] = int(snapshot.get("cup_consumed_value", 0))
	simulation["target_last_capture"] = (snapshot.get("target_last_capture", {}) as Dictionary).duplicate(true) if typeof(snapshot.get("target_last_capture", {})) == TYPE_DICTIONARY else {}
	simulation["tray_ledger"] = restored_tray
	return simulation


static func _session_rng(session: Dictionary) -> RngStream:
	var rng := RngStream.new()
	rng.restore(session.get("rng", {}))
	return rng


static func all_steady(machine: Dictionary, motor_running: bool = true) -> bool:
	var session_value: Variant = machine.get("live_session")
	var session: Dictionary = session_value if typeof(session_value) == TYPE_DICTIONARY else {}
	if bool(session.get("native_body_state_dirty", false)):
		return bool(session.get("native_steady_with_motor" if motor_running else "native_steady_without_motor", false))
	var simulation_value: Variant = machine.get("simulation")
	var simulation: Dictionary = simulation_value if typeof(simulation_value) == TYPE_DICTIONARY else {}
	return CoinPusherSolverScript.all_steady(simulation, motor_running)


static func sync_native_body_state(machine: Dictionary) -> void:
	var session: Dictionary = machine.get("live_session", {}) if typeof(machine.get("live_session", {})) == TYPE_DICTIONARY else {}
	if session.is_empty() or not bool(session.get("native_body_state_dirty", false)):
		return
	var simulation: Dictionary = machine.get("simulation", {}) if typeof(machine.get("simulation", {})) == TYPE_DICTIONARY else {}
	if simulation.is_empty():
		return
	CoinPusherSolverScript.step_ticks(simulation, {
		"live_cache_key": str(session.get("native_cache_key", "")),
		"write_body_state": true,
	}, 0)
	session["native_body_state_dirty"] = false


static func _step_traced_ticks(machine: Dictionary, tick_count: int, capture_presentation: bool = true) -> Dictionary:
	var session: Dictionary = machine.get("live_session")
	var simulation: Dictionary = machine.get("simulation")
	var all_events: Array = []
	var safe_tick_count := maxi(0, tick_count)
	var previous_views: Array = []
	var previous_packed := PackedInt64Array()
	var previous_face_y := int(session.get("presentation_current_face_y", simulation.get("face_y", 0)))
	var native_batch := CoinPusherSolverScript.native_live_batch_supported()
	var compact_native_authority := native_batch and OS.has_feature("web")
	var compact_native_presentation := compact_native_authority and capture_presentation
	if safe_tick_count == 1:
		if not compact_native_authority:
			var current_views: Variant = session.get("presentation_current_bodies", [])
			previous_views = current_views if typeof(current_views) == TYPE_ARRAY and not (current_views as Array).is_empty() else _presentation_body_views(simulation)
		if compact_native_presentation:
			var current_packed: Variant = session.get("presentation_current_packed", PackedInt64Array())
			previous_packed = current_packed if typeof(current_packed) == TYPE_PACKED_INT64_ARRAY else PackedInt64Array()
	var rng: RngStream = null
	var remaining := safe_tick_count
	var final_result: Dictionary = {}
	while remaining > 0:
		var tick_value := int(simulation.get("tick", 0))
		if safe_tick_count > 1 and not native_batch and remaining == 1:
			previous_views = _presentation_body_views(simulation)
			previous_face_y = int(simulation.get("face_y", 0))
		_release_due_drop(machine, simulation, tick_value)
		# A queued release is an authored tick boundary. Batch only up to that
		# boundary so the queue produces the same one-release-per-tick trace.
		var chunk_ticks := remaining
		if remaining > 1 and not native_batch:
			chunk_ticks = remaining - 1
		var queue_value: Variant = machine.get("drop_queue")
		var queue: Array = queue_value if typeof(queue_value) == TYPE_ARRAY else []
		if not queue.is_empty() and typeof(queue[0]) == TYPE_DICTIONARY:
			var next_emit_tick := int((queue[0] as Dictionary).get("next_emit_tick", tick_value))
			chunk_ticks = mini(chunk_ticks, 1 if next_emit_tick <= tick_value else next_emit_tick - tick_value)
		var trace_slice_value: Variant = session.get("native_trace_slice_scratch")
		var trace_slice: Array = trace_slice_value if typeof(trace_slice_value) == TYPE_ARRAY else []
		trace_slice.clear()
		session["native_trace_slice_scratch"] = trace_slice
		var trace_contains_drop := false
		var cursor := int(session.get("input_cursor", 0))
		var trace: Array = session.get("input_trace", [])
		while cursor < trace.size() and int((trace[cursor] as Dictionary).get("tick", -1)) < tick_value + chunk_ticks:
			var traced_input: Variant = trace[cursor]
			trace_slice.append(traced_input)
			trace_contains_drop = trace_contains_drop or (typeof(traced_input) == TYPE_DICTIONARY and str((traced_input as Dictionary).get("kind", "")) == "drop")
			cursor += 1
		session["input_cursor"] = cursor
		var is_final_chunk := chunk_ticks == remaining
		var step_config_value: Variant = session.get("native_step_config_scratch")
		var step_config: Dictionary = step_config_value if typeof(step_config_value) == TYPE_DICTIONARY else {}
		session["native_step_config_scratch"] = step_config
		step_config["input_trace"] = trace_slice
		step_config["motor_enabled"] = bool(machine.get("motor_started", false)) and not bool(machine.get("locked_down", false))
		step_config["live_cache_key"] = str(session.get("native_cache_key", "")) if native_batch else ""
		step_config["live_cache_reset"] = bool(session.get("native_cache_reset", false))
		step_config["write_body_state"] = not compact_native_authority
		step_config["capture_previous_views"] = capture_presentation and native_batch and not compact_native_authority and safe_tick_count > 1 and is_final_chunk
		step_config["capture_previous_packed"] = compact_native_presentation and is_final_chunk
		step_config["capture_current_views"] = capture_presentation and native_batch and not compact_native_authority and is_final_chunk
		step_config["capture_current_packed"] = compact_native_presentation and is_final_chunk
		if trace_contains_drop:
			if rng == null:
				rng = _session_rng(session)
			step_config["rng"] = rng
		else:
			step_config.erase("rng")
		var result := CoinPusherSolverScript.step_ticks(simulation, step_config, chunk_ticks)
		step_config.erase("rng")
		final_result = result
		session["native_cache_reset"] = false
		var result_events_value: Variant = result.get("events")
		var result_events: Array = result_events_value if typeof(result_events_value) == TYPE_ARRAY else []
		if all_events.is_empty() and chunk_ticks == safe_tick_count:
			all_events = result_events
		else:
			all_events.append_array(result_events)
		if capture_presentation and native_batch and not compact_native_authority and safe_tick_count > 1 and is_final_chunk:
			previous_views = result.get("presentation_previous_bodies", []) if typeof(result.get("presentation_previous_bodies", [])) == TYPE_ARRAY else []
		if compact_native_presentation and is_final_chunk:
			previous_packed = result.get("presentation_previous_packed", PackedInt64Array()) if typeof(result.get("presentation_previous_packed", PackedInt64Array())) == TYPE_PACKED_INT64_ARRAY else PackedInt64Array()
		if capture_presentation and native_batch and safe_tick_count > 1 and is_final_chunk:
			previous_face_y = int(result.get("presentation_previous_face_y", simulation.get("previous_face_y", 0)))
		remaining -= chunk_ticks
	if safe_tick_count > 0:
		if compact_native_presentation:
			session["presentation_previous_packed"] = previous_packed
			session["presentation_current_packed"] = final_result.get("presentation_current_packed", PackedInt64Array()) if typeof(final_result.get("presentation_current_packed", PackedInt64Array())) == TYPE_PACKED_INT64_ARRAY else PackedInt64Array()
			session["presentation_feature_count"] = int(final_result.get("presentation_feature_count", session.get("presentation_feature_count", 0)))
			session["presentation_motion"] = final_result.get("presentation_motion", {}) if typeof(final_result.get("presentation_motion", {})) == TYPE_DICTIONARY else {}
		elif capture_presentation:
			var current_views: Array = final_result.get("presentation_current_bodies", []) if native_batch and typeof(final_result.get("presentation_current_bodies", [])) == TYPE_ARRAY else _presentation_body_views(simulation)
			session["presentation_previous_bodies"] = previous_views
			session["presentation_current_bodies"] = current_views
			session["presentation_feature_count"] = _presentation_feature_count(current_views)
		if compact_native_authority:
			session["native_body_state_dirty"] = true
		var metrics_value: Variant = final_result.get("metrics")
		var metrics: Dictionary = metrics_value if typeof(metrics_value) == TYPE_DICTIONARY else {}
		session["last_step_metrics"] = metrics
		session["native_steady_without_motor"] = bool(metrics.get("steady_without_motor", false))
		session["native_steady_with_motor"] = bool(metrics.get("steady_with_motor", false))
		if capture_presentation:
			session["presentation_previous_face_y"] = previous_face_y
			session["presentation_current_face_y"] = int(final_result.get("presentation_current_face_y", simulation.get("face_y", 0))) if native_batch else int(simulation.get("face_y", 0))
			session["presentation_view_serial"] = int(session.get("presentation_view_serial", 0)) + safe_tick_count
	if rng != null:
		session["rng"] = rng.snapshot()
	session["liveness_ticks"] = int(session.get("liveness_ticks", 0)) + safe_tick_count
	return {"events": all_events}


static func _release_due_drop(machine: Dictionary, simulation: Dictionary, tick_value: int) -> void:
	var queue_value: Variant = machine.get("drop_queue")
	var queue: Array = queue_value if typeof(queue_value) == TYPE_ARRAY else []
	if queue.is_empty():
		return
	var item: Dictionary = queue[0] if typeof(queue[0]) == TYPE_DICTIONARY else {}
	if item.is_empty() or int(item.get("remaining", 0)) <= 0:
		queue.pop_front()
		machine["drop_queue"] = queue
		return
	if tick_value < int(item.get("next_emit_tick", tick_value)):
		return
	var definition := _machine_definition(simulation)
	var nozzle_id := str(item.get("nozzle_id", _default_nozzle_id(definition, simulation)))
	var x := _nozzle_x(definition, simulation, nozzle_id)
	var provenance: Dictionary = item.get("provenance", {}) if typeof(item.get("provenance", {})) == TYPE_DICTIONARY else {}
	provenance = provenance.duplicate(true)
	provenance["source_nozzle_id"] = nozzle_id
	provenance["chain_depth"] = maxi(0, int(item.get("chain_depth", 0)))
	if not str(item.get("parent_body_id", "")).is_empty():
		provenance["chain_parent_body_id"] = str(item.get("parent_body_id", ""))
	# Reserved feeder work remains owed while external player input is locked.
	var session: Dictionary = machine.get("live_session", {}) if typeof(machine.get("live_session", {})) == TYPE_DICTIONARY else {}
	if session.is_empty():
		return
	_append_input(simulation, session, {
		"kind": "drop",
		"x": x,
		"density": maxi(1, int(item.get("density", 1))),
		"provenance": provenance,
		"bonus_origin": bool(item.get("bonus_origin", false)),
	})
	item["remaining"] = int(item.get("remaining", 1)) - 1
	# All cabinet types share a human-readable three-drops-per-second feeder.
	# Keeping this at the scheduler boundary also repairs old snapshots whose
	# authored machine definition predates the cadence change.
	item["next_emit_tick"] = tick_value + DROP_RELEASE_INTERVAL_TICKS
	if int(item["remaining"]) <= 0:
		queue.pop_front()
		# Adjacent reservations are still one physical feeder queue. A later
		# batch may have been reserved while this one was active, so move its
		# original due tick forward instead of allowing a one-tick batch seam.
		if not queue.is_empty() and typeof(queue[0]) == TYPE_DICTIONARY:
			var next_item: Dictionary = queue[0]
			next_item["next_emit_tick"] = maxi(int(next_item.get("next_emit_tick", 0)), tick_value + DROP_RELEASE_INTERVAL_TICKS)
			queue[0] = next_item
	else:
		queue[0] = item
	machine["drop_queue"] = queue


static func _machine_definition(simulation: Dictionary) -> Dictionary:
	return simulation.get("machine_definition", {}) if typeof(simulation.get("machine_definition", {})) == TYPE_DICTIONARY else {}


static func _default_nozzle_id(definition: Dictionary, simulation: Dictionary) -> String:
	var apparatus: Dictionary = definition.get("apparatus", {}) if typeof(definition.get("apparatus", {})) == TYPE_DICTIONARY else {}
	var nozzles: Array = apparatus.get("nozzles", []) if typeof(apparatus.get("nozzles", [])) == TYPE_ARRAY else []
	if str(apparatus.get("type", "rail_slot")) == "hole_set" and not nozzles.is_empty():
		var index := clampi(int(simulation.get("selected_hole", 0)), 0, nozzles.size() - 1)
		return str((nozzles[index] as Dictionary).get("id", "nozzle_%d" % index)) if typeof(nozzles[index]) == TYPE_DICTIONARY else "nozzle_%d" % index
	return str((nozzles[0] as Dictionary).get("id", "rail")) if not nozzles.is_empty() and typeof(nozzles[0]) == TYPE_DICTIONARY else "rail"


static func _nozzle_x(definition: Dictionary, simulation: Dictionary, nozzle_id: String) -> int:
	var apparatus: Dictionary = definition.get("apparatus", {}) if typeof(definition.get("apparatus", {})) == TYPE_DICTIONARY else {}
	var nozzles: Array = apparatus.get("nozzles", []) if typeof(apparatus.get("nozzles", [])) == TYPE_ARRAY else []
	for nozzle_value in nozzles:
		if typeof(nozzle_value) != TYPE_DICTIONARY:
			continue
		var nozzle: Dictionary = nozzle_value
		if str(nozzle.get("id", "")) != nozzle_id:
			continue
		if str(nozzle.get("mount", "static")) == "rail":
			return int(simulation.get("carriage_x", nozzle.get("x", 50000)))
		return int(nozzle.get("x", simulation.get("carriage_x", 50000)))
	return int(simulation.get("carriage_x", 50000))


# Renderer-facing public state intentionally excludes canonical solver fields
# that the cabinet never consumes (velocities, remainders, mass, and deep
# metadata). Canonical body_views remains unchanged for determinism, saves, and
# mechanics contracts; this lean view avoids rebuilding those values 300 times
# per visible fixed tick.
static func _presentation_body_views(simulation: Dictionary) -> Array:
	var views: Array = []
	var bodies: Array = simulation.get("bodies", []) if typeof(simulation.get("bodies", [])) == TYPE_ARRAY else []
	views.resize(bodies.size())
	for body_index in range(bodies.size()):
		var body: Dictionary = bodies[body_index]
		views[body_index] = {
			"id": str(body.get("id", "")),
			"kind": str(body.get("kind", "coin")),
			"x": int(body.get("x", 0)),
			"y": int(body.get("y", 0)),
			"z": int(body.get("z", 0)),
			"rest_state": str(body.get("rest_state", "falling")),
			"support_kind": str(body.get("support_kind", "")),
			"support_root": "platform" if str(body.get("support_kind", "")) == "platform" or (str(body.get("support_kind", "")) == "body" and bool(body.get("carried_sleep", false))) else "deck" if not str(body.get("support_kind", "")).is_empty() else "",
		}
	return views


static func presentation_body_views_for_test(simulation: Dictionary) -> Array:
	return _presentation_body_views(simulation)


static func _presentation_feature_count(views: Array) -> int:
	var count := 0
	for body_value in views:
		if typeof(body_value) == TYPE_DICTIONARY and str((body_value as Dictionary).get("kind", "coin")) != "coin":
			count += 1
	return count


static func _settled_body(body: Dictionary) -> Dictionary:
	var settled := {"id": str(body.get("id", "")), "kind": str(body.get("kind", "coin")), "x": _quantize_100(int(body.get("x", 0))), "y": _quantize_100(int(body.get("y", 0))), "z": _quantize_100(int(body.get("z", 0))), "support": str(body.get("support_kind", "deck")), "carried": bool(body.get("carried_sleep", false)), "meta": (body.get("meta", {}) as Dictionary).duplicate(true)}
	if str(body.get("support_kind", "")) == "body":
		settled["support_ids"] = (body.get("support_ids", []) as Array).duplicate() if typeof(body.get("support_ids", [])) == TYPE_ARRAY else []
		if body.has("support_anchor_x") and body.has("support_anchor_y"):
			settled["anchor_x"] = _quantize_100(int(body.get("support_anchor_x", 0)))
			settled["anchor_y"] = _quantize_100(int(body.get("support_anchor_y", 0)))
	return settled


static func _restore_extra(body: Dictionary, definition: Dictionary) -> Dictionary:
	var restored := _restored_body(str(body.get("id", "")), str(body.get("kind", "coin")), int(body.get("x", 0)) * 100, int(body.get("y", 0)) * 100, int(body.get("z", 0)) * 100, body.get("meta", {}), definition, str(body.get("support", "deck")), bool(body.get("carried", false)))
	if str(restored.get("support_kind", "")) == "body":
		restored["support_ids"] = (body.get("support_ids", []) as Array).duplicate() if typeof(body.get("support_ids", [])) == TYPE_ARRAY else []
		if body.has("anchor_x") and body.has("anchor_y"):
			restored["support_anchor_x"] = int(body.get("anchor_x", 0)) * 100
			restored["support_anchor_y"] = int(body.get("anchor_y", 0)) * 100
	return restored


static func _restored_body(id: String, kind: String, x: int, y: int, z: int, meta: Dictionary, definition: Dictionary, support: String, carried: bool) -> Dictionary:
	var coins: Dictionary = definition.get("coins", {})
	return {"id": id, "kind": kind, "x": x, "y": y, "z": z, "vx": 0, "vy": 0, "vz": 0, "radius": int(meta.get("radius", coins.get("radius", 2350))), "height": int(meta.get("height", coins.get("height", 950))), "mass": int(meta.get("mass", coins.get("mass", 1000))), "sleeping": true, "sleep_ticks": 8, "rest_state": "resting", "support_kind": support, "carried_sleep": carried, "meta": meta.duplicate(true)}
static func _read_u16(bytes: PackedByteArray, offset: int) -> int:
	return int(bytes[offset]) | (int(bytes[offset + 1]) << 8)


static func _append_u32(bytes: PackedByteArray, value: int) -> void:
	for shift in [0, 8, 16, 24]:
		bytes.append((value >> shift) & 255)


static func _read_u32(bytes: PackedByteArray, offset: int) -> int:
	return int(bytes[offset]) | (int(bytes[offset + 1]) << 8) | (int(bytes[offset + 2]) << 16) | (int(bytes[offset + 3]) << 24)


static func _append_varuint(bytes: PackedByteArray, value: int) -> void:
	var remaining := maxi(0, value)
	while remaining >= 128:
		bytes.append((remaining & 127) | 128)
		remaining >>= 7
	bytes.append(remaining)


static func _read_varuint(bytes: PackedByteArray, offset: int) -> Dictionary:
	var value := 0
	var shift := 0
	var cursor := offset
	while cursor < bytes.size() and shift <= 28:
		var byte := int(bytes[cursor])
		cursor += 1
		value |= (byte & 127) << shift
		if (byte & 128) == 0:
			break
		shift += 7
	return {"value": value, "cursor": cursor}


static func _zigzag_encode(value: int) -> int:
	return (value << 1) ^ (value >> 31)


static func _zigzag_decode(value: int) -> int:
	return (value >> 1) ^ -(value & 1)


static func _pack_tray(value: Variant) -> Dictionary:
	var ledger: Array = value if typeof(value) == TYPE_ARRAY else []
	var coin_bytes := PackedByteArray()
	var extras: Array = []
	for index in range(ledger.size()):
		var entry: Dictionary = ledger[index] if typeof(ledger[index]) == TYPE_DICTIONARY else {}
		var provenance: Dictionary = entry.get("provenance", {}) if typeof(entry.get("provenance", {})) == TYPE_DICTIONARY else {}
		var variation := str(provenance.get("variation_id", ""))
		var multiplier := clampi(int(provenance.get("ridge_multiplier", 0)) if variation == "jackpot_ridge" else 0, 0, 15)
		var default_nonpaying := not provenance.is_empty() and variation != "jackpot_ridge" \
				and int(provenance.get("ridge_multiplier", 1)) == 1 and provenance.keys().all(func(key: Variant) -> bool: return str(key) in ["variation_id", "ridge_multiplier"])
		var compact := str(entry.get("kind", "coin")) == "coin" and str(entry.get("item_id", "")).is_empty() \
				and int(entry.get("value", 0)) >= 0 and int(entry.get("value", 0)) <= 15 \
				and (provenance.is_empty() or multiplier > 0 or default_nonpaying)
		if compact:
			coin_bytes.append((int(entry.get("value", 0)) & 15) | (multiplier << 4))
		else:
			extras.append({"index": index, "entry": entry.duplicate(true)})
	return {"count": ledger.size(), "coin_blob": Marshalls.raw_to_base64(coin_bytes) if not coin_bytes.is_empty() else "", "extras": extras}


static func _restore_tray(snapshot: Dictionary) -> Array:
	if int(snapshot.get("version", 1)) < 2 or not snapshot.has("tray_count"):
		return (snapshot.get("tray_ledger", []) as Array).duplicate(true)
	var total := maxi(0, int(snapshot.get("tray_count", 0)))
	var result: Array = []
	result.resize(total)
	var occupied := {}
	for extra_value in snapshot.get("tray_extras", []):
		if typeof(extra_value) != TYPE_DICTIONARY:
			continue
		var index := clampi(int((extra_value as Dictionary).get("index", -1)), 0, maxi(0, total - 1))
		result[index] = ((extra_value as Dictionary).get("entry", {}) as Dictionary).duplicate(true)
		occupied[index] = true
	var coin_bytes := Marshalls.base64_to_raw(str(snapshot.get("tray_coin_blob", "")))
	var coin_cursor := 0
	for index in range(total):
		if occupied.has(index):
			continue
		if coin_cursor >= coin_bytes.size():
			result[index] = {"kind": "coin", "value": 0, "item_id": "", "provenance": {}}
			continue
		var packed := int(coin_bytes[coin_cursor])
		coin_cursor += 1
		var multiplier := (packed >> 4) & 15
		result[index] = {"kind": "coin", "value": packed & 15, "item_id": "", "provenance": {"variation_id": "jackpot_ridge", "ridge_multiplier": multiplier} if multiplier > 0 else {}}
	return result


static func _quantize_100(value: int) -> int:
	return clampi((value + 50) / 100 if value >= 0 else -((-value + 50) / 100), 0, 65535)
