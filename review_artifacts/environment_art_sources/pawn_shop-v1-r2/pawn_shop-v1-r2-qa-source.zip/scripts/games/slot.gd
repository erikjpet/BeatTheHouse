class_name SlotGame
extends GameModule

# Deterministic full-simulation slot machine module.

const StateScript := preload("res://scripts/games/slots/slot_machine_state.gd")
const BonusRecoveryScript := preload("res://scripts/games/slots/slot_bonus_recovery.gd")
const DefinitionCacheScript := preload("res://scripts/games/slots/slot_definition_cache.gd")
const CatalogScript := preload("res://scripts/games/slots/slot_catalog.gd")
const GeneratorScript := preload("res://scripts/games/slots/slot_machine_generator.gd")
const ResolverScript := preload("res://scripts/games/slots/slot_resolver.gd")
const PresentationScript := preload("res://scripts/games/slots/slot_presentation.gd")
const RendererScript := preload("res://scripts/games/slots/slot_renderer.gd")
const PinballFeatureScript := preload("res://scripts/games/slots/pinball/pinball_feature.gd")
const RuntimeScript := preload("res://scripts/core/game_ritual_runtime.gd")
const ActionAuthorityScript := preload("res://scripts/core/blackjack_action_authority.gd")
const SELECT_BET_PREFIX := "select_bet_option:"
const SLOT_BONUS_WATCHDOG_ACTION := "slot_bonus_watchdog"
const SLOT_BONUS_WATCHDOG_GRACE_MSEC := 2200
const SLOT_AUTOPLAY_LOSS_HOLD_MSEC := 100
const SLOT_AUTOPLAY_WIN_HOLD_MSEC := 500
const SLOT_RESULT_REVEAL_BEAT_MSEC := 180
const BUFFALO_AUTOPLAY_MAX_DELAY_MSEC := 10000
const SLOT_ENV_PREVIEW_MAX_REELS := 6
const SLOT_ENV_PREVIEW_MAX_ROWS := 4
const LUCKY_REEL_GREASE_ITEM_ID := "lucky_reel_grease"
const COLD_QUARTERS_ITEM_ID := "cold_quarters"
const SPLIT_REEL_NOTE_ITEM_ID := "split_reel_note"
const CUMQUAT_SANDWICH_ITEM_ID := "cumquat_sandwich"
const SLOT_RITUAL_CONTRACT := "game_ritual/1"
const SLOT_RITUAL_ID := "slot.machine_session"
const SLOT_HANDLE_PULL_GESTURE := "slot_handle_pull_gesture"
const SLOT_HANDLE_MIN_PULL := 36.0
const SLOT_CONTEXTUAL_ITEM_EFFECT_KEYS := [
	"win_bonus", "payout_delta", "loss_reduction",
	"slot_nudge_perfect_msec_bonus", "slot_nudge_close_msec_bonus",
	"slot_cold_quarter_heat_reduction", "slot_split_reel_note_perfect_msec_bonus",
	"slot_split_reel_note_close_msec_bonus",
]
const SLOT_LEGAL_ITEM_EFFECT_KEYS := [
	"slot_three_reel_loss_refund_percent", "slot_gold_tooth_coin_upgrade_chance",
	"slot_gold_tooth_coin_multiplier", "slot_first_bonus_bonus_percent",
	"slot_first_bonus_bonus_cap", "slot_feature_weight_bonus_percent",
	"slot_reel_win_weight_percent", "slot_pinball_drain_cleaner_uses",
	"slot_pinball_drain_cleaner_floor_percent", "slot_pinball_drain_cleaner_award_percent",
	"slot_pinball_jackpot_magnet_uses", "slot_pinball_jackpot_magnet_award_percent",
	"slot_pinball_jackpot_magnet_progress_bonus", "slot_pinball_splitter_token_uses",
	"slot_pinball_splitter_token_extra_balls", "slot_pinball_return_spring_uses",
	"slot_pinball_return_spring_impulse", "slot_pinball_tilt_dampener_percent",
	"slot_pinball_bumper_battery_hits", "slot_pinball_bumper_battery_award_percent",
	"slot_pinball_bumper_battery_kick_percent", "slot_pinball_bumper_battery_up_impulse",
	"slot_pinball_rubber_pegs", "slot_pinball_magnet_cup_radius_percent",
	"slot_pinball_extra_ball_token", "slot_pinball_plunger_tuner_width_percent",
	"slot_pinball_lock_jammer_uses",
]

var generator
var resolver
var presentation
var renderer
var catalog
var definition_cache
func sealed_action_authority_script() -> Script:
	return ActionAuthorityScript


func sealed_action_authority_contract() -> Dictionary:
	return {
		"resolve_proposal_method": &"_machine_game_resolve_proposal",
		"wager_cost_proposal_method": &"_machine_game_wager_cost_proposal",
		"trusted_candidate_resolve_method": &"_machine_game_resolve_candidate",
		"trusted_candidate_wager_method": &"_machine_game_wager_cost_candidate",
		"proposal_runtime_checkpoint_method": &"_machine_game_runtime_checkpoint",
		"proposal_runtime_restore_method": &"_machine_game_runtime_restore",
		# Slot actions read the run but mutate only their bound machine until the
		# host applies the accepted result. This lets Foundation replay the proposal
		# against a narrow detached candidate and fingerprint the exact Slot inputs
		# instead of serializing unrelated late-run story/world history six times.
		"compact_authority_evidence_method": &"_machine_game_authority_evidence",
		# Both isolated executions already compare their complete result, RNG, and
		# compact authority graphs. The replay does not need to serialize that same
		# large Slot/pinball payload into a second output digest.
		"trusted_candidate_structural_replay_match": true,
		"lightweight_resolution_candidate": true,
		# Slot resolution replaces machine fields and takes an owned copy before
		# changing any nested runtime model. The two replay candidates therefore
		# need independent top-level tables, not recursive copies of retained
		# animation/feature history that neither execution mutates in place.
		"trusted_candidate_shallow_machine_detach": true,
		"in_place_nonrejecting_commit": true,
		# One current response plus its immediate predecessor covers synchronous
		# retry/save recovery. Larger Blackjack hand history only made each later
		# autoplay spin validate and copy stale presentation payloads.
		"active_replay_limit": 2,
		"host_auto_tick_method": &"_machine_game_host_needs_auto_tick",
		# Slot deadlines live on the slowed presentation clock. Foundation keeps
		# every other sealed game on its existing raw-clock contract and converts
		# only this provider's cheap due predicate into the same timing domain.
		"host_auto_tick_uses_drunk_scaled_time": true,
		"surface_intent_key": "",
		"surface_intent_index_key": "",
		"retry_surface_actions": ["slot_retry_pending", "slot_spin", "spin"],
		"cancel_surface_actions": ["slot_cancel_pending"],
		"proposal_requires_apply_key": "machine_game_proposal_requires_apply",
		"authoritative_result_marker": "sealed_action_authoritative",
		"place_bet_action": "",
		"host_pointer_intent": true,
	}


func slot_machine_ritual_contract() -> Dictionary:
	# Slot-owned declaration only: resolver authority and RNG remain in the
	# shipped machine state/resolver. Shared runtime use is limited to canonical
	# sealed-proposal fingerprints; it does not execute Slot phases or math.
	var action_ids := ["slot_handpay_acknowledge", "slot_bet", "spin", "nudge", "slot_auto_toggle", "launch", "left", "right", "soft", "hard", "power_down", "power_up", "tilt"]
	var declarations: Array = []
	for action_id in action_ids:
		declarations.append({"action_id": action_id, "handler_id": "slot_machine_authority", "parameters": {}})
	return {
		"contract": SLOT_RITUAL_CONTRACT,
		"ritual_id": SLOT_RITUAL_ID,
		"initial_phase": "bankroll",
		"ritual_phases": [
			_slot_ritual_phase("bankroll", ["slot_bet", "spin", "slot_auto_toggle"], "commitment"),
			_slot_ritual_phase("commitment", ["spin"], "activation"),
			_slot_ritual_phase("activation", [], "outcome_staging"),
			{"id": "outcome_staging", "entry_conditions": [], "permitted_actions": ["nudge"], "entry_operations": [], "transitions": [
				{"id": "outcome_to_feature", "condition": {"kind": "public_state_equals", "key": "feature_active", "value": true}, "next_phase": "feature", "operations": []},
				{"id": "outcome_to_payout", "condition": {"kind": "public_state_equals", "key": "feature_active", "value": false}, "next_phase": "payout_or_handpay", "operations": []},
			], "terminal": false},
			_slot_ritual_phase("feature", ["launch", "left", "right", "soft", "hard", "power_down", "power_up", "tilt"], "payout_or_handpay"),
			_slot_ritual_phase("payout_or_handpay", ["slot_handpay_acknowledge"], "bankroll"),
		],
		"action_declarations": declarations,
		"staged_commitment": {
			"pending_collection": "pending_items", "working_collection": "working_items", "resolution_collection": "item_resolutions", "funds_authority": "slot_game_rules",
			"actions": [{"id": "slot_bet", "effect": "correct_one_pending_amount"}, {"id": "spin", "effect": "authorize_pending_set"}],
			"readable_totals": ["available_funds", "pending_total", "at_risk_total", "returned_stake", "payout", "net_change"],
		},
		"pointer_verbs": [
			_slot_ritual_pointer("slot_button_press", "hold", "spin", "button_deck"),
			_slot_ritual_pointer("slot_handle_pull", "drag", "spin", "handle_lane"),
		],
		"actors": [
			{"id": "attendant_primary", "role": "attendant", "anchor": "attendant_station", "poses": ["absent", "approaching", "servicing"], "behavior_states": ["idle", "handpay", "security"], "initial_pose": "absent", "initial_behavior": "idle", "fact_reactions": []},
			{"id": "neighbour_seats", "role": "neighbours", "anchor": "seat_rail", "poses": ["seated", "turning"], "behavior_states": ["idle", "playing", "reacting"], "initial_pose": "seated", "initial_behavior": "idle", "fact_reactions": []},
		],
		"scene_objects": [
			_slot_ritual_object("cabinet_body", "cabinet", ["attract", "idle", "play", "feature", "lockup"], ["passive"]),
			_slot_ritual_object("cabinet_reels", "reel_window", ["idle", "spinning", "stopped", "feature"], ["read_only"]),
			_slot_ritual_object("cabinet_button_deck", "button_deck", ["ready", "pressed", "locked"], ["enabled", "locked"]),
			_slot_ritual_object("cabinet_credit_meter", "credit_meter", ["ready", "committed", "paying"], ["read_only"]),
			_slot_ritual_object("cabinet_tower_light", "tower_light", ["off", "service", "feature", "handpay", "security"], ["passive"]),
			_slot_ritual_object("cabinet_money_path", "money_path", ["idle", "accepting", "paying"], ["enabled", "locked"]),
		],
		"energy": {"initial_tier": "quiet", "tiers": [
			{"id": "quiet", "actor_operations": [{"target": "neighbour_seats", "behavior": "idle"}], "object_operations": [{"target": "cabinet_body", "state": "idle"}], "interaction_operations": [], "audio_cues": []},
			{"id": "engaged", "actor_operations": [{"target": "neighbour_seats", "behavior": "playing"}], "object_operations": [{"target": "cabinet_button_deck", "state": "pressed"}], "interaction_operations": [], "audio_cues": []},
			{"id": "feature", "actor_operations": [{"target": "neighbour_seats", "behavior": "reacting"}], "object_operations": [{"target": "cabinet_tower_light", "state": "feature"}], "interaction_operations": [], "audio_cues": []},
			{"id": "lockup", "actor_operations": [{"target": "attendant_primary", "behavior": "handpay"}], "object_operations": [{"target": "cabinet_tower_light", "state": "handpay"}], "interaction_operations": [{"target": "button_deck", "state": "locked"}], "audio_cues": []},
		]},
		"game_facts": [
			{"fact_type": "machine.commitment_accepted", "fact_version": 1, "boundary": "action", "visibility": "public", "payload": {"bankroll_at_risk": "int"}},
			{"fact_type": "machine.result_completed", "fact_version": 1, "boundary": "action", "visibility": "public", "payload": {"coin_out": "int", "result_class": "string"}},
			{"fact_type": "machine.handpay_required", "fact_version": 1, "boundary": "action", "visibility": "public", "payload": {"jackpot_result_id": "string"}},
		],
		"ritual_persistence": {
			"authoritative_serialized": ["machine_state", "selected_bet", "host_bankroll", "active_bonus", "result_receipts"],
			"derived_projection": ["actors", "scene_objects", "energy", "hit_regions"],
			"transient_presentation": ["pointer_path", "reel_interpolation", "pulse", "hover"],
			"one_shot_receipted": ["coin_out_audio", "feature_entry", "room_reaction", "handpay_call"],
			"save_boundaries": ["bankroll", "commitment", "activation", "outcome_staging", "feature", "payout_or_handpay"],
			"restore_policy": "restore_legal_phase_without_replay",
		},
		"handler_registry": [{
			"handler_id": "slot_machine_authority", "version": 1, "accepted_actions": action_ids, "accepted_operations": [], "inputs": {"phase_id": "string"}, "outputs": {"public_projection": "qualified_id"},
			"authority": "sealed_host_slot_game_rules", "persisted_state": ["machine_state", "result_receipts"], "transient_state": ["pointer_path", "reel_interpolation"],
			"rng": {"owner": "slot_game_rules", "stream": "existing_action_stream", "consumption": "accepted_authoritative_action_only"},
			"emitted_facts": ["machine.commitment_accepted", "machine.result_completed", "machine.handpay_required"], "rejection": "side_effect_free",
		}],
		"declared_targets": {"anchors": ["cabinet", "attendant_station", "seat_rail", "reel_window", "credit_meter", "tower_light", "money_path"], "regions": ["button_deck", "handle_lane"], "sealed_host_targets": []},
	}


func _slot_ritual_phase(phase_id: String, permitted_actions: Array, next_phase: String) -> Dictionary:
	return {"id": phase_id, "entry_conditions": [], "permitted_actions": permitted_actions, "entry_operations": [], "transitions": [{"id": "%s_to_%s" % [phase_id, next_phase], "condition": {"kind": "public_state_equals", "key": "phase_complete", "value": true}, "next_phase": next_phase, "operations": []}], "terminal": false}


func _slot_ritual_pointer(pointer_id: String, verb: String, action_id: String, region: String) -> Dictionary:
	return {"id": pointer_id, "verb": verb, "source_region": region, "target_regions": [region], "bounds": {"space": "design", "min_distance": 0, "max_distance": 220}, "phases": ["bankroll", "commitment"], "accepted_action": action_id, "rejection": "restore_focus", "rejection_effects": [], "equivalents": {"keyboard": {"action_id": action_id, "target_selection": "focus"}, "controller": {"action_id": action_id, "target_selection": "focus"}, "reduced_motion": {"action_id": action_id, "target_selection": "focus", "staging": "short"}}}


func _slot_ritual_object(object_id: String, anchor: String, appearances: Array, functions: Array) -> Dictionary:
	return {"id": object_id, "anchor": anchor, "bounds": {"space": "design", "x": 80, "y": 50, "w": 740, "h": 330}, "z_layer": 10, "visual_states": appearances, "functional_states": functions, "initial_visual_state": str(appearances[0]), "initial_functional_state": str(functions[0]), "hit_regions": [], "text_safety_regions": []}


func setup(p_definition: Dictionary, p_library: ContentLibrary = null) -> void:
	super.setup(p_definition, p_library)
	definition_cache = DefinitionCacheScript.new()
	definition_cache.configure(p_definition)
	generator = GeneratorScript.new()
	resolver = ResolverScript.new()
	presentation = PresentationScript.new()
	renderer = RendererScript.new()
	catalog = CatalogScript.new()
	# Compile immutable pinball boards with the module, before any foreground or
	# background spin can make a player-facing frame pay the cold-cache cost.
	PinballFeatureScript.prewarm_board_templates()


func gameplay_model() -> String:
	return GameModule.GAMEPLAY_MODEL_FULL_SIMULATION


func enter(run_state: RunState, environment: Dictionary) -> Dictionary:
	_ensure_machine_state(run_state, environment, run_state.create_rng("slot_enter") if run_state != null else null)
	var result: Dictionary = super.enter(run_state, environment)
	var machine: Dictionary = _read_machine(environment)
	result["message"] = "%s %s machine waits." % [
		str(machine.get("type_id", "pinball")).capitalize(),
		str(machine.get("format_id", "classic_3_reel")).replace("_", " "),
	]
	return result


func checkpoint_surface_ui_state(ui_state: Dictionary, _run_state: RunState, environment: Dictionary) -> void:
	if _tag_loss_has_pending_authority(_peek_machine(environment)) or _bonus_recovery_required(_peek_machine(environment)):
		return
	var machine: Dictionary = _read_machine(environment)
	if machine.is_empty() or str(machine.get("slot_animation_id", "")).is_empty():
		return
	var runtime_value: Variant = ui_state.get("surface_runtime_status", {})
	var runtime: Dictionary = runtime_value as Dictionary if typeof(runtime_value) == TYPE_DICTIONARY else {}
	var animations_value: Variant = runtime.get("surface_animations", {})
	var animations: Dictionary = animations_value as Dictionary if typeof(animations_value) == TYPE_DICTIONARY else {}
	var spin_value: Variant = animations.get("slot_spin", {})
	var spin: Dictionary = spin_value as Dictionary if typeof(spin_value) == TYPE_DICTIONARY else {}
	var duration_msec := maxi(0, int(machine.get("slot_animation_duration_msec", 0)))
	if str(spin.get("active_id", "")) != str(machine.get("slot_animation_id", "")):
		if machine.has("slot_animation_resume_elapsed_msec") \
				and int(machine.get("slot_animation_resume_elapsed_msec", 0)) >= duration_msec \
				and not StateScript.active_bonus_incomplete(machine) \
				and not str(machine.get("slot_animation_id", "")).begins_with("bonus:"):
			_settle_completed_presentation(machine)
			_write_machine(environment, machine, false)
		return
	var elapsed_msec := maxi(0, int(round(float(spin.get("elapsed", 0.0)) * 1000.0)))
	if bool(spin.get("active", false)) and elapsed_msec < duration_msec:
		machine["slot_animation_resume_elapsed_msec"] = elapsed_msec
	elif StateScript.active_bonus_incomplete(machine) or str(machine.get("slot_animation_id", "")).begins_with("bonus:"):
		# Feature/replay payloads remain durable, but record that their finite
		# channel already reached the end so reopening does not replay it.
		machine["slot_animation_resume_elapsed_msec"] = duration_msec
	else:
		_settle_completed_presentation(machine)
	_write_machine(environment, machine, false)


func checkpoint_surface_ui_state_for_save(ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> void:
	if _tag_loss_has_pending_authority(_peek_machine(environment)) or _bonus_recovery_required(_peek_machine(environment)):
		return
	checkpoint_surface_ui_state(ui_state, run_state, environment)
	var machine: Dictionary = _read_machine(environment)
	var projected := BonusRecoveryScript.machine_view(machine, definition)
	var active: Dictionary = projected.get("active_bonus", {}) if typeof(projected.get("active_bonus", {})) == TYPE_DICTIONARY else {}
	if str(active.get("family", "")) != "pinball" or not bool(active.get("active", false)) or bool(active.get("complete", false)):
		return
	var durable := PinballFeatureScript.durable_runtime_checkpoint(active)
	if durable.is_empty():
		return
	# Capture the real runtime while retaining the original family tag and all
	# pending request fingerprints. Only accepted resolution migrates that tag.
	var saved_active: Dictionary = (machine["active_bonus"] as Dictionary).duplicate(false)
	saved_active[PinballFeatureScript.DURABLE_RUNTIME_KEY] = durable
	machine["active_bonus"] = saved_active
	_write_machine(environment, machine, false)


func _settle_completed_presentation(machine: Dictionary) -> void:
	# Feature state, replay data, final grid, classification, and offers remain
	# durable. Only the finite ordinary-spin timeline has reached end-of-life.
	machine.erase("slot_animation_resume_elapsed_msec")
	machine["slot_animation_id"] = ""
	machine["slot_animation_duration_msec"] = 0
	machine["slot_animation_started_msec"] = 0
	machine["slot_animation_plan"] = {}
	machine["last_previous_grid"] = []


func actions(run_state: RunState, environment: Dictionary) -> Dictionary:
	_ensure_machine_state(run_state, environment, run_state.create_rng("slot_actions") if run_state != null else null)
	var machine: Dictionary = _read_machine(environment)
	var selected: Dictionary = StateScript.selected_bet(machine)
	var ceiling := run_state.wager_stake_ceiling(maxi(20, run_state.wager_capacity_for_game(get_id(), environment))) if run_state != null else 20
	return {
		"ok": true,
		"type": "game_actions",
		"game_id": get_id(),
		"legal_actions": legal_actions(run_state, environment),
		"cheat_actions": cheat_actions(run_state, environment),
		"stake_floor": 2,
		"stake_ceiling": maxi(2, ceiling),
		"base_stake_ceiling": maxi(2, ceiling),
		"economy_stake_ceiling": maxi(2, ceiling),
		"economy_state": run_state.economy() if run_state != null else {},
		"economy_pressure_applied": false,
		"selected_stake": int(selected.get("total_credits", 2)),
	}


func legal_actions(_run_state: RunState, _environment: Dictionary) -> Array:
	if _bonus_recovery_required(_peek_machine(_environment)):
		return []
	return _slot_copy_array(definition.get("legal_actions", []))


func cheat_actions(run_state: RunState, environment: Dictionary) -> Array:
	if _bonus_recovery_required(_peek_machine(environment)):
		return []
	var actions: Array = super.cheat_actions(run_state, environment)
	var machine: Dictionary = _read_machine(environment)
	var nudge_ready := not _slot_copy_dict(machine.get("last_nudge_offer", {})).is_empty()
	for i in range(actions.size()):
		if typeof(actions[i]) != TYPE_DICTIONARY:
			continue
		var action: Dictionary = actions[i]
		if str(action.get("id", "")) == "nudge":
			action["summary"] = "Time the coin chain; heat +%d per nudge." % int(action.get("suspicion_delta", 12)) if nudge_ready else "Watch for a coin-chain tease; heat +%d." % int(action.get("suspicion_delta", 12))
			actions[i] = action
	return actions


func generate_environment_state(run_state: RunState, environment: Dictionary, rng: RngStream) -> Dictionary:
	var machine: Dictionary = generator.generate_machine(run_state, environment, rng, definition, get_id())
	return definition_cache.compact_machine_for_storage(machine)


func generate_environment_fixture_states(_run_state: RunState, environment: Dictionary, rng: RngStream, fixture_count: int) -> Dictionary:
	var local_flags: Dictionary = environment.get("local_narrative_flags", {}) if typeof(environment.get("local_narrative_flags", {})) == TYPE_DICTIONARY else {}
	var supported_room := str(environment.get("archetype_id", "")) == RunState.GRAND_CASINO_ARCHETYPE_ID \
			or bool(local_flags.get("practice_session", false))
	if not supported_room or fixture_count <= 0:
		return {}
	var fixture_specs := [
		{"format_id": "classic_3_reel", "type_id": "pinball", "math_variant_id": "steady", "cabinet_variant_id": "neon_magenta", "bonus_variant_id": "plain"},
		{"format_id": "line_5x3", "type_id": "buffalo", "math_variant_id": "standard", "cabinet_variant_id": "cyan_gold", "bonus_variant_id": "retrigger"},
		{"format_id": "video_feature", "type_id": "pinball", "math_variant_id": "volatile", "cabinet_variant_id": "blacklight", "bonus_variant_id": "jackpot_chase"},
		{"format_id": "classic_3_reel", "type_id": "buffalo", "math_variant_id": "steady", "cabinet_variant_id": "cyan_gold", "bonus_variant_id": "plain"},
		{"format_id": "line_5x3", "type_id": "pinball", "math_variant_id": "standard", "cabinet_variant_id": "blacklight", "bonus_variant_id": "retrigger"},
		{"format_id": "video_feature", "type_id": "buffalo", "math_variant_id": "volatile", "cabinet_variant_id": "neon_magenta", "bonus_variant_id": "jackpot_chase"},
	]
	var result: Dictionary = {}
	for fixture_index in range(fixture_count):
		var key := get_id() if fixture_index == 0 else "%s:%d" % [get_id(), fixture_index + 1]
		var spec: Dictionary = fixture_specs[fixture_index % fixture_specs.size()]
		var machine: Dictionary = generator.build_machine_from_ids(definition, spec, rng.fork("grand_casino_slot_fixture:%d" % fixture_index))
		var skin: Dictionary = catalog.skin_for_machine(machine, definition)
		machine["environment_display_name"] = str(skin.get("cabinet_title", "Slot"))
		# Build the immutable family/format view during room generation, outside
		# active play, so the first autoplay spin for a newly unique cabinet cannot
		# pay a one-time strip/cache construction cost.
		definition_cache.view_for_machine(machine)
		result[key] = definition_cache.compact_machine_for_storage(machine)
	return result


func _machine_state_key(environment: Dictionary) -> String:
	var default_key := get_id()
	var transient_key := transient_state_key_context()
	if transient_key == default_key or transient_key.begins_with("%s:" % default_key):
		return transient_key
	var active_keys_value: Variant = environment.get("active_game_state_keys", {})
	if typeof(active_keys_value) != TYPE_DICTIONARY:
		return default_key
	var active_key := str((active_keys_value as Dictionary).get(default_key, default_key)).strip_edges()
	if active_key == default_key or active_key.begins_with("%s:" % default_key):
		return active_key
	return default_key


func _read_machine(environment: Dictionary) -> Dictionary:
	return definition_cache.owned_runtime_machine(StateScript.peek_machine(environment, _machine_state_key(environment)))


func _bonus_recovery_required(machine: Dictionary) -> bool:
	return BonusRecoveryScript.recovery_required(BonusRecoveryScript.machine_view(machine, definition), definition)


func _tag_loss_has_pending_authority(machine: Dictionary) -> bool:
	var active_value: Variant = machine.get("active_bonus", null)
	if typeof(active_value) != TYPE_DICTIONARY or not str((active_value as Dictionary).get("family", "")).is_empty():
		return false
	var projected := BonusRecoveryScript.machine_view(machine, definition)
	var active: Dictionary = projected.get("active_bonus", {}) if typeof(projected.get("active_bonus", {})) == TYPE_DICTIONARY else {}
	if str(active.get("family", "")) != "pinball" or not bool(active.get("active", false)) or bool(active.get("complete", false)):
		return false
	# A view can repair the tag, but presentation and save checkpoints must not
	# change a sealed request's original machine context before it is accepted.
	var ledger: Dictionary = machine.get(ActionAuthorityScript.LEDGER_KEY, {}) if typeof(machine.get(ActionAuthorityScript.LEDGER_KEY, {})) == TYPE_DICTIONARY else {}
	for key in ["pending_delivery", "pending_recovery_session"]:
		if typeof(ledger.get(key, {})) == TYPE_DICTIONARY and not (ledger.get(key, {}) as Dictionary).is_empty():
			return true
	return machine.has(ActionAuthorityScript.PENDING_APPLY_RECEIPT_KEY)


func _peek_machine(environment: Dictionary) -> Dictionary:
	return StateScript.peek_machine(environment, _machine_state_key(environment))


func _write_machine(environment: Dictionary, machine: Dictionary, consume_saved_checkpoint: bool = true) -> void:
	if consume_saved_checkpoint:
		machine.erase("slot_animation_resume_elapsed_msec")
	StateScript.write_runtime_machine(environment, _machine_state_key(environment), machine)


func _write_owned_machine(environment: Dictionary, machine: Dictionary, consume_saved_checkpoint: bool = true) -> void:
	if consume_saved_checkpoint:
		machine.erase("slot_animation_resume_elapsed_msec")
	StateScript.write_runtime_machine(environment, _machine_state_key(environment), machine)


func active_item_command(item_id: String, run_state: RunState, environment: Dictionary, _rng: RngStream) -> Dictionary:
	var machine: Dictionary = _ensure_machine_state(run_state, environment, run_state.create_rng("slot_active_item") if run_state != null else null)
	match item_id:
		LUCKY_REEL_GREASE_ITEM_ID:
			return _arm_lucky_reel_grease(machine, environment)
		COLD_QUARTERS_ITEM_ID:
			return _load_cold_quarters(machine, environment)
		SPLIT_REEL_NOTE_ITEM_ID:
			return _arm_split_reel_note(machine, run_state, environment)
		CUMQUAT_SANDWICH_ITEM_ID:
			return _arm_cumquat_sandwich(machine, environment)
	return {"handled": false}


func surface_realtime_patch_preserves_host_state() -> bool:
	# Realtime presentation may commit the one-time reels-to-pinball reveal, but
	# it cannot change Foundation bankroll, pressure, intoxication, or selection.
	return true


func foreground_blocks_environment_runtime_during_surface_presentation() -> bool:
	return true


func surface_realtime_uses_lightweight_ui_state() -> bool:
	return true


func surface_realtime_ui_state_keys() -> Array:
	# Slot timing reads the canvas channel status plus optional player timing
	# inputs. Dense retained reels, history, and bonus data come from the owned
	# machine, not from the host UI dictionary.
	return ["surface_runtime_status", "slot_tease_input_msec", "slot_nudge_chain_input_msec"]


func surface_state(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	# Ordinary rendering is read-only. Once a machine exists, use its live stored
	# snapshot instead of rewriting the environment on every rebuild. The sole
	# exception below commits the one-time reels -> pinball lifecycle handoff.
	var machine: Dictionary = _read_machine(environment)
	if machine.is_empty():
		machine = _ensure_machine_state(run_state, environment, run_state.create_rng("slot_surface") if run_state != null else null)
	var presentation_machine := _saved_checkpoint_presentation_view(machine)
	var surface: Dictionary = presentation.surface_state(presentation_machine, run_state, definition, ui_state)
	if bool(surface.get("slot_bonus_trigger_revealed", false)):
		_commit_bonus_trigger_reveal(environment, machine)
	surface["ritual_contract"] = SLOT_RITUAL_CONTRACT
	surface["ritual_id"] = SLOT_RITUAL_ID
	surface["ritual_projection"] = _slot_live_ritual_projection(machine, surface, run_state)
	return surface


func embedded_action_view_patch(run_state: RunState, environment: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	var machine := _peek_machine(environment)
	if machine.is_empty():
		return {}
	var patch := surface_state(run_state, environment, ui_state)
	# This full Slot-owned surface replaces only the embedded canvas state. It is
	# derived after commit, so dense reel timelines never enter sealed replay
	# responses and Foundation need not rebuild the surrounding game/room model.
	patch["surface_action_realtime_refresh_required"] = true
	patch["surface_action_catalog_key"] = RuntimeScript.canonical_fingerprint({
		"state_key": _machine_state_key(environment),
		"challenge_cheats_disabled": run_state.challenge_cheat_actions_disabled() if run_state != null else false,
		"security_risk_bonus": run_state.security_risk_bonus("cheat") if run_state != null else 0,
		"security_pressure": run_state.security_pressure_label() if run_state != null else "",
		"pit_boss_watch": run_state.pit_boss_watch_status(environment) if run_state != null else {},
		"nudge_ready": not _slot_copy_dict(machine.get("last_nudge_offer", {})).is_empty(),
		"crew_actions": run_state.crew_play_actions(get_id(), environment) if run_state != null else [],
	})
	var selected := StateScript.selected_bet(machine)
	var ceiling := run_state.wager_stake_ceiling(maxi(20, run_state.wager_capacity_for_game(get_id(), environment))) if run_state != null else 20
	patch["surface_action_stake_view"] = {
		"stake_floor": 2,
		"stake_ceiling": maxi(2, ceiling),
		"base_stake_ceiling": maxi(2, ceiling),
		"economy_stake_ceiling": maxi(2, ceiling),
		"selected_stake": int(selected.get("total_credits", 2)),
	}
	return patch


func host_action_rollback_snapshot(action_id: String, run_state: RunState, environment: Dictionary) -> Dictionary:
	if _normalize_action(action_id) != "spin" or run_state == null:
		return {}
	var state_key := _machine_state_key(environment)
	var states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var machine_value: Variant = states.get(state_key, null)
	return {
		"supported": true,
		"state_key": state_key,
		"machine_present": typeof(machine_value) == TYPE_DICTIONARY,
		"machine": (machine_value as Dictionary).duplicate(true) if typeof(machine_value) == TYPE_DICTIONARY else {},
		"environment_runtime_revision_present": environment.has("environment_runtime_revision"),
		"environment_runtime_revision": int(environment.get("environment_runtime_revision", 0)),
	}


func restore_host_action_rollback(snapshot: Dictionary, _run_state: RunState, environment: Dictionary) -> bool:
	if not bool(snapshot.get("supported", false)):
		return false
	var state_key := str(snapshot.get("state_key", "")).strip_edges()
	if state_key.is_empty():
		return false
	var states: Dictionary = (environment.get("game_states", {}) as Dictionary).duplicate(false) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	if bool(snapshot.get("machine_present", false)):
		states[state_key] = (snapshot.get("machine", {}) as Dictionary).duplicate(true)
	else:
		states.erase(state_key)
	environment["game_states"] = states
	if bool(snapshot.get("environment_runtime_revision_present", false)):
		environment["environment_runtime_revision"] = int(snapshot.get("environment_runtime_revision", 0))
	else:
		environment.erase("environment_runtime_revision")
	return true


func _slot_live_ritual_projection(machine: Dictionary, surface: Dictionary, run_state: RunState) -> Dictionary:
	var animation_id := str(machine.get("slot_animation_id", ""))
	var feature_active := StateScript.active_bonus_incomplete(machine)
	var phase_id := "bankroll"
	if feature_active:
		phase_id = "feature"
	elif not animation_id.is_empty():
		phase_id = "outcome_staging"
	elif str(machine.get("last_classification", "idle")) != "idle":
		phase_id = "payout_or_handpay"
	var suspicion := run_state.suspicion_level() if run_state != null else 0
	var celebration := str(surface.get("slot_celebration_tier", "none"))
	var result_id := _slot_handpay_result_id(machine)
	var handpay := celebration in ["jackpot", "grand"] and not result_id.is_empty() and str(machine.get("ritual_acknowledged_result_id", "")) != result_id
	var energy_tier := "lockup" if handpay or suspicion >= 70 else "feature" if feature_active or celebration not in ["", "none"] else "engaged" if not animation_id.is_empty() else "quiet"
	var tower_state := "handpay" if handpay else "security" if suspicion >= 50 else "feature" if feature_active else "off"
	var selected_bet := int(surface.get("selected_bet_total_credits", 0))
	var actor_states := {
		"attendant_primary": {"visible": handpay or suspicion >= 50, "behavior": "handpay" if handpay else "security"},
		"neighbour_seats": {"visible": true, "behavior": "reacting" if celebration not in ["", "none"] else "playing", "authority": "none"},
	}
	var object_states := {
		"cabinet_body": {"visual_state": "lockup" if handpay else "feature" if feature_active else "play" if not animation_id.is_empty() else "idle"},
		"cabinet_reels": {"visual_state": "feature" if feature_active else "spinning" if not animation_id.is_empty() else "stopped"},
		"cabinet_button_deck": {"visual_state": "locked" if handpay or feature_active else "pressed" if not animation_id.is_empty() else "ready", "functional_state": "locked" if handpay or feature_active else "enabled"},
		"cabinet_credit_meter": {"visual_state": "ready", "cash_balance": int(surface.get("bankroll", 0)), "machine_credit_ledger": "unavailable"},
		"cabinet_tower_light": {"visual_state": tower_state},
		"cabinet_money_path": {"visual_state": "idle", "functional_state": "locked"},
	}
	return {
		"phase_id": phase_id,
		"cabinet_state": "lockup" if handpay else "feature" if feature_active else "play" if not animation_id.is_empty() else "idle",
		"energy_tier": energy_tier,
		"cash_balance": int(surface.get("bankroll", 0)),
		"machine_credit_ledger_available": false,
		"currency_representability_gap": "W0 direct-bankroll play is authoritative; no machine-credit ledger or conversion boundary exists.",
		"denomination_label": "$%d BET" % selected_bet,
		"tower_state": tower_state,
		"validator_state": "locked" if handpay or not animation_id.is_empty() else "ready",
		"button_state": "locked" if handpay or feature_active else "pressed" if not animation_id.is_empty() else "ready",
		"result_stage": "feature" if feature_active else "reel_stops" if not animation_id.is_empty() else "readout" if phase_id == "payout_or_handpay" else "idle",
		"payout": int(surface.get("slot_payout", 0)),
		"result_id": result_id,
		"acknowledgement_available": handpay and run_state != null,
		"actors": actor_states,
		"scene_objects": object_states,
	}


func _slot_handpay_result_id(machine: Dictionary) -> String:
	var spin_count := maxi(0, int(machine.get("spin_count", 0)))
	var outcome_id := str(machine.get("last_outcome_id", ""))
	if spin_count <= 0 or outcome_id.is_empty():
		return ""
	return "slot_result_%d_%s" % [spin_count, outcome_id]


func _slot_handpay_acknowledgement(run_state: RunState, environment: Dictionary, caller_claims: Dictionary = {}, sealed_host_proposal: bool = false) -> Dictionary:
	# Compatibility seam is deliberately non-authoritative. Neither a cached live
	# RunState identity nor a caller-authored boolean/capability may mutate Slot.
	return {
		"ok": false,
		"error_code": "unsealed_authority",
		"caller_claims_ignored": not caller_claims.is_empty(),
		"live_identity_ignored": run_state != null,
		"caller_proposal_flag_ignored": sealed_host_proposal,
		"environment_observed_only": not environment.is_empty(),
	}


func _slot_handpay_acknowledgement_proposal(environment: Dictionary) -> Dictionary:
	# Pure proposal construction. Only _machine_game_resolve_proposal writes this
	# candidate into its detached RunState snapshot; Foundation alone can commit it.
	var machine := _read_machine(environment).duplicate(true)
	var result_id := _slot_handpay_result_id(machine)
	if result_id.is_empty() or not str(machine.get("slot_celebration_tier", "none")) in ["jackpot", "grand"]:
		return {"ok": false, "error_code": "precondition_failed"}
	if str(machine.get("ritual_acknowledged_result_id", "")) == result_id:
		return {"ok": false, "error_code": "already_acknowledged", "result_id": result_id}
	machine["ritual_acknowledged_result_id"] = result_id
	var deltas := GameModule.empty_result_deltas()
	deltas["messages"] = ["The attendant acknowledges jackpot %s." % result_id]
	var result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": "slot_handpay_acknowledge",
		"action_kind": "legal",
		"stake": 0,
		"deltas": deltas,
		"won": false,
		"environment_id": str(environment.get("id", "")),
		"environment_archetype_id": str(environment.get("archetype_id", "")),
		"message": str((deltas.get("messages", []) as Array)[0]),
	})
	# build_action_result closes the shared envelope, so append only the sealed
	# Slot acknowledgement receipt fields after that normalization boundary.
	result["slot_handpay_acknowledgement"] = true
	result["slot_handpay_result_id"] = result_id
	result[ActionAuthorityScript.SKIP_ENVIRONMENT_TURN_KEY] = true
	return {"ok": true, "machine": machine, "result": result}


func _slot_sealed_handpay_acknowledgement_result(_run_state: RunState, environment: Dictionary) -> Dictionary:
	# Kept only as a hostile compatibility target: direct invocation never returns
	# a committable acknowledgement, regardless of live-object identity.
	return _empty_slot_result("slot_handpay_acknowledge", environment, "The attendant acknowledgement requires the sealed host.")


func _saved_checkpoint_presentation_view(machine: Dictionary) -> Dictionary:
	if not machine.has("slot_animation_resume_elapsed_msec"):
		return machine
	var view := machine.duplicate(true)
	var duration_msec := maxi(0, int(view.get("slot_animation_duration_msec", 0)))
	var elapsed_msec := clampi(int(view.get("slot_animation_resume_elapsed_msec", 0)), 0, duration_msec)
	if elapsed_msec >= duration_msec \
			and not StateScript.active_bonus_incomplete(view) \
			and not str(view.get("slot_animation_id", "")).begins_with("bonus:"):
		_settle_completed_presentation(view)
		return view
	view["slot_animation_resume_offset_msec"] = elapsed_msec
	return view


func surface_realtime_state_patch(run_state: RunState, environment: Dictionary, ui_state: Dictionary, current_surface_state: Dictionary = {}) -> Dictionary:
	# Realtime slot presentation used to rebuild the entire machine snapshot,
	# including reel strips, grids, audio cues, and bonus history, every frame.
	# Machine mutations still rebuild canonically at action boundaries; frames in
	# between only need the time-dependent presentation fields below.
	var machine := _peek_machine(environment)
	var patch: Dictionary = presentation.realtime_state_patch(machine, run_state, ui_state, current_surface_state, definition)
	if bool(patch.get("slot_bonus_trigger_revealed", false)):
		_commit_bonus_trigger_reveal(environment, machine)
	return patch


func _commit_bonus_trigger_reveal(environment: Dictionary, machine: Dictionary) -> void:
	if bool(machine.get("slot_bonus_trigger_revealed", false)):
		return
	if _tag_loss_has_pending_authority(machine):
		return
	var projected := BonusRecoveryScript.machine_view(machine, definition)
	var active: Dictionary = projected.get("active_bonus", {}) if typeof(projected.get("active_bonus", {})) == TYPE_DICTIONARY else {}
	if str(active.get("family", "")) != "pinball" or not bool(active.get("active", false)) or bool(active.get("complete", false)):
		return
	# This mutation happens exactly once per triggered feature. It is a lifecycle
	# transition, not per-frame presentation state, and lets full refreshes, save /
	# load, and re-entry agree that the triggering reels have yielded to pinball.
	var committed := _read_machine(environment)
	if committed.is_empty():
		return
	committed["slot_bonus_trigger_revealed"] = true
	_write_owned_machine(environment, committed, false)


func draw_surface(surface_canvas, surface_state: Dictionary, _render_context: Dictionary = {}) -> bool:
	return bool(renderer.draw(surface_canvas, surface_state, definition))


func prewarm_surface_assets() -> int:
	PinballFeatureScript.prewarm_board_templates()
	return int(renderer.prewarm_background_textures(definition))


func debug_surface_asset_cache_snapshot() -> Dictionary:
	return renderer.cache_snapshot()


func resolve(action_id: String, stake: int, run_state: RunState, environment: Dictionary, rng: RngStream) -> Dictionary:
	return resolve_with_context(action_id, stake, run_state, environment, rng, {})


func _machine_game_resolve_proposal(action_id: String, stake: int, run_snapshot: Dictionary, rng_snapshot: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	var proposal_input := {
		"action_id": action_id,
		"stake": stake,
		"run_snapshot": run_snapshot,
		"rng_snapshot": rng_snapshot,
		"ui_state": ui_state,
	}
	var candidate := RunState.new()
	candidate.from_dict(run_snapshot)
	var proposal_rng := RngStream.new()
	proposal_rng.restore(rng_snapshot)
	var result := _machine_game_resolve_candidate(action_id, stake, candidate, proposal_rng, ui_state)
	var proposal := {
		"ok": bool(result.get("ok", false)),
		"input_fingerprint": RuntimeScript.canonical_fingerprint(proposal_input),
		"result": result.duplicate(true),
		"run_snapshot": candidate.to_save_snapshot(),
		"rng_snapshot": proposal_rng.snapshot(),
	}
	proposal["output_fingerprint"] = RuntimeScript.canonical_fingerprint(proposal)
	return proposal


func _machine_game_resolve_candidate(action_id: String, stake: int, candidate: RunState, proposal_rng: RngStream, ui_state: Dictionary = {}) -> Dictionary:
	var result: Dictionary
	if action_id == "slot_handpay_acknowledge":
		var acknowledgement := _slot_handpay_acknowledgement_proposal(candidate.current_environment)
		if bool(acknowledgement.get("ok", false)):
			_write_machine(candidate.current_environment, (acknowledgement.get("machine", {}) as Dictionary).duplicate(true), false)
			result = (acknowledgement.get("result", {}) as Dictionary).duplicate(true)
		else:
			result = _empty_slot_result("slot_handpay_acknowledge", candidate.current_environment, "The attendant acknowledgement is unavailable or already receipted.")
	else:
		result = resolve_with_context(action_id, stake, candidate, candidate.current_environment, proposal_rng, ui_state.duplicate(true))
		if bool(result.get("ok", false)) and bool(result.get("host_apply_result", false)):
			result["machine_game_proposal_requires_apply"] = true
	return result


func _machine_game_wager_cost_proposal(action_id: String, stake: int, run_snapshot: Dictionary, ui_state: Dictionary = {}) -> Dictionary:
	var candidate := RunState.new()
	candidate.from_dict(run_snapshot)
	var cost := _machine_game_wager_cost_candidate(action_id, stake, candidate, ui_state)
	return {
		"cost": maxi(0, cost),
		"input_fingerprint": RuntimeScript.canonical_fingerprint({"action_id": action_id, "stake": stake, "run_snapshot": run_snapshot, "ui_state": ui_state}),
	}


func _machine_game_wager_cost_candidate(action_id: String, stake: int, candidate: RunState, ui_state: Dictionary = {}) -> int:
	return wager_cost_for_context(action_id, stake, candidate, candidate.current_environment, ui_state.duplicate(true))


func _machine_game_authority_evidence(candidate: RunState, action_id: String, stake: int, ui_state: Dictionary = {}) -> Dictionary:
	if candidate == null:
		return {}
	var environment := candidate.current_environment
	var machine := _peek_machine(environment).duplicate(false)
	# Replay/cache metadata proves the transaction envelope, not Slot math. It is
	# already validated independently by the host and must not recursively enlarge
	# the next action's deterministic evidence.
	machine.erase(ActionAuthorityScript.LEDGER_KEY)
	machine.erase(ActionAuthorityScript.PENDING_APPLY_RECEIPT_KEY)
	var environment_evidence := {
		"id": str(environment.get("id", "")),
		"archetype_id": str(environment.get("archetype_id", "")),
		"kind": str(environment.get("kind", "")),
		"tier": int(environment.get("tier", 0)),
		"turns": int(environment.get("turns", 0)),
		"economic_profile": _slot_copy_dict(environment.get("economic_profile", {})),
		"security_profile": _slot_copy_dict(environment.get("security_profile", {})),
		"local_narrative_flags": _slot_copy_dict(environment.get("local_narrative_flags", {})),
		"scenario_sequence_state": _slot_copy_dict(environment.get("scenario_sequence_state", {})),
	}
	return {
		"version": 1,
		"game_id": get_id(),
		"state_key": _machine_state_key(environment),
		"action_id": action_id,
		"stake": maxi(0, stake),
		"account_checkpoint": candidate.action_authority_checkpoint_fingerprint(),
		"bankroll": candidate.bankroll,
		"grand_casino_chips": candidate.grand_casino_chips,
		"rng_seed": candidate.rng_seed,
		"rng_state": candidate.rng_state,
		"simulation_msec": candidate.simulation_msec,
		"game_clock_minutes": candidate.game_clock_minutes,
		"challenge_modifiers": candidate.challenge_modifiers(),
		"tutorial_run": candidate.is_tutorial_run(),
		"challenge_cheats_disabled": candidate.challenge_cheat_actions_disabled(),
		"suspicion": candidate.suspicion.duplicate(true),
		"suspicion_level": candidate.suspicion_level(),
		"drunk_level": candidate.drunk_level,
		"alcoholic_level": candidate.alcoholic_level,
		"baseline_luck": candidate.baseline_luck,
		"effective_luck": candidate.effective_luck(),
		"active_item_id": candidate.active_item_id,
		"item_effects": _slot_cross_game_item_effects(candidate, machine, action_id == "nudge"),
		"security_risk_bonus": candidate.security_risk_bonus("cheat"),
		"pit_boss_watch": candidate.pit_boss_watch_status(environment),
		"environment": environment_evidence,
		"machine": machine,
		"ui_state": ui_state,
	}


func _machine_game_runtime_checkpoint(candidate: RunState) -> Dictionary:
	if candidate == null:
		return {}
	var machine := BonusRecoveryScript.machine_view(_peek_machine(candidate.current_environment), definition)
	if BonusRecoveryScript.recovery_required(machine, definition):
		return {}
	var active: Dictionary = machine.get("active_bonus", {}) if typeof(machine.get("active_bonus", {})) == TYPE_DICTIONARY else {}
	if str(active.get("family", "")) != "pinball":
		return {}
	return {
		"active_bonus": active.duplicate(true),
		"runtime": PinballFeatureScript.runtime_transaction_checkpoint(active),
	}


func _machine_game_runtime_restore(checkpoint: Dictionary) -> bool:
	if checkpoint.is_empty():
		return true
	var active: Dictionary = checkpoint.get("active_bonus", {}) if typeof(checkpoint.get("active_bonus", {})) == TYPE_DICTIONARY else {}
	var runtime_checkpoint: Dictionary = checkpoint.get("runtime", {}) if typeof(checkpoint.get("runtime", {})) == TYPE_DICTIONARY else {}
	return PinballFeatureScript.restore_runtime_transaction_checkpoint(active, runtime_checkpoint)


func _machine_game_host_needs_auto_tick(surface_time_msec: int, run_state: RunState, environment: Dictionary) -> bool:
	return surface_needs_auto_tick({"surface_time_msec": surface_time_msec, "drunk_scaled_surface_time_msec": surface_time_msec}, run_state, environment)


func resolve_with_context(action_id: String, _stake: int, run_state: RunState, environment: Dictionary, rng: RngStream, _ui_state: Dictionary = {}) -> Dictionary:
	if _bonus_recovery_required(_peek_machine(environment)):
		return _empty_slot_result(action_id, environment, BonusRecoveryScript.recovery_message())
	var machine: Dictionary = _ensure_machine_state(run_state, environment, rng)
	var normalized_action := _normalize_action(action_id)
	if normalized_action.begins_with("slot_bonus_"):
		# _ensure_machine_state returns a private, current-schema candidate. Preserve
		# that ownership through bonus resolution just as the spin path below does.
		var bonus_resolved: Dictionary = resolver.resolve_bonus_action_owned(machine, normalized_action, rng, definition, environment, run_state, _slot_cross_game_item_effects(run_state, machine, false), _ui_state)
		var bonus_machine_value: Variant = bonus_resolved.get("machine", machine)
		var bonus_machine: Dictionary = bonus_machine_value as Dictionary if typeof(bonus_machine_value) == TYPE_DICTIONARY else machine
		if not StateScript.active_bonus_incomplete(bonus_machine):
			bonus_machine.erase("slot_bonus_watchdog_since_msec")
		if bool(bonus_machine.get("slot_autoplay_active", false)):
			bonus_machine["slot_autoplay_next_msec"] = _slot_autoplay_next_msec(bonus_machine, _ui_state, run_state)
		if _buffalo_bonus_auto_action(bonus_machine).is_empty():
			bonus_machine.erase("slot_bonus_auto_next_msec")
		else:
			bonus_machine["slot_bonus_auto_next_msec"] = _slot_bonus_auto_next_msec(bonus_machine, _ui_state, run_state)
		_write_owned_machine(environment, bonus_machine)
		var bonus_result_value: Variant = bonus_resolved.get("result", {})
		return bonus_result_value as Dictionary if typeof(bonus_result_value) == TYPE_DICTIONARY else {}
	if normalized_action != "spin" and normalized_action != "nudge":
		return _empty_slot_result(normalized_action, environment, "That slot action is not available.")
	var selected_bet: Dictionary = StateScript.selected_bet(machine)
	# _ensure_machine_state returns an owned, current-schema machine and the
	# final write normalizes once. Normalizing at both resolver entry and exit
	# duplicated the entire reel/bonus state twice per spin.
	var resolved: Dictionary = resolver.resolve_spin(FunctionOptions.SlotResolveOptions.from({
		"machine": machine,
		"action_id": normalized_action,
		"selected_bet": selected_bet,
		"rng": rng,
		"definition": definition,
		"environment": environment,
		"normalize_machine": false,
		"audit_metrics_mode": false,
		"run_state": run_state,
		"item_effects": _slot_cross_game_item_effects(run_state, machine, normalized_action == "nudge"),
		"ui_state": _ui_state,
	}))
	var resolved_machine_value: Variant = resolved.get("machine", machine)
	var resolved_machine: Dictionary = resolved_machine_value as Dictionary if typeof(resolved_machine_value) == TYPE_DICTIONARY else machine
	resolved = _apply_tutorial_first_night_match(resolved, resolved_machine, normalized_action, run_state)
	resolved_machine_value = resolved.get("machine", resolved_machine)
	if typeof(resolved_machine_value) == TYPE_DICTIONARY:
		resolved_machine = resolved_machine_value as Dictionary
	if _slot_feature_pending(resolved_machine):
		resolved_machine = _mark_slot_feature_pending(resolved_machine, GameModule.deterministic_time_msec(run_state, _ui_state))
	elif bool(resolved_machine.get("slot_autoplay_active", false)):
		resolved_machine["slot_autoplay_next_msec"] = _slot_autoplay_next_msec(resolved_machine, _ui_state, run_state)
	if _buffalo_bonus_auto_action(resolved_machine).is_empty():
		resolved_machine.erase("slot_bonus_auto_next_msec")
	else:
		resolved_machine["slot_bonus_auto_next_msec"] = _slot_bonus_auto_next_msec(resolved_machine, _ui_state, run_state)
	_write_owned_machine(environment, resolved_machine)
	var result_value: Variant = resolved.get("result", {})
	return result_value as Dictionary if typeof(result_value) == TYPE_DICTIONARY else {}


func _apply_tutorial_first_night_match(resolved: Dictionary, machine: Dictionary, action_id: String, run_state: RunState) -> Dictionary:
	if run_state == null or action_id != "spin" or not run_state.is_tutorial_run():
		return resolved
	var friendly_net := maxi(0, int(run_state.challenge_modifiers().get("tutorial_first_slot_net", 0)))
	if friendly_net <= 0 or maxi(0, int(machine.get("spin_count", 0))) != 1:
		return resolved
	var adjusted := resolved.duplicate(true)
	var result := _slot_copy_dict(adjusted.get("result", {}))
	if not bool(result.get("ok", false)):
		return resolved
	var stake_cost := maxi(0, int(result.get("slot_stake_cost", result.get("stake", 0))))
	var payout := stake_cost + friendly_net
	var deltas := _slot_copy_dict(result.get("deltas", {}))
	deltas["bankroll_delta"] = friendly_net
	var story_log := _slot_copy_array(deltas.get("story_log", []))
	if not story_log.is_empty() and typeof(story_log[story_log.size() - 1]) == TYPE_DICTIONARY:
		var story := _slot_copy_dict(story_log[story_log.size() - 1])
		story["bankroll_delta"] = friendly_net
		story["currency_delta"] = friendly_net
		story["payout"] = payout
		story["classification"] = "tutorial_match"
		story["outcome_id"] = "tutorial_first_night_match"
		story["tutorial_first_night_match"] = true
		story_log[story_log.size() - 1] = story
	deltas["story_log"] = story_log
	deltas["messages"] = ["The First Night match adds $%d, leaving this spin $%d ahead." % [payout, friendly_net]]
	result["deltas"] = deltas
	result["bankroll_delta"] = friendly_net
	result["message"] = str(deltas["messages"][0])
	result["messages"] = deltas["messages"]
	result["won"] = true
	result["slot_net"] = friendly_net
	result["slot_payout"] = payout
	result["slot_classification"] = "tutorial_match"
	result["slot_outcome_id"] = "tutorial_first_night_match"
	result["tutorial_first_night_match"] = true
	var adjusted_machine := machine.duplicate(true)
	adjusted_machine["last_net"] = friendly_net
	adjusted_machine["last_payout"] = payout
	adjusted_machine["last_classification"] = "tutorial_match"
	adjusted_machine["last_outcome_id"] = "tutorial_first_night_match"
	adjusted["machine"] = adjusted_machine
	adjusted["result"] = result
	return adjusted


func wager_cost_for_context(action_id: String, _stake: int, run_state: RunState, environment: Dictionary, _ui_state: Dictionary = {}) -> int:
	var normalized_action := _normalize_action(action_id)
	if normalized_action.begins_with("slot_bonus_") or normalized_action in ["slot_bet", "slot_auto_toggle", "slot_handpay_acknowledge"]:
		return 0
	# Wager queries are read-only and run immediately before resolution. Reuse the
	# canonical stored machine instead of cloning its nested reel/bonus state.
	var machine: Dictionary = _query_machine(run_state, environment, "slot_cost")
	var selected: Dictionary = StateScript.selected_bet(machine)
	if normalized_action == "nudge" and not _slot_copy_dict(machine.get("last_nudge_offer", {})).is_empty():
		return 0
	if normalized_action == "spin" and int(machine.get("free_spins", 0)) > 0:
		return 0
	return maxi(0, int(selected.get("total_credits", 2)))


func minimum_wager_return_for_context(action_id: String, _stake: int, wager_cost: int, run_state: RunState, environment: Dictionary, _ui_state: Dictionary = {}) -> int:
	if _normalize_action(action_id) != "spin" or wager_cost <= 0:
		return 0
	var machine := _query_machine(run_state, environment, "slot_minimum_return")
	var item_effects := _slot_cross_game_item_effects(run_state, machine, false)
	var guaranteed_return := maxi(0, int(item_effects.get("loss_reduction", 0)))
	if str(machine.get("format_id", "")) == "classic_3_reel":
		var refund_percent := maxi(0, int(item_effects.get("slot_three_reel_loss_refund_percent", 0)))
		if refund_percent > 0:
			guaranteed_return += mini(wager_cost, maxi(1, int(round(float(wager_cost) * float(refund_percent) / 100.0))))
	return mini(wager_cost, guaranteed_return)


func surface_pointer_command(surface_action: String, index: int, phase: String, board_position: Vector2, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if surface_action != SLOT_HANDLE_PULL_GESTURE:
		return {"handled": false}
	var next := ui_state
	if phase == "begin":
		next["slot_handle_active"] = true
		next["slot_handle_origin"] = board_position
		next["slot_handle_distance"] = 0.0
		return GameModule.surface_command({"handled": true, "ui_state": next, "preserve_surface_ui_state": true})
	if phase == "move" and bool(next.get("slot_handle_active", false)):
		var origin: Vector2 = next.get("slot_handle_origin", board_position)
		next["slot_handle_distance"] = maxf(0.0, board_position.y - origin.y)
		return GameModule.surface_command({"handled": true, "ui_state": next, "preserve_surface_ui_state": true})
	if phase in ["cancel", "end"]:
		var end_origin: Vector2 = next.get("slot_handle_origin", board_position)
		var pull_distance := maxf(float(next.get("slot_handle_distance", 0.0)), board_position.y - end_origin.y)
		var pulled := pull_distance >= SLOT_HANDLE_MIN_PULL
		next.erase("slot_handle_active")
		next.erase("slot_handle_origin")
		next.erase("slot_handle_distance")
		if phase == "end" and pulled:
			var command := surface_action_command("slot_spin", index, false, next, run_state, environment)
			command["ui_state"] = next
			command["preserve_surface_ui_state"] = true
			return command
		return GameModule.surface_command({"handled": true, "ui_state": next, "preserve_surface_ui_state": true, "message": "Pull the handle through its full travel to spin."})
	return GameModule.surface_command({"handled": true, "ui_state": next, "preserve_surface_ui_state": true})


func surface_action_command(surface_action: String, index: int, confirm_requested: bool, ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	if _bonus_recovery_required(_peek_machine(environment)):
		return GameModule.surface_command({"handled": true, "message": BonusRecoveryScript.recovery_message()})
	var machine: Dictionary = _ensure_machine_state(run_state, environment, run_state.create_rng("slot_surface_action") if run_state != null else null)
	if surface_action.begins_with(SELECT_BET_PREFIX):
		var bet_id := surface_action.substr(SELECT_BET_PREFIX.length())
		machine = StateScript.set_selected_bet(machine, bet_id)
		_write_machine(environment, machine)
		return GameModule.surface_command({
			"handled": true,
			"environment_changed": true,
			"selected_index": index,
			"set_stake": int(StateScript.selected_bet(machine).get("total_credits", 2)),
			"message": "Bet set to $%d." % int(StateScript.selected_bet(machine).get("total_credits", 2)),
		})
	if _is_pinball_direct_bonus_action(surface_action):
		return GameModule.surface_command({
			"handled": true,
			"action_id": surface_action,
			"action_kind": "bonus",
			"direct_resolve": true,
			"skip_stake_validation": true,
			"preserve_surface_ui_state": true,
			"selected_index": index,
			"message": "Bonus input.",
		})
	match surface_action:
		"slot_handpay_acknowledge":
			return GameModule.surface_command({
				"handled": true,
				"action_id": "slot_handpay_acknowledge",
				"action_kind": "legal",
				"direct_resolve": true,
				"skip_stake_validation": true,
				"set_stake": 0,
				"message": "Calling the attendant to acknowledge the sealed jackpot result.",
			})
		"spin", "slot_spin":
			return GameModule.surface_command({
				"handled": true,
				"action_id": "spin",
				"action_kind": "legal",
				"resolve": true,
				"selected_index": index,
				"set_stake": int(StateScript.selected_bet(machine).get("total_credits", 2)),
				"message": "Spin.",
			})
		"nudge", "slot_nudge":
			var nudge_ready := not _slot_copy_dict(machine.get("last_nudge_offer", {})).is_empty()
			return GameModule.surface_command({
				"handled": true,
				"action_id": "nudge",
				"action_kind": "cheat",
				"direct_resolve": nudge_ready,
				"resolve": nudge_ready or confirm_requested or str(ui_state.get("selected_action_id", "")) == "nudge",
				"selected_index": index,
				"set_stake": int(StateScript.selected_bet(machine).get("total_credits", 2)),
				"message": "Coin-chain nudge selected." if nudge_ready else "Nudge selected.",
			})
		"slot_bet":
			machine = StateScript.set_selected_bet_by_index(machine, index)
			_write_machine(environment, machine)
			return GameModule.surface_command({
				"handled": true,
				"environment_changed": true,
				"selected_index": index,
				"set_stake": int(StateScript.selected_bet(machine).get("total_credits", 2)),
				"message": "Bet set to $%d." % int(StateScript.selected_bet(machine).get("total_credits", 2)),
			})
		"slot_auto_toggle":
			machine["slot_autoplay_active"] = not bool(machine.get("slot_autoplay_active", false))
			if bool(machine.get("slot_autoplay_active", false)):
				machine["slot_autoplay_next_msec"] = _slot_autoplay_next_msec(machine, ui_state, run_state)
			else:
				machine["slot_autoplay_next_msec"] = 0
			_write_machine(environment, machine)
			return GameModule.surface_command({
				"handled": true,
				"environment_changed": true,
				"message": "Autoplay on." if bool(machine.get("slot_autoplay_active", false)) else "Autoplay off.",
			})
		"launch", "left", "right", "soft", "hard", "power_down", "power_up", "tilt", "slot_bonus_launch", "slot_bonus_left", "slot_bonus_right", "slot_bonus_power_down", "slot_bonus_power_up", "slot_bonus_soft", "slot_bonus_hard", "slot_bonus_tilt":
			return GameModule.surface_command({
				"handled": true,
				"action_id": _normalize_bonus_action(surface_action),
				"action_kind": "bonus",
				"direct_resolve": true,
				"skip_stake_validation": true,
				"preserve_surface_ui_state": true,
				"selected_index": index,
				"message": "Bonus input.",
			})
	return {"handled": false}


func surface_uses_auto_tick() -> bool:
	return true


func surface_needs_auto_tick(ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> bool:
	# Per-frame check: peek (zero-copy, read-only) instead of deep-copying the machine.
	var machine := BonusRecoveryScript.machine_view(_peek_machine(environment), definition)
	if BonusRecoveryScript.recovery_required(machine, definition):
		return false
	var buffalo_bonus_action := _buffalo_bonus_auto_action(machine)
	if not buffalo_bonus_action.is_empty():
		var bonus_surface_time := _surface_timing_msec(ui_state)
		var next_msec := int(machine.get("slot_bonus_auto_next_msec", 0))
		return bonus_surface_time <= 0 or next_msec <= 0 or bonus_surface_time >= next_msec
	var watchdog: Dictionary = _slot_bonus_watchdog_status(machine, ui_state)
	if bool(watchdog.get("needs_tick", false)):
		return true
	var surface_time := _surface_timing_msec(ui_state)
	if machine.is_empty() or not bool(machine.get("slot_autoplay_active", false)):
		return false
	var next_msec := int(machine.get("slot_autoplay_next_msec", 0))
	return surface_time <= 0 or next_msec <= 0 or surface_time >= next_msec


func surface_auto_action_uses_lightweight_ui_state() -> bool:
	# Slot autoplay commands and resolution only read selected stake plus the
	# deterministic surface clocks supplied by the lightweight tick snapshot.
	return true


func surface_auto_action_command(ui_state: Dictionary, _run_state: RunState, environment: Dictionary, _surface_status: Dictionary = {}) -> Dictionary:
	# The common autoplay path only inspects machine state. Take an owned copy
	# solely in the recovery branches that actually mutate it.
	var machine := BonusRecoveryScript.machine_view(_query_machine(_run_state, environment, "slot_auto_action"), definition)
	if BonusRecoveryScript.recovery_required(machine, definition):
		return {"handled": false}
	if machine.is_empty():
		return {"handled": false}
	var surface_time := _surface_timing_msec(ui_state)
	var buffalo_bonus_action := _buffalo_bonus_auto_action(machine)
	if not buffalo_bonus_action.is_empty():
		if surface_time <= 0:
			surface_time = Time.get_ticks_msec()
		var next_msec := int(machine.get("slot_bonus_auto_next_msec", 0))
		if next_msec <= 0:
			machine = _read_machine(environment)
			machine["slot_bonus_auto_next_msec"] = surface_time + _slot_bonus_auto_delay_msec(machine)
			_write_owned_machine(environment, machine)
			return GameModule.surface_command({
				"handled": true,
				"environment_changed": true,
				"message": "Buffalo feature reels are winding up.",
			})
		if surface_time < next_msec:
			return {"handled": false}
		return GameModule.surface_command({
			"handled": true,
			"action_id": buffalo_bonus_action,
			"action_kind": "bonus",
			"direct_resolve": true,
			"skip_stake_validation": true,
			"preserve_surface_ui_state": true,
			"ui_state": {
				"surface_time_msec": int(ui_state.get("surface_time_msec", surface_time)),
				"drunk_scaled_surface_time_msec": surface_time,
			},
			"message": "Buffalo feature auto spin.",
		})
	var watchdog: Dictionary = _slot_bonus_watchdog_status(machine, ui_state)
	if bool(watchdog.get("needs_seed", false)):
		if surface_time <= 0:
			surface_time = Time.get_ticks_msec()
		machine = _read_machine(environment)
		machine["slot_bonus_watchdog_since_msec"] = surface_time
		_write_owned_machine(environment, machine)
		return GameModule.surface_command({
			"handled": true,
			"environment_changed": true,
			"message": "Bonus recovery check armed.",
		})
	if bool(watchdog.get("due", false)):
		if surface_time <= 0:
			surface_time = Time.get_ticks_msec()
		return GameModule.surface_command({
			"handled": true,
			"action_id": SLOT_BONUS_WATCHDOG_ACTION,
			"action_kind": "bonus",
			"direct_resolve": true,
			"skip_stake_validation": true,
			"preserve_surface_ui_state": true,
			"ui_state": {
				"surface_time_msec": int(ui_state.get("surface_time_msec", surface_time)),
				"drunk_scaled_surface_time_msec": surface_time,
			},
			"message": "Bonus recovery tick.",
		})
	if StateScript.active_bonus_incomplete(machine):
		var paused_family := _slot_active_bonus_family(machine)
		machine = _read_machine(environment)
		machine["slot_autoplay_active"] = false
		machine["slot_autoplay_next_msec"] = 0
		_write_owned_machine(environment, machine)
		return GameModule.surface_command({
			"handled": true,
			"environment_changed": true,
			"message": "Autoplay paused for %s bonus." % paused_family.capitalize(),
		})
	# The host predicate is a performance fast path, not authority to skip the
	# machine's own deadline. Recheck the ordinary timer here just as Buffalo does
	# above so a mismatched/stale caller can never resolve hundreds of spins in one
	# presentation interval.
	if not bool(machine.get("slot_autoplay_active", false)):
		return {"handled": false}
	if surface_time <= 0:
		surface_time = Time.get_ticks_msec()
	var autoplay_next_msec := int(machine.get("slot_autoplay_next_msec", 0))
	if autoplay_next_msec <= 0:
		machine = _read_machine(environment)
		machine["slot_autoplay_next_msec"] = surface_time + _slot_autoplay_delay_msec(machine)
		_write_owned_machine(environment, machine)
		return GameModule.surface_command({
			"handled": true,
			"environment_changed": true,
			"message": "Autoplay reels are winding up.",
		})
	if surface_time < autoplay_next_msec:
		return {"handled": false}
	# Decide whether paid Auto may continue before the host seals a spin. A
	# rejected unaffordable delivery otherwise owns the controls indefinitely;
	# pausing after sealing also changes the delivery's trusted machine context.
	var wager_cost := wager_cost_for_context("spin", 0, _run_state, environment, ui_state)
	var capacity := _run_state.wager_capacity_for_game(get_id(), environment) if _run_state != null else 0
	var guaranteed_return := minimum_wager_return_for_context("spin", 0, wager_cost, _run_state, environment, ui_state) if wager_cost == capacity else 0
	if wager_cost > 0 and (wager_cost > capacity or capacity - wager_cost + guaranteed_return <= 0):
		machine = _read_machine(environment)
		machine["slot_autoplay_active"] = false
		machine["slot_autoplay_next_msec"] = 0
		_write_machine(environment, machine)
		return GameModule.surface_command({
			"handled": true,
			"environment_changed": true,
			# This is a presentation request, not a wager delivery. Acceptance
			# enters the ordinary sealed resolver once the player has decided.
			"request_wager_confirmation": wager_cost <= capacity,
			"wager_confirmation_action_id": "spin",
			"wager_confirmation_stake": int(StateScript.selected_bet(machine).get("total_credits", 2)),
			"message": "Autoplay paused for all-in confirmation." if wager_cost <= capacity else "Autoplay paused. Choose a smaller bet to keep playing.",
		})
	return GameModule.surface_command({
		"handled": true,
		"action_id": "spin",
		"action_kind": "legal",
		"direct_resolve": true,
		"ui_state": {
			"surface_time_msec": int(ui_state.get("surface_time_msec", surface_time)),
			"drunk_scaled_surface_time_msec": surface_time,
		},
		"set_stake": int(StateScript.selected_bet(machine).get("total_credits", 2)),
		"message": "Autoplay spin.",
	})


func surface_pause_repeating_action_for_confirmation(_ui_state: Dictionary, _run_state: RunState, environment: Dictionary) -> Dictionary:
	var machine: Dictionary = _read_machine(environment)
	if machine.is_empty() or not bool(machine.get("slot_autoplay_active", false)):
		return {"handled": false}
	machine["slot_autoplay_active"] = false
	machine["slot_autoplay_next_msec"] = 0
	_write_machine(environment, machine)
	return GameModule.surface_command({
		"handled": true,
		"environment_changed": true,
		"message": "Autoplay paused for all-in confirmation.",
	})


func environment_runtime_enabled() -> bool:
	return true


func environment_runtime_needs_tick(_run_state: RunState, environment: Dictionary, now_msec: int) -> bool:
	# Per-frame check: peek (zero-copy, read-only) instead of deep-copying the machine.
	var machine: Dictionary = _peek_machine(environment)
	if machine.is_empty() or not bool(machine.get("slot_autoplay_active", false)):
		return false
	var next_msec := int(machine.get("slot_autoplay_next_msec", 0))
	return next_msec <= 0 or now_msec >= next_msec


func environment_runtime_next_due_msec(_run_state: RunState, environment: Dictionary, now_msec: int) -> int:
	var machine: Dictionary = _peek_machine(environment)
	if machine.is_empty() or not bool(machine.get("slot_autoplay_active", false)):
		return -1
	var next_msec := int(machine.get("slot_autoplay_next_msec", 0))
	return now_msec if next_msec <= 0 else next_msec


func environment_runtime_tick(run_state: RunState, environment: Dictionary, rng: RngStream, now_msec: int) -> Dictionary:
	var machine: Dictionary = _ensure_machine_state(run_state, environment, rng)
	if machine.is_empty() or not bool(machine.get("slot_autoplay_active", false)):
		return {"handled": false}
	if StateScript.active_bonus_incomplete(machine):
		var paused_family := _slot_active_bonus_family(machine)
		machine = _mark_slot_feature_pending(machine, now_msec)
		_write_machine(environment, machine)
		return {
			"handled": true,
			"message": "Autoplay paused for %s bonus." % paused_family.capitalize(),
			"attention": true,
			"audio_cue": _slot_feature_audio_cue(machine),
			"audio_cue_volume_db": _slot_feature_audio_volume_db(machine),
		}
	if wager_cost_for_context("spin", 0, run_state, environment) > run_state.wager_capacity_for_game(get_id(), environment):
		machine["slot_autoplay_active"] = false
		machine["slot_autoplay_next_msec"] = 0
		_write_machine(environment, machine)
		return {"handled": true, "message": "Autoplay paused. Choose a smaller bet to keep playing."}
	machine["slot_autoplay_next_msec"] = now_msec + _slot_autoplay_delay_msec(machine)
	_write_machine(environment, machine)
	var selected_bet: Dictionary = StateScript.selected_bet(machine)
	var resolved: Dictionary = resolver.resolve_spin(FunctionOptions.SlotResolveOptions.from({
		"machine": machine,
		"action_id": "spin",
		"selected_bet": selected_bet,
		"rng": rng,
		"definition": definition,
		"environment": environment,
		"normalize_machine": false,
		"audit_metrics_mode": false,
		"run_state": run_state,
		"item_effects": _slot_cross_game_item_effects(run_state, machine, false),
		"ui_state": {},
		"include_presentation_payload": false,
	}))
	var resolved_machine_value: Variant = resolved.get("machine", machine)
	var resolved_machine: Dictionary = resolved_machine_value as Dictionary if typeof(resolved_machine_value) == TYPE_DICTIONARY else machine
	var feature_pending := _slot_feature_pending(resolved_machine)
	if feature_pending:
		resolved_machine = _mark_slot_feature_pending(resolved_machine, now_msec)
	else:
		resolved_machine["slot_autoplay_active"] = true
		resolved_machine["slot_autoplay_next_msec"] = now_msec + _slot_autoplay_delay_msec(resolved_machine)
	_write_owned_machine(environment, resolved_machine)
	var result_value: Variant = resolved.get("result", {})
	var result: Dictionary = result_value as Dictionary if typeof(result_value) == TYPE_DICTIONARY else {}
	if feature_pending:
		result["slot_pending_feature"] = true
	return {
		"handled": true,
		"result": result,
		"message": "Slot feature ready. Open the machine to play it.",
		"attention": feature_pending,
		"audio_cue": _slot_feature_audio_cue(resolved_machine) if feature_pending else "",
		"audio_cue_volume_db": _slot_feature_audio_volume_db(resolved_machine) if feature_pending else -1.0,
	}


func environment_runtime_state(_run_state: RunState, environment: Dictionary) -> Dictionary:
	var machine: Dictionary = _read_machine(environment)
	if machine.is_empty():
		return {}
	return _slot_environment_runtime_state_for_machine(machine)


func environment_object_state(run_state: RunState, environment: Dictionary) -> Dictionary:
	var machine: Dictionary = _read_machine(environment)
	if machine.is_empty():
		return {}
	return _slot_environment_object_state_for_machine(machine, run_state, environment)


func environment_object_state_for_state_key(run_state: RunState, environment: Dictionary, state_key: String) -> Dictionary:
	var machine: Dictionary = StateScript.read_machine(environment, _normalized_fixture_state_key(state_key))
	if machine.is_empty():
		return {}
	return _slot_environment_object_state_for_machine(machine, run_state, environment)


func _slot_environment_object_state_for_machine(machine: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	var preview := _slot_environment_preview(machine)
	var runtime := _slot_environment_runtime_state_for_machine(machine, preview)
	return {
		"display_name": str(machine.get("environment_display_name", "Slot")),
		"status_summary": str(runtime.get("status_summary", "")),
		"state_badge": str(runtime.get("status_label", "")),
		"nudge_heat_preview": resolver.preview_nudge_heat(machine, run_state, definition, environment, _slot_cross_game_item_effects(run_state, machine, true)),
		"runtime_state": runtime,
		"visual_state": _slot_environment_visual_state(machine, preview),
	}


func _normalized_fixture_state_key(state_key: String) -> String:
	var clean_key := state_key.strip_edges()
	if clean_key == get_id() or clean_key.begins_with("%s:" % get_id()):
		return clean_key
	return get_id()


func _slot_environment_runtime_state_for_machine(machine: Dictionary, preview: Dictionary = {}, now_msec: int = -1) -> Dictionary:
	var active_bonus: Dictionary = _slot_copy_dict(machine.get("active_bonus", {}))
	var nudge_offer: Dictionary = _slot_copy_dict(machine.get("last_nudge_offer", {}))
	var bonus_preview: Dictionary = _slot_copy_dict(preview.get("bonus", {}))
	var nudge_preview: Dictionary = _slot_copy_dict(preview.get("nudge_chain", {}))
	var phase := str(preview.get("phase", ""))
	if phase.is_empty():
		if now_msec < 0:
			now_msec = Time.get_ticks_msec()
		phase = _slot_runtime_phase(machine, active_bonus, nudge_offer, now_msec)
	var bonus_active := bool(bonus_preview.get("active", bool(active_bonus.get("active", false)) and not bool(active_bonus.get("complete", false))))
	var nudge_chain_active := bool(nudge_preview.get("active", not nudge_offer.is_empty() and str(nudge_offer.get("type", "")) == "coin_chain"))
	var active := bool(preview.get("active", _slot_preview_active(machine, active_bonus, nudge_offer, phase)))
	var caption := str(preview.get("caption", _slot_preview_caption(phase, machine, active_bonus, nudge_offer)))
	return {
		"active": active,
		"status_label": str(preview.get("status_label", _slot_preview_status_label(phase, machine, active_bonus, nudge_offer))),
		"status_summary": "Slot spins %d, coin in $%d, coin out $%d." % [int(machine.get("spin_count", 0)), int(machine.get("coin_in", 0)), int(machine.get("coin_out", 0))],
		"spin_count": int(machine.get("spin_count", 0)),
		"slot_autoplay_active": bool(machine.get("slot_autoplay_active", false)),
		"slot_bonus_active": bonus_active,
		"slot_pending_feature": bool(preview.get("pending_feature", bonus_active)),
		"slot_pending_feature_alert": bool(machine.get("slot_pending_feature_alert", false)),
		"slot_bonus_family": str(bonus_preview.get("family", active_bonus.get("family", ""))),
		"slot_feature_audio_cue": _slot_feature_audio_cue(machine) if bool(preview.get("pending_feature", bonus_active)) else "",
		"slot_feature_audio_volume_db": _slot_feature_audio_volume_db(machine) if bool(preview.get("pending_feature", bonus_active)) else -1.0,
		"slot_free_spins": int(machine.get("free_spins", 0)),
		"slot_last_payout": int(machine.get("last_payout", 0)),
		"slot_last_classification": str(machine.get("last_classification", "idle")),
		"slot_preview_phase": phase,
		"slot_preview_caption": caption,
		"slot_nudge_chain_active": nudge_chain_active,
	}


func _slot_environment_visual_state(machine: Dictionary, preview: Dictionary = {}) -> Dictionary:
	var skin: Dictionary = {}
	var environment_catalog = catalog
	if environment_catalog == null:
		environment_catalog = CatalogScript.new()
	if environment_catalog != null:
		skin = environment_catalog.skin_for_machine(machine, definition)
	var active_bonus: Dictionary = _slot_copy_dict(machine.get("active_bonus", {}))
	var resolved_preview := preview
	if resolved_preview.is_empty():
		resolved_preview = _slot_environment_preview(machine)
	return {
		"machine_family": str(machine.get("type_id", "slot")),
		"machine_format": str(machine.get("format_id", "")),
		"machine_key": str(machine.get("machine_key", "")),
		"cabinet_variant_id": str(machine.get("cabinet_variant_id", "")),
		"cabinet_identity": str(skin.get("cabinet_identity", "")),
		"cabinet_title": str(skin.get("cabinet_title", "")),
		"cabinet_material": str(skin.get("material", "")),
		"cabinet_topper_style": str(skin.get("topper_style", "")),
		"cabinet_motion_style": str(skin.get("motion_style", "")),
		"cabinet_background_path": str(skin.get("background_path", "")),
		"cabinet_palette": _slot_copy_dict(skin.get("palette", {})),
		"feature_name": str(skin.get("feature_name", "")),
		"pay_model": str(skin.get("pay_model", "")),
		"reel_count": int(skin.get("reel_count", machine.get("reel_count", 3))),
		"row_count": int(skin.get("row_count", machine.get("row_count", 1))),
		"last_classification": str(machine.get("last_classification", "idle")),
		"last_payout": int(machine.get("last_payout", 0)),
		"free_spins": int(machine.get("free_spins", 0)),
		"active_bonus_family": str(active_bonus.get("family", "")),
		"slot_preview": resolved_preview,
	}


func _slot_environment_preview(machine: Dictionary, now_msec: int = -1) -> Dictionary:
	if now_msec < 0:
		now_msec = Time.get_ticks_msec()
	var reel_count := clampi(int(machine.get("reel_count", 3)), 1, SLOT_ENV_PREVIEW_MAX_REELS)
	var row_count := clampi(int(machine.get("row_count", 1)), 1, SLOT_ENV_PREVIEW_MAX_ROWS)
	var active_bonus: Dictionary = _slot_copy_dict(machine.get("active_bonus", {}))
	var nudge_offer: Dictionary = _slot_copy_dict(machine.get("last_nudge_offer", {}))
	var selected_bet: Dictionary = StateScript.selected_bet(machine)
	var spin_plan: Dictionary = _slot_copy_dict(machine.get("slot_animation_plan", {}))
	var autoplay_delay := _slot_autoplay_delay_msec(machine) if bool(machine.get("slot_autoplay_active", false)) else 0
	var phase := _slot_preview_phase(machine, active_bonus, nudge_offer, now_msec, autoplay_delay, spin_plan)
	var autoplay_next := maxi(0, int(machine.get("slot_autoplay_next_msec", 0)))
	var remaining := maxi(0, autoplay_next - now_msec) if autoplay_next > 0 else 0
	var elapsed := maxi(0, autoplay_delay - remaining) if autoplay_delay > 0 else 0
	var preview := {
		"schema_version": 1,
		"active": _slot_preview_active(machine, active_bonus, nudge_offer, phase),
		"phase": phase,
		"status_label": _slot_preview_status_label(phase, machine, active_bonus, nudge_offer),
		"caption": _slot_preview_caption(phase, machine, active_bonus, nudge_offer),
		"family": str(machine.get("type_id", "slot")),
		"format_id": str(machine.get("format_id", "")),
		"machine_key": str(machine.get("machine_key", "")),
		"reel_count": reel_count,
		"row_count": row_count,
		"grid": _slot_preview_grid(machine.get("last_grid", []), reel_count, row_count),
		"previous_grid": _slot_preview_grid(machine.get("last_previous_grid", []), reel_count, row_count),
		"win_cells": _slot_preview_cells(machine.get("slot_win_cells", [])),
		"win_symbol": str(machine.get("slot_win_symbol", "")),
		"win_reason": str(machine.get("slot_win_reason", "")),
		"payout": maxi(0, int(machine.get("last_payout", 0))),
		"net": int(machine.get("last_net", 0)),
		"classification": str(machine.get("last_classification", "idle")),
		"celebration_tier": str(machine.get("slot_celebration_tier", "none")),
		"spin_count": maxi(0, int(machine.get("spin_count", 0))),
		"selected_bet": int(selected_bet.get("total_credits", 2)),
		"autoplay_active": bool(machine.get("slot_autoplay_active", false)),
		"pending_feature": bool(active_bonus.get("active", false)) and not bool(active_bonus.get("complete", false)),
		"pending_feature_alert": bool(machine.get("slot_pending_feature_alert", false)),
		"autoplay_next_msec": autoplay_next,
		"autoplay_delay_msec": autoplay_delay,
		"autoplay_remaining_msec": remaining,
		"preview_elapsed_msec": elapsed,
		"spin": {
			"animation_id": str(machine.get("slot_animation_id", "")),
			"duration_msec": maxi(0, int(machine.get("slot_animation_duration_msec", 0))),
			"timeline": _slot_preview_timeline(machine.get("slot_reel_timeline", spin_plan.get("reel_timeline", []))),
		},
		"bonus": _slot_preview_bonus(machine, active_bonus),
		"nudge_chain": _slot_preview_nudge_chain(nudge_offer),
	}
	return preview


func _slot_runtime_phase(machine: Dictionary, active_bonus: Dictionary, nudge_offer: Dictionary, now_msec: int) -> String:
	if not nudge_offer.is_empty():
		return "nudge_chain" if str(nudge_offer.get("type", "")) == "coin_chain" else "nudge"
	if bool(active_bonus.get("active", false)) and not bool(active_bonus.get("complete", false)):
		return "bonus"
	var classification := str(machine.get("last_classification", "idle"))
	if bool(machine.get("slot_autoplay_active", false)):
		var animation_id := str(machine.get("slot_animation_id", ""))
		var autoplay_next := int(machine.get("slot_autoplay_next_msec", 0))
		var remaining := maxi(0, autoplay_next - now_msec) if autoplay_next > 0 else 0
		if not animation_id.is_empty() and remaining > _slot_autoplay_outcome_hold_msec(machine):
			return "spinning"
	if maxi(0, int(machine.get("last_payout", 0))) > 0:
		return "win"
	if classification == "near_miss":
		return "near_miss"
	if classification == "nudge_chain_break":
		return "miss"
	if classification == "idle":
		return "autoplay_wait" if bool(machine.get("slot_autoplay_active", false)) else "idle"
	return "autoplay_wait" if bool(machine.get("slot_autoplay_active", false)) else "loss"


func _slot_preview_phase(machine: Dictionary, active_bonus: Dictionary, nudge_offer: Dictionary, now_msec: int, autoplay_delay_msec: int = -1, spin_plan: Dictionary = {}) -> String:
	if not nudge_offer.is_empty():
		return "nudge_chain" if str(nudge_offer.get("type", "")) == "coin_chain" else "nudge"
	if bool(active_bonus.get("active", false)) and not bool(active_bonus.get("complete", false)):
		return "bonus"
	var classification := str(machine.get("last_classification", "idle"))
	if bool(machine.get("slot_autoplay_active", false)):
		var plan: Dictionary = spin_plan if not spin_plan.is_empty() else _slot_copy_dict(machine.get("slot_animation_plan", {}))
		var delay := autoplay_delay_msec if autoplay_delay_msec >= 0 else _slot_autoplay_delay_msec(machine)
		var remaining := maxi(0, int(machine.get("slot_autoplay_next_msec", 0)) - now_msec)
		var elapsed := maxi(0, delay - remaining)
		if not str(machine.get("slot_animation_id", "")).is_empty() and elapsed < _slot_spin_reveal_msec(plan):
			return "spinning"
	if maxi(0, int(machine.get("last_payout", 0))) > 0:
		return "win"
	if classification == "near_miss":
		return "near_miss"
	if classification == "nudge_chain_break":
		return "miss"
	if classification == "idle":
		return "autoplay_wait" if bool(machine.get("slot_autoplay_active", false)) else "idle"
	return "autoplay_wait" if bool(machine.get("slot_autoplay_active", false)) else "loss"


func _slot_preview_active(machine: Dictionary, active_bonus: Dictionary, nudge_offer: Dictionary, phase: String) -> bool:
	if bool(machine.get("slot_autoplay_active", false)) or not nudge_offer.is_empty():
		return true
	if bool(active_bonus.get("active", false)) and not bool(active_bonus.get("complete", false)):
		return true
	return ["spinning", "bonus", "nudge_chain"].has(phase)


func _slot_preview_status_label(phase: String, machine: Dictionary, _active_bonus: Dictionary, _nudge_offer: Dictionary) -> String:
	match phase:
		"spinning":
			return "SPIN"
		"nudge_chain", "nudge":
			return "NUDGE"
		"bonus":
			return "BONUS"
		"win":
			return "WIN"
		"near_miss":
			return "CLOSE"
		"miss":
			return "MISS"
		"autoplay_wait":
			return "AUTO" if bool(machine.get("slot_autoplay_active", false)) else ""
		_:
			return ""


func _slot_preview_caption(phase: String, machine: Dictionary, active_bonus: Dictionary, nudge_offer: Dictionary) -> String:
	match phase:
		"spinning":
			return "Reels spinning"
		"nudge_chain":
			return "Coin chain %d/%d bank $%d" % [
				int(nudge_offer.get("collected_count", 0)),
				int(nudge_offer.get("coin_count", _slot_copy_array(nudge_offer.get("coins", [])).size())),
				int(nudge_offer.get("banked_payout", 0)),
			]
		"nudge":
			return "Timed nudge ready"
		"bonus":
			return "%s %d left" % [
				str(active_bonus.get("mode", "bonus")).replace("_", " ").capitalize(),
				int(active_bonus.get("remaining_steps", active_bonus.get("remaining_spins", machine.get("free_spins", 0)))),
			]
		"win":
			return "Won $%d" % maxi(0, int(machine.get("last_payout", 0)))
		"near_miss":
			return "Near miss"
		"miss":
			return "Chain broke"
		"autoplay_wait":
			return "Autoplay waiting"
		_:
			return "Ready"


func _slot_preview_grid(value: Variant, reel_count: int, row_count: int) -> Array:
	var source: Array = _slot_copy_array(value)
	var result: Array = []
	for reel_index in range(reel_count):
		var column_source: Array = []
		if reel_index < source.size() and typeof(source[reel_index]) == TYPE_ARRAY:
			column_source = (source[reel_index] as Array)
		var column: Array = []
		for row_index in range(row_count):
			var symbol := "BLANK"
			if row_index < column_source.size():
				symbol = str(column_source[row_index])
			column.append(symbol)
		result.append(column)
	return result


func _slot_preview_cells(value: Variant) -> Array:
	var result: Array = []
	for cell_value in _slot_copy_array(value):
		var cell: Dictionary = _slot_copy_dict(cell_value)
		result.append({
			"reel": int(cell.get("reel", -1)),
			"row": int(cell.get("row", -1)),
		})
		if result.size() >= 12:
			break
	return result


func _slot_preview_timeline(value: Variant) -> Array:
	var result: Array = []
	var index := 0
	for entry_value in _slot_copy_array(value):
		var entry: Dictionary = _slot_copy_dict(entry_value)
		result.append({
			"reel": int(entry.get("reel", index)),
			"stop_msec": int(round(float(entry.get("stop_time", 0.0)) * 1000.0)),
			"settle_msec": int(round(float(entry.get("settle_end", entry.get("stop_time", 0.0))) * 1000.0)),
			"tease": bool(entry.get("tease", false)),
		})
		index += 1
		if result.size() >= SLOT_ENV_PREVIEW_MAX_REELS:
			break
	return result


func _slot_preview_bonus(machine: Dictionary, active_bonus: Dictionary) -> Dictionary:
	var active := bool(active_bonus.get("active", false)) and not bool(active_bonus.get("complete", false))
	return {
		"active": active,
		"family": str(active_bonus.get("family", machine.get("type_id", ""))),
		"mode": str(active_bonus.get("mode", "")),
		"step_index": int(active_bonus.get("step_index", 0)),
		"total_steps": int(active_bonus.get("total_steps", active_bonus.get("total_spins", 0))),
		"remaining_steps": int(active_bonus.get("remaining_steps", active_bonus.get("remaining_spins", machine.get("free_spins", 0)))),
		"feature_total": int(active_bonus.get("feature_total", active_bonus.get("pending_award", machine.get("last_bonus_total", 0)))),
		"jackpot_tier": str(active_bonus.get("jackpot_tier", "")),
		"free_spins": int(machine.get("free_spins", 0)),
	}


func _slot_preview_nudge_chain(nudge_offer: Dictionary) -> Dictionary:
	var coins: Array = []
	for coin_value in _slot_copy_array(nudge_offer.get("coins", [])):
		var coin: Dictionary = _slot_copy_dict(coin_value)
		coins.append({
			"index": int(coin.get("index", coins.size())),
			"row": int(coin.get("row", coins.size())),
			"side": str(coin.get("side", "left")),
			"collected": bool(coin.get("collected", false)),
			"ready_msec": int(coin.get("ready_msec", -1)),
		})
		if coins.size() >= SLOT_ENV_PREVIEW_MAX_ROWS:
			break
	return {
		"active": not nudge_offer.is_empty(),
		"type": str(nudge_offer.get("type", "")),
		"coin_count": int(nudge_offer.get("coin_count", coins.size())),
		"active_index": int(nudge_offer.get("active_index", 0)),
		"collected_count": int(nudge_offer.get("collected_count", 0)),
		"banked_payout": int(nudge_offer.get("banked_payout", 0)),
		"last_grade": str(nudge_offer.get("last_grade", "")),
		"last_award": int(nudge_offer.get("last_award", 0)),
		"last_spawned": bool(nudge_offer.get("last_spawned", false)),
		"coins": coins,
	}


func _slot_feature_pending(machine: Dictionary) -> bool:
	return StateScript.active_bonus_incomplete(machine)


func wager_activity_incomplete(run_state: RunState, environment: Dictionary, _ui_state: Dictionary = {}) -> bool:
	return StateScript.active_bonus_incomplete(_read_machine(environment))


func _mark_slot_feature_pending(machine: Dictionary, now_msec: int) -> Dictionary:
	var marked := machine.duplicate(true)
	marked["slot_autoplay_active"] = false
	marked["slot_autoplay_next_msec"] = 0
	marked["slot_pending_feature_alert"] = true
	marked["slot_pending_feature_alert_msec"] = maxi(0, now_msec)
	return marked


func _slot_feature_audio_cue(machine: Dictionary) -> String:
	var family := _slot_active_bonus_family(machine)
	if family == "buffalo":
		return "bonus_start_buffalo"
	if family == "pinball":
		return "bonus_start_pinball"
	return "bonus_start"


func _slot_feature_audio_volume_db(machine: Dictionary) -> float:
	return -7.0 if _slot_active_bonus_family(machine) == "pinball" else -1.0


func _arm_lucky_reel_grease(machine: Dictionary, environment: Dictionary) -> Dictionary:
	var item_state: Dictionary = _slot_copy_dict(machine.get("slot_item_state", {}))
	item_state["lucky_reel_grease_spins"] = 10
	item_state["lucky_reel_grease_target"] = 3
	item_state["lucky_reel_grease_near_misses"] = 0
	item_state["lucky_reel_grease_failed_nudge_heat_bonus"] = 14
	machine["slot_item_state"] = item_state
	_write_machine(environment, machine)
	return _slot_active_item_result(
		LUCKY_REEL_GREASE_ITEM_ID,
		"arm_lucky_reel_grease",
		"Lucky Reel Grease slicks this cabinet for ten spins. Bonuses now need a clean nudge.",
		environment,
		[LUCKY_REEL_GREASE_ITEM_ID],
		0
	)


func _load_cold_quarters(machine: Dictionary, environment: Dictionary) -> Dictionary:
	var item_state: Dictionary = _slot_copy_dict(machine.get("slot_item_state", {}))
	item_state["cold_quarters_charges"] = maxi(6, int(item_state.get("cold_quarters_charges", 0)))
	item_state["cold_quarter_heat_reduction"] = 6
	machine["slot_item_state"] = item_state
	_write_machine(environment, machine)
	return _slot_active_item_result(
		COLD_QUARTERS_ITEM_ID,
		"load_cold_quarters",
		"Six Cold Quarters are ready for nudge attempts on this cabinet.",
		environment,
		[COLD_QUARTERS_ITEM_ID],
		0
	)


func _arm_split_reel_note(machine: Dictionary, run_state: RunState, environment: Dictionary) -> Dictionary:
	var item_state: Dictionary = _slot_copy_dict(machine.get("slot_item_state", {}))
	item_state["split_reel_note_armed"] = true
	item_state["split_reel_note_perfect_msec_bonus"] = 55
	item_state["split_reel_note_close_msec_bonus"] = 90
	machine["slot_item_state"] = item_state
	_write_machine(environment, machine)
	var heat_delta := 0
	if run_state != null:
		var watch_status: Dictionary = run_state.pit_boss_watch_status(environment)
		if bool(watch_status.get("watched", false)):
			heat_delta = 6
	var message := "Split-Reel Note is tucked by the Buffalo controls for the next tease."
	if heat_delta > 0:
		message += " Staff catch the move."
	return _slot_active_item_result(
		SPLIT_REEL_NOTE_ITEM_ID,
		"arm_split_reel_note",
		message,
		environment,
		[SPLIT_REEL_NOTE_ITEM_ID],
		heat_delta
	)


func _arm_cumquat_sandwich(machine: Dictionary, environment: Dictionary) -> Dictionary:
	if not resolver.machine_has_feature_entry(machine, definition):
		return {
			"handled": true,
			"environment_changed": false,
			"message": "This cabinet has no bonus to force.",
		}
	var item_state: Dictionary = _slot_copy_dict(machine.get("slot_item_state", {}))
	if bool(item_state.get("cumquat_force_bonus_pending", false)):
		return {
			"handled": true,
			"environment_changed": false,
			"message": "A bonus is already forced on this cabinet.",
		}
	item_state["cumquat_force_bonus_pending"] = true
	item_state["cumquat_force_bonus_item_id"] = CUMQUAT_SANDWICH_ITEM_ID
	machine["slot_item_state"] = item_state
	_write_machine(environment, machine)
	return _slot_active_item_result(
		CUMQUAT_SANDWICH_ITEM_ID,
		"arm_cumquat_sandwich",
		"The next slot spin forces a bonus.",
		environment,
		[CUMQUAT_SANDWICH_ITEM_ID],
		0
	)


func _slot_active_item_result(item_id: String, action_id: String, message: String, environment: Dictionary, inventory_remove: Array, suspicion_delta: int) -> Dictionary:
	var deltas := GameModule.empty_result_deltas()
	deltas["inventory_remove"] = inventory_remove.duplicate()
	deltas["suspicion_delta"] = maxi(0, suspicion_delta)
	deltas["messages"] = [message]
	deltas["story_log"] = [{
		"type": "active_item",
		"game_id": get_id(),
		"item_id": item_id,
		"action_id": action_id,
		"inventory_remove": inventory_remove.duplicate(),
		"suspicion_delta": maxi(0, suspicion_delta),
		"environment_id": str(environment.get("id", "")),
	}]
	var result := GameModule.build_action_result({
		"ok": true,
		"type": "active_item",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": "active_item",
		"stake": 0,
		"deltas": deltas,
		"won": false,
		"environment_id": str(environment.get("id", "")),
		"message": message,
	})
	result["host_apply_result"] = true
	return {
		"handled": true,
		"environment_changed": true,
		"result": result,
		"message": message,
	}


func _ensure_machine_state(run_state: RunState, environment: Dictionary, rng: RngStream) -> Dictionary:
	var machine: Dictionary = _read_machine(environment)
	if machine.is_empty():
		var generation_rng: RngStream = rng
		if generation_rng == null and run_state != null:
			generation_rng = run_state.create_rng("slot_generate")
		if generation_rng == null:
			generation_rng = RngStream.new()
			generation_rng.configure(1)
		machine = generator.generate_machine(run_state, environment, generation_rng, definition, get_id())
		_write_machine(environment, machine, false)
	elif not _bonus_recovery_required(machine) and int(machine.get("schema_version", 0)) != StateScript.SCHEMA_VERSION:
		machine = StateScript.normalize(machine)
		_write_machine(environment, machine, false)
	return machine


func _query_machine(run_state: RunState, environment: Dictionary, rng_salt: String) -> Dictionary:
	var machine := _peek_machine(environment)
	if not machine.is_empty() and int(machine.get("schema_version", 0)) == StateScript.SCHEMA_VERSION:
		return machine
	return _ensure_machine_state(run_state, environment, run_state.create_rng(rng_salt) if run_state != null else null)


func _table_state(run_state: RunState, environment: Dictionary) -> Dictionary:
	return _ensure_machine_state(run_state, environment, run_state.create_rng("slot_authority_state") if run_state != null else null)


func _table_state_preview(_run_state: RunState, environment: Dictionary) -> Dictionary:
	return _peek_machine(environment)


func _update_environment_table(environment: Dictionary, machine: Dictionary) -> void:
	_write_owned_machine(environment, machine, false)


func _empty_slot_result(action_id: String, environment: Dictionary, text: String) -> Dictionary:
	return GameModule.build_action_result({
		"ok": false,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": "unknown",
		"stake": 0,
		"environment_id": str(environment.get("id", "")),
		"message": text,
	})


func _normalize_action(action_id: String) -> String:
	match action_id:
		"slot_spin", "spin":
			return "spin"
		"slot_nudge", "nudge":
			return "nudge"
		_:
			return action_id


func _normalize_bonus_action(action_id: String) -> String:
	match action_id:
		"launch":
			return "slot_bonus_launch"
		"left":
			return "slot_bonus_left"
		"right":
			return "slot_bonus_right"
		"power_down", "soft", "slot_bonus_soft":
			return "slot_bonus_power_down"
		"power_up", "hard", "slot_bonus_hard":
			return "slot_bonus_power_up"
		"tilt":
			return "slot_bonus_tilt"
		_:
			return action_id


func _is_pinball_direct_bonus_action(action_id: String) -> bool:
	return action_id.begins_with("slot_bonus_aim_") or action_id.begins_with("slot_bonus_start_") or action_id.begins_with("slot_bonus_power_")


func _slot_autoplay_delay_msec(machine: Dictionary) -> int:
	var plan: Dictionary = _slot_copy_dict(machine.get("slot_animation_plan", {}))
	var delay := 0
	if not StateScript.active_bonus_incomplete(machine) and not str(machine.get("slot_animation_id", "")).begins_with("bonus:") and not _slot_copy_array(plan.get("reel_timeline", [])).is_empty():
		delay = _slot_spin_reveal_msec(plan) + _slot_autoplay_outcome_hold_msec(machine)
	else:
		delay = _slot_legacy_autoplay_delay_msec(machine)
	if _slot_active_bonus_family(machine) == "buffalo" or str(machine.get("type_id", "")) == "buffalo":
		delay = mini(delay, BUFFALO_AUTOPLAY_MAX_DELAY_MSEC)
	return delay


func _slot_legacy_autoplay_delay_msec(machine: Dictionary) -> int:
	var plan: Dictionary = _slot_copy_dict(machine.get("slot_animation_plan", {}))
	var duration := maxi(0, int(machine.get("slot_animation_duration_msec", 0)))
	duration = maxi(duration, int(plan.get("duration_msec", 0)))
	duration = maxi(duration, int(plan.get("feature_duration_msec", 0)))
	duration = maxi(duration, int(plan.get("count_up_end_msec", 0)))
	duration = maxi(duration, int(plan.get("celebration_start_msec", 0)) + int(plan.get("celebration_duration_msec", 0)))
	for entry_value in _slot_copy_array(plan.get("reel_timeline", [])):
		var entry: Dictionary = _slot_copy_dict(entry_value)
		duration = maxi(duration, int(ceil(float(entry.get("settle_end", 0.0)) * 1000.0)))
	return maxi(900, duration + 120)


func _slot_spin_reveal_msec(plan: Dictionary) -> int:
	var reveal_msec := 0
	for entry_value in _slot_copy_array(plan.get("reel_timeline", [])):
		var entry: Dictionary = _slot_copy_dict(entry_value)
		reveal_msec = maxi(reveal_msec, int(ceil(float(entry.get("settle_end", entry.get("stop_time", 0.0))) * 1000.0)))
	return reveal_msec + SLOT_RESULT_REVEAL_BEAT_MSEC


func _slot_autoplay_outcome_hold_msec(machine: Dictionary) -> int:
	if int(machine.get("last_payout", 0)) > 0:
		return SLOT_AUTOPLAY_WIN_HOLD_MSEC
	if str(machine.get("last_classification", "")) == "near_miss":
		return SLOT_AUTOPLAY_WIN_HOLD_MSEC
	if str(machine.get("slot_celebration_tier", "none")) != "none":
		return SLOT_AUTOPLAY_WIN_HOLD_MSEC
	return SLOT_AUTOPLAY_LOSS_HOLD_MSEC


func _slot_autoplay_next_msec(machine: Dictionary, ui_state: Dictionary, run_state: RunState = null) -> int:
	var base_msec := _surface_timing_msec(ui_state)
	if base_msec <= 0:
		base_msec = GameModule.deterministic_time_msec(run_state, ui_state)
	return base_msec + _slot_autoplay_delay_msec(machine)


func _slot_bonus_auto_next_msec(machine: Dictionary, ui_state: Dictionary, run_state: RunState = null) -> int:
	var base_msec := _surface_timing_msec(ui_state)
	if base_msec <= 0:
		base_msec = GameModule.deterministic_time_msec(run_state, ui_state)
	return base_msec + _slot_bonus_auto_delay_msec(machine)


func _slot_bonus_auto_delay_msec(machine: Dictionary) -> int:
	return mini(BUFFALO_AUTOPLAY_MAX_DELAY_MSEC, maxi(900, _slot_autoplay_delay_msec(machine)))


func _slot_bonus_watchdog_status(machine: Dictionary, ui_state: Dictionary) -> Dictionary:
	var active: Dictionary = _slot_copy_dict(machine.get("active_bonus", {}))
	var status := {
		"eligible": false,
		"needs_seed": false,
		"due": false,
		"needs_tick": false,
	}
	if active.is_empty() or not bool(active.get("active", false)) or bool(active.get("complete", false)):
		return status
	if not _slot_bonus_has_no_live_work(active, ui_state):
		return status
	if _slot_bonus_completion_animation_pending(machine, ui_state):
		return status
	status["eligible"] = true
	# Pinball's realtime simulation can drain the final ball between player
	# actions. The zero-copy live-status check above is authoritative, so settle
	# on the next host tick instead of arming the generic stalled-bonus grace timer.
	if str(active.get("family", "")) == "pinball":
		status["due"] = true
		status["needs_tick"] = true
		return status
	var surface_time := _surface_timing_msec(ui_state)
	var since_msec := maxi(0, int(machine.get("slot_bonus_watchdog_since_msec", 0)))
	if surface_time <= 0 or since_msec <= 0 or surface_time < since_msec:
		status["needs_seed"] = true
		status["needs_tick"] = true
		return status
	if surface_time - since_msec >= SLOT_BONUS_WATCHDOG_GRACE_MSEC:
		status["due"] = true
		status["needs_tick"] = true
	return status


func _slot_bonus_has_no_live_work(active: Dictionary, ui_state: Dictionary) -> bool:
	var family := str(active.get("family", ""))
	if family == "pinball":
		var status: Dictionary = PinballFeatureScript.live_status(active)
		var active_count := maxi(0, int(status.get("active_ball_count", 0)))
		var balls_remaining := maxi(0, int(status.get("balls_remaining", active.get("remaining_steps", 0))))
		var remaining_steps := maxi(0, int(status.get("remaining_steps", balls_remaining + active_count)))
		return balls_remaining <= 0 and active_count <= 0 and remaining_steps <= 0
	if family == "buffalo":
		var mode := str(active.get("mode", ""))
		if mode == "hold_and_spin":
			var locks: Array = _slot_copy_array(active.get("locks", []))
			var max_cells := maxi(0, int(active.get("max_cells", 0)))
			return int(active.get("remaining_steps", active.get("respins_remaining", 0))) <= 0 or int(active.get("respins_remaining", active.get("remaining_steps", 0))) <= 0 or (max_cells > 0 and locks.size() >= max_cells)
		if mode == "free_games":
			return int(active.get("remaining_steps", 0)) <= 0
		if mode == "wheel":
			return not bool(active.get("trophy_pick_active", false)) and int(active.get("remaining_steps", 0)) <= 0
	return int(active.get("remaining_steps", 0)) <= 0


func _slot_bonus_completion_animation_pending(machine: Dictionary, ui_state: Dictionary) -> bool:
	if not str(machine.get("slot_animation_id", "")).begins_with("bonus:"):
		return false
	var surface_time := _surface_timing_msec(ui_state)
	if surface_time <= 0:
		return false
	var plan: Dictionary = _slot_copy_dict(machine.get("slot_animation_plan", {}))
	var duration := maxi(maxi(0, int(machine.get("slot_animation_duration_msec", 0))), int(plan.get("duration_msec", 0)))
	duration = maxi(duration, int(plan.get("feature_duration_msec", 0)))
	return surface_time <= duration


func _buffalo_bonus_auto_action(machine: Dictionary) -> String:
	var active: Dictionary = _slot_copy_dict(machine.get("active_bonus", {}))
	if active.is_empty() or not bool(active.get("active", false)) or bool(active.get("complete", false)):
		return ""
	if str(active.get("family", machine.get("type_id", ""))) != "buffalo":
		return ""
	match str(active.get("mode", "")):
		"free_games", "hold_and_spin":
			return "slot_bonus_launch"
		_:
			return ""


func _surface_timing_msec(ui_state: Dictionary) -> int:
	return maxi(0, int(ui_state.get("drunk_scaled_surface_time_msec", ui_state.get("surface_time_msec", 0))))


func _slot_active_bonus_family(machine: Dictionary) -> String:
	var active: Dictionary = _slot_copy_dict(machine.get("active_bonus", {}))
	return str(active.get("family", machine.get("type_id", "")))


func _slot_cross_game_item_effects(run_state: RunState, machine: Dictionary, is_cheat: bool) -> Dictionary:
	if run_state == null:
		return {}
	var item_state: Dictionary = _slot_copy_dict(machine.get("slot_item_state", {}))
	var effects := run_state.item_effect_totals(SLOT_LEGAL_ITEM_EFFECT_KEYS, get_family(), "legal")
	var contextual := run_state.item_effect_totals(SLOT_CONTEXTUAL_ITEM_EFFECT_KEYS, get_family(), "cheat" if is_cheat else "legal")
	for key_value in contextual.keys():
		effects[key_value] = contextual[key_value]
	effects["cheat_suspicion_delta"] = run_state.item_effect_total("cheat_suspicion_delta", get_family(), "cheat")
	for override_key in [
		"slot_cold_quarter_heat_reduction",
		"slot_split_reel_note_perfect_msec_bonus",
		"slot_split_reel_note_close_msec_bonus",
	]:
		var state_key: String = override_key.trim_prefix("slot_")
		if item_state.has(state_key):
			effects[override_key] = int(item_state.get(state_key, 0))
	return effects


func _slot_copy_array(value: Variant) -> Array:
	if typeof(value) != TYPE_ARRAY:
		return []
	return (value as Array).duplicate(true)


func _slot_copy_dict(value: Variant) -> Dictionary:
	if typeof(value) != TYPE_DICTIONARY:
		return {}
	return (value as Dictionary).duplicate(true)
