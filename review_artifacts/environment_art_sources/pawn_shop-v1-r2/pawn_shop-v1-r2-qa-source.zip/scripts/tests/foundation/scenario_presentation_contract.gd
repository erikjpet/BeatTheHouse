extends RefCounted

const ScenarioSemanticViewModelScript := preload("res://scripts/ui/scenario_semantic_view_model.gd")
const PixelSceneCanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
const ScenarioLayoutResolverScript := preload("res://scripts/core/scenario_layout_resolver.gd")
const ScenarioExtensionDispatchScript := preload("res://scripts/core/scenario_extension_dispatch.gd")
const EnvironmentInteractionViewModelScript := preload("res://scripts/ui/environment_interaction_view_model.gd")
const EnvironmentInteractionControllerScript := preload("res://scripts/ui/environment_interaction_controller.gd")

const CurrentProjectionFixtureScript := preload("res://scripts/tests/fixtures/current_projection_fixture.gd")

const BOARD_SIZE := Vector2(900.0, 430.0)
const SCENARIO_OBJECT_ID := "scenario::console:night"
const DIRECT_TOKEN := "scenario_action:7:scenario:console%3Anight:brace%3Aexit"


class ActivationCapture:
	extends RefCounted
	var object_id := ""

	func record(value: String) -> void:
		object_id = value


static func check(library: Variant, failures: Array) -> void:
	_check_composed_actions_and_geometry(library, failures)
	_check_observable_action_consequence(failures)
	_check_authored_action_observability_census(failures)
	_check_small_screen_expansion(library, failures)
	_check_renderer_failure_payload_is_empty(failures)
	_check_competing_augment_presentation(library, failures)
	_check_fail_closed_presentation(library, failures)
	_check_live_event_presentation_restoration(failures)
	_check_live_base_record_reconciliation(failures)
	_check_live_slot_variation_restoration(failures)


static func _check_live_event_presentation_restoration(failures: Array) -> void:
	var live := {
		"object_id": "event:town_rumor_staff",
		"object_type": "event",
		"visual_type": "character",
		"source_id": "town_rumor_staff",
		"label": "Word from Across Town",
		"asset_path": "res://assets/art/events/late_shift_discount.png",
		"icon_key": "conversation",
		"prop": "staff",
		"character_actor": {"name": "Staff", "role": "staff"},
		# Person events expose Talk through their sealed object action. They must
		# never restore a response token that resolves the event before TalkDock.
		"inline_actions": [],
	}
	var sealed := {
		"object_id": "event:town_rumor_staff",
		"object_type": "event",
		"source_id": "town_rumor_staff",
		"label": "Word from Across Town",
		"owner_namespace": "base",
		"stable_object_id": "event:town_rumor_staff",
		"available_actions": [{"id": "inspect_event_choices", "label": "Talk"}],
		"confirm_action_id": "inspect_event_choices",
		"focus_rect": {"x": 0.2, "y": 0.2, "w": 0.1, "h": 0.1},
	}
	var restored := _record_by_id(
		EnvironmentInteractionControllerScript.restore_live_presentation_fields([sealed], [live]),
		"event:town_rumor_staff"
	)
	var actions := _array(restored.get("inline_actions", []))
	if str(restored.get("visual_type", "")) != "character" \
			or str(restored.get("asset_path", "")) != str(live.get("asset_path", "")) \
			or not actions.is_empty():
		failures.append("Scenario finalization restored a direct Word from Across Town response instead of the conversation-first actor/icon presentation.")
	if str(restored.get("confirm_action_id", "")) != "inspect_event_choices" or str(restored.get("focus_rect", {})) != str(sealed.get("focus_rect", {})):
		failures.append("Live event presentation restoration overwrote sealed interaction authority.")


static func _check_live_slot_variation_restoration(failures: Array) -> void:
	var fixtures := [
		{"object_id": "game:slot", "identity": "em_bumper_drop", "format": "classic_3_reel", "family": "pinball", "marker": "bumpers", "reels": 3, "rows": 1},
		{"object_id": "game:slot:2", "identity": "ways", "format": "line_5x3", "family": "buffalo", "marker": "sunset", "reels": 5, "rows": 3},
		{"object_id": "game:slot:3", "identity": "full_table", "format": "video_feature", "family": "pinball", "marker": "table", "reels": 5, "rows": 3},
	]
	var canvas = PixelSceneCanvasScript.new()
	for fixture_value in fixtures:
		var fixture := _dict(fixture_value)
		var object_id := str(fixture.get("object_id", ""))
		var live_visual := {
			"machine_family": str(fixture.get("family", "")),
			"machine_format": str(fixture.get("format", "")),
			"machine_key": "%s:fixture" % str(fixture.get("format", "")),
			"cabinet_variant_id": "fixture_palette",
			"cabinet_identity": str(fixture.get("identity", "")),
			"cabinet_title": str(fixture.get("identity", "")).replace("_", " ").capitalize(),
			"cabinet_palette": {"primary": "#112233", "accent": "#44aaff"},
			"reel_count": int(fixture.get("reels", 3)),
			"row_count": int(fixture.get("rows", 1)),
			"slot_preview": {"phase": "win", "grid": [["7"]], "win_cells": [{"reel": 0, "row": 0}]},
			"private_token": "PRIVATE_SLOT_VISUAL",
		}
		var live := {
			"object_id": object_id,
			"object_type": "game",
			"source_id": "slot",
			"owner_namespace": "base",
			"stable_object_id": object_id,
			"visual_state": live_visual,
		}
		var projected := live.duplicate(true)
		projected["visual_state"] = {"role": "fixture", "state": "present", "appearance": "machine"}
		var restored_records := EnvironmentInteractionControllerScript.restore_live_presentation_fields([projected], [live])
		var restored := _dict(restored_records[0] if not restored_records.is_empty() else {})
		var restored_visual := _dict(restored.get("visual_state", {}))
		var profile := _dict(canvas.call("_slot_prop_profile", restored, Color.WHITE))
		if str(restored_visual.get("cabinet_identity", "")) != str(fixture.get("identity", "")) \
				or str(restored_visual.get("machine_format", "")) != str(fixture.get("format", "")) \
				or str(profile.get("identity", "")) != str(fixture.get("identity", "")) \
				or str(profile.get("format_id", "")) != str(fixture.get("format", "")) \
				or str(profile.get("marker", "")) != str(fixture.get("marker", "")):
			failures.append("Scenario live reconciliation replaced Slot variation %s with the generic cabinet." % object_id)
		if not restored_visual.has("slot_preview") or not restored_visual.has("role") \
				or restored_visual.has("private_token") or JSON.stringify(restored_visual).contains("PRIVATE_SLOT_VISUAL"):
			failures.append("Scenario live reconciliation did not preserve the bounded Slot preview/semantic fields for %s." % object_id)
	canvas.free()


static func _check_live_base_record_reconciliation(failures: Array) -> void:
	var phone_rect := {"x": 0.14, "y": 0.12, "w": 0.10, "h": 0.12}
	var lender_rect := {"x": 0.74, "y": 0.60, "w": 0.10, "h": 0.20}
	var make_call_id := "event_response:call_brother_in_law:make_call"
	var scenario_action_id := "scenario_action:17:scenario:wedding_phone:listen"
	var projected := [{
		"object_id": "lender:brother_in_law",
		"object_type": "lender",
		"source_id": "brother_in_law",
		"owner_namespace": "service",
		"stable_object_id": "lender:brother_in_law",
		"label": "Your Brother-in-Law",
		"visible": true,
		"interactive": true,
		"enabled": true,
		"available_actions": [{"id": "use_lender_hook", "label": "Use"}],
		"confirm_action_id": "use_lender_hook",
		"presentation_mode": "room",
		"focus_rect": lender_rect,
	}, {
		"object_id": "service:house_drink",
		"object_type": "service",
		"source_id": "house_drink",
		"owner_namespace": "service",
		"stable_object_id": "service:house_drink",
		"visible": true,
		"enabled": true,
		"available_actions": [{"id": "use_service_hook", "label": "Use"}],
	}, {
		"object_id": "event:call_brother_in_law",
		"object_type": "event",
		"source_id": "call_brother_in_law",
		"owner_namespace": "event",
		"stable_object_id": "event:call_brother_in_law",
		"label": "Counter Phone",
		"visible": false,
		"interactive": false,
		"enabled": false,
		"disabled_reason": "Stale sealed state.",
		"action_summary": "Stale sealed action.",
		"available_actions": [],
		"inline_actions": [{"id": "stale_response", "emit_object_id": "event_response:call_brother_in_law:stale_response", "label": "Stale"}, {"id": "listen", "emit_object_id": scenario_action_id, "label": "Listen"}],
		"scenario_augmented_inline_actions": [{"id": "listen", "emit_object_id": scenario_action_id, "label": "Listen"}],
		"confirm_action_id": "",
		"presentation_mode": "overflow",
		"normalized_rect": phone_rect,
		"focus_rect": phone_rect,
	}, {
		"object_id": "lender:motel_friend",
		"object_type": "lender",
		"source_id": "motel_friend",
		"owner_namespace": "service",
		"stable_object_id": "lender:motel_friend",
		"label": "Motel Friend",
		"visible": true,
		"interactive": false,
		"enabled": false,
		"disabled_reason": "Stale sealed state.",
		"available_actions": [],
		"confirm_action_id": "",
		"presentation_mode": "room",
		"normalized_rect": lender_rect,
		"focus_rect": lender_rect,
	}, {
		"object_id": "service:scenario_open_bar",
		"object_type": "service",
		"source_id": "scenario_open_bar",
		"owner_namespace": "scenario",
		"stable_object_id": "scenario_open_bar",
		"enabled": true,
		"presentation_mode": "room",
		"focus_rect": {"x": 0.42, "y": 0.40, "w": 0.12, "h": 0.14},
	}, {
		# Exact family/prefix matching prevents a malformed non-service identity from
		# being interpreted as a dynamic service tombstone.
		"object_id": "event:service_alias",
		"object_type": "service",
		"source_id": "service_alias",
		"owner_namespace": "event",
		"stable_object_id": "event:service_alias",
		"enabled": true,
		"presentation_mode": "room",
		"focus_rect": {"x": 0.58, "y": 0.40, "w": 0.10, "h": 0.12},
	}]
	var live := [{
		"object_id": "event:call_brother_in_law",
		"object_type": "event",
		"source_id": "call_brother_in_law",
		"visual_type": "event",
		"short_description": "A counter phone. Family guilt is free.",
		"visible": true,
		"interactive": true,
		"decorative": false,
		"enabled": true,
		"disabled_reason": "",
		"action_summary": "Choose a response.",
		"available_actions": [{"id": "inspect_event_choices", "label": "Review responses"}],
		"inline_actions": [{"id": "make_call", "emit_object_id": make_call_id, "label": "Make the call"}],
		"confirm_action_id": "inspect_event_choices",
		"presentation_mode": "room",
		"normalized_rect": {"x": 0.88, "y": 0.88, "w": 0.04, "h": 0.04},
		"focus_rect": {"x": 0.88, "y": 0.88, "w": 0.04, "h": 0.04},
		"runtime_state": {"private_token": "PRIVATE_PHONE_RUNTIME"},
		"visual_state": {"private_token": "PRIVATE_PHONE_VISUAL"},
		"local_state": {"traitor": "PRIVATE_TRAITOR"},
		"rigged_draw": "PRIVATE_RIGGED_DRAW",
		"unrevealed_turn": "PRIVATE_UNREVEALED_TURN",
	}, {
		"object_id": "lender:motel_friend",
		"object_type": "lender",
		"source_id": "motel_friend",
		"visual_type": "character",
		"visible": true,
		"interactive": true,
		"decorative": false,
		"enabled": true,
		"disabled_reason": "",
		"action_summary": "Double-click to use.",
		"available_actions": [{"id": "use_lender_hook", "label": "Use"}],
		"inline_actions": [],
		"confirm_action_id": "use_lender_hook",
		"presentation_mode": "overflow",
		"normalized_rect": {"x": 0.02, "y": 0.02, "w": 0.04, "h": 0.04},
		"focus_rect": {"x": 0.02, "y": 0.02, "w": 0.04, "h": 0.04},
	}]
	var restored_records := EnvironmentInteractionControllerScript.restore_live_presentation_fields(projected, live)
	if not _record_by_id(restored_records, "lender:brother_in_law").is_empty() \
			or not _record_by_id(restored_records, "service:house_drink").is_empty():
		failures.append("Scenario live reconciliation resurrected an absent dynamic service/lender from the sealed base inventory.")
	if _record_by_id(restored_records, "service:scenario_open_bar").is_empty() \
			or _record_by_id(restored_records, "event:service_alias").is_empty():
		failures.append("Scenario live reconciliation treated scenario-owned or non-prefix records as dynamic service/lender tombstones.")
	var phone := _record_by_id(restored_records, "event:call_brother_in_law")
	var phone_inline := _array(phone.get("inline_actions", []))
	if not bool(phone.get("visible", false)) or not bool(phone.get("interactive", false)) or not bool(phone.get("enabled", false)) \
			or str(phone.get("disabled_reason", "missing")) != "" \
			or str(phone.get("action_summary", "")) != "Choose a response." \
			or str(phone.get("confirm_action_id", "")) != "inspect_event_choices" \
			or str(phone.get("presentation_mode", "")) != "room" \
			or not _action_emit_ids(phone_inline).has(make_call_id) \
			or not _action_emit_ids(phone_inline).has(scenario_action_id) \
			or _action_emit_ids(phone_inline).has("event_response:call_brother_in_law:stale_response"):
		failures.append("Counter Phone did not restore its current visible, enabled, actionable room presentation while retaining its scenario augment.")
	if str(phone.get("focus_rect", {})) != str(phone_rect) \
			or str(phone.get("normalized_rect", {})) != str(phone_rect) \
			or str(phone.get("owner_namespace", "")) != "event" \
			or str(phone.get("stable_object_id", "")) != "event:call_brother_in_law":
		failures.append("Counter Phone live reconciliation overwrote sealed geometry or semantic identity.")
	var current_lender := _record_by_id(restored_records, "lender:motel_friend")
	if not bool(current_lender.get("enabled", false)) or not bool(current_lender.get("interactive", false)) \
			or str(current_lender.get("confirm_action_id", "")) != "use_lender_hook" \
			or str(current_lender.get("presentation_mode", "")) != "overflow" \
			or _array(current_lender.get("available_actions", [])).size() != 1:
		failures.append("Present live lender availability/action/presentation did not replace the stale sealed snapshot.")
	if str(current_lender.get("focus_rect", {})) != str(lender_rect) or str(current_lender.get("normalized_rect", {})) != str(lender_rect):
		failures.append("Present live lender reconciliation overwrote sealed slot geometry.")
	if JSON.stringify(restored_records).contains("PRIVATE_") \
			or phone.has("runtime_state") or phone.has("visual_state") or phone.has("local_state") \
			or phone.has("rigged_draw") or phone.has("unrevealed_turn"):
		failures.append("Live base reconciliation copied private runtime/visual/local state outside the public allowlist.")
	var canvas = PixelSceneCanvasScript.new()
	canvas.render_environment_snapshot({"id": "live_reconciliation", "archetype_id": "motel", "interactable_objects": restored_records})
	var rendered_objects := _array(canvas.current_view_snapshot().get("objects", []))
	if _record_by_id(rendered_objects, "event:call_brother_in_law").is_empty() \
			or not _record_by_id(rendered_objects, "lender:brother_in_law").is_empty():
		failures.append("Production room rendering did not show Counter Phone while omitting the unavailable Brother-in-Law lender.")
	canvas.free()


static func _check_observable_action_consequence(failures: Array) -> void:
	var canvas = PixelSceneCanvasScript.new()
	var before := _dict(canvas.call("_apply_draw_hints", {
		"visual_key": "scenario_scene service rope barrier",
		"icon_key": "room_barrier",
		"state": "intact",
		"prop": "",
	}, "scenario_object", 0))
	var after := _dict(canvas.call("_apply_draw_hints", {
		"visual_key": "scenario_scene service rope barrier",
		"icon_key": "room_barrier",
		"state": "acted_open_public_rail",
		"prop": "",
	}, "scenario_object", 0))
	if str(before.get("prop", "")) != "room_barrier" or str(after.get("prop", "")) != "room_barrier":
		failures.append("Observable-action rendering stopped preserving the authored physical object identity.")
	if str(before.get("prop_state_variant", "")).is_empty() or str(after.get("prop_state_variant", "")).is_empty() or before.get("prop_state_variant") == after.get("prop_state_variant"):
		failures.append("change_scene_object public state does not produce a distinct persistent room-prop variant.")
	var record := {
		"object_id": "scenario::public_rail",
		"object_type": "scenario_scene_object",
		"visual_type": "scenario_object",
		"owner_namespace": "scenario",
		"stable_object_id": "public_rail",
		"label": "Public observer rail",
		"icon_key": "room_barrier",
		"state": "intact",
		"visible": true,
		"enabled": true,
		"interactive": true,
		"focus_rect": {"x": 0.2, "y": 0.2, "w": 0.12, "h": 0.16},
	}
	canvas.render_environment_snapshot({"id": "observable_before", "archetype_id": "bar", "interactable_objects": [record]})
	var rendered_before := _record_by_id(_array(canvas.current_view_snapshot().get("objects", [])), "scenario::public_rail")
	record["state"] = "acted_open_public_rail"
	canvas.render_environment_snapshot({"id": "observable_after", "archetype_id": "bar", "interactable_objects": [record]})
	var rendered_after := _record_by_id(_array(canvas.current_view_snapshot().get("objects", [])), "scenario::public_rail")
	if str(rendered_before.get("prop_state_variant", "")).is_empty() or str(rendered_after.get("prop_state_variant", "")).is_empty() or rendered_before.get("prop_state_variant") == rendered_after.get("prop_state_variant"):
		failures.append("The production canvas snapshot did not consume changed public state into its room-prop variant.")
	if JSON.stringify(rendered_after).contains("local_state"):
		failures.append("Observable room-prop state exposed private scenario local_state.")
	if str(canvas.call("_public_prop_state_label", "traitor_grievance_rigged_draw_unrevealed_turn")) != "CHANGED":
		failures.append("Room-prop marker turns unapproved state tokens into visible hidden-state text.")
	if str(canvas.call("_fallback_event_prop", "scenario_scene", "", "opened exit")) != "side_door":
		failures.append("Fallback prop selection does not consume public scene-object state.")
	var expected_game_props := {
		"scratch_tickets": ["novelty", "scratch_ticket_room"],
		"pull_tabs": ["novelty", "machine"],
		"slot": ["slots", "machine"],
		"bar_dice": ["dice", "bar_dice_room"],
		"craps": ["dice", "craps_room"],
		"blackjack": ["cards", "card_table"],
		"roulette": ["wheel", "roulette_table"],
		"video_poker": ["cards", "video_poker_machine"],
		"coin_pusher": ["coin_pusher", "coin_pusher_room"],
	}
	for source_value in expected_game_props.keys():
		var source_id := str(source_value)
		var expectation := expected_game_props.get(source_value, []) as Array
		var game_hint := _dict(canvas.call("_apply_draw_hints", {
			"source_id": source_id,
			"visual_key": str(expectation[0]),
			"prop": "slot_machine" if source_id == "coin_pusher" else "",
		}, "game", 0))
		if str(game_hint.get("prop", "")) != str(expectation[1]):
			failures.append("Production room prop mapping does not distinguish game %s." % source_id)
	var street_craps_hint := _dict(canvas.call("_apply_draw_hints", {
		"source_id": "craps",
		"visual_key": "dice",
		"prop": "street_craps_circle",
		"visual_state": {"variant": "street_craps"},
	}, "game", 0))
	if str(street_craps_hint.get("prop", "")) != "street_craps_circle":
		failures.append("Street Craps reused the casino table room prop instead of its dedicated pavement circle.")
	var acknowledgement := EnvironmentInteractionViewModelScript.accepted_scenario_action_acknowledgement(
		{"label": "Public observer rail", "local_state": {"traitor": true, "grievance": 2, "rigged_draw": true, "unrevealed_turn": 7}},
		{"id": "set_local_private", "label": "Open the public rail", "handler": "set_local", "inputs": {"key": "traitor", "value": true}}
	)
	if acknowledgement != "Done at Public observer rail: Open the public rail.":
		failures.append("Accepted scenario actions do not produce an immediate label-bound acknowledgement.")
	if acknowledgement.contains("traitor") or acknowledgement.contains("grievance") or acknowledgement.contains("rigged") or acknowledgement.contains("unrevealed") or acknowledgement.contains("turn") or acknowledgement.contains("true"):
		failures.append("Scenario action acknowledgement leaked private local/action input state.")
	var next_acknowledgement := EnvironmentInteractionViewModelScript.accepted_scenario_action_acknowledgement(
		{"label": "Public observer rail"},
		{"id": "set_local_second", "label": "Close the public rail", "handler": "set_local", "inputs": {"key": "traitor", "value": false}}
	)
	if next_acknowledgement != "Done at Public observer rail: Close the public rail." or next_acknowledgement.contains("Open the public rail"):
		failures.append("Back-to-back set_local acknowledgements reused stale prior-action feedback.")
	canvas.free()


static func _check_authored_action_observability_census(failures: Array) -> void:
	var canvas = PixelSceneCanvasScript.new()
	var stats := {"handlers": 0, "set_local": 0, "player_actions": 0, "player_set_local": 0, "change_scene_object": 0}
	var signatures_by_target: Dictionary = {}
	var files := DirAccess.get_files_at("res://data/environments/scenario_sequences")
	files.sort()
	for file_value in files:
		var file_name := str(file_value)
		if not file_name.ends_with(".json"):
			continue
		var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/environments/scenario_sequences/%s" % file_name))
		if typeof(parsed) != TYPE_DICTIONARY:
			failures.append("Observable-action census could not parse scenario package %s." % file_name)
			continue
		_collect_authored_action_observability(parsed, canvas, stats, signatures_by_target, failures)
	# The original 729 measurement counts every handler-bearing definition. On
	# the exact package inventory, 673 are clickable available_actions; the
	# remaining 48 set_local and 8 publish_feedback handlers are fact
	# subscriptions and therefore have no player click to acknowledge.
	if int(stats.get("handlers", 0)) < 729:
		failures.append("Observable-action census covered only %d authored handlers; expected at least the audited 729." % int(stats.get("handlers", 0)))
	if int(stats.get("set_local", 0)) < 125:
		failures.append("Observable-action census covered only %d set_local handlers; expected at least the audited 125." % int(stats.get("set_local", 0)))
	if int(stats.get("player_actions", 0)) < 673 or int(stats.get("player_set_local", 0)) < 77:
		failures.append("Observable-action census did not cover all 673 clickable actions, including their 77 set_local choices.")
	if int(stats.get("change_scene_object", 0)) < 360:
		failures.append("Observable-action census covered only %d changed room props; expected at least the audited 360." % int(stats.get("change_scene_object", 0)))
	canvas.free()


static func _collect_authored_action_observability(value: Variant, canvas, stats: Dictionary, signatures_by_target: Dictionary, failures: Array) -> void:
	if typeof(value) == TYPE_ARRAY:
		for child_value in (value as Array):
			_collect_authored_action_observability(child_value, canvas, stats, signatures_by_target, failures)
		return
	if typeof(value) != TYPE_DICTIONARY:
		return
	var node := value as Dictionary
	var authored_handler := str(node.get("handler", ""))
	if not authored_handler.is_empty():
		stats["handlers"] = int(stats.get("handlers", 0)) + 1
		if authored_handler == "set_local":
			stats["set_local"] = int(stats.get("set_local", 0)) + 1
	if typeof(node.get("available_actions", [])) == TYPE_ARRAY:
		for action_value in (node.get("available_actions", []) as Array):
			var action := _dict(action_value)
			if action.is_empty() or str(action.get("handler", "")).is_empty():
				continue
			stats["player_actions"] = int(stats.get("player_actions", 0)) + 1
			var acknowledgement := EnvironmentInteractionViewModelScript.accepted_scenario_action_acknowledgement({}, action)
			if acknowledgement.strip_edges().is_empty():
				failures.append("Player-facing action %s has no immediate acknowledgement." % str(action.get("id", "")))
			var handler := str(action.get("handler", ""))
			if handler == "set_local":
				stats["player_set_local"] = int(stats.get("player_set_local", 0)) + 1
			if handler == "change_scene_object":
				stats["change_scene_object"] = int(stats.get("change_scene_object", 0)) + 1
				var inputs := _dict(action.get("inputs", {}))
				_record_public_state_signature(
					"%s::%s" % [str(inputs.get("owner_namespace", "")), str(inputs.get("stable_object_id", ""))],
					str(inputs.get("state", "")), canvas, signatures_by_target, failures
				)
	if str(node.get("family", "")) == "scene_ops" and str(node.get("op", "")) in ["spawn", "update"]:
		var payload := _dict(node.get("object", node.get("changes", {})))
		_record_public_state_signature(
			"%s::%s" % [str(node.get("owner_namespace", "")), str(node.get("stable_object_id", ""))],
			str(payload.get("state", "")), canvas, signatures_by_target, failures
		)
	for child_value in node.values():
		_collect_authored_action_observability(child_value, canvas, stats, signatures_by_target, failures)


static func _record_public_state_signature(target: String, public_state: String, canvas, signatures_by_target: Dictionary, failures: Array) -> void:
	if target == "::" or public_state.strip_edges().is_empty():
		return
	var signature := str(canvas.call("_public_prop_state_variant", public_state))
	var target_signatures := _dict(signatures_by_target.get(target, {}))
	if target_signatures.has(signature) and str(target_signatures.get(signature, "")) != public_state:
		failures.append("Room prop %s gives two authored public states the same rendered marker signature." % target)
	target_signatures[signature] = public_state
	signatures_by_target[target] = target_signatures


static func _check_composed_actions_and_geometry(library: Variant, failures: Array) -> void:
	var fixture := CurrentProjectionFixtureScript.physical(library)
	if not bool(fixture.get("ok", false)):
		failures.append("Current finalized projection fixture failed: %s" % JSON.stringify(fixture.get("errors", [])))
		return
	var prepared := _dict(fixture.get("renderer", {}))
	var composed := _dict(fixture.get("public", {}))
	if not bool(composed.get("ok", false)):
		failures.append("Scenario presentation fixture did not compose: %s" % JSON.stringify(composed.get("errors", [])))
		return
	var records := _array(composed.get("records", []))
	var scenario_record := _record_by_id(records, SCENARIO_OBJECT_ID)
	if scenario_record.is_empty():
		failures.append("Scenario semantic interaction did not become a player-facing room record.")
		return
	var actions := _array(scenario_record.get("inline_actions", []))
	if actions.size() != 2:
		failures.append("Scenario presentation did not preserve both authored actions.")
		return
	var first_action := _dict(actions[0])
	if str(first_action.get("emit_object_id", "")) != DIRECT_TOKEN or str(first_action.get("input_action", "")) != "confirm":
		failures.append("Scenario direct-action token/input mapping is not stable or colon-safe.")
	var physical_descriptor := ScenarioSemanticViewModelScript.action_descriptor_for_token(records, DIRECT_TOKEN)
	if _dict(physical_descriptor.get("sequence_record", {})) != scenario_record or _dict(physical_descriptor.get("sequence_action", {})) != _dict(_array(scenario_record.get("scenario_sequence_actions", []))[0]):
		failures.append("Current physical action token lost its exact sequence record/action descriptor.")
	# Keep the retained non-sequence descriptor branch as an explicit unit case;
	# this synthetic record is not a room publication or source of hit authority.
	var unit_record := {"enabled": true, "interactive": true, "inline_actions": ScenarioSemanticViewModelScript.inline_actions_for_interaction(CurrentProjectionFixtureScript.console_interaction(), 7)}
	var descriptor := ScenarioSemanticViewModelScript.action_descriptor_for_token([unit_record], DIRECT_TOKEN)
	if descriptor != {
		"owner_namespace": "scenario",
		"stable_object_id": "console:night",
		"command_id": "brace:exit",
		"idempotency_key": "ui:7:scenario:console%3Anight:brace%3Aexit",
		"action_origin_owner_namespace": "scenario",
		"action_origin_stable_object_id": "console:night",
		"action_origin_receipt_key": "",
		"action_origin_boundary_id": "",
		"action_origin_fingerprint": "",
	}:
		failures.append("Scenario direct-action token did not resolve to the exact authoritative command descriptor.")

	var canvas = PixelSceneCanvasScript.new()
	var main_loop := Engine.get_main_loop()
	if not main_loop is SceneTree:
		failures.append("Scenario presentation contract requires an active SceneTree.")
		canvas.free()
		return
	var root := (main_loop as SceneTree).root
	root.add_child(canvas)
	canvas.size = BOARD_SIZE
	canvas.render_environment_snapshot({
		"id": "presentation_fixture",
		"archetype_id": "bar",
		"display_name": "Presentation Fixture",
		"interactable_objects": records,
		"scenario_render_snapshot": prepared,
	})
	var view := _dict(canvas.current_view_snapshot())
	var objects := _array(view.get("objects", []))
	var ids := _object_ids(objects)
	if ids.find(SCENARIO_OBJECT_ID) < 0 or ids.find("travel:leave") < 0:
		failures.append("Canvas did not consume the unified scenario/base room catalog.")
	elif ids.find("scenario:stage:arrival_shift") >= 0:
		failures.append("Canvas created a renderer-only scenario stage outside the unified room catalog.")
	elif not ids.find(SCENARIO_OBJECT_ID) < ids.find("travel:leave"):
		failures.append("Canvas did not apply deterministic global scenario/base z ordering.")
	var layout_entry := _layout_by_id(_dict(view.get("object_layout", {})), SCENARIO_OBJECT_ID)
	var draw_rect := _rect(_dict(layout_entry.get("rect", {})))
	if draw_rect.size.x < 72.0 or draw_rect.size.y < 48.0:
		failures.append("Scenario visual draw geometry did not preserve the bounded semantic target.")
	elif canvas.object_id_at_local_position(draw_rect.get_center()) != SCENARIO_OBJECT_ID:
		failures.append("Scenario draw geometry and interaction hit geometry are not correlated.")
	var reachable := canvas.keyboard_reachable_object_ids()
	if reachable != [SCENARIO_OBJECT_ID, "travel:leave"]:
		failures.append("Keyboard/controller focus does not preserve authored focus_order or excludes the wrong room objects: %s" % JSON.stringify(reachable))
	if not canvas._cycle_interactive_object(1) or str(canvas.current_view_snapshot().get("selected_object_id", "")) != SCENARIO_OBJECT_ID:
		failures.append("Keyboard/controller room-object cycling cannot reach the first scenario interaction.")
	var capture := ActivationCapture.new()
	canvas.object_activated.connect(capture.record)
	var authored_event := InputEventAction.new()
	authored_event.action = "ui_down"
	authored_event.pressed = true
	canvas._gui_input(authored_event)
	if capture.object_id != "scenario_action:7:scenario:console%3Anight:refuse":
		failures.append("Authored controller input did not take precedence over room/action navigation.")

	canvas.set_small_screen_mode(true)
	var small_view := _dict(canvas.current_view_snapshot())
	var small_entry := _layout_by_id(_dict(small_view.get("object_layout", {})), SCENARIO_OBJECT_ID)
	var small_rect := _rect(_dict(small_entry.get("rect", {})))
	if small_rect.size.x < 104.0 or small_rect.size.y < 76.0:
		failures.append("Canvas did not apply authored small-screen draw geometry.")
	elif canvas.object_id_at_local_position(small_rect.get_center()) != SCENARIO_OBJECT_ID:
		failures.append("Small-screen scenario draw and hit geometry diverged.")
	root.remove_child(canvas)
	canvas.free()


static func _check_small_screen_expansion(library: Variant, failures: Array) -> void:
	var semantic := {
		"scene_objects": {"scenario::edge_exit": {
			"owner_namespace": "scenario", "stable_object_id": "edge_exit", "label": "Edge exit",
			"role": "exit", "anchor_id": "layout:game:0", "bounds": {"w": 16.0, "h": 16.0},
			"visible": true, "enabled": true,
		}},
		"interactions": {"scenario::edge_exit": {
			"owner_namespace": "scenario", "stable_object_id": "edge_exit", "mode": "add",
			"label": "Edge exit", "state_label": "Open", "prompt": "Leave through the edge exit.",
			"enabled": true, "disabled_reason": "", "available_actions": [{"id": "leave", "label": "Leave", "input_action": "ui_accept", "non_color_state": "ready"}],
			"input_actions": ["ui_accept"], "non_color_state": "open", "focus_order": 1,
			"hit_bounds": {"w": 44.0, "h": 44.0}, "min_target_size": 44.0, "safe_exit": true, "alternate_exit": false,
		}},
	}
	var prepared := ScenarioLayoutResolverScript.prepare({"layout": {"game_spots": [{"x": 890.0, "y": 420.0}]}}, {"scenario_id": "small_screen_fixture", "phase_id": "arrival", "status": "active", "semantic_state": semantic})
	if not bool(prepared.get("ok", false)):
		failures.append("Small-screen layout fixture failed resolution: %s" % JSON.stringify(prepared.get("errors", [])))
		return
	var visual := _dict(_array(prepared.get("visual_objects", []))[0])
	var normal_rect := _rect(_dict(visual.get("normalized_rect", {})))
	var expanded_rect := _rect(_dict(visual.get("small_screen_rect", {})))
	normal_rect = Rect2(normal_rect.position * BOARD_SIZE, normal_rect.size * BOARD_SIZE)
	expanded_rect = Rect2(expanded_rect.position * BOARD_SIZE, expanded_rect.size * BOARD_SIZE)
	if normal_rect.size.x >= 104.0 or normal_rect.size.y >= 76.0:
		failures.append("Small-screen fixture did not begin with an undersized semantic visual.")
	if expanded_rect.size.x < 104.0 or expanded_rect.size.y < 76.0 or not is_equal_approx(expanded_rect.end.x, BOARD_SIZE.x) or not is_equal_approx(expanded_rect.end.y, BOARD_SIZE.y):
		failures.append("Small-screen resolver did not expand and clamp the undersized edge target.")
	# Direct canvas unit: consume the exact original extension visual/expanded
	# rectangle, without recreating the removed overlay-to-room composer. This
	# synthetic hit record is not a published room or source-authority fixture.
	var extension_record := visual.duplicate(true)
	extension_record["interactive"] = true
	extension_record["decorative"] = false
	extension_record["enabled"] = true
	extension_record["available_actions"] = _array(_dict(_dict(semantic.get("interactions", {})).get("scenario::edge_exit", {})).get("available_actions", []))
	extension_record["confirm_action_id"] = "leave"
	var extension_canvas = PixelSceneCanvasScript.new()
	extension_canvas.size = BOARD_SIZE
	extension_canvas.render_environment_snapshot({"id": "small_screen_extension_unit", "archetype_id": "bar", "interactable_objects": [extension_record], "scenario_render_snapshot": prepared})
	extension_canvas.set_small_screen_mode(true)
	var extension_entry := _layout_by_id(_dict(extension_canvas.current_view_snapshot().get("object_layout", {})), "scenario:scenario:edge_exit")
	var extension_consumed := _rect(_dict(extension_entry.get("rect", {})))
	if not extension_consumed.is_equal_approx(expanded_rect) or extension_canvas.object_id_at_local_position(extension_consumed.get_center()) != "scenario:scenario:edge_exit":
		failures.append("Canvas did not consume the exact original expanded/clamped renderer-extension geometry.")
	extension_canvas.free()
	# The extension resolver above still owns expansion/clamping. The current
	# room case consumes its actual finalized slot authority rather than the old
	# independent extension-to-room composer.
	var fixture := CurrentProjectionFixtureScript.physical(library, "edge_exit")
	if not bool(fixture.get("ok", false)):
		failures.append("Current small-screen room fixture failed: %s" % JSON.stringify(fixture.get("errors", [])))
		return
	prepared = _dict(fixture.get("renderer", {}))
	var composed := _dict(fixture.get("public", {}))
	if not bool(composed.get("ok", false)):
		failures.append("Small-screen resolved presentation did not compose: %s" % JSON.stringify(composed.get("errors", [])))
		return
	var canvas = PixelSceneCanvasScript.new()
	canvas.size = BOARD_SIZE
	canvas.render_environment_snapshot({"id": "small_screen_fixture", "archetype_id": "bar", "interactable_objects": _array(composed.get("records", [])), "scenario_render_snapshot": prepared})
	canvas.set_small_screen_mode(true)
	var entry := _layout_by_id(_dict(canvas.current_view_snapshot().get("object_layout", {})), "scenario::edge_exit")
	var consumed_rect := _rect(_dict(entry.get("rect", {})))
	if consumed_rect.size.x < 104.0 or consumed_rect.size.y < 76.0 or canvas.object_id_at_local_position(consumed_rect.get_center()) != "scenario::edge_exit":
		failures.append("Canvas did not consume the resolver's expanded/clamped small-screen hit geometry.")
	var sealed := _dict(_dict(_dict(fixture.get("finalized", {})).get("layout_authority", {})).get("scenario::edge_exit", {}))
	var sealed_small := _rect(_dict(sealed.get("small_screen_rect", {})))
	sealed_small = Rect2(sealed_small.position * BOARD_SIZE, sealed_small.size * BOARD_SIZE)
	if not consumed_rect.is_equal_approx(sealed_small):
		failures.append("Current canvas small-screen hit geometry diverged from its exact finalized authority.")
	canvas.free()


static func _check_renderer_failure_payload_is_empty(failures: Array) -> void:
	var environment := {
		"id": "validation_corner_store_delivery_day",
		"layout": {"object_rects": {}},
		"semantic_anchors": {"delivery_clerk": {"position": [180.0, 180.0]}},
		"semantic_zones": {},
	}
	var projection := {
		"scenario_id": "corner_store_delivery_day",
		"phase_id": "arrival",
		"status": "active",
		"boundary_serial": 3,
		"active_stages": [{"stage_id": "HOSTILE_PUBLIC_SENTINEL"}],
		"semantic_state": {
			"scene_objects": {
				"scenario::missing_scene": {
					"owner_namespace": "scenario", "stable_object_id": "missing_scene",
					"label": "HOSTILE_PUBLIC_SENTINEL", "anchor_id": "missing_anchor",
				},
			},
			"actors": {
				"scenario::delivery_clerk": {
					"owner_namespace": "scenario", "stable_object_id": "delivery_clerk",
					"label": "Delivery clerk", "anchor_id": "delivery_clerk",
					"route_id": "delivery_clerk",
				},
			},
			"interactions": {
				"scenario::leaked_interaction": {
					"owner_namespace": "scenario", "stable_object_id": "leaked_interaction",
					"label": "HOSTILE_PUBLIC_SENTINEL", "mode": "add",
				},
			},
			"services": {"service::leaked": {"id": "HOSTILE_PUBLIC_SENTINEL"}},
			"games": {"game::leaked": {"id": "HOSTILE_PUBLIC_SENTINEL"}},
			"routes": {"base::world:leaked": {"id": "HOSTILE_PUBLIC_SENTINEL"}},
		},
	}
	var environment_fingerprint := JSON.stringify(environment)
	var projection_fingerprint := JSON.stringify(projection)
	var prepared := ScenarioLayoutResolverScript.prepare(environment, projection)
	if bool(prepared.get("ok", true)) or not _contains_text(_array(prepared.get("errors", [])), "unresolved anchor or zone") \
		or not _contains_text(_array(prepared.get("errors", [])), "unresolved route"):
		failures.append("Hostile Delivery Day renderer fixture did not preserve its typed scene/actor resolution errors.")
	for key in ["visual_objects", "interaction_overlays", "services", "games", "routes", "active_stages"]:
		if not _array(prepared.get(key, [])).is_empty():
			failures.append("Failed scenario renderer retained public %s payload." % key)
	var audit := _dict(prepared.get("layout_audit", {}))
	if int(audit.get("visual_count", -1)) != 0 or int(audit.get("interaction_count", -1)) != 0:
		failures.append("Failed scenario renderer audit reported unpublished presentation payload.")
	if str(prepared.get("scenario_id", "")) != "corner_store_delivery_day" or str(prepared.get("phase_id", "")) != "arrival" \
		or str(prepared.get("status", "")) != "active" or int(prepared.get("boundary_serial", -1)) != 3 \
		or typeof(prepared.get("errors", [])) != TYPE_ARRAY or typeof(prepared.get("warnings", [])) != TYPE_ARRAY \
		or typeof(prepared.get("layout_audit", {})) != TYPE_DICTIONARY:
		failures.append("Failed scenario renderer discarded typed diagnostics or safe snapshot metadata.")
	if JSON.stringify(prepared).contains("HOSTILE_PUBLIC_SENTINEL"):
		failures.append("Failed scenario renderer leaked rejected presentation content outside its public collections.")
	if JSON.stringify(environment) != environment_fingerprint or JSON.stringify(projection) != projection_fingerprint:
		failures.append("Failed scenario renderer mutated caller-owned environment or projection input.")
	var dispatched := ScenarioExtensionDispatchScript.prepare_render({}, environment, projection)
	if bool(dispatched.get("ok", true)) or not _contains_text(_array(dispatched.get("errors", [])), "unresolved route") \
		or _contains_text(_array(dispatched.get("errors", [])), "failure must publish no visuals or interactions"):
		failures.append("Renderer dispatch replaced the resolver's typed failure with a generic payload-impurity error.")
	for key in ["visual_objects", "interaction_overlays", "services", "games", "routes", "active_stages"]:
		if not _array(dispatched.get(key, [])).is_empty():
			failures.append("Renderer dispatch retained failed %s payload." % key)


static func _check_fail_closed_presentation(library: Variant, failures: Array) -> void:
	var fixture := CurrentProjectionFixtureScript.room(library, true)
	var enabled_fixture := CurrentProjectionFixtureScript.room(library)
	if not bool(fixture.get("ok", false)) or not bool(enabled_fixture.get("ok", false)):
		failures.append("Current fail-closed room fixture could not authenticate its base controls.")
		return
	var base := _dict(_array(enabled_fixture.get("records", []))[0])
	var augment_prepared := {
		"ok": true, "errors": [], "boundary_serial": 7, "visual_objects": [], "active_stages": [],
		"interaction_overlays": [{
			"owner_namespace": "scenario", "stable_object_id": "route_augment", "mode": "augment",
			"target_owner_namespace": "base", "target_stable_object_id": "travel:leave",
			"available_actions": [{"id": "shortcut", "label": "Take shortcut", "input_action": "ui_accept", "non_color_state": "ready"}],
		}],
	}
	var disabled_before := var_to_bytes(fixture)
	var disabled_composed := CurrentProjectionFixtureScript.reduced_projection(enabled_fixture, _array(augment_prepared.get("interaction_overlays", [])))
	var disabled_token := "scenario_action:7:scenario:route_augment:shortcut"
	var disabled_reduction := _dict(disabled_composed.get("reduction", {}))
	var disabled_public := _dict(disabled_composed.get("public", {}))
	var sealed_records := _array(disabled_public.get("records", []))
	var sealed_before := var_to_bytes(sealed_records)
	# The real room owner seals valid semantics first, then refreshes current
	# availability from its live producer. That view never rewrites the seal.
	var disabled_records := EnvironmentInteractionControllerScript.restore_live_presentation_fields(sealed_records, _array(fixture.get("records", [])))
	var disabled_result := _record_by_id(disabled_records, "travel:leave")
	var sealed_result := _record_by_id(sealed_records, "travel:leave")
	if not bool(disabled_reduction.get("ok", false)) or _array(disabled_reduction.get("accepted_overlay_source_identities", [])) != ["scenario::route_augment"] or not bool(disabled_public.get("ok", false)) or disabled_result.is_empty() or bool(disabled_result.get("enabled", true)) or disabled_result.get("owner_namespace") != sealed_result.get("owner_namespace") or disabled_result.get("stable_object_id") != sealed_result.get("stable_object_id") or var_to_bytes(disabled_result.get("focus_rect")) != var_to_bytes(sealed_result.get("focus_rect")) or var_to_bytes(sealed_records) != sealed_before or var_to_bytes(fixture) != disabled_before:
		failures.append("Disabled-host fixture did not reach the real live-availability boundary with exact sealed geometry/identity and owned inputs.")
	# Also retain the strict raw-input negative: authored actions on disabled
	# causal semantics must receive the actual typed rejection and preserve base.
	var rejected_disabled := CurrentProjectionFixtureScript.reduced_projection(fixture, _array(augment_prepared.get("interaction_overlays", [])))
	var rejected_public := _dict(rejected_disabled.get("public", {}))
	if bool(rejected_public.get("ok", true)) or not _array(rejected_public.get("errors", [])).has("Disabled scenario interaction base::travel:leave cannot retain action authority.") or var_to_bytes(rejected_public.get("records", [])) != var_to_bytes(fixture.get("records", [])) or var_to_bytes(fixture) != disabled_before:
		failures.append("Disabled causal semantics bypassed its typed layout rejection or changed the complete ordinary control/input.")
	var disabled_unit := CurrentProjectionFixtureScript.accepted_token_unit_record(_dict(disabled_composed.get("reduction", {})), _array(augment_prepared.get("interaction_overlays", [])), false)
	if not ScenarioSemanticViewModelScript.action_descriptor_for_token([disabled_unit], disabled_token).is_empty():
		failures.append("Disabled compatibility-token unit exposed its augmented action.")
	if not ScenarioSemanticViewModelScript.action_descriptor_for_token(disabled_records, disabled_token).is_empty():
		failures.append("Disabled host interaction exposed a directly routable augmented scenario action.")

	var invalid_prepared := {
		"ok": false,
		"errors": ["fixture renderer rejected"],
		"visual_objects": [{
			"object_id": "scenario:scenario:leaked",
			"object_type": "scenario_object",
			"visual_type": "scenario_object",
			"label": "Leaked visual",
			"normalized_rect": {"x": 0.4, "y": 0.4, "w": 0.1, "h": 0.1},
		}],
	}
	var composed := EnvironmentInteractionControllerScript.project_finalized_sequence_interaction_result([base], invalid_prepared)
	var records := _array(composed.get("records", []))
	var error_record := _record_by_id(records, "scenario:presentation_error")
	if bool(composed.get("ok", true)) or not _array(composed.get("errors", [])).has("fixture renderer rejected") or records != [base] or not error_record.is_empty():
		failures.append("Invalid finalized presentation did not retain its structured error and preserve the ordinary control exactly.")
	if PixelSceneCanvasScript.should_draw_hotspot_hint({"interactive": false, "enabled": false}, false):
		failures.append("Noninteractive scenario diagnostics still advertise an interaction hotspot.")
	if PixelSceneCanvasScript.should_draw_hotspot_hint({"interactive": false, "disabled": false}, false):
		failures.append("Decorative scenario staging still advertises an interaction hotspot.")

	var canvas = PixelSceneCanvasScript.new()
	canvas.size = BOARD_SIZE
	canvas.render_environment_snapshot({
		"id": "failed_presentation_fixture",
		"archetype_id": "bar",
		"interactable_objects": records,
		"scenario_render_snapshot": invalid_prepared,
	})
	var objects := _array(canvas.current_view_snapshot().get("objects", []))
	if _object_ids(objects).has("scenario:scenario:leaked"):
		failures.append("Canvas leaked scenario visuals from an invalid renderer snapshot.")
	if canvas.keyboard_reachable_object_ids().has("scenario:presentation_error"):
		failures.append("Fail-closed scenario presentation error became keyboard/controller actionable.")
	canvas.free()


static func _check_competing_augment_presentation(library: Variant, failures: Array) -> void:
	var fixture := CurrentProjectionFixtureScript.room(library)
	if not bool(fixture.get("ok", false)):
		failures.append("Current augment room fixture could not authenticate its base control.")
		return
	var base := _dict(_array(fixture.get("records", []))[0])
	var primary_action_id := str(_dict(_array(base.get("available_actions", []))[0]).get("id", ""))
	var overlays: Array = []
	for owner in ["event", "sweep", "scenario"]:
		overlays.append({
			"owner_namespace": owner,
			"stable_object_id": "%s_route_augment" % owner,
			"mode": "augment",
			"target_owner_namespace": "base",
			"target_stable_object_id": "travel:leave",
			"available_actions": [{
				"id": "%s_shortcut" % owner,
				"label": "%s shortcut" % owner.capitalize(),
				"input_action": "ui_accept",
				"non_color_state": "ready",
			}],
		})
	var prepared := {
		"ok": true, "errors": [], "boundary_serial": 7,
		"visual_objects": [], "active_stages": [], "interaction_overlays": overlays,
	}
	var composed := CurrentProjectionFixtureScript.reduced_projection(fixture, _array(prepared.get("interaction_overlays", [])))
	var record := _record_by_id(_array(composed.get("records", [])), "travel:leave")
	var public_text := JSON.stringify(record)
	if not bool(_dict(composed.get("public", {})).get("ok", false)) or _array(_dict(composed.get("reduction", {})).get("accepted_overlay_source_identities", [])) != ["sweep::sweep_route_augment"]:
		failures.append("Competing augment fixture did not reach the real reducer winner and current finalized projection.")
	var token_unit := CurrentProjectionFixtureScript.accepted_token_unit_record(_dict(composed.get("reduction", {})), overlays)
	if bool(composed.get("ok", true)) or record.is_empty():
		failures.append("Competing augment presentation did not fail closed around its retained winner.")
		return
	for forbidden_action in ["event_shortcut", "scenario_shortcut"]:
		if public_text.contains(forbidden_action):
			failures.append("Rejected lower-priority augment leaked into public action surfaces: %s." % forbidden_action)
		var token := "scenario_action:7:%s:%s_route_augment:%s" % [forbidden_action.trim_suffix("_shortcut"), forbidden_action.trim_suffix("_shortcut"), forbidden_action]
		if not ScenarioSemanticViewModelScript.action_descriptor_for_token([record], token).is_empty() or not ScenarioSemanticViewModelScript.action_descriptor_for_token([token_unit], token).is_empty():
			failures.append("Rejected lower-priority augment retained a routable action token: %s." % forbidden_action)
	var augmented_ids := CurrentProjectionFixtureScript.augmented_action_ids(record)
	var augmented_inline_ids: Array = []
	for action_value in _array(token_unit.get("inline_actions", [])):
		augmented_inline_ids.append(str(_dict(action_value).get("id", "")))
	if augmented_ids != ["sweep_shortcut"] or augmented_inline_ids != ["sweep_shortcut"]:
		failures.append("Winning sweep augment did not exclusively own available/inline public actions.")
	var sweep_token := "scenario_action:7:sweep:sweep_route_augment:sweep_shortcut"
	if ScenarioSemanticViewModelScript.action_descriptor_for_token([token_unit], sweep_token).is_empty():
		failures.append("Accepted sweep augment lost its routable action token.")
	# Tokens without a committed origin proof remain a unit-only compatibility
	# check; the current room projector must not publish that legacy dispatch.
	if not ScenarioSemanticViewModelScript.action_descriptor_for_token([record], sweep_token).is_empty():
		failures.append("Current room projection exposed an uncommitted legacy augment token.")
	for private_key in ["accepted_overlay_source_identities", "effective_priority", "effective_owner_namespace", "effective_winner", "source_key"]:
		if public_text.contains(private_key):
			failures.append("Composed interaction leaked reducer-private overlay metadata %s." % private_key)

	var collision_overlay := {
		"owner_namespace": "sweep", "stable_object_id": "collision_augment", "mode": "augment",
		"target_owner_namespace": "base", "target_stable_object_id": "travel:leave",
		"available_actions": [
			{"id": primary_action_id, "label": "Colliding activate", "input_action": "ui_accept", "non_color_state": "ready"},
			{"id": "sweep_unique", "label": "Sweep unique", "input_action": "ui_accept", "non_color_state": "ready"},
		],
	}
	var collision_prepared := prepared.duplicate(true)
	collision_prepared["interaction_overlays"] = [collision_overlay]
	var collision_composed := CurrentProjectionFixtureScript.reduced_projection(fixture, _array(collision_prepared.get("interaction_overlays", [])))
	var collision_record := _record_by_id(_array(collision_composed.get("records", [])), "travel:leave")
	var collision_text := JSON.stringify(collision_record)
	var collision_reduction := _dict(collision_composed.get("reduction", {}))
	if not _contains_text(_array(collision_reduction.get("errors", [])), "augment action id %s collides" % primary_action_id) or not _array(collision_reduction.get("accepted_overlay_source_identities", [])).is_empty() or not bool(_dict(collision_composed.get("public", {})).get("ok", false)) or collision_record.is_empty():
		failures.append("Primary-action collision fixture failed before its intended reducer collision boundary.")
	var collision_unit := CurrentProjectionFixtureScript.accepted_token_unit_record(_dict(collision_composed.get("reduction", {})), _array(collision_prepared.get("interaction_overlays", [])))
	if bool(collision_composed.get("ok", true)) \
		or collision_text.contains("sweep_unique") \
		or not CurrentProjectionFixtureScript.augmented_action_ids(collision_record).is_empty() \
		or not _array(collision_unit.get("inline_actions", [])).is_empty() \
		or not _array(collision_record.get("inline_actions", [])).is_empty() \
		or not ScenarioSemanticViewModelScript.action_descriptor_for_token([collision_record], "scenario_action:7:sweep:collision_augment:sweep_unique").is_empty():
		failures.append("Base primary-action collision leaked part of a rejected augment into public/token surfaces.")

	var equal_a := {
		"owner_namespace": "scenario", "stable_object_id": "a_equal_augment", "mode": "augment",
		"target_owner_namespace": "base", "target_stable_object_id": "travel:leave",
		"available_actions": [{"id": "duplicate_action", "label": "A duplicate", "input_action": "ui_accept", "non_color_state": "ready"}],
	}
	var equal_z := equal_a.duplicate(true)
	equal_z["stable_object_id"] = "z_equal_augment"
	equal_z["available_actions"] = [{"id": "duplicate_action", "label": "Z duplicate", "input_action": "ui_accept", "non_color_state": "ready"}]
	var equal_forward_prepared := prepared.duplicate(true)
	equal_forward_prepared["interaction_overlays"] = [equal_z, equal_a]
	var equal_reverse_prepared := prepared.duplicate(true)
	equal_reverse_prepared["interaction_overlays"] = [equal_a, equal_z]
	var equal_forward := CurrentProjectionFixtureScript.reduced_projection(fixture, _array(equal_forward_prepared.get("interaction_overlays", [])))
	var equal_reverse := CurrentProjectionFixtureScript.reduced_projection(fixture, _array(equal_reverse_prepared.get("interaction_overlays", [])))
	var equal_record := _record_by_id(_array(equal_forward.get("records", [])), "travel:leave")
	var equal_unit := CurrentProjectionFixtureScript.accepted_token_unit_record(_dict(equal_forward.get("reduction", {})), _array(equal_forward_prepared.get("interaction_overlays", [])))
	if not bool(_dict(equal_forward.get("public", {})).get("ok", false)) or not bool(_dict(equal_reverse.get("public", {})).get("ok", false)) or _array(_dict(equal_forward.get("reduction", {})).get("accepted_overlay_source_identities", [])) != ["scenario::a_equal_augment"] or _array(_dict(equal_reverse.get("reduction", {})).get("accepted_overlay_source_identities", [])) != ["scenario::a_equal_augment"]:
		failures.append("Equal-priority fixture did not reach its deterministic reducer winner/current projection.")
	var a_token := "scenario_action:7:scenario:a_equal_augment:duplicate_action"
	var z_token := "scenario_action:7:scenario:z_equal_augment:duplicate_action"
	if JSON.stringify(equal_forward) != JSON.stringify(equal_reverse) \
		or bool(equal_forward.get("ok", true)) \
		or CurrentProjectionFixtureScript.augmented_action_ids(equal_record).size() != 1 \
		or _array(equal_unit.get("inline_actions", [])).size() != 1 \
		or ScenarioSemanticViewModelScript.action_descriptor_for_token([equal_unit], a_token).is_empty() \
		or not ScenarioSemanticViewModelScript.action_descriptor_for_token([equal_unit], z_token).is_empty():
		failures.append("Same-priority duplicate augment did not preserve one deterministic inline/token winner.")


static func _record_by_id(records: Array, object_id: String) -> Dictionary:
	for record_value in records:
		var record := _dict(record_value)
		if str(record.get("object_id", record.get("id", ""))) == object_id:
			return record
	return {}


static func _action_emit_ids(actions: Array) -> Array:
	var ids: Array = []
	for action_value in actions:
		var action := _dict(action_value)
		ids.append(str(action.get("emit_object_id", action.get("id", ""))))
	return ids


static func _layout_by_id(layout: Dictionary, object_id: String) -> Dictionary:
	for entry_value in _array(layout.get("objects", [])):
		var entry := _dict(entry_value)
		if str(entry.get("id", "")) == object_id:
			return entry
	return {}


static func _object_ids(objects: Array) -> Array:
	var ids: Array = []
	for object_value in objects:
		ids.append(str(_dict(object_value).get("id", "")))
	return ids


static func _rect(value: Dictionary) -> Rect2:
	return Rect2(float(value.get("x", 0.0)), float(value.get("y", 0.0)), float(value.get("w", 0.0)), float(value.get("h", 0.0)))


static func _dict(value: Variant) -> Dictionary:
	return (value as Dictionary).duplicate(true) if typeof(value) == TYPE_DICTIONARY else {}


static func _array(value: Variant) -> Array:
	return (value as Array).duplicate(true) if typeof(value) == TYPE_ARRAY else []


static func _contains_text(values: Array, needle: String) -> bool:
	for value in values:
		if str(value).contains(needle):
			return true
	return false
