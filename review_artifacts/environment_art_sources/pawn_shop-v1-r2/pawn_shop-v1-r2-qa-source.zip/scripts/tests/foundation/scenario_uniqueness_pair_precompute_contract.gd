extends SceneTree

const ContentLibraryScript := preload("res://scripts/core/content_library.gd")
const Catalog := preload("res://scripts/core/scenario_sequence_catalog.gd")
const ScenarioEngineScript := preload("res://scripts/core/scenario_engine.gd")
const Registry := preload("res://scripts/core/scenario_operation_registry.gd")
const Schema := preload("res://scripts/core/scenario_sequence_schema.gd")

# Refreshed after the accepted integrated environment/scenario passes expanded
# the exact signatures and removed all previously recorded similarity warnings.
# JSON.stringify formats floats through the C runtime's snprintf, so its bytes
# differ between Windows and Linux. The baseline hashes a canonical form with
# every float fixed at 1e-12 resolution, which is identical on all platforms.
# Two independent full audits reproduced this refreshed authority after the
# reviewed slot/counter target inventory changes, with the same 1,485 clean
# pairs and no warnings or failures.
const PRODUCTION_AUTHORITY_SHA256 := "45446147aef3f81132a059791c5d61104c553221f397fa4c14ca00a3aff389d4"
const PRODUCTION_AUTHORITY_BYTES := 1784388
const PRODUCTION_AUTHORITY_FIXTURE_PATH := "res://scripts/tests/fixtures/scenario_uniqueness_authority_accepted_env06_7.canonical.json"
# Current authored content is pinned separately from the retained historical oracle.
const CURRENT_PRODUCTION_AUTHORITY_SHA256 := "80ec3bc73f5f2a1366cd9e756e00683aa7bf6eb1757598553044accc307f2245"
const CURRENT_PRODUCTION_AUTHORITY_BYTES := 1784784
const CURRENT_PRODUCTION_AUTHORITY_FIXTURE_PATH := "res://scripts/tests/fixtures/scenario_uniqueness_authority_current.canonical.json"
const CANONICAL_FLOAT_SCALE := 1000000000000.0


static func canonical_authority_text(value: Variant) -> String:
	return JSON.stringify(_canonical_authority_value(value))


static func _canonical_authority_value(value: Variant) -> Variant:
	match typeof(value):
		TYPE_FLOAT:
			return int(roundf(float(value) * CANONICAL_FLOAT_SCALE))
		TYPE_ARRAY:
			var items: Array = []
			for item in value as Array:
				items.append(_canonical_authority_value(item))
			return items
		TYPE_DICTIONARY:
			var fields: Dictionary = {}
			for key in (value as Dictionary).keys():
				fields[key] = _canonical_authority_value((value as Dictionary).get(key))
			return fields
	return value


func _init() -> void:
	var failures: Array[String] = []
	var started_usec := Time.get_ticks_usec()
	var library = ContentLibraryScript.new()
	library.load(true)
	var elapsed_ms := float(Time.get_ticks_usec() - started_usec) / 1000.0
	var authority: Dictionary = library.scenario_sequence_catalog.get("uniqueness_audit", {})
	var authority_json := JSON.stringify(authority)
	var canonical_json := canonical_authority_text(authority)
	check_authority_fixtures(canonical_json, failures)
	_check_authority_fixture_refusals(failures)
	if canonical_json.sha256_text() != CURRENT_PRODUCTION_AUTHORITY_SHA256 or canonical_json.to_utf8_buffer().size() != CURRENT_PRODUCTION_AUTHORITY_BYTES:
		failures.append("Optimized production authority JSON differs from the exact current authored baseline: sha256=%s bytes=%d expected_sha256=%s expected_bytes=%d." % [canonical_json.sha256_text(), canonical_json.to_utf8_buffer().size(), CURRENT_PRODUCTION_AUTHORITY_SHA256, CURRENT_PRODUCTION_AUTHORITY_BYTES])
	if (authority.get("pairs", []) as Array).size() != 1485 or not (authority.get("failures", []) as Array).is_empty() or not (authority.get("warnings", []) as Array).is_empty():
		failures.append("Optimized production authority shape/findings differ from the exact accepted ENV-06.7 baseline.")
	var audit_inputs := _production_audit_inputs(library)
	var definitions: Array = audit_inputs.get("definitions", [])
	var target_inventories: Dictionary = audit_inputs.get("target_inventories", {})
	var masked_visual_explanations: Dictionary = audit_inputs.get("masked_visual_explanations", {})
	var full_started_usec := Time.get_ticks_usec()
	var full_report := Schema.catalog_uniqueness_report(definitions, definitions.size(), Registry, masked_visual_explanations, target_inventories)
	var full_elapsed_ms := float(Time.get_ticks_usec() - full_started_usec) / 1000.0
	if JSON.stringify(full_report) != authority_json:
		failures.append("Same-call receipt audit differs from the unchanged full-validation audit.")
	if definitions.size() != 55:
		failures.append("Production receipt proof must bind all 55 sequence definitions.")
	elif not definitions.is_empty():
		var registry_context_fingerprint := ScenarioEngineScript._sequence_validation_registry_context_fingerprint()
		var receipts: Array = []
		for definition_value in definitions:
			var production_definition: Dictionary = definition_value
			var production_id := str(production_definition.get("id", ""))
			receipts.append(ScenarioEngineScript._sequence_validation_receipt(production_definition, target_inventories.get(production_id, {}), registry_context_fingerprint))
		if not ScenarioEngineScript._sequence_validation_receipts_match(definitions, 55, target_inventories, receipts, registry_context_fingerprint):
			failures.append("Fresh exact 55-definition receipt set was not accepted.")
		var first_definition: Dictionary = definitions[0]
		var first_id := str(first_definition.get("id", ""))
		var hostile_definitions := definitions.duplicate(true)
		var hostile_definition: Dictionary = hostile_definitions[0]
		hostile_definition["display_name"] = "%s hostile stale receipt" % str(hostile_definition.get("display_name", ""))
		hostile_definitions[0] = hostile_definition
		if ScenarioEngineScript._sequence_validation_receipts_match(hostile_definitions, 55, target_inventories, receipts, registry_context_fingerprint):
			failures.append("A stale same-id definition receipt bypassed full validation fallback.")
		var hostile_target_inventories := target_inventories.duplicate(true)
		var hostile_target: Dictionary = hostile_target_inventories.get(first_id, {}).duplicate(true)
		hostile_target["hostile_unvalidated_target"] = true
		hostile_target_inventories[first_id] = hostile_target
		if ScenarioEngineScript._sequence_validation_receipts_match(definitions, 55, hostile_target_inventories, receipts, registry_context_fingerprint):
			failures.append("A stale target-inventory receipt bypassed full validation fallback.")
		var missing_receipts := receipts.duplicate(true)
		missing_receipts.pop_back()
		if ScenarioEngineScript._sequence_validation_receipts_match(definitions, 55, target_inventories, missing_receipts, registry_context_fingerprint):
			failures.append("A missing validation receipt bypassed full validation fallback.")
		var forged_receipts := receipts.duplicate(true)
		var forged_receipt: Dictionary = forged_receipts[0]
		forged_receipt["receipt_fingerprint"] = "0".repeat(64)
		forged_receipts[0] = forged_receipt
		if ScenarioEngineScript._sequence_validation_receipts_match(definitions, 55, target_inventories, forged_receipts, registry_context_fingerprint):
			failures.append("A forged validation receipt bypassed full validation fallback.")
	var threshold_band: Dictionary = Schema.uniqueness_band(0.820)
	var equal_band: Dictionary = Schema.uniqueness_band(0.0, true)
	if str(threshold_band.get("status", "")) != "fail" or str(threshold_band.get("severity", "")) != "P1" or not bool(threshold_band.get("blocking", false)):
		failures.append("The 0.820 P1 similarity threshold changed.")
	if str(equal_band.get("status", "")) != "equal_hash_hard_fail" or str(equal_band.get("severity", "")) != "P1" or not bool(equal_band.get("blocking", false)):
		failures.append("The equal-hash P1 threshold changed.")
	var signatures := [
		{},
		{"phases": [{"ops": ["scene:add", "actor:spawn"], "terminal": false}], "objectives": ["command", "fact"], "reentry": {"partial": "resume"}},
		{"phases": [{"ops": ["scene:add", "actor:spawn"], "terminal": true}], "objectives": ["command", "fact"], "reentry": {"partial": "resume"}},
		{"phases": [{"ops": ["service:add", "route:unlock"], "terminal": false}], "objectives": ["world_boundary"], "expiry": {"boundary": "night_end"}},
	]
	var tokens: Array = []
	var canonical_texts: Array = []
	for signature_value in signatures:
		var signature: Dictionary = signature_value
		tokens.append(Schema._signature_tokens(signature))
		canonical_texts.append(JSON.stringify(Schema._canonical_variant(signature)))
	var old_report: Array = []
	var new_report: Array = []
	for left_index in range(signatures.size()):
		for right_index in range(left_index + 1, signatures.size()):
			var left: Dictionary = signatures[left_index]
			var right: Dictionary = signatures[right_index]
			var old_similarity := _legacy_similarity(left, right)
			var old_equal := JSON.stringify(Schema._canonical_variant(left)) == JSON.stringify(Schema._canonical_variant(right))
			var new_similarity := Schema._signature_similarity_from_tokens(tokens[left_index], tokens[right_index])
			var new_equal := str(canonical_texts[left_index]) == str(canonical_texts[right_index])
			old_report.append(_pair_row(left_index, right_index, old_similarity, old_equal))
			new_report.append(_pair_row(left_index, right_index, new_similarity, new_equal))
	if JSON.stringify(old_report) != JSON.stringify(new_report):
		failures.append("Precomputed signature pair report differs from the legacy per-pair report: old=%s new=%s" % [JSON.stringify(old_report), JSON.stringify(new_report)])
	if failures.is_empty():
		print("SCENARIO_UNIQUENESS_PAIR_PRECOMPUTE PASS production_pairs=1485 production_failures=0 production_warnings=0 representative_pairs=6 receipt_load_ms=%.1f full_audit_ms=%.1f" % [elapsed_ms, full_elapsed_ms])
		quit(0)
		return
	for failure in failures:
		push_error(failure)
	quit(1)


func _production_audit_inputs(library: Variant) -> Dictionary:
	var definitions: Array = []
	var target_inventories: Dictionary = {}
	var masked_visual_explanations: Dictionary = {}
	for archetype_key_value in library.environment_scenarios.keys():
		var pool_value: Variant = library.environment_scenarios.get(archetype_key_value)
		if typeof(pool_value) != TYPE_ARRAY:
			continue
		for scenario_value in pool_value as Array:
			if typeof(scenario_value) != TYPE_DICTIONARY:
				continue
			var definition: Dictionary = Catalog.apply_overlay(scenario_value as Dictionary, library.scenario_sequence_catalog)
			if not definition.has("sequence"):
				continue
			definitions.append(definition.duplicate(true))
			var scenario_id := str(definition.get("id", ""))
			var target_catalog: Dictionary = library.scenario_target_catalog(definition)
			if not target_catalog.is_empty() and (target_catalog.get("errors", []) as Array).is_empty():
				var target_inventory: Dictionary = (target_catalog.get("guaranteed", {}) as Dictionary).duplicate(true)
				target_inventory["event_choices"] = target_catalog.get("event_choices", {}) as Dictionary
				target_inventories[scenario_id] = target_inventory
			var authored: Dictionary = definition.get("sequence_authoring", {})
			var authored_explanations: Dictionary = authored.get("masked_visual_explanations", {})
			for pair_key_value in authored_explanations.keys():
				masked_visual_explanations[str(pair_key_value)] = (authored_explanations.get(pair_key_value, {}) as Dictionary).duplicate(true)
	return {
		"definitions": definitions,
		"target_inventories": target_inventories,
		"masked_visual_explanations": masked_visual_explanations,
	}


func _legacy_similarity(left: Dictionary, right: Dictionary) -> float:
	var left_tokens: Dictionary = Schema._signature_tokens(left)
	var right_tokens: Dictionary = Schema._signature_tokens(right)
	if left_tokens.is_empty() and right_tokens.is_empty():
		return 1.0
	var union: Dictionary = left_tokens.duplicate(true)
	var intersection := 0
	for token_value in right_tokens.keys():
		var token := str(token_value)
		if left_tokens.has(token):
			intersection += 1
		union[token] = true
	return float(intersection) / float(maxi(1, union.size()))


func _pair_row(left_index: int, right_index: int, similarity: float, equal_hash: bool) -> Dictionary:
	var band: Dictionary = Schema.uniqueness_band(similarity, equal_hash)
	return {
		"left": left_index,
		"right": right_index,
		"similarity": similarity,
		"equal_normalized_hash": equal_hash,
		"status": str(band.get("status", "")),
		"severity": str(band.get("severity", "")),
		"blocking": bool(band.get("blocking", false)),
	}


# Test-only references: read exact native-qualified canonical bytes, without
# reserializing JSON, regenerating an oracle or rerunning another catalog audit.
static func check_authority_fixtures(canonical_json: String, failures: Array[String]) -> void:
	_read_authority_fixture(PRODUCTION_AUTHORITY_FIXTURE_PATH, PRODUCTION_AUTHORITY_SHA256, PRODUCTION_AUTHORITY_BYTES, failures)
	var current_fixture := _read_authority_fixture(CURRENT_PRODUCTION_AUTHORITY_FIXTURE_PATH, CURRENT_PRODUCTION_AUTHORITY_SHA256, CURRENT_PRODUCTION_AUTHORITY_BYTES, failures)
	if canonical_json != current_fixture:
		failures.append("Complete current production authority text differs from its exact canonical fixture.")


static func _read_authority_fixture(path: String, expected_sha256: String, expected_bytes: int, failures: Array[String]) -> String:
	if not FileAccess.file_exists(path):
		failures.append("Authority canonical fixture is missing: %s." % path)
		return ""
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		failures.append("Authority canonical fixture could not be opened: %s." % path)
		return ""
	if file.get_length() != expected_bytes:
		file.close()
		failures.append("Authority canonical fixture byte length differs: %s." % path)
		return ""
	var fixture_bytes := file.get_buffer(expected_bytes)
	var read_error := file.get_error()
	file.close()
	if read_error != OK or fixture_bytes.size() != expected_bytes:
		failures.append("Authority canonical fixture read was incomplete: %s." % path)
		return ""
	var fixture_text := fixture_bytes.get_string_from_utf8()
	if fixture_text.to_utf8_buffer() != fixture_bytes or fixture_text.sha256_text() != expected_sha256:
		failures.append("Authority canonical fixture exact UTF-8 bytes/hash differ: %s." % path)
		return ""
	return fixture_text


static func _check_authority_fixture_refusals(failures: Array[String]) -> void:
	# These exercise absence, length and digest refusal without editing a fixture.
	var missing_errors: Array[String] = []
	var missing_text := _read_authority_fixture(PRODUCTION_AUTHORITY_FIXTURE_PATH + ".missing", PRODUCTION_AUTHORITY_SHA256, PRODUCTION_AUTHORITY_BYTES, missing_errors)
	if not missing_text.is_empty() or missing_errors.is_empty():
		failures.append("Authority fixture reader accepted a missing reference.")
	var length_errors: Array[String] = []
	var wrong_length_text := _read_authority_fixture(CURRENT_PRODUCTION_AUTHORITY_FIXTURE_PATH, CURRENT_PRODUCTION_AUTHORITY_SHA256, CURRENT_PRODUCTION_AUTHORITY_BYTES - 1, length_errors)
	if not wrong_length_text.is_empty() or length_errors.is_empty():
		failures.append("Authority fixture reader accepted a wrong byte length.")
	var digest_errors: Array[String] = []
	var wrong_digest_text := _read_authority_fixture(CURRENT_PRODUCTION_AUTHORITY_FIXTURE_PATH, "0".repeat(64), CURRENT_PRODUCTION_AUTHORITY_BYTES, digest_errors)
	if not wrong_digest_text.is_empty() or digest_errors.is_empty():
		failures.append("Authority fixture reader accepted a correct-length reference with a wrong digest.")
