class_name CrewHeistContract
extends RefCounted

const RunStateScript := preload("res://scripts/core/run_state.gd")
const CrewStateModelScript := preload("res://scripts/core/crew_state_model.gd")
const CrewHeistModelScript := preload("res://scripts/core/crew_heist_model.gd")
const RunReportViewModelScript := preload("res://scripts/ui/run_report_view_model.gd")
const EventModuleScript := preload("res://scripts/core/event_module.gd")
const GameModuleScript := preload("res://scripts/core/game_module.gd")
const RunGeneratorScript := preload("res://scripts/core/run_generator.gd")
const DeliveryRunModelScript := preload("res://scripts/core/delivery_run_model.gd")
const HarnessProductionFidelityScript := preload("res://scripts/tests/foundation/harness_production_fidelity.gd")
const FoundationMainScript := preload("res://scripts/ui/foundation_main.gd")
const BlackjackActionAuthorityScript := preload("res://scripts/core/blackjack_action_authority.gd")


static func check(_library: ContentLibrary, failures: Array) -> void:
	failures.append_array(CrewHeistModelScript.validate_content())
	if _array(CrewHeistModelScript.plan("the_count").get("architects", [])) != ["crew_bishop"] or _array(CrewHeistModelScript.plan("the_whale_game").get("architects", [])) != ["crew_velvet", "crew_mags"]:
		failures.append("The crew06_9 seam lost its exact plan architect arrays.")
	_check_gating(_library, failures)
	_check_production_paths(_library, failures)
	_check_plan_a(_library, failures)
	_check_abort_and_save(_library, failures)
	_check_seam_regressions(failures)
	_check_determinism(_library, failures)


static func _check_gating(library: ContentLibrary, failures: Array) -> void:
	var hidden := _run("HEIST-GATE-HIDDEN", {})
	var hidden_status := hidden.crew_heist_planning_status()
	var hidden_count := _dict(_rows(hidden).get("the_count", {}))
	if not bool(hidden_status.get("visible", false)) or bool(hidden_count.get("live", true)) \
		or not _strings(hidden_count.get("missing_stars", [])).has("No audit on the books this season."):
		failures.append("The release planning table did not expose a truthful locked Count row before Audit knowledge.")
	var count := _run("HEIST-GATE-COUNT", {"audit_night": true})
	_set_inner(count, "crew_bishop")
	var count_rows := _rows(count)
	if not bool(_dict(count_rows.get("the_count", {})).get("live", false)) or bool(_dict(count_rows.get("the_whale_game", {})).get("live", false)):
		failures.append("Plan A gating did not require Audit Night plus Bishop alone.")
	var whale := _run("HEIST-GATE-WHALE", {"heist_plan_b_criteria": true})
	_set_inner(whale, "crew_velvet")
	var whale_rows := _rows(whale)
	if whale_rows.has("the_whale_game") or bool(_dict(whale_rows.get("the_count", {})).get("live", false)):
		failures.append("The unreleased Whale plan leaked into the public planning table.")
	var missing := _run("HEIST-GATE-MISSING", {})
	_set_inner(missing, "crew_bishop")
	var missing_row := _dict(_rows(missing).get("the_count", {}))
	if bool(missing_row.get("live", true)) or not _strings(missing_row.get("missing_stars", [])).has("No audit on the books this season."):
		failures.append("Planning table did not tell the truth about the missing Audit Night star.")
	var gala := _run("HEIST-GATE-GALA", {"gala_night": true})
	_set_inner(gala, "crew_velvet")
	if _rows(gala).has("the_whale_game"):
		failures.append("Gala Night exposed the unreleased Whale plan on the public planning table.")
	_check_audit_knowledge_gating(library, failures)
	var direct := _run("HEIST-DIRECT-REJECT", {"audit_night": true})
	_set_inner(direct, "crew_bishop")
	var direct_before := JSON.stringify(direct.to_dict())
	if bool(direct.crew_heist_lock("the_count").get("ok", false)) or bool(direct.world_sequence_schedule_heist_mount("lock").get("ok", false)) or JSON.stringify(direct.to_dict()) != direct_before:
		failures.append("A caller without the private heist host capability mutated lock or W1 registration state.")
	var forged := {"ok": true, "type": "event", "event_id": "crew_planning_table", "choice_id": "lock_the_count", "deltas": {"event_hooks": [{"type": "crew_heist", "action": "lock", "plan_id": "the_count", "signed": true}]}}
	direct.current_environment["event_ids"] = ["crew_planning_table"]
	if bool(direct.crew_record_heist_event_result(forged).get("ok", false)) or not direct.crew_heist_state.is_empty():
		failures.append("A substituted or self-asserted resolved heist hook crossed the exact Event host boundary.")


static func _check_audit_knowledge_gating(library: ContentLibrary, failures: Array) -> void:
	const KNOWLEDGE_FLAG := "crew_heist_count_audit_roster_read"
	var seeded_only := _run("HEIST-AUDIT-SEEDED-ONLY", {})
	_set_inner(seeded_only, "crew_bishop")
	seeded_only.seed_scenario_for_node("grand_casino", library.scenario("grand_casino_audit_night"))
	if bool(_dict(_rows(seeded_only).get("the_count", {})).get("live", false)):
		failures.append("An unvisited seeded Audit leaked private scenario selection into The Count gate.")

	var hostile := _run("HEIST-AUDIT-HOSTILE", {})
	_set_inner(hostile, "crew_bishop")
	hostile.narrative_flags[KNOWLEDGE_FLAG] = true
	hostile.story_flags[KNOWLEDGE_FLAG] = "true"
	_set_grand_situation(hostile, "grand_casino_convention_crowd", {"audit_night": "true"})
	if bool(_dict(_rows(hostile).get("the_count", {})).get("live", false)):
		failures.append("A non-Audit situation or malformed/forged knowledge unlocked The Count.")

	var declined := _run("HEIST-AUDIT-DECLINED", {})
	_set_inner(declined, "crew_bishop")
	_set_grand_situation(declined, "grand_casino_audit_night", {"audit_night": true}, ["scenario_audit_roster"])
	if not bool(_dict(_rows(declined).get("the_count", {})).get("live", false)):
		failures.append("The currently active Audit did not make The Count live.")
	var decline_result := _event_choice(declined, library, "scenario_audit_roster", "leave_the_count_clean")
	if not bool(decline_result.get("ok", false)) or bool(declined.story_flags.get(KNOWLEDGE_FLAG, false)):
		failures.append("Leaving the Audit roster either failed or incorrectly taught lasting Count knowledge.")
	_set_grand_situation(declined, "grand_casino_convention_crowd", {})
	if bool(_dict(_rows(declined).get("the_count", {})).get("live", false)):
		failures.append("The Count remained live after an unobserved Audit rolled over to Convention.")

	var observed := _run("HEIST-AUDIT-OBSERVED", {})
	_set_inner(observed, "crew_bishop")
	_set_grand_situation(observed, "grand_casino_audit_night", {"audit_night": true}, ["scenario_audit_roster"])
	var heat_before_read := observed.suspicion_level()
	var read_result := _event_choice(observed, library, "scenario_audit_roster", "read_the_shift")
	if not bool(read_result.get("ok", false)) or str(read_result.get("choice_id", "")) != "read_the_shift" \
			or observed.suspicion_level() != heat_before_read + 3 \
			or not _array(observed.current_environment.get("resolved_event_ids", [])).has("scenario_audit_roster") \
			or not bool(observed.story_flags.get(KNOWLEDGE_FLAG, false)) \
			or not bool(observed.narrative_flags.get(KNOWLEDGE_FLAG, false)):
		failures.append("Resolving the real Audit roster/read_the_shift choice did not teach the public Count fact.")
	var heat_after_read := observed.suspicion_level()
	if bool(_event_choice(observed, library, "scenario_audit_roster", "read_the_shift").get("ok", false)) \
			or observed.suspicion_level() != heat_after_read:
		failures.append("The resolved Audit roster replayed or charged its Heat twice.")
	_set_grand_situation(observed, "grand_casino_convention_crowd", {})
	if not bool(_dict(_rows(observed).get("the_count", {})).get("live", false)):
		failures.append("Learned Audit knowledge did not survive a Convention rollover/revisit.")

	var restored := RunStateScript.new()
	restored.from_dict(observed.to_save_snapshot())
	if not bool(restored.story_flags.get(KNOWLEDGE_FLAG, false)) \
			or not bool(restored.narrative_flags.get(KNOWLEDGE_FLAG, false)) \
			or str(restored.current_environment.get("scenario_id", "")) != "grand_casino_convention_crowd" \
			or not bool(_dict(_rows(restored).get("the_count", {})).get("live", false)):
		failures.append("Learned Audit knowledge did not survive Save/Continue restore.")


static func _check_production_paths(library: ContentLibrary, failures: Array) -> void:
	var count := _run("HEIST-PRODUCTION-COUNT", {"audit_night": true})
	for node_value in _array(count.world_map.get("nodes", [])):
		var node := _dict(node_value)
		if str(node.get("archetype_id", "")) in [RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID, RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID, RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID]:
			failures.append("The production-shaped heist fixture exposed a map-hidden Grand Casino room as a world node.")
	_set_inner(count, "crew_bishop")
	var planning := EventModuleScript.new()
	planning.setup(library.event("crew_planning_table"), library)
	var planning_ids: Array = []
	for choice_value in planning.choices(count, count.current_environment):
		planning_ids.append(str(_dict(choice_value).get("id", "")))
	if not planning_ids.has("lock_the_count") or not bool(planning.resolve(count, count.current_environment, "lock_the_count").get("ok", false)) or str(count.crew_heist_snapshot().get("plan_id", "")) != "the_count":
		failures.append("The production planning-table EventModule path did not lock Plan A.")
		return
	# The shared result contract also carries early legal actions.  Without a
	# shipped blackjack settlement payload they must not count at all.
	GameModuleScript.apply_result(count, GameModuleScript.build_action_result({"ok": true, "type": "game_action", "source_id": "blackjack", "game_id": "blackjack", "action_id": "hit", "action_kind": "legal", "stake": 12, "bankroll_delta": 0, "deltas": {"bankroll_delta": 0, "suspicion_delta": 0}, "environment_archetype_id": "grand_casino"}))
	var count_setup := _dict(count.crew_heist_snapshot().get("setup", {}))
	if not bool(count_setup.get("identity", false)) or int(count_setup.get("identity_sessions", 0)) != 0:
		failures.append("The release Count route reintroduced a separate identity-session grind.")
	# Start through the planning event, then travel through RunGenerator and use
	# the production in-room handoff API; no test mutates current_node_id here.
	if not bool(planning.resolve(count, count.current_environment, "count_schedule").get("ok", false)):
		failures.append("Planning-table schedule action did not start the production hold.")
	else:
		var restored_count := RunStateScript.new()
		restored_count.from_dict(count.to_dict())
		count = restored_count
		var generator := RunGeneratorScript.new(library)
		var schedule_targets := _array(count.delivery_snapshot().get("targets", []))
		if schedule_targets.size() != 1 or str(_dict(schedule_targets[0]).get("node_id", "")) != RunState.GRAND_CASINO_ARCHETYPE_ID:
			failures.append("The Count schedule did not target the canonical Grand Casino world node.")
		var arrived := HarnessProductionFidelityScript.travel_and_finalize(generator, count, RunState.GRAND_CASINO_ARCHETYPE_ID, true, library, failures, "Crew heist schedule Grand Casino arrival")
		if not bool(arrived.get("ok", false)):
			return
		var street_arrival := count.delivery_resolve_travel_arrival()
		if not bool(street_arrival.get("ok", false)):
			failures.append("The Count schedule did not accept its authoritative Grand Casino street arrival.")
			return
		count.advance_environment_turns(1)
		if int(count.delivery_snapshot().get("hold_progress", -1)) != 0 or bool(_dict(count.crew_heist_snapshot().get("setup", {})).get("schedule", false)):
			failures.append("The Count schedule advanced on Grand Casino Main instead of requiring the Cage.")
		var model_before := JSON.stringify(count.active_delivery_run)
		var missing_room_attempt := DeliveryRunModelScript.apply_host_action(
			count.active_delivery_run,
			"wait",
			"heist_schedule_missing_room",
			count._delivery_host_context(count.current_world_node_id(), "", "", "", "", "", "wait")
		)
		if JSON.stringify(missing_room_attempt) != model_before:
			failures.append("The room-constrained hold model failed open when host room authority was omitted.")
		var wrong_room_before := JSON.stringify(count.to_dict())
		if bool(count.delivery_apply_physical_action("wait", "heist_schedule_wrong_room").get("ok", false)) or JSON.stringify(count.to_dict()) != wrong_room_before:
			failures.append("The Count schedule accepted or mutated on a stale Main-floor hold action.")
		if not _enter_grand_room(count, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID, library, failures, "Crew heist schedule Cage arrival"):
			return
		var room_before := JSON.stringify(count.to_dict())
		var forged_room_arrival := count.delivery_resolve_travel_arrival()
		if bool(forged_room_arrival.get("ok", false)) or JSON.stringify(count.to_dict()) != room_before:
			failures.append("The Count Cage door accepted or mutated an empty forged arrival route.")
			return
		var room_arrival := count.delivery_resolve_travel_arrival(_grand_room_route(RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID))
		if not bool(room_arrival.get("ok", false)) or not bool(room_arrival.get("room_transition", false)) or JSON.stringify(count.to_dict()) != room_before:
			failures.append("The Count Cage door was not an exact no-op for the canonical street route.")
			return
		if not bool(count.delivery_apply_physical_action("wait", "heist_schedule_cage_1").get("ok", false)):
			failures.append("The Count schedule did not accept its one authored Cage hold action.")
	if not bool(_dict(count.crew_heist_snapshot().get("setup", {})).get("schedule", false)):
		failures.append("Canonical Grand travel plus the real Cage room did not complete the production schedule hold.")
	var public_text := JSON.stringify({"save": count.to_dict(), "choices": count.crew_heist_table_choices(), "story": count.story_log}).to_lower()
	for forbidden in ["traitor", "no_turn", "nobody turns", "traitor_resolution"]:
		if public_text.find(forbidden) != -1:
			failures.append("Hidden crew06_9 state leaked through a save, planning choice, or story log.")


static func _check_plan_a(library: ContentLibrary, failures: Array) -> void:
	var run := _run("HEIST-A-E2E", {"audit_night": true})
	_set_inner(run, "crew_bishop")
	if not bool(_event_choice(run, library, "crew_planning_table", "lock_the_count").get("ok", false)):
		failures.append("Plan A could not lock from its truthful live gate.")
		return
	if _dict(run.crew_heist_snapshot().get("r", {})) != {"v": 1, "s": "0"}:
		failures.append("Plan lock did not write the neutral crew06_9 handoff seam.")
	if not bool(_event_choice(run, library, "crew_planning_table", "count_schedule").get("ok", false)):
		failures.append("Plan A schedule did not start a real delivery hold.")
	else:
		_move(run, RunState.GRAND_CASINO_ARCHETYPE_ID, library, failures)
		if not bool(run.delivery_resolve_travel_arrival().get("ok", false)):
			failures.append("Plan A schedule did not cross the real Grand Casino street route.")
		if not _enter_grand_room(run, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID, library, failures, "Plan A schedule Cage"):
			return
		run.delivery_resolve_travel_arrival(_grand_room_route(RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID))
		run.delivery_apply_physical_action("wait", "plan_a_schedule_cage_1")
		run.call("_crew_heist_boundary_sync")
	if not bool(_dict(run.crew_heist_snapshot().get("setup", {})).get("schedule", false)):
		failures.append("Plan A schedule hold did not complete inside the real Cage room.")
	# The shortened release route chains its already-carried cart directly from
	# the authenticated Cage hold into the same-node Grand Main handoff.
	var chained_cart := run.delivery_snapshot()
	var chained_cart_physical := _dict(chained_cart.get("physical", {}))
	if str(chained_cart.get("run_id", "")) != "heist:the_count:swap_cart" or str(chained_cart_physical.get("cargo_state", "")) != "carried":
		failures.append("Plan A schedule completion did not chain its carried swap cart.")
	else:
		var cart_room_before := JSON.stringify(run.to_dict())
		var direct_cart_attempt := DeliveryRunModelScript.complete_handoff(run.active_delivery_run, run.current_world_node_id(), RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID)
		if JSON.stringify(direct_cart_attempt) != JSON.stringify(run.active_delivery_run) or not run.delivery_arrival_interaction().is_empty() \
				or bool(run.delivery_complete_handoff().get("ok", false)) or JSON.stringify(run.to_dict()) != cart_room_before:
			failures.append("Plan A swap cart could be handed off in the Cage instead of Grand Casino Main.")
		if not _enter_grand_room(run, RunState.GRAND_CASINO_ARCHETYPE_ID, library, failures, "Plan A swap-cart Main handoff"):
			return
		var cart_room_arrival := run.delivery_resolve_travel_arrival(_grand_room_route(RunState.GRAND_CASINO_ARCHETYPE_ID))
		if not bool(cart_room_arrival.get("ok", false)) or run.delivery_arrival_interaction().is_empty() or not bool(run.delivery_complete_handoff().get("ok", false)):
			failures.append("Plan A swap cart did not expose and complete its authenticated Main-floor handoff.")
	if not bool(_dict(run.crew_heist_snapshot().get("setup", {})).get("swap_cart", false)):
		failures.append("Plan A swap cart did not complete through the real-map handoff.")
	run.narrative_flags["debt_court_settlement"] = true
	run.crew_trust_by_member["crew_knuckles"] = CrewStateModelScript.rank_threshold("associate")
	run.call("_crew_heist_boundary_sync")
	if str(run.crew_heist_snapshot().get("status", "")) != CrewHeistModelScript.STATUS_PLAY:
		failures.append("Plan A did not chain into the Play after all mandatory setup.")
		return
	_move(run, "grand_casino", library, failures)
	if not _array(run.current_environment.get("event_ids", [])).has("heist_live_table"):
		failures.append("Plan A did not mount its production crew event at the designated table.")
	var live_table_row := _manifest_row(run.current_environment, "event:heist_live_table")
	var live_table_binding := _dict(_dict(_dict(run.current_environment.get("layout", {})).get("slot_bindings", {})).get("event:heist_live_table", {}))
	if str(live_table_row.get("family", "")) != "scenario" \
			or str(live_table_row.get("placement_class", "")) != "floor_fixture" \
			or str(live_table_row.get("spot_field", "")) != "runtime_object_manifest_entries" \
			or str(live_table_binding.get("slot_family", "")) != "scenario" \
			or not str(live_table_binding.get("slot_id", "")).begins_with("scenario.floor_fixture_"):
		failures.append("Plan A's production Live Table did not mount through its trusted scenario-family floor-fixture projection.")
	var live_table := EventModuleScript.new()
	live_table.setup(library.event("heist_live_table"), library)
	# The release route mounts the Live Table directly on its first decision.
	# Settled hands advance the later beats; an extra fixture turn here expires
	# go_hold before the player can make the opening choice.
	var mid_window := RunStateScript.new()
	mid_window.from_dict(run.to_dict())
	if JSON.stringify(mid_window.crew_heist_snapshot()) != JSON.stringify(run.crew_heist_snapshot()):
		failures.append("Plan A save/load changed the live action-boundary window.")
	var restored_live_table_row := _manifest_row(mid_window.current_environment, "event:heist_live_table")
	var restored_live_table_binding := _dict(_dict(_dict(mid_window.current_environment.get("layout", {})).get("slot_bindings", {})).get("event:heist_live_table", {}))
	if str(restored_live_table_row.get("family", "")) != "scenario" \
			or str(restored_live_table_row.get("spot_field", "")) != "runtime_object_manifest_entries" \
			or str(restored_live_table_binding.get("slot_family", "")) != "scenario":
		failures.append("Plan A save/load did not rebuild the trusted Live Table physical projection.")
	HarnessProductionFidelityScript.finalize_arrival(mid_window, library, failures, "Plan A restored live-table window")
	# If a presentation refresh invalidates only the derived proof, the durable
	# room event order must reconstruct the same immutable seal. The Grand room's
	# authored event order is intentionally non-alphabetical, while the Crew Live
	# Table is a post-seal runtime event that must remain outside that proof.
	var invalidated_live_table := RunStateScript.new()
	invalidated_live_table.from_dict(mid_window.to_dict())
	var invalidated_expected_digest := str(invalidated_live_table.current_environment.get("scenario_semantic_digest", ""))
	var invalidated_event_choice_order := _dict(_dict(_dict(invalidated_live_table.current_environment.get("scenario_sequence_state", {})).get("semantic_state", {})).get("event_choices", {})).keys()
	var invalidated_routes := _array(invalidated_live_table.current_environment.get("next_archetypes", []))
	for route_id in ["jazz_club", "small_underground_casino"]:
		if not invalidated_routes.has(route_id):
			invalidated_routes.append(route_id)
	invalidated_live_table.current_environment["next_archetypes"] = invalidated_routes
	for key in ["scenario_semantic_ready", "scenario_semantic_inventory", "scenario_base_interactions", "scenario_base_actors", "scenario_base_producer_context", "scenario_semantic_action_digest", "scenario_layout_base_records", "scenario_layout_context", "scenario_layout_authority", "scenario_layout_audit", "scenario_layout_authority_digest", "scenario_render_snapshot", "scenario_sequence_projection"]:
		invalidated_live_table.current_environment.erase(key)
	invalidated_live_table.current_environment["scenario_restore_pending_trusted_rebuild"] = true
	var invalidated_rebuild := invalidated_live_table.scenario_finalize_installed_environment(library)
	if not bool(invalidated_rebuild.get("ok", false)) \
			or str(invalidated_live_table.current_environment.get("scenario_semantic_digest", "")) != invalidated_expected_digest \
			or not invalidated_live_table._scenario_semantic_ready() \
			or _dict(_dict(_dict(invalidated_live_table.current_environment.get("scenario_sequence_state", {})).get("semantic_state", {})).get("event_choices", {})).keys() != invalidated_event_choice_order:
		failures.append("Plan A's invalidated save-shaped Live Table window could not reconstruct its original scenario seal: %s" % JSON.stringify(invalidated_rebuild.get("errors", [])))
	# Event resolution owns the same trusted repair. A player can return from a
	# sealed Blackjack action (or resume a save) and immediately answer Bishop;
	# that public choice must not strand behind renderer-owned proof.
	var pending_live_table := RunStateScript.new()
	pending_live_table.from_dict(mid_window.to_dict())
	if pending_live_table._scenario_semantic_ready():
		failures.append("Plan A's save-shaped Live Table fixture did not begin with trusted scenario rebuild pending.")
	else:
		var pending_choice := live_table.resolve(pending_live_table, pending_live_table.current_environment, "go_hold")
		if not bool(pending_choice.get("ok", false)) or not pending_live_table._scenario_semantic_ready():
			failures.append("Plan A's first post-restore Live Table choice did not rebuild and retain trusted scenario semantics: %s" % str(pending_choice.get("message", "")))
	if _choice_ids(live_table.choices(run, run.current_environment)).has("distraction_sit"):
		failures.append("Plan A allowed its second decision before the first live-table round boundary.")
	var expected_choices := [["go_hold", "distraction_sit"], ["distraction_sit", "exit_dock"], ["exit_dock", "begin_getaway"]]
	for round_index in range(3):
		var before_ids := _choice_ids(live_table.choices(run, run.current_environment))
		if not before_ids.has(str(expected_choices[round_index][0])) or before_ids.has(str(expected_choices[round_index][1])):
			failures.append("Plan A live-table beat %d was early, missing, or front-loaded." % round_index)
		var decision_choice := str(expected_choices[round_index][0])
		if not bool(live_table.resolve(run, run.current_environment, decision_choice).get("ok", false)):
			failures.append("Plan A production crew event rejected %s." % decision_choice)
		HarnessProductionFidelityScript.finalize_arrival(run, library, failures, "Plan A live-table beat %d" % round_index)
		_apply_authoritative_blackjack(run, library, 12)
	if int(_dict(run.crew_heist_snapshot().get("play", {})).get("round", 0)) != 3:
		failures.append("Plan A real settled hands did not interleave all three crew beats.")
	var corridor := RunStateScript.new()
	corridor.from_dict(run.to_dict())
	HarnessProductionFidelityScript.finalize_arrival(corridor, library, failures, "Plan A restored corridor route")
	corridor.crew_heist_state["play"]["decisions"]["exit"] = "corridor"
	var missing_delta := RunStateScript.new()
	missing_delta.from_dict(corridor.to_dict())
	HarnessProductionFidelityScript.finalize_arrival(missing_delta, library, failures, "Plan A missing-Delta route")
	var missing_delta_map := missing_delta.world_map.duplicate(true)
	var remaining_nodes: Array = []
	for node_value in _array(missing_delta_map.get("nodes", [])):
		if str(_dict(node_value).get("id", "")) != "delta_queen":
			remaining_nodes.append(node_value)
	var remaining_edges: Array = []
	for edge_value in _array(missing_delta_map.get("edges", [])):
		var edge := _dict(edge_value)
		if str(edge.get("a", "")) != "delta_queen" and str(edge.get("b", "")) != "delta_queen":
			remaining_edges.append(edge_value)
	missing_delta_map["nodes"] = remaining_nodes
	missing_delta_map["edges"] = remaining_edges
	missing_delta.set_world_map(missing_delta_map)
	var missing_delta_before := JSON.stringify(missing_delta.to_dict())
	if bool(_event_choice(missing_delta, library, "heist_live_table", "begin_getaway").get("ok", false)) \
			or JSON.stringify(missing_delta.to_dict()) != missing_delta_before:
		failures.append("Plan A getaway did not fail closed and preserve state without its canonical Delta Queen endpoint.")
	var corridor_started := _event_choice(corridor, library, "heist_live_table", "begin_getaway")
	var corridor_targets := _array(corridor.delivery_snapshot().get("targets", []))
	var corridor_getaway := _dict(corridor.crew_heist_snapshot().get("getaway", {}))
	if not bool(corridor_started.get("ok", false)) or int(corridor.delivery_snapshot().get("pursuit_pressure", -1)) != 1 \
			or str(corridor_getaway.get("exit", "")) != "corridor" or str(corridor_getaway.get("target_node_id", "")) != "delta_queen" \
			or corridor_targets.size() != 1 or str(_dict(corridor_targets[0]).get("node_id", "")) != "delta_queen":
		failures.append("Plan A slow/quiet corridor route did not target the canonical Delta Queen getaway with its distinct pressure-1 contract.")
	else:
		_move(corridor, "delta_queen", library, failures)
		corridor.delivery_resolve_travel_arrival()
		if corridor.run_status != RunState.RUN_STATUS_ENDED or str(corridor.crew_heist_snapshot().get("outcome", "")) != "clean_sweep":
			failures.append("Plan A slow/quiet corridor route did not resolve through the real Delta Queen arrival to Act 1 victory.")
	if not bool(live_table.resolve(run, run.current_environment, "begin_getaway").get("ok", false)) or str(run.delivery_snapshot().get("mode", "")) != "getaway":
		failures.append("Plan A did not enter the real getaway mode.")
		return
	if int(run.delivery_snapshot().get("pursuit_pressure", -1)) != 4 or str(_dict(run.crew_heist_snapshot().get("getaway", {})).get("exit", "")) != "dock":
		failures.append("Plan A fast/loud dock route lost its historical pressure-4 contract.")
	_move(run, "delta_queen", library, failures)
	run.delivery_resolve_travel_arrival()
	if run.run_status != RunState.RUN_STATUS_ENDED or str(run.crew_heist_snapshot().get("outcome", "")) != "clean_sweep" or run.bankroll < 1000:
		failures.append("Plan A clean route did not produce its deterministic flat payout and Act 1 victory.")
	var no_guard := _run("HEIST-A-NO-GUARD", {"audit_night": true})
	_set_inner(no_guard, "crew_bishop")
	_event_choice(no_guard, library, "crew_planning_table", "lock_the_count")
	var no_guard_state := no_guard.crew_heist_snapshot()
	no_guard_state["setup"] = {"identity": true, "schedule": true, "swap_cart": true}
	no_guard.crew_heist_state = no_guard_state
	_event_choice(no_guard, library, "crew_planning_table", "begin_play")
	_move(no_guard, "grand_casino", library, failures)
	no_guard.crew_heist_state["play"]["round"] = 2
	no_guard.crew_heist_state["play"]["decisions"] = {"go": "hold", "distraction": "sit"}
	var no_guard_live := EventModuleScript.new()
	no_guard_live.setup(library.event("heist_live_table"), library)
	if _choice_ids(no_guard_live.choices(no_guard, no_guard.current_environment)).has("exit_corridor") or not bool(no_guard_live.resolve(no_guard, no_guard.current_environment, "exit_dock").get("ok", false)):
		failures.append("Plan A exit availability did not derive from the optional Debt Court guard setup.")
	var late := RunStateScript.new()
	late.from_dict(mid_window.to_dict())
	HarnessProductionFidelityScript.finalize_arrival(late, library, failures, "Plan A restored late window")
	late.advance_environment_turns(10)
	var late_play := _dict(late.crew_heist_snapshot().get("play", {}))
	if not bool(late_play.get("late", false)) or not bool(late_play.get("corridor_blown", false)) or int(late_play.get("score", 100)) >= 100:
		failures.append("Plan A idle actions did not expire and degrade the deterministic live window.")
	var left := RunStateScript.new()
	left.from_dict(mid_window.to_dict())
	_move(left, "delta_queen", library, failures)
	left.advance_environment_turns(1)
	if not bool(_dict(left.crew_heist_snapshot().get("play", {})).get("left_table", false)) or _array(left.current_environment.get("event_ids", [])).has("heist_live_table"):
		failures.append("Leaving Plan A's live session did not record its boundary-driven consequence.")
	var blown := RunStateScript.new()
	blown.from_dict(mid_window.to_dict())
	HarnessProductionFidelityScript.finalize_arrival(blown, library, failures, "Plan A restored heat-spike window")
	blown.crew_heist_state["play"]["round"] = 2
	blown.crew_heist_state["play"]["decisions"] = {"go": "hold", "distraction": "sit", "exit": "corridor"}
	# Authoritative game settlement is covered above; isolate the host-owned
	# heist reducer here to prove the documented heat-spike branch.
	blown.crew_heist_play_round({"game_id": "blackjack", "bet": 12, "heat_delta": 15}, blown.get("_crew_heist_host_capability"))
	var blown_started := _event_choice(blown, library, "heist_live_table", "begin_getaway")
	if not bool(blown_started.get("ok", false)) or str(_dict(blown.crew_heist_snapshot().get("getaway", {})).get("exit", "")) != "dock":
		failures.append("A Plan A heat spike did not blow the corridor and force the dock.")
	if CrewHeistModelScript.ladder(65, true) != "out_hot" or CrewHeistModelScript.ladder(90, false) != "out_hot" or CrewHeistModelScript.ladder(50, false) != "somebody_got_pinched":
		failures.append("Plan A ladder fixtures lost their clean/hot/pinched bands.")


static func _check_plan_b(library: ContentLibrary, failures: Array) -> void:
	var run := _run("HEIST-B-E2E", {"heist_plan_b_criteria": true})
	_set_inner(run, "crew_velvet")
	if not bool(_event_choice(run, library, "crew_planning_table", "lock_the_whale_game").get("ok", false)):
		failures.append("Plan B could not lock from its truthful live gate.")
		return
	_prepare_whale_setup(run, library)
	for source in ["practice_rig", "street_craps"]:
		var source_run := _run("HEIST-B-RIG-%s" % source, {"heist_plan_b_criteria": true})
		_set_inner(source_run, "crew_velvet")
		_event_choice(source_run, library, "crew_planning_table", "lock_the_whale_game")
		source_run.add_item("false_bottom_cup")
		source_run.narrative_flags["craps_setting_trained"] = true
		source_run.crew_heist_table_choices()
		if not bool(_dict(source_run.crew_heist_snapshot().get("setup", {})).get("rig", false)):
			failures.append("Plan B rig rejected the %s training source." % source)
	run.add_item("false_bottom_cup")
	run.narrative_flags["craps_setting_trained"] = true
	run.crew_heist_table_choices()
	if not bool(_event_choice(run, library, "crew_planning_table", "begin_play").get("ok", false)):
		failures.append("Plan B did not seed Lucky's drunk and enter the invitational.")
		return
	_move(run, RunState.GRAND_CASINO_ARCHETYPE_ID, library, failures)
	if not _enter_grand_room(run, RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID, library, failures, "Plan B High-Limit invitational"):
		return
	run.current_environment["crew_presence"] = [{"member_id": "crew_velvet", "rank": "inner_circle"}]
	run.current_environment["active_game_id"] = "craps"
	var invitational_start := RunStateScript.new()
	invitational_start.from_dict(run.to_dict())
	var craps_caught := RunStateScript.new()
	craps_caught.from_dict(invitational_start.to_dict())
	GameModuleScript.apply_result(craps_caught, _cheating_settled_game_result("craps", 42, -20, "grand_casino_high_limit"))
	if not bool(_dict(craps_caught.crew_heist_snapshot().get("play", {})).get("made", false)):
		failures.append("A production-shaped caught Craps cheat remained clean in the invitational.")
	var blackjack_caught := RunStateScript.new()
	blackjack_caught.from_dict(invitational_start.to_dict())
	GameModuleScript.apply_result(blackjack_caught, _settled_game_result("craps", 42, 0, "grand_casino_high_limit"))
	_apply_authoritative_blackjack_cheat(blackjack_caught, library, 42)
	var blackjack_play := _dict(blackjack_caught.crew_heist_snapshot().get("play", {}))
	var caught_pending := _dict(_dict(blackjack_play.get("pending_game_facts", {})).get("blackjack", {}))
	if int(blackjack_play.get("round", 0)) != 1 or not bool(blackjack_play.get("made", false)) or not bool(caught_pending.get("dishonest", false)):
		failures.append("Authenticated caught Blackjack cheat did not mark the name and retain its nonterminal pending fact.")
	var peek_then_settle := RunStateScript.new()
	peek_then_settle.from_dict(invitational_start.to_dict())
	GameModuleScript.apply_result(peek_then_settle, _settled_game_result("craps", 42, 0, "grand_casino_high_limit"))
	var peek_result := _apply_authoritative_blackjack_cheat(peek_then_settle, library, 42, true)
	var peek_play := _dict(peek_then_settle.crew_heist_snapshot().get("play", {}))
	var peek_caught := bool(peek_result.get("blackjack_cheat_caught", false)) or str(peek_result.get("skill_outcome", "")) == "caught"
	if int(peek_play.get("round", 0)) != 1 or bool(peek_play.get("made", false)) != peek_caught:
		failures.append("An authenticated nonterminal Blackjack peek did not preserve its caught/clean fact without advancing the round.")
	_apply_authoritative_blackjack(peek_then_settle, library, 42)
	peek_play = _dict(peek_then_settle.crew_heist_snapshot().get("play", {}))
	if _array(peek_play.get("hazards", [])).is_empty() or bool(_dict(_array(peek_play.get("hazards", []))[-1]).get("honest", true)):
		failures.append("A later legal Blackjack settlement lost or double-penalized its pending dishonest/made fact.")
	var baccarat_caught := RunStateScript.new()
	baccarat_caught.from_dict(invitational_start.to_dict())
	for game_id in ["craps", "blackjack", "craps"]:
		if game_id == "blackjack": _apply_authoritative_blackjack(baccarat_caught, library, 42)
		else: GameModuleScript.apply_result(baccarat_caught, _settled_game_result(game_id, 42, 0, "grand_casino_high_limit"))
	GameModuleScript.apply_result(baccarat_caught, _cheating_settled_game_result("baccarat", 42, -20, "grand_casino_high_limit"))
	var baccarat_play := _dict(baccarat_caught.crew_heist_snapshot().get("play", {}))
	if not bool(baccarat_play.get("made", false)) or bool(_dict(_array(baccarat_play.get("hazards", []))[-1]).get("honest", true)):
		failures.append("Production Baccarat edge-sort/blown fields did not fail the honesty hazard and mark the name.")
	var edge_then_settle := RunStateScript.new()
	edge_then_settle.from_dict(invitational_start.to_dict())
	for game_id in ["craps", "blackjack", "craps"]:
		if game_id == "blackjack": _apply_authoritative_blackjack(edge_then_settle, library, 42)
		else: GameModuleScript.apply_result(edge_then_settle, _settled_game_result(game_id, 42, 0, "grand_casino_high_limit"))
	GameModuleScript.apply_result(edge_then_settle, _nonterminal_cheat_result("baccarat", "grand_casino_high_limit", false))
	if int(_dict(edge_then_settle.crew_heist_snapshot().get("play", {})).get("round", 0)) != 3:
		failures.append("A nonterminal Baccarat Edge Sort action advanced the invitational round.")
	GameModuleScript.apply_result(edge_then_settle, _settled_game_result("baccarat", 42, 0, "grand_casino_high_limit"))
	if bool(_dict(_array(_dict(edge_then_settle.crew_heist_snapshot().get("play", {})).get("hazards", []))[-1]).get("honest", true)):
		failures.append("A later legal Baccarat hand forgot its pending Edge Sort dishonesty.")
	_apply_authoritative_blackjack(run, library, 42)
	if int(_dict(run.crew_heist_snapshot().get("play", {})).get("round", 0)) != 0:
		failures.append("Plan B advanced on the wrong game before the required craps opener.")
	var sequence := ["craps", "blackjack", "craps", "baccarat", "blackjack"]
	for round_index in range(1, 6):
		var round_game := str(sequence[round_index - 1])
		# The fixture crosses physical tables. Mirror the production selection
		# boundary before asking for a table-bound coordinated play.
		run.current_environment["active_game_id"] = round_game
		var lifeline_result := run.crew_play_activate("distraction", "craps", run.current_environment) if round_index == 3 else {"ok": true}
		if round_index == 3 and not bool(lifeline_result.get("ok", false)):
			failures.append("Plan B could not activate its real coordinated-play lifeline.")
		if round_game == "blackjack": _apply_authoritative_blackjack(run, library, 42)
		else: GameModuleScript.apply_result(run, _settled_game_result(round_game, 42, 40, "grand_casino_high_limit"))
		if int(_dict(run.crew_heist_snapshot().get("play", {})).get("round", 0)) != round_index:
			failures.append("Plan B rejected the real %s result at invitational round %d." % [sequence[round_index - 1], round_index])
	if _array(_dict(run.crew_heist_snapshot().get("play", {})).get("lifelines_used", [])).size() != 1:
		failures.append("Plan B did not consume exactly one real coordinated-play activation as a finite lifeline.")
	if _array(_dict(run.crew_heist_snapshot().get("play", {})).get("hazards", [])).size() != 2:
		failures.append("Plan B did not record both counter-rig hazard rounds.")
	# The Blackjack legs are deliberately resolved by the real seeded game and
	# may win or lose. The invariant is that the visible heist pot stays identical
	# to the authoritative casino-chip account, not that a fixture forces profit.
	if int(_dict(run.crew_heist_snapshot().get("play", {})).get("pot", 0)) != run.grand_casino_chips or run.grand_casino_chips <= 0:
		failures.append("Plan B mixed results diverged from the authoritative Grand Casino chip pot.")
	var loser := RunStateScript.new()
	loser.from_dict(invitational_start.to_dict())
	for round_index in range(1, 6):
		var loss_game := str(sequence[round_index - 1])
		if loss_game == "blackjack": _apply_authoritative_blackjack(loser, library, 42)
		else: GameModuleScript.apply_result(loser, _settled_game_result(loss_game, 42, -220, "grand_casino_high_limit"))
	var loser_play := _dict(loser.crew_heist_snapshot().get("play", {}))
	if loser.grand_casino_chips != 0 or int(loser_play.get("pot", -1)) != 0 or not bool(loser_play.get("bust", false)):
		failures.append("Plan B's real losing mixed sequence did not bust the authoritative chip pot.")
	var attention := RunStateScript.new()
	attention.from_dict(invitational_start.to_dict())
	attention.add_suspicion("fixture_rourke_attention", 100, "fixture", true)
	attention.evaluate_immediate_terminal_state()
	if attention.run_status != RunState.RUN_STATUS_ACTIVE or attention.suspicion_level() != 99 or not bool(_dict(attention.crew_heist_snapshot().get("play", {})).get("made", false)):
		failures.append("Grand Casino 100 heat bypassed the Whale Game's Rourke-attention made semantics.")
	var hot := RunStateScript.new()
	hot.from_dict(run.to_dict())
	hot.crew_heist_state["play"]["score"] = 70
	var live_table := EventModuleScript.new()
	live_table.setup(library.event("heist_live_table"), library)
	if not bool(live_table.resolve(hot, hot.current_environment, "begin_interview").get("ok", false)) or bool(hot.crew_heist_begin_getaway().get("ok", false)) or not bool(live_table.resolve(hot, hot.current_environment, "interview_cut_short").get("ok", false)) or int(hot.delivery_snapshot().get("pursuit_pressure", 0)) != 3 or not bool(_dict(hot.crew_heist_snapshot().get("getaway", {})).get("chase", false)):
		failures.append("Plan B hot front-door path did not turn into its authored chase.")
	if not bool(live_table.resolve(run, run.current_environment, "begin_interview").get("ok", false)) or bool(run.crew_heist_begin_getaway().get("ok", false)) or not bool(live_table.resolve(run, run.current_environment, "interview_show_receipt").get("ok", false)):
		failures.append("Plan B did not begin its front-door getaway.")
		return
	if int(run.delivery_snapshot().get("pursuit_pressure", -1)) != 0 or bool(_dict(run.crew_heist_snapshot().get("getaway", {})).get("chase", true)):
		failures.append("Plan B clean front-door walk incorrectly began as a chase.")
	run.advance_environment_turns(2)
	if int(run.delivery_snapshot().get("pursuit_pressure", -1)) != 0 or str(run.delivery_snapshot().get("status", "")) != "active":
		failures.append("Plan B clean front-door walk silently became a chase across ordinary boundaries.")
	_move(run, "small_underground_casino", library, failures)
	run.delivery_resolve_travel_arrival()
	if _array(run.current_environment.get("event_ids", [])).has("heist_live_table") or bool(run.narrative_flags.get("heist_live_table_active", true)):
		failures.append("The transient heist live-table event survived getaway completion.")
	var seam := run.act_two_seam_payload()
	if str(seam.get("victory_route", "")) != "crew_heist" or int(seam.get("schema_version", 0)) != 2 or str(_dict(seam.get("route_payload", {})).get("hook", "")) != "town_remembers":
		failures.append("Plan B victory did not write the schema-v2 crew_heist town_remembers seam.")
	var report := RunReportViewModelScript.build(run.to_dict(), {"outcomes": RunReportViewModelScript.load_outcome_registry()})
	if str(_dict(report.get("outcome", {})).get("key", "")) != "heist_clean_sweep":
		failures.append("The victory report did not preserve the heist outcome rung.")
	if CrewHeistModelScript.ladder(90, true, true, false) != "out_hot" or CrewHeistModelScript.ladder(90, true, false, true) != "out_hot" or CrewHeistModelScript.ladder(60, false, true, true) != "somebody_got_pinched":
		failures.append("Plan B made/clean and rich/bust ladder fixtures lost deterministic bands.")


static func _check_abort_and_save(library: ContentLibrary, failures: Array) -> void:
	for progress in range(3):
		var run := _run("HEIST-ABORT-%d" % progress, {"audit_night": true})
		_set_inner(run, "crew_bishop")
		_event_choice(run, library, "crew_planning_table", "lock_the_count")
		for _index in range(progress):
			_record_count_session(run, library, "abort_%d_%d" % [progress, _index])
		var result := _event_choice(run, library, "crew_planning_table", "abort")
		if not bool(result.get("ok", false)) or bool(result.get("run_ended", true)) or run.run_status != RunState.RUN_STATUS_ACTIVE or run.bankroll <= 0:
			failures.append("A pre-Play abort ended the run or failed to charge a survivable cost at progress %d." % progress)
		if bool(_event_choice(run, library, "crew_planning_table", "lock_the_whale_game").get("ok", false)):
			failures.append("An aborted heist allowed a second heist in the same run.")
	var saved := _run("HEIST-SAVE", {"audit_night": true})
	_set_inner(saved, "crew_bishop")
	_event_choice(saved, library, "crew_planning_table", "lock_the_count")
	_record_count_session(saved, library, "save")
	var restored := RunStateScript.new()
	restored.from_dict(saved.to_dict())
	if JSON.stringify(restored.crew_heist_snapshot()) != JSON.stringify(saved.crew_heist_snapshot()):
		failures.append("Mid-heist save/load did not restore the phase state exactly.")
	var hostile_save := saved.to_dict()
	hostile_save["crew_state"]["crew_heist"]["unknown_private_claim"] = true
	var hostile_restored := RunStateScript.new()
	hostile_restored.from_dict(hostile_save)
	if not hostile_restored.crew_heist_state.is_empty():
		failures.append("Heist restore accepted an unknown top-level private claim.")
	var bounded := CrewHeistModelScript.begin("the_count", 0)
	for index in range(32): bounded = CrewHeistModelScript.record_tombstone(bounded, index, 1, 1)
	if _array(bounded.get("q", [])).size() != CrewHeistModelScript.TOMBSTONE_LIMIT:
		failures.append("Heist receipts did not retain the exact bounded tail.")
	var oversized := bounded.duplicate(true)
	oversized["q"].append({"a": 99, "c": 1, "p": 1})
	if not CrewHeistModelScript.restore_state(oversized).is_empty():
		failures.append("Heist restore accepted an oversized receipt list.")
	for phase in CrewHeistModelScript.STATUSES:
		var phase_run := _run("HEIST-SAVE-%s" % phase, {"audit_night": true})
		phase_run.crew_heist_state = CrewHeistModelScript.begin("the_count", 4)
		phase_run.crew_heist_state["status"] = phase
		phase_run.crew_heist_state["setup"] = {"identity_sessions": 2, "schedule": phase != "setup"}
		phase_run.crew_heist_state["play"] = {"round": 2, "score": 73, "decisions": {"go": "hold"}, "hazards": [], "lifelines_used": []}
		var phase_loaded := RunStateScript.new()
		phase_loaded.from_dict(phase_run.to_dict())
		if JSON.stringify(phase_loaded.crew_heist_snapshot()) != JSON.stringify(phase_run.crew_heist_snapshot()):
			failures.append("Heist save/load changed the exact %s phase." % phase)
	var ignored := _run("HEIST-IGNORED", {})
	var ignored_crew := _dict(ignored.to_dict().get("crew_state", {}))
	if ignored_crew.has("crew_heist") or ignored_crew.has("crew_heist_schema_version"):
		failures.append("Crew-ignoring runs gained heist save bytes.")
	var ignored_before := JSON.stringify(ignored.to_dict())
	ignored.call("_crew_heist_boundary_sync")
	if JSON.stringify(ignored.to_dict()) != ignored_before:
		failures.append("A crew-ignoring action boundary mutated serialized run bytes through the live-table lifecycle.")
	var ordinary_gap := _run("HEIST-ORDINARY-SETUP-GAP", {"audit_night": true})
	_set_inner(ordinary_gap, "crew_bishop")
	_event_choice(ordinary_gap, library, "crew_planning_table", "lock_the_count")
	ordinary_gap.crew_heist_state["setup"] = {"identity": true, "swap_cart": true}
	var ordinary_bankroll := ordinary_gap.bankroll
	var ordinary_result := _event_choice(ordinary_gap, library, "crew_planning_table", "begin_play")
	if bool(ordinary_result.get("ok", false)) or str(ordinary_gap.crew_heist_snapshot().get("status", "")) != "setup" or ordinary_gap.bankroll != ordinary_bankroll:
		failures.append("An ordinary missing schedule/cart setup guardrail was incorrectly converted into a forced abort.")


static func _check_seam_regressions(failures: Array) -> void:
	var players := _terminal_route("high_roller_cashout")
	var players_expected := {"schema_version": 1, "source_act": 1, "target_act": 2, "victory_route": "players_card_cashout", "demo_victory_route": "high_roller_cashout", "final_bankroll_band": "walking_money", "story_flags": {}, "route_payload": {"hook": "players_card_open_rooms", "house_attention": "valued_guest", "tone": "invited"}}
	if JSON.stringify(players.act_two_seam_payload()) != JSON.stringify(players_expected):
		failures.append("Players Card Act seam bytes changed after the heist extension.")
	var duel := _terminal_route("pit_boss_showdown")
	var duel_expected := {"schema_version": 1, "source_act": 1, "target_act": 2, "victory_route": "showdown", "demo_victory_route": "pit_boss_showdown", "final_bankroll_band": "walking_money", "story_flags": {}, "route_payload": {"hook": "rourke_remembers", "house_attention": "watched_exit", "tone": "marked"}}
	if JSON.stringify(duel.act_two_seam_payload()) != JSON.stringify(duel_expected):
		failures.append("Rourke showdown Act seam bytes changed after the heist extension.")


static func _check_determinism(library: ContentLibrary, failures: Array) -> void:
	var a := _run("HEIST-DETERMINISM", {"audit_night": true})
	var b := _run("HEIST-DETERMINISM", {"audit_night": true})
	_set_inner(a, "crew_bishop")
	_set_inner(b, "crew_bishop")
	_event_choice(a, library, "crew_planning_table", "lock_the_count")
	_event_choice(b, library, "crew_planning_table", "lock_the_count")
	if JSON.stringify(a.crew_heist_snapshot()) != JSON.stringify(b.crew_heist_snapshot()):
		failures.append("Identical heist seeds and boundaries produced different state.")


static func _event_choice(run: RunState, library: ContentLibrary, event_id: String, choice_id: String) -> Dictionary:
	var event := EventModuleScript.new()
	event.setup(library.event(event_id), library)
	return event.resolve(run, run.current_environment, choice_id)


static func _record_count_session(run: RunState, library: ContentLibrary, session_id: String) -> void:
	var planning_environment := run.current_environment.duplicate(true)
	run.set_environment({"id": "grand_casino", "world_node_id": "grand_casino", "archetype_id": "grand_casino", "kind": "casino", "turns": 0, "visit_id": session_id, "event_ids": [], "resolved_event_ids": []})
	_apply_authoritative_blackjack(run, library, 12)
	run.set_environment(planning_environment)


static func _prepare_whale_setup(run: RunState, library: ContentLibrary) -> void:
	var original_environment := run.current_environment.duplicate(true)
	run.bankroll = maxi(run.bankroll, 500)
	run.narrative_flags["heist_plan_b_whale_vouch"] = true
	run.set_environment({"id": "delta_queen", "world_node_id": "delta_queen", "archetype_id": "delta_queen", "kind": "casino", "turns": 0, "visit_id": "whale_setup_1", "scenario_hook_flags": {"heist_plan_b_criteria": true, "whale_vouch_anchor": true}, "event_ids": ["scenario_whale_aboard_vouch"], "resolved_event_ids": []})
	for _attempt in range(16):
		_apply_authoritative_blackjack(run, library, 35)
		if bool(_dict(run.crew_heist_snapshot().get("setup", {})).get("vouch", false)): break
	run.add_item("false_bottom_cup")
	run.narrative_flags["craps_setting_trained"] = true
	run.record_score_spending(120, "whale_setup")
	run.advance_environment_turns(1)
	run.current_environment["visit_id"] = "whale_setup_2"
	run.advance_environment_turns(1)
	run.set_environment(original_environment)
	run.crew_heist_table_choices()


static func _settled_blackjack_result(stake: int, bankroll_delta: int, venue_id: String) -> Dictionary:
	var result := GameModuleScript.build_action_result({"ok": true, "type": "game_action", "source_id": "blackjack", "game_id": "blackjack", "action_id": "stand", "action_kind": "legal", "stake": stake, "bankroll_delta": bankroll_delta, "deltas": {"bankroll_delta": bankroll_delta, "suspicion_delta": 0}, "environment_archetype_id": venue_id})
	# Blackjack.perform_action appends this after the shared builder only when
	# the hand reaches settlement.  The contract mirrors that shipped boundary.
	result["blackjack_hand_results"] = [{"outcome": "push" if bankroll_delta == 0 else "loss"}]
	return result


static func _apply_authoritative_blackjack(run: RunState, library: ContentLibrary, stake: int) -> Dictionary:
	var definition := library.game("blackjack")
	var module_script: Script = load(str(definition.get("module_path", "")))
	var game: GameModule = module_script.new()
	game.setup(definition, library)
	var environment := run.current_environment.duplicate(true)
	var game_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	if typeof(game_states.get("blackjack", null)) != TYPE_DICTIONARY:
		game_states["blackjack"] = game.generate_environment_state(run, environment, run.create_rng("crew_heist_contract:blackjack_table"))
		environment["game_states"] = game_states
	var deal: Dictionary = game.surface_action_command("blackjack_deal", 0, false, {"selected_stake": stake, "surface_time_msec": 20000}, run, environment)
	var stand: Dictionary = game.surface_action_command("blackjack_stand", 0, true, deal.get("ui_state", {}), run, environment)
	var session: Dictionary = stand.get("ui_state", {}) if typeof(stand.get("ui_state", {})) == TYPE_DICTIONARY else deal.get("ui_state", {})
	var table: Dictionary = game.call("_table_state", run, environment)
	var binding := "blackjack:%s:%s" % [str(environment.get("id", "unknown")), str(environment.get("archetype_id", "unknown"))]
	var ledger := BlackjackActionAuthorityScript.default_ledger(binding, run.blackjack_authority_checkpoint_fingerprint())
	table[BlackjackActionAuthorityScript.LEDGER_KEY] = BlackjackActionAuthorityScript.stage_session(ledger, session)
	game.call("_update_environment_table", environment, table)
	run.current_environment = environment
	var host: Control = FoundationMainScript.new()
	host.set("current_game", game)
	host.set("game_module_cache", {"blackjack": game})
	host.set("run_state", run)
	host.set("selected_stake", stake)
	var result: Dictionary = host.call("_sealed_action_host_resolve_intent", "play_basic", stake)
	host.free()
	return result


static func _apply_authoritative_blackjack_cheat(run: RunState, library: ContentLibrary, stake: int, protected_peek: bool = false) -> Dictionary:
	var definition := library.game("blackjack")
	var module_script: Script = load(str(definition.get("module_path", "")))
	var game: GameModule = module_script.new()
	game.setup(definition, library)
	var environment := run.current_environment.duplicate(true)
	var game_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	if typeof(game_states.get("blackjack", null)) != TYPE_DICTIONARY:
		game_states["blackjack"] = game.generate_environment_state(run, environment, run.create_rng("crew_heist_contract:blackjack_cheat_table"))
		environment["game_states"] = game_states
	var deal: Dictionary = game.surface_action_command("blackjack_deal", 0, false, {"selected_stake": stake, "surface_time_msec": 20000}, run, environment)
	var surface_state: Dictionary = deal.get("ui_state", {}) if typeof(deal.get("ui_state", {})) == TYPE_DICTIONARY else {}
	if protected_peek:
		var distraction: Dictionary = game.surface_action_command("blackjack_distraction", 1, false, surface_state, run, environment)
		surface_state = distraction.get("ui_state", surface_state)
	var peek: Dictionary = game.surface_action_command("blackjack_peek", 1 if protected_peek else 0, false, surface_state, run, environment)
	var session: Dictionary = peek.get("ui_state", surface_state) if typeof(peek.get("ui_state", surface_state)) == TYPE_DICTIONARY else surface_state
	var table: Dictionary = game.call("_table_state", run, environment)
	var binding := "blackjack:%s:%s" % [str(environment.get("id", "unknown")), str(environment.get("archetype_id", "unknown"))]
	var ledger := BlackjackActionAuthorityScript.default_ledger(binding, run.blackjack_authority_checkpoint_fingerprint())
	table[BlackjackActionAuthorityScript.LEDGER_KEY] = BlackjackActionAuthorityScript.stage_session(ledger, session)
	game.call("_update_environment_table", environment, table)
	run.current_environment = environment
	var host: Control = FoundationMainScript.new()
	host.set("current_game", game)
	host.set("game_module_cache", {"blackjack": game})
	host.set("run_state", run)
	host.set("selected_stake", stake)
	var result: Dictionary = host.call("_sealed_action_host_resolve_intent", "peek_hole_card", stake)
	host.free()
	return result


static func _settled_game_result(game_id: String, stake: int, bankroll_delta: int, venue_id: String) -> Dictionary:
	if game_id == "blackjack":
		return _settled_blackjack_result(stake, bankroll_delta, venue_id)
	var action_id := "roll_craps" if game_id == "craps" else "deal_baccarat"
	var result := GameModuleScript.build_action_result({"ok": true, "type": "game_action", "source_id": game_id, "game_id": game_id, "action_id": action_id, "action_kind": "legal", "stake": stake, "bankroll_delta": bankroll_delta, "deltas": {"bankroll_delta": bankroll_delta, "suspicion_delta": 0}, "environment_archetype_id": venue_id})
	if game_id == "craps":
		result["craps_roll"] = {"dice": [3, 4], "total": 7}
		result["craps_bet_results"] = [{"bet": "pass", "outcome": "win"}]
	else:
		result["baccarat_winner"] = "player"
		result["baccarat_hand"] = {"player": [{"rank": "9"}], "banker": [{"rank": "8"}]}
	return result


static func _cheating_settled_game_result(game_id: String, stake: int, bankroll_delta: int, venue_id: String) -> Dictionary:
	var result := _settled_game_result(game_id, stake, bankroll_delta, venue_id)
	result["action_kind"] = "cheat"
	result["skill_outcome"] = "caught"
	result["skill_grade"] = "blown"
	if game_id == "blackjack":
		result["player_cheat_used"] = true
		result["blackjack_cheat_caught"] = true
		result["dealer_caught_cheat"] = true
	elif game_id == "baccarat":
		result["baccarat_edge_sort_edge_used"] = true
	return result


static func _nonterminal_cheat_result(game_id: String, venue_id: String, caught: bool) -> Dictionary:
	var result := GameModuleScript.build_action_result({"ok": true, "type": "game_action", "source_id": game_id, "game_id": game_id, "action_id": "peek_hole_card" if game_id == "blackjack" else "edge_sort", "action_kind": "cheat", "stake": 0, "bankroll_delta": 0, "deltas": {"bankroll_delta": 0, "suspicion_delta": 5}, "environment_archetype_id": venue_id})
	result["skill_outcome"] = "caught" if caught else "applied"
	result["skill_grade"] = "blown" if caught else "good"
	if game_id == "blackjack":
		result["player_cheat_used"] = true
		result["blackjack_cheat_caught"] = caught
		result["dealer_caught_cheat"] = caught
	else:
		result["baccarat_edge_sort"] = true
	return result


static func _run(seed: String, hooks: Dictionary) -> RunState:
	var run: RunState = RunStateScript.new()
	run.start_new(seed)
	var nodes := [
		{"id": "small_underground_casino", "archetype_id": "small_underground_casino", "kind": "crew", "state": "visited", "seen": true, "environment": {}},
		{"id": "grand_casino", "archetype_id": "grand_casino", "kind": "casino", "state": "visited", "seen": true, "environment": {}},
		{"id": "delta_queen", "archetype_id": "delta_queen", "kind": "casino", "state": "visited", "seen": true, "environment": {}},
	]
	var edges := [{"a": "small_underground_casino", "b": "grand_casino"}, {"a": "grand_casino", "b": "delta_queen"}]
	run.set_world_map({"version": 3, "seed_text": seed, "start_node_id": "small_underground_casino", "current_node_id": "small_underground_casino", "nodes": nodes, "edges": edges, "visited_path": ["small_underground_casino"]})
	run.set_environment({"id": "small_underground_casino", "world_node_id": "small_underground_casino", "archetype_id": "small_underground_casino", "kind": "crew", "turns": 0, "scenario_hook_flags": hooks.duplicate(true), "event_ids": ["crew_planning_table"], "resolved_event_ids": []})
	return run


static func _set_grand_situation(run: RunState, scenario_id: String, hooks: Dictionary, event_ids: Array = []) -> void:
	run.set_environment({
		"id": "grand_casino",
		"world_node_id": "grand_casino",
		"archetype_id": "grand_casino",
		"kind": "boss",
		"turns": 0,
		"scenario_id": scenario_id,
		"scenario_state": {
			"schema_version": 1,
			"id": scenario_id,
			"archetype_id": "grand_casino",
			"phase_index": 0,
			"phase_action_counter": 0,
			"mutations": {},
			"phases": [],
		},
		"scenario_hook_flags": hooks.duplicate(true),
		"event_ids": event_ids.duplicate(true),
		"resolved_event_ids": [],
	})
	run.world_map["current_node_id"] = "grand_casino"
	var visited_path := _array(run.world_map.get("visited_path", []))
	if not visited_path.has("grand_casino"):
		visited_path.append("grand_casino")
	run.world_map["visited_path"] = visited_path
	run.store_current_world_node_environment()


static func _move(run: RunState, node_id: String, library: ContentLibrary, failures: Array) -> void:
	var generator := RunGeneratorScript.new(library)
	HarnessProductionFidelityScript.travel_and_finalize(generator, run, node_id, true, library, failures, "Crew heist arrival %s" % node_id)


static func _enter_grand_room(run: RunState, archetype_id: String, library: ContentLibrary, failures: Array, context: String) -> bool:
	if run.current_world_node_id() != RunState.GRAND_CASINO_ARCHETYPE_ID:
		failures.append("%s requires the canonical Grand Casino world node." % context)
		return false
	var generator := RunGeneratorScript.new(library)
	var result := generator.enter_grand_casino_room_result(run, archetype_id)
	if not bool(result.get("ok", false)):
		failures.append("%s could not enter %s: %s" % [context, archetype_id, JSON.stringify(result.get("errors", []))])
		return false
	if run.current_world_node_id() != RunState.GRAND_CASINO_ARCHETYPE_ID or str(run.current_environment.get("archetype_id", "")) != archetype_id:
		failures.append("%s lost the canonical Grand world node or installed the wrong interior room." % context)
		return false
	return true


static func _grand_room_route(archetype_id: String) -> Dictionary:
	return {
		"destination_archetype": archetype_id,
		"target_node_id": RunState.GRAND_CASINO_ARCHETYPE_ID,
		"local_casino_room": true,
	}


static func _set_inner(run: RunState, member_id: String) -> void:
	run.crew_trust_by_member[member_id] = CrewStateModelScript.rank_threshold("inner_circle")


static func _rows(run: RunState) -> Dictionary:
	var result := {}
	for value in _array(run.crew_heist_planning_status().get("plans", [])):
		var row := _dict(value)
		result[str(row.get("id", ""))] = row
	return result


static func _choice_ids(choices: Array) -> Array:
	var result: Array = []
	for value in choices:
		result.append(str(_dict(value).get("id", "")))
	return result


static func _manifest_row(environment: Dictionary, object_id: String) -> Dictionary:
	for row_value in _array(_dict(environment.get("object_manifest", {})).get("rows", [])):
		var row := _dict(row_value)
		if bool(row.get("active", false)) and bool(row.get("physical", false)) \
				and str(row.get("presentation_object_id", row.get("object_id", ""))) == object_id:
			return row
	return {}


static func _terminal_route(route: String) -> RunState:
	var run: RunState = RunStateScript.new()
	run.start_new("HEIST-SEAM-%s" % route)
	run.run_status = RunState.RUN_STATUS_ENDED
	run.narrative_flags["demo_victory"] = true
	run.narrative_flags["demo_victory_route"] = route
	return run


static func _dict(value: Variant) -> Dictionary:
	return (value as Dictionary).duplicate(true) if typeof(value) == TYPE_DICTIONARY else {}


static func _array(value: Variant) -> Array:
	return (value as Array).duplicate(true) if typeof(value) == TYPE_ARRAY else []


static func _strings(value: Variant) -> Array:
	var result: Array = []
	for entry in _array(value):
		result.append(str(entry))
	return result
