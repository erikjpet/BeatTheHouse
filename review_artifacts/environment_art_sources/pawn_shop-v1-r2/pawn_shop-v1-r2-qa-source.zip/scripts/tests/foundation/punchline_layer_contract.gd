extends RefCounted

const EnvironmentInstanceScript := preload("res://scripts/core/environment_instance.gd")
const EventModuleScript := preload("res://scripts/core/event_module.gd")
const RunGeneratorScript := preload("res://scripts/core/run_generator.gd")
const HarnessProductionFidelityScript := preload("res://scripts/tests/foundation/harness_production_fidelity.gd")
const RunStateScript := preload("res://scripts/core/run_state.gd")
const ScenarioEngineScript := preload("res://scripts/core/scenario_engine.gd")
const WorldMapScript := preload("res://scripts/core/world_map.gd")

const BASELINE_PATH := "res://scripts/tests/fixtures/punchline_l2_pre_rework_baseline.json"
const PUNCHLINE_ID := "small_underground_casino"
const CANONICAL_FIELDS := [
	"visual_context", "objective_hint", "layout", "security_profile", "music_profile",
	"economic_profile", "game_pool", "game_count", "item_pool", "item_count",
	"event_pool", "event_scopes", "event_count", "service_pool", "lender_hooks",
	"lender_count", "suspicion_cues", "travel_hooks", "local_narrative_flags", "moods",
]


static func check(library: ContentLibrary, failures: Array) -> void:
	var archetype := library.environment_archetype(PUNCHLINE_ID)
	var layers := _dict(archetype.get("layers", {}))
	if str(archetype.get("display_name", "")) != "The Punchline" or str(archetype.get("default_layer_id", "")) != "club" or layers.size() != 3:
		failures.append("Punchline archetype did not expose one node with club/casino/back_room layers.")
		return
	_check_public_identity(library, archetype, failures)
	_check_l2_baseline(layers, failures)
	_check_generation_and_tutorial(library, archetype, failures)
	_check_layer_scoped_sequence_projection(library, archetype, failures)
	_check_production_scenario_layer_entry(library, failures)
	_check_discovery_and_save(library, archetype, failures)
	_check_back_room_access(library, archetype, failures)
	_check_private_room_recovery(library, archetype, failures)
	_check_legacy_migration(library, archetype, failures)
	_check_shortcut_edge(library, failures)
	_check_scenario_layer_scope(failures)


static func _check_production_scenario_layer_entry(library: ContentLibrary, failures: Array) -> void:
	var run_state := RunStateScript.new()
	run_state.start_new("WAVE-B-COMPOSITION-08")
	var generator := RunGeneratorScript.new(library)
	var initial_arrival := HarnessProductionFidelityScript.generate_and_finalize(generator, run_state, failures, "Punchline contract initial arrival")
	if not bool(initial_arrival.get("ok", false)):
		return
	var travel := HarnessProductionFidelityScript.travel_and_finalize(generator, run_state, PUNCHLINE_ID, true, library, failures, "Punchline L1 arrival")
	if not bool(travel.get("ok", false)) or str(run_state.current_environment.get("scenario_id", "")) != "punchline_high_stakes_night":
		failures.append("Production Punchline high-stakes scenario could not install on L1: %s." % JSON.stringify(travel.get("errors", [])))
		return
	var side_door := EventModuleScript.new()
	side_door.setup(library.event("side_door"), library)
	var discovery := side_door.resolve(run_state, run_state.current_environment, "punchline_password")
	var entered := generator.enter_environment_layer(run_state, "casino", false)
	if not bool(discovery.get("ok", false)) or not bool(entered.get("ok", false)) or str(run_state.current_environment.get("current_layer_id", "")) != "casino":
		failures.append("Production Punchline high-stakes scenario could not cross its L1-to-L2 semantic layout boundary: %s." % JSON.stringify(entered))


static func _check_public_identity(library: ContentLibrary, archetype: Dictionary, failures: Array) -> void:
	var route := library.route(PUNCHLINE_ID)
	var public_copy := " ".join([
		str(archetype.get("display_name", "")),
		str(archetype.get("kind", "")),
		str(_dict(archetype.get("visual_context", {})).get("description", "")),
		str(archetype.get("objective_hint", "")),
		str(route.get("label", "")),
		str(route.get("description", "")),
		str(_dict(route.get("decision", {})).get("offer", "")),
		str(_dict(library.route("gas_station_casino").get("decision", {})).get("tradeoff", "")),
	]).to_lower()
	if not public_copy.contains("comedy") or public_copy.contains("casino") or public_copy.contains("underground") or public_copy.contains("basement"):
		failures.append("Punchline public map/preview identity leaked the hidden casino or omitted the comedy-club cover.")
	if not _array(archetype.get("game_pool", [])).is_empty() or _array(archetype.get("service_pool", [])) != ["punchline_two_drink_minimum"]:
		failures.append("Punchline club did not retain its lean no-games/two-drink public layer.")
	var service := library.service("punchline_two_drink_minimum")
	if service.is_empty() or str(service.get("category", "")) != "alcohol":
		failures.append("Punchline two-drink-minimum service was not registered through the drink-service contract.")


static func _check_l2_baseline(layers: Dictionary, failures: Array) -> void:
	var baseline := _load_dictionary(BASELINE_PATH)
	var expected := _dict(baseline.get("canonical_fields", {}))
	var casino := _dict(layers.get("casino", {}))
	for field_name in CANONICAL_FIELDS:
		if not _json_equal(casino.get(field_name), expected.get(field_name)):
			failures.append("Punchline L2 changed pre-rework canonical field %s (baseline %s)." % [field_name, str(baseline.get("baseline_sha256", "missing"))])
	if _array(casino.get("game_pool", [])) != ["slot", "blackjack", "video_poker"] or int(_dict(casino.get("economic_profile", {})).get("stake_floor", -1)) != 10:
		failures.append("Punchline L2 gameplay pool/stakes no longer match the shipped underground venue.")
	if _array(casino.get("required_game_ids", [])) != ["slot", "blackjack", "video_poker"]:
		failures.append("Punchline L2 must guarantee its slot, blackjack, and video-poker machines on every generated run.")


static func _check_generation_and_tutorial(library: ContentLibrary, archetype: Dictionary, failures: Array) -> void:
	var normal_run := RunStateScript.new()
	normal_run.start_new("PUNCHLINE-NORMAL")
	var normal := EnvironmentInstanceScript.from_archetype(archetype, 2, normal_run.create_rng("punchline"), library).to_dict()
	if str(normal.get("current_layer_id", "")) != "club" or not _array(normal.get("game_ids", [])).is_empty() or not bool(_dict(normal.get("layer_discovery", {})).get("club", false)) or bool(_dict(normal.get("layer_discovery", {})).get("casino", true)):
		failures.append("Ordinary Punchline generation did not begin in the public undiscovered club layer.")
	if _array(normal.get("layer_ambient_lines", [])).size() < 4 or str(normal.get("layer_ambient_line", "")).is_empty():
		failures.append("Punchline club did not generate its deterministic rotating stage bit.")
	var object_rects := _dict(_dict(normal.get("layout", {})).get("object_rects", {}))
	var slot_bindings := _dict(_dict(normal.get("layout", {})).get("slot_bindings", {}))
	if not object_rects.has("environment_layer:ambient") or not object_rects.has("environment_layer:casino"):
		failures.append("Punchline layer fixtures were not assigned stable transition-time layout surfaces.")
	# EnvironmentInstance owns capacity only. Numbers presence is conditional and
	# must not appear until the room is installed into its authoritative RunState.
	if object_rects.has("numbers:book") or slot_bindings.has("numbers:book"):
		failures.append("Raw Punchline generation projected a Numbers book before RunState supplied live venue presence.")
	var installed := normal_run.set_environment(normal)
	var installed_rects := _dict(_dict(normal_run.current_environment.get("layout", {})).get("object_rects", {}))
	var installed_bindings := _dict(_dict(normal_run.current_environment.get("layout", {})).get("slot_bindings", {}))
	if not bool(installed.get("ok", false)) \
			or str(_dict(installed_bindings.get("numbers:book", {})).get("presentation_mode", "")) != "room" \
			or not installed_rects.has("numbers:book") or _layout_overlap_count(installed_rects) != 0:
		failures.append("Punchline club did not project the live Numbers book onto a collision-free layout after RunState installation.")
	var ambient_before := str(normal_run.current_environment.get("layer_ambient_line", ""))
	normal_run.advance_environment_turns(1)
	if str(normal_run.current_environment.get("layer_ambient_line", "")) != ambient_before:
		failures.append("Punchline ambient stage bit rotated before its action boundary.")
	normal_run.advance_environment_turns(1)
	if str(normal_run.current_environment.get("layer_ambient_line", "")) == ambient_before:
		failures.append("Punchline ambient stage bit did not rotate on its authored action boundary.")
	var history_before := normal_run.environment_history.size()
	var bankroll_before := normal_run.bankroll
	var clock_before := normal_run.game_clock_minutes
	normal_run.discover_environment_layer("casino", "fixture")
	if not bool(RunGeneratorScript.new(library).enter_environment_layer(normal_run, "casino", true).get("ok", false)) or normal_run.environment_history.size() != history_before or normal_run.bankroll != bankroll_before or normal_run.game_clock_minutes != clock_before:
		failures.append("Punchline interior navigation behaved like world travel or charged the run.")
	var casino_object_rects := _dict(_dict(normal_run.current_environment.get("layout", {})).get("object_rects", {}))
	var casino_bindings := _dict(_dict(normal_run.current_environment.get("layout", {})).get("slot_bindings", {}))
	var casino_game_ids := _array(normal_run.current_environment.get("game_ids", []))
	var casino_games_grounded := casino_game_ids == ["slot", "blackjack", "video_poker"]
	for game_id_value in casino_game_ids:
		casino_games_grounded = casino_games_grounded and casino_object_rects.has("game:%s" % str(game_id_value))
	if not casino_games_grounded or str(_dict(casino_bindings.get("numbers:book", {})).get("presentation_mode", "")) != "room" \
			or not casino_object_rects.has("numbers:book") or _layout_overlap_count(casino_object_rects) != 0:
		failures.append("Punchline casino did not compose its slot, blackjack, video-poker, and physical Numbers book on one collision-free layout plane.")
	for seed_index in range(32):
		var seed_run := RunStateScript.new()
		seed_run.start_new("PUNCHLINE-REQUIRED-GAMES-%02d" % seed_index)
		var seeded_casino := EnvironmentInstanceScript.from_archetype_layer(archetype, "casino", 2, seed_run.create_rng("punchline"), library).to_dict()
		if _array(seeded_casino.get("game_ids", [])) != ["slot", "blackjack", "video_poker"]:
			failures.append("Punchline casino omitted a required slot, blackjack, or video-poker game for deterministic seed %02d." % seed_index)
			break
	var tutorial_config := library.challenge_config_for("tutorial_first_card", "IGNORED")
	var tutorial_run := RunStateScript.new()
	tutorial_run.start_new("PUNCHLINE-TUTORIAL", tutorial_config)
	var tutorial := EnvironmentInstanceScript.from_archetype(archetype, 2, tutorial_run.create_rng("punchline"), library, tutorial_config).to_dict()
	if str(tutorial.get("current_layer_id", "")) != "casino" or _array(tutorial.get("game_ids", [])) != ["blackjack"] or _array(tutorial.get("event_ids", [])) != ["tutorial_grand_casino_invitation"]:
		failures.append("Tutorial compatibility override did not enter Punchline L2 with the shipped blackjack/invitation flow.")
	if int(_dict(tutorial.get("economic_profile", {})).get("stake_floor", -1)) != 10 or int(_dict(tutorial.get("economic_profile", {})).get("game_stake_floor_overrides", {}).get("blackjack", -1)) != 5:
		failures.append("Tutorial Punchline L2 lost the pre-rework underground stake contract.")


static func _check_layer_scoped_sequence_projection(library: ContentLibrary, archetype: Dictionary, failures: Array) -> void:
	var definition := library._runtime_validated_scenario_definition(library.scenario("punchline_open_mic_night"))
	if definition.is_empty():
		failures.append("Punchline Open Mic scenario definition is missing.")
		return
	var run_state := RunStateScript.new()
	run_state.start_new("PUNCHLINE-SCOPED-SEQUENCE")
	run_state.cache_runtime_scenario_definition(definition)
	var generated := EnvironmentInstanceScript.from_archetype(archetype, 2, run_state.create_rng("punchline"), library, {}, definition).to_dict()
	var stored_casino := _dict(_dict(generated.get("layer_states", {})).get("casino", {}))
	if str(_dict(generated.get("scenario_state", {})).get("id", "")) != "punchline_open_mic_night" \
			or str(_dict(stored_casino.get("scenario_state", {})).get("id", "")) != "punchline_open_mic_night" \
			or stored_casino.has("scenario_sequence_state") \
			or stored_casino.has("scenario_sequence_projection"):
		failures.append("Club-scoped Open Mic sequence was not confined to Punchline L1 during layered generation.")
		return
	var installed := run_state.set_environment(generated)
	var finalized := run_state.scenario_finalize_installed_environment(library)
	# Simulate the prior-build save defect: a room-local L1 sequence projection
	# was serialized into the unopened L2 body. Entry must discard those derived
	# fields while retaining the venue's authoritative scenario cursor.
	if bool(finalized.get("ok", false)):
		var stale_states := _dict(run_state.current_environment.get("layer_states", {}))
		var stale_casino := _dict(stale_states.get("casino", {}))
		for stale_field in [
			"scenario_sequence_state", "scenario_sequence_projection", "scenario_render_snapshot",
			"scenario_sequence_migration", "scenario_semantic_inventory", "scenario_semantic_inventory_version",
			"scenario_semantic_digest", "scenario_semantic_ready", "scenario_layout_authority",
			"scenario_layout_audit", "scenario_layout_authority_digest",
		]:
			if run_state.current_environment.has(stale_field):
				var stale_value: Variant = run_state.current_environment.get(stale_field)
				stale_casino[stale_field] = stale_value.duplicate(true) if typeof(stale_value) in [TYPE_ARRAY, TYPE_DICTIONARY] else stale_value
		stale_states["casino"] = stale_casino
		run_state.current_environment["layer_states"] = stale_states
	run_state.discover_environment_layer("casino", "password")
	var generator := RunGeneratorScript.new(library)
	var entered := generator.enter_environment_layer(run_state, "casino", false)
	# Round 4 makes a layout projection failure non-blocking. This fixture still
	# seeds stale L1 projection fields when finalization succeeds, but crossing
	# the Side Door must remain possible in either case.
	if not bool(installed.get("ok", false)) or not bool(entered.get("ok", false)):
		failures.append("Club-scoped Open Mic scenario blocked the Side Door layer boundary: %s." % JSON.stringify(entered))
		return
	if str(run_state.current_environment.get("current_layer_id", "")) != "casino" \
			or str(_dict(run_state.current_environment.get("scenario_state", {})).get("id", "")) != "punchline_open_mic_night" \
			or run_state.current_environment.has("scenario_sequence_state") \
			or bool(run_state.current_environment.get("scenario_semantic_ready", false)):
		failures.append("Punchline L2 did not preserve the venue scenario cursor while suppressing the L1-only projection.")
	var returned := generator.enter_environment_layer(run_state, "club", false)
	if not bool(returned.get("ok", false)) \
			or (bool(finalized.get("ok", false)) and (not run_state.current_environment.has("scenario_sequence_state") \
			or not bool(run_state.current_environment.get("scenario_semantic_ready", false)))):
		failures.append("Returning to Punchline L1 did not restore its scoped Open Mic sequence projection: %s." % JSON.stringify({"returned": returned, "initial_finalization_ok": finalized.get("ok", false), "has_state": run_state.current_environment.has("scenario_sequence_state"), "semantic_ready": run_state.current_environment.get("scenario_semantic_ready", false)}))


static func _check_discovery_and_save(library: ContentLibrary, archetype: Dictionary, failures: Array) -> void:
	var event_module := EventModuleScript.new()
	event_module.setup(library.event("side_door"), library)
	for choice_id in ["punchline_password", "punchline_regular_nod"]:
		var run_state := RunStateScript.new()
		run_state.start_new("PUNCHLINE-DISCOVERY-%s" % choice_id)
		run_state.set_environment(EnvironmentInstanceScript.from_archetype(archetype, 2, run_state.create_rng("punchline"), library).to_dict())
		var club_choices := _choice_ids(event_module.choices(run_state, run_state.current_environment))
		if not club_choices.has("punchline_password") or not club_choices.has("punchline_regular_nod") or club_choices.has("cheap_route") or club_choices.has("dark_route"):
			failures.append("Punchline club did not offer two canonical discovery paths while hiding legacy route choices.")
			return
		var result := event_module.resolve(run_state, run_state.current_environment, choice_id)
		if not bool(result.get("ok", false)) or not bool(_dict(run_state.current_environment.get("layer_discovery", {})).get("casino", false)):
			failures.append("Punchline discovery choice %s did not persist the L2 seam." % choice_id)
			continue
		var discovery_log_count := _story_type_count(run_state.story_log, "environment_layer_discovered")
		var generator := RunGeneratorScript.new(library)
		var entered := generator.enter_environment_layer(run_state, "casino", false)
		if not bool(entered.get("ok", false)) or str(run_state.current_environment.get("current_layer_id", "")) != "casino":
			failures.append("Punchline discovery choice %s did not open L2." % choice_id)
			continue
		var casino_choices := _choice_ids(event_module.choices(run_state, run_state.current_environment))
		if not casino_choices.has("cheap_route") or not casino_choices.has("dark_route") or casino_choices.has("punchline_password"):
			failures.append("Legacy side-door route choices did not survive outside Punchline L1.")
		var restored := RunStateScript.new()
		restored.from_dict(run_state.to_dict())
		if str(restored.current_environment.get("current_layer_id", "")) != "casino" or not bool(_dict(restored.current_environment.get("layer_discovery", {})).get("casino", false)):
			failures.append("Punchline save/load did not restore the active L2 and discovery state.")
		var stored_games := _dict(restored.current_environment.get("game_states", {}))
		stored_games["layer_fixture"] = {"choice_id": choice_id}
		restored.current_environment["game_states"] = stored_games
		if not bool(generator.enter_environment_layer(restored, "club", false).get("ok", false)) or not bool(generator.enter_environment_layer(restored, "casino", false).get("ok", false)):
			failures.append("Discovered Punchline L2 did not become one-click re-entry.")
		elif str(_dict(_dict(restored.current_environment.get("game_states", {})).get("layer_fixture", {})).get("choice_id", "")) != choice_id:
			failures.append("Punchline layer re-entry regenerated and lost persisted game state.")
		restored.discover_environment_layer("casino", "repeat")
		if _story_type_count(restored.story_log, "environment_layer_discovered") != discovery_log_count:
			failures.append("Punchline re-entry repeated discovery presentation/logging.")


static func _check_back_room_access(library: ContentLibrary, archetype: Dictionary, failures: Array) -> void:
	var run_state := RunStateScript.new()
	run_state.start_new("PUNCHLINE-L3")
	var casino := EnvironmentInstanceScript.from_archetype_layer(archetype, "casino", 2, run_state.create_rng("casino"), library).to_dict()
	casino["layer_discovery"] = {"club": true, "casino": true, "back_room": false}
	run_state.set_environment(casino)
	var denied := run_state.environment_layer_access_status("back_room")
	if bool(denied.get("available", false)):
		failures.append("Punchline L3 admitted a stranger without an escort.")
	var generator := RunGeneratorScript.new(library)
	var denied_snapshot := run_state.to_dict()
	if bool(generator.enter_environment_layer(run_state, "back_room", true).get("ok", false)) or not _json_equal(run_state.to_dict(), denied_snapshot):
		failures.append("Denied Crew door changed the authoritative run or entered the private room.")
	run_state.discover_environment_layer("back_room", "legacy")
	if bool(run_state.environment_layer_access_status("back_room").get("available", false)):
		failures.append("Crew room discovery bypassed current credentials.")
	var legacy := run_state.to_dict()
	var legacy_environment: Dictionary = legacy["current_environment"]
	for transition in legacy_environment.get("layer_transitions", []):
		if str(transition.get("target_layer_id", "")) == "back_room":
			transition.erase("requires_current_access")
			transition["access_paths"] = [{"method": "crew_rank", "min_crew_rank": "stranger"}]
	var legacy_run := RunStateScript.new()
	legacy_run.from_dict(legacy)
	if bool(legacy_run.environment_layer_access_status("back_room").get("available", false)):
		failures.append("Restored legacy Crew door retained its stranger/discovery bypass.")
	run_state.crew_add_trust("crew_rook", 59, "punchline_test")
	if bool(run_state.environment_layer_access_status("back_room").get("available", false)):
		failures.append("Crew room opened below canonical Made standing.")
	run_state.crew_add_trust("crew_rook", 1, "punchline_test")
	if not bool(run_state.environment_layer_access_status("back_room").get("available", false)):
		failures.append("Punchline L3 did not open at made Crew standing.")
	var back_room_entry := generator.enter_environment_layer(run_state, "back_room", false)
	var entered_back_room := bool(back_room_entry.get("ok", false))
	var back_room_games := _array(run_state.current_environment.get("game_ids", []))
	var rook_ambient_ok := str(run_state.current_environment.get("layer_ambient_label", "")) == "Rook" \
		and str(run_state.current_environment.get("layer_ambient_prop", "")) == "patron_talk" \
		and str(run_state.current_environment.get("layer_ambient_line", "")).contains("Rook")
	var manifest_rows := EnvironmentInstanceScript.active_object_manifest_rows(run_state.current_environment)
	var has_exit := false
	for row in manifest_rows:
		if str(row.get("object_id", "")) == "environment_layer:casino": has_exit = true
	if not entered_back_room or not has_exit or not _json_equal(back_room_games, ["crew_draw_poker"]) or not rook_ambient_ok:
		failures.append("Punchline L3 did not enter with its single Crew poker table and compatible Rook ambient shell: %s." % JSON.stringify(back_room_entry))
	var resumed := RunStateScript.new()
	resumed.from_dict(run_state.to_dict())
	var cash_before := resumed.bankroll
	var inventory_before := resumed.inventory.duplicate(true)
	if not bool(generator.enter_environment_layer(resumed, "casino", false).get("ok", false)) or resumed.bankroll != cash_before or resumed.inventory != inventory_before:
		failures.append("Saved Crew room could not leave without changing cash/inventory.")
	var escort_run := RunStateScript.new()
	escort_run.start_new("PUNCHLINE-L3-ESCORT")
	escort_run.set_environment(casino)
	escort_run.story_flags["rook_escort_punchline_back_room"] = true
	if not bool(escort_run.environment_layer_access_status("back_room").get("available", false)):
		failures.append("Punchline L3 did not open from the authored Rook escort flag.")


static func _check_private_room_recovery(library: ContentLibrary, archetype: Dictionary, failures: Array) -> void:
	var run_state := RunStateScript.new()
	run_state.start_new("PUNCHLINE-RECOVERY")
	run_state.crew_add_trust("crew_rook", 10000, "recovery_test")
	var casino := EnvironmentInstanceScript.from_archetype_layer(archetype, "casino", 2, run_state.create_rng("casino"), library).to_dict()
	run_state.set_environment(casino)
	var generator := RunGeneratorScript.new(library)
	if not bool(generator.enter_environment_layer(run_state, "back_room", false).get("ok", false)):
		failures.append("Recovery setup could not enter the Crew room.")
		return
	var intact := run_state.to_dict()
	# A damaged display envelope represents the rejection class, not a claimed
	# reproduction of the user's still-unidentified empty room.
	run_state.current_environment["object_manifest_digest"] = "rejected-layout"
	var preserved := run_state.current_environment.duplicate(true)
	preserved.erase("layer_states")
	var cash := run_state.bankroll
	var clock := run_state.game_clock_minutes
	var inventory := run_state.inventory.duplicate(true)
	var rng := run_state.rng_state
	var result := generator.recover_punchline_back_room_exit(run_state)
	var retained := _dict(_dict(run_state.current_environment.get("layer_states", {})).get("back_room", {}))
	if not bool(result.get("ok", false)) or str(run_state.current_environment.get("current_layer_id", "")) != "casino" or not _json_equal(retained, preserved):
		failures.append("Rejected Crew room could not recover to its validated saved parent while retaining the exact room payload: %s." % JSON.stringify(result))
	if run_state.bankroll != cash or run_state.inventory != inventory or run_state.game_clock_minutes != clock or run_state.rng_state != rng:
		failures.append("Crew room recovery changed cash, inventory, clock, or RNG.")
	if not EnvironmentInstanceScript.object_manifest_errors(run_state.current_environment).is_empty():
		failures.append("Recovered casino has invalid object authority.")
	run_state.from_dict(intact)
	run_state.current_environment["layer_states"] = {}
	var missing_parent := run_state.to_dict()
	if bool(generator.recover_punchline_back_room_exit(run_state).get("ok", false)) or not _json_equal(run_state.to_dict(), missing_parent):
		failures.append("Missing recovery parent did not retain the exact active run.")
	run_state.from_dict(intact)
	var states := _dict(run_state.current_environment.get("layer_states", {}))
	var invalid_parent := _dict(states.get("casino", {}))
	invalid_parent["archetype_id"] = "missing_archetype"
	states["casino"] = invalid_parent
	run_state.current_environment["layer_states"] = states
	var before_rejection := run_state.to_dict()
	if bool(generator.recover_punchline_back_room_exit(run_state).get("ok", false)) or not _json_equal(run_state.to_dict(), before_rejection):
		failures.append("Invalid recovery parent did not roll back the exact active run.")


static func _check_legacy_migration(library: ContentLibrary, archetype: Dictionary, failures: Array) -> void:
	var source_run := RunStateScript.new()
	source_run.start_new("PUNCHLINE-LEGACY")
	var legacy := EnvironmentInstanceScript.from_archetype_layer(archetype, "casino", 2, source_run.create_rng("casino"), library).to_dict()
	for key in ["environment_layer_schema_version", "current_layer_id", "default_layer_id", "layer_ids", "layer_display_name", "layer_transitions", "layer_discovery", "layer_states", "layer_ambient_lines", "layer_ambient_label", "layer_ambient_prop", "layer_ambient_rotate_actions", "layer_ambient_index", "layer_ambient_line"]:
		legacy.erase(key)
	legacy["display_name"] = "Pink Room Underground Casino"
	source_run.current_environment = legacy
	var restored := RunStateScript.new()
	restored.from_dict(source_run.to_dict())
	if int(restored.current_environment.get("environment_layer_schema_version", 0)) != 1 or str(restored.current_environment.get("current_layer_id", "")) != "casino" or str(restored.current_environment.get("display_name", "")) != "The Punchline" or not bool(_dict(restored.current_environment.get("layer_discovery", {})).get("casino", false)):
		failures.append("Pre-0.6 underground save did not migrate into discovered Punchline L2.")
	var snapshot_run := RunStateScript.new()
	snapshot_run.start_new("PUNCHLINE-LEGACY-SNAPSHOT")
	snapshot_run.world_map = WorldMapScript.new(library).build(snapshot_run, snapshot_run.create_rng("world"))
	snapshot_run.world_map = WorldMapScript.store_environment(snapshot_run.world_map, PUNCHLINE_ID, legacy)
	snapshot_run.current_environment = {}
	var snapshot_restored := RunStateScript.new()
	snapshot_restored.from_dict(snapshot_run.to_dict())
	var migrated_snapshot: Dictionary = WorldMapScript.new(library).preview_for_target(snapshot_restored.world_map, PUNCHLINE_ID)
	if int(migrated_snapshot.get("environment_layer_schema_version", 0)) != 1 or str(migrated_snapshot.get("current_layer_id", "")) != "casino" or not bool(_dict(migrated_snapshot.get("layer_discovery", {})).get("casino", false)):
		failures.append("Pre-0.6 underground world-map snapshot did not migrate eagerly into discovered Punchline L2.")


static func _check_shortcut_edge(library: ContentLibrary, failures: Array) -> void:
	var run_state := RunStateScript.new()
	run_state.start_new("PUNCHLINE-WORLD-EDGE")
	var world_map := WorldMapScript.new(library).build(run_state, run_state.create_rng("world"))
	if WorldMapScript.edge_between(world_map, PUNCHLINE_ID, "grand_casino").is_empty():
		failures.append("World graph lost the guaranteed Punchline-to-Grand-Casino shortcut edge.")
		return
	world_map = WorldMapScript.enter_node(world_map, "grand_casino", {})
	world_map = WorldMapScript.enter_node(world_map, PUNCHLINE_ID, {})
	var route := WorldMapScript.new(library).route_for_target(world_map, PUNCHLINE_ID, "grand_casino")
	if route.is_empty() or _array(route.get("world_path", [])) != [PUNCHLINE_ID, "grand_casino"]:
		failures.append("Guaranteed Punchline-to-Grand-Casino shortcut edge was present but not traversable.")


static func _check_scenario_layer_scope(failures: Array) -> void:
	var state := ScenarioEngineScript.initial_state({
		"id": "punchline_layer_fixture",
		"archetype_id": PUNCHLINE_ID,
		"layer_id": "casino",
		"display_name": "Layer Fixture",
		"weight": 1,
		"mutations": {"presentation": {"signage_line": "PRIVATE"}},
	})
	if str(state.get("layer_id", "")) != "casino" or str(ScenarioEngineScript.public_snapshot(state).get("layer_id", "")) != "casino":
		failures.append("Scenario engine did not preserve its optional environment layer scope.")
	var club := ScenarioEngineScript.apply_to_archetype({"current_layer_id": "club"}, state)
	ScenarioEngineScript.attach_to_environment(club, state)
	if _dict(club.get("scenario_presentation", {})).has("signage_line"):
		failures.append("Casino-scoped scenario mutations leaked into Punchline L1.")
	var casino := ScenarioEngineScript.apply_to_archetype({"current_layer_id": "casino"}, state)
	ScenarioEngineScript.attach_to_environment(casino, state)
	if str(_dict(casino.get("scenario_presentation", {})).get("signage_line", "")) != "PRIVATE":
		failures.append("Casino-scoped scenario mutation did not attach to Punchline L2.")


static func _load_dictionary(path: String) -> Dictionary:
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	return (parsed as Dictionary).duplicate(true) if typeof(parsed) == TYPE_DICTIONARY else {}


static func _dict(value: Variant) -> Dictionary:
	return (value as Dictionary).duplicate(true) if typeof(value) == TYPE_DICTIONARY else {}


static func _array(value: Variant) -> Array:
	return (value as Array).duplicate(true) if typeof(value) == TYPE_ARRAY else []


static func _json_equal(left: Variant, right: Variant) -> bool:
	return JSON.stringify(left) == JSON.stringify(right)


static func _choice_ids(choices: Array) -> Array:
	var result: Array = []
	for choice_value in choices:
		if typeof(choice_value) == TYPE_DICTIONARY:
			result.append(str((choice_value as Dictionary).get("id", "")))
	return result


static func _story_type_count(story_log: Array, type_id: String) -> int:
	var result := 0
	for entry_value in story_log:
		if typeof(entry_value) == TYPE_DICTIONARY and str((entry_value as Dictionary).get("type", "")) == type_id:
			result += 1
	return result


static func _layout_overlap_count(object_rects: Dictionary) -> int:
	var ids := object_rects.keys()
	ids.sort()
	var count := 0
	for left_index in range(ids.size()):
		var left := _layout_rect(object_rects.get(ids[left_index], {}))
		if not left.has_area():
			continue
		for right_index in range(left_index + 1, ids.size()):
			var right := _layout_rect(object_rects.get(ids[right_index], {}))
			if right.has_area() and left.intersects(right):
				count += 1
	return count


static func _layout_rect(value: Variant) -> Rect2:
	var data := _dict(value)
	return Rect2(
		float(data.get("x", 0.0)), float(data.get("y", 0.0)),
		float(data.get("w", 0.0)), float(data.get("h", 0.0))
	)
