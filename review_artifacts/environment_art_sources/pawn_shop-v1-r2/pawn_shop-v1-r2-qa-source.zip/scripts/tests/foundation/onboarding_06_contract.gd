class_name Onboarding06Contract
extends RefCounted

const CoachOverlayScript := preload("res://scripts/ui/coach_overlay.gd")
const CoachViewModelScript := preload("res://scripts/ui/coach_view_model.gd")

const GUIDED_LESSON_IDS := [
	"tutorial_apartment_xray", "tutorial_inventory_xray", "tutorial_open_map_corner", "tutorial_travel_corner",
	"tutorial_inspect_coffee", "tutorial_inspect_pencil", "tutorial_buy_store_item", "tutorial_buy_remaining_store_item",
	"tutorial_crew_warning", "tutorial_family_phone", "tutorial_family_debt", "tutorial_parking_tip",
	"tutorial_route_map", "tutorial_route_choice", "tutorial_gas_machine", "tutorial_gas_peek",
	"tutorial_gas_peek_heat", "tutorial_gas_xray_buy", "tutorial_gas_peel", "tutorial_gas_leave_machine",
	"tutorial_gas_redeem", "tutorial_gas_map_underground", "tutorial_gas_travel_underground", "tutorial_underground_table",
	"tutorial_blackjack_clean_deal", "tutorial_blackjack_clean_finish", "tutorial_blackjack_raise", "tutorial_blackjack_raised_deal",
	"tutorial_blackjack_heat_precheck", "tutorial_blackjack_lookaway", "tutorial_blackjack_peek", "tutorial_blackjack_peek_finish",
	"tutorial_blackjack_count_start", "tutorial_blackjack_count_all", "tutorial_blackjack_count_finish", "tutorial_heat_warning",
	"tutorial_leave_blackjack", "tutorial_drink_intro", "tutorial_accept_invitation", "tutorial_pal_goodbye_map",
	"tutorial_travel_grand", "tutorial_host_entry", "tutorial_rourke_intro", "tutorial_take_comp",
	"tutorial_enter_cage", "tutorial_open_linda", "tutorial_buy_cage_chips", "tutorial_cage_shop",
	"tutorial_return_main_floor", "tutorial_enter_grand_table", "tutorial_earn_bronze", "tutorial_leave_grand_table",
	"tutorial_return_cage", "tutorial_reopen_linda", "tutorial_claim_bronze", "tutorial_meta_home_card",
]

const LESSON_IDS := [
	"tip06_tonight_changes_rooms",
	"tip06_delivery_route",
	"tip06_numbers_book",
	"tip06_crew_standing",
	"tip06_coin_pusher",
	"tip06_craps_pass_line",
	"tip06_venue_depth",
	"tip06_back_room_poker",
	"tip06_true_rumor",
	"tip06_police_sweep",
]

const DISCOVERY_BLOCKERS := [
	"past-post", "past posting", "crew fix", "the turn", "hidden layer", "lower layer", "layer 2", "layer 3",
	"traitor", "betrayal", "grievance", "bribe", "camouflage", "already won", "book closes", "news across town",
	"hidden casino", "crew back room", "numbers desk",
]


class PublicRunFixture:
	extends RefCounted

	var current_environment := {
		"archetype_id": "small_underground_casino",
		"current_layer_id": "club",
		"scenario_id": "punchline_open_mic",
	}
	var crew_jobs := {"fixture:0001": {"status": "resolved"}}
	var delivery := {"status": "active"}

	func delivery_has_active_run() -> bool:
		return true

	func delivery_snapshot() -> Dictionary:
		return delivery.duplicate(true)


class PublicHostFixture:
	extends Control

	var run_state: Variant = PublicRunFixture.new()
	var current_context_mode := "numbers"
	var pending_event_choice_popup_snapshot := {"popup_type": "numbers_surface"}


static func check(library: Variant, failures: Array) -> void:
	_check_guided_prefix(library, failures)
	_check_contextual_lesson_matrix(library, failures)
	_check_public_host_context(failures)
	_check_contextual_queue_discipline(library, failures)
	_check_normal_tip_action_handoff(library, failures)
	_check_discovery_boundary(library, failures)


static func _check_guided_prefix(library: Variant, failures: Array) -> void:
	var guided_ids: Array = []
	var found_normal := false
	for lesson_value in library.tutorial_lessons:
		if typeof(lesson_value) != TYPE_DICTIONARY:
			continue
		var lesson: Dictionary = lesson_value
		if str(lesson.get("scope", "")) == "tutorial_run":
			if found_normal:
				failures.append("0.6 onboarding was inserted into the shipped guided tutorial sequence instead of appended after it.")
			guided_ids.append(str(lesson.get("id", "")))
		else:
			found_normal = true
	if guided_ids != GUIDED_LESSON_IDS:
		failures.append("The shipped 56-lesson guided tutorial prefix or sequence changed: %s" % str(guided_ids))


static func _check_contextual_lesson_matrix(library: Variant, failures: Array) -> void:
	var matrix := [
		{
			"id": "tip06_tonight_changes_rooms",
			"encounter": _environment_context({"scenario_active": true}),
			"miss": _environment_context({"scenario_active": false}),
			"terms": ["scenario", "read the objective", "what can change", "ends the night"],
		},
		{
			"id": "tip06_delivery_route",
			"encounter": _environment_context({"delivery_active": true}),
			"miss": _environment_context({"delivery_active": false}),
			"terms": ["action deadlines", "packages", "stops", "lookout holds", "watch ends", "contraband", "risk"],
		},
		{
			"id": "tip06_numbers_book",
			"encounter": _environment_context({}, {"numbers_encountered": true}),
			"miss": _environment_context({}, {"numbers_encountered": false}),
			"terms": ["digits", "stake", "daily draw", "town talks", "contraband"],
		},
		{
			"id": "tip06_crew_standing",
			"encounter": _environment_context({"crew_job_resolved": true}),
			"miss": _environment_context({"crew_job_resolved": false}),
			"terms": ["jobs", "standing", "miss", "opens rooms", "path"],
		},
		{
			"id": "tip06_coin_pusher",
			"encounter": _game_context("coin_pusher"),
			"miss": _game_context("blackjack"),
			"terms": ["carriage", "hold", "drop", "bonus-token cups", "heavy feature pieces", "cabinet goal"],
		},
		{
			"id": "tip06_craps_pass_line",
			"encounter": _game_context("craps"),
			"miss": _game_context("blackjack"),
			"terms": ["bet", "pass", "seven", "eleven", "point", "grab", "drag", "release"],
		},
		{
			"id": "tip06_venue_depth",
			"encounter": _environment_context({"venue_depth_surface": true}),
			"miss": _environment_context({"venue_depth_surface": false}),
			"terms": ["venues", "more room", "way through"],
		},
		{
			"id": "tip06_back_room_poker",
			"encounter": _game_context("crew_draw_poker"),
			"miss": _game_context("blackjack"),
			"terms": ["poker night", "seeded session", "ante", "cash out", "public behavior", "tell", "verified"],
		},
		{
			"id": "tip06_true_rumor",
			"encounter": _environment_context({"flags": {"chain06_dave_true_rumor_heard": true}}),
			"miss": _environment_context({"flags": {"chain06_dave_true_rumor_heard": false}}),
			"terms": ["heard rumor", "true fact", "another place", "marked map stop", "truthful"],
		},
		{
			"id": "tip06_police_sweep",
			"encounter": _environment_context({}, {}, {"last_action_id": "sweep_wait"}),
			"miss": _environment_context({}, {}, {"last_action_id": "map"}),
			"terms": ["police sweep", "action boundaries", "public marker", "wait", "one action", "contraband", "heat"],
		},
	]
	var actual_ids: Array = []
	for lesson_value in library.tutorial_lessons:
		if typeof(lesson_value) == TYPE_DICTIONARY and str((lesson_value as Dictionary).get("scope", "")) != "tutorial_run":
			actual_ids.append(str((lesson_value as Dictionary).get("id", "")))
	if actual_ids != LESSON_IDS:
		failures.append("The public 0.6 onboarding catalog drifted: %s" % str(actual_ids))
	for case_value in matrix:
		var case: Dictionary = case_value
		var lesson: Dictionary = library.tutorial_lesson(str(case.get("id", "")))
		if lesson.is_empty():
			failures.append("Missing contextual 0.6 lesson: %s" % str(case.get("id", "")))
			continue
		var encounter := _dict(case.get("encounter", {}))
		var miss := _dict(case.get("miss", {}))
		if not CoachViewModelScript.trigger_matches(lesson, encounter, {}, true):
			failures.append("%s did not fire on its first genuine encounter." % str(case.get("id", "")))
		if CoachViewModelScript.trigger_matches(lesson, encounter, {str(case.get("id", "")): true}, true):
			failures.append("%s fired more than once after being seen." % str(case.get("id", "")))
		if CoachViewModelScript.trigger_matches(lesson, miss, {}, true):
			failures.append("%s appeared in a run that never met its system." % str(case.get("id", "")))
		if CoachViewModelScript.trigger_matches(lesson, encounter, {}, false):
			failures.append("%s ignored the normal-run coach preference." % str(case.get("id", "")))
		var tutorial_encounter := encounter.duplicate(true)
		var tutorial_run := _dict(tutorial_encounter.get("run", {})).duplicate(true)
		tutorial_run["tutorial"] = true
		tutorial_encounter["run"] = tutorial_run
		if CoachViewModelScript.trigger_matches(lesson, tutorial_encounter, {}, true):
			failures.append("%s leaked into the shipped guided tutorial." % str(case.get("id", "")))
		if not CoachViewModelScript.completion_matches(lesson, "coach:skip"):
			failures.append("%s cannot be skipped." % str(case.get("id", "")))
		var model := CoachViewModelScript.build(lesson, encounter)
		if not bool(model.get("dismissible", false)) or bool(model.get("gating", true)):
			failures.append("%s became modal or non-dismissible." % str(case.get("id", "")))
		var copy := str(lesson.get("copy", "")).to_lower()
		for term_value in case.get("terms", []):
			var term := str(term_value)
			if not copy.contains(term):
				failures.append("%s lost required public teaching term '%s'." % [str(case.get("id", "")), term])
		_check_contextual_determinism_and_placement(lesson, encounter, failures)
		_check_contextual_double_notify(lesson, encounter, failures)
	_check_crew_ignoring_run(library, failures)
	var depth_lesson: Dictionary = library.tutorial_lesson("tip06_venue_depth")
	var depth_context := _environment_context({"venue_depth_surface": true})
	depth_context["viewport_rect"] = Rect2(Vector2.ZERO, Vector2(1280, 720))
	var room_target := Rect2(448, 288, 384, 144)
	depth_context["anchor_rects"] = {"interactable_objects": {"fixture:center": room_target}}
	var depth_model := CoachViewModelScript.build(depth_lesson, depth_context)
	var depth_bubble := CoachViewModelScript._rect(depth_model.get("bubble_rect", {}))
	if depth_bubble.intersects(room_target):
		failures.append("Normal-run advice did not move away from public interaction geometry when a clear placement existed.")


static func _check_public_host_context(failures: Array) -> void:
	var host := PublicHostFixture.new()
	var overlay := CoachOverlayScript.new()
	host.add_child(overlay)
	var source_context := _environment_context()
	var source_run: Dictionary = source_context.get("run", {})
	var source_ui: Dictionary = source_context.get("ui", {})
	var borrowed_geometry := {"dense": [{"marker": 7}]}
	source_context["anchor_rects"] = borrowed_geometry
	var source_json := JSON.stringify(source_context)
	var context: Dictionary = overlay.call("_with_public_system_context", source_context)
	var run_context := _dict(context.get("run", {}))
	var ui_context := _dict(context.get("ui", {}))
	for key in ["scenario_active", "delivery_active", "crew_job_resolved", "venue_depth_surface"]:
		if not bool(run_context.get(key, false)):
			failures.append("Coach public-context seam did not expose landed encounter '%s'." % key)
	if not bool(ui_context.get("numbers_encountered", false)):
		failures.append("Coach public-context seam did not recognize the focused Numbers surface.")
	if JSON.stringify(source_context) != source_json \
			or is_same(context, source_context) \
			or is_same(run_context, source_run) \
			or is_same(ui_context, source_ui) \
			or not is_same(context.get("anchor_rects", {}), borrowed_geometry):
		failures.append("Coach public-context copy-on-write seam mutated its source or copied an untouched presentation branch.")
	run_context["scenario_active"] = false
	ui_context["numbers_encountered"] = false
	if source_run.has("scenario_active") or source_ui.has("numbers_encountered"):
		failures.append("Coach public-context derived flags aliased caller-owned run/ui branches.")
	var property_scans_after_first := int(overlay.object_property_list_scan_count)
	overlay.call("_with_public_system_context", source_context)
	if property_scans_after_first != 2 or int(overlay.object_property_list_scan_count) != property_scans_after_first:
		failures.append("Coach public-context property capability cache rescanned a stable host or RunState instance.")
	var action_source := _game_context("coin_pusher")
	var action_source_branch := {"last_action_id": "before"}
	action_source["action"] = action_source_branch
	action_source["anchor_rects"] = borrowed_geometry
	overlay.latest_context = action_source
	overlay.call("_evaluate_normal_action_boundary", "coin_pusher_drop")
	var observed_action: Dictionary = _dict(overlay.latest_context.get("action", {}))
	if str(action_source_branch.get("last_action_id", "")) != "before" \
			or str(observed_action.get("last_action_id", "")) != "coin_pusher_drop" \
			or is_same(observed_action, action_source_branch) \
			or not is_same(overlay.latest_context.get("anchor_rects", {}), borrowed_geometry):
		failures.append("Coach action-boundary copy-on-write path mutated its source or copied untouched geometry.")
	host.free()


static func _check_contextual_queue_discipline(library: Variant, failures: Array) -> void:
	var host := PublicHostFixture.new()
	var overlay := CoachOverlayScript.new()
	host.add_child(overlay)
	var scenario_lesson: Dictionary = library.tutorial_lesson("tip06_tonight_changes_rooms")
	var depth_lesson: Dictionary = library.tutorial_lesson("tip06_venue_depth")
	overlay.set_lessons([scenario_lesson, depth_lesson])
	overlay.restore_seen({})
	overlay.evaluate_at_boundary(_environment_context())
	var first_snapshot: Dictionary = overlay.current_snapshot()
	if str(first_snapshot.get("lesson_id", "")) != "tip06_tonight_changes_rooms" \
			or int(first_snapshot.get("queued_count", -1)) != 0:
		failures.append("A simultaneous scenario/Punchline encounter queued a normal-run advice wall: %s" % JSON.stringify(first_snapshot))
	if not overlay.notify_action("coach:skip"):
		failures.append("The first simultaneous contextual tip could not be dismissed normally.")
	# Leaving the surface before another boundary must not display the deferred
	# Punchline tip out of context.
	host.run_state.current_environment = {"archetype_id": "bar"}
	host.current_context_mode = "room"
	host.pending_event_choice_popup_snapshot = {}
	overlay.evaluate_at_boundary(_environment_context())
	var stale_surface_snapshot: Dictionary = overlay.current_snapshot()
	if bool(stale_surface_snapshot.get("visible", false)) or not str(stale_surface_snapshot.get("lesson_id", "")).is_empty():
		failures.append("Deferred contextual advice followed the player off its genuine encounter: %s" % JSON.stringify(stale_surface_snapshot))
	# Returning later is a new genuine encounter and may teach the deferred tip.
	host.run_state.current_environment = {
		"archetype_id": "small_underground_casino",
		"current_layer_id": "club",
	}
	overlay.evaluate_at_boundary(_environment_context())
	var deferred_snapshot: Dictionary = overlay.current_snapshot()
	if str(deferred_snapshot.get("lesson_id", "")) != "tip06_venue_depth" \
			or int(deferred_snapshot.get("queued_count", -1)) != 0:
		failures.append("A deferred contextual tip did not wait for its next genuine encounter: %s" % JSON.stringify(deferred_snapshot))
	# Exercise the defensive display-time check directly: a legacy/staged queue
	# entry whose trigger no longer matches is dropped without becoming seen.
	overlay.restore_seen({})
	overlay.set_lessons([depth_lesson])
	host.run_state.current_environment = {"archetype_id": "bar"}
	overlay.queued_lessons.append({"lesson": depth_lesson.duplicate(true), "context": _environment_context({"venue_depth_surface": true})})
	overlay.queued_ids["tip06_venue_depth"] = true
	overlay.evaluate_at_boundary(_environment_context())
	var revalidated_snapshot: Dictionary = overlay.current_snapshot()
	if bool(revalidated_snapshot.get("visible", false)) \
			or int(revalidated_snapshot.get("queued_count", -1)) != 0 \
			or bool(overlay.seen.get("tip06_venue_depth", false)):
		failures.append("A stale contextual queue entry displayed or became seen after its trigger disappeared: %s" % JSON.stringify(revalidated_snapshot))
	host.free()


static func _check_normal_tip_action_handoff(library: Variant, failures: Array) -> void:
	var host := PublicHostFixture.new()
	host.current_context_mode = "room"
	host.pending_event_choice_popup_snapshot = {}
	var overlay := CoachOverlayScript.new()
	host.add_child(overlay)
	var delivery_lesson: Dictionary = library.tutorial_lesson("tip06_delivery_route")
	var scenario_lesson: Dictionary = library.tutorial_lesson("tip06_tonight_changes_rooms")
	var numbers_lesson: Dictionary = library.tutorial_lesson("tip06_numbers_book")
	overlay.set_lessons([delivery_lesson])
	overlay.restore_seen({})
	overlay.evaluate_at_boundary(_environment_context())
	if overlay.active_lesson_id() != "tip06_delivery_route":
		failures.append("Normal-tip handoff fixture did not begin with active delivery advice.")
	if overlay.ok_button == null or overlay.ok_button.mouse_filter != Control.MOUSE_FILTER_STOP:
		failures.append("Normal-run advice lost its clickable explicit dismiss control.")
	if not _normal_tip_pointer_blockers(overlay, overlay.ok_button).is_empty():
		failures.append("Normal-run advice was not pointer-transparent over real room and surface controls.")
	# Production activation reports the object to the input guard before focus
	# updates the public context. The guard may dismiss existing advice, but it
	# must not select and mark an intermediate room tip in that same physical
	# activation.
	overlay.set_lessons([delivery_lesson, scenario_lesson, numbers_lesson])
	var guard_consumed := overlay.notify_action("numbers:book")
	if guard_consumed \
			or not overlay.active_lesson_id().is_empty() \
			or bool(overlay.seen.get("tip06_tonight_changes_rooms", false)) \
			or bool(overlay.seen.get("tip06_numbers_book", false)):
		failures.append("The activation guard selected or marked unseen contextual advice before the real focus boundary.")
	host.current_context_mode = "numbers"
	host.pending_event_choice_popup_snapshot = {"popup_type": "numbers_surface"}
	var focus_consumed := overlay.notify_action("focus:numbers:book")
	if focus_consumed \
			or overlay.active_lesson_id() != "tip06_tonight_changes_rooms" \
			or not bool(overlay.seen.get("tip06_tonight_changes_rooms", false)) \
			or bool(overlay.seen.get("tip06_numbers_book", false)):
		failures.append("The genuine focus boundary did not admit exactly one visible contextual tip in catalog order.")
	if overlay.ok_button == null or overlay.ok_button.mouse_filter != Control.MOUSE_FILTER_STOP:
		failures.append("Replacement normal-run advice lost its clickable explicit dismiss control.")
	if not _normal_tip_pointer_blockers(overlay, overlay.ok_button).is_empty():
		failures.append("Replacement normal-run advice stopped being pointer-transparent after the genuine focus boundary.")
	var first_surface_action_consumed := overlay.notify_action("numbers:digit")
	if first_surface_action_consumed \
			or not overlay.active_lesson_id().is_empty() \
			or bool(overlay.seen.get("tip06_numbers_book", false)):
		failures.append("The first Numbers control silently admitted replacement advice in the notification that dismissed the visible tip.")
	overlay.evaluate_at_boundary(_environment_context())
	if overlay.active_lesson_id() != "tip06_numbers_book" or not bool(overlay.seen.get("tip06_numbers_book", false)):
		failures.append("A later genuine refresh boundary did not admit the deferred Numbers advice.")
	var slip_consumed := overlay.notify_action("numbers:write_slip")
	if slip_consumed or not overlay.active_lesson_id().is_empty():
		failures.append("Normal Numbers advice consumed or remained over the ordinary slip action instead of yielding non-modally.")
	host.free()


static func _normal_tip_pointer_blockers(node: Node, dismiss_button: BaseButton) -> Array:
	var blockers: Array = []
	if node == null:
		return ["missing_panel"]
	if node is Control and node != dismiss_button and (node as Control).mouse_filter != Control.MOUSE_FILTER_IGNORE:
		blockers.append((node as Control).name)
	for child in node.get_children():
		blockers.append_array(_normal_tip_pointer_blockers(child, dismiss_button))
	return blockers


static func _check_discovery_boundary(library: Variant, failures: Array) -> void:
	for lesson_id in LESSON_IDS:
		var lesson: Dictionary = library.tutorial_lesson(str(lesson_id))
		var searchable := JSON.stringify(lesson).to_lower()
		for blocker in DISCOVERY_BLOCKERS:
			if searchable.contains(str(blocker)):
				failures.append("Discovery-gated phrase '%s' leaked into %s." % [str(blocker), str(lesson_id)])


static func _check_contextual_determinism_and_placement(lesson: Dictionary, encounter: Dictionary, failures: Array) -> void:
	if lesson.has("timing") or _dict(lesson.get("trigger", {})).has("wall_clock"):
		failures.append("%s uses time instead of an action-boundary trigger." % str(lesson.get("id", "")))
	var first_trigger := CoachViewModelScript.trigger_matches(lesson, encounter, {}, true)
	var second_trigger := CoachViewModelScript.trigger_matches(lesson, encounter.duplicate(true), {}, true)
	if first_trigger != second_trigger:
		failures.append("%s trigger was not deterministic for the same public context." % str(lesson.get("id", "")))
	for size_value in [Vector2(1280, 720), Vector2(854, 480)]:
		var size: Vector2 = size_value
		for reduce_motion in [false, true]:
			var context := encounter.duplicate(true)
			context["viewport_rect"] = Rect2(Vector2.ZERO, size)
			context["small_screen"] = size.x < 1000.0
			context["reduce_motion"] = reduce_motion
			context["anchor_rects"] = _contextual_anchor_rects(lesson, size)
			var model := CoachViewModelScript.build(lesson, context)
			var viewport := Rect2(Vector2.ZERO, size)
			var bubble := CoachViewModelScript._rect(model.get("bubble_rect", {}))
			var anchor := CoachViewModelScript._rect(model.get("anchor_rect", {}))
			if not bool(model.get("anchor_found", false)) or not viewport.encloses(bubble):
				failures.append("%s placement escaped or lost its pointer at %dx%d reduced=%s." % [str(lesson.get("id", "")), int(size.x), int(size.y), str(reduce_motion)])
			if anchor.has_area() and bubble.intersects(anchor):
				failures.append("%s placement covered its target at %dx%d reduced=%s." % [str(lesson.get("id", "")), int(size.x), int(size.y), str(reduce_motion)])


static func _check_contextual_double_notify(lesson: Dictionary, encounter: Dictionary, failures: Array) -> void:
	var host := PublicHostFixture.new()
	var overlay := CoachOverlayScript.new()
	host.add_child(overlay)
	overlay.set_lessons([lesson])
	overlay.restore_seen({})
	overlay.evaluate_at_boundary(encounter)
	var lesson_id := str(lesson.get("id", ""))
	if overlay.active_lesson_id() != lesson_id:
		failures.append("%s did not activate for its double-notify fixture." % lesson_id)
	else:
		var first_consumed := overlay.notify_action("fixture:ordinary_action")
		var second_consumed := overlay.notify_action("fixture:ordinary_action")
		if first_consumed or second_consumed or not overlay.active_lesson_id().is_empty() or not bool(overlay.seen.get(lesson_id, false)):
			failures.append("%s consumed or repeated an ordinary action across its double-notify boundary." % lesson_id)
	host.free()


static func _check_crew_ignoring_run(library: Variant, failures: Array) -> void:
	var ignored_context := _environment_context({"scenario_active": false, "delivery_active": false, "crew_job_resolved": false, "flags": {}}, {"numbers_encountered": false}, {"last_action_id": "map"})
	for lesson_id in ["tip06_delivery_route", "tip06_crew_standing", "tip06_back_room_poker", "tip06_true_rumor", "tip06_police_sweep"]:
		if CoachViewModelScript.trigger_matches(library.tutorial_lesson(lesson_id), ignored_context, {}, true):
			failures.append("Crew-ignoring run unexpectedly triggered %s." % lesson_id)


static func _contextual_anchor_rects(lesson: Dictionary, viewport_size: Vector2) -> Dictionary:
	var anchor := _dict(lesson.get("anchor", {}))
	var kind := str(anchor.get("kind", ""))
	var id := str(anchor.get("id", ""))
	var rect := Rect2(Vector2(viewport_size.x * 0.44, viewport_size.y * 0.42), Vector2(maxf(72.0, viewport_size.x * 0.12), maxf(44.0, viewport_size.y * 0.10)))
	var result := {"interactable_objects": {}, "hud_elements": {}, "surface_actions": {}}
	var group := "interactable_objects" if kind == "interactable_object" else "hud_elements" if kind == "hud_element" else "surface_actions"
	var group_rects: Dictionary = result[group]
	group_rects[id] = rect
	for additional_id in lesson.get("additional_anchor_ids", []):
		group_rects[str(additional_id)] = Rect2(rect.position + Vector2(rect.size.x + 12.0, 0.0), rect.size)
	result[group] = group_rects
	return result


static func _environment_context(run_values: Dictionary = {}, ui_values: Dictionary = {}, action_values: Dictionary = {}) -> Dictionary:
	var run_context := {"tutorial": false}
	for key in run_values.keys():
		run_context[key] = run_values.get(key)
	return {"screen": "ENVIRONMENT", "run": run_context, "ui": ui_values.duplicate(true), "action": action_values.duplicate(true)}


static func _game_context(game_id: String) -> Dictionary:
	return {"screen": "GAME", "game_id": game_id, "run": {"tutorial": false}, "ui": {}}


static func _dict(value: Variant) -> Dictionary:
	return (value as Dictionary) if typeof(value) == TYPE_DICTIONARY else {}
