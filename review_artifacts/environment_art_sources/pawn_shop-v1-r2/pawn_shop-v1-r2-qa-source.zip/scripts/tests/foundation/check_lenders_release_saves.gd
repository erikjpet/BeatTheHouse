extends "res://scripts/tests/foundation/check_items_events_world.gd"

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")
const EnvironmentPlacementScript := preload("res://scripts/core/environment_placement.gd")
const EnvironmentSlotBinderScript := preload("res://scripts/core/environment_slot_binder.gd")

const RunReportViewModelScript := preload("res://scripts/ui/run_report_view_model.gd")
const RunReportTimelineCanvasScript := preload("res://scripts/ui/run_report_timeline_canvas.gd")
const CageCounterViewModelScript := preload("res://scripts/ui/cage_counter_view_model.gd")
const EnvironmentInteractionViewModelScript := preload("res://scripts/ui/environment_interaction_view_model.gd")
const FoundationActionViewModelScript := preload("res://scripts/ui/foundation_action_view_model.gd")
const LendersBlackjackActionAuthorityScript := preload("res://scripts/core/blackjack_action_authority.gd")
const StaffBlackjackGameScript := preload("res://scripts/games/blackjack.gd")
const StaffBaccaratGameScript := preload("res://scripts/games/baccarat.gd")
const StaffRouletteGameScript := preload("res://scripts/games/roulette.gd")
const StaffBarDiceGameScript := preload("res://scripts/games/bar_dice.gd")
const SaveFuzzTableGameAuthorityDriverScript := preload("res://scripts/tests/foundation/table_game_authority_test_driver.gd")
const GrandCasinoDuelModelScript := preload("res://scripts/core/grand_casino_duel_model.gd")
const MusicDeliveryIndexScript := preload("res://scripts/core/music_delivery_index.gd")
const MusicLayerChoreographyScript := preload("res://scripts/ui/music_layer_choreography.gd")
const MusicOutcomeDirectorModelScript := preload("res://scripts/ui/music_outcome_director_model.gd")


class BlackjackChipStakeRangeGame:
	func get_id() -> String:
		return "blackjack"


class BlackjackChipStakeRangeHost:
	var run_state: RunState
	var current_game = BlackjackChipStakeRangeGame.new()
	var presented_cash := 0

	func _presented_bankroll() -> int:
		return presented_cash


class EmbeddedRefreshFixtureGame:
	extends GameModule

	var realtime_probe_mode := ""
	var realtime_patch_calls := 0
	var surface_serial := 0

	func _init() -> void:
		definition = {
			"id": "embedded_refresh_fixture", "display_name": "Embedded Refresh Fixture", "family": "slot",
			"legal_actions": [{"id": "fixture_action", "label": "Act", "min_stake": 1}], "cheat_actions": [],
		}

	func wager_cost_for_context(_action_id: String, _stake: int, _run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> int:
		return 0

	func resolve_with_context(_action_id: String, _stake: int, _run_state: RunState, environment: Dictionary, _rng: RngStream, _ui_state: Dictionary = {}) -> Dictionary:
		surface_serial += 1
		var deltas := GameModule.empty_result_deltas()
		deltas["messages"] = ["Embedded refresh fixture %d." % surface_serial]
		var result := GameModule.build_action_result({
			"ok": true, "source_id": get_id(), "game_id": get_id(), "action_id": "fixture_action", "action_kind": "legal",
			"stake": 0, "environment_id": str(environment.get("id", "")), "deltas": deltas,
			"message": "Embedded refresh fixture %d." % surface_serial,
		})
		result["host_apply_result"] = false
		result["preserve_surface_ui_state"] = true
		return result

	func surface_state(_run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> Dictionary:
		return {
			"game_id": get_id(), "surface_renderer": "slot_machine", "surface_life": "animated",
			"surface_cast": "machine", "surface_embeds_outcomes": true, "runtime_serial": surface_serial,
			"surface_realtime_state_refresh": not realtime_probe_mode.is_empty(),
		}

	func surface_realtime_patch_preserves_host_state() -> bool:
		return true

	func surface_realtime_state_patch(_run_state: RunState, _environment: Dictionary, ui_state: Dictionary, _current_surface_state: Dictionary = {}) -> Dictionary:
		if realtime_probe_mode != "advance":
			return {}
		realtime_patch_calls += 1
		surface_serial += 1
		return {"runtime_serial": surface_serial, "realtime_fixture_clock_msec": int(ui_state.get("surface_time_msec", -1))}

	func surface_action_command(surface_action: String, _index: int, _confirm_requested: bool, ui_state: Dictionary, _run_state: RunState, _environment: Dictionary) -> Dictionary:
		if surface_action != "fixture_complete":
			return {"handled": false}
		return GameModule.surface_command({
			"ui_state": ui_state.duplicate(true), "action_id": "fixture_action", "action_kind": "legal",
			"resolve": true, "direct_resolve": true, "skip_stake_validation": true,
			"preserve_surface_ui_state": true, "message": "Fixture action committed.",
		})


class EmbeddedRefreshProbeHost:
	extends FoundationMain

	var embedded_probe_log: Array = []
	var embedded_probe_interrupt_saw_pending_autosave := false
	var embedded_probe_interrupt_environment_id := ""
	var embedded_probe_time_msec := -1

	func _environment_simulation_time_msec() -> int:
		return embedded_probe_time_msec if embedded_probe_time_msec >= 0 else super._environment_simulation_time_msec()

	func _prepare_foundation_run_save() -> void:
		embedded_probe_log.append("autosave_prepare")
		super._prepare_foundation_run_save()

	func _apply_post_action_environment_interrupt(source: String, forced_travel_just_armed: bool = false) -> bool:
		embedded_probe_log.append("post_action_interrupt")
		embedded_probe_interrupt_saw_pending_autosave = pending_autosave
		embedded_probe_interrupt_environment_id = str(run_state.current_environment.get("id", "")) if run_state != null else ""
		return super._apply_post_action_environment_interrupt(source, forced_travel_just_armed)

	func _refresh_after_embedded_game_action(embeds_result_feedback: bool = false, action_boundary_preflight_complete: bool = false) -> void:
		embedded_probe_log.append("embedded_refresh")
		super._refresh_after_embedded_game_action(embeds_result_feedback, action_boundary_preflight_complete)

	func _refresh_active_item_slot() -> void:
		embedded_probe_log.append("active_item")
		super._refresh_active_item_slot()

	func _refresh_talk_dock() -> void:
		embedded_probe_log.append("talk_dock")
		super._refresh_talk_dock()

	func _update_procedural_music() -> void:
		embedded_probe_log.append("music")
		super._update_procedural_music()

	func _schedule_game_coach_refresh_after_draw() -> void:
		embedded_probe_log.append("coach_schedule")
		super._schedule_game_coach_refresh_after_draw()

	func _refresh_coach_at_boundary(surface_transition_wait_satisfied: bool = false) -> void:
		embedded_probe_log.append("coach_execute:%s" % str(surface_transition_wait_satisfied))
		super._refresh_coach_at_boundary(surface_transition_wait_satisfied)


func _check_run_report_foundation(failures: Array) -> void:
	var outcome_registry := RunReportViewModelScript.load_outcome_registry()
	var terminal_cases: Array = []
	var failure_reasons := RunStateScript.terminal_failure_reasons()
	var expected_failure_reasons := [
		RunStateScript.FAILURE_BANKROLL_ZERO,
		RunStateScript.FAILURE_STRANDED,
		RunStateScript.FAILURE_POLICE_CAPTURE,
		RunStateScript.FAILURE_CASINO_TAKEN_OUT_BACK,
		RunStateScript.FAILURE_ABANDONED,
	]
	if failure_reasons != expected_failure_reasons:
		failures.append("Terminal report registry did not cover all five producible failure reasons: %s." % JSON.stringify(failure_reasons))
	for failure_reason in failure_reasons:
		terminal_cases.append({"status": RunStateScript.RUN_STATUS_FAILED, "reason": str(failure_reason)})
	for definition_value in RunStateScript.terminal_victory_route_definitions():
		var definition: Dictionary = definition_value
		var runtime_route := str(definition.get("runtime_id", ""))
		var profile_route := str(definition.get("profile_id", ""))
		var production_run: RunState = RunStateScript.new()
		production_run.start_new("META06-ROUTE-%s" % profile_route)
		production_run.run_status = RunStateScript.RUN_STATUS_ENDED
		production_run.narrative_flags["demo_victory"] = true
		production_run.narrative_flags["demo_victory_route"] = runtime_route
		if str(production_run.act_two_seam_payload().get("victory_route", "")) != profile_route:
			failures.append("Terminal route registry diverged from the production Act-seam path: %s." % JSON.stringify(definition))
		if runtime_route == RunStateScript.CREW_HEIST_ROUTE:
			for heist_outcome in RunStateScript.terminal_crew_heist_outcomes():
				terminal_cases.append({"status": RunStateScript.RUN_STATUS_ENDED, "route": runtime_route, "heist_outcome": str(heist_outcome)})
		else:
			terminal_cases.append({"status": RunStateScript.RUN_STATUS_ENDED, "route": runtime_route})
	var report_aliases := RunStateScript.terminal_report_route_aliases()
	var report_alias_ids: Array = report_aliases.keys()
	report_alias_ids.sort()
	for alias_value in report_alias_ids:
		terminal_cases.append({"status": RunStateScript.RUN_STATUS_ENDED, "route": str(alias_value), "report_only": true})
	for terminal_case in terminal_cases:
		var terminal_data := {
			"run_status": str(terminal_case.get("status", "")),
			"run_failure_reason": str(terminal_case.get("reason", "")),
			"run_failure_message": "",
			"narrative_flags": {
				"demo_victory": str(terminal_case.get("status", "")) == RunStateScript.RUN_STATUS_ENDED,
				"demo_victory_route": str(terminal_case.get("route", "")),
				"crew_heist_outcome": str(terminal_case.get("heist_outcome", "")),
			},
			"current_environment": {"display_name": "Terminal Fixture"},
			"game_clock_minutes": RunStateScript.GAME_CLOCK_START_MINUTE,
		}
		var terminal_outcome := RunReportViewModelScript.build_outcome(terminal_data, outcome_registry)
		if str(terminal_outcome.get("title", "")).is_empty() or str(terminal_outcome.get("how", "")).is_empty() or str(terminal_outcome.get("icon_path", "")).is_empty() or not ResourceLoader.exists(str(terminal_outcome.get("icon_path", ""))):
			failures.append("Run report did not map a finished-run route to complete renderable copy: %s -> %s." % [JSON.stringify(terminal_case), JSON.stringify(terminal_outcome)])

	var ledger_fixture := {
		"run_status": RunStateScript.RUN_STATUS_FAILED,
		"game_clock_minutes": RunStateScript.GAME_CLOCK_START_MINUTE + 3000,
		"narrative_flags": {"profile_games_played": {"craps": 3, "coin_pusher": 2, "crew_draw_poker": 4}, "profile_delivery_runs_completed": 2, "profile_delivery_packages_lost": 1},
		"crew_state": {
			"trust": {"crew_rook": 20, "crew_lucky": 40},
			"jobs": {"job_good": {"status": "resolved", "outcome": "success"}, "job_left": {"status": "resolved", "outcome": "abandoned"}},
			"crew_heist": {"plan_id": "the_count", "status": "setup", "x": {"m": "crew_lucky", "w": 9, "e": ["pattern"], "c": false}},
		},
		"world_map": {
			"visited_path": ["bar", "corner_store"],
			"nodes": [
				{"id": "bar", "environment": {"scenario_state": {"id": "bar_wake", "display_name": "The Wake"}}},
				{"id": "corner_store", "environment": {"scenario_state": {"id": "corner_store_aftermath", "display_name": "The Aftermath"}}},
			],
		},
		"current_environment": {"world_node_id": "corner_store", "scenario_state": {"id": "corner_store_aftermath", "display_name": "The Aftermath"}},
		"story_log": [
			{"type": "police_sweep_encounter"},
			{"type": "event", "event_id": "scenario_aftermath_fence_offer", "choice_id": "take"},
		],
		"town_state": {"living_world": {"heard_by_node": {"corner_store": {"id": "rumor:scenario:corner_store"}, "pawn_shop": {"id": "rumor:scenario:pawn_shop"}}}},
		"numbers_state": {
			"slips": [{"status": "settled", "won": true}, {"status": "settled", "won": false}, {"status": "confiscated"}],
			"fix_state": {"status": "completed"},
		},
	}
	var failed_ledger := RunReportViewModelScript.build_release_ledger(ledger_fixture)
	var failed_ledger_text := JSON.stringify(failed_ledger).to_lower()
	if failed_ledger_text.contains("the turn") or failed_ledger_text.contains("traitor") or failed_ledger_text.contains("grievance") or failed_ledger_text.contains("pattern") or failed_ledger_text.contains("\"w\":9"):
		failures.append("Unresolved/failed run ledger leaked Turn or hidden heist state: %s." % JSON.stringify(failed_ledger))
	var failed_world := JsonCoerceScript._copy_dict(failed_ledger.get("world", {}))
	var failed_numbers := JsonCoerceScript._copy_dict(failed_ledger.get("numbers", {}))
	if JsonCoerceScript._copy_array(failed_world.get("scenarios", [])).size() != 2 or JsonCoerceScript._copy_array(failed_world.get("notable_outcomes", [])).size() != 1 or int(failed_world.get("sweeps_encountered", 0)) != 1 or int(failed_world.get("rumors_proved_true", 0)) != 1 \
		or int(failed_numbers.get("slips_placed", 0)) != 3 or int(failed_numbers.get("hits", 0)) != 1 or not bool(failed_numbers.get("rig_route_used", false)) or JsonCoerceScript._copy_array(failed_ledger.get("games", [])).size() != 3:
		failures.append("Run report did not aggregate the complete visible 0.6 ledger at terminal boundary: %s." % JSON.stringify(failed_ledger))
	var midnight_ledger := RunReportViewModelScript.build_release_ledger({"game_clock_minutes": 1440})
	if int(JsonCoerceScript._copy_dict(midnight_ledger.get("world", {})).get("nights_survived", 0)) != 1:
		failures.append("Run report did not record the first survived night at the existing calendar-day boundary.")
	var meeting_run: RunState = RunStateScript.new()
	meeting_run.start_new("META06-MEETING-BOUNDARY")
	meeting_run.crew_trust_by_member["crew_rook"] = CrewStateModelScript.rank_threshold("marker")
	meeting_run.crew_trust_by_member["crew_lucky"] = CrewStateModelScript.rank_threshold("associate")
	meeting_run.crew_trust_by_member["crew_bishop"] = CrewStateModelScript.rank_threshold("marker") - 1
	var production_met: Array = meeting_run.call("_crew_heist_met_members")
	var reported_members := JsonCoerceScript._copy_array(JsonCoerceScript._copy_dict(RunReportViewModelScript.build_release_ledger(meeting_run.to_dict()).get("crew", {})).get("members_met", []))
	var reported_member_ids: Array = []
	for member in reported_members:
		reported_member_ids.append(str(JsonCoerceScript._copy_dict(member).get("id", "")))
	if reported_member_ids != production_met or reported_member_ids != ["crew_rook", "crew_lucky"]:
		failures.append("Run report member detection diverged from the production rank!=stranger meeting boundary: production=%s report=%s." % [JSON.stringify(production_met), JSON.stringify(reported_member_ids)])
	var completed_ledger_fixture := ledger_fixture.duplicate(true)
	completed_ledger_fixture["run_status"] = RunStateScript.RUN_STATUS_ENDED
	completed_ledger_fixture["narrative_flags"]["demo_victory"] = true
	completed_ledger_fixture["narrative_flags"]["demo_victory_route"] = "crew_heist"
	completed_ledger_fixture["narrative_flags"]["demo_victory_message"] = "The Turn broke the score. The crew left before the room could count twice."
	completed_ledger_fixture["crew_state"]["crew_heist"]["status"] = "completed"
	var completed_ledger := RunReportViewModelScript.build_release_ledger(completed_ledger_fixture)
	if not str(JsonCoerceScript._copy_dict(completed_ledger.get("crew", {})).get("turn_resolution", "")).contains("The Turn"):
		failures.append("A completed heist did not surface its contract-approved ending-only Turn resolution.")

	var delivery_reporting_run: RunState = RunStateScript.new()
	delivery_reporting_run.start_new("META06-DELIVERY-REPORTING")
	delivery_reporting_run.active_delivery_run = {"status": "resolved", "world_applied": false, "mode": "package", "run_id": "fixture:success", "resolution": {"outcome": "success", "reason": "delivered"}, "consumer_payload": {}}
	delivery_reporting_run._apply_delivery_resolution()
	delivery_reporting_run._apply_delivery_resolution()
	delivery_reporting_run.active_delivery_run = {"status": "resolved", "world_applied": false, "mode": "multi_stop", "run_id": "fixture:loss", "resolution": {"outcome": "failure", "reason": "swept"}, "consumer_payload": {}}
	delivery_reporting_run._apply_delivery_resolution()
	delivery_reporting_run.active_delivery_run = {"status": "resolved", "world_applied": false, "mode": "getaway", "run_id": "heist:fixture:getaway", "resolution": {"outcome": "success", "reason": "escaped"}, "consumer_payload": {}}
	delivery_reporting_run._apply_delivery_resolution()
	delivery_reporting_run.active_delivery_run = {"status": "resolved", "world_applied": false, "mode": "hold", "run_id": "fixture:lookout", "resolution": {"outcome": "failure", "reason": "attention"}, "consumer_payload": {}}
	delivery_reporting_run._apply_delivery_resolution()
	if int(delivery_reporting_run.narrative_flags.get("profile_delivery_runs_completed", 0)) != 1 or int(delivery_reporting_run.narrative_flags.get("profile_delivery_packages_lost", 0)) != 1:
		failures.append("Delivery reporting counters were not idempotent or counted a lookout/getaway as a package route.")
	var delivery_round_trip := delivery_reporting_run.to_dict()
	var delivery_restored: RunState = RunStateScript.new()
	delivery_restored.from_dict(delivery_round_trip)
	if int(delivery_restored.narrative_flags.get("profile_delivery_runs_completed", 0)) != 1 or int(delivery_restored.narrative_flags.get("profile_delivery_packages_lost", 0)) != 1:
		failures.append("Delivery reporting counters did not survive run save/load.")

	var run_state: RunState = RunStateScript.new()
	run_state.start_new("RUN-REPORT-FOUNDATION")
	run_state.set_environment({"id": "bar_fixture", "world_node_id": "bar", "archetype_id": "bar", "display_name": "Fixture Bar"})
	run_state.add_suspicion("report_spike", 34, "behavior", true, {"environment_id": "bar_fixture"})
	run_state.advance_environment_turns(2)
	run_state.set_environment({"id": "casino_fixture", "world_node_id": "grand_casino", "archetype_id": "grand_casino", "display_name": "Grand Casino"})
	if run_state.heat_history.size() < 3 or not bool((run_state.heat_history[-1] as Dictionary).get("transition", false)):
		failures.append("Run report heat history did not record heat changes and environment transitions.")
	if int((run_state.heat_history[-1] as Dictionary).get("game_clock_minutes", -1)) != run_state.game_clock_minutes:
		failures.append("Run report heat history did not timestamp transitions with the existing game clock.")
	if run_state.environment_history.is_empty() or int((run_state.environment_history[0] as Dictionary).get("entered_game_clock_minutes", -1)) != RunState.GAME_CLOCK_START_MINUTE or int(run_state.current_environment.get("entered_game_clock_minutes", -1)) != run_state.game_clock_minutes:
		failures.append("Run environment visits did not retain their game-clock entry times.")
	if run_state.environment_history.is_empty() or int((run_state.environment_history[0] as Dictionary).get("departed_game_clock_minutes", -1)) != run_state.game_clock_minutes:
		failures.append("RunState did not close a visit at the exact clock when the environment changed.")
	var timed_travel_run: RunState = RunStateScript.new()
	timed_travel_run.start_new("RUN-REPORT-TRAVEL-BOUNDARY")
	timed_travel_run.set_environment({"id": "source", "world_node_id": "bar", "entered_game_clock_minutes": timed_travel_run.game_clock_minutes})
	var exact_departure := timed_travel_run.game_clock_minutes
	timed_travel_run.current_environment["departed_game_clock_minutes"] = exact_departure
	timed_travel_run.advance_game_clock_minutes(23)
	timed_travel_run.set_environment({"id": "destination", "world_node_id": "grand_casino", "departed_game_clock_minutes": exact_departure - 10})
	if timed_travel_run.environment_history.is_empty() \
		or int((timed_travel_run.environment_history[0] as Dictionary).get("departed_game_clock_minutes", -1)) != exact_departure \
		or int(timed_travel_run.current_environment.get("entered_game_clock_minutes", -1)) != exact_departure + 23 \
		or timed_travel_run.current_environment.has("departed_game_clock_minutes"):
		failures.append("RunState collapsed a stamped travel departure into the destination arrival clock.")
	var saved := run_state.to_dict()
	var restored: RunState = RunStateScript.new()
	restored.from_dict(saved)
	if JSON.stringify(restored.heat_history) != JSON.stringify(run_state.heat_history):
		failures.append("Run report heat history did not survive save/load exactly.")
	var oversized: Array = []
	for index in range(600):
		oversized.append({"action_index": index, "heat_value": 100 if index == 311 else index % 47, "environment_id": "venue_%d" % int(index / 100), "environment_name": "Venue", "transition": index % 100 == 0})
	var compacted := RunStateScript.downsample_heat_history(oversized, RunStateScript.HEAT_HISTORY_COMPACT_TARGET)
	if compacted.size() > RunStateScript.HEAT_HISTORY_COMPACT_TARGET:
		failures.append("Run report heat history downsampling exceeded its compact target.")
	var preserved_peak := false
	for value in compacted:
		if int((value as Dictionary).get("action_index", -1)) == 311 and int((value as Dictionary).get("heat_value", 0)) == 100:
			preserved_peak = true
	if not preserved_peak:
		failures.append("Run report heat downsampling did not preserve an obvious spike.")

	var story := [
		{"type": "game_action", "game_id": "slot", "bankroll_delta": 120},
		{"type": "game_action", "game_id": "slot", "bankroll_delta": -20},
		{"type": "game_action", "game_id": "bar_dice", "bankroll_delta": -85},
		{"type": "item_sale", "item_id": "instant_coffee", "sale_price": 7},
		{"type": "item_purchase", "item_id": "creased_luck_card", "price": 9},
		{"type": "lender_hook", "id": "sal", "label": "Sal", "bankroll_delta": 20, "debt_changes": [{"id": "pawn_redeemed", "lender_id": "sal", "principal": 20, "balance": 22, "debt_kind": "pawn", "collateral_item_id": "instant_coffee", "collateral_item_name": "Instant Coffee"}]},
		{"type": "debt_paid", "debt_id": "pawn_redeemed", "lender_id": "sal", "collateral_item_id": "instant_coffee", "bankroll_delta": -22},
		{"type": "lender_hook", "id": "sal", "label": "Sal", "bankroll_delta": 30, "debt_changes": [{"id": "pawn_forfeit", "lender_id": "sal", "principal": 30, "balance": 33, "debt_kind": "pawn", "collateral_item_id": "creased_luck_card", "collateral_item_name": "Creased Luck Card"}]},
		{"type": "debt_default", "debt_id": "pawn_forfeit", "lender_id": "sal"},
		{"type": "lender_hook", "id": "crew", "label": "The Crew", "bankroll_delta": 50, "debt_changes": [{"id": "cash_default", "lender_id": "crew", "principal": 50, "balance": 50, "debt_kind": "cash"}]},
		{"type": "debt_default", "debt_id": "cash_default", "lender_id": "crew"},
	]
	var money := RunReportViewModelScript.build_money_rows(story, {"games": {"slot": {"display_name": "Slots"}, "bar_dice": {"display_name": "Bar Dice"}}})
	if money.is_empty() or int((money[0] as Dictionary).get("net", 0)) != 100:
		failures.append("Run report money aggregation did not net and absolute-sort scripted game results.")
	var debts := RunReportViewModelScript.build_debt_ledger([], story)
	if debts.size() != 3 or JSON.stringify(debts).find("redeemed") == -1 or JSON.stringify(debts).find("collateral kept") == -1 or JSON.stringify(debts).find("defaulted") == -1:
		failures.append("Run report debt ledger did not reconstruct paid, defaulted, redeemed, and forfeited outcomes.")
	var items := RunReportViewModelScript.build_item_fates(["instant_coffee", "instant_coffee"], [], story, {"instant_coffee": {"display_name": "Instant Coffee"}, "creased_luck_card": {"display_name": "Creased Luck Card"}})
	if int(((items.get("kept", []) as Array)[0] as Dictionary).get("count", 0)) != 2 or JSON.stringify(items).find("forfeited") == -1 or JSON.stringify(items).find("sold") == -1:
		failures.append("Run report item fate aggregation did not collapse kept duplicates or retain pawn/sale fates.")
	var take_home_data := run_state.to_dict()
	take_home_data["run_status"] = RunState.RUN_STATUS_ENDED
	take_home_data["inventory"] = ["instant_coffee", "bag", "backpack"]
	take_home_data["narrative_flags"] = {"demo_victory": true}
	take_home_data["challenge_config"] = {"mode": "standard", "completion_flag": "", "modifiers": {"meta_collection_enabled": true}}
	var take_home_reward := RunReportViewModelScript.build_take_home_item_reward(take_home_data, {
		"instant_coffee": {"display_name": "Instant Coffee", "class": "consumable"},
		"bag": {"display_name": "Bag", "class": "container", "container_capacity": 3, "asset_path": "res://assets/art/items/bag.png"},
		"backpack": {"display_name": "Backpack", "class": "container", "container_capacity": 5, "asset_path": "res://assets/art/items/backpack.png"},
	})
	if not bool(take_home_reward.get("visible", false)) or not bool(take_home_reward.get("pending", false)) or (take_home_reward.get("choices", []) as Array).size() != 2 or str(((take_home_reward.get("choices", []) as Array)[0] as Dictionary).get("id", "")) != "backpack":
		failures.append("Run report did not present earned container items as a required take-home choice.")
	var stored_take_home_flags := {"demo_victory": true}
	stored_take_home_flags[RunReportViewModelScript.TAKE_HOME_ITEM_EXTRACTED_FLAG] = true
	stored_take_home_flags[RunReportViewModelScript.TAKE_HOME_ITEM_ID_FLAG] = "backpack"
	stored_take_home_flags[RunReportViewModelScript.TAKE_HOME_ITEM_LINE_FLAG] = "Brought home Backpack."
	take_home_data["narrative_flags"] = stored_take_home_flags
	var stored_take_home_reward := RunReportViewModelScript.build_take_home_item_reward(take_home_data, {"backpack": {"display_name": "Backpack", "class": "container", "container_capacity": 5}})
	if bool(stored_take_home_reward.get("pending", true)) or str(stored_take_home_reward.get("summary_line", "")) != "Brought home Backpack.":
		failures.append("Run report did not replace the take-home selector with its stored-item confirmation.")

	var report_start_clock := RunState.GAME_CLOCK_START_MINUTE
	var timeline := RunReportViewModelScript.build_timeline(
		run_state.heat_history,
		{"visited_path": ["bar", "grand_casino"], "nodes": [{"id": "bar", "display_name": "Bar", "position": {"x": 0.1, "y": 0.4}}, {"id": "grand_casino", "display_name": "Grand Casino", "position": {"x": 0.9, "y": 0.5}}]},
		8,
		[{"type": "travel", "from_world_node_id": "bar", "to_world_node_id": "grand_casino", "departed_game_clock_minutes": report_start_clock + 16, "arrived_game_clock_minutes": report_start_clock + 24, "travel_minutes": 8}],
		report_start_clock,
		report_start_clock + 32
	)
	var boundary := RunReportViewModelScript.cursor_for_progress(timeline, 1.0)
	if not bool(timeline.get("precomputed", false)) or int(boundary.get("action_index", -1)) != 8 or int(boundary.get("leg_index", -1)) != 1:
		failures.append("Run report shared timeline did not map action, travel leg, and heat sample boundaries.")
	var route_run_data := run_state.to_dict()
	route_run_data["world_map"] = {
		"visited_path": ["home", "grand_casino"],
		"nodes": [
			{"id": "home", "display_name": "Home", "position": {"x": 0.1, "y": 0.2}},
			{"id": "bar", "display_name": "Bar", "position": {"x": 0.35, "y": 0.55}},
			{"id": "grand_casino", "display_name": "Grand Casino", "position": {"x": 0.82, "y": 0.4}},
		],
		"edges": [{"id": "home-bar", "a": "home", "b": "bar"}],
		"current_node_id": "",
	}
	route_run_data["environment_history"] = [
		# Reproduce saves made by the former boundary bug: each visit was closed at
		# the next arrival even though the travel story retained the exact clocks.
		{"id": "home_env", "world_node_id": "home", "archetype_id": "home", "display_name": "Home", "entered_game_clock_minutes": report_start_clock, "departed_game_clock_minutes": report_start_clock + 8},
		{"id": "bar_env", "world_node_id": "bar", "archetype_id": "bar", "display_name": "Bar", "entered_game_clock_minutes": report_start_clock + 8, "departed_game_clock_minutes": report_start_clock + 16},
		{"id": "casino_env", "world_node_id": "grand_casino", "archetype_id": "grand_casino", "display_name": "Grand Casino", "entered_game_clock_minutes": report_start_clock + 16, "departed_game_clock_minutes": report_start_clock + 24},
	]
	route_run_data["current_environment"] = {"id": "bar_revisit_env", "world_node_id": "bar", "archetype_id": "bar", "display_name": "Bar Revisit", "entered_game_clock_minutes": report_start_clock + 24}
	route_run_data["story_log"] = [
		{"type": "travel", "from_world_node_id": "home", "to_world_node_id": "bar", "departed_game_clock_minutes": report_start_clock + 4, "arrived_game_clock_minutes": report_start_clock + 8, "travel_minutes": 4},
		{"type": "travel", "from_world_node_id": "bar", "to_world_node_id": "grand_casino", "departed_game_clock_minutes": report_start_clock + 12, "arrived_game_clock_minutes": report_start_clock + 16, "travel_minutes": 4},
		{"type": "travel", "from_world_node_id": "grand_casino", "to_world_node_id": "bar", "departed_game_clock_minutes": report_start_clock + 20, "arrived_game_clock_minutes": report_start_clock + 24, "travel_minutes": 4},
	]
	route_run_data["heat_history"] = [
		{"action_index": 0, "game_clock_minutes": report_start_clock, "heat_value": 0, "world_node_id": "home", "transition": true},
		{"action_index": 1, "game_clock_minutes": report_start_clock + 8, "heat_value": 2, "world_node_id": "bar", "transition": true},
		{"action_index": 2, "game_clock_minutes": report_start_clock + 16, "heat_value": 5, "world_node_id": "grand_casino", "transition": true},
		{"action_index": 3, "game_clock_minutes": report_start_clock + 24, "heat_value": 7, "world_node_id": "bar", "transition": true},
	]
	route_run_data["game_clock_minutes"] = report_start_clock + 28
	var route_report := RunReportViewModelScript.build(route_run_data)
	var route_timeline := JsonCoerceScript._copy_dict(route_report.get("timeline", {}))
	var route_path := JsonCoerceScript._copy_array(route_timeline.get("visited_node_ids", []))
	if JSON.stringify(route_path) != JSON.stringify(["home", "bar", "grand_casino", "bar"]):
		failures.append("Run report route reconstruction did not preserve authoritative visits/revisit order: %s." % JSON.stringify(route_path))
	var route_segments: Array = route_timeline.get("replay_segments", []) if typeof(route_timeline.get("replay_segments", [])) == TYPE_ARRAY else []
	var travel_segment_count := 0
	var route_travel_clocks: Array = []
	for segment_value in route_segments:
		if typeof(segment_value) == TYPE_DICTIONARY and str((segment_value as Dictionary).get("kind", "")) == "travel":
			travel_segment_count += 1
			route_travel_clocks.append([
				int((segment_value as Dictionary).get("start_game_clock_minutes", -1)),
				int((segment_value as Dictionary).get("end_game_clock_minutes", -1)),
			])
	var route_map := JsonCoerceScript._copy_dict(route_report.get("map_snapshot", {}))
	if travel_segment_count != 3 or JsonCoerceScript._copy_array(route_map.get("route_path_geometry", [])).size() != 3 or JsonCoerceScript._copy_array(route_map.get("nodes", [])).size() != 3:
		failures.append("Run report map did not render the full movement path with unique nodes and all travel legs: segments=%d geometry=%d nodes=%d." % [travel_segment_count, JsonCoerceScript._copy_array(route_map.get("route_path_geometry", [])).size(), JsonCoerceScript._copy_array(route_map.get("nodes", [])).size()])
	if JSON.stringify(route_travel_clocks) != JSON.stringify([
		[report_start_clock + 4, report_start_clock + 8],
		[report_start_clock + 12, report_start_clock + 16],
		[report_start_clock + 20, report_start_clock + 24],
	]):
		failures.append("Run report did not recover animated travel intervals from the exact story clocks: %s." % JSON.stringify(route_travel_clocks))

	# Multi-day reports must use the compact visit ledger directly. Heat samples
	# and story rows are intentionally sparse here to reproduce the former bug
	# that stretched the apartment across most of the run.
	var multi_day_end := report_start_clock + 2880
	var multi_day_data := run_state.to_dict()
	multi_day_data["world_map"] = {
		"visited_path": ["apartment", "gas_station_casino", "motel", "grand_casino"],
		"nodes": [
			{"id": "apartment", "display_name": "Apartment", "position": {"x": 0.1, "y": 0.2}},
			{"id": "gas_station_casino", "display_name": "Gas Station Casino", "position": {"x": 0.3, "y": 0.6}},
			{"id": "motel", "display_name": "Motel", "position": {"x": 0.55, "y": 0.35}},
			{"id": "grand_casino", "display_name": "Grand Casino", "position": {"x": 0.85, "y": 0.5}},
		],
		"current_node_id": "grand_casino",
	}
	multi_day_data["environment_history"] = [
		{"id": "apartment_001", "world_node_id": "apartment", "display_name": "Apartment", "entered_game_clock_minutes": report_start_clock, "departed_game_clock_minutes": report_start_clock + 180},
		{"id": "gas_002", "world_node_id": "gas_station_casino", "display_name": "Gas Station Casino", "entered_game_clock_minutes": report_start_clock + 240, "departed_game_clock_minutes": report_start_clock + 780},
		{"id": "motel_003", "world_node_id": "motel", "display_name": "Motel", "entered_game_clock_minutes": report_start_clock + 820, "departed_game_clock_minutes": report_start_clock + 1980},
	]
	multi_day_data["current_environment"] = {"id": "grand_004", "world_node_id": "grand_casino", "display_name": "Grand Casino", "entered_game_clock_minutes": report_start_clock + 2040}
	multi_day_data["story_log"] = []
	multi_day_data["heat_history"] = [
		{"action_index": 0, "game_clock_minutes": report_start_clock, "heat_value": 0, "world_node_id": "apartment", "environment_name": "Apartment", "transition": true},
		{"action_index": 20, "game_clock_minutes": report_start_clock + 500, "heat_value": 18, "world_node_id": "gas_station_casino", "environment_name": "Gas Station Casino", "transition": false},
		{"action_index": 80, "game_clock_minutes": report_start_clock + 2500, "heat_value": 42, "world_node_id": "grand_casino", "environment_name": "Grand Casino", "transition": false},
	]
	multi_day_data["event_cadence"] = {"action_index": 100}
	multi_day_data["suspicion"] = {"level": 42}
	multi_day_data["game_clock_minutes"] = multi_day_end
	var multi_day_timeline := JsonCoerceScript._copy_dict(RunReportViewModelScript.build(multi_day_data).get("timeline", {}))
	var multi_day_segments := JsonCoerceScript._copy_array(multi_day_timeline.get("replay_segments", []))
	var expected_segment_clocks := [
		["dwell", "apartment", report_start_clock, report_start_clock + 180],
		["travel", "", report_start_clock + 180, report_start_clock + 240],
		["dwell", "gas_station_casino", report_start_clock + 240, report_start_clock + 780],
		["travel", "", report_start_clock + 780, report_start_clock + 820],
		["dwell", "motel", report_start_clock + 820, report_start_clock + 1980],
		["travel", "", report_start_clock + 1980, report_start_clock + 2040],
		["dwell", "grand_casino", report_start_clock + 2040, multi_day_end],
	]
	if multi_day_segments.size() != expected_segment_clocks.size():
		failures.append("Multi-day run report did not retain every exact dwell/travel segment: %s." % JSON.stringify(multi_day_segments))
	else:
		for index in range(expected_segment_clocks.size()):
			var expected: Array = expected_segment_clocks[index]
			var actual: Dictionary = multi_day_segments[index]
			if str(actual.get("kind", "")) != str(expected[0]) \
				or (str(expected[1]) != "" and str(actual.get("node_id", "")) != str(expected[1])) \
				or int(actual.get("start_game_clock_minutes", -1)) != int(expected[2]) \
				or int(actual.get("end_game_clock_minutes", -1)) != int(expected[3]):
				failures.append("Multi-day run report distorted segment %d: expected=%s actual=%s." % [index, JSON.stringify(expected), JSON.stringify(actual)])
				break
	var multi_day_heat := JsonCoerceScript._copy_array(multi_day_timeline.get("heat_samples", []))
	if multi_day_heat.is_empty() or int((multi_day_heat[-1] as Dictionary).get("game_clock_minutes", -1)) != multi_day_end or not is_equal_approx(float((multi_day_heat[-1] as Dictionary).get("progress", -1.0)), 1.0):
		failures.append("Multi-day run report did not extend the final heat state through the exact run end time.")
	var step_canvas: RunReportTimelineCanvas = RunReportTimelineCanvasScript.new()
	step_canvas.size = Vector2(400.0, 120.0)
	step_canvas.set_timeline({"heat_samples": [
		{"progress": 0.0, "heat_value": 10},
		{"progress": 0.5, "heat_value": 60},
		{"progress": 1.0, "heat_value": 60},
	]})
	var step_points: PackedVector2Array = step_canvas.heat_points
	if step_points.size() < 5 \
		or not is_equal_approx(step_points[1].y, step_points[0].y) \
		or not is_equal_approx(step_points[1].x, step_points[2].x) \
		or is_equal_approx(step_points[1].y, step_points[2].y):
		failures.append("Run report heat graph interpolated diagonally instead of applying heat at its recorded event time.")
	step_canvas.free()
	var missing_heat_save := run_state.to_dict()
	missing_heat_save["heat_history"] = []
	missing_heat_save["game_clock_minutes"] = multi_day_end
	var restored_missing_heat: RunState = RunStateScript.new()
	restored_missing_heat.from_dict(missing_heat_save)
	if restored_missing_heat.heat_history.is_empty() or int((restored_missing_heat.heat_history[0] as Dictionary).get("game_clock_minutes", -1)) != multi_day_end:
		failures.append("Legacy save repair timestamped missing heat history at Day 1 instead of the restored run clock.")

	var registry := RunReportViewModelScript.load_outcome_registry()
	var base_data := run_state.to_dict()
	for reason in [RunState.FAILURE_BANKROLL_ZERO, RunState.FAILURE_STRANDED, RunState.FAILURE_POLICE_CAPTURE, RunState.FAILURE_CASINO_TAKEN_OUT_BACK, RunState.FAILURE_ABANDONED]:
		base_data["run_status"] = RunState.RUN_STATUS_FAILED
		base_data["run_failure_reason"] = reason
		base_data["run_failure_message"] = "Fixture ending for %s." % reason
		var outcome := RunReportViewModelScript.build_outcome(base_data, registry)
		if str(outcome.get("icon_key", "")).is_empty() or str(outcome.get("title", "")).is_empty() or str(outcome.get("how", "")).is_empty() or str(outcome.get("where", "")).find("Fixture Bar") == -1 and str(outcome.get("where", "")).find("Grand Casino") == -1:
			failures.append("Run report failure outcome %s missed its icon/title/where/how contract." % reason)
	for route in [RunState.GRAND_CASINO_HIGH_ROLLER_EVENT_ID, RunState.GRAND_CASINO_SHOWDOWN_ROUTE]:
		base_data["run_status"] = RunState.RUN_STATUS_ENDED
		base_data["narrative_flags"] = {"demo_victory": true, "demo_victory_route": route, "demo_victory_message": "Fixture victory."}
		var outcome := RunReportViewModelScript.build_outcome(base_data, registry)
		if str(outcome.get("icon_key", "")).is_empty() or not bool(outcome.get("won", false)) or str(outcome.get("where", "")).is_empty():
			failures.append("Run report victory route %s missed its distinct outcome contract." % route)

func _check_suspicion_security_foundation(failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("SUSPICION-SECURITY")
	var game := GameModule.new()
	game.setup({
		"id": "security_pressure_game",
		"display_name": "Security Pressure Game",
		"family": "fixture",
		"legal_actions": [{"id": "legal_fixture", "label": "Play Clean", "win_chance": 50, "payout_mult": 2}],
		"cheat_actions": [{"id": "risky_fixture", "label": "Palm The Card", "win_chance": 70, "payout_mult": 2, "suspicion_delta": 2}],
	})
	var environment := {
		"id": "security_pressure_environment",
		"kind": "casino",
		"tier": 1,
		"economic_profile": {
			"stake_floor": 1,
			"stake_ceiling": 20,
		},
	}
	var quiet_actions := game.actions(run_state, environment)
	var quiet_cheat_actions: Array = quiet_actions.get("cheat_actions", [])
	if quiet_cheat_actions.is_empty():
		failures.append("Security pressure fixture did not expose a risky action.")
		return
	var quiet_risk := int((quiet_cheat_actions[0] as Dictionary).get("suspicion_delta", 0))
	if quiet_risk != 2:
		failures.append("Quiet security pressure should not alter base risky action suspicion.")

	run_state.add_suspicion("watchful_floor", 25, "behavior", false, {"environment_id": "security_pressure_environment"})
	if run_state.suspicion_level() != 25:
		failures.append("RunState suspicion_level did not expose bounded suspicion.")
	if run_state.security_risk_bonus("cheat") <= 0:
		failures.append("Elevated suspicion did not produce risky-action pressure.")
	if run_state.security_pressure_summary().is_empty() or run_state.security_pressure_summary().contains("25"):
		failures.append("Security pressure summary should be behavior-first, not raw-meter-first.")
	var pressured_actions := game.actions(run_state, environment)
	var pressured_cheat_actions: Array = pressured_actions.get("cheat_actions", [])
	var pressured_risk := int((pressured_cheat_actions[0] as Dictionary).get("suspicion_delta", 0))
	if pressured_risk <= quiet_risk:
		failures.append("Suspicion did not increase visible risky-action consequence.")
	if int((pressured_cheat_actions[0] as Dictionary).get("security_pressure_bonus", 0)) <= 0:
		failures.append("Risky-action view did not expose security pressure bonus.")

	var before_suspicion := run_state.suspicion_level()
	var before_cue_count := (run_state.suspicion.get("cues", []) as Array).size()
	var result := game.resolve("risky_fixture", 1, run_state, environment, run_state.create_rng())
	if int(result.get("suspicion_delta", 0)) != pressured_risk:
		failures.append("Risky action result did not apply security-adjusted suspicion.")
	if run_state.suspicion_level() != before_suspicion + pressured_risk:
		failures.append("Risky action did not update RunState suspicion by adjusted consequence.")
	if (run_state.suspicion.get("cues", []) as Array).size() <= before_cue_count:
		failures.append("Risky action did not add a behavior cue.")
	if not str(result.get("message", "")).contains("risky moves draw more heat"):
		failures.append("Risky action result did not communicate security pressure.")

	var high_heat_run: RunState = RunStateScript.new()
	high_heat_run.start_new("HIGH-HEAT-PRESSURE")
	high_heat_run.add_suspicion("heated_floor", 66, "behavior", false, {"environment_id": "security_pressure_environment"})
	var high_heat_actions := game.actions(high_heat_run, environment)
	var high_heat_cheat_actions: Array = high_heat_actions.get("cheat_actions", [])
	var high_heat_risk := int((high_heat_cheat_actions[0] as Dictionary).get("suspicion_delta", 0)) if not high_heat_cheat_actions.is_empty() else 0
	if high_heat_risk <= pressured_risk:
		failures.append("High heat did not materially increase risky-action heat consequence.")
	var high_heat_result := game.resolve("risky_fixture", 10, high_heat_run, environment, high_heat_run.create_rng())
	var high_heat_story: Dictionary = {}
	var high_heat_story_log: Array = high_heat_result.get("deltas", {}).get("story_log", [])
	if not high_heat_story_log.is_empty() and typeof(high_heat_story_log[0]) == TYPE_DICTIONARY:
		high_heat_story = high_heat_story_log[0] as Dictionary
	if int(high_heat_story.get("security_bankroll_delta", 0)) >= 0:
		failures.append("High heat did not add a material security cost to risky action results.")
	if not str(high_heat_result.get("message", "")).contains("shakedown") and not str(high_heat_result.get("message", "")).contains("costly"):
		failures.append("High heat result did not communicate the security consequence.")

	var severe_heat_run: RunState = RunStateScript.new()
	severe_heat_run.start_new("SEVERE-HEAT-PRESSURE")
	severe_heat_run.add_suspicion("closing_in", 92, "behavior", false, {"environment_id": "security_pressure_environment"})
	var severe_heat_result := game.resolve("risky_fixture", 1, severe_heat_run, environment, severe_heat_run.create_rng())
	if not bool(severe_heat_result.get("ended", false)):
		failures.append("Very high heat did not create visible run-ending pressure.")
	if severe_heat_run.run_status != RunState.RUN_STATUS_FAILED:
		failures.append("Very high heat did not fail the run through RunState.")
	if severe_heat_run.run_failure_reason != RunState.FAILURE_POLICE_CAPTURE:
		failures.append("Very high heat failure was not recorded as police capture.")
	if not str(severe_heat_result.get("message", "")).contains("cuffs"):
		failures.append("Very high heat result did not explain the police capture consequence.")

	var capture_run: RunState = RunStateScript.new()
	capture_run.start_new("DIRECT-POLICE-CAPTURE")
	capture_run.add_suspicion("risk_meter_full", 100, "behavior", true, {"environment_id": "security_pressure_environment"})
	if capture_run.run_status != RunState.RUN_STATUS_FAILED or capture_run.run_failure_reason != RunState.FAILURE_POLICE_CAPTURE:
		failures.append("Risk meter reaching 100 did not immediately fail the run as police capture.")

	var event := EventModule.new()
	event.setup({
		"id": "security_pressure_event",
		"display_name": "Security Pressure Event",
		"type": "security",
		"min_suspicion": run_state.suspicion_level() + 5,
		"payload": {
			"choices": [{"id": "wait", "label": "Wait", "consequences": {"suspicion_delta": 1}}],
		},
	})
	if event.can_trigger(run_state, environment):
		failures.append("Suspicion-gated event triggered before enough pressure was present.")
	run_state.add_suspicion("guard_attention", 5, "behavior", false, {"environment_id": "security_pressure_environment"})
	if not event.can_trigger(run_state, environment):
		failures.append("Suspicion-gated event did not trigger after enough pressure was present.")

	var local_heat_run: RunState = RunStateScript.new()
	local_heat_run.start_new("LOCAL-HEAT-MEMORY")
	local_heat_run.set_environment({"id": "gas_station_casino_001", "archetype_id": "gas_station_casino"})
	local_heat_run.add_suspicion("hot_table", 80, "behavior", false, {"environment_id": "gas_station_casino_001"})
	var far_travel := local_heat_run.begin_travel_suspicion_decay({"distance": "far", "risk_decay": 85}, "motel")
	local_heat_run.set_environment({"id": "motel_002", "archetype_id": "motel"})
	var far_decay := local_heat_run.finish_travel_suspicion_decay(far_travel)
	if int(far_decay.get("cooled", 0)) <= 0:
		failures.append("Far travel did not cool local heat before arrival.")
	if local_heat_run.suspicion_level() > 15:
		failures.append("Far travel carried too much local heat into a distant environment.")
	var far_return := local_heat_run.begin_travel_suspicion_decay({"distance": "far", "risk_decay": 85}, "gas_station_casino")
	local_heat_run.set_environment({"id": "gas_station_casino_003", "archetype_id": "gas_station_casino"})
	local_heat_run.finish_travel_suspicion_decay(far_return)
	if local_heat_run.suspicion_level() < 70 or local_heat_run.suspicion_level() > 75:
		failures.append("Returning to a hot venue should remember heat with only a small cooldown.")

	var near_heat_run: RunState = RunStateScript.new()
	near_heat_run.start_new("NEAR-HEAT-MEMORY")
	near_heat_run.set_environment({"id": "gas_station_casino_001", "archetype_id": "gas_station_casino"})
	near_heat_run.add_suspicion("hot_table", 80, "behavior", false, {"environment_id": "gas_station_casino_001"})
	var near_travel := near_heat_run.begin_travel_suspicion_decay({"distance": "near", "risk_decay": 12}, "bar")
	near_heat_run.set_environment({"id": "bar_002", "archetype_id": "bar"})
	near_heat_run.finish_travel_suspicion_decay(near_travel)
	var near_return := near_heat_run.begin_travel_suspicion_decay({"distance": "near", "risk_decay": 12}, "gas_station_casino")
	near_heat_run.set_environment({"id": "gas_station_casino_003", "archetype_id": "gas_station_casino"})
	near_heat_run.finish_travel_suspicion_decay(near_return)
	if near_heat_run.suspicion_level() < 65:
		failures.append("Nearby travel should preserve most local heat when returning to the source venue.")
	var same_heat_run: RunState = RunStateScript.new()
	same_heat_run.start_new("SAME-HEAT-MEMORY")
	same_heat_run.set_environment({"id": "bar_001", "archetype_id": "bar"})
	same_heat_run.add_suspicion("watched_bar", 40, "behavior", false, {"environment_id": "bar_001"})
	var same_travel := same_heat_run.begin_travel_suspicion_decay({"distance": "same", "risk_decay": 0}, "bar")
	same_heat_run.set_environment({"id": "bar_002", "archetype_id": "bar"})
	same_heat_run.finish_travel_suspicion_decay(same_travel)
	if same_heat_run.suspicion_level() != 40:
		failures.append("Same-location travel should not cool local heat.")
	var near_snapshot := near_heat_run.to_dict()
	var near_restored: RunState = RunStateScript.new()
	near_restored.from_dict(near_snapshot)
	if near_restored.suspicion_level() != near_heat_run.suspicion_level():
		failures.append("Local heat memory did not survive RunState serialization.")

	var time_heat_run: RunState = RunStateScript.new()
	time_heat_run.start_new("TIME-HEAT-COOLING")
	time_heat_run.set_environment({"id": "bar_001", "archetype_id": "bar"})
	time_heat_run.add_suspicion("regulars_watch", 20, "behavior", false, {"environment_id": "bar_001"})
	time_heat_run.advance_environment_turns(1)
	if time_heat_run.suspicion_level() != 20:
		failures.append("In-room heat cooled too quickly after one turn.")
	time_heat_run.advance_environment_turns(1)
	if time_heat_run.suspicion_level() != 19:
		failures.append("In-room heat did not cool slowly over time.")

	var save_service: SaveService = SaveServiceScript.new()
	var slot_id := "foundation_check_suspicion"
	var save_error: Error = save_service.save_run(run_state, slot_id)
	if save_error != OK:
		failures.append("Save service could not save suspicion/security state: %s." % save_error)
	else:
		var loaded = save_service.load_run(slot_id)
		if loaded == null:
			failures.append("Save service could not reload suspicion/security state.")
		elif loaded.suspicion_level() != run_state.suspicion_level():
			failures.append("Suspicion level did not survive SaveService load.")
		elif (loaded.suspicion.get("cues", []) as Array).size() != (run_state.suspicion.get("cues", []) as Array).size():
			failures.append("Suspicion cues did not survive SaveService load.")
		elif loaded.security_risk_bonus("cheat") != run_state.security_risk_bonus("cheat"):
			failures.append("Security pressure bonus did not survive SaveService load.")

	var severe_slot_id := "foundation_check_severe_heat"
	var severe_save_error: Error = save_service.save_run(severe_heat_run, severe_slot_id)
	if severe_save_error != OK:
		failures.append("Save service could not save severe heat state: %s." % severe_save_error)
	else:
		var loaded_severe = save_service.load_run(severe_slot_id)
		if loaded_severe == null:
			failures.append("Save service could not reload severe heat state.")
		elif loaded_severe.suspicion_level() != severe_heat_run.suspicion_level():
			failures.append("Severe heat level did not survive SaveService load.")
		elif loaded_severe.run_status != severe_heat_run.run_status:
			failures.append("Severe heat run-ending pressure did not survive SaveService load.")
		elif loaded_severe.run_failure_reason != severe_heat_run.run_failure_reason:
			failures.append("Severe heat failure reason did not survive SaveService load.")


func _check_music_fx_foundation(library: ContentLibrary, failures: Array) -> void:
	var first_environment: Dictionary = {}
	var boss_environment: Dictionary = {}
	for archetype_value in library.environment_archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		if first_environment.is_empty():
			first_environment = archetype.duplicate(true)
		if str(archetype.get("id", "")) == "grand_casino":
			boss_environment = archetype.duplicate(true)
	if first_environment.is_empty() or boss_environment.is_empty():
		failures.append("Music FX foundation fixture could not find environment archetypes.")
		return

	var topology_before: Dictionary = ProceduralMusicPlayerScript.music_bus_topology_snapshot()
	if not bool(topology_before.get("preconfigured", false)):
		failures.append("The authored audio bus layout was incomplete before music startup: %s." % JSON.stringify(topology_before))
	var bus_count_before := int(topology_before.get("bus_count", -1))
	var graph_a: Dictionary = ProceduralMusicPlayerScript.ensure_music_fx_bus_graph()
	var graph_b: Dictionary = ProceduralMusicPlayerScript.ensure_music_fx_bus_graph()
	var topology_after: Dictionary = ProceduralMusicPlayerScript.music_bus_topology_snapshot()
	if int(topology_after.get("bus_count", -2)) != bus_count_before or not bool(topology_after.get("preconfigured", false)):
		failures.append("Repeated music startup mutated the audio bus topology while the mixer could be active: before=%s after=%s." % [JSON.stringify(topology_before), JSON.stringify(topology_after)])
	if int(graph_a.get("effect_count", 0)) != 4 or int(graph_b.get("effect_count", 0)) != 4:
		failures.append("Music master bus should contain shared pitch compensation, low-pass, chorus, and the safety limiter.")
	if JSON.stringify(graph_a.get("effects", [])) != JSON.stringify(graph_b.get("effects", [])):
		failures.append("Music FX bus graph was not idempotent across repeated startup calls.")
	var effect_types: Array = []
	var enabled: Array = []
	for effect_value in (graph_b.get("effects", []) as Array):
		if typeof(effect_value) != TYPE_DICTIONARY:
			continue
		var effect: Dictionary = effect_value
		effect_types.append(str(effect.get("type", "")))
		enabled.append(bool(effect.get("enabled", false)))
	var expected_types := [
		"AudioEffectPitchShift",
		"AudioEffectLowPassFilter",
		"AudioEffectChorus",
		"AudioEffectLimiter",
	]
	if JSON.stringify(effect_types) != JSON.stringify(expected_types):
		failures.append("Music FX bus graph order/types changed: %s." % JSON.stringify(effect_types))
	if enabled.size() == 4 and (bool(enabled[0]) or bool(enabled[1]) or bool(enabled[2]) or not bool(enabled[3])):
		failures.append("Music master bus should bypass idle pitch/low-pass/chorus processing and keep the safety limiter active.")
	var send_graph: Dictionary = graph_b.get("send_buses", {}) as Dictionary
	var send_buses: Dictionary = send_graph.get("buses", {}) as Dictionary
	var expected_send_types := {
		"band_pass": "AudioEffectBandPassFilter",
		"delay": "AudioEffectDelay",
		"distortion": "AudioEffectDistortion",
		"reverb": "AudioEffectReverb",
		"compressor": "AudioEffectCompressor",
	}
	for effect_key in expected_send_types.keys():
		var send_bus: Dictionary = send_buses.get(effect_key, {}) as Dictionary
		if str(send_bus.get("send", "")) != "Music" or str(send_bus.get("effect_type", "")) != str(expected_send_types.get(effect_key, "")) or not bool(send_bus.get("independent_role_sends", false)):
			failures.append("Music %s send bus did not expose independent per-instrument routing." % effect_key)

	var web_contract: Dictionary = WebAudioBridgeScript.mix_contract_snapshot()
	if not bool(web_contract.get("stream_bridge_enabled", false)) or not bool(web_contract.get("pcm_stream_bridge_default", false)):
		failures.append("Web export should use the browser PCM stream bridge so music/SFX remain audible when native web playback is silent.")
	if bool(web_contract.get("script_has_oscillator_fallback", true)):
		failures.append("Web audio bridge must not fall back to oscillator synth cues; those produced the browser hum regression.")
	if int(web_contract.get("version", 0)) < 4 or not bool(web_contract.get("script_has_version_guard", false)):
		failures.append("Web audio bridge did not expose a versioned replacement guard.")
	if not bool(web_contract.get("script_has_highpass", false)) or float(web_contract.get("highpass_hz", 0.0)) < 30.0:
		failures.append("Web audio bridge must high-pass browser output to prevent sub-bass overload.")
	if not bool(web_contract.get("script_has_compressor", false)) or float(web_contract.get("compressor_ratio", 0.0)) < 1.5:
		failures.append("Web audio bridge must keep a browser-side compressor before destination output.")
	if not bool(web_contract.get("script_has_pcm_decoder", false)) or not bool(web_contract.get("script_has_music_stems", false)):
		failures.append("Web audio bridge must decode PCM buffers and play the normal music stem set.")
	if not bool(web_contract.get("script_has_adpcm_decoder", false)):
		failures.append("Web audio bridge must decode the bounded 22.05 kHz authored ADPCM delivery.")
	if not bool(web_contract.get("script_syncs_user_bus_levels", false)):
		failures.append("Web audio bridge must mirror the native Master, Music, and SFX volume buses.")
	if int(web_contract.get("minimum_buffer_sample_rate", 0)) < 3000 or not bool(web_contract.get("script_resamples_low_rate_pcm", false)):
		failures.append("Web audio bridge must upsample bandwidth-bounded music beds to a browser-supported AudioBuffer rate.")
	if not bool(web_contract.get("script_rejects_empty_music_groups", false)):
		failures.append("Web audio bridge must not cache a music group when every stem failed to start.")
	if not bool(web_contract.get("script_accepts_json_payloads", false)):
		failures.append("Web audio bridge JavaScript methods must parse JSON string payloads from direct interface calls.")
	if not bool(web_contract.get("script_has_loop_stop", false)):
		failures.append("Web audio bridge must expose explicit loop stopping for reel/roulette browser loops.")
	if not bool(web_contract.get("script_requires_explicit_one_shot_unlock", false)):
		failures.append("Web audio one-shots must wait for the explicit user-gesture unlock instead of retrying a rejected browser resume on simulation ticks.")
	if int(web_contract.get("music_mix_min_interval_msec", 0)) < 100:
		failures.append("Web audio bridge must throttle browser mix calls so music fades do not stall the web main thread.")
	if not bool(web_contract.get("bridge_uses_direct_interface", false)) or not bool(web_contract.get("telemetry_uses_call_payload_names", false)):
		failures.append("Web audio bridge must report direct-call payload telemetry instead of eval byte telemetry.")
	if not bool(web_contract.get("bridge_skips_silent_music_stems", false)):
		failures.append("Web audio bridge must skip silent music stems before serializing browser PCM payloads.")
	if not bool(web_contract.get("bridge_skips_duplicate_music_stems", false)):
		failures.append("Web audio bridge must skip duplicate music stem payloads before crossing JavaScriptBridge.")
	if not bool(web_contract.get("bridge_skips_duplicate_music_stops", false)):
		failures.append("Web audio bridge must skip duplicate browser music stops before crossing JavaScriptBridge.")
	if not bool(web_contract.get("script_limits_sfx_gain", false)) or float(web_contract.get("sfx_max_gain", 2.0)) > 1.25:
		failures.append("Web audio bridge SFX gain staging can clip browser output.")
	if float(web_contract.get("master_gain", 1.0)) * float(web_contract.get("output_gain", 1.0)) > 0.75:
		failures.append("Web audio bridge master/output gain leaves too little headroom.")
	var web_audio_bridge_text := FileAccess.get_file_as_string("res://scripts/ui/web_audio_bridge.gd")
	if _foundation_string_occurrence_count(web_audio_bridge_text, "JavaScriptBridge.eval(") != 1:
		failures.append("Web audio bridge should use JavaScriptBridge.eval only for one-time bridge installation.")
	if web_audio_bridge_text.find("JavaScriptBridge.get_interface(\"BTHWebAudio\")") < 0:
		failures.append("Web audio bridge should cache BTHWebAudio through JavaScriptBridge.get_interface after installation.")
	if web_audio_bridge_text.find("\"call_counts\"") < 0 or web_audio_bridge_text.find("\"payload_bytes\"") < 0:
		failures.append("Web audio bridge debug stats should expose call_counts and payload_bytes telemetry.")
	var foundation_main_text := FileAccess.get_file_as_string("res://scripts/ui/foundation_main.gd")
	if foundation_main_text.find("_suppress_web_music_for_game_surface") != -1 or foundation_main_text.find("OS.has_feature(\"web\") and current_screen == SCREEN_GAME") != -1:
		failures.append("Web procedural music should keep playing inside game surfaces instead of being suppressed on entry.")
	var export_presets_text := FileAccess.get_file_as_string("res://export_presets.cfg")
	var web_preset_start := export_presets_text.find("[preset.3]")
	var web_options_start := export_presets_text.find("[preset.3.options]")
	var web_preset_text := export_presets_text.substr(web_preset_start, web_options_start - web_preset_start) if web_preset_start >= 0 and web_options_start > web_preset_start else ""
	var desktop_preset_end := export_presets_text.find("[preset.0.options]")
	var desktop_preset_text := export_presets_text.substr(0, desktop_preset_end) if desktop_preset_end > 0 else ""
	if web_preset_text.find("assets/audio/music/*") < 0 or web_preset_text.find("assets/audio/music_web/**") < 0 or web_preset_text.find("assets/audio/sfx_web/**") < 0:
		failures.append("Web export must replace desktop masters with the bounded Web-authored delivery, not remove both copies.")
	if desktop_preset_text.find("assets/audio/music/*") >= 0:
		failures.append("Desktop export must retain the untouched authored music masters.")
	if not FileAccess.file_exists("res://assets/audio/music_web/corner_store_sparse_fixture/pad.bthadpcm.gz") \
			or not FileAccess.file_exists("res://assets/audio/music_web/jazz_club_delivery_fixture_8_bar/JazzClub_Bass_UprightBass_1.bthadpcm.gz") \
			or not FileAccess.file_exists("res://assets/audio/music_web/procedural/main_menu_tour.bthadpcm.gz"):
		failures.append("Web-authored 22.05 kHz music delivery is incomplete.")
	for web_music_path in [
		"res://assets/audio/music_web/corner_store_sparse_fixture/pad.bthadpcm.gz",
		"res://assets/audio/music_web/jazz_club_delivery_fixture_8_bar/JazzClub_Bass_UprightBass_1.bthadpcm.gz",
		"res://assets/audio/music_web/procedural/main_menu_tour.bthadpcm.gz",
	]:
		var web_music_info: Dictionary = ContentLibraryScript.inspect_web_music_delivery(web_music_path)
		if not bool(web_music_info.get("valid", false)) or int(web_music_info.get("sample_rate", 0)) != 22050 or int(web_music_info.get("frames", 0)) <= 0:
			failures.append("Web authored music delivery failed deep build-time validation: %s." % web_music_path)

	var player: ProceduralMusicPlayer = ProceduralMusicPlayerScript.new()
	get_root().add_child(player)
	var initial_snapshot: Dictionary = player.music_fx_snapshot({})
	if bool(initial_snapshot.get("player_instantiated", true)):
		failures.append("Headless procedural music player should not instantiate AudioStreamPlayer playback.")
	var music_latency: Dictionary = player.music_generation_latency_snapshot_for_environment(first_environment, 20)
	var web_bed_seconds := float(music_latency.get("web_bed_seconds", 0.0))
	var web_bed_pcm_bytes := int(music_latency.get("web_bed_pcm_bytes", 0))
	var web_bed_cap_bytes := int(music_latency.get("web_bed_bridge_cap_bytes", 0))
	if int(music_latency.get("web_bed_sample_rate", 0)) < 22050:
		failures.append("Web procedural music must retain the 22.05 kHz fidelity floor used by the browser mix contract.")
	if web_bed_seconds < 30.0:
		failures.append("Web procedural music bed should be long-form, not a short startup loop.")
	if web_bed_pcm_bytes <= 0 or web_bed_cap_bytes <= 0 or web_bed_pcm_bytes > web_bed_cap_bytes:
		failures.append("Web procedural music bed must fit the browser PCM bridge budget.")
	if web_bed_seconds <= float(music_latency.get("instant_seconds", 0.0)) * 4.0:
		failures.append("Web procedural music bed should be substantially longer than the desktop instant bed.")
	var first_music_profile_value: Variant = first_environment.get("music_profile", {})
	var first_music_profile: Dictionary = {}
	if typeof(first_music_profile_value) == TYPE_DICTIONARY:
		first_music_profile = first_music_profile_value as Dictionary
	if not str(first_music_profile.get("authored_track_id", "")).is_empty():
		if str(music_latency.get("web_mixdown_source", "")) != "authored":
			failures.append("Web music bridge should downmix authored room music instead of replacing it with generated filler.")
		if float(music_latency.get("web_mixdown_seconds", 0.0)) < 20.0:
			failures.append("Web authored room music mixdown should preserve a long-form loop.")
	var boss_music_latency: Dictionary = player.music_generation_latency_snapshot_for_environment(boss_environment, 20)
	if str(music_latency.get("web_bed_track_id", "")) == str(boss_music_latency.get("web_bed_track_id", "")):
		failures.append("Web procedural music bed track ids should change between environment archetypes.")
	if str(music_latency.get("web_bed_cache_key", "")) == str(boss_music_latency.get("web_bed_cache_key", "")):
		failures.append("Web procedural music bed cache keys should change between environment archetypes.")

	var sober: Dictionary = _music_fx_target(player, {
		"environment": first_environment,
		"visual_context": first_environment.get("visual_context", {}),
		"heat": 20,
		"drunk_level": 0,
	})
	var drunk: Dictionary = _music_fx_target(player, {
		"environment": first_environment,
		"visual_context": first_environment.get("visual_context", {}),
		"heat": 20,
		"drunk_level": 85,
	})
	if float(drunk.get("chorus_depth", 0.0)) <= float(sober.get("chorus_depth", 0.0)) + 0.20:
		failures.append("Music FX drunk tier did not materially raise chorus depth.")
	if float(drunk.get("pitch_wobble_cents", 0.0)) <= 6.0:
		failures.append("Music FX drunk tier did not expose slow pitch wobble.")
	if float(drunk.get("lowpass_cutoff_hz", 20000.0)) >= float(sober.get("lowpass_cutoff_hz", 0.0)) - 2000.0:
		failures.append("Music FX drunk tier did not close the low-pass filter.")
	if float(drunk.get("delay_amount", 0.0)) <= float(sober.get("delay_amount", 0.0)) + 0.20:
		failures.append("Music FX drunk tier did not raise the per-instrument delay sends.")

	var heat_low: Dictionary = _music_fx_target(player, {
		"environment": first_environment,
		"visual_context": first_environment.get("visual_context", {}),
		"heat": 20,
	})
	var heat_high: Dictionary = _music_fx_target(player, {
		"environment": first_environment,
		"visual_context": first_environment.get("visual_context", {}),
		"heat": 90,
	})
	if float(heat_high.get("distortion_drive", 0.0)) <= float(heat_low.get("distortion_drive", 0.0)) + 0.04:
		failures.append("Music FX heat mapping did not add subtle high-heat distortion.")

	var unwatched: Dictionary = _music_fx_target(player, {
		"environment": boss_environment,
		"visual_context": boss_environment.get("visual_context", {}),
		"heat": 30,
		"pit_boss_watch": {"active": true, "watched": false},
		"staff_attention": {"active": false},
		"boss_floor": false,
	})
	var watched: Dictionary = _music_fx_target(player, {
		"environment": boss_environment,
		"visual_context": boss_environment.get("visual_context", {}),
		"heat": 30,
		"pit_boss_watch": {"active": true, "watched": true},
		"staff_attention": {"active": true},
		"boss_floor": false,
	})
	if float(watched.get("watch_bandpass_amount", 0.0)) <= float(unwatched.get("watch_bandpass_amount", 0.0)) + 0.10:
		failures.append("Music FX watch/staff attention did not expose the surveillance tinge.")
	if float(watched.get("watch_bandpass_q", 0.0)) <= float(unwatched.get("watch_bandpass_q", 0.0)) + 0.5:
		failures.append("Music FX attention did not narrow the true band-pass as attention rose.")
	var watched_send_snapshot: Dictionary = player.music_fx_snapshot({"watched": true, "attention_level": 90.0})
	var watched_send_matrix: Dictionary = watched_send_snapshot.get("send_matrix", {}) as Dictionary
	if float(((watched_send_matrix.get("band_pass", {}) as Dictionary).get("lead", 0.0))) <= 0.2:
		failures.append("Music FX attention did not route the lead into its band-pass send.")

	var calm_boss: Dictionary = _music_fx_target(player, {
		"environment": boss_environment,
		"visual_context": boss_environment.get("visual_context", {}),
		"heat": 30,
		"boss_floor": true,
	})
	var showdown: Dictionary = _music_fx_target(player, {
		"environment": boss_environment,
		"visual_context": boss_environment.get("visual_context", {}),
		"heat": 30,
		"boss_floor": true,
		"showdown_pending": true,
	})
	if float(showdown.get("distortion_drive", 0.0)) <= float(calm_boss.get("distortion_drive", 0.0)) + 0.10:
		failures.append("Music FX showdown did not push danger distortion beyond the boss-floor bed.")
	if float(showdown.get("compressor_pump", 0.0)) <= float(calm_boss.get("compressor_pump", 0.0)) + 0.25:
		failures.append("Music FX showdown did not increase compressor pump.")
	if float(calm_boss.get("reverb_size", 0.0)) <= float(sober.get("reverb_size", 1.0)):
		failures.append("Music FX venue room scale did not open reverb on the boss floor.")

	var settings := UserSettingsScript.new()
	settings.audio_calm = true
	settings.play_on_small_screen = true
	var restored_settings: UserSettings = UserSettingsScript.new()
	restored_settings.from_dict(settings.to_dict())
	if not restored_settings.audio_calm:
		failures.append("Audio-calm setting did not round-trip through UserSettings.")
	if not restored_settings.play_on_small_screen:
		failures.append("Play-on-small-screen setting did not round-trip through UserSettings.")
	player.audio_calm = false
	var intense_showdown: Dictionary = _music_fx_target(player, {
		"environment": boss_environment,
		"visual_context": boss_environment.get("visual_context", {}),
		"heat": 95,
		"boss_floor": true,
		"showdown_pending": true,
		"drunk_level": 85,
	})
	player.audio_calm = true
	var calm_showdown: Dictionary = _music_fx_target(player, {
		"environment": boss_environment,
		"visual_context": boss_environment.get("visual_context", {}),
		"heat": 95,
		"boss_floor": true,
		"showdown_pending": true,
		"drunk_level": 85,
	})
	if float(calm_showdown.get("distortion_drive", 0.0)) >= float(intense_showdown.get("distortion_drive", 0.0)):
		failures.append("Audio-calm did not damp Music FX distortion.")
	if float(calm_showdown.get("compressor_pump", 0.0)) >= float(intense_showdown.get("compressor_pump", 0.0)):
		failures.append("Audio-calm did not damp Music FX compressor pump.")
	player.queue_free()


func _music_fx_target(player: ProceduralMusicPlayer, snapshot: Dictionary) -> Dictionary:
	var fx_snapshot: Dictionary = player.music_fx_snapshot(snapshot)
	return fx_snapshot.get("target", {}) as Dictionary


func _check_music_stem_director_foundation(library: ContentLibrary, failures: Array) -> void:
	var attached_headless_player: ProceduralMusicPlayer = ProceduralMusicPlayerScript.new()
	root.add_child(attached_headless_player)
	if attached_headless_player.is_processing():
		failures.append("Tree-attached ProceduralMusicPlayer kept an idle process callback active in headless mode.")
	var attached_snapshot: Dictionary = attached_headless_player.music_fx_snapshot({"heat": 42})
	if (attached_snapshot.get("target", {}) as Dictionary).is_empty() or not is_equal_approx(float((attached_snapshot.get("target", {}) as Dictionary).get("heat", -1.0)), 42.0):
		failures.append("Disabling headless automatic music processing also disabled direct snapshot APIs.")
	attached_headless_player.free()

	var player: ProceduralMusicPlayer = ProceduralMusicPlayerScript.new()
	var stem_buses: Dictionary = ProceduralMusicPlayerScript.ensure_music_stem_bus_graph()
	var bus_roles: Dictionary = stem_buses.get("buses", {}) as Dictionary
	for role in ["pad", "bass", "bass_dark", "lead", "drums_low", "drums_high", "drums_high_double", "tension", "texture"]:
		var role_bus: Dictionary = bus_roles.get(role, {}) as Dictionary
		if str(role_bus.get("send", "")) != "Music":
			failures.append("Music stem bus %s was not routed into the Music bus." % role)
	var send_matrix_fixture := {"reverb": {"lead": 0.1}, "delay": {"lead": 0.05}}
	var merged_send_matrix: Dictionary = player.call("_merge_authored_send_preferences", send_matrix_fixture, {
		"preferred_dsp_sends": {"lead": {"reverb": 0.4, "delay": 0.02}},
	})
	if merged_send_matrix.has("lead") or not is_equal_approx(float((merged_send_matrix.get("reverb", {}) as Dictionary).get("lead", 0.0)), 0.4) or not is_equal_approx(float((merged_send_matrix.get("delay", {}) as Dictionary).get("lead", 0.0)), 0.05):
		failures.append("Authored DSP preferences did not merge into the effect-to-role send matrix without lowering the live mix.")

	var authored_track := library.music_track("corner_store_sparse_fixture")
	if authored_track.is_empty():
		failures.append("ContentLibrary did not load the authored sparse music track fixture.")
	var jazz_8_track := library.music_track("jazz_club_delivery_fixture_8_bar")
	var jazz_16_track := library.music_track("jazz_club_delivery_fixture_16_bar")
	if jazz_8_track.is_empty() or jazz_16_track.is_empty():
		failures.append("ContentLibrary did not load both 24-bit Jazz delivery fixtures.")
	var parsed_delivery := MusicDeliveryIndexScript.parse_filename("JazzClub_Lead_Trumpet_1.WAV")
	if not bool(parsed_delivery.get("ok", false)) or str(parsed_delivery.get("environment", "")) != "JazzClub" or str(parsed_delivery.get("role", "")) != "lead" or str(parsed_delivery.get("instrument", "")) != "Trumpet" or int(parsed_delivery.get("pattern_number", 0)) != 1:
		failures.append("Jazz delivery filename parser did not expose environment/classification/instrument/pattern fields case-insensitively.")
	for malformed_name in ["JazzClub_Lead_Trumpet.wav", "JazzClub_Unknown_Trumpet_1.wav", "JazzClub_Lead_Trumpet_0.wav", "JazzClub_Lead_Bad_Name_1.wav"]:
		if bool(MusicDeliveryIndexScript.parse_filename(malformed_name).get("ok", false)):
			failures.append("Jazz delivery filename parser accepted malformed name %s." % malformed_name)
	var wrong_environment_index := MusicDeliveryIndexScript.build_index("jazz_fixture", "JazzClub", ["Motel_Lead_Trumpet_1.wav"])
	if bool(wrong_environment_index.get("valid", true)) or JSON.stringify(wrong_environment_index.get("errors", [])).find("requires JazzClub") < 0:
		failures.append("Jazz delivery index did not reject a filename from the wrong environment.")
	var duplicate_index := MusicDeliveryIndexScript.build_index("jazz_fixture", "JazzClub", ["JazzClub_Lead_Trumpet_1.wav", "JazzClub_lead_trumpet_1.WAV"])
	if bool(duplicate_index.get("valid", true)) or JSON.stringify(duplicate_index.get("errors", [])).find("duplicates semantic ID") < 0:
		failures.append("Jazz delivery index did not reject a duplicate semantic instrument/pattern ID.")
	var scanned_jazz := library.music_delivery_index("jazz_club_delivery_fixture_8_bar")
	if not bool(scanned_jazz.get("valid", false)) or (scanned_jazz.get("entries", []) as Array).size() != 10 or (scanned_jazz.get("proposed_manifest_entries", []) as Array).size() != 10:
		failures.append("Jazz delivery import helper did not index and propose all ten 8-bar fixture records without rewriting the manifest.")
	var wav_8 := ContentLibraryScript.inspect_music_wav("res://assets/audio/music/jazz_club_delivery_fixture_8_bar/JazzClub_Chords_Piano_1.wav")
	var wav_16 := ContentLibraryScript.inspect_music_wav("res://assets/audio/music/jazz_club_delivery_fixture_16_bar/JazzClub_Chords_Piano_2.wav")
	if not bool(wav_8.get("valid", false)) or int(wav_8.get("bits_per_sample", 0)) != 24 or int(wav_8.get("frames", 0)) != 705600:
		failures.append("24-bit 8-bar WAV inspection did not derive the real data-chunk frame count.")
	if not bool(wav_16.get("valid", false)) or int(wav_16.get("bits_per_sample", 0)) != 24 or int(wav_16.get("frames", 0)) != 1411200:
		failures.append("24-bit 16-bar WAV inspection did not derive the real data-chunk frame count.")
	if str(wav_8.get("inspection_mode", "")) != "streamed_chunk_headers" or int(wav_8.get("inspected_header_bytes", 99999999)) >= 256 or int(wav_8.get("inspected_header_bytes", 0)) * 1000 >= int(wav_8.get("data_bytes", 0)):
		failures.append("WAV validation loaded more than bounded RIFF/chunk headers from the large PCM24 fixture.")
	if int(wav_8.get("odd_sized_chunks", 0)) < 1 or int(wav_8.get("non_audio_chunks", 0)) < 1 or int(wav_8.get("riff_bytes", 0)) > int(wav_8.get("file_bytes", 0)):
		failures.append("Streamed WAV validation did not prove odd-chunk padding/non-audio metadata bounds.")
	for mismatch_fixture in [
		{"property": "bits_per_sample", "value": 16},
		{"property": "channels", "value": 2},
		{"property": "frames", "value": 705599},
		{"property": "sample_rate", "value": 48000},
	]:
		var candidate := wav_8.duplicate(true)
		candidate[str(mismatch_fixture.get("property", ""))] = int(mismatch_fixture.get("value", 0))
		if not ContentLibraryScript.synchronized_wav_mismatches(wav_8, candidate).has(str(mismatch_fixture.get("property", ""))):
			failures.append("Synchronized WAV validation missed %s mismatch." % str(mismatch_fixture.get("property", "")))
	_check_music_wav_info_cache(failures)
	var invalid_library: ContentLibrary = ContentLibraryScript.new()
	invalid_library.music_tracks = [{
		"id": "bad_music_entry",
		"bpm": 0,
		"bars": 1,
		"loop_frames": 100,
		"stems": {"pad": "missing.wav"},
	}]
	var invalid_errors := invalid_library.validate()
	if invalid_errors.is_empty():
		failures.append("ContentLibrary music manifest validation did not reject a bad authored entry.")
	var bad_policy_track := jazz_8_track.duplicate(true)
	var bad_policy_recipes: Array = bad_policy_track.get("arrangement_recipes", []) as Array
	(bad_policy_recipes[0] as Dictionary)["role_policies"] = {"pad": {"retain": true, "change_every": 0}}
	bad_policy_track["arrangement_recipes"] = bad_policy_recipes
	if JSON.stringify(_music_track_validation_errors(bad_policy_track)).find("change_every must be positive") < 0:
		failures.append("Music validation did not reject a non-positive role-policy change_every.")
	var bad_progression_track := jazz_8_track.duplicate(true)
	var bad_sets: Array = bad_progression_track.get("compatibility_sets", []) as Array
	((bad_sets[0] as Dictionary).get("roles", {}) as Dictionary)["bass"] = ["jazz_bass_incompatible"]
	bad_progression_track["compatibility_sets"] = bad_sets
	if JSON.stringify(_music_track_validation_errors(bad_progression_track)).find("does not declare that progression compatibility") < 0:
		failures.append("Music validation did not reject a cross-progression bass reference.")
	var incomplete_track := jazz_8_track.duplicate(true)
	var incomplete_banks: Dictionary = incomplete_track.get("stem_banks", {}) as Dictionary
	for variant_value in ((incomplete_banks.get("bass", {}) as Dictionary).get("variants", []) as Array):
		if str((variant_value as Dictionary).get("id", "")) == "jazz_bass_b":
			(variant_value as Dictionary)["enabled"] = false
	incomplete_track["stem_banks"] = incomplete_banks
	if JSON.stringify(_music_track_validation_errors(incomplete_track)).find("no enabled positive complete compatibility set") < 0:
		failures.append("Music validation did not reject a recipe section without a complete positive set.")
	var unknown_send_track := jazz_8_track.duplicate(true)
	var unknown_send_banks: Dictionary = unknown_send_track.get("stem_banks", {}) as Dictionary
	var unknown_send_variants: Array = (unknown_send_banks.get("lead", {}) as Dictionary).get("variants", []) as Array
	(unknown_send_variants[0] as Dictionary)["dsp_sends"] = {"mystery_wash": 0.5}
	unknown_send_track["stem_banks"] = unknown_send_banks
	if JSON.stringify(_music_track_validation_errors(unknown_send_track)).find("unknown effect mystery_wash") < 0:
		failures.append("Music validation did not reject an unknown engineer DSP-send name.")
	var invalid_send_track := jazz_8_track.duplicate(true)
	var invalid_send_banks: Dictionary = invalid_send_track.get("stem_banks", {}) as Dictionary
	var invalid_send_variants: Array = (invalid_send_banks.get("lead", {}) as Dictionary).get("variants", []) as Array
	(invalid_send_variants[0] as Dictionary)["dsp_sends"] = {"reverb": 1.5}
	invalid_send_track["stem_banks"] = invalid_send_banks
	if JSON.stringify(_music_track_validation_errors(invalid_send_track)).find("reverb must be a number inside 0..1") < 0:
		failures.append("Music validation did not reject an out-of-range engineer DSP send.")

	var authored_environment := _music_environment_with_authored_track(library)
	var procedural_environment := _music_environment_without_authored_track(library)
	if authored_environment.is_empty() or procedural_environment.is_empty():
		failures.append("Music stem foundation could not find authored and procedural environment fixtures.")
		return

	var authored_manifest: Dictionary = player.music_stem_manifest_snapshot_for_environment(authored_environment, 20)
	if str(authored_manifest.get("source", "")) != "authored":
		failures.append("Authored music profile did not resolve the sparse authored provider.")
	if not bool(authored_manifest.get("sync_ok", false)):
		failures.append("Authored sparse stem set did not expose synchronized loop metadata.")
	if int(authored_manifest.get("sample_rate", 0)) != 44100 or int(authored_manifest.get("bit_depth", 0)) != 16:
		failures.append("Authored music did not preserve the native 16-bit/44.1 kHz delivery contract.")
	if int(authored_manifest.get("loop_frames", 0)) < 44100 * 12:
		failures.append("Authored corner-store music fixture should be a long ambient bed, not a short repeated loop.")
	if int(authored_manifest.get("bars", 0)) < 8:
		failures.append("Authored corner-store music fixture should span multiple bars before looping.")
	if not bool(authored_manifest.get("sparse", false)):
		failures.append("Authored sparse fixture should report absent roles as silent.")
	var authored_roles: Dictionary = authored_manifest.get("roles", {}) as Dictionary
	if not bool((authored_roles.get("pad", {}) as Dictionary).get("present", false)) or not bool((authored_roles.get("tension", {}) as Dictionary).get("present", false)):
		failures.append("Authored fixture did not expose its pad+tension stems.")
	if bool((authored_roles.get("bass", {}) as Dictionary).get("present", false)):
		failures.append("Sparse authored fixture should leave absent bass silent.")
	var authored_hot: Dictionary = player.music_stem_manifest_snapshot_for_environment(authored_environment, 90)
	if str(authored_hot.get("cache_key", "")) == str(authored_manifest.get("cache_key", "")):
		failures.append("Authored intensity bank did not select a new phrase-ready variation at high heat.")
	if str(((authored_manifest.get("selected_variants", {}) as Dictionary).get("tension", {}) as Dictionary).get("id", "")) != "tension_low":
		failures.append("Authored low-intensity bank did not select its low tension variant.")
	if str(((authored_hot.get("selected_variants", {}) as Dictionary).get("tension", {}) as Dictionary).get("id", "")) != "tension_high":
		failures.append("Authored high-intensity bank did not select its high tension variant.")
	var authored_relative_key: Dictionary = player.music_stem_manifest_snapshot_for_environment(authored_environment, 20, {"harmonic_section": "B"})
	if str(authored_relative_key.get("selection_key", "")) == str(authored_manifest.get("selection_key", "")) or str((authored_relative_key.get("selection_context", {}) as Dictionary).get("harmonic_section", "")) != "B":
		failures.append("Authored harmonic bank did not preserve its relative-key section selection.")
	var jazz_recipe := MusicArrangementSelectorScript.recipe_definition(jazz_8_track)
	var jazz_tempo_profile: Dictionary = jazz_8_track.get("adaptive_tempo", {}) as Dictionary
	var jazz_tempo_low := ProceduralMusicPlayerScript.adaptive_tempo_bpm_for_heat(jazz_tempo_profile, 0.0)
	var jazz_tempo_mid := ProceduralMusicPlayerScript.adaptive_tempo_bpm_for_heat(jazz_tempo_profile, 50.0)
	var jazz_tempo_high := ProceduralMusicPlayerScript.adaptive_tempo_bpm_for_heat(jazz_tempo_profile, 100.0)
	if not bool(jazz_tempo_profile.get("enabled", false)) or not (jazz_tempo_low < jazz_tempo_mid and jazz_tempo_mid < jazz_tempo_high) or str(jazz_tempo_profile.get("native_processing", "")) != "player_rate_shared_bus_pitch_compensation":
		failures.append("Jazz authored delivery did not expose a monotonic, data-driven native adaptive-tempo profile.")
	var tempo_save_run := RunStateScript.new()
	tempo_save_run.start_new("MUSIC-TEMPO-ROUNDTRIP")
	tempo_save_run.remember_music_tempo_state({"profile_id": "jazz", "enabled": true, "current_bpm": 121.25, "target_bpm": 123.0, "source_heat": 80.0, "transport_beats": 13.75, "source_position": 6.875})
	var restored_tempo_run := RunStateScript.new()
	restored_tempo_run.from_dict(tempo_save_run.to_dict())
	if JSON.stringify(restored_tempo_run.music_tempo_state) != JSON.stringify(tempo_save_run.music_tempo_state):
		failures.append("Adaptive-tempo current/target transport state did not survive a RunState save/load round trip.")
	var jazz_layer_recipe: Dictionary = jazz_8_track.get("layer_choreography", {}) as Dictionary
	var jazz_layer_timeline := MusicLayerChoreographyScript.timeline_snapshot(jazz_layer_recipe, 32)
	var jazz_layer_stage_changes: Array = []
	for row_value in jazz_layer_timeline:
		var stage_id := str((row_value as Dictionary).get("stage_id", ""))
		if jazz_layer_stage_changes.is_empty() or str(jazz_layer_stage_changes[-1]) != stage_id:
			jazz_layer_stage_changes.append(stage_id)
	if jazz_layer_stage_changes != ["sparse", "build_bass", "build_drums", "peak", "release", "rebuild"]:
		failures.append("Jazz layer choreography did not encode its sparse/build/peak/release/rebuild dwell arc in order.")
	var fill_requests := [
		{"id": "layer", "kind": "layer", "priority": 40, "source_section": "A", "destination_section": "B", "destination_progression_id": "jazz_b_1", "change_roles": ["drums_high"]},
		{"id": "section", "kind": "section", "priority": 100, "source_section": "A", "destination_section": "B", "destination_progression_id": "jazz_b_1"},
	]
	var fill_resolution := MusicLayerChoreographyScript.resolve_fill_request(jazz_8_track.get("fills", {}), fill_requests, 2)
	if str(fill_resolution.get("request_id", "")) != "section" or str(fill_resolution.get("fill_id", "")) != "jazz_fixture_fill" or int(fill_resolution.get("lead_in_bars", 0)) != 2:
		failures.append("Jazz section/layer fill requests did not resolve to one compatible two-bar section-priority fill.")
	var incompatible_fill := MusicLayerChoreographyScript.resolve_fill_request({"wrong": {"loop": false, "source_sections": ["C"], "destination_sections": ["C"], "progression_compatibility": ["wrong"]}}, fill_requests, 2)
	if not bool(incompatible_fill.get("quiet_fallback", false)) or not str(incompatible_fill.get("fill_id", "")).is_empty():
		failures.append("Jazz incompatible fill request did not degrade to the quiet authored-safe exit/entry.")
	var choreography_save_run := RunStateScript.new()
	choreography_save_run.start_new("MUSIC-CHOREOGRAPHY-ROUNDTRIP")
	choreography_save_run.remember_music_choreography_state({"profile_id": "jazz", "visit_bar": 6, "stage_id": "build_bass", "stage_index": 1, "next_boundary_bar": 8, "last_fill_bar": 6, "scheduled_transition": {"destination_bar": 8, "fill_id": "jazz_fixture_fill", "started": true}, "feature_release_bar": 8, "role_target": {"drums_low": 0.0}, "role_live": {"drums_low": 0.1}})
	var restored_choreography_run := RunStateScript.new()
	restored_choreography_run.from_dict(choreography_save_run.to_dict())
	if JSON.stringify(restored_choreography_run.music_choreography_state) != JSON.stringify(choreography_save_run.music_choreography_state):
		failures.append("Layer stage and scheduled fill boundary did not survive a RunState save/load round trip.")
	var jazz_outcome_stingers: Dictionary = jazz_8_track.get("stingers", {}) as Dictionary
	for outcome_cue_id in ["jazz_fixture_small_win", "jazz_fixture_loss", "jazz_fixture_big_win"]:
		var outcome_cue: Dictionary = jazz_outcome_stingers.get(outcome_cue_id, {}) as Dictionary
		if outcome_cue.is_empty() or bool(outcome_cue.get("loop", true)) or (outcome_cue.get("outcome_classes", []) as Array).is_empty() or (outcome_cue.get("reverb_pulse", {}) as Dictionary).is_empty():
			failures.append("Jazz outcome fixture %s did not declare a one-shot class and controlled reverb pulse." % outcome_cue_id)
	var deadline_boundary := MusicOutcomeDirectorModelScript.quantized_boundary(1.25, "phrase", 4, 1.0)
	if str(deadline_boundary.get("quantization", "")) != "half_bar" or not bool(deadline_boundary.get("fallback_used", false)) or absf(float(deadline_boundary.get("target_transport_beat", 0.0)) - 2.0) > 0.000001:
		failures.append("Outcome quantization did not fall back from a distant phrase to the largest deadline-safe subdivision.")
	var bad_outcome_track := jazz_8_track.duplicate(true)
	var bad_outcome_stingers: Dictionary = bad_outcome_track.get("stingers", {}) as Dictionary
	var bad_outcome_cue: Dictionary = bad_outcome_stingers.get("jazz_fixture_small_win", {}) as Dictionary
	var bad_outcome_pulse: Dictionary = bad_outcome_cue.get("reverb_pulse", {}) as Dictionary
	bad_outcome_pulse["peak_send"] = 0.9
	bad_outcome_cue["reverb_pulse"] = bad_outcome_pulse
	bad_outcome_stingers["jazz_fixture_small_win"] = bad_outcome_cue
	bad_outcome_track["stingers"] = bad_outcome_stingers
	if JSON.stringify(_music_track_validation_errors(bad_outcome_track)).find("peak_send must stay inside 0..0.45") < 0:
		failures.append("Music validation did not reject an outcome reverb send above its clarity ceiling.")
	var outcome_player: ProceduralMusicPlayer = ProceduralMusicPlayerScript.new()
	outcome_player.set("_current_stem_set", {"stinger_metadata": jazz_outcome_stingers, "harmony_phrase_bars": 4})
	var scheduled_small := outcome_player.schedule_music_outcome_event({"event_token": "systems:small", "outcome_class": "small_win", "magnitude": 8, "tier": "small", "source_game": "roulette", "result_time": 760, "transport_beat": 1.25})
	var duplicate_small := outcome_player.schedule_music_outcome_event({"event_token": "systems:small", "outcome_class": "small_win", "magnitude": 8, "source_game": "roulette", "result_time": 760, "transport_beat": 1.25})
	var small_pulse_peak := outcome_player.music_outcome_director_snapshot(2.5)
	var small_pulse_end := outcome_player.music_outcome_director_snapshot(4.01)
	if not bool(scheduled_small.get("accepted", false)) or bool(scheduled_small.get("controls_blocked", true)) or bool(duplicate_small.get("accepted", true)) or not bool(duplicate_small.get("deduplicated", false)):
		failures.append("Outcome director did not schedule immediately and deduplicate a stable gameplay event token.")
	if absf(float(small_pulse_peak.get("reverb_send", 0.0)) - 0.24) > 0.0001 or float(small_pulse_end.get("reverb_send", -1.0)) != 0.0 or bool(small_pulse_peak.get("shared_full_mix_reverb", true)):
		failures.append("Outcome reverb did not stay role-selected, bounded, and return to baseline on musical beats.")
	var scheduled_big := outcome_player.schedule_music_outcome_event({"event_token": "systems:big", "outcome_class": "big_win", "magnitude": 80, "tier": "big", "source_game": "slot", "result_time": 764, "transport_beat": 10.2})
	var big_envelope: Dictionary = outcome_player.get("_music_event_envelope")
	if not bool(scheduled_big.get("accepted", false)) or float(big_envelope.get("end_beat", 0.0)) - float(big_envelope.get("start_beat", 0.0)) != 16.0:
		failures.append("Explicit big-win outcome did not preserve the true four-musical-bar envelope.")
	if JsonCoerceScript._copy_array(jazz_recipe.get("sections", [])) != ["A", "A", "B", "A", "A", "A", "C", "A"]:
		failures.append("Jazz harmony recipe did not encode AABA followed by AACA.")
	var jazz_state := MusicArrangementSelectorScript.initial_recipe_state(jazz_8_track, 17, "fixture_visit")
	var jazz_sections: Array = [str(jazz_state.get("harmonic_section", "A"))]
	var jazz_c_state: Dictionary = {}
	for phrase_index in range(7):
		jazz_state = MusicArrangementSelectorScript.advance_recipe_state(jazz_8_track, jazz_state, {"phrase_event_index": phrase_index, "event_token": "fixture:%d" % phrase_index})
		jazz_sections.append(str(jazz_state.get("harmonic_section", "")))
		if phrase_index == 5:
			jazz_c_state = jazz_state.duplicate(true)
	if jazz_sections != ["A", "A", "B", "A", "A", "A", "C", "A"]:
		failures.append("Jazz phrase events did not advance the exact AABA/AACA sequence: %s." % [jazz_sections])
	var jazz_selection := MusicArrangementSelectorScript.select(jazz_8_track, {"environment_id": "jazz_fixture"}, {"run_seed": 17, "music_visit_id": "fixture_visit", "music_arrangement_state": jazz_c_state})
	if not bool(jazz_selection.get("valid", false)) or str(jazz_selection.get("compatibility_set_id", "")) != "jazz_c_instrument_contrast" or str(jazz_selection.get("progression_id", "")) != "jazz_a_1":
		failures.append("Jazz C contrast did not preserve A progression authority through its distinct arrangement set: %s." % [jazz_selection])
	var stinger_modes: Dictionary = authored_manifest.get("stinger_loop_modes", {}) as Dictionary
	var fill_modes: Dictionary = authored_manifest.get("fill_loop_modes", {}) as Dictionary
	if int(stinger_modes.get("win_fixture", -1)) != AudioStreamWAV.LOOP_DISABLED or int(fill_modes.get("drum_fill_fixture", -1)) != AudioStreamWAV.LOOP_DISABLED:
		failures.append("Authored stingers and fills must load as one-shots unless explicitly declared looping.")
	var transition_policy: Dictionary = player.music_transition_policy_snapshot_for_environment(authored_environment, 20)
	if str(transition_policy.get("quantize", "")) != "phrase" or int(transition_policy.get("phrase_bars", 0)) != 4 or not bool(transition_policy.get("filler_clips", false)):
		failures.append("Authored transition policy did not expose four-bar phrase and filler-aware switching.")

	var fallback_environment := procedural_environment.duplicate(true)
	var fallback_profile: Dictionary = (fallback_environment.get("music_profile", {}) as Dictionary).duplicate(true)
	fallback_profile["authored_track_id"] = "missing_music_track"
	fallback_environment["music_profile"] = fallback_profile
	var fallback_manifest: Dictionary = player.music_stem_manifest_snapshot_for_environment(fallback_environment, 30)
	if str(fallback_manifest.get("source", "")) != "procedural":
		failures.append("Missing authored_track_id did not silently fall back to procedural stems.")

	var cache_keys := {}
	for heat in [0, 50, 90]:
		var heat_manifest: Dictionary = player.music_stem_manifest_snapshot_for_environment(procedural_environment, int(heat))
		cache_keys[str(heat_manifest.get("cache_key", ""))] = true
		if bool(heat_manifest.get("cache_key_uses_heat", true)):
			failures.append("Procedural music manifest reported a heat-bearing cache key.")
	if cache_keys.size() != 1:
		failures.append("Procedural music cache should hold one stem set across heat sweeps, got %d keys." % cache_keys.size())

	for index in range(10):
		var seeded_environment := procedural_environment.duplicate(true)
		seeded_environment["id"] = "music_seed_%02d" % index
		var manifest: Dictionary = player.music_stem_manifest_snapshot_for_environment(seeded_environment, (index * 11) % 100)
		if str(manifest.get("source", "")) != "procedural":
			failures.append("Procedural stem seed fixture resolved the wrong provider at index %d." % index)
		if not bool(manifest.get("sync_ok", false)):
			failures.append("Procedural stem manifest was not sample-synced at index %d." % index)
		if (manifest.get("present_roles", []) as Array).size() != 9:
			failures.append("Procedural stem manifest should expose seven roles plus two variants at index %d." % index)
	var baked_manifest: Dictionary = player.music_stem_manifest_snapshot_for_environment(procedural_environment, 40, {}, true)
	if not bool(baked_manifest.get("sync_ok", false)) or int(baked_manifest.get("loop_frames", 0)) <= 0:
		failures.append("Baked procedural stem set did not preserve one loop length authority.")

	var calm := {"heat": 20, "bankroll": 120, "debt": []}
	var hot := {"heat": 90, "bankroll": 120, "debt": []}
	var watched := {"heat": 35, "pit_boss_watch": {"active": true, "watched": true}, "staff_attention": {"active": true}}
	var debt_pressure := {"heat": 25, "bankroll": 24, "debt": [{"id": "note", "status": "overdue", "balance": 80}]}
	var showdown := {"heat": 80, "showdown_pending": true, "boss_floor": true}
	var calm_mix: Dictionary = (player.music_mix_snapshot(calm).get("target", {}) as Dictionary)
	var hot_mix: Dictionary = (player.music_mix_snapshot(hot).get("target", {}) as Dictionary)
	if float(hot_mix.get("drums_high", 0.0)) <= float(calm_mix.get("drums_high", 0.0)) + 0.30:
		failures.append("MusicDirector heat matrix did not raise high drum density.")
	if float(hot_mix.get("tension", 0.0)) <= float(calm_mix.get("tension", 0.0)) + 0.10:
		failures.append("MusicDirector heat matrix did not creep in tension above 60 heat.")
	var watched_mix: Dictionary = (player.music_mix_snapshot(watched).get("target", {}) as Dictionary)
	if float(watched_mix.get("tension", 0.0)) <= float(calm_mix.get("tension", 0.0)) + 0.35:
		failures.append("MusicDirector watch matrix did not lift tension.")
	if float(watched_mix.get("lead", 1.0)) >= float(calm_mix.get("lead", 0.0)):
		failures.append("MusicDirector watch matrix did not pull lead back.")
	var debt_mix: Dictionary = (player.music_mix_snapshot(debt_pressure).get("target", {}) as Dictionary)
	if float(debt_mix.get("bass_dark", 0.0)) <= float(calm_mix.get("bass_dark", 0.0)) + 0.40:
		failures.append("MusicDirector debt pressure did not swap toward dark bass.")
	if float(debt_mix.get("pad", 1.0)) >= float(calm_mix.get("pad", 0.0)):
		failures.append("MusicDirector debt pressure did not thin the pad.")
	var showdown_mix: Dictionary = (player.music_mix_snapshot(showdown).get("target", {}) as Dictionary)
	if float(showdown_mix.get("tension", 0.0)) < 0.95 or float(showdown_mix.get("pad", 1.0)) > 0.20:
		failures.append("MusicDirector showdown mix did not enter percussion/heartbeat danger state.")
	var deterministic_a := JSON.stringify(player.music_mix_snapshot(hot).get("target", {}))
	var deterministic_b := JSON.stringify(player.music_mix_snapshot(hot).get("target", {}))
	if deterministic_a != deterministic_b:
		failures.append("MusicDirector mix snapshot changed for identical scripted input.")

	var quantized_player: ProceduralMusicPlayer = ProceduralMusicPlayerScript.new()
	quantized_player.update_music_state(calm)
	quantized_player.update_music_state(watched)
	var mid_bar: Dictionary = quantized_player.music_mix_snapshot({}, 0.50)
	var pending_mid: Dictionary = mid_bar.get("pending", {}) as Dictionary
	if pending_mid.is_empty():
		failures.append("MusicDirector watch change did not wait for the next bar.")
	var target_mid: Dictionary = mid_bar.get("target", {}) as Dictionary
	if float(target_mid.get("tension", 0.0)) > 0.10:
		failures.append("MusicDirector quantized tension unmuted before the bar boundary.")
	var boundary := float(pending_mid.get("target_position", 0.0))
	var after_bar: Dictionary = quantized_player.music_mix_snapshot({}, boundary + 0.01)
	if not (after_bar.get("pending", {}) as Dictionary).is_empty():
		failures.append("MusicDirector pending change did not resolve at the bar boundary.")
	var target_after: Dictionary = after_bar.get("target", {}) as Dictionary
	if float(target_after.get("tension", 0.0)) <= 0.35:
		failures.append("MusicDirector quantized tension did not apply at the bar boundary.")

	var feature_player: ProceduralMusicPlayer = ProceduralMusicPlayerScript.new()
	feature_player.update_feature_music_state({
		"active": true,
		"cue_id": "bonus_music_buffalo",
		"feature_music": {
			"cue_id": "bonus_music_buffalo",
			"duck_background_music": true,
			"volume_db": -10.0,
		},
		"feature_scene": {
			"active": true,
			"scene_id": "feature_fixture",
		},
	})
	var feature_mid: Dictionary = feature_player.music_feature_snapshot({}, 0.50)
	var feature_pending: Dictionary = feature_mid.get("pending", {}) as Dictionary
	if feature_pending.is_empty():
		failures.append("Feature music layer did not wait for the next bar.")
	var feature_target_mid: Dictionary = feature_mid.get("target", {}) as Dictionary
	if float(feature_target_mid.get("feature", 0.0)) > 0.01 or float(feature_target_mid.get("venue_duck", 0.0)) > 0.01:
		failures.append("Feature music layer applied before the bar boundary.")
	var feature_boundary := float(feature_pending.get("target_position", 0.0))
	var feature_after: Dictionary = feature_player.music_feature_snapshot({}, feature_boundary + 0.01)
	var feature_target_after: Dictionary = feature_after.get("target", {}) as Dictionary
	if float(feature_target_after.get("feature", 0.0)) <= 0.50 or float(feature_target_after.get("venue_duck", 0.0)) <= 0.40:
		failures.append("Feature music layer did not apply gain and venue ducking at the bar boundary.")
	feature_player.play_feature_stinger("pinball_super_jackpot", {})
	var stinger_pending_snapshot: Dictionary = feature_player.music_feature_snapshot({}, 0.01)
	var pending_stingers: Array = stinger_pending_snapshot.get("pending_stingers", []) as Array
	if pending_stingers.is_empty():
		failures.append("Feature stinger did not schedule to the next beat.")
	else:
		var pending_stinger: Dictionary = pending_stingers[0] as Dictionary
		var stinger_after: Dictionary = feature_player.music_feature_snapshot({}, float(pending_stinger.get("target_position", 0.0)) + 0.01)
		if (stinger_after.get("stinger_history", []) as Array).is_empty():
			failures.append("Feature stinger did not resolve at its quantized beat.")
	var one_shot_stream: AudioStreamWAV = feature_player.call("_feature_stinger_stream", "big_win", "arcade", 120.0)
	if one_shot_stream == null or one_shot_stream.loop_mode != AudioStreamWAV.LOOP_DISABLED:
		failures.append("Generated music stingers must be one-shot streams.")
	var event_player: ProceduralMusicPlayer = ProceduralMusicPlayerScript.new()
	event_player.update_music_state({"big_win": true, "last_bankroll_delta": 75, "big_win_event_token": "fixture:1"})
	var event_start: Dictionary = event_player.music_event_envelope_snapshot({}, 0.0)
	if int(event_start.get("bars_remaining", 0)) != 4:
		failures.append("Big-win event did not schedule a four-musical-bar envelope.")
	var event_bar_seconds := float((event_start.get("envelope", {}) as Dictionary).get("start_bar", 1)) * float(event_player.music_mix_snapshot().get("bar_seconds", 0.0))
	var event_after: Dictionary = event_player.music_event_envelope_snapshot({}, event_bar_seconds + float(event_player.music_mix_snapshot().get("bar_seconds", 0.0)) * 4.01)
	if bool(event_after.get("active", true)) or int(event_after.get("bars_remaining", -1)) != 0:
		failures.append("Big-win event envelope did not expire after consuming four musical bars.")
	event_player.update_music_state({"big_win": true, "last_bankroll_delta": 90, "big_win_event_token": "fixture:2"})
	var cooldown_event: Dictionary = event_player.music_event_envelope_snapshot({}, event_bar_seconds + float(event_player.music_mix_snapshot().get("bar_seconds", 0.0)) * 4.01)
	if str((cooldown_event.get("envelope", {}) as Dictionary).get("event_token", "")) != "fixture:1":
		failures.append("Big-win event cooldown did not prevent an immediate envelope retrigger.")

	var sfx_text := FileAccess.get_file_as_string("res://scripts/ui/sfx_player.gd")
	if sfx_text.find("_sample_bonus_music") != -1:
		failures.append("SfxPlayer still contains generated bonus music samplers.")
	var sfx := SfxPlayerScript.new()
	var sfx_fidelity: Dictionary = sfx.audio_fidelity_contract_snapshot()
	if int(sfx_fidelity.get("web_sample_rate", 0)) != int(sfx_fidelity.get("native_sample_rate", -1)) or int(sfx_fidelity.get("web_sample_rate", 0)) < 22050:
		failures.append("Web SFX must render from the same 22.05 kHz synthesis source as native playback.")
	if not bool(sfx_fidelity.get("shared_synthesis", false)) or not bool(sfx_fidelity.get("web_incremental_prewarm", false)):
		failures.append("Web SFX fidelity parity must retain bounded incremental prewarming.")
	if not bool(sfx_fidelity.get("web_delivery_uses_preencoded_pcm", false)) or int(sfx_fidelity.get("web_delivery_event_count", 0)) != SfxPlayerScript.WEB_DELIVERY_EVENT_IDS.size():
		failures.append("Web SFX must use the complete pre-encoded desktop-rate delivery bank.")
	for delivery_event_value in SfxPlayerScript.WEB_DELIVERY_EVENT_IDS:
		var delivery_event_id := str(delivery_event_value)
		if not FileAccess.file_exists("res://assets/audio/sfx_web/%s.bthsfx" % delivery_event_id):
			failures.append("Web SFX delivery bank is missing %s." % delivery_event_id)
	var web_sfx_delivery: AudioStreamWAV = sfx.call("_web_delivery_event_stream", "blackjack_card")
	if web_sfx_delivery == null or web_sfx_delivery.format != AudioStreamWAV.FORMAT_IMA_ADPCM or web_sfx_delivery.mix_rate != 22050 or web_sfx_delivery.data.is_empty() or str(web_sfx_delivery.get_meta(WebAudioBridgeScript.PCM_BASE64_META, "")).is_empty():
		failures.append("Web SFX delivery master could not be decoded and prepared for the browser bridge.")
	var director_cues: Array = sfx.debug_music_director_cue_ids()
	if not director_cues.has("bonus_music_buffalo") or not director_cues.has("bonus_music_pinball"):
		failures.append("SfxPlayer did not keep feature music cue ids routed to the MusicDirector.")
	var bonus_preview: AudioStreamWAV = sfx.preview_event_stream("bonus_music_pinball")
	if bonus_preview != null and bonus_preview.loop_mode == AudioStreamWAV.LOOP_FORWARD:
		failures.append("SfxPlayer still treats feature music cues as local looping SFX.")

	var jazz_environment := _music_environment_by_archetype(library, "jazz_club")
	var grand_environment := _music_environment_by_archetype(library, "grand_casino")
	var motel_environment := _music_environment_by_archetype(library, "motel")
	if jazz_environment.is_empty() or grand_environment.is_empty() or motel_environment.is_empty():
		failures.append("Music composition fixtures could not find jazz, grand, and motel archetypes.")
	else:
		var jazz_theory: Dictionary = player.music_theory_snapshot_for_environment(jazz_environment, 20)
		var grand_theory: Dictionary = player.music_theory_snapshot_for_environment(grand_environment, 20)
		var motel_theory: Dictionary = player.music_theory_snapshot_for_environment(motel_environment, 20)
		if str(jazz_theory.get("arrangement_form", "")) != "AABA" or int(jazz_theory.get("bridge_phrase_index", -1)) < 0:
			failures.append("Music theory snapshot did not expose AABA bridge form.")
		if float(jazz_theory.get("swing_amount", 0.0)) <= float(grand_theory.get("swing_amount", 0.0)) + 0.05:
			failures.append("Jazz music theory did not expose a stronger swing amount than grand casino.")
		if (jazz_theory.get("voicing_inversions", []) as Array).is_empty() or (jazz_theory.get("chord_voicings", []) as Array).is_empty():
			failures.append("Music theory snapshot did not expose voice-led pad inversions.")
		var jazz_palette: Dictionary = jazz_theory.get("instrument_palette", {}) as Dictionary
		var grand_palette: Dictionary = grand_theory.get("instrument_palette", {}) as Dictionary
		var motel_palette: Dictionary = motel_theory.get("instrument_palette", {}) as Dictionary
		if str(jazz_palette.get("id", "")) == str(grand_palette.get("id", "")) or str(motel_palette.get("id", "")) == str(grand_palette.get("id", "")):
			failures.append("Music instrument palettes did not differ by venue archetype.")
	# These headless-only Nodes are never inserted into a SceneTree, so free them
	# synchronously and release cached float PCM resources before process exit.
	player.free()
	outcome_player.free()
	quantized_player.free()
	feature_player.free()
	event_player.free()
	sfx.free()


func _check_music_wav_info_cache(failures: Array) -> void:
	var fixture_path := "user://music_wav_cache_fixture.wav"
	var absolute_path := ProjectSettings.globalize_path(fixture_path)
	DirAccess.remove_absolute(absolute_path)
	ContentLibraryScript.clear_music_wav_info_cache()
	var missing := ContentLibraryScript.inspect_music_wav(fixture_path)
	var missing_snapshot := ContentLibraryScript.music_wav_info_cache_snapshot()
	if bool(missing.get("valid", true)) or int(missing_snapshot.get("entries", -1)) != 0:
		failures.append("WAV inspection cache retained a missing-file error that could poison a later delivery.")

	if not _write_music_wav_cache_fixture(fixture_path, 1, true):
		failures.append("WAV inspection cache test could not write its valid fixture.")
		return
	var first := ContentLibraryScript.inspect_music_wav(fixture_path)
	var first_snapshot := ContentLibraryScript.music_wav_info_cache_snapshot()
	first["frames"] = 999
	var cached := ContentLibraryScript.inspect_music_wav(fixture_path)
	var hit_snapshot := ContentLibraryScript.music_wav_info_cache_snapshot()
	if not bool(cached.get("valid", false)) or int(cached.get("frames", 0)) != 1 or cached.has("path") or cached.has("_cache_path"):
		failures.append("WAV inspection cache did not return an isolated copy of the cached validation result.")
	if int(first_snapshot.get("entries", 0)) != 1 or int(first_snapshot.get("misses", 0)) != 1 or int(hit_snapshot.get("hits", 0)) != 1:
		failures.append("WAV inspection cache did not record one miss followed by one hit for an unchanged file.")

	if not _write_music_wav_cache_fixture(fixture_path, 2, true):
		failures.append("WAV inspection cache test could not rewrite its valid fixture.")
	else:
		var rewritten := ContentLibraryScript.inspect_music_wav(fixture_path)
		var rewritten_snapshot := ContentLibraryScript.music_wav_info_cache_snapshot()
		if not bool(rewritten.get("valid", false)) or int(rewritten.get("frames", 0)) != 2 or int(rewritten_snapshot.get("misses", 0)) != 2 or int(rewritten_snapshot.get("entries", 0)) != 1:
			failures.append("WAV inspection cache did not invalidate its stale entry after the file length changed.")

	if not _write_music_wav_cache_fixture(fixture_path, 3, false):
		failures.append("WAV inspection cache test could not write its invalid fixture.")
	else:
		var invalid_first := ContentLibraryScript.inspect_music_wav(fixture_path)
		var invalid_cached := ContentLibraryScript.inspect_music_wav(fixture_path)
		var invalid_snapshot := ContentLibraryScript.music_wav_info_cache_snapshot()
		if bool(invalid_first.get("valid", true)) or invalid_first != invalid_cached or str(invalid_first.get("error", "")).is_empty():
			failures.append("WAV inspection cache did not preserve an actionable invalid-file result on a cache hit.")
		if int(invalid_snapshot.get("entries", 0)) != 1 or int(invalid_snapshot.get("misses", 0)) != 3 or int(invalid_snapshot.get("hits", 0)) != 2:
			failures.append("WAV inspection cache counters or stale-entry replacement were incorrect after an invalid rewrite.")
		if int(invalid_snapshot.get("max_entries", 0)) != ContentLibraryScript.MUSIC_WAV_INFO_CACHE_MAX_ENTRIES:
			failures.append("WAV inspection cache did not expose its bounded-growth limit.")

	ContentLibraryScript.clear_music_wav_info_cache()
	var cleared_snapshot := ContentLibraryScript.music_wav_info_cache_snapshot()
	if int(cleared_snapshot.get("entries", -1)) != 0 or int(cleared_snapshot.get("hits", -1)) != 0 or int(cleared_snapshot.get("misses", -1)) != 0:
		failures.append("WAV inspection cache clear hook did not reset entries and diagnostics.")
	DirAccess.remove_absolute(absolute_path)


func _write_music_wav_cache_fixture(path: String, frames: int, valid_signature: bool) -> bool:
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		return false
	file.big_endian = false
	var data_bytes := frames * 3
	var padded_data_bytes := data_bytes + (data_bytes % 2)
	var riff_size := 4 + 8 + 16 + 8 + padded_data_bytes
	file.store_buffer(("RIFF" if valid_signature else "NOPE").to_ascii_buffer())
	file.store_32(riff_size)
	file.store_buffer("WAVE".to_ascii_buffer())
	file.store_buffer("fmt ".to_ascii_buffer())
	file.store_32(16)
	file.store_16(1)
	file.store_16(1)
	file.store_32(44100)
	file.store_32(132300)
	file.store_16(3)
	file.store_16(24)
	file.store_buffer("data".to_ascii_buffer())
	file.store_32(data_bytes)
	for byte_index in range(data_bytes):
		file.store_8((byte_index * 17) & 0xff)
	if data_bytes % 2 != 0:
		file.store_8(0)
	file.close()
	return true


func _music_environment_with_authored_track(library: ContentLibrary) -> Dictionary:
	for archetype_value in library.environment_archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		var profile: Dictionary = archetype.get("music_profile", {}) as Dictionary
		if not str(profile.get("authored_track_id", "")).strip_edges().is_empty():
			return archetype.duplicate(true)
	return {}


func _music_environment_without_authored_track(library: ContentLibrary) -> Dictionary:
	for archetype_value in library.environment_archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		var profile: Dictionary = archetype.get("music_profile", {}) as Dictionary
		if str(profile.get("authored_track_id", "")).strip_edges().is_empty():
			return archetype.duplicate(true)
	return {}


func _music_environment_by_archetype(library: ContentLibrary, archetype_id: String) -> Dictionary:
	for archetype_value in library.environment_archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		if str(archetype.get("id", "")) == archetype_id:
			return archetype.duplicate(true)
	return {}


# Checks one deterministic vertical slice where M2 systems affect each other through existing contracts.
func _check_m2_system_interaction_scenario(library: ContentLibrary, failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("M2-SYSTEM-SCENARIO")
	run_state.game_clock_minutes = 20 * 60
	var generator: RunGenerator = RunGeneratorScript.new(library)
	var start_environment := _harness_arrive(generator, run_state, failures, "M2 interaction initial arrival")
	var environment_target := _first_target_with_game(library, _unique_strings(start_environment.next_archetypes, start_environment.travel_hooks), "")
	var environment := _harness_arrive(generator, run_state, failures, "M2 interaction destination arrival", environment_target)
	if run_state.current_environment.is_empty():
		failures.append("M2 scenario did not enter a generated environment.")
		return
	if environment.game_ids.is_empty():
		failures.append("M2 scenario generated environment without a game option.")
		return

	run_state.change_bankroll(RunState.DEFAULT_BANKROLL - run_state.bankroll)
	var pressure_result := _fixture_system_pressure_result(run_state.current_environment, -60, "A cold streak tightens the run.")
	GameModule.apply_result(run_state, pressure_result)
	if run_state.economy() != "volatile":
		failures.append("M2 scenario did not create observable economy pressure.")

	var item_def := library.item("instant_coffee")
	if item_def.is_empty():
		failures.append("M2 scenario item fixture is missing: instant_coffee.")
		return
	GameModule.apply_result(run_state, _fixture_item_purchase_result(item_def, 4, str(run_state.current_environment.get("id", ""))))
	if not run_state.inventory.has("instant_coffee"):
		failures.append("M2 scenario did not buy an item through result-delta inventory.")

	var game: GameModule = null
	var risky_action: Dictionary = {}
	for candidate_id_value in environment.game_ids:
		var candidate_id := str(candidate_id_value)
		var candidate_game_value = _load_surface_contract_game(library, candidate_id, failures)
		if candidate_game_value == null or not candidate_game_value is GameModule:
			continue
		var candidate_game: GameModule = candidate_game_value
		var candidate_actions := candidate_game.actions(run_state, run_state.current_environment)
		var candidate_cheats: Array = candidate_actions.get("cheat_actions", []) if typeof(candidate_actions.get("cheat_actions", [])) == TYPE_ARRAY else []
		if candidate_cheats.is_empty():
			continue
		var positive_heat_action: Dictionary = {}
		for candidate_action_value in candidate_cheats:
			if typeof(candidate_action_value) != TYPE_DICTIONARY:
				continue
			var candidate_action: Dictionary = candidate_action_value
			if int(candidate_action.get("suspicion_delta", 0)) > 0:
				positive_heat_action = candidate_action.duplicate(true)
				break
		if positive_heat_action.is_empty():
			continue
		game = candidate_game
		risky_action = positive_heat_action
		break
	if game == null:
		failures.append("M2 scenario generated no game with a risky action.")
		return
	var before_suspicion := run_state.suspicion_level()
	var risky_action_id := str(risky_action.get("id", ""))
	var risky_result := game.resolve(risky_action_id, 5, run_state, run_state.current_environment, run_state.create_rng())
	_check_action_result_shape(risky_result, "cheat", failures)
	if bool(risky_result.get("host_apply_result", false)):
		GameModule.apply_result(run_state, risky_result, run_state.create_rng("m2_risky_host_apply"))
	if run_state.suspicion_level() <= before_suspicion:
		failures.append("M2 scenario risky action did not change suspicion/security state.")
	if (run_state.suspicion.get("cues", []) as Array).is_empty():
		failures.append("M2 scenario risky action did not create a security cue.")

	var scenario_environment := run_state.current_environment.duplicate(true)
	var event_ids := _string_array_from_variant(scenario_environment.get("event_ids", []))
	if not event_ids.has("parking_lot_tip"):
		event_ids.append("parking_lot_tip")
	scenario_environment["event_ids"] = event_ids
	var travel_hooks := _string_array_from_variant(scenario_environment.get("travel_hooks", []))
	if not travel_hooks.has("small_underground_casino"):
		travel_hooks.append("small_underground_casino")
	scenario_environment["travel_hooks"] = travel_hooks
	# This probe augments the already-installed production room in place. Sending
	# the same active scenario through set_environment() starts a new visit and
	# intentionally clears its derived semantic authorization until the UI host
	# rebuilds records; there is no UI controller in this model-only check.
	run_state.current_environment = scenario_environment
	run_state.current_environment["layout"] = EnvironmentInstance.ensure_generated_layout(run_state.current_environment)

	var underground_route := library.route("small_underground_casino")
	if underground_route.is_empty():
		failures.append("M2 scenario route fixture is missing: small_underground_casino.")
		return
	if bool(run_state.travel_route_status(underground_route).get("available", true)):
		failures.append("M2 scenario route should be locked before the event outcome.")
	var event_def := library.event("parking_lot_tip")
	if event_def.is_empty():
		failures.append("M2 scenario event fixture is missing: parking_lot_tip.")
		return
	var event := EventModule.new()
	event.setup(event_def)
	if not event.can_trigger(run_state, run_state.current_environment):
		failures.append("M2 scenario event did not respond as eligible from current system state.")
		return
	var event_before := _run_state_result_snapshot(run_state)
	var event_result := event.resolve(run_state, run_state.current_environment, "follow_tip")
	_check_event_result_delta_shape(event_result, failures)
	_check_event_result_applied(event_before, run_state, event_result, "M2 scenario event result", failures)
	if not bool(run_state.narrative_flags.get("underground_tip", false)):
		failures.append("M2 scenario event did not set its downstream travel flag.")
	if not bool(run_state.travel_route_status(underground_route).get("available", false)):
		failures.append("M2 scenario event outcome did not unlock the gated route choice.")

	var before_travel_bankroll := run_state.bankroll
	var before_travel_suspicion := run_state.suspicion_level()
	var travel_status := run_state.travel_route_status(underground_route)
	var travel_result := _fixture_travel_result(run_state, underground_route, "small_underground_casino")
	GameModule.apply_result(run_state, travel_result)
	if run_state.bankroll != before_travel_bankroll - int(travel_status.get("cost", underground_route.get("cost", 0))):
		failures.append("M2 scenario travel cost did not apply through result-delta.")
	if run_state.suspicion_level() != before_travel_suspicion + int(underground_route.get("suspicion_delta", 0)):
		failures.append("M2 scenario travel risk did not apply through result-delta.")

	var lender := library.lender("street_lender")
	if lender.is_empty():
		failures.append("M2 scenario lender fixture is missing: street_lender.")
		return
	var lender_result := _fixture_lender_result(run_state, lender, "street_lender")
	GameModule.apply_result(run_state, lender_result)
	if run_state.debt.is_empty():
		failures.append("M2 scenario supported lender did not add debt.")
	if run_state.economy() != "distressed":
		failures.append("M2 scenario debt plus low bankroll did not affect economy pressure.")

	var service := library.service("cashier_tip")
	if service.is_empty():
		failures.append("M2 scenario service fixture is missing: cashier_tip.")
		return
	var service_before_bankroll := run_state.bankroll
	var service_before_suspicion := run_state.suspicion_level()
	var service_result := _fixture_service_result(run_state, service, "cashier_tip")
	GameModule.apply_result(run_state, service_result)
	if run_state.bankroll != service_before_bankroll - int(service.get("cost", 0)):
		failures.append("M2 scenario service cost did not apply through result-delta.")
	if run_state.suspicion_level() >= service_before_suspicion:
		failures.append("M2 scenario supported service did not reduce suspicion pressure.")

	var expected := _save_service_expected_snapshot(run_state)
	var save_service: SaveService = SaveServiceScript.new()
	var slot_id := "foundation_check_m2_system_scenario"
	var save_error: Error = save_service.save_run(run_state, slot_id)
	if save_error != OK:
		failures.append("Save service could not save M2 system scenario state: %s." % save_error)
		return
	var loaded = save_service.load_run(slot_id)
	if loaded == null:
		failures.append("Save service could not reload M2 system scenario state.")
		return
	_check_run_state_save_round_trip(expected, loaded.to_dict(), failures)


# Checks the boss-floor demo objective triggers and resolves The House Calls through RunState.
func _check_demo_boss_objective_foundation(library: ContentLibrary, failures: Array) -> void:
	var boss_archetype := _archetype_by_id(library, "grand_casino")
	if boss_archetype.is_empty():
		failures.append("Grand Casino boss archetype is missing.")
		return
	_check_grand_casino_spatial_split(library, boss_archetype, failures)
	call("_check_cage_environment_rework", library, failures)
	_check_grand_casino_chips_and_cage(library, boss_archetype, failures)
	_check_grand_casino_living_floor(library, boss_archetype, failures)
	_check_grand_casino_staff_rotation(library, boss_archetype, failures)
	_check_grand_casino_players_card_tiers(library, boss_archetype, failures)
	var objective: Dictionary = boss_archetype.get("demo_objective", {}) if typeof(boss_archetype.get("demo_objective", {})) == TYPE_DICTIONARY else {}
	if objective.is_empty() or str(objective.get("type", "")) != "bankroll_target":
		failures.append("Grand Casino must define a bankroll-target demo objective.")
		return
	var finale_event_id := str(objective.get("finale_event_id", ""))
	if finale_event_id != "the_house_calls":
		failures.append("Grand Casino demo objective must route into The House Calls finale event.")
		return
	if int(objective.get("target_bankroll", -1)) != 0:
		failures.append("Grand Casino Players Card objective should not require a total bankroll target.")
	var route := library.route("grand_casino")
	if route.is_empty() or int(route.get("cost", 0)) < 70:
		failures.append("Grand Casino route must exist and keep a meaningful buy-in.")
	elif int(route.get("requires_travel_count_min", 0)) < 1 or not bool(route.get("hide_until_travel_count_met", false)):
		failures.append("Grand Casino route should stay hidden until at least one travel has occurred.")
	var underground := _archetype_by_id(library, "small_underground_casino")
	if underground.is_empty() or not JsonCoerceScript._string_array(underground.get("next_archetypes", [])).has("grand_casino"):
		failures.append("Underground casino must route to the Grand Casino boss floor.")
	for boss_event_id in ["pit_boss_sweep", "comped_suite_offer", "eye_in_the_sky", "high_roller_cashout", "the_house_calls"]:
		var event := library.event(boss_event_id)
		if event.is_empty() or not JsonCoerceScript._string_array(event.get("scopes", [])).has("boss"):
			failures.append("Boss-only event is missing or not scoped to boss: %s." % boss_event_id)
	var finale_event := library.event(finale_event_id)
	if finale_event.is_empty() or str(finale_event.get("type", "")) != "landmark":
		failures.append("The House Calls must be authored as a landmark boss event.")
		return
	var high_roller_event := library.event("high_roller_cashout")
	if high_roller_event.is_empty() or str(high_roller_event.get("type", "")) != "landmark":
		failures.append("High-roller cashout must be authored as a landmark boss event.")
		return

	var run_state: RunState = RunStateScript.new()
	run_state.start_new("M2-FUN-BOSS")
	var rng := run_state.create_rng("boss-objective")
	var environment := EnvironmentInstance.from_archetype(boss_archetype, 3, rng, library)
	run_state.set_environment(environment.to_dict())
	var high_roller_target := int(objective.get("high_roller_target_bankroll", 0))
	var high_roller_net := int(objective.get("high_roller_net_winnings", 0))
	var high_roller_min_games := int(objective.get("high_roller_min_grand_casino_games", 0))
	var high_roller_max_heat := int(objective.get("high_roller_max_heat", -1))
	var showdown_heat_threshold := int(objective.get("showdown_heat_threshold", 0))
	var forced_showdown_heat_threshold := int(objective.get("forced_showdown_heat_threshold", 0))
	if high_roller_target != 0:
		failures.append("Grand Casino Players Card objective should be gated by net Grand Casino winnings, not total bankroll.")
	if high_roller_net != 30 or high_roller_min_games != 5:
		failures.append("Grand Casino Gold review should use the data-tuned five-game, $30 net target.")
	if high_roller_net <= 0 or high_roller_min_games <= 0 or high_roller_max_heat < 0:
		failures.append("Grand Casino clean lane must define net winnings, game count, and max heat.")
	if showdown_heat_threshold <= high_roller_max_heat or forced_showdown_heat_threshold <= showdown_heat_threshold:
		failures.append("Grand Casino heat lane thresholds should escalate above clean-route heat.")
	if str(objective.get("showdown_event_id", "")) != "the_house_calls":
		failures.append("Grand Casino heat lane must name The House Calls as showdown_event_id.")
	if str(objective.get("high_roller_event_id", "")) != "high_roller_cashout":
		failures.append("Grand Casino clean lane must name high_roller_cashout as high_roller_event_id.")

	var travel_sync_run: RunState = RunStateScript.new()
	travel_sync_run.start_new("M2-FUN-BOSS-TRAVEL-SYNC")
	travel_sync_run.bankroll = 350
	travel_sync_run.set_environment(environment.to_dict())
	var route_cost := maxi(0, int(route.get("cost", 100)))
	var expected_entry_after_cost := travel_sync_run.bankroll - route_cost
	var travel_sync_deltas := GameModule.empty_result_deltas()
	travel_sync_deltas["bankroll_delta"] = -route_cost
	var travel_sync_result := GameModule.build_action_result({
		"ok": true,
		"type": "travel",
		"source_id": "travel",
		"action_id": "confirm_travel",
		"action_kind": "travel",
		"deltas": travel_sync_deltas,
		"environment_id": str(travel_sync_run.current_environment.get("id", "")),
		"environment_archetype_id": "grand_casino",
		"message": "Travel sync fixture.",
	})
	GameModule.apply_result(travel_sync_run, travel_sync_result)
	if int(travel_sync_run.narrative_flags.get("grand_casino_entry_bankroll", -1)) != expected_entry_after_cost:
		failures.append("Grand Casino entry bankroll should be recorded after the travel buy-in is paid.")
	if int(travel_sync_run.demo_objective_status().get("grand_casino_net_winnings", -1)) != 0:
		failures.append("Grand Casino net winnings should start at $0 after the travel buy-in is paid.")

	var entry_bankroll := int(run_state.narrative_flags.get("grand_casino_entry_bankroll", run_state.bankroll))
	run_state.bankroll = entry_bankroll + high_roller_net - 1
	var status_before := run_state.demo_objective_status()
	if not bool(status_before.get("active", false)) or not bool(status_before.get("grand_casino_objective", false)):
		failures.append("Boss objective should report the Grand Casino dual-lane model.")
	if bool(status_before.get("complete", true)) or bool(status_before.get("high_roller_ready", false)) or bool(status_before.get("showdown_pending", false)):
		failures.append("Boss objective should be incomplete below clean and heat route targets.")
	var lanes: Dictionary = status_before.get("lanes", {})
	if not lanes.has("clean") or not lanes.has("heat"):
		failures.append("Grand Casino objective status did not expose both clean and heat lanes.")

	var non_boss_run: RunState = RunStateScript.new()
	non_boss_run.start_new("M2-FUN-BOSS-NON-BOSS")
	var non_boss_environment := environment.to_dict()
	non_boss_environment["id"] = "casino_non_boss_objective_fixture"
	non_boss_environment["archetype_id"] = "gas_station_casino"
	non_boss_environment["kind"] = "casino"
	non_boss_environment["event_ids"] = []
	non_boss_run.set_environment(non_boss_environment)
	non_boss_run.bankroll = RunState.DEFAULT_BANKROLL + high_roller_net
	var non_boss_status := non_boss_run.demo_objective_status()
	if bool(non_boss_status.get("active", false)):
		failures.append("Grand Casino boss objective should not appear outside the boss floor.")
	non_boss_run.evaluate_environment_objective_state()
	if bool(non_boss_run.narrative_flags.get("demo_finale_pending", false)) or JsonCoerceScript._string_array(non_boss_run.current_environment.get("event_ids", [])).has(finale_event_id):
		failures.append("The House Calls triggered outside the boss floor.")
	if non_boss_run.run_status != RunState.RUN_STATUS_ACTIVE:
		failures.append("Non-boss objective fixture should not end or fail the run.")

	var clean_run: RunState = RunStateScript.new()
	clean_run.start_new("M2-FUN-BOSS-CLEAN")
	clean_run.set_environment(environment.to_dict())
	if not _prepare_players_card_gold_ready(clean_run, library, failures):
		failures.append("Grand Casino clean route could not reach sequential Gold readiness.")
	var clean_status := clean_run.demo_objective_status()
	if not bool(clean_status.get("high_roller_ready", false)) or not bool(clean_status.get("players_card_ready", false)) or not bool(clean_run.narrative_flags.get("high_roller_cashout_pending", false)):
		failures.append("Grand Casino clean lane did not report Players Card readiness.")
	if bool(clean_run.narrative_flags.get("demo_victory", false)) or clean_run.run_status != RunState.RUN_STATUS_ACTIVE:
		failures.append("Grand Casino clean lane should not set victory during A1 state reporting.")
	var ready_cage := CageCounterViewModelScript.build(clean_run)
	var ready_card: Dictionary = ready_cage.get("card", {}) if typeof(ready_cage.get("card", {})) == TYPE_DICTIONARY else {}
	if str(JsonCoerceScript._copy_dict(ready_cage.get("host", {})).get("name", "")) != "Linda" or not bool(ready_card.get("can_review", false)) or str(ready_card.get("review_state", "")) != "ready":
		failures.append("Cage view model did not expose Linda and the ready Players Card review.")
	if JsonCoerceScript._copy_array(ready_cage.get("promotions", [])).is_empty():
		failures.append("Cage view model did not populate Players Card tier benefits and comps.")

	var save_service: SaveService = SaveServiceScript.new()
	var clean_slot_id := "foundation_check_grand_casino_clean_ready"
	var save_error: Error = save_service.save_run(clean_run, clean_slot_id)
	if save_error != OK:
		failures.append("Save service could not save Grand Casino clean objective state: %s." % save_error)
		return
	var loaded_clean = save_service.load_run(clean_slot_id)
	if loaded_clean == null:
		failures.append("Save service could not reload Grand Casino clean objective state.")
		return
	var loaded_clean_status: Dictionary = loaded_clean.demo_objective_status()
	if not bool(loaded_clean_status.get("high_roller_ready", false)) or str(loaded_clean_status.get("players_card_next_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_GOLD:
		failures.append("Grand Casino clean objective metadata did not survive SaveService load.")
	if JsonCoerceScript._string_array(loaded_clean.current_environment.get("event_ids", [])).has("high_roller_cashout"):
		failures.append("Players Card review should remain at the Cage instead of the Grand Casino event surface.")
	var high_roller_module := EventModule.new()
	high_roller_module.setup(high_roller_event)
	var high_roller_choices: Array = high_roller_module.choices(loaded_clean, loaded_clean.current_environment)
	if high_roller_choices.size() != 1 or str((high_roller_choices[0] as Dictionary).get("id", "")) != "high_roller_cashout":
		failures.append("Cage Players Card action should expose one deliberate claim response when clean readiness is pending.")
	var cashout_result := high_roller_module.resolve(loaded_clean, loaded_clean.current_environment, "high_roller_cashout")
	if not bool(cashout_result.get("ok", false)) or loaded_clean.run_status != RunState.RUN_STATUS_ENDED:
		failures.append("Players Card claim did not end the run in demo victory.")
	if not bool(loaded_clean.narrative_flags.get("demo_victory", false)) or str(loaded_clean.narrative_flags.get("demo_victory_route", "")) != "high_roller_cashout":
		failures.append("Players Card claim did not set the canonical clean victory route.")
	if bool(loaded_clean.narrative_flags.get("high_roller_cashout_pending", true)) or bool(loaded_clean.narrative_flags.get("grand_casino_high_roller_ready", true)):
		failures.append("Players Card claim did not clear pending clean-route flags.")
	if str(loaded_clean.current_demo_victory_message()).find("Players Card") == -1:
		failures.append("Players Card victory message did not mention the card.")
	var high_roller_victory_round_trip_status := "unsaved"
	var high_roller_win_slot_id := "foundation_check_high_roller_cashout_win"
	save_error = save_service.save_run(loaded_clean, high_roller_win_slot_id)
	if save_error != OK:
		failures.append("Save service could not save Players Card win state: %s." % save_error)
		return
	var loaded_high_roller_win = save_service.load_run(high_roller_win_slot_id)
	if loaded_high_roller_win == null:
		failures.append("Save service could not reload Players Card win state.")
		return
	high_roller_victory_round_trip_status = str(loaded_high_roller_win.run_status)
	if loaded_high_roller_win.run_status != RunState.RUN_STATUS_ENDED or not bool(loaded_high_roller_win.narrative_flags.get("demo_victory", false)):
		failures.append("Players Card win status did not survive SaveService load.")
	if str(loaded_high_roller_win.narrative_flags.get("demo_victory_route", "")) != "high_roller_cashout":
		failures.append("Players Card win route did not survive SaveService load.")
	if bool(loaded_high_roller_win.narrative_flags.get("high_roller_cashout_pending", true)) or bool(loaded_high_roller_win.narrative_flags.get("grand_casino_high_roller_ready", true)):
		failures.append("Players Card win reloaded with pending clean-route flags.")
	if str(loaded_high_roller_win.current_demo_victory_message()).find("Players Card") == -1:
		failures.append("Players Card win message did not survive SaveService load.")

	var cheated_cashout_run: RunState = RunStateScript.new()
	cheated_cashout_run.start_new("M2-FUN-BOSS-CHEATED-CASHOUT")
	cheated_cashout_run.set_environment(environment.to_dict())
	var cheat_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "blackjack",
		"game_id": "blackjack",
		"action_id": "peek_fixture",
		"action_kind": "cheat",
		"stake": 0,
		"deltas": GameModule.empty_result_deltas(),
		"environment_id": str(cheated_cashout_run.current_environment.get("id", "")),
		"message": "Cheat evidence fixture.",
	})
	cheated_cashout_run.record_grand_casino_game_result(cheat_result)
	for game_index in range(high_roller_min_games):
		var cheated_progress_deltas := GameModule.empty_result_deltas()
		cheated_progress_deltas["story_log"] = [{"type": "game_action", "game_id": "blackjack", "stake_cost": 12 + game_index}]
		var cheated_progress_result := GameModule.build_action_result({
			"ok": true,
			"type": "game_action",
			"source_id": "blackjack",
			"game_id": "blackjack",
			"action_id": "cheated_progress",
			"action_kind": "legal",
			"stake": 12 + game_index,
			"deltas": cheated_progress_deltas,
			"environment_id": str(cheated_cashout_run.current_environment.get("id", "")),
			"message": "Cheated cashout progress.",
		})
		cheated_cashout_run.record_grand_casino_game_result(cheated_progress_result)
	cheated_cashout_run.bankroll = int(cheated_cashout_run.narrative_flags.get("grand_casino_entry_bankroll", 0)) + high_roller_net
	cheated_cashout_run.evaluate_environment_objective_state()
	var cheated_cashout_status := cheated_cashout_run.demo_objective_status()
	if bool(cheated_cashout_status.get("high_roller_ready", false)) or bool(cheated_cashout_run.narrative_flags.get("high_roller_cashout_pending", false)):
		failures.append("Cheated Grand Casino player should not receive the Players Card.")
	if not bool(cheated_cashout_status.get("showdown_pending", false)) or str(cheated_cashout_run.narrative_flags.get("grand_casino_showdown_trigger_reason", "")) != "dirty_money":
		failures.append("Cheated Grand Casino money target should route to the Pit Boss Showdown.")
	if int(cheated_cashout_status.get("grand_casino_open_cheat_actions", 0)) <= 0:
		failures.append("Grand Casino open cheat action count was not tracked.")
	var blocked_cage := CageCounterViewModelScript.build(cheated_cashout_run)
	var blocked_card: Dictionary = blocked_cage.get("card", {}) if typeof(blocked_cage.get("card", {})) == TYPE_DICTIONARY else {}
	if str(blocked_card.get("review_state", "")) != "ineligible" or bool(blocked_card.get("can_review", true)) or str(blocked_card.get("review_detail", "")).find("permanently") == -1:
		failures.append("Cage view model did not make permanent Players Card ineligibility visible.")

	var hot_cashout_run: RunState = RunStateScript.new()
	hot_cashout_run.start_new("M2-FUN-BOSS-HOT-CASHOUT")
	hot_cashout_run.set_environment(environment.to_dict())
	hot_cashout_run.add_suspicion("cashout_heat_fixture", high_roller_max_heat + 1, "behavior")
	for game_index in range(high_roller_min_games):
		var hot_progress_deltas := GameModule.empty_result_deltas()
		hot_progress_deltas["story_log"] = [{"type": "game_action", "game_id": "blackjack", "stake_cost": 14 + game_index}]
		var hot_progress_result := GameModule.build_action_result({
			"ok": true,
			"type": "game_action",
			"source_id": "blackjack",
			"game_id": "blackjack",
			"action_id": "hot_progress",
			"action_kind": "legal",
			"stake": 14 + game_index,
			"deltas": hot_progress_deltas,
			"environment_id": str(hot_cashout_run.current_environment.get("id", "")),
			"message": "Hot cashout progress.",
		})
		hot_cashout_run.record_grand_casino_game_result(hot_progress_result)
	hot_cashout_run.bankroll = int(hot_cashout_run.narrative_flags.get("grand_casino_entry_bankroll", 0)) + high_roller_net
	hot_cashout_run.evaluate_environment_objective_state()
	var hot_cashout_status := hot_cashout_run.demo_objective_status()
	if bool(hot_cashout_status.get("high_roller_ready", false)) or bool(hot_cashout_run.narrative_flags.get("high_roller_cashout_pending", false)):
		failures.append("High-heat Grand Casino player should not receive the Players Card.")
	if not bool(hot_cashout_status.get("showdown_pending", false)):
		failures.append("High-heat Grand Casino money target should route to the Pit Boss Showdown.")
	if int(hot_cashout_status.get("grand_casino_max_heat", 0)) <= high_roller_max_heat:
		failures.append("Grand Casino max visit heat was not tracked for cashout eligibility.")

	var non_boss_cashout_environment := non_boss_environment.duplicate(true)
	non_boss_cashout_environment["event_ids"] = ["high_roller_cashout"]
	var non_boss_cashout_run: RunState = RunStateScript.new()
	non_boss_cashout_run.start_new("M2-FUN-BOSS-NON-BOSS-CASHOUT")
	non_boss_cashout_run.set_environment(non_boss_cashout_environment)
	non_boss_cashout_run.narrative_flags["high_roller_cashout_pending"] = true
	if high_roller_module.can_trigger(non_boss_cashout_run, non_boss_cashout_run.current_environment):
		failures.append("Players Card event should appear only in the Grand Casino.")

	run_state.current_environment["turns"] = 0
	run_state.add_suspicion("boss_heat_fixture", showdown_heat_threshold, "behavior")
	run_state.evaluate_environment_objective_state()
	var showdown_status := run_state.demo_objective_status()
	if run_state.run_status != RunState.RUN_STATUS_ACTIVE:
		failures.append("Boss objective should trigger the finale before ending the run.")
	if bool(run_state.narrative_flags.get("demo_victory", false)):
		failures.append("Heat lane set demo victory before The House Calls branch resolved.")
	if not bool(showdown_status.get("showdown_pending", false)) or not bool(run_state.narrative_flags.get("demo_finale_pending", false)):
		failures.append("Grand Casino heat lane did not mark The House Calls as pending.")
	if not bool(showdown_status.get("staff_attention_active", false)):
		failures.append("Grand Casino heat lane did not expose staff attention while pending.")
	if not JsonCoerceScript._string_array(run_state.current_environment.get("event_ids", [])).has(finale_event_id):
		failures.append("Boss objective did not inject The House Calls into the active event list.")
	var finale_module := EventModule.new()
	finale_module.setup(finale_event)
	if not finale_module.can_trigger(run_state, run_state.current_environment):
		failures.append("The House Calls did not become triggerable at the boss target.")
	var showdown_slot_id := "foundation_check_grand_casino_showdown_pending"
	save_error = save_service.save_run(run_state, showdown_slot_id)
	if save_error != OK:
		failures.append("Save service could not save Grand Casino showdown objective state: %s." % save_error)
		return
	var loaded_showdown = save_service.load_run(showdown_slot_id)
	if loaded_showdown == null:
		failures.append("Save service could not reload Grand Casino showdown objective state.")
		return
	var loaded_showdown_status: Dictionary = loaded_showdown.demo_objective_status()
	if loaded_showdown.run_status != RunState.RUN_STATUS_ACTIVE or not bool(loaded_showdown_status.get("showdown_pending", false)):
		failures.append("Grand Casino showdown objective state did not survive SaveService load.")
	if bool(loaded_showdown.narrative_flags.get("demo_victory", false)):
		failures.append("Grand Casino showdown pending state should not become victory after SaveService load.")

	var watched_heat_run: RunState = RunStateScript.new()
	watched_heat_run.start_new("M2-FUN-BOSS-WATCHED-HEAT")
	watched_heat_run.set_environment(environment.to_dict())
	watched_heat_run.current_environment["turns"] = 0
	var watched_pressure := watched_heat_run.security_action_pressure("cheat", 10, 100)
	if bool(watched_pressure.get("ended", true)):
		failures.append("Grand Casino security pressure should not return generic capture while Rourke can reroute.")
	var watched_heat_deltas := GameModule.empty_result_deltas()
	watched_heat_deltas["suspicion_delta"] = 100
	watched_heat_deltas["story_log"] = [{"type": "game_action", "game_id": "baccarat", "stake_cost": 10, "pit_boss_heat_bonus": 30}]
	watched_heat_deltas["messages"] = ["Watched heat fixture."]
	var watched_heat_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "baccarat",
		"game_id": "baccarat",
		"action_id": "watched_heat_fixture",
		"action_kind": "cheat",
		"stake": 10,
		"suspicion_delta": 100,
		"deltas": watched_heat_deltas,
		"environment_id": str(watched_heat_run.current_environment.get("id", "")),
		"message": "Watched heat fixture.",
	})
	GameModule.apply_result(watched_heat_run, watched_heat_result)
	var watched_heat_status := watched_heat_run.demo_objective_status()
	if watched_heat_run.run_status != RunState.RUN_STATUS_ACTIVE or not bool(watched_heat_status.get("showdown_pending", false)):
		failures.append("Watched Grand Casino heat should queue showdown without police capture.")
	if watched_heat_run.run_failure_reason == RunState.FAILURE_POLICE_CAPTURE:
		failures.append("Watched Grand Casino heat incorrectly recorded police capture.")
	var event_count_after_first := _count_string_occurrences(watched_heat_run.current_environment.get("event_ids", []), finale_event_id)
	watched_heat_run.add_suspicion("repeat_heat_fixture", 5, "behavior")
	var event_count_after_repeat := _count_string_occurrences(watched_heat_run.current_environment.get("event_ids", []), finale_event_id)
	if event_count_after_repeat != event_count_after_first:
		failures.append("Repeated Grand Casino heat duplicated the showdown event.")

	var forced_heat_run: RunState = RunStateScript.new()
	forced_heat_run.start_new("M2-FUN-BOSS-FORCED-HEAT")
	forced_heat_run.set_environment(environment.to_dict())
	var forced_initial_watch := forced_heat_run.pit_boss_watch_status(forced_heat_run.current_environment)
	forced_heat_run.current_environment["turns"] = int(forced_initial_watch.get("watched_turns", 2))
	forced_heat_run.current_environment["event_ids"] = []
	forced_heat_run.add_suspicion("forced_heat_fixture", forced_showdown_heat_threshold, "behavior")
	var forced_heat_status := forced_heat_run.demo_objective_status()
	if forced_heat_run.run_status != RunState.RUN_STATUS_ACTIVE or not bool(forced_heat_status.get("showdown_pending", false)):
		failures.append("Unwatched forced Grand Casino heat should establish attention and queue showdown.")
	if not bool(forced_heat_run.narrative_flags.get("grand_casino_attention_forced_heat", false)):
		failures.append("Forced Grand Casino heat did not record the forced attention flag.")
	var forced_story_found := false
	for entry_value in forced_heat_run.story_log:
		if typeof(entry_value) == TYPE_DICTIONARY and str((entry_value as Dictionary).get("type", "")) == "grand_casino_heat_reroute":
			forced_story_found = true
			break
	if not forced_story_found:
		failures.append("Forced Grand Casino heat did not log a clear reroute story entry.")

	var outside_heat_run: RunState = RunStateScript.new()
	outside_heat_run.start_new("M2-FUN-BOSS-OUTSIDE-HEAT")
	outside_heat_run.set_environment(non_boss_environment)
	outside_heat_run.add_suspicion("outside_heat_fixture", 100, "behavior")
	if outside_heat_run.run_status != RunState.RUN_STATUS_FAILED or outside_heat_run.run_failure_reason != RunState.FAILURE_POLICE_CAPTURE:
		failures.append("Outside Grand Casino heat 100 should still fail as police_capture.")

	var watched_run: RunState = RunStateScript.new()
	watched_run.start_new("M2-FUN-BOSS-WATCH")
	watched_run.set_environment(environment.to_dict())
	watched_run.current_environment["turns"] = 0
	var watched_status := watched_run.pit_boss_watch_status(watched_run.current_environment)
	if not bool(watched_status.get("active", false)) or not bool(watched_status.get("watched", false)):
		failures.append("Pit boss watch state should be active and watched at turn zero.")
	watched_run.current_environment["turns"] = int(watched_status.get("watched_turns", 2))
	var clear_status := watched_run.pit_boss_watch_status(watched_run.current_environment)
	if bool(clear_status.get("watched", true)):
		failures.append("Pit boss watch state should have an unwatched cycle window.")
	var game: GameModule = _load_surface_contract_game(library, "blackjack", failures)
	if game != null:
		watched_run.current_environment["turns"] = 0
		var watched_actions: Array = game.cheat_actions(watched_run, watched_run.current_environment)
		watched_run.current_environment["turns"] = int(watched_status.get("watched_turns", 2))
		var clear_actions: Array = game.cheat_actions(watched_run, watched_run.current_environment)
		if watched_actions.is_empty() or clear_actions.is_empty():
			failures.append("Boss watch fixture needs cheat actions to compare heat.")
		elif int((watched_actions[0] as Dictionary).get("suspicion_delta", 0)) <= int((clear_actions[0] as Dictionary).get("suspicion_delta", 0)):
			failures.append("Cheating while watched did not add extra pit-boss heat.")

	var finale_payload: Dictionary = {}
	var finale_payload_value: Variant = finale_event.get("payload", {})
	if typeof(finale_payload_value) == TYPE_DICTIONARY:
		finale_payload = (finale_payload_value as Dictionary).duplicate(true)
	var showdown_config: Dictionary = {}
	var showdown_tuning_value: Variant = finale_payload.get("showdown_tuning", {})
	if typeof(showdown_tuning_value) == TYPE_DICTIONARY:
		showdown_config = (showdown_tuning_value as Dictionary).duplicate(true)
	for showdown_key in ["walk", "pat_down", "interrogation", "duel_terms"]:
		showdown_config[showdown_key] = JsonCoerceScript._copy_dict(finale_payload.get(showdown_key, {}))
	showdown_config["success_message"] = str(finale_payload.get("success_message", ""))
	showdown_config["failure_message"] = str(finale_payload.get("failure_message", ""))

	var pat_down_config := JsonCoerceScript._copy_dict(showdown_config.get("pat_down", {}))
	var classifications := JsonCoerceScript._copy_array(pat_down_config.get("classifications", []))
	if classifications.size() != 2 or int(pat_down_config.get("blatant_min_items", 0)) != 3:
		failures.append("Showdown contraband tiers were not data-authored with the locked blatant threshold.")
	var classification_items := {}
	for classification_value in classifications:
		if typeof(classification_value) == TYPE_DICTIONARY:
			var classification: Dictionary = classification_value
			classification_items[str(classification.get("id", ""))] = JsonCoerceScript._string_array(classification.get("item_ids", []))
	if JSON.stringify(classification_items.get("contraband", [])) != JSON.stringify(["marked_cards", "foil_sleeve", "weighted_keyring"]) or JSON.stringify(classification_items.get("surveillance", [])) != JSON.stringify(["xray_glasses", "tab_detector", "tarot_card"]):
		failures.append("Showdown pat-down data drifted from the canonical item-modifier classification sets.")

	var active_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-ACTIVE", environment.to_dict(), finale_module)
	if active_run == null:
		failures.append("Back-room arrival did not start the phased Pit Boss Showdown.")
		return
	if str(active_run.narrative_flags.get("grand_casino_showdown_step", "")) != RunState.GRAND_CASINO_SHOWDOWN_STEP_WALK:
		failures.append("Back-room arrival did not enter the serialized walk phase.")
	var walk_choices := finale_module.choices(active_run, active_run.current_environment)
	if _showdown_choice_id(walk_choices, "keep_everything").is_empty() or not _showdown_choice_id(walk_choices, "hand_to_crew__").is_empty():
		failures.append("The walk did not expose Keep while correctly gating Crew handoff.")
	var crew_debt_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-CREW-DEBT", environment.to_dict(), finale_module, ["scratch_pad"])
	crew_debt_run.add_debt({"id": "crew_walk_marker", "lender_id": "the_crew", "balance": 30, "status": "active"})
	if _showdown_choice_id(finale_module.choices(crew_debt_run, crew_debt_run.current_environment), "hand_to_crew__scratch_pad").is_empty():
		failures.append("A real Crew lender marker did not prove interaction for the walk handoff.")
	var active_slot_id := "foundation_check_house_calls_walk"
	save_error = save_service.save_run(active_run, active_slot_id)
	if save_error != OK:
		failures.append("Save service could not save the walk phase: %s." % save_error)
		return
	var loaded_walk = save_service.load_run(active_slot_id)
	if loaded_walk == null or str(loaded_walk.narrative_flags.get("grand_casino_showdown_step", "")) != RunState.GRAND_CASINO_SHOWDOWN_STEP_WALK:
		failures.append("The walk phase did not survive SaveService load.")
		return

	var walk_result := finale_module.resolve(active_run, active_run.current_environment, "keep_everything")
	if not bool(walk_result.get("ok", false)) or str(active_run.narrative_flags.get("grand_casino_showdown_step", "")) != RunState.GRAND_CASINO_SHOWDOWN_STEP_PAT_DOWN:
		failures.append("Keeping every item did not advance to the pat-down boundary.")
	var clean_pat_down := JsonCoerceScript._copy_dict(active_run.narrative_flags.get("grand_casino_showdown_pat_down", {}))
	if str(clean_pat_down.get("tier", "")) != "clean" or not JsonCoerceScript._copy_array(clean_pat_down.get("confiscated_items", [])).is_empty():
		failures.append("A clean inventory did not produce the clean pat-down tier.")
	var pat_down_slot_id := "foundation_check_house_calls_pat_down"
	save_error = save_service.save_run(active_run, pat_down_slot_id)
	if save_error != OK:
		failures.append("Save service could not save the pat-down boundary: %s." % save_error)
		return
	var loaded_pat_down = save_service.load_run(pat_down_slot_id)
	if loaded_pat_down == null or str(loaded_pat_down.narrative_flags.get("grand_casino_showdown_step", "")) != RunState.GRAND_CASINO_SHOWDOWN_STEP_PAT_DOWN:
		failures.append("The pat-down boundary did not survive SaveService load.")
		return
	var pat_choices := finale_module.choices(loaded_pat_down, loaded_pat_down.current_environment)
	if _showdown_choice_id(pat_choices, "face_rourke").is_empty():
		failures.append("The visible pat-down phase did not expose its interrogation transition.")
	finale_module.resolve(loaded_pat_down, loaded_pat_down.current_environment, "face_rourke")
	if str(loaded_pat_down.narrative_flags.get("grand_casino_showdown_step", "")) != RunState.GRAND_CASINO_SHOWDOWN_STEP_INTERROGATION:
		failures.append("The pat-down did not advance to interrogation.")
	var clean_evidence := JsonCoerceScript._string_array(loaded_pat_down.narrative_flags.get("grand_casino_showdown_interrogation_evidence", []))
	if clean_evidence.size() != 3 or clean_evidence.has("watched_cheat") or clean_evidence.has("cheat_evidence") or clean_evidence.has("open_debt") or clean_evidence.has("drunk"):
		failures.append("Clean interrogation selected evidence that was not present in the scripted run.")
	var evidence_twin := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-ACTIVE", environment.to_dict(), finale_module)
	finale_module.resolve(evidence_twin, evidence_twin.current_environment, "keep_everything")
	finale_module.resolve(evidence_twin, evidence_twin.current_environment, "face_rourke")
	if JSON.stringify(evidence_twin.narrative_flags.get("grand_casino_showdown_interrogation_evidence", [])) != JSON.stringify(clean_evidence):
		failures.append("Interrogation evidence selection changed for an identical seeded run.")
	var interrogation_choices := finale_module.choices(loaded_pat_down, loaded_pat_down.current_environment)
	if interrogation_choices.size() != 3 or JSON.stringify(interrogation_choices).find("{strength}") != -1:
		failures.append("Interrogation did not expose three fact-strength responses with visible stakes.")
	finale_module.resolve(loaded_pat_down, loaded_pat_down.current_environment, "hold_steady")
	var interrogation_slot_id := "foundation_check_house_calls_interrogation"
	save_error = save_service.save_run(loaded_pat_down, interrogation_slot_id)
	if save_error != OK:
		failures.append("Save service could not save the interrogation boundary: %s." % save_error)
		return
	var loaded_interrogation = save_service.load_run(interrogation_slot_id)
	if loaded_interrogation == null or int(loaded_interrogation.narrative_flags.get("grand_casino_showdown_interrogation_beat", 0)) != 1 or JSON.stringify(loaded_interrogation.narrative_flags.get("grand_casino_showdown_interrogation_evidence", [])) != JSON.stringify(clean_evidence):
		failures.append("Interrogation beat/evidence state did not survive SaveService load.")
		return
	var win_result := _finish_showdown_interrogation(finale_module, loaded_interrogation, "hold_steady")
	var win_run: RunState = loaded_interrogation
	if not bool(win_result.get("ok", false)) or not bool(win_result.get("duel_ready", false)) or win_run.run_status != RunState.RUN_STATUS_ACTIVE or str(win_run.narrative_flags.get("grand_casino_showdown_step", "")) != RunState.GRAND_CASINO_SHOWDOWN_STEP_DUEL:
		failures.append("The interrogation did not hand off to the playable serialized Rourke duel.")
	var duel_state := win_run.grand_casino_duel_status()
	if str(duel_state.get("status", "")) != "active" or int(duel_state.get("hand_limit", 0)) <= 0 or int(duel_state.get("ante", 0)) <= 0:
		failures.append("Rourke duel terms did not initialize active stacks, hand limit, and ante.")
	var blocked_duel_cashout := win_run.cash_out_grand_casino_chips()
	if bool(blocked_duel_cashout.get("ok", false)):
		failures.append("The Cage allowed cashout while Rourke's duel was active.")
	var duel_generator := RunGenerator.new(library)
	if game == null or not duel_generator.enter_grand_casino_room(win_run, RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID):
		failures.append("The active duel did not unlock and enter the Grand Casino Back Room.")
	else:
		var duel_surface := game.surface_state(win_run, win_run.current_environment, {})
		if not bool(duel_surface.get("boss_duel_active", false)) or str(duel_surface.get("dealer_name", "")) != "Rourke" or bool(duel_surface.get("surface_stake_controls_required", true)):
			failures.append("Back Room blackjack did not expose Rourke's fixed-ante boss surface: active=%s step=%s room=%s local=%s duel=%s surface=%s dealer=%s stake_controls=%s." % [
				str(win_run.grand_casino_duel_active(win_run.current_environment)),
				str(win_run.narrative_flags.get("grand_casino_showdown_step", "")),
				str(win_run.current_environment.get("archetype_id", "")),
				JSON.stringify(win_run.current_environment.get("local_narrative_flags", {})),
				JSON.stringify(win_run.grand_casino_duel_status()),
				str(duel_surface.get("boss_duel_active", false)),
				str(duel_surface.get("dealer_name", "")),
				str(duel_surface.get("surface_stake_controls_required", true)),
			])
		var replay_run: RunState = RunStateScript.new()
		replay_run.from_dict(win_run.to_dict())
		var deterministic_ui := {"surface_time_msec": 5000, "drunk_scaled_surface_time_msec": 5000}
		var deal_command := game.surface_action_command("blackjack_deal", 0, false, deterministic_ui, win_run, win_run.current_environment)
		var replay_deal := game.surface_action_command("blackjack_deal", 0, false, deterministic_ui, replay_run, replay_run.current_environment)
		var dealt_ui := JsonCoerceScript._copy_dict(deal_command.get("ui_state", {}))
		var replay_ui := JsonCoerceScript._copy_dict(replay_deal.get("ui_state", {}))
		if not bool(deal_command.get("handled", false)) or JsonCoerceScript._copy_array(dealt_ui.get("player_hands", [])).is_empty() or JsonCoerceScript._copy_array(dealt_ui.get("dealer_cards", [])).size() != 2:
			failures.append("Rourke boss surface did not deal a playable deterministic blackjack hand.")
		if JSON.stringify(_save_load_canonical_value([dealt_ui.get("player_hands", []), dealt_ui.get("dealer_cards", []), win_run.grand_casino_duel_status().get("edge_schedule", [])])) != JSON.stringify(_save_load_canonical_value([replay_ui.get("player_hands", []), replay_ui.get("dealer_cards", []), replay_run.grand_casino_duel_status().get("edge_schedule", [])])):
			failures.append("Identical Rourke duel seeds/actions did not reproduce hands and edge schedule.")
		var hit_run: RunState = RunStateScript.new()
		hit_run.from_dict(win_run.to_dict())
		hit_run.bankroll = 0
		hit_run.grand_casino_chips = 0
		var hit_ui := JsonCoerceScript._copy_dict(dealt_ui)
		hit_ui["boss_duel_session"] = true
		hit_ui["selected_stake"] = int(duel_state.get("ante", 20))
		hit_ui["locked_stake"] = int(duel_state.get("ante", 20))
		hit_ui["active_hand_index"] = 0
		hit_ui["moves_made"] = false
		hit_ui["round_terminal"] = false
		hit_ui["settlement_pending"] = false
		hit_ui["settlement_count_revealed"] = false
		hit_ui["counting_enabled"] = false
		hit_ui["count_challenge"] = {}
		hit_ui["dealer_hole_visible"] = false
		hit_ui["dealer_cards"] = [{"rank": 9, "suit": 0, "deck": 0}, {"rank": 7, "suit": 1, "deck": 0}]
		hit_ui["player_hands"] = [{
			"cards": [{"rank": 10, "suit": 2, "deck": 0}, {"rank": 5, "suit": 3, "deck": 0}],
			"stood": false,
			"doubled": false,
			"split": false,
			"blackjack_eligible": true,
			"wager_multiplier": 1,
		}]
		hit_ui["shoe"] = [{"rank": 6, "suit": 0, "deck": 0}, {"rank": 2, "suit": 1, "deck": 0}]
		hit_ui["shoe_refilled_during_hand"] = true
		hit_run.persist_grand_casino_duel_session(hit_ui)
		var hit_hands_before := JsonCoerceScript._copy_array(hit_run.grand_casino_duel_status().get("hands", [])).size()
		var hit_command := game.surface_action_command("blackjack_hit", 0, false, hit_ui, hit_run, hit_run.current_environment)
		var hit_command_ui := JsonCoerceScript._copy_dict(hit_command.get("ui_state", {}))
		if not bool(hit_command.get("handled", false)) or bool(hit_command.get("resolve", false)) or not bool(hit_command_ui.get("settlement_pending", false)):
			failures.append("Rourke hit-to-21 did not stage settlement behind its card animation: %s." % JSON.stringify(hit_command))
		hit_command_ui["surface_presentation_time_msec"] = int(hit_command_ui.get("deal_started_msec", 0)) + 5000
		var hit_settle_command := game.surface_auto_action_command(hit_command_ui, hit_run, hit_run.current_environment)
		hit_command_ui = JsonCoerceScript._copy_dict(hit_settle_command.get("ui_state", hit_command_ui))
		if str(hit_settle_command.get("action_id", "")) != "play_basic" or not bool(hit_settle_command.get("resolve", hit_settle_command.get("direct_resolve", false))):
			failures.append("Rourke hit-to-21 did not become settleable after its card animation: %s." % JSON.stringify(hit_settle_command))
		elif game.wager_cost_for_context("play_basic", int(duel_state.get("ante", 20)), hit_run, hit_run.current_environment, hit_command_ui) != 0:
			failures.append("Rourke hit-to-21 settlement incorrectly requested another cash/chip ante.")
		else:
			var hit_before_compat := JSON.stringify(_save_load_canonical_run_snapshot(hit_run.to_dict()))
			var hit_compat := game.resolve_with_context("play_basic", int(duel_state.get("ante", 20)), hit_run, hit_run.current_environment, hit_run.create_rng("duel_hit_21_unused"), hit_command_ui)
			if not bool(hit_compat.get("blackjack_compatibility_simulation", false)) or JSON.stringify(_save_load_canonical_run_snapshot(hit_run.to_dict())) != hit_before_compat:
				failures.append("Detached Rourke hit compatibility resolve mutated live RunState.")
			var hit_result := _blackjack_authority_resolve_for_test(game, "play_basic", int(duel_state.get("ante", 20)), hit_run, hit_command_ui)
			var hit_hands_after := JsonCoerceScript._copy_array(hit_run.grand_casino_duel_status().get("hands", [])).size()
			if not bool(hit_result.get("ok", false)) or hit_hands_after != hit_hands_before + 1:
				failures.append("Rourke hit-to-21 SETTLE path did not advance exactly one duel hand: result=%s state=%s." % [JSON.stringify(hit_result), JSON.stringify(hit_run.grand_casino_duel_status())])
		var double_run: RunState = RunStateScript.new()
		double_run.from_dict(win_run.to_dict())
		var double_ui := JsonCoerceScript._copy_dict(dealt_ui)
		double_ui["boss_duel_session"] = true
		double_ui["selected_stake"] = int(duel_state.get("ante", 20))
		double_ui["locked_stake"] = int(duel_state.get("ante", 20))
		double_ui["active_hand_index"] = 0
		double_ui["moves_made"] = false
		double_ui["round_terminal"] = false
		double_ui["settlement_pending"] = false
		double_ui["dealer_hole_visible"] = false
		double_ui["dealer_cards"] = [{"rank": 9, "suit": 0, "deck": 0}, {"rank": 7, "suit": 1, "deck": 0}]
		double_ui["player_hands"] = [{
			"cards": [{"rank": 5, "suit": 2, "deck": 0}, {"rank": 6, "suit": 3, "deck": 0}],
			"stood": false,
			"doubled": false,
			"split": false,
			"blackjack_eligible": true,
			"wager_multiplier": 1,
		}]
		double_ui["shoe"] = [{"rank": 10, "suit": 0, "deck": 0}, {"rank": 2, "suit": 1, "deck": 0}, {"rank": 10, "suit": 2, "deck": 0}]
		double_ui["shoe_refilled_during_hand"] = true
		var double_hands_before := JsonCoerceScript._copy_array(double_run.grand_casino_duel_status().get("hands", [])).size()
		var double_command := game.surface_action_command("blackjack_double", 0, false, double_ui, double_run, double_run.current_environment)
		var double_command_ui := JsonCoerceScript._copy_dict(double_command.get("ui_state", {}))
		if not bool(double_command.get("handled", false)) or bool(double_command.get("resolve", double_command.get("direct_resolve", false))) or not bool(double_command_ui.get("settlement_pending", false)):
			failures.append("Rourke duel double did not stage settlement behind its card animation: %s." % JSON.stringify(double_command))
		double_command_ui["surface_presentation_time_msec"] = int(double_command_ui.get("deal_started_msec", 0)) + 5000
		var double_settle_command := game.surface_auto_action_command(double_command_ui, double_run, double_run.current_environment)
		double_command_ui = JsonCoerceScript._copy_dict(double_settle_command.get("ui_state", double_command_ui))
		if str(double_settle_command.get("action_id", "")) != "play_basic" or not bool(double_settle_command.get("resolve", double_settle_command.get("direct_resolve", false))):
			failures.append("Rourke duel double did not become settleable after its card animation: %s." % JSON.stringify(double_settle_command))
		else:
			var double_before_compat := JSON.stringify(_save_load_canonical_run_snapshot(double_run.to_dict()))
			var double_compat := game.resolve_with_context("play_basic", int(duel_state.get("ante", 20)), double_run, double_run.current_environment, double_run.create_rng("duel_double_unused"), double_command_ui)
			if not bool(double_compat.get("blackjack_compatibility_simulation", false)) or JSON.stringify(_save_load_canonical_run_snapshot(double_run.to_dict())) != double_before_compat:
				failures.append("Detached Rourke double compatibility resolve mutated live RunState.")
			var doubled_result := _blackjack_authority_resolve_for_test(game, "play_basic", int(duel_state.get("ante", 20)), double_run, double_command_ui)
			var doubled_status := double_run.grand_casino_duel_status()
			var doubled_hands := JsonCoerceScript._copy_array(doubled_status.get("hands", []))
			var result_hands := JsonCoerceScript._copy_array(doubled_result.get("blackjack_hand_results", []))
			var result_hand: Dictionary = result_hands[0] if not result_hands.is_empty() and typeof(result_hands[0]) == TYPE_DICTIONARY else {}
			if not bool(doubled_result.get("ok", false)) or not bool(doubled_result.get("blackjack_boss_duel", false)):
				failures.append("Rourke duel double did not settle through the boss duel result path: %s." % JSON.stringify(doubled_result))
			if double_run.run_status != RunState.RUN_STATUS_ACTIVE or double_run.is_terminal() or str(doubled_status.get("status", "")) != "active":
				failures.append("Rourke duel double prematurely ended the run/status=%s duel=%s result=%s." % [str(double_run.run_status), JSON.stringify(doubled_status), JSON.stringify(doubled_result)])
			if doubled_hands.size() != double_hands_before + 1 or not bool(result_hand.get("doubled", false)):
				failures.append("Rourke duel double did not advance exactly one doubled hand: before=%d after=%d result_hands=%s." % [double_hands_before, doubled_hands.size(), JSON.stringify(result_hands)])
		var mid_duel_slot_id := "foundation_check_rourke_mid_duel"
		save_error = save_service.save_run(win_run, mid_duel_slot_id)
		var loaded_mid_duel = save_service.load_run(mid_duel_slot_id)
		if save_error != OK or loaded_mid_duel == null or JSON.stringify(_save_load_canonical_value(loaded_mid_duel.narrative_flags.get("grand_casino_duel_state", {}))) != JSON.stringify(_save_load_canonical_value(win_run.narrative_flags.get("grand_casino_duel_state", {}))):
			failures.append("Rourke's exact dealt hand/session did not survive SaveService load.")
		var loaded_surface := game.surface_state(loaded_mid_duel, loaded_mid_duel.current_environment, {}) if loaded_mid_duel != null else {}
		if loaded_mid_duel != null and JsonCoerceScript._copy_array(loaded_surface.get("player_hands", [])).is_empty():
			failures.append("Rourke's saved mid-hand cards did not reopen on the boss surface.")
		var replay_before_compat := JSON.stringify(_save_load_canonical_run_snapshot(replay_run.to_dict()))
		var original_before_compat := JSON.stringify(_save_load_canonical_run_snapshot(win_run.to_dict()))
		game.resolve_with_context("play_basic", int(duel_state.get("ante", 20)), replay_run, replay_run.current_environment, replay_run.create_rng("duel_test_unused"), replay_ui)
		game.resolve_with_context("play_basic", int(duel_state.get("ante", 20)), win_run, win_run.current_environment, win_run.create_rng("duel_test_unused"), dealt_ui)
		if JSON.stringify(_save_load_canonical_run_snapshot(replay_run.to_dict())) != replay_before_compat or JSON.stringify(_save_load_canonical_run_snapshot(win_run.to_dict())) != original_before_compat:
			failures.append("Detached deterministic Rourke compatibility probes mutated live RunState.")
		var settled_replay := _blackjack_authority_resolve_for_test(game, "play_basic", int(duel_state.get("ante", 20)), replay_run, replay_ui)
		var settled_original := _blackjack_authority_resolve_for_test(game, "play_basic", int(duel_state.get("ante", 20)), win_run, dealt_ui)
		if JSON.stringify(_save_load_canonical_value([settled_original.get("blackjack_hand_results", []), win_run.grand_casino_duel_status()])) != JSON.stringify(_save_load_canonical_value([settled_replay.get("blackjack_hand_results", []), replay_run.grand_casino_duel_status()])):
			failures.append("Identical Rourke duel actions did not reproduce the settled hand and duel state.")

	var crew_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-CREW", environment.to_dict(), finale_module, ["cheap_sunglasses"], {"crew_marker_open": true})
	var crew_choice_id := _showdown_choice_id(finale_module.choices(crew_run, crew_run.current_environment), "hand_to_crew__cheap_sunglasses")
	if crew_choice_id.is_empty():
		failures.append("A provable Crew interaction did not unlock item handoff.")
	else:
		var crew_walk := finale_module.resolve(crew_run, crew_run.current_environment, crew_choice_id)
		if not bool(crew_walk.get("ok", false)) or crew_run.inventory.has("cheap_sunglasses") or str(crew_run.narrative_flags.get("grand_casino_showdown_crew_handoff_item_id", "")) != "cheap_sunglasses":
			failures.append("Crew handoff did not save and remove exactly one selected item.")
		var second_ditch := crew_run.resolve_grand_casino_showdown_walk("trash", "cheap_sunglasses", showdown_config)
		if bool(second_ditch.get("ok", false)):
			failures.append("RunState allowed a second ditch after the walk choice was committed.")
		finale_module.resolve(crew_run, crew_run.current_environment, "face_rourke")
		_finish_showdown_interrogation(finale_module, crew_run, "hold_steady")
		_force_rourke_duel_outcome(crew_run, "walk_out_clean")
		if crew_run.run_status != RunState.RUN_STATUS_ENDED or not crew_run.inventory.has("cheap_sunglasses") or str(crew_run.narrative_flags.get("grand_casino_showdown_crew_handoff_returned", "")) != "cheap_sunglasses":
			failures.append("Crew handoff did not return the saved item after survival.")
	var crew_failure_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-CREW-FAIL", environment.to_dict(), finale_module, ["scratch_pad"], {"crew_favor_completed": true})
	var crew_failure_choice := _showdown_choice_id(finale_module.choices(crew_failure_run, crew_failure_run.current_environment), "hand_to_crew__scratch_pad")
	finale_module.resolve(crew_failure_run, crew_failure_run.current_environment, crew_failure_choice)
	finale_module.resolve(crew_failure_run, crew_failure_run.current_environment, "face_rourke")
	_finish_showdown_interrogation(finale_module, crew_failure_run, "take_the_edge")
	_force_rourke_duel_outcome(crew_failure_run, "taken_out_back")
	if crew_failure_run.run_status != RunState.RUN_STATUS_FAILED or crew_failure_run.inventory.has("scratch_pad") or str(crew_failure_run.narrative_flags.get("grand_casino_showdown_crew_handoff_lost_on_failure", "")) != "scratch_pad":
		failures.append("Crew handoff failure did not retain the documented interim lost-item state.")

	var trash_a := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-TRASH", environment.to_dict(), finale_module, ["scratch_pad"])
	var trash_b := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-TRASH", environment.to_dict(), finale_module, ["scratch_pad"])
	var trash_choice_a := _showdown_choice_id(finale_module.choices(trash_a, trash_a.current_environment), "trash_item__scratch_pad")
	var trash_choice_b := _showdown_choice_id(finale_module.choices(trash_b, trash_b.current_environment), "trash_item__scratch_pad")
	finale_module.resolve(trash_a, trash_a.current_environment, trash_choice_a)
	finale_module.resolve(trash_b, trash_b.current_environment, trash_choice_b)
	if trash_a.inventory.has("scratch_pad") or JSON.stringify(trash_a.grand_casino_showdown_walk_status()) != JSON.stringify(trash_b.grand_casino_showdown_walk_status()):
		failures.append("Trash loss, flavor, or seen chance was not deterministic for the same seed.")

	var minor_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-MINOR", environment.to_dict(), finale_module, ["marked_cards"])
	finale_module.resolve(minor_run, minor_run.current_environment, "keep_everything")
	if str(JsonCoerceScript._copy_dict(minor_run.narrative_flags.get("grand_casino_showdown_pat_down", {})).get("tier", "")) != "minor" or minor_run.inventory.has("marked_cards"):
		failures.append("One contraband item did not produce confiscating minor pat-down.")
	var serious_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-SERIOUS", environment.to_dict(), finale_module, ["marked_cards", "foil_sleeve"])
	finale_module.resolve(serious_run, serious_run.current_environment, "keep_everything")
	var serious_pat_down := JsonCoerceScript._copy_dict(serious_run.narrative_flags.get("grand_casino_showdown_pat_down", {}))
	if str(serious_pat_down.get("tier", "")) != "serious" or int(serious_pat_down.get("handicap", 0)) <= 0 or serious_run.inventory.has("marked_cards") or serious_run.inventory.has("foil_sleeve"):
		failures.append("Multiple contraband did not produce confiscation plus a serious handicap.")
	var surveillance_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-SURVEILLANCE", environment.to_dict(), finale_module, ["xray_glasses"])
	finale_module.resolve(surveillance_run, surveillance_run.current_environment, "keep_everything")
	if str(JsonCoerceScript._copy_dict(surveillance_run.narrative_flags.get("grand_casino_showdown_pat_down", {})).get("tier", "")) != "serious":
		failures.append("Carried surveillance gear did not produce the serious pat-down tier.")
	var watched_surveillance_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-WATCHED-SURVEILLANCE", environment.to_dict(), finale_module, ["xray_glasses"], {"grand_casino_watched_cheat_evidence": true})
	finale_module.resolve(watched_surveillance_run, watched_surveillance_run.current_environment, "keep_everything")
	if watched_surveillance_run.is_terminal() or str(JsonCoerceScript._copy_dict(watched_surveillance_run.narrative_flags.get("grand_casino_showdown_pat_down", {})).get("tier", "")) != "serious":
		failures.append("Watched evidence incorrectly promoted surveillance-only gear above the serious tier.")
	var blatant_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-BLATANT", environment.to_dict(), finale_module, ["marked_cards", "foil_sleeve", "weighted_keyring"])
	var blatant_result := finale_module.resolve(blatant_run, blatant_run.current_environment, "keep_everything")
	if blatant_run.run_status != RunState.RUN_STATUS_FAILED or blatant_run.run_failure_reason != RunState.FAILURE_CASINO_TAKEN_OUT_BACK or str(blatant_result.get("message", "")).find("before the game") == -1 or not JsonCoerceScript._copy_dict(blatant_run.narrative_flags.get("grand_casino_duel_terms", {})).is_empty():
		failures.append("Blatant contraband did not fail immediately with its distinct pre-duel message.")
	var watched_blatant_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-WATCHED-BLATANT", environment.to_dict(), finale_module, ["marked_cards"], {"grand_casino_watched_cheat_evidence": true, "grand_casino_cheat_evidence": true})
	finale_module.resolve(watched_blatant_run, watched_blatant_run.current_environment, "keep_everything")
	if watched_blatant_run.run_status != RunState.RUN_STATUS_FAILED or str(JsonCoerceScript._copy_dict(watched_blatant_run.narrative_flags.get("grand_casino_showdown_pat_down", {})).get("tier", "")) != "blatant":
		failures.append("Watched evidence plus carried contraband did not trigger blatant failure.")

	serious_run.drunk_level = 75
	serious_run.alcoholic_level = 100
	serious_run.add_debt({"id": "showdown_debt_one", "lender_id": "street_lender", "balance": 40, "status": "active"})
	serious_run.narrative_flags["grand_casino_cheat_evidence"] = true
	finale_module.resolve(serious_run, serious_run.current_environment, "face_rourke")
	var dirty_evidence := JsonCoerceScript._string_array(serious_run.narrative_flags.get("grand_casino_showdown_interrogation_evidence", []))
	if dirty_evidence.size() != 3 or dirty_evidence.has("clean_record"):
		failures.append("Dirty interrogation selected evidence inconsistent with the scripted run.")
	var failure_result := _finish_showdown_interrogation(finale_module, serious_run, "take_the_edge")
	var failure_run: RunState = serious_run
	var clean_terms := JsonCoerceScript._copy_dict(win_run.narrative_flags.get("grand_casino_duel_terms", {}))
	var dirty_terms := JsonCoerceScript._copy_dict(failure_run.narrative_flags.get("grand_casino_duel_terms", {}))
	if clean_terms.is_empty() or dirty_terms.is_empty() or not clean_terms.has("starting_stacks") or not dirty_terms.has("handicaps") or not dirty_terms.has("margin_thresholds"):
		failures.append("Interrogation did not serialize the complete duel_terms schema.")
	elif int(JsonCoerceScript._copy_dict(dirty_terms.get("handicaps", {})).get("player", 0)) <= 0 or int(dirty_terms.get("rourke_aggression", 0)) < int(clean_terms.get("rourke_aggression", 0)):
		failures.append("Dirty/serious facts did not harden the serialized duel terms.")
	var clean_interrogation_terms := JsonCoerceScript._copy_dict(clean_terms.get("interrogation", {}))
	var clean_answers := JsonCoerceScript._copy_array(clean_interrogation_terms.get("answers", []))
	var clean_strength_total := 0
	for answer_value in clean_answers:
		if typeof(answer_value) == TYPE_DICTIONARY:
			clean_strength_total += int((answer_value as Dictionary).get("strength", 0))
	var expected_response_modifier := int(round(float(clean_strength_total) / float(maxi(1, clean_answers.size()))))
	if clean_answers.size() != 3 or int(clean_interrogation_terms.get("response_modifier", -999)) != expected_response_modifier:
		failures.append("Serialized duel terms did not consume the three recorded fact-derived response strengths.")
	if not bool(failure_result.get("ok", false)) or not bool(failure_result.get("duel_ready", false)) or failure_run.run_status != RunState.RUN_STATUS_ACTIVE:
		failures.append("Dirty interrogation did not enter the playable duel boundary.")
	var clean_rules := JsonCoerceScript._copy_dict(clean_terms.get("rules", {}))
	var dirty_rules := JsonCoerceScript._copy_dict(dirty_terms.get("rules", {}))
	var clean_detection := int(clean_rules.get("player_cheat_detection_base", 0)) + int(clean_terms.get("rourke_aggression", 0)) * int(clean_rules.get("player_cheat_detection_per_aggression", 0)) + int(clean_terms.get("rourke_cheat_level", 0)) * int(clean_rules.get("player_cheat_detection_per_cheat_level", 0))
	var dirty_detection := int(dirty_rules.get("player_cheat_detection_base", 0)) + int(dirty_terms.get("rourke_aggression", 0)) * int(dirty_rules.get("player_cheat_detection_per_aggression", 0)) + int(dirty_terms.get("rourke_cheat_level", 0)) * int(dirty_rules.get("player_cheat_detection_per_cheat_level", 0))
	if int(JsonCoerceScript._copy_dict(dirty_terms.get("starting_stacks", {})).get("player", 0)) >= int(JsonCoerceScript._copy_dict(clean_terms.get("starting_stacks", {})).get("player", 0)) or dirty_detection < clean_detection:
		failures.append("Pat-down/interrogation terms did not visibly worsen the player's stack and Rourke detection sensitivity.")

	var edge_rng_a := RngStream.new()
	edge_rng_a.configure(7717)
	var edge_rng_b := RngStream.new()
	edge_rng_b.configure(7717)
	var replay_a := GrandCasinoDuelModelScript.initialize(dirty_terms, edge_rng_a)
	var replay_b := GrandCasinoDuelModelScript.initialize(dirty_terms, edge_rng_b)
	if JSON.stringify(replay_a.get("edge_schedule", [])) != JSON.stringify(replay_b.get("edge_schedule", [])):
		failures.append("Rourke's named seeded edge schedule drifted across identical replays.")
	var schedule := JsonCoerceScript._copy_array(replay_a.get("edge_schedule", []))
	if not schedule.is_empty():
		var authored_edge := JsonCoerceScript._copy_dict(schedule[0])
		authored_edge.merge({"id": "deck_stack", "active": true, "called": false, "stripped": false}, true)
		schedule[0] = authored_edge
		replay_a["edge_schedule"] = schedule
		var correct_call := GrandCasinoDuelModelScript.call_out(replay_a, "deck_stack", dirty_terms)
		var false_call := GrandCasinoDuelModelScript.call_out(replay_a, "hole_swap", dirty_terms)
		if not bool(correct_call.get("correct", false)) or not bool(JsonCoerceScript._copy_dict(correct_call.get("edge", {})).get("stripped", false)) or int(correct_call.get("swing", 0)) <= 0:
			failures.append("A correct Rourke call-out did not strip the authored edge and swing momentum.")
		if bool(false_call.get("correct", true)) or int(false_call.get("swing", 0)) >= 0:
			failures.append("A false Rourke accusation did not cost the authored duel chips.")

	_force_rourke_duel_outcome(win_run, "walk_out_clean")
	if win_run.run_status != RunState.RUN_STATUS_ENDED or str(win_run.narrative_flags.get("demo_victory_route", "")) != RunState.GRAND_CASINO_SHOWDOWN_ROUTE or str(win_run.narrative_flags.get("grand_casino_duel_outcome", "")) != "walk_out_clean":
		failures.append("Decisive Rourke victory did not cash out into the canonical showdown route.")
	var shown_run := _new_showdown_phase_run("M2-FUN-HOUSE-CALLS-SHOWN", environment.to_dict(), finale_module, ["scratch_pad"], {"crew_favor_completed": true})
	var shown_handoff := _showdown_choice_id(finale_module.choices(shown_run, shown_run.current_environment), "hand_to_crew__scratch_pad")
	finale_module.resolve(shown_run, shown_run.current_environment, shown_handoff)
	finale_module.resolve(shown_run, shown_run.current_environment, "face_rourke")
	_finish_showdown_interrogation(finale_module, shown_run, "hold_steady")
	shown_run.grand_casino_chips = 37
	_force_rourke_duel_outcome(shown_run, "shown_the_door")
	var shown_score := shown_run.terminal_score_summary()
	if shown_run.run_status != RunState.RUN_STATUS_ENDED or not bool(shown_run.narrative_flags.get("grand_casino_walked_with_chips", false)) or int(shown_run.narrative_flags.get("grand_casino_uncashed_chip_amount", 0)) != 37 or shown_run.grand_casino_chips != 37:
		failures.append("Shown-the-door ending did not end successfully with the exact uncashed chip amount.")
	if int(shown_score.get("uncashed_chip_score_value", 0)) != 18 or bool(shown_run.cash_out_grand_casino_chips().get("ok", false)):
		failures.append("Shown-the-door ending did not apply reduced chip score and permanent Cage lockout.")
	if not shown_run.inventory.has("scratch_pad") or str(shown_run.narrative_flags.get("grand_casino_showdown_crew_handoff_returned", "")) != "scratch_pad":
		failures.append("Crew handoff item did not return for the shown-the-door success ending.")
	_force_rourke_duel_outcome(failure_run, "taken_out_back")
	if failure_run.run_status != RunState.RUN_STATUS_FAILED or failure_run.run_failure_reason != RunState.FAILURE_CASINO_TAKEN_OUT_BACK or str(failure_run.narrative_flags.get("grand_casino_duel_outcome", "")) != "taken_out_back":
		failures.append("Losing Rourke's duel did not preserve casino_taken_out_back.")

	var failure_slot_id := "foundation_check_house_calls_failure"
	save_error = save_service.save_run(failure_run, failure_slot_id)
	if save_error != OK:
		failures.append("Save service could not save the phased House Calls failure: %s." % save_error)
		return
	var loaded_failure = save_service.load_run(failure_slot_id)
	var loaded_failure_terms: Dictionary = {}
	if loaded_failure != null:
		loaded_failure_terms = _save_load_canonical_value(loaded_failure.narrative_flags.get("grand_casino_duel_terms", {})) as Dictionary
	if loaded_failure == null or loaded_failure.run_failure_reason != RunState.FAILURE_CASINO_TAKEN_OUT_BACK or JSON.stringify(loaded_failure_terms) != JSON.stringify(_save_load_canonical_value(dirty_terms)):
		failures.append("Terminal phased showdown state/duel terms did not survive SaveService load.")

	print("HOUSE_CALLS_PHASES walk=%s pat_down=%s evidence=%s clean_terms=%s dirty_terms=%s failure=%s" % [
		str(RunState.GRAND_CASINO_SHOWDOWN_STEP_WALK),
		str(clean_pat_down.get("tier", "")),
		",".join(clean_evidence),
		str(not clean_terms.is_empty()),
		str(not dirty_terms.is_empty()),
		str(failure_run.run_failure_reason),
	])


func _force_rourke_duel_outcome(run_state: RunState, outcome: String) -> void:
	var state := run_state.grand_casino_duel_status()
	if str(state.get("status", "")) != "active":
		return
	match outcome:
		"walk_out_clean":
			state["player_stack"] = 100
			state["rourke_stack"] = 1
		"shown_the_door":
			state["player_stack"] = 100
			state["rourke_stack"] = 100
			state["hand_index"] = maxi(0, int(state.get("hand_limit", 5)) - 1)
		_:
			state["player_stack"] = 1
			state["rourke_stack"] = 100
	run_state.narrative_flags["grand_casino_duel_state"] = state
	var transfer := 1 if outcome == "walk_out_clean" else -1 if outcome == "taken_out_back" else 0
	run_state.apply_grand_casino_duel_hand({"transfer": transfer, "message": "Scripted ladder fixture."})


func _new_showdown_phase_run(seed: String, environment: Dictionary, finale_module: EventModule, item_ids: Array = [], flags: Dictionary = {}) -> RunState:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new(seed)
	run_state.set_environment(environment.duplicate(true))
	run_state.current_environment["turns"] = 0
	for item_value in item_ids:
		run_state.add_item(str(item_value))
	for flag_id in flags.keys():
		run_state.narrative_flags[str(flag_id)] = flags[flag_id]
	var objective := JsonCoerceScript._copy_dict(run_state.current_environment.get("demo_objective", {}))
	run_state.add_suspicion("boss_heat_fixture", int(objective.get("showdown_heat_threshold", 70)), "behavior")
	run_state.evaluate_environment_objective_state()
	var arrival := finale_module.resolve(run_state, run_state.current_environment, "enter_back_room")
	if not bool(arrival.get("ok", false)) or not bool(run_state.narrative_flags.get("grand_casino_showdown_active", false)):
		return null
	return run_state


func _showdown_choice_id(choices: Array, prefix: String) -> String:
	for choice_value in choices:
		if typeof(choice_value) != TYPE_DICTIONARY:
			continue
		var choice_id := str((choice_value as Dictionary).get("id", ""))
		if choice_id == prefix or choice_id.begins_with(prefix):
			return choice_id
	return ""


func _finish_showdown_interrogation(finale_module: EventModule, run_state: RunState, choice_id: String) -> Dictionary:
	var result: Dictionary = {}
	while str(run_state.narrative_flags.get("grand_casino_showdown_step", "")) == RunState.GRAND_CASINO_SHOWDOWN_STEP_INTERROGATION and not run_state.is_terminal():
		result = finale_module.resolve(run_state, run_state.current_environment, choice_id)
		if not bool(result.get("ok", false)):
			break
	return result


func _check_grand_casino_players_card_tiers(library: ContentLibrary, main_archetype: Dictionary, failures: Array) -> void:
	var objective: Dictionary = main_archetype.get("demo_objective", {}) if typeof(main_archetype.get("demo_objective", {})) == TYPE_DICTIONARY else {}
	var bronze_games := int(objective.get("players_card_bronze_min_games", 0))
	var bronze_net := int(objective.get("players_card_bronze_net_winnings", 0))
	var silver_games := int(objective.get("players_card_silver_min_games", 0))
	var silver_net := int(objective.get("players_card_silver_net_winnings", 0))
	var gold_games := int(objective.get("players_card_gold_min_games", 0))
	var gold_net := int(objective.get("players_card_gold_net_winnings", 0))
	if bronze_games <= 0 or bronze_net <= 0 or silver_games <= bronze_games or silver_net <= bronze_net or gold_games <= silver_games or gold_net <= silver_net:
		failures.append("Players Card Bronze, Silver, and Gold thresholds must rise in data-authored order.")
		return
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("GC-PLAYERS-CARD-TIERS")
	var environment := EnvironmentInstance.from_archetype(main_archetype, 3, run_state.create_rng("gc_card_tiers_environment"), library)
	run_state.set_environment(environment.to_dict())
	var generator: RunGenerator = RunGeneratorScript.new(library)
	_qualify_active_players_card_segment(run_state, bronze_games, bronze_net)
	var bronze_status := run_state.demo_objective_status()
	if str(bronze_status.get("players_card_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_NONE or not bool(bronze_status.get("players_card_ready_to_claim", false)) or str(bronze_status.get("players_card_next_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_BRONZE:
		failures.append("Unranked play did not freeze at Bronze readiness without auto-awarding it.")
	var frozen_games := int(bronze_status.get("players_card_segment_games", -1))
	var frozen_net := int(bronze_status.get("players_card_segment_net_winnings", -1))
	_record_players_card_clean_games(run_state, int(run_state.narrative_flags.get("grand_casino_games_played", 0)) + silver_games + gold_games)
	run_state.bankroll += silver_net + gold_net
	run_state.evaluate_environment_objective_state()
	var frozen_status := run_state.demo_objective_status()
	if int(frozen_status.get("players_card_segment_games", -2)) != frozen_games or int(frozen_status.get("players_card_segment_net_winnings", -2)) != frozen_net or str(frozen_status.get("players_card_next_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_BRONZE:
		failures.append("Extra play after Bronze readiness leaked into Silver progress.")
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
		failures.append("Players Card fixture could not enter the Cage for Bronze claim.")
		return
	var marker_draw := run_state.borrow_from_grand_casino_atm(50)
	var debt_blocked_claim := run_state.claim_grand_casino_players_card_tier()
	var debt_blocked_status := run_state.demo_objective_status()
	if not bool(marker_draw.get("ok", false)) or bool(debt_blocked_claim.get("ok", true)) or not bool(debt_blocked_status.get("players_card_ready_to_claim", false)) or str(debt_blocked_status.get("players_card_claim_block_reason", "")).find("$50") == -1:
		failures.append("Grand Casino ATM debt did not temporarily block Bronze while preserving readiness and exact balance copy.")
	var marker_payoff := run_state.repay_grand_casino_atm_debt(-1)
	if not bool(marker_payoff.get("ok", false)) or not bool(run_state.demo_objective_status().get("players_card_can_claim", false)):
		failures.append("Clearing the Grand Casino ATM marker did not immediately re-enable the pending Bronze claim.")
	var bronze_claim := run_state.claim_grand_casino_players_card_tier()
	if not bool(bronze_claim.get("ok", false)) or str(bronze_claim.get("tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_BRONZE:
		failures.append("Linda did not issue Bronze at the Cage.")
	if run_state.grand_casino_chips != int(objective.get("players_card_bronze_chip_bonus", 0)) or int(run_state.narrative_flags.get("grand_casino_comp_drink_tokens", 0)) != int(objective.get("players_card_bronze_drink_comps", 0)):
		failures.append("Bronze claim did not grant its data-tuned chip and drink comps exactly once.")
	if str(run_state.next_pending_talk_event().get("dialogue_id", "")) != "linda_bronze_tier":
		failures.append("Bronze claim did not enqueue Linda's talk-dock scene.")
	if int(run_state.demo_objective_status().get("players_card_segment_games", -1)) != 0 or int(run_state.demo_objective_status().get("players_card_segment_net_winnings", -1)) != 0:
		failures.append("Bronze claim did not start Silver from a fresh zero segment.")
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_ARCHETYPE_ID):
		failures.append("Players Card fixture could not return to the Main Floor for Silver progress.")
		return
	_qualify_active_players_card_segment(run_state, silver_games, silver_net)
	var silver_status := run_state.demo_objective_status()
	if str(silver_status.get("players_card_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_BRONZE or not bool(silver_status.get("players_card_ready_to_claim", false)):
		failures.append("Bronze play did not freeze at Silver readiness without auto-awarding it.")
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
		failures.append("Players Card fixture could not enter the Cage for Silver claim.")
		return
	var silver_claim := run_state.claim_grand_casino_players_card_tier()
	if not bool(silver_claim.get("ok", false)) or str(silver_claim.get("tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_SILVER:
		failures.append("Linda did not issue Silver at the Cage.")
	silver_status = run_state.demo_objective_status()
	var silver_access := run_state.grand_casino_room_access_status(RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID, 60)
	if not bool(silver_access.get("available", false)) or str(silver_access.get("access_method", "")) != "silver_card" or int(silver_access.get("cost", -1)) != 0:
		failures.append("Silver Players Card did not open the High-Limit Room without a cash buy-in.")
	if not bool(run_state.narrative_flags.get("grand_casino_linda_look_away_available", false)) or int(run_state.narrative_flags.get("grand_casino_comp_suite_rests", 0)) != int(objective.get("players_card_silver_suite_rests", 0)):
		failures.append("Silver did not grant Linda's look-away and suite-rest benefits.")
	var expected_net_before_comps := int(silver_status.get("grand_casino_net_winnings", -1))
	if expected_net_before_comps < bronze_net + silver_net:
		failures.append("Tier claims corrupted retained total Grand Casino net winnings.")
	var silver_payload := run_state.to_dict()
	var loaded_silver: RunState = RunStateScript.new()
	loaded_silver.from_dict(silver_payload)
	if str(loaded_silver.demo_objective_status().get("players_card_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_SILVER or not bool(loaded_silver.narrative_flags.get("grand_casino_high_limit_access", false)):
		failures.append("Silver tier and benefits did not survive save/load.")
	var legacy_payload := silver_payload.duplicate(true)
	var legacy_flags: Dictionary = legacy_payload.get("narrative_flags", {}).duplicate(true)
	for key in ["grand_casino_players_card_awarded_tier", "grand_casino_players_card_segment_start_games", "grand_casino_players_card_segment_start_net_winnings", "grand_casino_players_card_segment_games", "grand_casino_players_card_segment_net_winnings", "grand_casino_players_card_segment_max_heat", "grand_casino_players_card_ready_to_claim", "grand_casino_players_card_ready_tier"]:
		legacy_flags.erase(key)
	legacy_payload["narrative_flags"] = legacy_flags
	var legacy_run: RunState = RunStateScript.new()
	legacy_run.from_dict(legacy_payload)
	var legacy_status := legacy_run.demo_objective_status()
	if str(legacy_status.get("players_card_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_SILVER or bool(legacy_status.get("players_card_ready_to_claim", true)) or int(legacy_status.get("players_card_segment_games", -1)) != 0:
		failures.append("Legacy Grand Casino save did not retain Silver with a conservative fresh Gold segment.")
	var look_away_max := int(objective.get("players_card_look_away_max_heat_gain", 0))
	var too_large := run_state.add_suspicion("linda_large_heat", look_away_max + 1, "behavior", false, {"action_kind": "risky"})
	if too_large != look_away_max + 1 or not bool(run_state.narrative_flags.get("grand_casino_linda_look_away_available", false)):
		failures.append("Linda consumed the look-away on heat above its data threshold.")
	run_state.add_suspicion("linda_large_heat_reset", -(look_away_max + 1), "recovery")
	var cheat_heat := run_state.add_suspicion("linda_cheat_heat", look_away_max, "behavior", false, {"action_kind": "cheat"})
	if cheat_heat != look_away_max or not bool(run_state.narrative_flags.get("grand_casino_linda_look_away_available", false)):
		failures.append("Linda consumed the clean-path look-away on a cheat action.")
	run_state.add_suspicion("linda_cheat_heat_reset", -look_away_max, "recovery")
	var forgiven := run_state.add_suspicion("linda_small_heat", look_away_max, "behavior", false, {"action_kind": "risky"})
	var second_gain := run_state.add_suspicion("linda_second_heat", look_away_max, "behavior", false, {"action_kind": "risky"})
	if forgiven != 0 or second_gain != look_away_max or not bool(run_state.narrative_flags.get("grand_casino_linda_look_away_consumed", false)):
		failures.append("Linda's Silver look-away did not forgive exactly one eligible small heat gain.")
	var look_away_story := false
	for story_value in run_state.story_log:
		if typeof(story_value) == TYPE_DICTIONARY and str((story_value as Dictionary).get("type", "")) == "grand_casino_linda_look_away":
			look_away_story = true
			break
	if not look_away_story:
		failures.append("Linda's consumed look-away did not log its story line.")
	var drink_before := int(run_state.narrative_flags.get("grand_casino_comp_drink_tokens", 0))
	var drink_result := run_state.grand_casino_players_card_comp_result("drink")
	GameModule.apply_result(run_state, drink_result)
	if not bool(drink_result.get("ok", false)) or int(run_state.narrative_flags.get("grand_casino_comp_drink_tokens", 0)) != drink_before - 1:
		failures.append("Players Card drink comp did not resolve through shared service deltas.")
	run_state.change_drunk(50)
	var heat_before_rest := run_state.suspicion_level()
	var drunk_before_rest := run_state.drunk_level
	var rest_result := run_state.grand_casino_players_card_comp_result("suite_rest")
	GameModule.apply_result(run_state, rest_result)
	run_state.advance_game_clock_minutes(int(rest_result.get("duration_minutes", 0)))
	if not bool(rest_result.get("ok", false)) or run_state.suspicion_level() >= heat_before_rest or run_state.drunk_level >= drunk_before_rest or int(rest_result.get("duration_minutes", 0)) != int(objective.get("players_card_suite_rest_minutes", 0)):
		failures.append("Players Card suite rest did not reuse service deltas for time, heat, and drunk recovery.")
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_ARCHETYPE_ID):
		failures.append("Players Card fixture could not return to the Main Floor for Gold progress.")
		return
	_qualify_active_players_card_segment(run_state, gold_games, gold_net)
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
		failures.append("Players Card fixture could not enter the Cage for Gold review.")
		return
	var gold_status := run_state.demo_objective_status()
	if str(gold_status.get("players_card_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_SILVER or str(gold_status.get("players_card_next_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_GOLD or not bool(gold_status.get("high_roller_ready", false)):
		failures.append("Scripted clean play did not cross Gold into deliberate Cage review readiness.")
	var gold_result := run_state.apply_demo_finale_result({
		"event_id": RunState.GRAND_CASINO_HIGH_ROLLER_EVENT_ID,
		"branch": "win_clean",
		"message": "Linda issues the Gold Players Card and lets you leave with your winnings.",
	})
	if not bool(gold_result.get("complete", false)) or run_state.run_status != RunState.RUN_STATUS_ENDED or str(run_state.narrative_flags.get("demo_victory_route", "")) != RunState.GRAND_CASINO_HIGH_ROLLER_EVENT_ID or not bool(run_state.narrative_flags.get("act_two_seam_ready", false)):
		failures.append("Linda's Gold review did not complete the canonical clean victory end-to-end.")
	var seam_story_count := 0
	for story_value in run_state.story_log:
		if typeof(story_value) != TYPE_DICTIONARY:
			continue
		var story_entry := story_value as Dictionary
		if str(story_entry.get("type", "")) == "act_two_seam_ready":
			seam_story_count += 1
			if str(story_entry.get("message", "")) != RunState.GRAND_CASINO_ACT_TWO_SEAM_MESSAGE or str(story_entry.get("tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_GOLD:
				failures.append("Gold victory logged an incorrect Act 2 seam story marker.")
	var seam_report := RunReportViewModelScript.build(run_state.to_dict(), {"outcomes": RunReportViewModelScript.load_outcome_registry()})
	var seam_outcome := JsonCoerceScript._copy_dict(seam_report.get("outcome", {}))
	if seam_story_count != 1 or str(seam_outcome.get("seam_line", "")) != RunState.GRAND_CASINO_ACT_TWO_SEAM_MESSAGE or str(seam_outcome.get("how", "")).count(RunState.GRAND_CASINO_ACT_TWO_SEAM_MESSAGE) != 1:
		failures.append("Gold victory did not log and present exactly one truthful Act 2 seam line.")
	var evidence_run: RunState = RunStateScript.new()
	evidence_run.start_new("GC-PLAYERS-CARD-EVIDENCE")
	evidence_run.set_environment(environment.to_dict())
	evidence_run.narrative_flags["grand_casino_cheat_evidence"] = true
	evidence_run.evaluate_environment_objective_state()
	var evidence_status := evidence_run.demo_objective_status()
	var evidence_cage := CageCounterViewModelScript.build(evidence_run)
	var evidence_card: Dictionary = evidence_cage.get("card", {}) if typeof(evidence_cage.get("card", {})) == TYPE_DICTIONARY else {}
	if bool(evidence_status.get("players_card_eligible", true)) or str(evidence_card.get("review_state", "")) != "ineligible" or str(evidence_card.get("review_detail", "")).find("permanently") == -1:
		failures.append("Cheat evidence did not permanently lock every Players Card tier at Linda's Cage counter.")
	var evidence_access := evidence_run.grand_casino_room_access_status(RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID, 60)
	if not bool(evidence_access.get("cash_buy_in_required", false)) or str(evidence_access.get("access_method", "")) != "cash_buy_in":
		failures.append("Cheat evidence did not revoke Silver access while preserving the independent cash buy-in path.")
	for dialogue_id in ["linda_bronze_tier", "linda_silver_tier", "linda_gold_review", "linda_main_floor_ambient_1", "linda_main_floor_ambient_2", "linda_main_floor_ambient_3"]:
		var dialogue := library.dialogue(dialogue_id)
		var speaker: Dictionary = dialogue.get("speaker", {}) if typeof(dialogue.get("speaker", {})) == TYPE_DICTIONARY else {}
		if dialogue.is_empty() or str(speaker.get("name", "")) != "Linda":
			failures.append("Linda dialogue scene is missing or misattributed: %s." % dialogue_id)
	print("GRAND_CASINO_CARD_TIERS bronze=%d/%d silver=%d/%d gold=%d/%d look_away=%d dialogues=6" % [bronze_games, bronze_net, silver_games, silver_net, gold_games, gold_net, look_away_max])


func _record_players_card_clean_games(run_state: RunState, target_games: int) -> void:
	var current_games := maxi(0, int(run_state.narrative_flags.get("grand_casino_games_played", 0)))
	for game_index in range(current_games, maxi(current_games, target_games)):
		var deltas := GameModule.empty_result_deltas()
		deltas["story_log"] = [{"type": "game_action", "game_id": "blackjack", "stake_cost": 5 + game_index}]
		var result := GameModule.build_action_result({
			"ok": true,
			"type": "game_action",
			"source_id": "blackjack",
			"game_id": "blackjack",
			"action_id": "play_basic",
			"action_kind": "legal",
			"stake": 5 + game_index,
			"deltas": deltas,
			"environment_id": str(run_state.current_environment.get("id", "")),
			"environment_archetype_id": str(run_state.current_environment.get("archetype_id", "")),
			"message": "Clean Players Card progress.",
		})
		run_state.record_grand_casino_game_result(result)


func _qualify_active_players_card_segment(run_state: RunState, game_count: int, net_winnings: int) -> void:
	var start_games := maxi(0, int(run_state.narrative_flags.get("grand_casino_games_played", 0)))
	_record_players_card_clean_games(run_state, start_games + maxi(0, game_count))
	var entry_bankroll := int(run_state.narrative_flags.get("grand_casino_entry_bankroll", run_state.grand_casino_total_money()))
	var segment_start_net := int(run_state.narrative_flags.get("grand_casino_players_card_segment_start_net_winnings", 0))
	var target_total_money := entry_bankroll + segment_start_net + net_winnings
	run_state.bankroll = maxi(0, target_total_money - run_state.grand_casino_chips)
	run_state.evaluate_environment_objective_state()


func _prepare_players_card_gold_ready(run_state: RunState, library: ContentLibrary, failures: Array) -> bool:
	var generator: RunGenerator = RunGeneratorScript.new(library)
	for expected_tier in [RunState.GRAND_CASINO_PLAYERS_CARD_TIER_BRONZE, RunState.GRAND_CASINO_PLAYERS_CARD_TIER_SILVER]:
		var status := run_state.demo_objective_status()
		var required_games := int(status.get("players_card_next_min_games", 0))
		var required_net := int(status.get("players_card_next_net_winnings", 0))
		_qualify_active_players_card_segment(run_state, required_games, required_net)
		status = run_state.demo_objective_status()
		if not bool(status.get("players_card_ready_to_claim", false)) or str(status.get("players_card_next_tier", "")) != expected_tier:
			failures.append("Sequential Players Card fixture did not prepare %s." % expected_tier)
			return false
		if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
			failures.append("Sequential Players Card fixture could not enter the Cage for %s." % expected_tier)
			return false
		var claim := run_state.claim_grand_casino_players_card_tier()
		if not bool(claim.get("ok", false)) or str(claim.get("tier", "")) != expected_tier:
			failures.append("Linda did not award sequential %s: %s" % [expected_tier, str(claim.get("message", ""))])
			return false
		if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_ARCHETYPE_ID):
			failures.append("Sequential Players Card fixture could not return to the Main Floor after %s." % expected_tier)
			return false
	var gold_status := run_state.demo_objective_status()
	_qualify_active_players_card_segment(
		run_state,
		int(gold_status.get("players_card_next_min_games", 0)),
		int(gold_status.get("players_card_next_net_winnings", 0))
	)
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
		failures.append("Sequential Players Card fixture could not enter the Cage for Gold.")
		return false
	return bool(run_state.demo_objective_status().get("high_roller_ready", false))


func _check_grand_casino_chips_and_cage(library: ContentLibrary, main_archetype: Dictionary, failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("GC-CHIPS-CAGE")
	var environment := EnvironmentInstance.from_archetype(main_archetype, 3, run_state.create_rng("gc_chips_environment"), library)
	run_state.set_environment(environment.to_dict())
	run_state.bankroll = 100
	var score_before := run_state.run_spending_score
	var buy_result := run_state.buy_grand_casino_chips(40, run_state.grand_casino_chip_exchange_rate())
	if not bool(buy_result.get("ok", false)) or run_state.bankroll != 60 or run_state.grand_casino_chips != 40 or run_state.grand_casino_total_money() != 100:
		failures.append("Grand Casino 1:1 table buy-in did not conserve cash plus chips.")
	if run_state.wager_balance_for_game("blackjack", run_state.current_environment) != 100 or run_state.wager_capacity_for_game("blackjack", run_state.current_environment) != 100:
		failures.append("Grand Casino table wager balance did not include cash available for seamless chip fallback.")
	if run_state.grand_casino_game_uses_chips("slot", run_state.current_environment) \
		or run_state.wager_balance_for_game("slot", run_state.current_environment) != 60 \
		or run_state.wager_capacity_for_game("slot", run_state.current_environment) != 60:
		failures.append("Grand Casino slot wager capacity did not remain cash-only when casino chips were present.")
	if run_state.run_spending_score != score_before:
		failures.append("Grand Casino chip buy-in incorrectly counted a currency transfer as score spending.")
	var fallback_run: RunState = RunStateScript.new()
	fallback_run.start_new("GC-CASH-FALLBACK")
	fallback_run.set_environment(environment.to_dict())
	fallback_run.bankroll = 50
	fallback_run.grand_casino_chips = 5
	var fallback_total_before := fallback_run.grand_casino_total_money()
	var fallback_funding := fallback_run.fund_grand_casino_table_wager("roulette", 20, fallback_run.current_environment)
	if not bool(fallback_funding.get("ok", false)) \
		or int(fallback_funding.get("existing_chips_used", -1)) != 5 \
		or int(fallback_funding.get("chips_bought", -1)) != 15 \
		or int(fallback_funding.get("cash_used", -1)) != 15 \
		or fallback_run.bankroll != 35 \
		or fallback_run.grand_casino_chips != 20 \
		or fallback_run.grand_casino_total_money() != fallback_total_before:
		failures.append("Grand Casino wager funding did not spend existing chips first and cover only the shortage with cash.")
	var winning_deltas := GameModule.empty_result_deltas()
	winning_deltas["bankroll_delta"] = 20
	var winning_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "roulette",
		"game_id": "roulette",
		"action_id": "cash_fallback_win_fixture",
		"action_kind": "legal",
		"stake": 20,
		"deltas": winning_deltas,
		"environment_id": str(fallback_run.current_environment.get("id", "")),
		"message": "Cash fallback win fixture.",
	})
	GameModule.apply_result(fallback_run, winning_result)
	if fallback_run.bankroll != 35 or fallback_run.grand_casino_chips != 40 or fallback_run.grand_casino_total_money() != fallback_total_before + 20:
		failures.append("A cash-funded Grand Casino winning wager did not return the stake and winnings as redeemable chips.")
	var direct_run: RunState = RunStateScript.new()
	direct_run.start_new("GC-CASH-FALLBACK-DIRECT")
	direct_run.set_environment(environment.to_dict())
	direct_run.bankroll = 50
	direct_run.grand_casino_chips = 0
	var direct_deltas := GameModule.empty_result_deltas()
	direct_deltas["bankroll_delta"] = 10
	var direct_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "roulette",
		"game_id": "roulette",
		"action_id": "direct_cash_fallback_fixture",
		"action_kind": "legal",
		"stake": 10,
		"deltas": direct_deltas,
		"environment_id": str(direct_run.current_environment.get("id", "")),
		"message": "Direct cash fallback fixture.",
	})
	GameModule.apply_result(direct_run, direct_result)
	if direct_run.bankroll != 40 or direct_run.grand_casino_chips != 20 or int(direct_result.get("wager_cash_used", 0)) != 10:
		failures.append("Direct Grand Casino settlement did not fund a zero-chip cash wager before returning its gross payout as chips.")
	var machine_funding_run: RunState = RunStateScript.new()
	machine_funding_run.start_new("GC-MACHINE-CASH-FALLBACK")
	machine_funding_run.set_environment(environment.to_dict())
	machine_funding_run.bankroll = 20
	machine_funding_run.grand_casino_chips = 30
	var machine_funding := machine_funding_run.fund_grand_casino_table_wager("slot", 10, machine_funding_run.current_environment)
	if not bool(machine_funding.get("ok", false)) \
		or int(machine_funding.get("cash_used", -1)) != 0 \
		or int(machine_funding.get("chips_bought", -1)) != 0 \
		or machine_funding_run.bankroll != 20 \
		or machine_funding_run.grand_casino_chips != 30:
		failures.append("Grand Casino slot wager preparation incorrectly bought or reserved casino chips.")
	var insufficient_run: RunState = RunStateScript.new()
	insufficient_run.start_new("GC-CASH-FALLBACK-INSUFFICIENT")
	insufficient_run.set_environment(environment.to_dict())
	insufficient_run.bankroll = 4
	insufficient_run.grand_casino_chips = 3
	var insufficient_before := insufficient_run.grand_casino_total_money()
	var insufficient_funding := insufficient_run.fund_grand_casino_table_wager("baccarat", 8, insufficient_run.current_environment)
	if bool(insufficient_funding.get("ok", true)) or insufficient_run.grand_casino_total_money() != insufficient_before:
		failures.append("Grand Casino cash fallback accepted an unaffordable wager or mutated funds on rejection.")

	for table_id in RunState.GRAND_CASINO_TABLE_GAME_IDS:
		# Blackjack settlements are sealed by their dedicated authority contract;
		# this generic currency fixture intentionally exercises unsealed table games.
		if table_id == "blackjack":
			continue
		var table_deltas := GameModule.empty_result_deltas()
		table_deltas["bankroll_delta"] = -2
		var table_result := GameModule.build_action_result({
			"ok": true,
			"type": "game_action",
			"source_id": table_id,
			"game_id": table_id,
			"action_id": "chips_fixture",
			"action_kind": "legal",
			"stake": 2,
			"deltas": table_deltas,
			"environment_id": str(run_state.current_environment.get("id", "")),
			"message": "Casino table chips fixture.",
		})
		var cash_before := run_state.bankroll
		var chips_before := run_state.grand_casino_chips
		GameModule.apply_result(run_state, table_result)
		if run_state.bankroll != cash_before or run_state.grand_casino_chips != chips_before - 2 or int(table_result.get("chips_delta", 0)) != -2 or str(table_result.get("currency", "")) != "chips":
			failures.append("Grand Casino table result did not route %s from bankroll_delta to chips." % table_id)

	var machine_deltas := GameModule.empty_result_deltas()
	machine_deltas["bankroll_delta"] = 7
	var machine_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "slot",
		"game_id": "slot",
		"action_id": "spin",
		"action_kind": "legal",
		"stake": 1,
		"deltas": machine_deltas,
		"environment_id": str(run_state.current_environment.get("id", "")),
		"message": "Casino machine cash payout fixture.",
	})
	var machine_cash_before := run_state.bankroll
	var machine_chips_before := run_state.grand_casino_chips
	GameModule.apply_result(run_state, machine_result)
	if run_state.bankroll != machine_cash_before + 7 or run_state.grand_casino_chips != machine_chips_before or machine_result.has("chips_delta") or str(machine_result.get("currency", "")) == "chips":
		failures.append("Grand Casino slot payout did not settle directly into the player's cash bankroll.")
	var machine_loss_deltas := GameModule.empty_result_deltas()
	machine_loss_deltas["bankroll_delta"] = -3
	var machine_loss_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "slot",
		"game_id": "slot",
		"action_id": "spin",
		"action_kind": "legal",
		"stake": 3,
		"deltas": machine_loss_deltas,
		"environment_id": str(run_state.current_environment.get("id", "")),
		"message": "Casino machine cash wager fixture.",
	})
	machine_cash_before = run_state.bankroll
	machine_chips_before = run_state.grand_casino_chips
	GameModule.apply_result(run_state, machine_loss_result)
	if run_state.bankroll != machine_cash_before - 3 or run_state.grand_casino_chips != machine_chips_before or machine_loss_result.has("chips_delta"):
		failures.append("Grand Casino slot wager did not debit the player's cash bankroll.")

	var outside_environment := run_state.current_environment.duplicate(true)
	outside_environment["id"] = "outside_table_currency_fixture"
	outside_environment["archetype_id"] = "gas_station_casino"
	outside_environment["world_node_id"] = "gas_station_casino"
	run_state.set_environment(outside_environment)
	var outside_deltas := GameModule.empty_result_deltas()
	outside_deltas["bankroll_delta"] = -3
	var outside_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "baccarat",
		"game_id": "baccarat",
		"action_id": "outside_cash_fixture",
		"action_kind": "legal",
		"stake": 3,
		"deltas": outside_deltas,
		"environment_id": "outside_table_currency_fixture",
		"message": "Outside table cash fixture.",
	})
	var outside_cash_before := run_state.bankroll
	var outside_chips_before := run_state.grand_casino_chips
	GameModule.apply_result(run_state, outside_result)
	if run_state.bankroll != outside_cash_before - 3 or run_state.grand_casino_chips != outside_chips_before or outside_result.has("chips_delta"):
		failures.append("Table play outside the Grand Casino did not remain cash-only.")
	var outside_machine_deltas := GameModule.empty_result_deltas()
	outside_machine_deltas["bankroll_delta"] = 4
	var outside_machine_result := GameModule.build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": "slot",
		"game_id": "slot",
		"action_id": "outside_machine_cash_fixture",
		"action_kind": "legal",
		"stake": 2,
		"deltas": outside_machine_deltas,
		"environment_id": "outside_table_currency_fixture",
		"message": "Outside machine cash fixture.",
	})
	outside_cash_before = run_state.bankroll
	outside_chips_before = run_state.grand_casino_chips
	GameModule.apply_result(run_state, outside_machine_result)
	if run_state.bankroll != outside_cash_before + 4 or run_state.grand_casino_chips != outside_chips_before or outside_machine_result.has("chips_delta"):
		failures.append("Slot play outside the Grand Casino did not remain cash-only.")

	run_state.set_environment(environment.to_dict())
	var cashout_generator: RunGenerator = RunGeneratorScript.new(library)
	if not cashout_generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
		failures.append("Grand Casino chip fixture could not enter the Cage for redemption.")
		return
	var saved := run_state.to_dict()
	var restored: RunState = RunStateScript.new()
	restored.from_dict(saved)
	if restored.grand_casino_chips != run_state.grand_casino_chips or str(restored.current_environment.get("archetype_id", "")) != RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID:
		failures.append("Grand Casino chip balance or Cage availability did not survive save/load.")
	var total_before_cash_out := restored.grand_casino_total_money()
	var score_before_cash_out := restored.run_spending_score
	var cash_out_result := restored.cash_out_grand_casino_chips(-1, restored.grand_casino_chip_exchange_rate())
	if not bool(cash_out_result.get("ok", false)) or restored.grand_casino_chips != 0 or restored.grand_casino_total_money() != total_before_cash_out:
		failures.append("Grand Casino cash-out did not conserve total money.")
	if restored.run_spending_score != score_before_cash_out:
		failures.append("Grand Casino chip cash-out incorrectly changed score spending.")


func _check_grand_casino_living_floor(library: ContentLibrary, main_archetype: Dictionary, failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("GC-LIVING-FLOOR")
	var environment := EnvironmentInstance.from_archetype(main_archetype, 3, run_state.create_rng("gc_living_environment"), library)
	run_state.set_environment(environment.to_dict())
	if run_state.rourke_current_room != RunState.GRAND_CASINO_ARCHETYPE_ID or run_state.rourke_current_spot.is_empty():
		failures.append("Rourke did not initialize as a one-room living Grand Casino agent.")
	if run_state.rival_cheaters.size() < RunState.RIVAL_CHEATER_MIN_COUNT or run_state.rival_cheaters.size() > RunState.RIVAL_CHEATER_MAX_COUNT:
		failures.append("Grand Casino rival cast was outside the seeded 1-3 range.")

	run_state.rival_cheater_day = run_state.game_day()
	run_state.rival_cheaters = []
	run_state.rourke_current_room = RunState.GRAND_CASINO_ARCHETYPE_ID
	run_state.rourke_current_spot = "main_center"
	run_state.rourke_actions_until_move = 1
	run_state.grand_casino_room_heat_accumulators = {
		RunState.GRAND_CASINO_ARCHETYPE_ID: 0,
		RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID: 30,
		RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID: 0,
	}
	run_state.advance_environment_turns(1)
	if run_state.rourke_current_room != RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID:
		failures.append("Scripted High-Limit heat did not pull Rourke one room toward the hotspot.")
	run_state.rourke_actions_until_move = 1
	run_state.grand_casino_room_heat_accumulators = {
		RunState.GRAND_CASINO_ARCHETYPE_ID: 11,
		RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID: 10,
		RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID: 0,
	}
	run_state.advance_environment_turns(1)
	if run_state.rourke_current_room != RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID:
		failures.append("Rourke movement inertia did not hold on near-equal room heat.")
	var restored: RunState = RunStateScript.new()
	restored.from_dict(run_state.to_dict())
	if restored.rourke_current_room != run_state.rourke_current_room or restored.rourke_current_spot != run_state.rourke_current_spot or restored.rourke_actions_until_move != run_state.rourke_actions_until_move or JSON.stringify(restored.grand_casino_room_heat_accumulators) != JSON.stringify(run_state.grand_casino_room_heat_accumulators):
		failures.append("Rourke room, spot, movement timer, or room heat did not survive save/load.")

	var away_run: RunState = RunStateScript.new()
	away_run.start_new("GC-SPATIAL-WATCH")
	away_run.set_environment(environment.to_dict())
	away_run.rourke_current_room = RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID
	away_run.record_grand_casino_game_result({"ok": true, "game_id": "slot", "action_kind": "cheat", "stake": 1})
	if bool(away_run.narrative_flags.get("grand_casino_watched_cheat_evidence", false)) or bool(away_run.pit_boss_watch_status().get("active", true)):
		failures.append("A cheat while Rourke was in another room incorrectly recorded watched evidence.")
	away_run.narrative_flags.erase("grand_casino_cheat_evidence")
	away_run.narrative_flags.erase("grand_casino_watched_cheat_evidence")
	away_run.narrative_flags.erase("grand_casino_attention_watched_cheat")
	away_run.rourke_current_room = RunState.GRAND_CASINO_ARCHETYPE_ID
	away_run.current_environment["turns"] = 0
	away_run.record_grand_casino_game_result({"ok": true, "game_id": "slot", "action_kind": "cheat", "stake": 1})
	if not bool(away_run.narrative_flags.get("grand_casino_watched_cheat_evidence", false)) or not bool(away_run.pit_boss_watch_status().get("active", false)):
		failures.append("A cheat with Rourke present did not record spatial watched evidence.")

	var escort_run: RunState = RunStateScript.new()
	escort_run.start_new("GC-RIVAL-ESCORT")
	escort_run.set_environment(environment.to_dict())
	escort_run.rival_cheater_day = escort_run.game_day()
	escort_run.rival_cheaters = [{"id": "escort_fixture", "display_name": "Vega", "room": RunState.GRAND_CASINO_ARCHETYPE_ID, "spot": 0, "tell": "heel_tap", "idle_phase": 0}]
	escort_run.rourke_current_room = RunState.GRAND_CASINO_ARCHETYPE_ID
	escort_run.grand_casino_room_heat_accumulators[RunState.GRAND_CASINO_ARCHETYPE_ID] = 100
	var player_heat_before := escort_run.suspicion_level()
	var room_heat_before := int(escort_run.grand_casino_room_heat_accumulators.get(RunState.GRAND_CASINO_ARCHETYPE_ID, 0))
	escort_run.advance_environment_turns(1)
	if escort_run.suspicion_level() != player_heat_before or int(escort_run.grand_casino_room_heat_accumulators.get(RunState.GRAND_CASINO_ARCHETYPE_ID, 0)) <= int(floor(float(room_heat_before * RunState.ROURKE_HEAT_DECAY_PERCENT) / 100.0)):
		failures.append("Rival heat did not raise room pull independently of player suspicion.")
	for _escort_action in range(100):
		if escort_run.rourke_off_floor_actions > 0:
			break
		escort_run.advance_environment_turns(1)
	if escort_run.rourke_off_floor_actions != RunState.ROURKE_OFF_FLOOR_ACTIONS or not escort_run.rival_cheaters.is_empty() or escort_run.rourke_escort_state.is_empty():
		failures.append("Seeded rival escort did not remove the cheater and bench Rourke for the full window.")
	elif bool(escort_run.pit_boss_watch_status().get("active", true)):
		failures.append("Rourke remained an active watcher during the escort window.")
	var escort_story_found := false
	for story_value in escort_run.story_log:
		if typeof(story_value) == TYPE_DICTIONARY and str((story_value as Dictionary).get("type", "")) == "rourke_rival_escort":
			escort_story_found = true
			break
	if not escort_story_found:
		failures.append("Rival escort did not log its visible Main Floor story moment.")

	var cameo := library.event("rourke_scouting_cameo")
	var kitty := _archetype_by_id(library, "kitty_cat_lounge")
	var delta := _archetype_by_id(library, "delta_queen")
	if cameo.is_empty() or str(cameo.get("presentation", "")) != "talk" or not JsonCoerceScript._string_array(kitty.get("event_pool", [])).has("rourke_scouting_cameo") or not JsonCoerceScript._string_array(delta.get("event_pool", [])).has("rourke_scouting_cameo"):
		failures.append("Rare Rourke scouting talk was not authored into both tier-2 casino pools.")
	else:
		var cameo_run: RunState = RunStateScript.new()
		cameo_run.start_new("GC-ROURKE-CAMEO")
		var cameo_environment := EnvironmentInstance.from_archetype(delta, 2, cameo_run.create_rng("gc_cameo_environment"), library).to_dict()
		cameo_environment["event_ids"] = ["rourke_scouting_cameo"]
		cameo_environment["resolved_event_ids"] = []
		cameo_run.set_environment(cameo_environment)
		if not cameo_run.enqueue_triggered_event("rourke_scouting_cameo", "demo_boss_objective_foundation", {}):
			failures.append("Rare Rourke scouting talk could not enter the triggered-event queue.")
			return
		var cameo_module: EventModule = EventModule.new()
		cameo_module.setup(cameo, library)
		var cameo_result := cameo_module.resolve(cameo_run, cameo_run.current_environment, "read_his_route")
		if not bool(cameo_result.get("ok", false)) or not bool(cameo_run.narrative_flags.get("grand_casino_event_pit_boss_sweep_lay_low", false)):
			failures.append("Rourke scouting choice did not feed an existing prior-boss modifier flag.")


func _check_grand_casino_staff_rotation(library: ContentLibrary, main_archetype: Dictionary, failures: Array) -> void:
	var main_environment := EnvironmentInstance.from_archetype(main_archetype, 3, RunStateScript.new().create_rng("gc_staff_main"), library).to_dict()
	var outside_environment := {"id": "gc_staff_outside", "archetype_id": "motel", "world_node_id": "motel", "display_name": "Motel"}
	var run_a: RunState = RunStateScript.new()
	var run_b: RunState = RunStateScript.new()
	run_a.start_new("GC-STAFF-TIMELINE")
	run_b.start_new("GC-STAFF-TIMELINE")
	run_a.set_environment(main_environment.duplicate(true))
	run_b.set_environment(main_environment.duplicate(true))
	var first_staffing := run_a.grand_casino_staffing_snapshot()
	var first_assignments: Dictionary = first_staffing.get("assignments", {}) if typeof(first_staffing.get("assignments", {})) == TYPE_DICTIONARY else {}
	var constants: Dictionary = first_staffing.get("constants", {}) if typeof(first_staffing.get("constants", {})) == TYPE_DICTIONARY else {}
	if first_assignments.size() != 4:
		failures.append("Grand Casino day-one staffing did not assign all three dealers and the bartender.")
	if str(JsonCoerceScript._copy_dict(constants.get("rourke", {})).get("id", "")) != "rourke" or str(JsonCoerceScript._copy_dict(constants.get("linda", {})).get("id", "")) != "linda":
		failures.append("Grand Casino staffing treated Rourke or Linda as a rotating role.")
	for assignment_value in first_assignments.values():
		if typeof(assignment_value) == TYPE_DICTIONARY and ["rourke", "linda"].has(str((assignment_value as Dictionary).get("id", ""))):
			failures.append("Grand Casino rotating roster included Rourke or Linda.")

	for day_step in range(1, 6):
		var action_rng := run_b.create_rng()
		for _draw in range(day_step + 2):
			action_rng.randi_range(1, 1000)
		run_b.save_rng(action_rng)
		run_b.set_environment(outside_environment.duplicate(true))
		run_b.set_environment(main_environment.duplicate(true))
		run_a.advance_game_clock_minutes(1440)
		run_b.advance_game_clock_minutes(1440)
		var staffing_a := run_a.grand_casino_staffing_snapshot()
		var staffing_b := run_b.grand_casino_staffing_snapshot()
		if JSON.stringify(staffing_a.get("assignments", {})) != JSON.stringify(staffing_b.get("assignments", {})) or JSON.stringify(staffing_a.get("rotated_roles", [])) != JSON.stringify(staffing_b.get("rotated_roles", [])):
			failures.append("Grand Casino staffing timeline changed with visit order or action RNG state on day %d." % run_a.game_day())
			break
		if JSON.stringify(run_a.rival_cheaters) != JSON.stringify(run_b.rival_cheaters) or run_a.rival_cheater_day != run_b.rival_cheater_day:
			failures.append("Grand Casino rival cast was not aligned to the same seeded day timeline.")
			break

	var saved_staffing := run_a.grand_casino_staffing.duplicate(true)
	var restored: RunState = RunStateScript.new()
	restored.from_dict(run_a.to_dict())
	if JSON.stringify(restored.grand_casino_staffing) != JSON.stringify(saved_staffing):
		failures.append("Grand Casino staffing assignment did not survive a mid-day save/load exactly.")

	var saw_rotation := false
	var saw_no_change := false
	for seed_index in range(24):
		var sample: RunState = RunStateScript.new()
		sample.start_new("GC-STAFF-SAMPLE-%02d" % seed_index)
		sample.set_environment(main_environment.duplicate(true))
		for _sample_day in range(6):
			sample.advance_game_clock_minutes(1440)
			var staffing := sample.grand_casino_staffing_snapshot()
			if bool(staffing.get("rotation_occurred", false)):
				saw_rotation = true
			else:
				saw_no_change = true
		if saw_rotation and saw_no_change:
			break
	if not saw_rotation or not saw_no_change:
		failures.append("Grand Casino 50% independent rotation tunable did not produce both changed and no-change days in the deterministic sample.")

	_check_grand_casino_staff_game_state_reset(library, main_environment, failures)
	_check_grand_casino_memory_entry_lines(main_environment, outside_environment, failures)


func _check_grand_casino_staff_game_state_reset(library: ContentLibrary, main_environment: Dictionary, failures: Array) -> void:
	var high_archetype := _archetype_by_id(library, RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID)
	if high_archetype.is_empty():
		failures.append("Grand Casino staff rotation could not find the High-Limit Room.")
		return
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("GC-STAFF-RESET")
	run_state.set_environment(main_environment.duplicate(true))
	var bar_game: GameModule = StaffBarDiceGameScript.new()
	bar_game.setup(library.game("bar_dice"), library)
	var bar_surface := bar_game.surface_state(run_state, run_state.current_environment, {})
	var bartender := run_state.grand_casino_staff_member_for_game("bar_dice")
	if str(bar_surface.get("dealer_name", "")) != str(bartender.get("name", "")):
		failures.append("Grand Casino bar surface did not display the assigned bartender identity.")

	var high_environment := EnvironmentInstance.from_archetype(high_archetype, 3, run_state.create_rng("gc_staff_high"), library).to_dict()
	run_state.set_environment(high_environment)
	var table_games := {
		"blackjack": StaffBlackjackGameScript.new(),
		"baccarat": StaffBaccaratGameScript.new(),
		"roulette": StaffRouletteGameScript.new(),
	}
	for game_id_value in table_games.keys():
		var game_id := str(game_id_value)
		var game := table_games[game_id] as GameModule
		game.setup(library.game(game_id), library)
		var surface := game.surface_state(run_state, run_state.current_environment, {})
		var assignment := run_state.grand_casino_staff_member_for_game(game_id)
		var profile: Dictionary = surface.get("dealer_profile", {}) if typeof(surface.get("dealer_profile", {})) == TYPE_DICTIONARY else {}
		if str(surface.get("dealer_name", "")) != str(assignment.get("name", "")) or str(profile.get("identity_id", "")) != str(assignment.get("id", "")):
			failures.append("Grand Casino %s surface did not display its assigned dealer identity." % game_id)

	var blackjack := table_games.get("blackjack") as GameModule
	# Establish the original dealer through the production write boundary before
	# seeding familiarity. Passive surface projection is intentionally
	# observational and must not make a later dealer look like a rotation.
	run_state.bankroll = maxi(run_state.bankroll, 100)
	var staff_before_compat := JSON.stringify(_save_load_canonical_run_snapshot(run_state.to_dict()))
	var staff_compat := blackjack.resolve_with_context("blackjack_place_bet", 1, run_state, run_state.current_environment, run_state.create_rng("gc_staff_initial_assignment_action"), {"selected_stake": 1})
	if not bool(staff_compat.get("blackjack_compatibility_simulation", false)) or JSON.stringify(_save_load_canonical_run_snapshot(run_state.to_dict())) != staff_before_compat:
		failures.append("Detached blackjack staff-assignment compatibility resolve mutated live RunState.")
	var staff_result := _blackjack_authority_resolve_for_test(blackjack, "blackjack_place_bet", 1, run_state, {"selected_stake": 1})
	if not bool(staff_result.get("blackjack_host_committed", false)):
		failures.append("Blackjack host did not commit the initial dealer assignment exactly once.")
	var blackjack_states: Dictionary = run_state.current_environment.get("game_states", {}) if typeof(run_state.current_environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var blackjack_table: Dictionary = blackjack_states.get("blackjack", {}) if typeof(blackjack_states.get("blackjack", {})) == TYPE_DICTIONARY else {}
	var first_blackjack_id := str(blackjack_table.get("staff_assignment_id", ""))
	if first_blackjack_id.is_empty():
		failures.append("Grand Casino staff reset fixture did not persist the initial blackjack dealer at an action boundary.")
		return
	blackjack_table["strategy_deviation_strikes"] = 7
	blackjack_table["strategy_watch_pressure"] = 31
	blackjack_table["strategy_last_notice"] = "Dealer questioned the line."
	blackjack_table["hands_played"] = 9
	blackjack_table["running_count"] = 4
	blackjack_table["barred"] = true
	blackjack_table["barred_reason"] = "Casino memory persists."
	run_state.add_suspicion("gc_staff_reset_heat", 28, "behavior", true, {"environment_id": str(run_state.current_environment.get("id", ""))})
	run_state.narrative_flags["grand_casino_games_played"] = 4
	run_state.narrative_flags["grand_casino_cheat_evidence"] = true
	run_state.narrative_flags["grand_casino_players_card_ineligible"] = true
	run_state.narrative_flags["grand_casino_players_card_tier"] = RunState.GRAND_CASINO_PLAYERS_CARD_TIER_NONE
	run_state.narrative_flags["grand_casino_players_card_highest_tier"] = RunState.GRAND_CASINO_PLAYERS_CARD_TIER_SILVER
	run_state.narrative_flags["grand_casino_comp_drink_tokens"] = 2
	var rotated := false
	var rotated_surface: Dictionary = {}
	for _day_index in range(20):
		run_state.advance_game_clock_minutes(1440)
		if str(run_state.grand_casino_staff_member_for_game("blackjack").get("id", "")) == first_blackjack_id:
			continue
		var before_surface_json := JSON.stringify(_save_load_canonical_run_snapshot(run_state.to_dict()))
		rotated_surface = blackjack.surface_state(run_state, run_state.current_environment, {})
		var after_surface_json := JSON.stringify(_save_load_canonical_run_snapshot(run_state.to_dict()))
		if after_surface_json != before_surface_json:
			failures.append("Fresh blackjack dealer preview mutated serialized RunState before play.")
		rotated = true
		break
	if not rotated:
		failures.append("Grand Casino staff reset fixture did not reach a seeded blackjack dealer rotation.")
		return
	var rotated_assignment := run_state.grand_casino_staff_member_for_game("blackjack")
	var rotated_profile: Dictionary = rotated_surface.get("dealer_profile", {}) if typeof(rotated_surface.get("dealer_profile", {})) == TYPE_DICTIONARY else {}
	if str(rotated_surface.get("dealer_name", "")) != str(rotated_assignment.get("name", "")) or str(rotated_profile.get("identity_id", "")) != str(rotated_assignment.get("id", "")) or int(rotated_surface.get("strategy_watch_pressure", -1)) != 0:
		failures.append("Fresh blackjack dealer preview did not project the rotated identity with cleared strategy pressure.")
	# The fresh identity is projected immediately. The durable ban rejects the
	# wager atomically, so only its retryable delivery may persist; dealer-local
	# familiarity remains nonauthoritative projection until an accepted boundary.
	run_state.bankroll = maxi(run_state.bankroll, 100)
	var reset_before_compat := JSON.stringify(_save_load_canonical_run_snapshot(run_state.to_dict()))
	blackjack.resolve_with_context("blackjack_place_bet", 1, run_state, run_state.current_environment, run_state.create_rng("gc_staff_reset_action"), {"selected_stake": 1})
	if JSON.stringify(_save_load_canonical_run_snapshot(run_state.to_dict())) != reset_before_compat:
		failures.append("Detached blackjack dealer-reset compatibility resolve mutated live RunState.")
	var reset_result := _blackjack_authority_resolve_for_test(blackjack, "blackjack_place_bet", 1, run_state, {"selected_stake": 1})
	blackjack_states = run_state.current_environment.get("game_states", {}) if typeof(run_state.current_environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	blackjack_table = blackjack_states.get("blackjack", {}) if typeof(blackjack_states.get("blackjack", {})) == TYPE_DICTIONARY else {}
	if bool(reset_result.get("ok", true)) or str(reset_result.get("blackjack_host_request_key", "")).is_empty():
		failures.append("Durably barred blackjack dealer reset did not fail atomically behind a retryable host delivery.")
	var rotated_projection := blackjack.surface_state(run_state, run_state.current_environment, {})
	if int(rotated_projection.get("strategy_watch_pressure", -1)) != 0:
		failures.append("Fresh blackjack dealer projection retained the prior dealer's strategy familiarity.")
	if int(blackjack_table.get("hands_played", 0)) != 9 or int(blackjack_table.get("running_count", 0)) != 4 or not bool(blackjack_table.get("barred", false)) or str(blackjack_table.get("barred_reason", "")) != "Casino memory persists.":
		failures.append("Dealer rotation reset physical table history or durable casino ban state.")
	if run_state.suspicion_level() != 28 or int(run_state.narrative_flags.get("grand_casino_games_played", 0)) != 4 or not bool(run_state.narrative_flags.get("grand_casino_cheat_evidence", false)) or str(run_state.narrative_flags.get("grand_casino_players_card_highest_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_SILVER or int(run_state.narrative_flags.get("grand_casino_comp_drink_tokens", 0)) != 2:
		failures.append("Dealer rotation changed heat, evidence, counters, Players Card progress, or durable comp tokens.")


func _blackjack_authority_resolve_for_test(game: GameModule, action_id: String, stake: int, run_state: RunState, session: Dictionary) -> Dictionary:
	var environment := run_state.current_environment
	var game_states: Dictionary = environment.get("game_states", {}) if typeof(environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var table: Dictionary = (game_states.get("blackjack", {}) as Dictionary).duplicate(true) if typeof(game_states.get("blackjack", {})) == TYPE_DICTIONARY else {}
	var binding := "blackjack:%s:%s" % [str(environment.get("id", "unknown")), str(environment.get("archetype_id", "unknown"))]
	var ledger := LendersBlackjackActionAuthorityScript.validate_persisted_ledger(
		table.get(LendersBlackjackActionAuthorityScript.LEDGER_KEY, {}),
		binding,
		run_state.blackjack_authority_checkpoint_fingerprint()
	)
	if ledger.is_empty():
		ledger = LendersBlackjackActionAuthorityScript.default_ledger(binding, run_state.blackjack_authority_checkpoint_fingerprint())
	if not (ledger.get("pending_delivery", {}) as Dictionary).is_empty():
		return {"ok": false, "error_code": "pending_delivery", "message": "Test host already has a pending Blackjack action."}
	table[LendersBlackjackActionAuthorityScript.LEDGER_KEY] = LendersBlackjackActionAuthorityScript.stage_session(ledger, session)
	game.call("_update_environment_table", environment, table)
	run_state.current_environment = environment
	var host: Control = FoundationMain.new()
	host.set("current_game", game)
	host.set("game_module_cache", {"blackjack": game})
	host.set("run_state", run_state)
	host.set("selected_stake", stake)
	var result: Dictionary = host.call("_sealed_action_host_resolve_intent", action_id, stake)
	# This detached authority host never enters the scene tree, so the fixture
	# owns its lifetime. Free it synchronously after copying the returned value;
	# otherwise every call retains a Control RID and its script/resource graph.
	host.free()
	return result


func _check_grand_casino_memory_entry_lines(main_environment: Dictionary, outside_environment: Dictionary, failures: Array) -> void:
	var cases := [
		{"key": "returning", "flags": {}, "heat": 0},
		{"key": "high_heat", "flags": {"grand_casino_max_heat": 58}, "heat": 0},
		{"key": "cheat_evidence", "flags": {"grand_casino_cheat_evidence": true}, "heat": 0},
		{"key": "showdown_pressure", "flags": {"grand_casino_attention_pit_boss_sweep": true}, "heat": 0},
		{"key": "pending_review", "flags": {"grand_casino_entry_bankroll": 100, "grand_casino_games_played": 9, "grand_casino_players_card_awarded_tier": "silver", "grand_casino_players_card_tier": "silver", "grand_casino_players_card_ready_to_claim": true, "grand_casino_players_card_ready_tier": "gold", "high_roller_cashout_pending": true}, "heat": 0, "bankroll": 140},
	]
	for case_value in cases:
		var case: Dictionary = case_value
		var run_state: RunState = RunStateScript.new()
		run_state.start_new("GC-MEMORY-%s" % str(case.get("key", "fixture")))
		run_state.set_environment(main_environment.duplicate(true))
		for flag_key in (case.get("flags", {}) as Dictionary).keys():
			run_state.narrative_flags[str(flag_key)] = (case.get("flags", {}) as Dictionary)[flag_key]
		if case.has("bankroll"):
			run_state.bankroll = int(case.get("bankroll", run_state.bankroll))
		if int(case.get("heat", 0)) > 0:
			run_state.add_suspicion("gc_memory_heat", int(case.get("heat", 0)), "behavior", true, {"environment_id": str(run_state.current_environment.get("id", ""))})
		run_state.set_environment(outside_environment.duplicate(true))
		run_state.set_environment(main_environment.duplicate(true))
		var cue := run_state.pending_grand_casino_entry_cue()
		if str(cue.get("memory_key", "")) != str(case.get("key", "")) or str(cue.get("message", "")).strip_edges().is_empty():
			failures.append("Grand Casino re-entry memory line selected %s instead of dominant state %s." % [str(cue.get("memory_key", "none")), str(case.get("key", ""))])


func _check_grand_casino_spatial_split(library: ContentLibrary, main_archetype: Dictionary, failures: Array) -> void:
	var high_limit := _archetype_by_id(library, RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID)
	var back_room := _archetype_by_id(library, RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID)
	var cage := _archetype_by_id(library, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID)
	if high_limit.is_empty() or back_room.is_empty() or cage.is_empty():
		failures.append("Grand Casino spatial split is missing the High-Limit, Back Room, or Cage archetype.")
		return
	if not bool(high_limit.get("map_hidden", false)) or not bool(back_room.get("map_hidden", false)) or not bool(cage.get("map_hidden", false)):
		failures.append("Grand Casino subrooms must be hidden from world-map node generation.")
	if not JsonCoerceScript._string_array(cage.get("game_pool", [])).is_empty() or RunState.ROURKE_ROOM_PATH.has(RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID) or RunState.RIVAL_CHEATER_ROOMS.has(RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
		failures.append("Grand Casino Cage leaked into a game, Rourke patrol, or rival-cheater room set.")
	var main_games := JsonCoerceScript._string_array(main_archetype.get("game_pool", []))
	var high_games := JsonCoerceScript._string_array(high_limit.get("game_pool", []))
	for machine_id in ["slot", "video_poker", "pull_tabs", "blackjack"]:
		if not main_games.has(machine_id):
			failures.append("Grand Casino Main Floor is missing required low-limit game: %s." % machine_id)
	if main_games.has("bar_dice"):
		failures.append("Grand Casino Main Floor still includes the removed bar dice game.")
	for table_id in ["baccarat", "roulette"]:
		if main_games.has(table_id) or not high_games.has(table_id):
			failures.append("Grand Casino table placement did not isolate %s to the High-Limit Room." % table_id)
	if not high_games.has("blackjack"):
		failures.append("Grand Casino High-Limit Room lost its blackjack table while adding the Main Floor low-limit table.")
	if high_games.has("video_poker"):
		failures.append("Grand Casino High-Limit Room incorrectly includes video poker.")
	var main_economic := JsonCoerceScript._copy_dict(main_archetype.get("economic_profile", {}))
	var high_economic := JsonCoerceScript._copy_dict(high_limit.get("economic_profile", {}))
	if int(high_economic.get("stake_floor", 0)) <= int(main_economic.get("stake_floor", 0)):
		failures.append("Grand Casino High-Limit Room stake floor is not higher than the Main Floor.")
	var main_blackjack_ceiling := GameModule.stake_ceiling_for_game({"economic_profile": main_economic}, "blackjack", 0)
	var high_blackjack_ceiling := GameModule.stake_ceiling_for_game({"economic_profile": high_economic}, "blackjack", 0)
	if main_blackjack_ceiling != 35 or high_blackjack_ceiling <= main_blackjack_ceiling:
		failures.append("Grand Casino blackjack limits are not split between the $5-$35 Main Floor table and the higher-limit room.")
	var chip_stake_run: RunState = RunStateScript.new()
	chip_stake_run.start_new("GC-BLACKJACK-CHIP-STAKE-RANGE")
	chip_stake_run.bankroll = 30
	chip_stake_run.grand_casino_chips = 70
	chip_stake_run.set_environment({
		"id": "grand_casino_chip_stake_range",
		"archetype_id": RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID,
		"economic_profile": {
			"stake_floor": 5,
			"stake_ceiling": 150,
			"game_stake_ceiling_overrides": {"blackjack": 150},
		},
	})
	var chip_stake_host := BlackjackChipStakeRangeHost.new()
	chip_stake_host.run_state = chip_stake_run
	chip_stake_host.presented_cash = 30
	var chip_stake_range := FoundationActionViewModelScript.stake_range_from_action_view(chip_stake_host, {
		"stake_floor": 5,
		"stake_ceiling": 150,
		"base_stake_ceiling": 150,
		"economy_stake_ceiling": 150,
		"economy_pressure_applied": false,
	})
	if int(chip_stake_range.get("max", 0)) != 100:
		failures.append("Grand Casino blackjack stake range ignored chips; $30 cash plus 70 chips should allow a $100 stake, got $%d." % int(chip_stake_range.get("max", 0)))
	var main_layout := JsonCoerceScript._copy_dict(main_archetype.get("layout", {}))
	var fixture_counts := JsonCoerceScript._copy_dict(main_layout.get("game_fixture_counts", {}))
	if int(fixture_counts.get("slot", 0)) != 3 or JsonCoerceScript._copy_array(main_layout.get("game_spots", [])).size() < 6:
		failures.append("Grand Casino Main Floor does not author three slot fixtures plus its other three games.")
	var fixture_run: RunState = RunStateScript.new()
	fixture_run.start_new("GC-MAIN-LOW-LIMIT-FIXTURES")
	var fixture_environment := EnvironmentInstance.from_archetype(main_archetype, 3, fixture_run.create_rng("gc_main_low_limit_fixtures"), library).to_dict()
	var fixture_rects := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(fixture_environment.get("layout", {})).get("object_rects", {}))
	for fixture_id in ["game:slot", "game:slot:2", "game:slot:3"]:
		if not fixture_rects.has(fixture_id):
			failures.append("Grand Casino Main Floor generated layout is missing slot fixture %s." % fixture_id)
	var slot_centers: Dictionary = {}
	for fixture_id in ["game:slot", "game:slot:2", "game:slot:3", "game:video_poker"]:
		var rect := JsonCoerceScript._copy_dict(fixture_rects.get(fixture_id, {}))
		if rect.is_empty():
			continue
		slot_centers[fixture_id] = Vector2(float(rect.get("x", 0.0)) + float(rect.get("w", 0.0)) * 0.5, float(rect.get("y", 0.0)) + float(rect.get("h", 0.0)) * 0.5)
	if slot_centers.size() == 4:
		var first_gap := absf((slot_centers["game:slot:2"] as Vector2).x - (slot_centers["game:slot"] as Vector2).x)
		var second_gap := absf((slot_centers["game:slot:3"] as Vector2).x - (slot_centers["game:slot:2"] as Vector2).x)
		var third_gap := absf((slot_centers["game:video_poker"] as Vector2).x - (slot_centers["game:slot:3"] as Vector2).x)
		var row_y := (slot_centers["game:slot"] as Vector2).y
		if first_gap <= 0.0 or absf(first_gap - second_gap) > 0.02 or absf(second_gap - third_gap) > 0.02 \
				or absf(row_y - (slot_centers["game:slot:2"] as Vector2).y) > 0.01 \
				or absf(row_y - (slot_centers["game:slot:3"] as Vector2).y) > 0.01 \
				or absf(row_y - (slot_centers["game:video_poker"] as Vector2).y) > 0.01:
			failures.append("Grand Casino Main Floor wall machines are not placed as one evenly aligned row (centers=%s gaps=%.3f/%.3f/%.3f)." % [str(slot_centers), first_gap, second_gap, third_gap])
	var slot_variant_run := _grand_casino_spatial_fixture_run(library, "GC-MAIN-SLOT-VARIANTS", failures)
	var slot_game_states := JsonCoerceScript._copy_dict(slot_variant_run.current_environment.get("game_states", {})) if slot_variant_run != null else {}
	var slot_machine_keys: Dictionary = {}
	var slot_cabinet_variants: Dictionary = {}
	for state_key in ["slot", "slot:2", "slot:3"]:
		var machine := JsonCoerceScript._copy_dict(slot_game_states.get(state_key, {}))
		if machine.is_empty():
			failures.append("Grand Casino Main Floor did not generate machine state for %s." % state_key)
			continue
		slot_machine_keys[str(machine.get("machine_key", ""))] = true
		slot_cabinet_variants[str(machine.get("cabinet_variant_id", ""))] = true
	if slot_machine_keys.size() != 3 or slot_cabinet_variants.size() != 3:
		failures.append("Grand Casino Main Floor slot fixtures did not generate three distinct slot machine variants.")
	var fixture_slot_object_states: Dictionary = {}
	for state_key in ["slot", "slot:2", "slot:3"]:
		var machine := JsonCoerceScript._copy_dict(slot_game_states.get(state_key, {}))
		if machine.is_empty():
			continue
		fixture_slot_object_states["game:%s" % state_key] = {
			"status_summary": "fixture %s" % state_key,
			"runtime_state": {"status_label": str(machine.get("format_id", ""))},
			"visual_state": {
				"machine_key": str(machine.get("machine_key", "")),
				"cabinet_variant_id": str(machine.get("cabinet_variant_id", "")),
			},
		}
	var game_sources: Array = []
	for game_index in range(JsonCoerceScript._string_array(fixture_environment.get("game_ids", [])).size()):
		var fixture_game_id := str(JsonCoerceScript._string_array(fixture_environment.get("game_ids", []))[game_index])
		game_sources.append({"id": fixture_game_id, "index": game_index, "definition": library.game(fixture_game_id), "runtime_state": {}, "object_state": {}, "fixture_object_states": fixture_slot_object_states if fixture_game_id == "slot" else {}})
	var fixture_objects := EnvironmentInteractionViewModelScript.interactable_object_view_list(fixture_run, library, {
		"selection": {},
		"layout": fixture_environment.get("layout", {}),
		"game_sources": game_sources,
	})
	var slot_fixture_ids: Array = []
	for fixture_object_value in fixture_objects:
		if typeof(fixture_object_value) != TYPE_DICTIONARY:
			continue
		var fixture_object: Dictionary = fixture_object_value
		if str(fixture_object.get("object_type", "")) == "game" and str(fixture_object.get("source_id", "")) == "slot":
			slot_fixture_ids.append(str(fixture_object.get("object_id", "")))
	if slot_fixture_ids != ["game:slot", "game:slot:2", "game:slot:3"]:
		failures.append("Grand Casino Main Floor interaction view did not expose exactly three clickable slot fixtures.")
	var slot_fixture_visual_keys: Dictionary = {}
	for fixture_object_value in fixture_objects:
		if typeof(fixture_object_value) != TYPE_DICTIONARY:
			continue
		var fixture_object: Dictionary = fixture_object_value
		if str(fixture_object.get("object_type", "")) != "game" or str(fixture_object.get("source_id", "")) != "slot":
			continue
		slot_fixture_visual_keys[str(JsonCoerceScript._copy_dict(fixture_object.get("visual_state", {})).get("machine_key", ""))] = true
	if slot_fixture_visual_keys.size() != 3:
		failures.append("Grand Casino Main Floor interaction view did not preserve distinct slot fixture visual states.")

	for seed_index in range(12):
		var map_run: RunState = RunStateScript.new()
		map_run.start_new("GC-SPATIAL-MAP-%02d" % seed_index)
		var map_data := WorldMapScript.new(library).build(map_run, map_run.create_rng("gc_spatial_map"))
		var grand_node_count := 0
		for node_value in JsonCoerceScript._copy_array(map_data.get("nodes", [])):
			if typeof(node_value) != TYPE_DICTIONARY:
				continue
			var node_id := str((node_value as Dictionary).get("id", ""))
			if node_id.begins_with("grand_casino"):
				grand_node_count += 1
		if grand_node_count != 1 or not WorldMapScript.node_by_id(map_data, RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID).is_empty() or not WorldMapScript.node_by_id(map_data, RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID).is_empty() or not WorldMapScript.node_by_id(map_data, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID).is_empty():
			failures.append("World map seed %d did not contain exactly one Grand Casino node." % seed_index)
			break

	var run_state := _grand_casino_spatial_fixture_run(library, "GC-SPATIAL-SHARED", failures)
	if run_state == null:
		return
	var generator: RunGenerator = RunGeneratorScript.new(library)
	var layout := JsonCoerceScript._copy_dict(run_state.current_environment.get("layout", {}))
	var object_rects := JsonCoerceScript._copy_dict(layout.get("object_rects", {}))
	var slot_bindings := JsonCoerceScript._copy_dict(layout.get("slot_bindings", {}))
	for object_id in ["casino_fixture:host_desk", "travel:grand_casino_high_limit", "travel:grand_casino_back_room", "travel:grand_casino_cage"]:
		var binding := JsonCoerceScript._copy_dict(slot_bindings.get(object_id, {}))
		var mode := str(binding.get("presentation_mode", ""))
		if mode not in ["room", "overflow"] or (mode == "room" and not object_rects.has(object_id)):
			failures.append("Grand Casino Main Floor layout is missing authored object placement authority: %s." % object_id)
	var buy_in := int(JsonCoerceScript._copy_dict(run_state.current_environment.get("local_narrative_flags", {})).get("casino_high_limit_buy_in", 60))
	run_state.bankroll = maxi(0, buy_in - 1)
	if bool(run_state.grand_casino_room_access_status(RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID, buy_in).get("available", true)):
		failures.append("Grand Casino High-Limit door admitted a player without card access or enough cash.")
	run_state.bankroll = buy_in + 40
	var cash_access := run_state.grand_casino_room_access_status(RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID, buy_in)
	if not bool(cash_access.get("available", false)) or int(cash_access.get("cost", 0)) != buy_in:
		failures.append("Grand Casino High-Limit cash buy-in gate did not admit and price an eligible player.")
	if bool(run_state.grand_casino_room_access_status(RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID, buy_in).get("available", true)) or generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID):
		failures.append("Grand Casino Back Room was reachable without the showdown.")
	if not bool(run_state.grand_casino_room_access_status(RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID, buy_in).get("available", false)):
		failures.append("Grand Casino Cage was not freely accessible from the Main Floor.")
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID):
		failures.append("Grand Casino room seam could not enter the freely accessible Cage.")
		return
	var cage_rects := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(run_state.current_environment.get("layout", {})).get("object_rects", {}))
	for object_id in ["casino_fixture:cage_counter", "casino_fixture:cage_atm", "travel:grand_casino"]:
		if not cage_rects.has(object_id):
			failures.append("Grand Casino Cage layout is missing authored object placement: %s." % object_id)
	var cage_item_spots := JsonCoerceScript._copy_array(JsonCoerceScript._copy_dict(run_state.current_environment.get("layout", {})).get("item_spots", []))
	if cage_item_spots.size() != 4 or cage_rects.has("casino_fixture:cage_gift_shop"):
		failures.append("Grand Casino Cage layout did not replace the gift popup fixture with four stable shelf-item spots.")
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_ARCHETYPE_ID):
		failures.append("Grand Casino Cage return door could not restore the Main Floor.")
		return

	run_state.add_suspicion("gc_room_shared_heat", 23, "behavior")
	run_state.narrative_flags["grand_casino_attention_eye_in_the_sky"] = true
	run_state.narrative_flags["grand_casino_cheat_evidence"] = true
	run_state.record_grand_casino_game_result({"ok": true, "game_id": "slot", "action_kind": "legal", "stake": 5})
	var entry_bankroll := int(run_state.narrative_flags.get("grand_casino_entry_bankroll", -1))
	run_state.narrative_flags["grand_casino_high_limit_access"] = true
	run_state.narrative_flags["grand_casino_high_limit_access_method"] = "fixture_card"
	if not generator.enter_grand_casino_room(run_state, RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID):
		failures.append("Grand Casino room seam could not enter the High-Limit Room with access.")
		return
	if run_state.current_world_node_id() != RunState.GRAND_CASINO_ARCHETYPE_ID or str(run_state.current_environment.get("archetype_id", "")) != RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID:
		failures.append("Grand Casino local room move changed the world node or missed the High-Limit archetype.")
	if run_state.suspicion_level() != 23 or not bool(run_state.narrative_flags.get("grand_casino_attention_eye_in_the_sky", false)) or not bool(run_state.narrative_flags.get("grand_casino_cheat_evidence", false)):
		failures.append("Grand Casino room move did not preserve shared heat, attention, and evidence.")
	if int(run_state.narrative_flags.get("grand_casino_games_played", 0)) != 1 or int(run_state.narrative_flags.get("grand_casino_entry_bankroll", -2)) != entry_bankroll:
		failures.append("Grand Casino room move reset shared objective counters or entry bankroll.")
	run_state.store_current_world_node_environment()
	var stored_main := JsonCoerceScript._copy_dict(WorldMapScript.node_by_id(run_state.world_map, RunState.GRAND_CASINO_ARCHETYPE_ID).get("environment", {}))
	if str(stored_main.get("archetype_id", "")) != RunState.GRAND_CASINO_ARCHETYPE_ID:
		failures.append("Grand Casino world node stored a subroom instead of the Main Floor snapshot.")
	var restored: RunState = RunStateScript.new()
	restored.from_dict(run_state.to_dict())
	if str(restored.current_environment.get("archetype_id", "")) != RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID or restored.grand_casino_room_environment(RunState.GRAND_CASINO_ARCHETYPE_ID).is_empty() or restored.suspicion_level() != 23:
		failures.append("Grand Casino room cache, position, or shared heat did not survive save/load.")
	if not generator.enter_grand_casino_room(restored, RunState.GRAND_CASINO_ARCHETYPE_ID):
		failures.append("Grand Casino room seam could not return from High-Limit to Main Floor.")

	var clean_run := _grand_casino_spatial_fixture_run(library, "GC-SPATIAL-CLEAN", failures)
	if clean_run == null:
		return
	clean_run.record_grand_casino_game_result({"ok": true, "game_id": "slot", "action_kind": "legal", "stake": 5})
	if not _prepare_players_card_gold_ready(clean_run, library, failures):
		failures.append("Grand Casino split clean-route fixture could not complete its sequential card path.")
		return
	var split_status := clean_run.demo_objective_status()
	if not bool(split_status.get("high_roller_ready", false)) or str(split_status.get("players_card_next_tier", "")) != RunState.GRAND_CASINO_PLAYERS_CARD_TIER_GOLD:
		failures.append("Grand Casino clean route did not complete its ready transition with play split across rooms.")


func _grand_casino_spatial_fixture_run(library: ContentLibrary, seed_text: String, failures: Array) -> RunState:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new(seed_text)
	var map_data := WorldMapScript.new(library).build(run_state, run_state.create_rng("gc_spatial_fixture_map"))
	run_state.set_world_map(map_data)
	var generator: RunGenerator = RunGeneratorScript.new(library)
	var generated := _harness_arrive(generator, run_state, failures, "Grand Casino spatial fixture arrival", RunState.GRAND_CASINO_ARCHETYPE_ID, true)
	if generated == null or str(run_state.current_environment.get("archetype_id", "")) != RunState.GRAND_CASINO_ARCHETYPE_ID:
		failures.append("Grand Casino spatial fixture could not generate the Main Floor under the world node.")
		return null
	return run_state


# Checks bankrupt failure, supported lender recovery, save/load, and victory/failure separation.
func _check_recovery_loss_pressure_foundation(library: ContentLibrary, failures: Array) -> void:
	var failed_run: RunState = RunStateScript.new()
	failed_run.start_new("M2-FUN-LOSS")
	failed_run.change_bankroll(-failed_run.bankroll)
	if failed_run.bankroll != 0:
		failures.append("Loss pressure fixture did not reach zero bankroll.")
	if failed_run.run_status != RunState.RUN_STATUS_FAILED:
		failures.append("Zero bankroll without recovery did not mark the run failed.")
	if failed_run.run_failure_reason != RunState.FAILURE_BANKROLL_ZERO:
		failures.append("Zero bankroll failure did not record a bankroll-zero reason.")
	if failed_run.economy() != "insolvent":
		failures.append("Zero bankroll without recovery did not mark the economy insolvent.")
	var failed_pressure := failed_run.recovery_pressure_status(false)
	if not bool(failed_pressure.get("failed", false)):
		failures.append("Recovery pressure status did not expose a clear failed state.")
	if str(failed_pressure.get("summary", "")).find("out of money") == -1:
		failures.append("Failed pressure summary is not player-facing enough.")
	var failed_save_service: SaveService = SaveServiceScript.new()
	var failed_slot := "foundation_check_loss_pressure"
	var failed_save_error: Error = failed_save_service.save_run(failed_run, failed_slot)
	if failed_save_error != OK:
		failures.append("Save service could not save failed run state: %s." % failed_save_error)
	else:
		var loaded_failed = failed_save_service.load_run(failed_slot)
		if loaded_failed == null:
			failures.append("Save service could not reload failed run state.")
		elif loaded_failed.run_status != RunState.RUN_STATUS_FAILED or loaded_failed.economy() != "insolvent":
			failures.append("Failed run status/economy did not survive SaveService load.")
		elif loaded_failed.run_failure_reason != failed_run.run_failure_reason:
			failures.append("Failed run reason did not survive SaveService load.")

	var lender := library.lender("street_lender")
	if lender.is_empty():
		failures.append("Recovery pressure needs supported lender fixture: street_lender.")
		return
	var recovery_run: RunState = RunStateScript.new()
	recovery_run.start_new("M2-FUN-RECOVERY")
	recovery_run.set_environment({
		"id": "back_alley_recovery_fixture",
		"archetype_id": "back_alley",
		"kind": "shop",
		"lender_hooks": ["street_lender"],
	})
	recovery_run.change_bankroll(-(recovery_run.bankroll - 1))
	_assert_terminal_fast_parity(recovery_run, library, "street-lender recovery", true, failures)
	var recovery_status := RunTerminalEvaluatorScript.evaluate(recovery_run, library)
	if bool(recovery_status.get("failed", false)) or not bool(recovery_status.get("lender_available", false)):
		failures.append("Low-bankroll lender recovery was not recognized before zero cash.")
	var crew_recovery_run: RunState = RunStateScript.new()
	crew_recovery_run.start_new("M2-FUN-CREW-RECOVERY")
	crew_recovery_run.set_environment({
		"id": "delta_queen_crew_recovery_fixture",
		"archetype_id": "delta_queen",
		"tier": 2,
		"kind": "casino",
		"lender_hooks": ["the_crew"],
	})
	crew_recovery_run.change_bankroll(-(crew_recovery_run.bankroll - 1))
	_assert_terminal_fast_parity(crew_recovery_run, library, "Crew recovery", true, failures)
	var crew_recovery_status := RunTerminalEvaluatorScript.evaluate(crew_recovery_run, library)
	if bool(crew_recovery_status.get("failed", false)) or not bool(crew_recovery_status.get("lender_available", false)):
		failures.append("Debt-profile Crew recovery was falsely classified as stranded.")
	var lender_result := _fixture_lender_result(recovery_run, lender, "street_lender")
	GameModule.apply_result(recovery_run, lender_result)
	if recovery_run.bankroll <= 0:
		failures.append("Supported lender recovery did not restore positive bankroll.")
	if recovery_run.debt.is_empty():
		failures.append("Supported lender recovery did not create debt pressure.")
	if recovery_run.run_status == RunState.RUN_STATUS_FAILED:
		failures.append("Supported lender recovery left the run in failed status.")
	var post_recovery_pressure := recovery_run.recovery_pressure_status(false)
	if bool(post_recovery_pressure.get("failed", false)):
		failures.append("Post-lender recovery still reports a failed pressure state.")
	var recovery_save_service: SaveService = SaveServiceScript.new()
	var recovery_slot := "foundation_check_recovery_pressure"
	var recovery_save_error: Error = recovery_save_service.save_run(recovery_run, recovery_slot)
	if recovery_save_error != OK:
		failures.append("Save service could not save recovery run state: %s." % recovery_save_error)
	else:
		var loaded_recovery = recovery_save_service.load_run(recovery_slot)
		if loaded_recovery == null:
			failures.append("Save service could not reload recovery run state.")
		elif loaded_recovery.bankroll != recovery_run.bankroll or loaded_recovery.debt.size() != recovery_run.debt.size() or loaded_recovery.run_status != recovery_run.run_status:
			failures.append("Recovery run pressure did not survive SaveService load.")

	var victory_run: RunState = RunStateScript.new()
	victory_run.start_new("M2-FUN-VICTORY-NOT-FAILURE")
	victory_run.change_bankroll(-(victory_run.bankroll - 1))
	var victory_deltas := GameModule.empty_result_deltas()
	victory_deltas["flags_set"] = {"demo_victory": true}
	victory_deltas["ended"] = true
	victory_deltas["messages"] = ["Demo Victory: you beat the house for now."]
	GameModule.apply_result(victory_run, GameModule.build_action_result({
		"ok": true,
		"type": "event",
		"source_id": "fixture_victory",
		"action_id": "demo_victory",
		"deltas": victory_deltas,
		"message": "Demo Victory: you beat the house for now.",
	}))
	var victory_pressure := victory_run.recovery_pressure_status(false)
	if victory_run.run_status != GameModule.RESULT_ENDED:
		failures.append("Victory result did not preserve ended run status after zero-bankroll pressure.")
	if bool(victory_pressure.get("failed", true)) or str(victory_pressure.get("state", "")) != "victory":
		failures.append("Victory state conflicted with failure pressure.")

	var stranded_run: RunState = RunStateScript.new()
	stranded_run.start_new("M2-FUN-STRANDED")
	stranded_run.set_environment({
		"id": "stranded_fixture",
		"archetype_id": "fixture_room",
		"kind": "casino",
		"economic_profile": {"stake_floor": 5, "stake_ceiling": 5},
		"game_ids": ["slot"],
		"event_ids": [],
		"item_offers": [],
		"travel_hooks": [],
		"next_archetypes": [],
		"lender_hooks": [],
	})
	stranded_run.change_bankroll(-(stranded_run.bankroll - 1))
	_assert_terminal_fast_parity(stranded_run, library, "stranded run", true, failures)
	var stranded_status := RunTerminalEvaluatorScript.evaluate_terminal_and_apply(stranded_run, library)
	if not bool(stranded_status.get("failed", false)) or stranded_run.run_failure_reason != RunState.FAILURE_STRANDED:
		failures.append("No-wager/no-recovery state did not fail as stranded.")

	var travel_escape_run: RunState = RunStateScript.new()
	travel_escape_run.start_new("M2-FUN-TRAVEL-ESCAPE")
	travel_escape_run.set_environment({
		"id": "travel_escape_fixture",
		"archetype_id": "fixture_room",
		"kind": "casino",
		"economic_profile": {"stake_floor": 5, "stake_ceiling": 5},
		"game_ids": ["slot"],
		"event_ids": [],
		"item_offers": [],
		"travel_hooks": ["corner_store"],
		"next_archetypes": [],
		"lender_hooks": [],
	})
	travel_escape_run.change_bankroll(-(travel_escape_run.bankroll - 2))
	_assert_terminal_fast_parity(travel_escape_run, library, "travel recovery", true, failures)
	var travel_escape_status := RunTerminalEvaluatorScript.evaluate_terminal_and_apply(travel_escape_run, library)
	if bool(travel_escape_status.get("failed", false)) or not bool(travel_escape_status.get("travel_available", false)):
		failures.append("Affordable travel was not preserved as a low-bankroll recovery path.")
	var wager_run: RunState = RunStateScript.new()
	wager_run.start_new("M2-FUN-TERMINAL-FAST-WAGER")
	wager_run.set_environment({
		"id": "terminal_fast_wager_fixture",
		"archetype_id": "fixture_room",
		"kind": "casino",
		"economic_profile": {"stake_floor": 1, "stake_ceiling": 5},
		"game_ids": ["slot"],
		"event_ids": [],
		"item_offers": [],
		"travel_hooks": ["corner_store"],
		"next_archetypes": [],
		"lender_hooks": ["street_lender"],
	})
	_assert_terminal_fast_parity(wager_run, library, "valid-wager fast path", false, failures)
	_check_terminal_evaluator_behavior_matrix(library, failures)
	_check_embedded_refresh_behavior(library, failures)
	_check_broke_pull_tab_deferred_terminal_boundary(library, failures)
	_check_broke_idle_terminal_evaluator_not_per_frame(library, failures)


func _check_broke_pull_tab_deferred_terminal_boundary(library: ContentLibrary, failures: Array) -> void:
	var pull_tabs: GameModule = _load_surface_contract_game(library, "pull_tabs", failures)
	if pull_tabs == null:
		return
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("BROKE-PULL-TAB-DEFERRED")
	var environment := {
		"id": "broke_pull_tab_fixture",
		"archetype_id": "fixture_room",
		"kind": "casino",
		"economic_profile": {"stake_floor": 1, "stake_ceiling": 1},
		# Pull-tabs owns the zero-cash defer state, while bar dice supplies a normal
		# funded wager so the setup refresh is not itself a stranded boundary.
		"game_ids": ["pull_tabs", "bar_dice"],
		"event_ids": [],
		"item_offers": [],
		"travel_hooks": [],
		"next_archetypes": [],
		"lender_hooks": [],
		"game_states": {},
	}
	var machine := pull_tabs.generate_environment_state(run_state, environment, run_state.create_rng("broke_pull_tabs"))
	machine["tray_stack"] = [{"symbols": ["A", "B", "C"], "payout": 0}]
	environment["game_states"] = {"pull_tabs": machine}
	run_state.set_environment(environment)
	run_state.change_bankroll(-run_state.bankroll, true)
	_assert_terminal_fast_parity(run_state, library, "deferred zero-bankroll game", true, failures)
	var deferred_status := RunTerminalEvaluatorScript.evaluate(run_state, library)
	if bool(deferred_status.get("failed", false)) or not bool(deferred_status.get("bankroll_zero_deferred", false)):
		failures.append("Unresolved pull-tab ticket did not preserve zero-bankroll deferred recovery.")
	var states: Dictionary = run_state.current_environment.get("game_states", {}) if typeof(run_state.current_environment.get("game_states", {})) == TYPE_DICTIONARY else {}
	var stored_machine: Dictionary = states.get("pull_tabs", {}) if typeof(states.get("pull_tabs", {})) == TYPE_DICTIONARY else {}
	stored_machine["tray_stack"] = []
	stored_machine["ticket_stack"] = []
	stored_machine["winner_pile"] = []
	states["pull_tabs"] = stored_machine
	run_state.current_environment["game_states"] = states
	run_state.capture_portable_ticket_piles_from_environment(run_state.current_environment)
	var failed_status := RunTerminalEvaluatorScript.evaluate_terminal_and_apply(run_state, library)
	if not bool(failed_status.get("failed", false)) or run_state.run_failure_reason != RunState.FAILURE_BANKROLL_ZERO:
		failures.append("Clearing zero-bankroll pull-tab recovery did not fail at the action boundary with bankroll-zero reason.")


func _assert_terminal_fast_parity(run_state: RunState, library: ContentLibrary, label: String, expect_full_diagnostics: bool, failures: Array) -> void:
	var diagnostic := RunTerminalEvaluatorScript.evaluate(run_state, library)
	var terminal_only := RunTerminalEvaluatorScript.evaluate_terminal(run_state, library)
	for key in ["failed", "terminal", "reason", "message", "wager_available", "bankroll_zero_deferred"]:
		if diagnostic.get(key) != terminal_only.get(key):
			failures.append("Terminal-only evaluator changed %s for %s." % [key, label])
	if expect_full_diagnostics and JSON.stringify(diagnostic) != JSON.stringify(terminal_only):
		failures.append("Terminal-only evaluator did not preserve full no-wager recovery diagnostics for %s." % label)


func _check_terminal_evaluator_behavior_matrix(library: ContentLibrary, failures: Array) -> void:
	var ended_run: RunState = RunStateScript.new()
	ended_run.start_new("TERMINAL-PUBLIC-ENDED")
	ended_run.run_status = RunState.RUN_STATUS_ENDED
	_assert_public_terminal_result(ended_run, library, _terminal_expected({"terminal": true}), RunState.RUN_STATUS_ENDED, RunState.FAILURE_NONE, "ended run", failures)

	var already_failed_run: RunState = RunStateScript.new()
	already_failed_run.start_new("TERMINAL-PUBLIC-FAILED")
	already_failed_run.fail_run(RunState.FAILURE_ABANDONED, "Fixture abandonment.")
	_assert_public_terminal_result(already_failed_run, library, _terminal_expected({
		"failed": true, "terminal": true, "reason": RunState.FAILURE_ABANDONED, "message": "Fixture abandonment.",
	}), RunState.RUN_STATUS_FAILED, RunState.FAILURE_ABANDONED, "already-failed run", failures)

	var heat_run: RunState = RunStateScript.new()
	heat_run.start_new("TERMINAL-PUBLIC-CAPTURE")
	heat_run.set_environment({"id": "heat_capture_room", "archetype_id": "bar", "kind": "casino"})
	heat_run.suspicion["level"] = 100
	_assert_public_terminal_result(heat_run, library, _terminal_expected({
		"failed": true, "terminal": true, "reason": RunState.FAILURE_POLICE_CAPTURE, "message": RunState.POLICE_CAPTURE_FAILURE_MESSAGE,
	}), RunState.RUN_STATUS_FAILED, RunState.FAILURE_POLICE_CAPTURE, "heat capture", failures)

	var forced_travel_run: RunState = RunStateScript.new()
	forced_travel_run.start_new("TERMINAL-PUBLIC-FORCED-TRAVEL")
	forced_travel_run.set_environment({"id": "forced_travel_room", "archetype_id": "bar", "kind": "casino"})
	forced_travel_run.closing_time_state = {"phase": RunState.CLOSING_TIME_PHASE_FORCED_TRAVEL, "environment_id": "forced_travel_room"}
	forced_travel_run.change_bankroll(-forced_travel_run.bankroll, true)
	_assert_public_terminal_result(forced_travel_run, library, _terminal_expected({
		"bankroll_zero_deferred": true, "travel_available": true, "recovery_available": true,
	}), RunState.RUN_STATUS_ACTIVE, RunState.FAILURE_NONE, "zero-bankroll forced travel", failures)

	var event_run := _terminal_recovery_run("TERMINAL-PUBLIC-EVENT", {
		"kind": "shop", "event_ids": ["chatty_clerk"],
	})
	_assert_public_terminal_result(event_run, library, _terminal_expected({
		"event_recovery_available": true, "recovery_available": true,
	}), RunState.RUN_STATUS_ACTIVE, RunState.FAILURE_NONE, "event recovery", failures)

	var zero_invite_run := _terminal_recovery_run("TERMINAL-PUBLIC-ZERO-INVITE", {
		"kind": "casino", "event_ids": ["grand_casino_invite"],
	})
	zero_invite_run.change_bankroll(-zero_invite_run.bankroll, true)
	_assert_public_terminal_result(zero_invite_run, library, _terminal_expected({
		"failed": true,
		"terminal": true,
		"reason": RunState.FAILURE_BANKROLL_ZERO,
		"message": RunState.BANKROLL_ZERO_FAILURE_MESSAGE,
	}), RunState.RUN_STATUS_FAILED, RunState.FAILURE_BANKROLL_ZERO, "zero-bankroll invitation cannot rescue bankruptcy", failures)

	var merchant_run := _terminal_recovery_run("TERMINAL-PUBLIC-MERCHANT", {
		"kind": "shop", "item_offers": [{"id": "fixture_offer"}],
	})
	merchant_run.add_item("creased_luck_card")
	_assert_public_terminal_result(merchant_run, library, _terminal_expected({
		"merchant_sale_available": true, "recovery_available": true,
	}), RunState.RUN_STATUS_ACTIVE, RunState.FAILURE_NONE, "merchant sale recovery", failures)

	var pull_tabs: GameModule = _load_surface_contract_game(library, "pull_tabs", failures)
	if pull_tabs != null:
		var game_hook_run := _terminal_recovery_run("TERMINAL-PUBLIC-GAME-HOOK", {"game_ids": ["pull_tabs"]})
		var game_hook_environment := game_hook_run.current_environment
		var machine := pull_tabs.generate_environment_state(game_hook_run, game_hook_environment, game_hook_run.create_rng("terminal_game_hook"))
		machine["winner_pile"] = [{"symbols": ["A", "A", "A"], "payout": 5}]
		game_hook_environment["game_states"] = {"pull_tabs": machine}
		game_hook_run.set_environment(game_hook_environment)
		_assert_public_terminal_result(game_hook_run, library, _terminal_expected({
			"game_hook_recovery_available": true, "recovery_available": true,
		}), RunState.RUN_STATUS_ACTIVE, RunState.FAILURE_NONE, "game-hook recovery", failures)

	var local_room_run := _grand_casino_spatial_fixture_run(library, "TERMINAL-PUBLIC-LOCAL-ROOM", failures)
	if local_room_run != null:
		local_room_run.current_environment["game_ids"] = []
		local_room_run.current_environment["event_ids"] = []
		local_room_run.current_environment["item_offers"] = []
		local_room_run.current_environment["travel_hooks"] = []
		local_room_run.current_environment["next_archetypes"] = []
		local_room_run.unlocked_travel = []
		local_room_run.current_environment["lender_hooks"] = []
		local_room_run.current_environment["economic_profile"] = {"stake_floor": 5, "stake_ceiling": 5}
		local_room_run.change_bankroll(-(local_room_run.bankroll - 1))
		var local_expected := _terminal_expected({"local_room_travel_available": true, "recovery_available": true})
		_assert_public_terminal_result(local_room_run, library, local_expected, RunState.RUN_STATUS_ACTIVE, RunState.FAILURE_NONE, "Grand Casino local-room recovery", failures)

	var grand_casino_run := _grand_casino_spatial_fixture_run(library, "TERMINAL-PUBLIC-GC-REROUTE", failures)
	if grand_casino_run != null:
		grand_casino_run.narrative_flags["grand_casino_attention_forced_heat"] = true
		grand_casino_run.suspicion["level"] = 100
		if not grand_casino_run.grand_casino_heat_reroute_available():
			failures.append("Grand Casino terminal reroute fixture did not reach a reroutable heat state.")
		else:
			var before_reroute := RunTerminalEvaluatorScript.evaluate(grand_casino_run, library)
			if JSON.stringify(before_reroute) != JSON.stringify(_terminal_expected()):
				failures.append("Public terminal evaluation did not preserve the pre-reroute Grand Casino run exactly.")
			var applied_reroute := RunTerminalEvaluatorScript.evaluate_and_apply(grand_casino_run, library)
			var reroute_status := grand_casino_run.demo_objective_status()
			if bool(applied_reroute.get("failed", true)) or bool(applied_reroute.get("terminal", true)) \
					or grand_casino_run.run_status != RunState.RUN_STATUS_ACTIVE \
					or not bool(reroute_status.get("showdown_pending", false)) \
					or str(grand_casino_run.narrative_flags.get("grand_casino_heat_reroute_context", "")) != "terminal_evaluator":
				failures.append("Public evaluate_and_apply did not reroute Grand Casino heat before terminal failure.")


func _check_embedded_refresh_behavior(library: ContentLibrary, failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("EMBEDDED-REFRESH-BEHAVIOR")
	run_state.set_environment(_embedded_refresh_environment("embedded_refresh_room"))
	run_state.add_item("thermos_black_coffee")
	run_state.set_active_item("thermos_black_coffee")
	var fixture_game := EmbeddedRefreshFixtureGame.new()
	var app := _embedded_refresh_fixture_app(library, run_state, fixture_game, true, "embedded refresh", failures, true)
	if app == null:
		return

	var expected_key := "GAME|%s|%s" % [fixture_game.get_id(), RunState.RUN_STATUS_ACTIVE]
	var stable_key := str(app.call("_embedded_world_header_context_key"))
	if stable_key != expected_key:
		failures.append("Embedded header dependency key was not exactly screen, game id, and run status: %s." % stable_key)
	app.set("current_screen", "RESULT")
	if str(app.call("_embedded_world_header_context_key")) == stable_key:
		failures.append("Embedded header dependency key ignored a screen change.")
	app.set("current_screen", "GAME")
	app.set("current_game", null)
	if str(app.call("_embedded_world_header_context_key")) == stable_key:
		failures.append("Embedded header dependency key ignored a current-game change.")
	app.set("current_game", fixture_game)
	run_state.run_status = RunState.RUN_STATUS_ENDED
	if str(app.call("_embedded_world_header_context_key")) == stable_key:
		failures.append("Embedded header dependency key ignored a run-status change.")
	run_state.run_status = RunState.RUN_STATUS_ACTIVE

	var dialogue := library.dialogue("pull_tab_clerk")
	if dialogue.is_empty() or not run_state.enqueue_dialogue(
			"pull_tab_clerk", "embedded_refresh_talk", {"name": "Fixture Clerk", "role": "guide"},
			str(dialogue.get("start", "greeting")), "embedded_refresh_fixture", {"trigger": "fixture"}):
		failures.append("Embedded refresh fixture could not queue its live TalkDock entry.")
	var title: Label = app.get("title_label")
	var result_panel: Control = app.get("environment_result_panel")
	var active_item_button: Button = app.get("active_item_button")
	var talk_dock: Control = app.get("talk_dock")
	var music_player: Node = app.get("procedural_music_player")
	if title != null:
		title.text = "EMBEDDED-STABLE-HEADER"
	if result_panel != null:
		result_panel.visible = true
	if active_item_button != null:
		active_item_button.text = "STALE-ACTIVE-ITEM"
	if music_player != null:
		music_player.set("_current_music_context", {"embedded_refresh_sentinel": true})
	app.set("game_coach_refresh_scheduled", false)
	app.call("_refresh_after_embedded_game_action", true)
	if title == null or title.text != "EMBEDDED-STABLE-HEADER":
		failures.append("Stable embedded action rebuilt the world header instead of retaining it.")
	if result_panel == null or result_panel.visible:
		failures.append("Embedded action did not hide host-owned result feedback for an embedding surface.")
	if active_item_button == null or not active_item_button.text.begins_with("Use: ") or active_item_button.text == "STALE-ACTIVE-ITEM":
		failures.append("Embedded action did not refresh the active-item slot.")
	if talk_dock == null or str((talk_dock.get("entry") as Dictionary).get("event_id", "")) != "embedded_refresh_talk":
		failures.append("Embedded action did not refresh the live TalkDock entry.")
	if not bool(app.get("game_coach_refresh_scheduled")):
		failures.append("Embedded action did not schedule the post-draw game coach refresh.")
	if music_player == null or bool((music_player.get("_current_music_context") as Dictionary).get("embedded_refresh_sentinel", false)):
		failures.append("Embedded action did not update the procedural-music context.")

	# Live surface progress has its own host boundary; it is not a game action.
	# Publish the module's actual opt-in through the normal snapshot route before
	# arming the synthetic visual increment, so entry rendering cannot count as it.
	run_state.complete_talk_event_resolution("embedded_refresh_talk")
	app.call("_refresh_talk_dock")
	app.set("embedded_probe_time_msec", 100000)
	fixture_game.realtime_probe_mode = "publish"
	app.call("_refresh")
	var surface_canvas: Control = app.get("game_surface_canvas")
	if surface_canvas == null or not surface_canvas.is_visible_in_tree() \
			or not bool(surface_canvas.call("surface_realtime_state_refresh_enabled")) \
			or bool(app.call("_simulation_progression_paused")):
		failures.append("Canonical realtime fixture did not establish an eligible visible module boundary.")
		_sb4_dispose_app(app)
		return
	app.set("last_game_surface_realtime_refresh_msec", 0)
	var run_before_realtime := JSON.stringify(run_state.to_dict())
	var rng_before_realtime := JSON.stringify(run_state.rng_state)
	var game_clock_before_realtime := run_state.game_clock_minutes
	var action_index_before_realtime := int(run_state.event_cadence.get("action_index", 0))
	var host_before_realtime: Dictionary = {}
	for field_name in ["pending_autosave", "pending_autosave_after_frame", "pending_autosave_not_before_msec", "autosave_dirty_generation", "autosave_inflight_generation", "autosave_completed_generation", "last_game_result", "game_surface_ui_state", "selected_action_id", "selected_action_kind", "selected_action_label", "selected_stake"]:
		host_before_realtime[field_name] = JSON.stringify(app.get(field_name))
	var serial_before_realtime := fixture_game.surface_serial
	var calls_before_realtime := fixture_game.realtime_patch_calls
	fixture_game.realtime_probe_mode = "advance"
	app.call("_advance_game_surface_realtime_state")
	var immediate_surface: Dictionary = surface_canvas.call("realtime_surface_state")
	if app.get("current_game") != fixture_game or str(app.get("current_screen")) != "GAME" \
			or int(immediate_surface.get("runtime_serial", -1)) != serial_before_realtime + 1 \
			or fixture_game.realtime_patch_calls != calls_before_realtime + 1 \
			or int(immediate_surface.get("realtime_fixture_clock_msec", -1)) != 100000 \
			or int(immediate_surface.get("surface_time_msec", -1)) != 100000 \
			or int(app.get("last_game_surface_realtime_refresh_msec")) != 100000:
		failures.append("Canonical realtime host boundary did not project exactly one current-clock visual update immediately in place.")
	if JSON.stringify(run_state.to_dict()) != run_before_realtime \
			or JSON.stringify(run_state.rng_state) != rng_before_realtime \
			or run_state.game_clock_minutes != game_clock_before_realtime \
			or int(run_state.event_cadence.get("action_index", 0)) != action_index_before_realtime:
		failures.append("Realtime projection changed serialized run, RNG, game clock, or action cadence.")
	for field_name in host_before_realtime:
		if JSON.stringify(app.get(field_name)) != str(host_before_realtime[field_name]):
			failures.append("Realtime projection changed action-owned host state: %s." % field_name)
	fixture_game.realtime_probe_mode = ""

	# A terminal transition is the exceptional context change: it must abandon the
	# hot path, clear the game, reroute, and rebuild the header immediately.
	run_state.current_environment["game_ids"] = []
	run_state.current_environment["event_ids"] = []
	run_state.current_environment["item_offers"] = []
	run_state.current_environment["travel_hooks"] = []
	run_state.current_environment["next_archetypes"] = []
	run_state.current_environment["lender_hooks"] = []
	run_state.current_environment["economic_profile"] = {"stake_floor": 5, "stake_ceiling": 5}
	run_state.bankroll = 0
	if title != null:
		title.text = "EMBEDDED-TERMINAL-STALE"
	app.call("_refresh_after_embedded_game_action", true)
	if run_state.run_status != RunState.RUN_STATUS_FAILED or str(app.get("current_screen")) != "FAILURE" \
			or app.get("current_game") != null or (title != null and title.text == "EMBEDDED-TERMINAL-STALE"):
		failures.append("Embedded refresh did not reroute and rebuild immediately when terminal evaluation changed context.")
	_sb4_dispose_app(app)

	_check_embedded_completed_action_callsite(library, failures)
	_check_embedded_refresh_autosave_interrupt(library, failures)
	_check_embedded_refresh_tutorial_intervention(library, true, failures)
	_check_embedded_refresh_tutorial_intervention(library, false, failures)


func _check_embedded_completed_action_callsite(library: ContentLibrary, failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("EMBEDDED-COMPLETED-CALLSITE")
	run_state.set_environment(_embedded_refresh_environment("embedded_callsite_room"))
	run_state.add_item("thermos_black_coffee")
	run_state.set_active_item("thermos_black_coffee")
	var fixture_game := EmbeddedRefreshFixtureGame.new()
	var app := _embedded_refresh_fixture_app(library, run_state, fixture_game, true, "embedded completed callsite", failures, true)
	if app == null:
		return
	var canvas: Control = app.get("game_surface_canvas")
	if canvas == null:
		failures.append("Embedded completed-action fixture did not use FoundationMain's owned game canvas.")
		_sb4_dispose_app(app)
		return
	var dialogue := library.dialogue("pull_tab_clerk")
	if dialogue.is_empty() or not run_state.enqueue_dialogue(
			"pull_tab_clerk", "embedded_callsite_talk", {"name": "Fixture Clerk", "role": "guide"},
			str(dialogue.get("start", "greeting")), "embedded_callsite_fixture", {"trigger": "fixture"}):
		failures.append("Embedded completed-action fixture could not queue its TalkDock consequence.")
	var result_panel: Control = app.get("environment_result_panel")
	var active_item_button: Button = app.get("active_item_button")
	var talk_dock: Control = app.get("talk_dock")
	var music_player: Node = app.get("procedural_music_player")
	if result_panel != null:
		result_panel.visible = true
	if active_item_button != null:
		active_item_button.text = "STALE-CALLSITE-ITEM"
	if music_player != null:
		music_player.set("_current_music_context", {"embedded_callsite_sentinel": true})
	(app.get("embedded_probe_log") as Array).clear()
	app.set("game_coach_refresh_scheduled", false)

	# Player input originates at the owned canvas signal, enters FoundationMain's
	# production handler, resolves a completed action, and returns through the real
	# embedded refresh call site. No refresh helper is invoked by this test.
	canvas.emit_signal("surface_action", "fixture_complete", 0, false)
	var probe_log: Array = app.get("embedded_probe_log")
	var canvas_state: Dictionary = canvas.call("realtime_surface_state")
	if str((app.get("last_game_result") as Dictionary).get("action_id", "")) != "fixture_action" \
			or str(app.get("current_screen")) != "GAME" or app.get("current_game") != fixture_game \
			or int(canvas_state.get("runtime_serial", -1)) != 1:
		failures.append("Real non-interrupted embedded action did not complete and render through the production host call site.")
	var refresh_index := probe_log.find("embedded_refresh")
	var active_item_index := probe_log.find("active_item", refresh_index + 1)
	var talk_dock_index := probe_log.find("talk_dock", refresh_index + 1)
	var music_index := probe_log.find("music", refresh_index + 1)
	if refresh_index < 0 or active_item_index <= refresh_index \
			or talk_dock_index <= refresh_index or music_index <= refresh_index:
		failures.append("Production completed-action call site omitted an embedded refresh consequence: %s." % JSON.stringify(probe_log))
	if result_panel == null or result_panel.visible:
		failures.append("Real completed embedded action left host-owned result feedback visible.")
	if active_item_button == null or not active_item_button.text.begins_with("Use: ") or active_item_button.text == "STALE-CALLSITE-ITEM":
		failures.append("Real completed embedded action did not refresh the active-item slot.")
	if talk_dock == null or str((talk_dock.get("entry") as Dictionary).get("event_id", "")) != "embedded_callsite_talk":
		failures.append("Real completed embedded action did not present its queued TalkDock consequence.")
	if music_player == null or bool((music_player.get("_current_music_context") as Dictionary).get("embedded_callsite_sentinel", false)):
		failures.append("Real completed embedded action did not update procedural music.")
	var coach_schedule_index := probe_log.find("coach_schedule", refresh_index + 1)
	if coach_schedule_index <= refresh_index or not bool(app.get("game_coach_refresh_scheduled")):
		failures.append("Real completed embedded action did not arm the production post-draw coach schedule: %s." % JSON.stringify(probe_log))
	_sb4_dispose_app(app)


func _check_embedded_refresh_autosave_interrupt(library: ContentLibrary, failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("EMBEDDED-AUTOSAVE-INTERRUPT")
	var environment := _embedded_refresh_environment("embedded_interrupt_room")
	environment["travel_hooks"] = ["corner_store"]
	run_state.set_environment(environment)
	run_state.narrative_flags["health_inspector_closing_actions"] = 1
	var fixture_game := EmbeddedRefreshFixtureGame.new()
	var app := _embedded_refresh_fixture_app(library, run_state, fixture_game, false, "embedded interrupt", failures, true)
	if app == null:
		return
	var source_environment_id := str(run_state.current_environment.get("id", ""))
	(app.get("embedded_probe_log") as Array).clear()
	var canvas: Control = app.get("game_surface_canvas")
	if canvas != null:
		canvas.emit_signal("surface_action", "fixture_complete", 0, false)
	var probe_log: Array = app.get("embedded_probe_log")
	var autosave_prepare_index := probe_log.find("autosave_prepare")
	var interrupt_index := probe_log.find("post_action_interrupt")
	if canvas == null or autosave_prepare_index < 0 or interrupt_index <= autosave_prepare_index \
			or not bool(app.get("embedded_probe_interrupt_saw_pending_autosave")) \
			or str(app.get("embedded_probe_interrupt_environment_id")) != source_environment_id:
		failures.append("Embedded action did not behaviorally prepare/queue autosave before entering its post-action interrupt: %s." % JSON.stringify(probe_log))
	if not bool(app.get("pending_autosave")):
		failures.append("Completed embedded action did not queue its autosave before post-action interruption.")
	if not bool(run_state.narrative_flags.get("health_inspector_forced_travel", false)) \
			or str(run_state.current_environment.get("id", "")) == source_environment_id \
			or app.get("current_game") != null or str(app.get("current_screen")) != "RESULT":
		failures.append("Post-action Health Inspector interruption did not reroute the embedded game into forced travel.")
	_sb4_dispose_app(app)


func _check_embedded_refresh_tutorial_intervention(library: ContentLibrary, tutorial: bool, failures: Array) -> void:
	var label := "tutorial" if tutorial else "normal"
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("EMBEDDED-HEAT-%s" % label.to_upper(), {"tutorial": true} if tutorial else {})
	run_state.set_environment(_embedded_refresh_environment("embedded_heat_%s_room" % label))
	run_state.suspicion["level"] = 98
	run_state.add_suspicion("embedded_heat_fixture", 1, "behavior", true, {}, true)
	var fixture_game := EmbeddedRefreshFixtureGame.new()
	var app := _embedded_refresh_fixture_app(library, run_state, fixture_game, true, "embedded %s heat" % label, failures)
	if app == null:
		return
	app.call("_resolve_game_action", "fixture_action", true, true, false, {})
	var talk_entry := run_state.next_pending_talk_event()
	var is_heat_intervention := str(talk_entry.get("event_id", "")).begins_with("tutorial_intervention:heat_99:") \
			and str(talk_entry.get("dialogue_id", "")) == "tutorial_pal_guidance" \
			and str(talk_entry.get("current_node", "")) == "heat_99"
	if tutorial:
		if run_state.suspicion_level() != 75 or not is_heat_intervention:
			failures.append("Embedded tutorial action did not surface Pal's live heat-99 intervention and reduce heat to 75.")
	else:
		if run_state.suspicion_level() != 99 or is_heat_intervention or not talk_entry.is_empty():
			failures.append("Normal embedded action incorrectly emitted the tutorial heat intervention.")
	_sb4_dispose_app(app)


func _embedded_refresh_fixture_app(library: ContentLibrary, run_state: RunState, fixture_game: GameModule, dev_mode: bool, label: String, failures: Array, use_probe_host: bool = false) -> Control:
	var app_value: Variant = EmbeddedRefreshProbeHost.new() if use_probe_host else MainScene.instantiate()
	if not app_value is Control:
		failures.append("%s fixture could not instantiate FoundationMain." % label.capitalize())
		return null
	var app: Control = app_value
	root.add_child(app)
	if not bool(app.call("uses_foundation_runtime")):
		app.call("_ready")
	if not bool(app.call("uses_foundation_runtime")):
		failures.append("%s fixture requires FoundationMain runtime nodes." % label.capitalize())
		_sb4_dispose_app(app)
		return null
	# FoundationMain intentionally loads its Play helpers over staged menu frames.
	# This focused fixture jumps straight into an embedded game, so complete those
	# same registered lifecycle stages explicitly before invoking Play methods.
	# A missing or unloadable helper now fails at fixture construction instead of
	# becoming a late Nil call that an aggregate runner could accidentally mask.
	for stage_index in range(11):
		if not bool(app.call("_ensure_run_ui_stage_scripts", stage_index)):
			failures.append("%s fixture could not load FoundationMain helper stage %d." % [label.capitalize(), stage_index])
			_sb4_dispose_app(app)
			return null
	if not bool(app.call("_ensure_run_ui_built")):
		failures.append("%s fixture could not construct FoundationMain's staged run interface." % label.capitalize())
		_sb4_dispose_app(app)
		return null
	app.set("library", library)
	app.set("generator", RunGeneratorScript.new(library))
	app.set("dev_game_test_mode", dev_mode)
	app.set("run_state", run_state)
	app.set("current_game", fixture_game)
	app.set("game_surface_ui_state", {})
	app.call("_set_current_screen", "GAME")
	app.call("_refresh_after_game_selection")
	return app


func _embedded_refresh_environment(environment_id: String) -> Dictionary:
	return {
		"id": environment_id, "display_name": "Embedded Refresh Room", "archetype_id": "bar", "kind": "casino",
		"economic_profile": {"stake_floor": 1, "stake_ceiling": 5},
		"game_ids": ["bar_dice"], "event_ids": [], "item_offers": [], "travel_hooks": [], "next_archetypes": [], "lender_hooks": [], "game_states": {},
	}


func _terminal_recovery_run(seed_text: String, environment_overrides: Dictionary) -> RunState:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new(seed_text)
	var environment := {
		"id": "%s_room" % seed_text.to_lower(), "archetype_id": "fixture_room", "kind": "casino",
		"economic_profile": {"stake_floor": 5, "stake_ceiling": 5},
		"game_ids": [], "event_ids": [], "item_offers": [], "travel_hooks": [], "next_archetypes": [], "lender_hooks": [], "game_states": {},
	}
	for key in environment_overrides:
		environment[key] = environment_overrides[key]
	run_state.set_environment(environment)
	run_state.change_bankroll(-(run_state.bankroll - 1))
	return run_state


func _terminal_expected(overrides: Dictionary = {}) -> Dictionary:
	var expected := {
		"failed": false, "terminal": false, "reason": RunState.FAILURE_NONE, "message": "",
		"wager_available": false, "travel_available": false, "local_room_travel_available": false,
		"event_recovery_available": false, "lender_available": false, "merchant_sale_available": false,
		"game_hook_recovery_available": false, "recovery_available": false, "bankroll_zero_deferred": false,
	}
	for key in overrides:
		expected[key] = overrides[key]
	return expected


func _assert_public_terminal_result(run_state: RunState, library: ContentLibrary, expected: Dictionary, expected_status: String, expected_reason: String, label: String, failures: Array) -> void:
	var diagnostic := RunTerminalEvaluatorScript.evaluate(run_state, library)
	if JSON.stringify(diagnostic) != JSON.stringify(expected):
		failures.append("Public terminal evaluate output drifted for %s. expected=%s actual=%s" % [label, JSON.stringify(expected), JSON.stringify(diagnostic)])
	var terminal_only := RunTerminalEvaluatorScript.evaluate_terminal(run_state, library)
	if not bool(expected.get("wager_available", false)) and JSON.stringify(terminal_only) != JSON.stringify(expected):
		failures.append("Terminal-only no-wager output drifted for %s." % label)
	var applied_run: RunState = RunStateScript.new()
	applied_run.from_dict(run_state.to_dict())
	var applied := RunTerminalEvaluatorScript.evaluate_and_apply(applied_run, library)
	if JSON.stringify(applied) != JSON.stringify(expected):
		failures.append("Public terminal evaluate_and_apply output drifted for %s. expected=%s actual=%s" % [label, JSON.stringify(expected), JSON.stringify(applied)])
	if applied_run.run_status != expected_status or applied_run.run_failure_reason != expected_reason:
		failures.append("Public terminal evaluate_and_apply side effects drifted for %s (status=%s reason=%s)." % [label, applied_run.run_status, applied_run.run_failure_reason])


func _check_broke_idle_terminal_evaluator_not_per_frame(library: ContentLibrary, failures: Array) -> void:
	var pull_tabs: GameModule = _load_surface_contract_game(library, "pull_tabs", failures)
	if pull_tabs == null:
		return
	var app_value: Variant = MainScene.instantiate()
	if not app_value is Control:
		failures.append("Broke-idle terminal evaluator fixture could not instantiate FoundationMain.")
		return
	var app: Control = app_value
	root.add_child(app)
	if not bool(app.call("uses_foundation_runtime")):
		app.call("_ready")
	if not bool(app.call("uses_foundation_runtime")):
		failures.append("Broke-idle terminal evaluator fixture requires FoundationMain runtime nodes.")
		_sb4_dispose_app(app)
		return
	for stage_index in range(11):
		if not bool(app.call("_ensure_run_ui_stage_scripts", stage_index)):
			failures.append("Broke-idle terminal evaluator fixture could not load FoundationMain helper stage %d." % stage_index)
			_sb4_dispose_app(app)
			return
	if not bool(app.call("_ensure_run_ui_built")):
		failures.append("Broke-idle terminal evaluator fixture could not construct FoundationMain's staged run interface.")
		_sb4_dispose_app(app)
		return
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("BROKE-IDLE-NO-POLL")
	var environment := {
		"id": "broke_idle_fixture",
		"archetype_id": "fixture_room",
		"kind": "casino",
		"economic_profile": {"stake_floor": 1, "stake_ceiling": 1},
		"game_ids": ["pull_tabs"],
		"event_ids": [],
		"item_offers": [],
		"travel_hooks": [],
		"next_archetypes": [],
		"lender_hooks": [],
		"game_states": {},
	}
	var machine := pull_tabs.generate_environment_state(run_state, environment, run_state.create_rng("broke_idle_pull_tabs"))
	machine["tray_stack"] = [{"symbols": ["A", "B", "C"], "payout": 0}]
	environment["game_states"] = {"pull_tabs": machine}
	run_state.set_environment(environment)
	app.set("run_state", run_state)
	app.set("current_game", null)
	app.call("_set_current_screen", "ENVIRONMENT")
	# Becoming broke is deliberately introduced without crossing an explicit
	# refresh/action boundary. The assertion below then isolates idle-frame
	# behavior: polling the UI must not turn a state mutation into an implicit
	# terminal evaluation.
	run_state.change_bankroll(-run_state.bankroll, true)
	app.set("terminal_evaluator_call_count", 0)
	for _frame_index in range(12):
		app.call("_process", 1.0 / 60.0)
	var call_count := int(app.get("terminal_evaluator_call_count"))
	if call_count != 0:
		failures.append("Broke-idle frames invoked the terminal evaluator %d time(s); expected action-boundary only." % call_count)
	_sb4_dispose_app(app)


func _fixture_system_pressure_result(environment: Dictionary, bankroll_delta: int, message: String) -> Dictionary:
	var deltas := GameModule.empty_result_deltas()
	deltas["bankroll_delta"] = bankroll_delta
	deltas["story_log"] = [{
		"type": "economy_pressure",
		"id": "m2_system_scenario",
		"bankroll_delta": bankroll_delta,
		"environment_id": str(environment.get("id", "")),
		"message": message,
	}]
	deltas["messages"] = [message]
	return GameModule.build_action_result({
		"ok": true,
		"type": "economy_pressure",
		"source_id": "m2_system_scenario",
		"action_id": "cash_pressure",
		"action_kind": "economy",
		"environment_id": str(environment.get("id", "")),
		"bankroll_delta": bankroll_delta,
		"deltas": deltas,
		"message": message,
	})


func _resolve_first_save_test_action(library: ContentLibrary, run_state: RunState, environment: EnvironmentInstance, failures: Array) -> void:
	if environment.game_ids.is_empty():
		failures.append("SaveService round trip needs a generated game option.")
		return
	var game_id := str(environment.game_ids[0])
	var definition := library.game(game_id)
	if definition.is_empty():
		failures.append("SaveService round trip generated unknown game: %s." % game_id)
		return
	var module_path := str(definition.get("module_path", ""))
	if module_path.ends_with("_ui.gd") or module_path.begins_with("res://data/runtime/"):
		failures.append("SaveService round trip game module points at demo runtime/UI path: %s." % module_path)
		return
	var module_script: Script = load(module_path)
	if module_script == null:
		failures.append("SaveService round trip could not load game module: %s." % module_path)
		return
	var module_instance = module_script.new()
	if not module_instance is GameModule:
		failures.append("SaveService round trip game module does not extend GameModule: %s." % module_path)
		return
	var game: GameModule = module_instance
	game.setup(definition, library)
	var legal_actions: Array = game.actions(run_state, environment.to_dict()).get("legal_actions", [])
	if legal_actions.is_empty():
		failures.append("SaveService round trip game did not expose a legal action.")
		return
	var result := game.resolve(str(legal_actions[0].get("id", "")), 1, run_state, environment.to_dict(), run_state.create_rng())
	_check_action_result_shape(result, "legal", failures)


# Checks the saved file is a foundation RunState payload, not profile/settings/demo data.
func _check_save_payload_file(save_path: String, failures: Array) -> void:
	var saved_text := FileAccess.get_file_as_string(save_path)
	var parsed: Variant = JSON.parse_string(saved_text)
	if typeof(parsed) != TYPE_DICTIONARY:
		failures.append("SaveService wrote non-dictionary save data.")
		return
	var payload: Dictionary = parsed
	if payload.get("schema", "") != SaveService.SAVE_SCHEMA:
		failures.append("SaveService save payload is missing the foundation run schema.")
	if int(payload.get("version", 0)) != SaveService.SAVE_VERSION:
		failures.append("SaveService save payload version is not current.")
	if not payload.has("run_state"):
		failures.append("SaveService save payload is missing RunState data.")
	if payload.has("settings") or payload.has("profile") or payload.has("profile_inventory"):
		failures.append("SaveService mixed settings/profile persistence into run persistence.")
	var stored_value: Variant = payload.get("run_state", {})
	if typeof(stored_value) != TYPE_DICTIONARY:
		failures.append("SaveService stored a non-dictionary RunState envelope.")
		return
	var stored: Dictionary = stored_value
	if str(stored.get(RunSaveCodecScript.STORAGE_MARKER_KEY, "")) != RunSaveCodecScript.STORAGE_FORMAT \
			or not RunSaveCodecScript.storage_envelope_valid(stored):
		failures.append("SaveService did not store a valid compressed RunState envelope.")
		return
	var unpacked := RunSaveCodecScript.unpack_from_storage(stored)
	var run_dict := RunSaveCodecScript.decode(unpacked)
	if unpacked.is_empty() or run_dict.is_empty():
		failures.append("SaveService compressed RunState envelope did not unpack and decode.")
		return
	if run_dict.has("profile_inventory"):
		failures.append("SaveService RunState payload included profile inventory.")
	var tampered := stored.duplicate(true)
	var packed_data := str(tampered.get(RunSaveCodecScript.STORAGE_DATA_KEY, ""))
	if not packed_data.is_empty():
		var replacement := "1" if packed_data.substr(0, 1) != "1" else "2"
		tampered[RunSaveCodecScript.STORAGE_DATA_KEY] = replacement + packed_data.substr(1)
		if not RunSaveCodecScript.unpack_from_storage(tampered).is_empty():
			failures.append("SaveService compressed RunState envelope accepted tampered data.")


# Compares saved and loaded RunState domains.
func _check_run_state_save_round_trip(expected: Dictionary, actual: Dictionary, failures: Array) -> void:
	var keys := [
		"seed_text",
		"seed_value",
		"rng_seed",
		"rng_state",
		"challenge_config",
		"bankroll",
		"economic_state",
		"inventory",
		"debt",
		"suspicion",
		"current_environment",
		"pending_triggered_events",
		"active_triggered_event",
		"environment_history",
		"unlocked_travel",
		"narrative_flags",
		"story_flags",
		"story_log",
		"closing_time_state",
		"run_status",
		"run_spending_score",
	]
	for key in keys:
		if JSON.stringify(expected.get(key)) != JSON.stringify(actual.get(key)):
			failures.append("SaveService did not preserve RunState key: %s." % key)


# Checks the README one-structure EnvironmentInstance shape.
func _check_environment_instance_shape(environment: EnvironmentInstance, require_game: bool, failures: Array, authoritative_environment: Dictionary = {}) -> void:
	if environment == null:
		failures.append("RunGenerator returned a null EnvironmentInstance.")
		return
	var data := environment.to_dict()
	if not authoritative_environment.is_empty() and EnvironmentInstance.from_dict(authoritative_environment).to_dict() != data:
		failures.append("EnvironmentInstance shape does not match its supplied authoritative live room.")
		return
	var scenario_authority_environment := authoritative_environment if not authoritative_environment.is_empty() else data
	if data.is_empty():
		failures.append("EnvironmentInstance did not produce saveable dictionary output.")
	if environment.id.is_empty():
		failures.append("EnvironmentInstance is missing generated id.")
	if environment.archetype_id.is_empty():
		failures.append("EnvironmentInstance is missing venue archetype identity.")
	if environment.display_name.is_empty():
		failures.append("EnvironmentInstance is missing display identity.")
	if environment.tier < 1:
		failures.append("EnvironmentInstance tier must be positive.")
	if environment.art_key.is_empty():
		failures.append("EnvironmentInstance is missing art reference key.")
	var layout: Variant = data.get("layout", {})
	if typeof(layout) != TYPE_DICTIONARY:
		failures.append("EnvironmentInstance layout should serialize generated object placement data.")
	else:
		var object_rects: Variant = (layout as Dictionary).get("object_rects", {})
		var slot_bindings: Variant = (layout as Dictionary).get("slot_bindings", {})
		var slot_overflow_ids: Variant = (layout as Dictionary).get("slot_overflow_ids", [])
		var slot_authority := EnvironmentSlotBinderScript.validate_base_layout_authority(data)
		if not bool(slot_authority.get("ok", false)):
			failures.append("EnvironmentInstance layout failed sealed base-slot validation: %s." % JSON.stringify(slot_authority.get("errors", [])))
		elif typeof(object_rects) != TYPE_DICTIONARY or typeof(slot_bindings) != TYPE_DICTIONARY or typeof(slot_overflow_ids) != TYPE_ARRAY:
			failures.append("EnvironmentInstance layout should include stable slot authority and object_rects.")
		else:
			var manifest_families := {}
			var manifest_action_owners := {}
			var object_manifest := JsonCoerceScript._copy_dict(data.get("object_manifest", {}))
			for row_value in JsonCoerceScript._copy_array(object_manifest.get("rows", [])):
				var row := JsonCoerceScript._copy_dict(row_value)
				var presentation_object_id := str(row.get("presentation_object_id", row.get("object_id", "")))
				if not presentation_object_id.is_empty():
					manifest_families[presentation_object_id] = str(row.get("family", ""))
					for action_id_value in JsonCoerceScript._copy_array(row.get("action_ids", [])):
						var action_id := str(action_id_value).strip_edges()
						if action_id.is_empty():
							continue
						if manifest_action_owners.has(action_id) and str(manifest_action_owners.get(action_id, "")) != presentation_object_id:
							failures.append("EnvironmentInstance manifest assigns one event action to multiple presentation hosts.")
						manifest_action_owners[action_id] = presentation_object_id
			for event_id in environment.event_ids:
				var object_id := "event:%s" % str(event_id)
				# An event may either own a presentation row or be an action exposed by
				# another sealed host. Exact scenario-layout authority is the source of
				# truth for the latter; the physical manifest intentionally omits the
				# action-only row so it cannot become a duplicate placement marker.
				# In every case the tangible host must retain complete slot authority.
				var presentation_object_id := object_id
				if not (slot_bindings as Dictionary).has(presentation_object_id):
					var exact_action_hosts := JsonCoerceScript._copy_dict(
						(layout as Dictionary).get("scenario_instance_action_host_ids", {})
					)
					presentation_object_id = str(exact_action_hosts.get(
						object_id,
						manifest_action_owners.get(object_id, "")
					))
				if str(manifest_families.get(presentation_object_id, "")) == "scenario":
					var composed_proof := preload("res://scripts/core/room_presentation_publication.gd").validate(scenario_authority_environment)
					var scenario_binding := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(scenario_authority_environment.get("scenario_layout_authority", {})).get(presentation_object_id, {}))
					var scenario_mode := str(scenario_binding.get("presentation_mode", ""))
					var scenario_rect := JsonCoerceScript._copy_dict(scenario_binding.get("normalized_hit_rect", {}))
					if not bool(composed_proof.get("ok", false)) or scenario_binding.is_empty() \
							or str(scenario_binding.get("identity", "")) != presentation_object_id \
							or str(scenario_binding.get("slot_family", "")) != "scenario" \
							or str(scenario_binding.get("placement_class", "")) not in EnvironmentPlacementScript.CLASSES \
							or scenario_mode not in ["room", "overflow"]:
						failures.append("EnvironmentInstance layout is missing sealed event presentation authority.")
					if scenario_mode == "room":
						var geometry_ok := scenario_rect.size() == 4 and not str(scenario_binding.get("slot_id", "")).is_empty()
						for field in ["x", "y", "w", "h"]:
							var value: Variant = scenario_rect.get(field)
							geometry_ok = geometry_ok and typeof(value) in [TYPE_INT, TYPE_FLOAT] and is_finite(float(value)) and float(value) >= 0.0
						if not geometry_ok or float(scenario_rect.get("w", 0)) <= 0.0 or float(scenario_rect.get("h", 0)) <= 0.0 \
								or float(scenario_rect.get("x", 0)) + float(scenario_rect.get("w", 0)) > 1.000001 \
								or float(scenario_rect.get("y", 0)) + float(scenario_rect.get("h", 0)) > 1.000001:
							failures.append("EnvironmentInstance room event binding is missing authored geometry.")
					elif scenario_mode == "overflow" and (not scenario_rect.is_empty() or not str(scenario_binding.get("slot_id", "")).is_empty()):
						failures.append("EnvironmentInstance overflow event binding retained room geometry.")
					continue
				var binding := JsonCoerceScript._copy_dict((slot_bindings as Dictionary).get(presentation_object_id, {}))
				var expected_family := str(manifest_families.get(presentation_object_id, ""))
				var mode := str(binding.get("presentation_mode", ""))
				var slot := JsonCoerceScript._copy_dict(binding.get("slot", {}))
				var slot_id := str(binding.get("slot_id", ""))
				var placement_class := str(binding.get("placement_class", ""))
				if binding.is_empty() \
						or presentation_object_id.is_empty() \
						or str(binding.get("identity", "")) != presentation_object_id \
						or expected_family not in ["fixed", "event", "scenario"] \
						or str(binding.get("kind", "")) != expected_family \
						or str(binding.get("slot_family", "")) != expected_family \
						or placement_class not in EnvironmentPlacementScript.CLASSES \
						or mode not in ["room", "overflow"]:
					failures.append("EnvironmentInstance layout is missing sealed event presentation authority.")
					break
				if mode == "room" and (slot_id.is_empty() or slot.is_empty() or not (object_rects as Dictionary).has(presentation_object_id) or (slot_overflow_ids as Array).has(presentation_object_id)):
					failures.append("EnvironmentInstance room event binding is missing authored geometry.")
					break
				if mode == "overflow" and (not slot_id.is_empty() or not slot.is_empty() or (object_rects as Dictionary).has(presentation_object_id) or not (slot_overflow_ids as Array).has(presentation_object_id)):
					failures.append("EnvironmentInstance overflow event binding retained room geometry.")
					break
			for offer in environment.item_offers:
				if typeof(offer) != TYPE_DICTIONARY:
					continue
				var item_object_id := "item:%s" % str((offer as Dictionary).get("id", ""))
				var item_binding := JsonCoerceScript._copy_dict((slot_bindings as Dictionary).get(item_object_id, {}))
				var item_mode := str(item_binding.get("presentation_mode", ""))
				if item_mode not in ["room", "overflow"] \
						or (item_mode == "room" and not (object_rects as Dictionary).has(item_object_id)) \
						or (item_mode == "overflow" and not (slot_overflow_ids as Array).has(item_object_id)):
					failures.append("EnvironmentInstance layout is missing sealed item offer placement authority.")
					break
			if not _unique_strings(environment.next_archetypes, environment.travel_hooks).is_empty() and not (object_rects as Dictionary).has("travel:leave"):
				failures.append("EnvironmentInstance layout is missing the world-map Leave travel object placement.")
	if data.get("visual_context", {}).has("asset_path"):
		failures.append("EnvironmentInstance visual context should not serialize concrete PNG asset paths.")
	if data.get("visual_context", {}).has("scene_asset_path"):
		failures.append("EnvironmentInstance visual context should not serialize concrete scene asset paths.")
	if environment.security_profile.is_empty():
		failures.append("EnvironmentInstance is missing security profile.")
	if environment.economic_profile.is_empty():
		failures.append("EnvironmentInstance is missing economy pressure data.")
	if require_game and environment.game_ids.is_empty():
		failures.append("First foundation EnvironmentInstance should expose at least one game option.")
	if environment.kind != "home" and environment.event_ids.is_empty():
		failures.append("EnvironmentInstance should expose event hooks.")
	if environment.travel_hooks.is_empty() and environment.next_archetypes.is_empty():
		failures.append("EnvironmentInstance should expose travel hooks or next archetypes.")
	if typeof(data.get("item_offers", [])) != TYPE_ARRAY:
		failures.append("EnvironmentInstance item opportunities should serialize as an array.")
	if typeof(data.get("service_ids", [])) != TYPE_ARRAY:
		failures.append("EnvironmentInstance services should serialize as an array.")
	if typeof(data.get("lender_hooks", [])) != TYPE_ARRAY:
		failures.append("EnvironmentInstance lender hooks should serialize as an array.")
	if typeof(data.get("suspicion_cues", [])) != TYPE_ARRAY:
		failures.append("EnvironmentInstance suspicion cues should serialize as an array.")
	if typeof(data.get("local_narrative_flags", {})) != TYPE_DICTIONARY:
		failures.append("EnvironmentInstance local flags should serialize as a dictionary.")
	var restored := EnvironmentInstance.from_dict(data)
	if JSON.stringify(restored.to_dict()) != JSON.stringify(data):
		failures.append("EnvironmentInstance did not preserve saveable data through from_dict.")


# Checks the canonical M2 packs without forcing unused future packs to exist.
func _check_m2_pack_availability(library: ContentLibrary, failures: Array) -> void:
	var future_paths := ContentLibraryScript.future_pack_paths()
	for pack_name in ["lenders", "services", "travel_routes"]:
		var path := str(future_paths.get(pack_name, ""))
		if path.is_empty():
			failures.append("ContentLibrary is missing M2 pack path: %s." % pack_name)
		elif not FileAccess.file_exists(path):
			failures.append("Missing M2 content pack %s at %s." % [pack_name, path])

	if library.lenders.is_empty():
		failures.append("M2 lender pack should load at least one lender definition.")
	if library.services.is_empty():
		failures.append("M2 service pack should load at least one service definition.")
	if library.travel_routes.is_empty():
		failures.append("M2 travel route pack should load at least one route definition.")

	for lender_hook in _all_environment_ids(library.environment_archetypes, "lender_hooks"):
		if library.lender(lender_hook).is_empty():
			failures.append("Environment lender hook is missing lender pack definition: %s." % lender_hook)

	for service_id in _all_environment_ids(library.environment_archetypes, "service_pool"):
		if library.service(service_id).is_empty():
			failures.append("Environment service hook is missing service pack definition: %s." % service_id)

	for travel_id in _all_environment_ids(library.environment_archetypes, "travel_hooks"):
		var route := library.route(travel_id)
		if route.is_empty():
			failures.append("Environment travel hook is missing route pack metadata: %s." % travel_id)
		elif str(route.get("destination_archetype", "")).is_empty():
			failures.append("Travel route is missing destination_archetype: %s." % travel_id)


func _check_tier_two_venue_progression(library: ContentLibrary, failures: Array) -> void:
	var kitty := _archetype_by_id(library, "kitty_cat_lounge")
	var delta := _archetype_by_id(library, "delta_queen")
	if kitty.is_empty():
		failures.append("T4.1 tier-2 venue kitty_cat_lounge is missing.")
	if delta.is_empty():
		failures.append("T4.1 tier-2 venue delta_queen is missing.")
	if kitty.is_empty() or delta.is_empty():
		return
	if int(kitty.get("tier", 0)) != 2 or str(kitty.get("kind", "")) != "casino":
		failures.append("Kitty Cat Lounge must be a tier-2 casino archetype.")
	if int(delta.get("tier", 0)) != 2 or str(delta.get("kind", "")) != "casino":
		failures.append("Delta Queen must be a tier-2 casino archetype.")
	if not JsonCoerceScript._string_array(kitty.get("service_pool", [])).has("kitty_burlesque_show"):
		failures.append("Kitty Cat Lounge is missing its heat-management show service.")
	if not JsonCoerceScript._string_array(kitty.get("game_pool", [])).has("roulette"):
		failures.append("Kitty Cat Lounge should reuse roulette as its house wheel.")
	for required_game in ["blackjack", "roulette", "video_poker"]:
		if not JsonCoerceScript._string_array(delta.get("game_pool", [])).has(required_game):
			failures.append("Delta Queen is missing mid-stakes game %s." % required_game)
	if int(delta.get("travel_locked_actions", 0)) < 2:
		failures.append("Delta Queen must declare a travel_locked_actions ride duration.")
	var kitty_route := library.route("kitty_cat_lounge")
	var delta_route := library.route("delta_queen")
	if kitty_route.is_empty():
		failures.append("Travel route metadata for Kitty Cat Lounge is missing.")
	if delta_route.is_empty():
		failures.append("Travel route metadata for Delta Queen is missing.")
	elif typeof(delta_route.get("availability_window", {})) != TYPE_DICTIONARY or (delta_route.get("availability_window", {}) as Dictionary).is_empty():
		failures.append("Delta Queen route must define an availability_window schedule.")
	var tier_one_sources := ["bar", "gas_station_casino", "small_underground_casino"]
	var tier_one_to_tier_two := false
	for source_id in tier_one_sources:
		var source := _archetype_by_id(library, source_id)
		var targets := _unique_strings(JsonCoerceScript._string_array(source.get("next_archetypes", [])), JsonCoerceScript._string_array(source.get("travel_hooks", [])))
		if targets.has("kitty_cat_lounge") or targets.has("delta_queen"):
			tier_one_to_tier_two = true
	if not tier_one_to_tier_two:
		failures.append("No tier-1 casino routes into the tier-2 venues.")
	var kitty_targets := _unique_strings(JsonCoerceScript._string_array(kitty.get("next_archetypes", [])), JsonCoerceScript._string_array(kitty.get("travel_hooks", [])))
	var delta_targets := _unique_strings(JsonCoerceScript._string_array(delta.get("next_archetypes", [])), JsonCoerceScript._string_array(delta.get("travel_hooks", [])))
	if not kitty_targets.has("grand_casino") or not delta_targets.has("grand_casino"):
		failures.append("Tier-2 venues must route onward to the Grand Casino.")
	var underground := _archetype_by_id(library, "small_underground_casino")
	var underground_targets := _unique_strings(JsonCoerceScript._string_array(underground.get("next_archetypes", [])), JsonCoerceScript._string_array(underground.get("travel_hooks", [])))
	if not underground_targets.has("grand_casino"):
		failures.append("Small Underground Casino lost its direct Grand Casino shortcut.")
	_check_tier_two_world_spawn_thresholds(library, failures)
	_check_grand_casino_invite_gate(library, kitty, delta, failures)
	_check_tier_two_route_gates(library, delta, delta_route, failures)


func _check_tier_two_world_spawn_thresholds(library: ContentLibrary, failures: Array) -> void:
	var repeated_visit_run: RunState = RunStateScript.new()
	repeated_visit_run.start_new("TIER2-REPEATED-VISIT")
	repeated_visit_run.set_world_map(WorldMapScript.new(library).build(repeated_visit_run, repeated_visit_run.create_rng("map")))
	repeated_visit_run.enter_world_node("bar", {})
	repeated_visit_run.enter_world_node("bar", {})
	for tier_two_id in ["kitty_cat_lounge", "delta_queen"]:
		var repeated_node := WorldMapScript.node_by_id(repeated_visit_run.world_map, tier_two_id)
		if bool(repeated_node.get("route_spawn_open", false)):
			failures.append("Repeated visits to one Tier-1 casino incorrectly enabled spawning for %s." % tier_two_id)

	var two_casino_run: RunState = RunStateScript.new()
	two_casino_run.start_new("TIER2-TWO-CASINOS")
	two_casino_run.environment_history_archive_count = 2
	two_casino_run.set_world_map(WorldMapScript.new(library).build(two_casino_run, two_casino_run.create_rng("map")))
	two_casino_run.enter_world_node("bar", {})
	two_casino_run.enter_world_node("gas_station_casino", {})
	for tier_two_id in ["kitty_cat_lounge", "delta_queen"]:
		var eligible_node := WorldMapScript.node_by_id(two_casino_run.world_map, tier_two_id)
		if not bool(eligible_node.get("route_spawn_open", false)):
			failures.append("Two distinct Tier-1 casino visits did not enable spawning for %s." % tier_two_id)
	_assert_tier_two_travel_option(two_casino_run, library, "two distinct Tier-1 casino visits", failures)
	if str(two_casino_run.narrative_flags.get(RunState.TIER_TWO_LOCATION_SPAWN_REASON_FLAG, "")) != "two_tier_one_casinos":
		failures.append("Two-casino Tier-2 spawn gate did not record its progression reason.")

	var underground_run: RunState = RunStateScript.new()
	underground_run.start_new("TIER2-UNDERGROUND")
	underground_run.environment_history_archive_count = 1
	underground_run.set_world_map(WorldMapScript.new(library).build(underground_run, underground_run.create_rng("map")))
	underground_run.enter_world_node("small_underground_casino", {})
	for tier_two_id in ["kitty_cat_lounge", "delta_queen"]:
		var eligible_node := WorldMapScript.node_by_id(underground_run.world_map, tier_two_id)
		if not bool(eligible_node.get("route_spawn_open", false)):
			failures.append("Underground Casino visit did not enable spawning for %s." % tier_two_id)
	_assert_tier_two_travel_option(underground_run, library, "the Underground Casino visit", failures)
	if str(underground_run.narrative_flags.get(RunState.TIER_TWO_LOCATION_SPAWN_REASON_FLAG, "")) != "underground_visit":
		failures.append("Underground Tier-2 spawn gate did not record its progression reason.")

	# A pre-fix save can already contain qualifying visits and open spawn gates
	# while both Tier-2 nodes remain hidden. Loading must reconcile that state.
	var legacy_run: RunState = RunStateScript.new()
	legacy_run.start_new("TIER2-LEGACY-SAVE")
	legacy_run.environment_history_archive_count = 2
	var legacy_map := WorldMapScript.new(library).build(legacy_run, legacy_run.create_rng("map"))
	legacy_map = WorldMapScript.enter_node(legacy_map, "bar", {})
	legacy_map = WorldMapScript.enter_node(legacy_map, "gas_station_casino", {})
	legacy_map = WorldMapScript.enable_node_spawns(legacy_map, ["kitty_cat_lounge", "delta_queen"])
	legacy_run.set_world_map(legacy_map)
	var loaded_legacy_run: RunState = RunStateScript.new()
	loaded_legacy_run.from_dict(legacy_run.to_dict())
	for tier_two_id in ["kitty_cat_lounge", "delta_queen"]:
		var repaired_node := WorldMapScript.node_by_id(loaded_legacy_run.world_map, tier_two_id)
		if not bool(repaired_node.get("route_spawn_open", false)):
			failures.append("Qualifying legacy save did not repair Tier-2 casino spawn eligibility for %s on load." % tier_two_id)
	_assert_tier_two_travel_option(loaded_legacy_run, library, "legacy save repair", failures)


func _assert_tier_two_travel_option(run_state: RunState, library: ContentLibrary, context: String, failures: Array) -> void:
	var revealed_tier_two_ids: Array = []
	for tier_two_id in ["kitty_cat_lounge", "delta_queen"]:
		var node := WorldMapScript.node_by_id(run_state.world_map, tier_two_id)
		if bool(node.get("seen", false)) and str(node.get("state", "")) != WorldMapScript.STATE_HIDDEN:
			revealed_tier_two_ids.append(tier_two_id)
	if revealed_tier_two_ids.is_empty():
		failures.append("%s opened Tier-2 spawn gates without revealing a connected casino route." % context.capitalize())
		return
	var generator: RunGenerator = RunGeneratorScript.new(library)
	var production_targets := generator._world_travel_target_ids(run_state, run_state.world_map, run_state.current_world_node_id())
	for tier_two_id in revealed_tier_two_ids:
		if production_targets.has(tier_two_id):
			return
	failures.append("%s revealed Tier-2 casinos, but none became a production travel option: revealed=%s targets=%s." % [context.capitalize(), JSON.stringify(revealed_tier_two_ids), JSON.stringify(production_targets)])


func _check_tier_two_route_gates(library: ContentLibrary, delta: Dictionary, delta_route: Dictionary, failures: Array) -> void:
	if delta_route.is_empty():
		return
	var bar := _archetype_by_id(library, "bar")
	var route_run: RunState = RunStateScript.new()
	route_run.start_new("TIER2-ROUTE-GATE")
	route_run.bankroll = 500
	route_run.environment_history.append({"id": "corner_store_001", "archetype_id": "corner_store"})
	var bar_env := EnvironmentInstance.from_archetype(bar, 1, route_run.create_rng("bar_env"), library)
	route_run.set_environment(bar_env.to_dict())
	route_run.current_environment["turns"] = 2
	var closed_status := route_run.travel_route_status(delta_route)
	if bool(closed_status.get("available", true)):
		failures.append("Delta Queen route should close when the boarding window is away from the dock.")
	route_run.current_environment["turns"] = 4
	var open_status := route_run.travel_route_status(delta_route)
	if not bool(open_status.get("available", false)):
		failures.append("Delta Queen route should open on its scheduled boarding turn: %s." % str(open_status.get("disabled_reason", "")))
	var delta_run: RunState = RunStateScript.new()
	delta_run.start_new("TIER2-LOCK-GATE")
	delta_run.bankroll = 500
	delta_run.environment_history.append({"id": "small_underground_casino_002", "archetype_id": "small_underground_casino"})
	var delta_env := EnvironmentInstance.from_archetype(delta, 2, delta_run.create_rng("delta_env"), library)
	delta_run.set_environment(delta_env.to_dict())
	var expected_lock := int(delta.get("travel_locked_actions", 0))
	if delta_run.current_travel_lock_remaining() != expected_lock:
		failures.append("Delta Queen travel lock did not initialize from the archetype.")
	var grand_route := library.route("grand_casino")
	var locked_status := delta_run.travel_route_status(grand_route)
	if bool(locked_status.get("available", true)):
		failures.append("Delta Queen allowed travel before its ride lock expired.")
	var loaded: RunState = RunStateScript.new()
	loaded.from_dict(delta_run.to_dict())
	if loaded.current_travel_lock_remaining() != expected_lock:
		failures.append("Delta Queen travel lock did not survive save/load.")
	loaded.advance_environment_turns(maxi(0, expected_lock - 1))
	if expected_lock > 1 and loaded.current_travel_lock_remaining() <= 0:
		failures.append("Delta Queen travel lock expired too early.")
	loaded.advance_environment_turns(1)
	if loaded.current_travel_lock_remaining() != 0:
		failures.append("Delta Queen travel lock did not expire after the required action count.")
	var unlocked_status := loaded.travel_route_status(grand_route)
	if bool(unlocked_status.get("available", true)) or bool(unlocked_status.get("hidden", true)) or not bool(unlocked_status.get("locked", false)):
		failures.append("Delta Queen did not expose Grand Casino as a visible locked route before the invitation was earned.")
	loaded.narrative_flags["grand_casino_invite"] = true
	var invite_status := loaded.travel_route_status(grand_route)
	if not bool(invite_status.get("available", false)) or bool(invite_status.get("hidden", true)) or bool(invite_status.get("locked", true)) or int(invite_status.get("cost", -1)) != 0:
		failures.append("Delta Queen did not allow onward travel after ride lock and invitation: %s." % str(invite_status.get("disabled_reason", "")))


func _check_grand_casino_invite_gate(library: ContentLibrary, kitty: Dictionary, delta: Dictionary, failures: Array) -> void:
	var invite_definition := library.event("grand_casino_invite")
	if invite_definition.is_empty():
		failures.append("Grand Casino invite event is missing.")
		return
	for archetype in [kitty, delta]:
		var archetype_id := str((archetype as Dictionary).get("id", ""))
		if not JsonCoerceScript._string_array((archetype as Dictionary).get("event_pool", [])).has("grand_casino_invite"):
			failures.append("%s event pool does not include the Grand Casino invite." % archetype_id)
		if not JsonCoerceScript._string_array((archetype as Dictionary).get("required_event_ids", [])).has("grand_casino_invite"):
			failures.append("%s does not require the Grand Casino invite event." % archetype_id)
	for seed_index in range(8):
		var seed_text := "GRAND-INVITE-SPAWN-%d" % seed_index
		var run_state: RunState = RunStateScript.new()
		run_state.start_new(seed_text)
		for archetype in [kitty, delta]:
			var archetype_data := archetype as Dictionary
			var environment := EnvironmentInstance.from_archetype(archetype_data, 2, run_state.create_rng("%s:%s" % [seed_text, str(archetype_data.get("id", ""))]), library).to_dict()
			if not JsonCoerceScript._string_array(environment.get("event_ids", [])).has("grand_casino_invite"):
				failures.append("%s did not guarantee Grand Casino invite for seed %s." % [str(archetype_data.get("id", "")), seed_text])
	var decline_run: RunState = RunStateScript.new()
	decline_run.start_new("GRAND-INVITE-DECLINE")
	var decline_env := EnvironmentInstance.from_archetype(delta, 2, decline_run.create_rng("decline_delta"), library).to_dict()
	decline_run.set_environment(decline_env)
	var invite_module := EventModule.new()
	invite_module.setup(invite_definition, library)
	_check_grand_casino_invite_table_win_spawn(library, invite_module, kitty, delta, failures)
	if not invite_module.can_trigger(decline_run, decline_env):
		failures.append("Grand Casino invite did not trigger at a tier-2 casino before acceptance.")
	var decline_bankroll_before := decline_run.bankroll
	var decline_result := invite_module.resolve(decline_run, decline_env, "not_yet")
	if not bool(decline_result.get("ok", false)):
		failures.append("Grand Casino invite decline choice did not resolve.")
	var decline_deltas := JsonCoerceScript._copy_dict(decline_result.get("deltas", {}))
	if decline_run.bankroll != decline_bankroll_before or int(decline_result.get("bankroll_delta", 0)) != 0 or int(decline_deltas.get("bankroll_delta", 0)) != 0:
		failures.append("Declining Grand Casino invite granted bankroll.")
	if bool(decline_run.narrative_flags.get("grand_casino_invite", false)) or JsonCoerceScript._string_array(decline_run.current_environment.get("resolved_event_ids", [])).has("grand_casino_invite"):
		failures.append("Declining Grand Casino invite set the flag or resolved the event.")
	if not invite_module.can_trigger(decline_run, decline_run.current_environment):
		failures.append("Declining Grand Casino invite did not leave the event re-openable.")
	var accept_run: RunState = RunStateScript.new()
	accept_run.start_new("GRAND-INVITE-ACCEPT")
	accept_run.bankroll = 500
	accept_run.environment_history.append({"id": "visited_once", "archetype_id": "corner_store"})
	var world_map := WorldMapScript.new(library)
	accept_run.set_world_map(world_map.build(accept_run, accept_run.create_rng("grand_invite_map")))
	var accept_env := EnvironmentInstance.from_archetype(delta, 2, accept_run.create_rng("accept_delta"), library).to_dict()
	accept_run.set_environment(accept_env)
	accept_run.current_environment["travel_lock_remaining"] = 0
	accept_run.enter_world_node("delta_queen", accept_run.current_environment)
	var locked_route := library.route("grand_casino")
	var expected_free_origins := ["beach", "delta_queen", "kitty_cat_lounge"]
	var authored_free_origins := JsonCoerceScript._string_array(JsonCoerceScript._copy_array(locked_route.get("free_from_archetypes", [])))
	expected_free_origins.sort()
	authored_free_origins.sort()
	if authored_free_origins != expected_free_origins:
		failures.append("Grand Casino route free origins must be exactly Kitty Cat Lounge, Delta Queen, and Beach: %s." % JSON.stringify(authored_free_origins))
	var locked_status := accept_run.travel_route_status(locked_route)
	if bool(locked_status.get("available", true)) or bool(locked_status.get("hidden", true)) or not bool(locked_status.get("locked", false)):
		failures.append("Grand Casino route was not exposed as a locked route before accepting the invite.")
	var underground_locked_status := accept_run.travel_route_status(library.route("small_underground_casino"))
	if bool(underground_locked_status.get("available", true)) or not bool(underground_locked_status.get("hidden", false)) or bool(underground_locked_status.get("locked", false)):
		failures.append("Underground route without locked_hint should remain fully hidden before its tip.")
	_check_grand_casino_locked_route_ui(library, delta, locked_route, failures)
	var accept_bankroll_before := accept_run.bankroll
	var accept_result := invite_module.resolve(accept_run, accept_run.current_environment, "accept_invite")
	if not bool(accept_result.get("ok", false)) or not bool(accept_run.narrative_flags.get("grand_casino_invite", false)):
		failures.append("Accepting Grand Casino invite did not set the unlock flag.")
	var accept_deltas := JsonCoerceScript._copy_dict(accept_result.get("deltas", {}))
	if int(accept_result.get("bankroll_delta", 0)) != 50 or int(accept_deltas.get("bankroll_delta", 0)) != 50 or accept_run.bankroll != accept_bankroll_before + 50:
		failures.append("Accepting Grand Casino invite did not grant exactly +50 bankroll once.")
	if not JsonCoerceScript._string_array(accept_run.current_environment.get("resolved_event_ids", [])).has("grand_casino_invite"):
		failures.append("Accepting Grand Casino invite did not resolve the event instance.")
	var grand_node := WorldMapScript.node_by_id(accept_run.world_map, "grand_casino")
	if not bool(grand_node.get("unlocked", false)) or str(grand_node.get("discovery_source", "")) != WorldMapScript.DISCOVERY_SOURCE_EVENT:
		failures.append("Accepting Grand Casino invite did not unlock the Grand Casino map node as an event discovery.")
	var unlocked_status := accept_run.travel_route_status(locked_route)
	if not bool(unlocked_status.get("available", false)) or bool(unlocked_status.get("hidden", true)) or bool(unlocked_status.get("locked", true)) or int(unlocked_status.get("cost", -1)) != 0:
		failures.append("Grand Casino route did not become available after accepting the invite.")
	var accepted_bankroll := accept_run.bankroll
	var retry_result := invite_module.resolve(accept_run, accept_run.current_environment, "accept_invite")
	var retry_deltas := JsonCoerceScript._copy_dict(retry_result.get("deltas", {}))
	if bool(retry_result.get("ok", false)) or accept_run.bankroll != accepted_bankroll \
			or int(retry_result.get("bankroll_delta", 0)) != 0 or int(retry_deltas.get("bankroll_delta", 0)) != 0:
		failures.append("Resolved Grand Casino invite granted bankroll again on retry.")

	var floor_run: RunState = RunStateScript.new()
	floor_run.start_new("GRAND-INVITE-ONE-DOLLAR")
	floor_run.change_bankroll(-(floor_run.bankroll - 1))
	floor_run.environment_history.append({"id": "visited_once", "archetype_id": "corner_store"})
	floor_run.set_world_map(WorldMapScript.new(library).build(floor_run, floor_run.create_rng("grand_invite_floor_map")))
	var floor_env := EnvironmentInstance.from_archetype(delta, 2, floor_run.create_rng("grand_invite_floor_delta"), library).to_dict()
	floor_env["travel_lock_remaining"] = 0
	floor_run.set_environment(floor_env)
	floor_run.enter_world_node("delta_queen", floor_run.current_environment)
	var floor_result := invite_module.resolve(floor_run, floor_run.current_environment, "accept_invite")
	var floor_status := floor_run.travel_route_status(locked_route)
	if not bool(floor_result.get("ok", false)) or floor_run.bankroll != 51 or floor_run.run_status != RunState.RUN_STATUS_ACTIVE or floor_run.is_terminal() \
			or int(floor_status.get("cost", -1)) != 0 or not bool(floor_status.get("available", false)):
		failures.append("A live $1 Delta Queen run did not become an active $51 run with free invited Grand travel.")

	var low_bankroll_run: RunState = RunStateScript.new()
	low_bankroll_run.from_dict(accept_run.to_dict())
	var bar_archetype := _archetype_by_id(library, "bar")
	var low_bankroll_env := EnvironmentInstance.from_archetype(bar_archetype, 1, low_bankroll_run.create_rng("grand_invite_low_bar"), library).to_dict()
	low_bankroll_env["travel_lock_remaining"] = 0
	low_bankroll_run.world_map = WorldMapScript.unlock_nodes(low_bankroll_run.world_map, ["bar"], WorldMapScript.DISCOVERY_SOURCE_TRAVEL)
	low_bankroll_run.set_environment(low_bankroll_env)
	low_bankroll_run.enter_world_node("bar", low_bankroll_run.current_environment)
	low_bankroll_run.bankroll = 500
	var low_bankroll_map := WorldMapScript.new(library)
	var low_bankroll_route := low_bankroll_map.route_for_target(low_bankroll_run.world_map, "bar", "grand_casino")
	var priced_low_bankroll_status := low_bankroll_run.travel_route_status(low_bankroll_route)
	var priced_low_bankroll_cost := int(priced_low_bankroll_status.get("cost", 0))
	low_bankroll_run.bankroll = maxi(0, priced_low_bankroll_cost - 1)
	var low_bankroll_status := low_bankroll_run.travel_route_status(low_bankroll_route)
	if low_bankroll_route.is_empty() or priced_low_bankroll_cost <= 0 or bool(low_bankroll_status.get("available", true)) or str(low_bankroll_status.get("disabled_reason", "")) != "Not enough bankroll for this route.":
		failures.append("Low-bankroll invited Grand route did not retain its exact affordability blocker.")
	var low_bankroll_targets := RunGeneratorScript.new(library)._world_travel_target_ids(low_bankroll_run, low_bankroll_run.world_map, "bar")
	if not low_bankroll_targets.has("grand_casino"):
		failures.append("The event-unlocked Grand Casino disappeared from the capped production map while its fare was unaffordable: %s." % JSON.stringify(low_bankroll_targets))
	if low_bankroll_targets.size() > WorldMapScript.TRAVEL_TOTAL_TARGET_LIMIT + low_bankroll_run.travel_option_bonus():
		failures.append("Preserving the unaffordable event-unlocked Grand Casino exceeded the production travel-card cap.")
	# A real late-route map can have one enabled event-unlocked Tier-2 casino plus
	# more additive revisits than the three-card surface can render. The promised
	# Grand card must replace the lower-priority new destination, while the
	# deterministic revisit subset fills only the remaining capped slots.
	var crowded_revisit_ids := ["back_alley", "bar", "gas_station_casino", "motel"]
	var crowded_nodes: Array = [{
		"id": "kitty_cat_lounge", "kind": "casino", "tier": 2,
		"state": WorldMapScript.STATE_VISITED, "seen": true,
		"position": {"x": 0.5, "y": 0.5},
	}]
	for revisit_index in range(crowded_revisit_ids.size()):
		crowded_nodes.append({
			"id": str(crowded_revisit_ids[revisit_index]), "kind": "casino", "tier": 1,
			"state": WorldMapScript.STATE_VISITED, "seen": true,
			"position": {"x": 0.1 + float(revisit_index) * 0.15, "y": 0.2},
		})
	crowded_nodes.append({
		"id": "delta_queen", "kind": "casino", "tier": 2,
		"state": WorldMapScript.STATE_REVEALED, "seen": true, "unlocked": true,
		"discovery_source": WorldMapScript.DISCOVERY_SOURCE_EVENT,
		"position": {"x": 0.7, "y": 0.7},
	})
	crowded_nodes.append({
		"id": "grand_casino", "kind": "boss", "tier": 3,
		"state": WorldMapScript.STATE_REVEALED, "seen": true, "unlocked": true,
		"discovery_source": WorldMapScript.DISCOVERY_SOURCE_EVENT,
		"position": {"x": 0.9, "y": 0.5},
	})
	var crowded_edges: Array = []
	for crowded_target_id in crowded_revisit_ids + ["delta_queen", "grand_casino"]:
		crowded_edges.append({
			"a": "kitty_cat_lounge", "b": str(crowded_target_id),
			"distance_blocks": 2, "base_cost": 8, "cost": 8,
		})
	var crowded_map := {
		"seed_text": "GRAND-INVITE-CROWDED",
		"start_node_id": "back_alley",
		"current_node_id": "kitty_cat_lounge",
		"nodes": crowded_nodes,
		"edges": crowded_edges,
		"visited_path": crowded_revisit_ids + ["kitty_cat_lounge"],
	}
	var crowded_enabled_ids := crowded_revisit_ids + ["delta_queen"]
	var crowded_targets := WorldMapScript.travel_target_ids(
		crowded_map,
		"kitty_cat_lounge",
		WorldMapScript.TRAVEL_NEW_TARGET_LIMIT,
		WorldMapScript.TRAVEL_TOTAL_TARGET_LIMIT,
		crowded_enabled_ids
	)
	if not crowded_targets.has("grand_casino") or crowded_targets.has("delta_queen"):
		failures.append("The promised Grand Casino did not replace the lower-priority new Tier-2 card on a revisit-crowded map: %s." % JSON.stringify(crowded_targets))
	if crowded_targets.size() != WorldMapScript.TRAVEL_TOTAL_TARGET_LIMIT:
		failures.append("The promised Grand Casino and crowded revisits did not obey the production travel-card cap: %s." % JSON.stringify(crowded_targets))
	var selected_crowded_revisits := 0
	for crowded_target_id_value in crowded_targets:
		var crowded_target_id := str(crowded_target_id_value)
		if crowded_target_id == "grand_casino":
			continue
		if not crowded_revisit_ids.has(crowded_target_id):
			failures.append("The crowded travel-card subset admitted an unexpected target %s: %s." % [crowded_target_id, JSON.stringify(crowded_targets)])
		else:
			selected_crowded_revisits += 1
	if selected_crowded_revisits != WorldMapScript.TRAVEL_TOTAL_TARGET_LIMIT - 1:
		failures.append("The promised Grand Casino did not preserve exactly two deterministic revisit cards under the cap: %s." % JSON.stringify(crowded_targets))
	# A temporarily unaffordable event promise cannot rely on a lower-priority new
	# card being available to displace. It must remain visible, with its blocker,
	# even when every competing capped card is an enabled revisit.
	var revisit_only_targets := WorldMapScript.travel_target_ids(
		crowded_map,
		"kitty_cat_lounge",
		WorldMapScript.TRAVEL_NEW_TARGET_LIMIT,
		WorldMapScript.TRAVEL_TOTAL_TARGET_LIMIT,
		crowded_revisit_ids
	)
	var revisit_only_selected_count := 0
	for revisit_only_target_value in revisit_only_targets:
		if crowded_revisit_ids.has(str(revisit_only_target_value)):
			revisit_only_selected_count += 1
	if revisit_only_targets.size() != WorldMapScript.TRAVEL_TOTAL_TARGET_LIMIT \
			or not revisit_only_targets.has("grand_casino") \
			or revisit_only_targets.has("delta_queen") \
			or revisit_only_selected_count != WorldMapScript.TRAVEL_TOTAL_TARGET_LIMIT - 1:
		failures.append("The disabled promised Grand Casino disappeared behind an all-revisit travel-card cap: %s." % JSON.stringify(revisit_only_targets))
	var suppressed_env := EnvironmentInstance.from_archetype(kitty, 2, accept_run.create_rng("suppressed_kitty"), library).to_dict()
	if invite_module.can_trigger(accept_run, suppressed_env):
		failures.append("Grand Casino invite copy at the other tier-2 venue was not suppressed after acceptance.")
	var save_service: SaveService = SaveServiceScript.new()
	var accept_slot := "foundation_check_grand_invite_accept"
	var save_error: Error = save_service.save_run(accept_run, accept_slot)
	if save_error != OK:
		failures.append("Save service could not save Grand Casino invite progress: %s." % save_error)
	else:
		var loaded_accept = save_service.load_run(accept_slot)
		if loaded_accept == null:
			failures.append("Save service could not reload Grand Casino invite progress.")
		else:
			var loaded_status: Dictionary = loaded_accept.travel_route_status(locked_route)
			if loaded_accept.bankroll != accepted_bankroll \
					or not bool(loaded_accept.narrative_flags.get("grand_casino_invite", false)) \
					or not JsonCoerceScript._string_array(loaded_accept.current_environment.get("resolved_event_ids", [])).has("grand_casino_invite") \
					or int(loaded_status.get("cost", -1)) != 0 \
					or not bool(loaded_status.get("available", false)):
				failures.append("Grand Casino invite route availability did not survive save/load.")
			var loaded_bankroll_before_retry: int = loaded_accept.bankroll
			var loaded_retry: Dictionary = invite_module.resolve(loaded_accept, loaded_accept.current_environment, "accept_invite")
			var loaded_retry_deltas := JsonCoerceScript._copy_dict(loaded_retry.get("deltas", {}))
			if bool(loaded_retry.get("ok", false)) or loaded_accept.bankroll != loaded_bankroll_before_retry \
					or int(loaded_retry.get("bankroll_delta", 0)) != 0 or int(loaded_retry_deltas.get("bankroll_delta", 0)) != 0:
				failures.append("Save/load rearmed the resolved Grand Casino invite or granted its bankroll twice.")
	var gated_run: RunState = RunStateScript.new()
	gated_run.start_new("GRAND-INVITE-GATED-LOAD")
	gated_run.bankroll = 500
	gated_run.environment_history.append({"id": "visited_once", "archetype_id": "corner_store"})
	var gated_slot := "foundation_check_grand_invite_gated"
	var gated_save_error: Error = save_service.save_run(gated_run, gated_slot)
	if gated_save_error == OK:
		var loaded_gated = save_service.load_run(gated_slot)
		if loaded_gated != null:
			var gated_status: Dictionary = loaded_gated.travel_route_status(locked_route)
			if bool(gated_status.get("available", true)) or bool(gated_status.get("hidden", true)) or not bool(gated_status.get("locked", false)):
				failures.append("Grand Casino locked route hint did not survive save/load without the invite flag.")


func _check_grand_casino_invite_table_win_spawn(library: ContentLibrary, invite_module: EventModule, kitty: Dictionary, delta: Dictionary, failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("GRAND-INVITE-TABLE-WIN")
	run_state.bankroll = 1000
	var map := WorldMapScript.new(library)
	run_state.set_world_map(map.build(run_state, run_state.create_rng("table_win_map")))
	var source_node_id := run_state.current_world_node_id()
	var source_archetype := _archetype_by_id(library, "gas_station_casino")
	var source_environment := EnvironmentInstance.from_archetype(source_archetype, 1, run_state.create_rng("table_win_source"), library).to_dict()
	source_environment["id"] = "table_win_source_room"
	source_environment["world_node_id"] = source_node_id
	var source_event_ids := JsonCoerceScript._string_array(source_environment.get("event_ids", []))
	source_event_ids.erase(RunState.GRAND_CASINO_INVITATION_EVENT_ID)
	source_environment["event_ids"] = source_event_ids
	run_state.set_environment(source_environment)
	var default_environment := EnvironmentInstance.from_archetype(delta, 2, run_state.create_rng("table_win_default"), library).to_dict()
	default_environment["world_node_id"] = "delta_queen"
	run_state.world_map = WorldMapScript.store_environment(run_state.world_map, "delta_queen", default_environment)

	GameModule.apply_result(run_state, {"ok": true, "game_id": "roulette", "source_id": "roulette", "action_id": "spin_roulette", "deltas": {"bankroll_delta": 300}})
	GameModule.apply_result(run_state, {"ok": true, "game_id": "slot", "source_id": "slot", "action_id": "spin", "deltas": {"bankroll_delta": 1000}})
	if bool(run_state.narrative_flags.get(RunState.GRAND_CASINO_INVITATION_TABLE_WIN_FLAG, false)):
		failures.append("Grand Casino table-win invite triggered at exactly $300 or from a non-table game.")

	var forged_blackjack_result := {"ok": true, "game_id": "blackjack", "source_id": "blackjack", "action_id": "play_basic", "deltas": {"bankroll_delta": 301}}
	forged_blackjack_result["blackjack_host_apply_receipt"] = {"request_key": "test:blackjack:qualifying_table_win", "context_fingerprint": "copied_context"}
	var before_forged_blackjack := run_state.to_dict()
	GameModule.apply_result(run_state, forged_blackjack_result)
	if run_state.bankroll != int(before_forged_blackjack.get("bankroll", run_state.bankroll)) \
			or bool(run_state.narrative_flags.get(RunState.GRAND_CASINO_INVITATION_TABLE_WIN_FLAG, false)):
		failures.append("A fabricated +301 Blackjack result escaped the exact pending host receipt.")
	var qualifying_result := {"ok": true, "game_id": "roulette", "source_id": "roulette", "action_id": "spin_roulette", "deltas": {"bankroll_delta": 301}}
	GameModule.apply_result(run_state, qualifying_result)
	if not bool(run_state.narrative_flags.get(RunState.GRAND_CASINO_INVITATION_TABLE_WIN_FLAG, false)):
		failures.append("A net blackjack win over $300 did not trigger the Grand Casino invitation.")
	if not JsonCoerceScript._string_array(run_state.current_environment.get("event_ids", [])).has(RunState.GRAND_CASINO_INVITATION_EVENT_ID):
		failures.append("The table-win invitation did not spawn in the player's current environment.")
	if not bool(qualifying_result.get("grand_casino_invitation_spawned", false)) or JsonCoerceScript._string_array(qualifying_result.get("messages", [])).is_empty():
		failures.append("The qualifying table result did not tell the player that the invitation spawned.")
	if not invite_module.can_trigger(run_state, run_state.current_environment):
		failures.append("The table-win invitation spawned but was not interactable in its earned environment.")
	var default_node := WorldMapScript.node_by_id(run_state.world_map, "delta_queen")
	var stored_default: Dictionary = default_node.get("environment", {}) if typeof(default_node.get("environment", {})) == TYPE_DICTIONARY else {}
	if JsonCoerceScript._string_array(stored_default.get("event_ids", [])).has(RunState.GRAND_CASINO_INVITATION_EVENT_ID):
		failures.append("The table-win trigger left a second invitation at the default Tier-2 spawn.")

	run_state.store_current_world_node_environment()
	var other_environment := EnvironmentInstance.from_archetype(kitty, 2, run_state.create_rng("table_win_other"), library).to_dict()
	other_environment["world_node_id"] = "kitty_cat_lounge"
	run_state.set_environment(other_environment)
	if JsonCoerceScript._string_array(run_state.current_environment.get("event_ids", [])).has(RunState.GRAND_CASINO_INVITATION_EVENT_ID):
		failures.append("Entering another default Tier-2 venue regenerated a second table-win invitation.")
	GameModule.apply_result(run_state, {"ok": true, "game_id": "roulette", "source_id": "roulette", "action_id": "spin_roulette", "deltas": {"bankroll_delta": 900}})
	if str(run_state.narrative_flags.get("grand_casino_invite_table_win_environment_id", "")) != "table_win_source_room":
		failures.append("A later table win relocated an invitation that had already spawned.")

	var loaded: RunState = RunStateScript.new()
	loaded.from_dict(run_state.to_dict())
	var loaded_source_node := WorldMapScript.node_by_id(loaded.world_map, source_node_id)
	var loaded_source: Dictionary = loaded_source_node.get("environment", {}) if typeof(loaded_source_node.get("environment", {})) == TYPE_DICTIONARY else {}
	if not JsonCoerceScript._string_array(loaded_source.get("event_ids", [])).has(RunState.GRAND_CASINO_INVITATION_EVENT_ID):
		failures.append("The earned invitation location did not survive save/load.")
	loaded.set_environment(loaded_source)
	if not invite_module.can_trigger(loaded, loaded.current_environment):
		failures.append("The earned invitation was not interactable after returning to its saved location.")
	else:
		var table_win_accept_bankroll_before := loaded.bankroll
		var accept_result := invite_module.resolve(loaded, loaded.current_environment, "accept_invite")
		if not bool(accept_result.get("ok", false)) or not bool(loaded.narrative_flags.get("grand_casino_invite", false)):
			failures.append("The earned table-win invitation could not be accepted normally.")
		var table_win_accept_deltas := JsonCoerceScript._copy_dict(accept_result.get("deltas", {}))
		if int(accept_result.get("bankroll_delta", 0)) != 50 or int(table_win_accept_deltas.get("bankroll_delta", 0)) != 50 or loaded.bankroll != table_win_accept_bankroll_before + 50:
			failures.append("The saved table-win invitation did not grant exactly +50 bankroll once.")
		if JsonCoerceScript._string_array(loaded.current_environment.get("event_ids", [])).has(RunState.GRAND_CASINO_INVITATION_EVENT_ID) or _world_map_stored_event_count(loaded.world_map, RunState.GRAND_CASINO_INVITATION_EVENT_ID) != 0:
			failures.append("Accepting the table-win invitation left another spawned copy in the run.")


func _world_map_stored_event_count(map_data: Dictionary, event_id: String) -> int:
	var count := 0
	for node_value in map_data.get("nodes", []):
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var environment_value: Variant = (node_value as Dictionary).get("environment", {})
		if typeof(environment_value) == TYPE_DICTIONARY and JsonCoerceScript._string_array((environment_value as Dictionary).get("event_ids", [])).has(event_id):
			count += 1
	return count


func _check_grand_casino_locked_route_ui(library: ContentLibrary, delta: Dictionary, locked_route: Dictionary, failures: Array) -> void:
	var app_value: Variant = MainScene.instantiate()
	if not app_value is Control:
		failures.append("Grand Casino locked route UI fixture could not instantiate FoundationMain.")
		return
	var app: Control = app_value
	root.add_child(app)
	if not bool(app.call("uses_foundation_runtime")):
		app.call("_ready")
	if not bool(app.call("uses_foundation_runtime")):
		failures.append("Grand Casino locked route UI fixture requires FoundationMain runtime nodes.")
		_sb4_dispose_app(app)
		return
	for stage_index in range(11):
		if not bool(app.call("_ensure_run_ui_stage_scripts", stage_index)):
			failures.append("Grand Casino locked route UI fixture could not load FoundationMain helper stage %d." % stage_index)
			_sb4_dispose_app(app)
			return
	if not bool(app.call("_ensure_run_ui_built")):
		failures.append("Grand Casino locked route UI fixture could not construct FoundationMain's staged run interface.")
		_sb4_dispose_app(app)
		return
	var ui_run: RunState = RunStateScript.new()
	ui_run.start_new("GRAND-LOCKED-ROUTE-UI")
	ui_run.bankroll = 500
	ui_run.environment_history.append({"id": "visited_once", "archetype_id": "corner_store"})
	var world_map := WorldMapScript.new(library)
	ui_run.set_world_map(world_map.build(ui_run, ui_run.create_rng("grand_locked_ui_map")))
	var delta_env := EnvironmentInstance.from_archetype(delta, 2, ui_run.create_rng("grand_locked_ui_delta"), library).to_dict()
	delta_env["travel_lock_remaining"] = 0
	ui_run.set_environment(delta_env)
	ui_run.world_map = WorldMapScript.unlock_nodes(ui_run.world_map, ["delta_queen", "grand_casino"], WorldMapScript.DISCOVERY_SOURCE_EVENT)
	ui_run.world_map = WorldMapScript.enter_node(ui_run.world_map, "delta_queen", ui_run.current_environment)
	app.set("library", library)
	app.set("generator", RunGeneratorScript.new(library))
	app.set("run_state", ui_run)
	app.set("current_game", null)
	app.call("_set_current_screen", "ENVIRONMENT")
	app.call("_refresh")
	var choices: Array = app.call("_travel_choice_view_list")
	var grand_choice: Dictionary = {}
	for choice_value in choices:
		if typeof(choice_value) != TYPE_DICTIONARY:
			continue
		var choice: Dictionary = choice_value
		if str(choice.get("id", "")) == "grand_casino":
			grand_choice = choice
			break
	if grand_choice.is_empty():
		failures.append("Grand Casino locked route did not render in the travel list.")
	else:
		if bool(grand_choice.get("enabled", true)) or not bool(grand_choice.get("locked", false)):
			failures.append("Grand Casino locked route travel row was not disabled and marked locked.")
		if str(grand_choice.get("disabled_reason", "")).find("invitation") == -1:
			failures.append("Grand Casino locked route row did not show the invitation condition.")
		if not grand_choice.has("cost") or not grand_choice.has("distance") or not grand_choice.has("distance_blocks"):
			failures.append("Grand Casino locked route row did not retain its read-only travel cost and distance details.")
	if bool(app.call("select_travel_option", "grand_casino")):
		failures.append("Grand Casino locked route was selectable from the travel list.")
	if not str(app.get("selected_travel_target_id")).is_empty():
		failures.append("Grand Casino locked route armed selected_travel_target_id.")
	var map_snapshot: Dictionary = app.call("_world_map_snapshot")
	var grand_node: Dictionary = {}
	for node_value in JsonCoerceScript._copy_array(map_snapshot.get("nodes", [])):
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		if str(node.get("id", "")) == "grand_casino":
			grand_node = node
			break
	if not grand_node.is_empty():
		failures.append("Unvisited Grand Casino map node appeared before the invitation made it an available destination.")
	if bool(app.call("select_world_map_node", "grand_casino")):
		failures.append("Grand Casino locked map node was selectable for travel.")
	if not str(app.get("selected_travel_target_id")).is_empty():
		failures.append("Grand Casino locked map node armed selected_travel_target_id.")
	var unlocked_run: RunState = RunStateScript.new()
	unlocked_run.from_dict(ui_run.to_dict())
	unlocked_run.narrative_flags["grand_casino_invite"] = true
	var unlocked_status := unlocked_run.travel_route_status(locked_route)
	if not bool(unlocked_status.get("available", false)) or bool(unlocked_status.get("hidden", true)) or bool(unlocked_status.get("locked", true)) or int(unlocked_status.get("cost", -1)) != 0:
		failures.append("Grand Casino locked_hint route did not return normal status after the invite flag.")
	var unaffordable_run: RunState = RunStateScript.new()
	unaffordable_run.from_dict(unlocked_run.to_dict())
	var bar_archetype := _archetype_by_id(library, "bar")
	if bar_archetype.is_empty():
		failures.append("Grand Casino unaffordable-map fixture requires the Bar archetype.")
		_sb4_dispose_app(app)
		return
	var bar_env := EnvironmentInstance.from_archetype(bar_archetype, 1, unaffordable_run.create_rng("grand_locked_ui_bar"), library).to_dict()
	bar_env["travel_lock_remaining"] = 0
	unaffordable_run.world_map = WorldMapScript.unlock_nodes(unaffordable_run.world_map, ["bar"], WorldMapScript.DISCOVERY_SOURCE_TRAVEL)
	unaffordable_run.set_environment(bar_env)
	unaffordable_run.enter_world_node("bar", unaffordable_run.current_environment)
	unaffordable_run.bankroll = 500
	var unaffordable_route := RunGeneratorScript.new(library).world_route_for_target(unaffordable_run, "grand_casino")
	var priced_unaffordable_status := unaffordable_run.travel_route_status(unaffordable_route)
	var priced_unaffordable_cost := int(priced_unaffordable_status.get("cost", 0))
	unaffordable_run.bankroll = maxi(0, priced_unaffordable_cost - 1)
	var unaffordable_status := unaffordable_run.travel_route_status(unaffordable_route)
	if unaffordable_route.is_empty() or priced_unaffordable_cost <= 0 or bool(unaffordable_status.get("available", true)) or str(unaffordable_status.get("disabled_reason", "")) != "Not enough bankroll for this route.":
		failures.append("Non-comp Grand Casino UI fixture did not retain its positive unaffordable fare.")
	app.set("run_state", unaffordable_run)
	app.call("_invalidate_travel_view_cache")
	app.call("_refresh")
	var unaffordable_target_ids: Array = app.call("_travel_target_ids")
	if not unaffordable_target_ids.has("grand_casino"):
		failures.append("Invited Grand Casino was not selected as a public map target while its fare was unaffordable: %s." % JSON.stringify(unaffordable_target_ids))
	var hidden_node_id := ""
	for hidden_candidate_value in JsonCoerceScript._copy_array(unaffordable_run.world_map.get("nodes", [])):
		if typeof(hidden_candidate_value) != TYPE_DICTIONARY:
			continue
		var hidden_candidate_id := str((hidden_candidate_value as Dictionary).get("id", "")).strip_edges()
		if not hidden_candidate_id.is_empty() and not WorldMapScript.is_node_visible(unaffordable_run.world_map, hidden_candidate_id):
			hidden_node_id = hidden_candidate_id
			break
	if hidden_node_id.is_empty():
		failures.append("Grand Casino unaffordable-map fixture did not retain an unrevealed node for privacy coverage.")
	elif unaffordable_target_ids.has(hidden_node_id):
		failures.append("Public travel targets retained hidden node %s even though no travel choice could be rendered for it." % hidden_node_id)
	var unaffordable_map_snapshot: Dictionary = app.call("_world_map_snapshot")
	var unaffordable_grand_node: Dictionary = {}
	var hidden_node_rendered := false
	for node_value in JsonCoerceScript._copy_array(unaffordable_map_snapshot.get("nodes", [])):
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		var node_id := str(node.get("id", ""))
		if node_id == "grand_casino":
			unaffordable_grand_node = node
		if not hidden_node_id.is_empty() and node_id == hidden_node_id:
			hidden_node_rendered = true
	if unaffordable_grand_node.is_empty():
		failures.append("Selected, invited Grand Casino disappeared from the public map while its fare was unaffordable.")
	else:
		if not bool(unaffordable_grand_node.get("travel_target", false)) or bool(unaffordable_grand_node.get("travel_enabled", true)):
			failures.append("Unaffordable Grand Casino public map node was not a disabled travel target.")
		if str(unaffordable_grand_node.get("travel_disabled_reason", "")) != "Not enough bankroll for this route.":
			failures.append("Unaffordable Grand Casino public map node did not retain the exact fare blocker.")
	if hidden_node_rendered:
		failures.append("Rendering an unaffordable selected destination leaked unrevealed map node %s." % hidden_node_id)

	# Confirm through FoundationMain rather than stopping at route-status preview:
	# destination installation replaces current_environment before the travel
	# result is built, so this catches any late recomputation of a departure comp.
	var comp_run: RunState = RunStateScript.new()
	comp_run.from_dict(unlocked_run.to_dict())
	comp_run.bankroll = 51
	var comp_generator: RunGenerator = RunGeneratorScript.new(library)
	var comp_route := comp_generator.world_route_for_target(comp_run, "grand_casino")
	var comp_status := comp_run.travel_route_status(comp_route)
	if comp_route.is_empty() or int(comp_status.get("cost", -1)) != 0 or not bool(comp_status.get("available", false)):
		failures.append("Grand Casino production comp-travel fixture was not enabled at zero fare before confirmation.")
	else:
		app.set("run_state", comp_run)
		app.set("generator", comp_generator)
		app.set("current_game", null)
		app.call("_clear_selected_travel")
		app.call("_invalidate_travel_view_cache")
		app.call("_set_current_screen", "ENVIRONMENT")
		app.call("_refresh")
		var comp_selected := bool(app.call("select_travel_option", "grand_casino"))
		var comp_confirmed := bool(app.call("confirm_selected_travel", true)) if comp_selected else false
		var comp_result: Dictionary = app.get("last_hook_result") if typeof(app.get("last_hook_result")) == TYPE_DICTIONARY else {}
		if not comp_selected or not comp_confirmed \
				or str(comp_run.current_environment.get("archetype_id", "")) != RunState.GRAND_CASINO_ARCHETYPE_ID \
				or comp_run.bankroll != 51 or comp_run.run_status != RunState.RUN_STATUS_ACTIVE or comp_run.is_terminal() \
				or int(comp_result.get("route_cost", -1)) != 0 or int(comp_result.get("bankroll_delta", -1)) != 0 \
				or int(comp_run.narrative_flags.get("grand_casino_entry_bankroll", -1)) != 51 \
				or int(comp_run.narrative_flags.get("grand_casino_net_winnings", -1)) != 0:
			failures.append("Real Delta Queen-to-Grand confirmation did not preserve the $51 comp stake as the active zero-net entry baseline: selected=%s confirmed=%s bankroll=%d status=%s result=%s." % [comp_selected, comp_confirmed, comp_run.bankroll, comp_run.run_status, JSON.stringify(comp_result)])

	# This is a new independent fare fixture. Tear down the previous menu-owned
	# presentation before replacing its RunState; do not bypass the input guard.
	app.call("_cancel_travel_presentation")
	var paid_run: RunState = RunStateScript.new()
	paid_run.from_dict(unaffordable_run.to_dict())
	paid_run.bankroll = 500
	var paid_generator: RunGenerator = RunGeneratorScript.new(library)
	var paid_route := paid_generator.world_route_for_target(paid_run, "grand_casino")
	var paid_status := paid_run.travel_route_status(paid_route)
	var paid_cost := int(paid_status.get("cost", 0))
	if paid_route.is_empty() or paid_cost <= 0 or not bool(paid_status.get("available", false)):
		failures.append("Grand Casino production paid-travel fixture did not retain an available positive Bar fare.")
	else:
		var paid_bankroll_before := paid_run.bankroll
		app.set("run_state", paid_run)
		app.set("generator", paid_generator)
		app.set("current_game", null)
		app.call("_clear_selected_travel")
		app.call("_invalidate_travel_view_cache")
		app.call("_set_current_screen", "ENVIRONMENT")
		app.call("_refresh")
		var paid_selected := bool(app.call("select_travel_option", "grand_casino"))
		var paid_confirmed := bool(app.call("confirm_selected_travel", true)) if paid_selected else false
		var paid_result: Dictionary = app.get("last_hook_result") if typeof(app.get("last_hook_result")) == TYPE_DICTIONARY else {}
		if not paid_selected or not paid_confirmed \
				or str(paid_run.current_environment.get("archetype_id", "")) != RunState.GRAND_CASINO_ARCHETYPE_ID \
				or paid_run.bankroll != paid_bankroll_before - paid_cost or paid_run.run_status != RunState.RUN_STATUS_ACTIVE \
				or int(paid_result.get("route_cost", -1)) != paid_cost or int(paid_result.get("bankroll_delta", 0)) != -paid_cost:
			failures.append("Real Bar-to-Grand confirmation did not charge its positive departure fare exactly once: selected=%s confirmed=%s expected=%d bankroll=%d result=%s." % [paid_selected, paid_confirmed, paid_cost, paid_run.bankroll, JSON.stringify(paid_result)])
	_sb4_dispose_app(app)


# Collects unique ids from one array field across environment archetypes.
func _all_environment_ids(archetypes: Array, field_name: String) -> Array:
	var result: Array = []
	for archetype in archetypes:
		if typeof(archetype) != TYPE_DICTIONARY:
			continue
		var values: Variant = (archetype as Dictionary).get(field_name, [])
		if typeof(values) != TYPE_ARRAY:
			continue
		for value in values:
			var id := str(value).strip_edges()
			if not id.is_empty() and not result.has(id):
				result.append(id)
	return result


func _check_baccarat_grand_casino_only(library: ContentLibrary, failures: Array) -> void:
	var found_baccarat_in_grand := false
	var found_roulette_in_grand := false
	var roulette_rooms := ["kitty_cat_lounge", "delta_queen", RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID]
	for archetype_value in library.environment_archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		var archetype_id := str(archetype.get("id", ""))
		var pool := JsonCoerceScript._string_array(archetype.get("game_pool", []))
		if pool.has("baccarat"):
			if archetype_id != RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID:
				failures.append("Baccarat must only appear in the Grand Casino High-Limit Room, but %s includes it." % archetype_id)
			else:
				found_baccarat_in_grand = true
		if pool.has("roulette"):
			if not roulette_rooms.has(archetype_id):
				failures.append("Roulette must only appear in the Grand Casino High-Limit Room or T4.1 tier-2 wheel venues, but %s includes it." % archetype_id)
			if archetype_id == RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID:
				found_roulette_in_grand = true
		if archetype_id == RunState.GRAND_CASINO_HIGH_LIMIT_ARCHETYPE_ID:
			var count_range: Array = archetype.get("game_count", []) if typeof(archetype.get("game_count", [])) == TYPE_ARRAY else []
			if count_range.size() < 2 or int(count_range[0]) < pool.size() or int(count_range[1]) < pool.size():
				failures.append("Grand Casino High-Limit Room does not guarantee every premium table is present.")
	if not found_baccarat_in_grand:
		failures.append("Baccarat must be present in the Grand Casino High-Limit game pool.")
	if not found_roulette_in_grand:
		failures.append("Roulette must be present in the Grand Casino High-Limit game pool.")


# Checks generated item offer prices.
func _check_offer_prices(offers: Array, library: ContentLibrary, failures: Array) -> void:
	var seen: Array = []
	for offer in offers:
		var item_id: String = offer.get("id", "")
		if seen.has(item_id):
			failures.append("Generated duplicate shop item offer: %s." % item_id)
		seen.append(item_id)
		var item := library.item(item_id)
		if item.is_empty():
			failures.append("Generated offer references unknown item: %s." % item_id)
			continue
		var price := int(offer.get("price", -1))
		if price < int(item.get("price_min", 0)) or price > int(item.get("price_max", 0)):
			failures.append("Generated item price outside range: %s." % item_id)


# Checks that room-facing items and events have replaceable art metadata.
func _check_content_art_presentation(library: ContentLibrary, failures: Array) -> void:
	var item_icon_keys: Dictionary = {}
	var item_asset_paths: Dictionary = {}
	for item in library.items:
		if typeof(item) != TYPE_DICTIONARY:
			continue
		var item_data: Dictionary = item
		var item_id := str(item_data.get("id", ""))
		_check_replaceable_asset("items %s" % item_id, item_data, failures)
		for key in ["icon_key", "environment_prop", "surface"]:
			if str(item_data.get(key, "")).strip_edges().is_empty():
				failures.append("items %s is missing %s for room/inventory presentation." % [item_id, key])
		var icon_key := str(item_data.get("icon_key", "")).strip_edges()
		if not icon_key.is_empty():
			if item_icon_keys.has(icon_key):
				failures.append("items %s and %s share icon_key %s." % [str(item_icon_keys.get(icon_key, "")), item_id, icon_key])
			else:
				item_icon_keys[icon_key] = item_id
		var asset_path := str(item_data.get("asset_path", "")).strip_edges()
		if not asset_path.is_empty():
			if item_asset_paths.has(asset_path):
				failures.append("items %s and %s share asset_path %s." % [str(item_asset_paths.get(asset_path, "")), item_id, asset_path])
			else:
				item_asset_paths[asset_path] = item_id
	for event in library.events:
		if typeof(event) != TYPE_DICTIONARY:
			continue
		var event_data: Dictionary = event
		var event_id := str(event_data.get("id", ""))
		_check_replaceable_asset("events %s" % event_id, event_data, failures)
		var interaction_mode := str(event_data.get("interaction_mode", "")).strip_edges()
		var icon_key := str(event_data.get("icon_key", "")).strip_edges()
		var environment_prop := str(event_data.get("environment_prop", "")).strip_edges()
		if interaction_mode == "triggered":
			if not icon_key.is_empty() or not environment_prop.is_empty():
				failures.append("events %s is triggered and should not define room presentation keys." % event_id)
		else:
			if icon_key.is_empty() or icon_key == "event":
				failures.append("events %s must define a non-generic icon_key." % event_id)
			for key in ["environment_prop", "start_summary"]:
				if str(event_data.get(key, "")).strip_edges().is_empty():
					failures.append("events %s is missing %s for room interaction presentation." % [event_id, key])


func _check_blackjack_control_hit_regions(harness: SurfaceHarness, failures: Array) -> void:
	var control_actions := [
		"blackjack_hit",
		"blackjack_stand",
		"blackjack_double",
		"blackjack_split",
		"blackjack_peek",
		"blackjack_surrender",
	]
	var regions: Array = []
	for region_value in harness.hit_regions:
		if typeof(region_value) != TYPE_DICTIONARY:
			continue
		var region: Dictionary = region_value
		var action := str(region.get("action", ""))
		if not control_actions.has(action):
			continue
		var rect: Rect2 = region.get("rect", Rect2())
		regions.append({"action": action, "rect": rect})
		if not bool(region.get("exact", false)):
			failures.append("Blackjack control button %s uses an expanded hitbox instead of the visible button rect." % action)
		if rect.size.x <= 0.0 or rect.size.y <= 0.0:
			failures.append("Blackjack control button %s registered an empty hitbox." % action)
	for action_value in control_actions:
		var expected_action := str(action_value)
		var found := false
		for region_value in regions:
			var region: Dictionary = region_value
			if str(region.get("action", "")) == expected_action:
				found = true
				break
		if not found:
			failures.append("Blackjack control button %s did not register a surface hit region." % expected_action)
	for i in range(regions.size()):
		var first: Dictionary = regions[i]
		var first_rect: Rect2 = first.get("rect", Rect2())
		for j in range(i + 1, regions.size()):
			var second: Dictionary = regions[j]
			var second_rect: Rect2 = second.get("rect", Rect2())
			if first_rect.intersects(second_rect):
				failures.append("Blackjack control hitboxes overlap: %s and %s." % [str(first.get("action", "")), str(second.get("action", ""))])


func _check_blackjack_item_content(library: ContentLibrary, failures: Array) -> void:
	var required_effects := {
		"marked_cards": ["blackjack_peek_heat_delta", "blackjack_dealer_catch_chance", "blackjack_peek_loss_reduction"],
		"card_counters_notes": ["blackjack_count_tolerance", "blackjack_count_window_msec", "blackjack_count_heat_delta", "blackjack_count_cover", "blackjack_count_edge_bonus"],
		"side_bet_chart": ["blackjack_side_bet_bonus", "blackjack_side_bet_loss_reduction", "blackjack_side_bet_flat_bonus"],
		"basic_strategy_card": ["blackjack_basic_strategy_card"],
		"lucky_ladies_compact": ["blackjack_lucky_ladies_stake_multiplier", "blackjack_lucky_ladies_payout_multiplier"],
		"coolers_cufflinks": ["blackjack_failed_peek_heat_absorb"],
		"broken_cufflinks": ["blackjack_peek_window_percent", "repair_cost", "repair_to_item"],
		"high_roller_watch": ["blackjack_table_limit_multiplier", "blackjack_table_minimum_to_previous_max"],
	}
	var reachable_blackjack_items: Array = []
	for item_id in required_effects.keys():
		var item := library.item(str(item_id))
		if item.is_empty():
			failures.append("Blackjack support item is missing from item content: %s." % item_id)
			continue
		var effect: Dictionary = item.get("effect", {}) if typeof(item.get("effect", {})) == TYPE_DICTIONARY else {}
		for effect_key in required_effects[item_id]:
			if not effect.has(str(effect_key)):
				failures.append("Blackjack support item %s is missing effect key %s." % [item_id, effect_key])
	for archetype_value in library.environment_archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		if _item_count_ceiling(archetype.get("item_count", 0)) <= 0:
			continue
		var pool := library.shop_item_pool_for_challenge(archetype.get("item_pool", []), {})
		for item_id in required_effects.keys():
			if pool.has(str(item_id)) and not reachable_blackjack_items.has(str(item_id)):
				reachable_blackjack_items.append(str(item_id))
	for item_id in required_effects.keys():
		var item := library.item(str(item_id))
		if bool(item.get("sellable", true)) and not reachable_blackjack_items.has(str(item_id)):
			failures.append("Blackjack support item is not reachable from any generated item pool: %s." % item_id)
	var repair_run_state: RunState = RunStateScript.new()
	repair_run_state.start_new("BLACKJACK-CUFFLINK-REPAIR")
	repair_run_state.change_bankroll(100)
	repair_run_state.set_environment({
		"id": "blackjack_repair_shop",
		"archetype_id": "corner_store",
		"kind": "shop",
		"display_name": "Repair Shop",
		"item_offers": [],
	})
	repair_run_state.add_item("broken_cufflinks")
	var repair_service: RunActionService = RunActionServiceScript.new()
	repair_service.setup(library, repair_run_state)
	var repair_result: Dictionary = repair_service.repair_inventory_item("broken_cufflinks")
	if not bool(repair_result.get("ok", false)):
		failures.append("Shopkeeper could not repair Broken Cufflinks.")
	else:
		if repair_run_state.inventory.has("broken_cufflinks") or not repair_run_state.inventory.has("coolers_cufflinks"):
			failures.append("Broken Cufflinks repair did not swap inventory items.")
		if repair_run_state.bankroll != 150:
			failures.append("Broken Cufflinks repair did not cost exactly $50.")


func _check_replaceable_asset(label: String, data: Dictionary, failures: Array) -> void:
	var asset_path := str(data.get("asset_path", "")).strip_edges()
	if asset_path.is_empty():
		failures.append("%s is missing asset_path." % label)
	elif not asset_path.begins_with("res://assets/art/"):
		failures.append("%s asset_path must stay under res://assets/art/." % label)
	elif not FileAccess.file_exists(asset_path):
		failures.append("%s references missing asset_path: %s." % [label, asset_path])


# Checks generated events against allowed scopes.
func _check_events(event_ids: Array, library: ContentLibrary, scopes: Array, failures: Array) -> void:
	if event_ids.size() < 2 or event_ids.size() > 4:
		failures.append("Environment should generate 2-4 events.")
	for event_id in event_ids:
		var event := library.event(event_id)
		if event.is_empty():
			failures.append("Generated unknown event: %s." % event_id)
			continue
		var event_scopes: Array = event.get("scopes", [])
		var matches := event_scopes.has("any")
		for scope in scopes:
			matches = matches or event_scopes.has(scope)
		if not matches:
			failures.append("Generated event does not match environment scope: %s." % event_id)


# Creates in-memory content for contract checks.
func _check_card_shoe_core_primitives(failures: Array) -> void:
	var shoe: Array = [
		{"rank": 14, "suit": 0, "deck": 0},
		"bad-card",
		{"rank": 10, "suit": 1, "deck": 0},
		{"rank": 5, "suit": 2, "deck": 0},
		{"rank": 7, "suit": 3, "deck": 1},
	]
	var original_json := JSON.stringify(shoe)
	var draw: Dictionary = CardShoeScript.draw_cards(shoe, 2)
	var drawn_cards: Array = draw.get("cards", [])
	var remaining_shoe: Array = draw.get("shoe", [])
	if JSON.stringify(shoe) != original_json:
		failures.append("CardShoe.draw_cards mutated the source shoe.")
	if drawn_cards.size() != 2 or remaining_shoe.size() != 2 or int(draw.get("remaining", -1)) != 2:
		failures.append("CardShoe.draw_cards did not preserve draw/remaining counts while filtering malformed cards.")
	else:
		var first_drawn: Dictionary = drawn_cards[0]
		var second_drawn: Dictionary = drawn_cards[1]
		var first_remaining: Dictionary = remaining_shoe[0]
		if int(first_drawn.get("rank", 0)) != 14 or int(second_drawn.get("rank", 0)) != 10 or int(first_remaining.get("rank", 0)) != 5:
			failures.append("CardShoe.draw_cards changed deterministic card order.")
	var composition: Dictionary = CardShoeScript.remaining_composition(shoe)
	if JSON.stringify(shoe) != original_json:
		failures.append("CardShoe.remaining_composition mutated the source shoe.")
	if CardShoeScript.remaining_count(shoe) != 4 or int(composition.get("total", 0)) != 4:
		failures.append("CardShoe remaining helpers did not ignore malformed card entries.")
	if int(composition.get("high_cards", 0)) != 2 or int(composition.get("low_cards", 0)) != 1 or int(composition.get("neutral_cards", 0)) != 1:
		failures.append("CardShoe.remaining_composition changed hi-lo bucket counts.")


# Checks seed and generation determinism.
func _check_rng(library: ContentLibrary, failures: Array) -> void:
	var rng_a := RngStream.new()
	rng_a.configure(12345)
	var rng_b := RngStream.new()
	rng_b.configure(12345)
	var rng_a_values := [rng_a.randi_range(0, 10), rng_a.randi_range(0, 10), rng_a.randi_range(0, 10)]
	var rng_b_values := [rng_b.randi_range(0, 10), rng_b.randi_range(0, 10), rng_b.randi_range(0, 10)]
	if JSON.stringify(rng_a_values) != JSON.stringify(rng_b_values):
		failures.append("RngStream is not deterministic.")
	var rng_snapshot := rng_a.snapshot()
	var rng_restored := RngStream.new()
	rng_restored.restore(rng_snapshot)
	if rng_a.randi_range(0, 100) != rng_restored.randi_range(0, 100):
		failures.append("RngStream snapshot/restore did not preserve stream state.")
	_check_keyed_rng_streams(failures)

	var custom_challenge := RunState.custom_challenge("foundation_smoke", "FOUNDATION-TEST-SEED", {"stake_pressure": "test"})
	var run_a: RunState = RunStateScript.new()
	run_a.start_new("FOUNDATION-TEST-SEED", custom_challenge)
	var run_b: RunState = RunStateScript.new()
	run_b.start_new("FOUNDATION-TEST-SEED", custom_challenge)
	var generator_a: RunGenerator = RunGeneratorScript.new(library)
	var generator_b: RunGenerator = RunGeneratorScript.new(library)
	var environment_a := _harness_arrive(generator_a, run_a, failures, "RNG twin A initial arrival")
	var environment_b := _harness_arrive(generator_b, run_b, failures, "RNG twin B initial arrival")

	if JSON.stringify(environment_a.to_dict()) != JSON.stringify(environment_b.to_dict()):
		failures.append("Same fixture seed did not generate the same fixture environment.")
	if run_a.rng_state != run_b.rng_state:
		failures.append("Same fixture seed did not leave the same RunState RNG state after generation.")
	_check_same_seed_game_result(library, custom_challenge, failures)

	var different_challenge_run: RunState = RunStateScript.new()
	different_challenge_run.start_new("FOUNDATION-TEST-SEED", RunState.custom_challenge("foundation_smoke", "FOUNDATION-TEST-SEED", {"stake_pressure": "different"}))
	if different_challenge_run.seed_value == run_a.seed_value:
		failures.append("Challenge modifiers did not affect deterministic seed value.")
	var different_challenge_rng := different_challenge_run.create_rng()
	var baseline_challenge_rng := RunStateScript.new()
	baseline_challenge_rng.start_new("FOUNDATION-TEST-SEED", custom_challenge)
	if JSON.stringify(different_challenge_rng.snapshot()) == JSON.stringify(baseline_challenge_rng.create_rng().snapshot()):
		failures.append("Different challenge modifiers did not change the deterministic stream snapshot.")
	if different_challenge_rng.randi_range(1, 1000000) == baseline_challenge_rng.create_rng().randi_range(1, 1000000):
		failures.append("Different challenge modifiers did not change the deterministic stream.")


# Checks named RNG streams are stable and distinct.
func _check_keyed_rng_streams(failures: Array) -> void:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("STREAM-SEED", RunState.custom_challenge("stream_keys", "STREAM-SEED", {"fixture": true}))
	var state_before := run_state.rng_state
	var environment_stream_a := run_state.create_rng("environment")
	var environment_stream_b := run_state.create_rng("environment")
	var game_stream := run_state.create_rng("game")
	var environment_value_a := environment_stream_a.randi_range(1, 1000000)
	var environment_value_b := environment_stream_b.randi_range(1, 1000000)
	var game_value := game_stream.randi_range(1, 1000000)
	if environment_stream_a.seed_value != environment_stream_b.seed_value:
		failures.append("Same RunState stream key did not derive the same stream seed.")
	if environment_stream_a.seed_value == game_stream.seed_value:
		failures.append("Different RunState stream keys did not derive distinct stream seeds.")
	if environment_value_a != environment_value_b:
		failures.append("Same RunState stream key did not produce the same deterministic stream.")
	if environment_value_a == game_value:
		failures.append("Different RunState stream keys did not produce distinct deterministic streams.")
	if run_state.rng_state != state_before:
		failures.append("RunState.create_rng with a stream key mutated stored RNG state.")


# Checks deterministic game resolution through the foundation RNG path.
func _check_same_seed_game_result(library: ContentLibrary, challenge: Dictionary, failures: Array) -> void:
	var run_a: RunState = RunStateScript.new()
	run_a.start_new("FOUNDATION-TEST-SEED", challenge)
	var run_b: RunState = RunStateScript.new()
	run_b.start_new("FOUNDATION-TEST-SEED", challenge)
	var generator_a: RunGenerator = RunGeneratorScript.new(library)
	var generator_b: RunGenerator = RunGeneratorScript.new(library)
	var environment_a := _harness_arrive(generator_a, run_a, failures, "game-result twin A initial arrival")
	var environment_b := _harness_arrive(generator_b, run_b, failures, "game-result twin B initial arrival")
	var game_a := GameModule.new()
	game_a.setup(library.game("fixture_game"))
	var game_b := GameModule.new()
	game_b.setup(library.game("fixture_game"))
	var result_a := game_a.resolve("legal_fixture", 1, run_a, environment_a.to_dict(), run_a.create_rng())
	var result_b := game_b.resolve("legal_fixture", 1, run_b, environment_b.to_dict(), run_b.create_rng())
	if JSON.stringify(result_a) != JSON.stringify(result_b):
		failures.append("Same seed and challenge did not produce the same foundation game result.")
	if JSON.stringify(_deterministic_run_projection(run_a)) != JSON.stringify(_deterministic_run_projection(run_b)):
		failures.append("Same foundation game result did not leave matching RunState snapshots.")


# Checks that RunState owns foundation run state and round-trips every required domain.
func _check_run_state_source_of_truth(library: ContentLibrary, failures: Array) -> void:
	var challenge := RunState.custom_challenge("run_state_round_trip", "RUNSTATE-SEED", {"route": "fixture", "pressure": "low"})
	var run_a: RunState = RunStateScript.new()
	run_a.start_new("IGNORED-SEED", challenge)
	var run_b: RunState = RunStateScript.new()
	run_b.start_new("IGNORED-SEED", challenge)
	if JSON.stringify(_deterministic_run_projection(run_a)) != JSON.stringify(_deterministic_run_projection(run_b)):
		failures.append("RunState.start_new is not deterministic for the same seed and challenge.")

	var rng_a := run_a.create_rng()
	var rng_b := run_b.create_rng()
	if rng_a.randi_range(1, 1000) != rng_b.randi_range(1, 1000):
		failures.append("RunState did not create deterministic RNG streams from initial state.")

	var generator: RunGenerator = RunGeneratorScript.new(library)
	var environment := _harness_arrive(generator, run_a, failures, "RunState source-of-truth initial arrival")
	var history_probe: RunState = RunStateScript.new()
	history_probe.start_new("HISTORY-COMPACTION-SEED", challenge)
	var environment_snapshot: Dictionary = environment.to_dict()
	var previous_environment: Dictionary = environment_snapshot.duplicate(true)
	previous_environment["runtime_state"] = {"large_transient_machine_state": [1, 2, 3, 4]}
	history_probe.current_environment = previous_environment
	history_probe.set_environment(environment_snapshot)
	var compact_history: Dictionary = history_probe.environment_history[0] if not history_probe.environment_history.is_empty() else {}
	if compact_history.has("runtime_state") or not compact_history.has("id") or not compact_history.has("archetype_id"):
		failures.append("RunState environment history retained full runtime state instead of a compact visited-location record.")
	run_a.change_bankroll(-17)
	run_a.add_item("fixture_item")
	run_a.set_active_item("fixture_item")
	run_a.add_debt({
		"id": "fixture_debt",
		"lender_id": "fixture_lender",
		"balance": 30,
		"status": "active",
	})
	run_a.add_suspicion("fixture_behavior", 4, "behavior", false, {"environment_id": environment.id})
	run_a.narrative_flags["fixture_flag"] = true
	run_a.set_story_flag("fixture_story_flag", true)
	run_a.log_story({"type": "round_trip", "id": "fixture_story", "environment_id": environment.id})
	run_a.record_score_spending(13, "round_trip_fixture")
	run_a.advance_environment_turns(2)
	run_a.resolve_event("fixture_event")
	run_a.set_next_archetypes(["fixture_environment"])
	var advanced_rng := run_a.create_rng()
	advanced_rng.randi_range(1, 1000)
	run_a.save_rng(advanced_rng)

	var snapshot := run_a.to_dict()
	_check_run_state_snapshot_keys(snapshot, failures)
	var restored: RunState = RunStateScript.new()
	restored.from_dict(snapshot)
	_assert_equal(run_a.seed_text, restored.seed_text, "RunState seed_text did not survive round-trip.", failures)
	_assert_equal(run_a.seed_value, restored.seed_value, "RunState seed_value did not survive round-trip.", failures)
	_assert_equal(run_a.rng_seed, restored.rng_seed, "RunState rng_seed did not survive round-trip.", failures)
	_assert_equal(run_a.rng_state, restored.rng_state, "RunState rng_state did not survive round-trip.", failures)
	_assert_json_equal(run_a.challenge_config, restored.challenge_config, "RunState challenge config did not survive round-trip.", failures)
	_assert_equal(run_a.bankroll, restored.bankroll, "RunState bankroll did not survive round-trip.", failures)
	_assert_equal(run_a.economic_state, restored.economic_state, "RunState economic state did not survive round-trip.", failures)
	_assert_json_equal(run_a.inventory, restored.inventory, "RunState inventory did not survive round-trip.", failures)
	_assert_equal(run_a.active_item_id, restored.active_item_id, "RunState active item did not survive round-trip.", failures)
	_assert_json_equal(run_a.debt, restored.debt, "RunState debt did not survive round-trip.", failures)
	_assert_json_equal(run_a.suspicion, restored.suspicion, "RunState suspicion did not survive round-trip.", failures)
	_assert_json_equal(run_a.current_environment, restored.current_environment, "RunState current environment did not survive round-trip.", failures)
	_assert_json_equal(run_a.grand_casino_staffing, restored.grand_casino_staffing, "RunState Grand Casino staffing did not survive round-trip.", failures)
	_assert_json_equal(run_a.environment_history, restored.environment_history, "RunState environment history did not survive round-trip.", failures)
	_assert_json_equal(run_a.unlocked_travel, restored.unlocked_travel, "RunState travel hooks did not survive round-trip.", failures)
	_assert_json_equal(run_a.narrative_flags, restored.narrative_flags, "RunState narrative flags did not survive round-trip.", failures)
	_assert_json_equal(run_a.story_flags, restored.story_flags, "RunState story flags did not survive round-trip.", failures)
	_assert_json_equal(run_a.story_log, restored.story_log, "RunState story log did not survive round-trip.", failures)
	_assert_equal(run_a.run_status, restored.run_status, "RunState run status did not survive round-trip.", failures)
	_assert_equal(run_a.run_spending_score, restored.run_spending_score, "RunState score spending did not survive round-trip.", failures)

	var original_rng := run_a.create_rng()
	var restored_rng := restored.create_rng()
	if original_rng.randi_range(1, 1000) != restored_rng.randi_range(1, 1000):
		failures.append("RunState restored RNG state did not continue the same stream.")

	snapshot["inventory"].append("mutated_item")
	snapshot["debt"][0]["balance"] = 999
	snapshot["suspicion"]["cues"][0]["context"]["environment_id"] = "mutated_environment"
	snapshot["current_environment"]["id"] = "mutated_environment"
	snapshot["narrative_flags"]["fixture_flag"] = false
	snapshot["story_flags"]["fixture_story_flag"] = false
	snapshot["story_log"][0]["id"] = "mutated_story"
	if restored.inventory.has("mutated_item"):
		failures.append("RunState.from_dict retained mutable inventory source data.")
	if int(restored.debt[0].get("balance", 0)) == 999:
		failures.append("RunState.from_dict retained mutable debt source data.")
	if str(restored.suspicion.get("cues", [])[0].get("context", {}).get("environment_id", "")) == "mutated_environment":
		failures.append("RunState.from_dict retained mutable suspicion source data.")
	if restored.current_environment.get("id", "") == "mutated_environment":
		failures.append("RunState.from_dict retained mutable environment source data.")
	if not bool(restored.narrative_flags.get("fixture_flag", false)):
		failures.append("RunState.from_dict retained mutable flag source data.")
	if not bool(restored.story_flags.get("fixture_story_flag", false)):
		failures.append("RunState.from_dict retained mutable story flag source data.")
	if str(restored.story_log[0].get("id", "")) == "mutated_story":
		failures.append("RunState.from_dict retained mutable story source data.")


func _check_save_load_interrupt_fuzz_foundation(library: ContentLibrary, failures: Array) -> void:
	_check_save_load_seed_sweep(library, failures)
	_check_save_load_targeted_midstates(library, failures)
	_check_save_load_030_compat_fixture(library, failures)
	_check_save_load_033_compat_fixture(library, failures)


func _check_save_load_seed_sweep(library: ContentLibrary, failures: Array) -> void:
	for seed_index in range(SAVE_LOAD_FUZZ_SEEDS):
		var seed_text := "SB3-FUZZ-%02d" % seed_index
		var challenge := RunState.custom_challenge("sb3_save_fuzz", seed_text, {
			"starting_bankroll": 4500,
			"baseline_luck_delta": 1 if seed_index % 2 == 0 else 0,
			"starting_heat": 4 if seed_index % 3 == 0 else 0,
			"hidden_seed": true,
		})
		var run_state: RunState = RunStateScript.new()
		run_state.start_new(seed_text, challenge)
		var generator: RunGenerator = RunGeneratorScript.new(library)
		_harness_arrive(generator, run_state, failures, "%s initial arrival" % seed_text)
		for action_index in range(SAVE_LOAD_FUZZ_ACTIONS_PER_SEED):
			var label := "%s/action_%02d" % [seed_text, action_index]
			var advanced := _save_load_fuzz_drive_action(library, generator, run_state, action_index, label, failures)
			if not advanced and not run_state.is_terminal():
				failures.append("SB.3 save/load fuzz could not find a legal continuation at %s." % label)
				break
			var restored := _save_load_checkpoint(library, run_state, label, true, failures)
			if restored != null:
				run_state = restored
			if run_state.is_terminal():
				break


func _save_load_fuzz_drive_action(library: ContentLibrary, generator: RunGenerator, run_state: RunState, action_index: int, label: String, failures: Array) -> bool:
	if run_state == null or run_state.is_terminal():
		return false
	if run_state.current_environment.is_empty():
		_harness_arrive(generator, run_state, failures, "%s replacement initial arrival" % label)
	if _save_load_fuzz_resolve_triggered_event(library, run_state, label, failures):
		return true
	if action_index % 7 == 3 and _save_load_fuzz_use_service_item_or_lender(library, run_state):
		return true
	if action_index % 5 == 4 and _save_load_fuzz_travel(generator, run_state, failures):
		return true
	if _save_load_fuzz_play_game(library, run_state, action_index, label, failures):
		return true
	if _save_load_fuzz_use_service_item_or_lender(library, run_state):
		return true
	return _save_load_fuzz_travel(generator, run_state, failures)


func _save_load_fuzz_resolve_triggered_event(library: ContentLibrary, run_state: RunState, label: String, failures: Array) -> bool:
	var entry := JsonCoerceScript._copy_dict(run_state.active_triggered_event)
	if entry.is_empty():
		entry = run_state.next_pending_triggered_event()
		if entry.is_empty():
			return false
		entry = run_state.begin_triggered_event_resolution(entry)
	var event_id := str(entry.get("event_id", "")).strip_edges()
	if event_id.is_empty():
		run_state.complete_triggered_event_resolution()
		return true
	var definition := library.event(event_id)
	if definition.is_empty():
		failures.append("SB.3 save/load fuzz found unknown triggered event %s at %s." % [event_id, label])
		run_state.complete_triggered_event_resolution(event_id)
		return true
	var event := EventModule.new()
	event.setup(definition, library)
	var choices := event.choices(run_state, run_state.current_environment)
	if choices.is_empty():
		run_state.complete_triggered_event_resolution(event_id)
		return true
	var choice: Dictionary = choices[0] if typeof(choices[0]) == TYPE_DICTIONARY else {}
	var choice_id := str(choice.get("id", "")).strip_edges()
	if choice_id.is_empty():
		run_state.complete_triggered_event_resolution(event_id)
		return true
	event.resolve(run_state, run_state.current_environment, choice_id)
	run_state.complete_triggered_event_resolution(event_id)
	return true


func _save_load_fuzz_use_service_item_or_lender(library: ContentLibrary, run_state: RunState) -> bool:
	var resolver: RunActionService = RunActionServiceScript.new()
	resolver.setup(library, run_state)
	for service_value in resolver.service_hook_view_list():
		if typeof(service_value) != TYPE_DICTIONARY:
			continue
		var service: Dictionary = service_value
		if bool(service.get("enabled", false)) and bool(service.get("mutation_supported", false)):
			var service_result := resolver.use_hook("service", str(service.get("id", "")))
			return bool(service_result.get("ok", false))
	for lender_value in resolver.lender_hook_view_list():
		if typeof(lender_value) != TYPE_DICTIONARY:
			continue
		var lender: Dictionary = lender_value
		if bool(lender.get("enabled", false)) and bool(lender.get("mutation_supported", false)):
			var lender_result := resolver.use_hook("lender", str(lender.get("id", "")))
			return bool(lender_result.get("ok", false))
	for offer_value in resolver.item_offer_view_list():
		if typeof(offer_value) != TYPE_DICTIONARY:
			continue
		var offer: Dictionary = offer_value
		if bool(offer.get("affordable", false)):
			var item_result := resolver.buy_item_offer(str(offer.get("id", "")))
			return bool(item_result.get("ok", false))
	return false


func _save_load_fuzz_travel(generator: RunGenerator, run_state: RunState, failures: Array) -> bool:
	if run_state == null or generator == null or not run_state.has_world_map():
		return false
	var current_node_id := run_state.current_world_node_id()
	for target_value in WorldMapScript.travel_target_ids(run_state.world_map, current_node_id):
		var target_id := str(target_value)
		if target_id.is_empty() or target_id == current_node_id:
			continue
		var route := generator.world_route_for_target(run_state, target_id)
		if route.is_empty():
			continue
		var status := run_state.travel_route_status(route)
		if not bool(status.get("available", false)):
			continue
		# Production travel only offers destinations that are open on arrival.
		if not generator._world_target_is_available(run_state, run_state.world_map, current_node_id, target_id):
			continue
		var cost := maxi(0, int(status.get("cost", route.get("cost", 0))))
		var travel_heat := run_state.begin_travel_suspicion_decay(route, target_id)
		var arrived := HarnessProductionFidelityScript.travel_and_finalize(generator, run_state, target_id, false, generator.library, failures, "save/load fuzz arrival %s" % target_id)
		if not bool(arrived.get("ok", false)):
			return false
		run_state.finish_travel_suspicion_decay(travel_heat)
		if cost > 0:
			GameModule.apply_result(run_state, _world_map_travel_charge_result(target_id, cost))
		return true
	return false


func _save_load_fuzz_play_game(library: ContentLibrary, run_state: RunState, action_index: int, _label: String, failures: Array) -> bool:
	var game_ids := JsonCoerceScript._string_array(run_state.current_environment.get("game_ids", []))
	if game_ids.is_empty():
		return false
	var start_index := posmod(action_index, game_ids.size())
	for offset in range(game_ids.size()):
		var game_id := str(game_ids[posmod(start_index + offset, game_ids.size())])
		var game: GameModule = _load_surface_contract_game(library, game_id, failures)
		if game == null:
			continue
		if game_id == "slot" and _save_load_fuzz_play_slot_bonus(game, run_state, action_index):
			return true
		var actions: Dictionary = game.actions(run_state, run_state.current_environment)
		var legal_actions: Array = actions.get("legal_actions", []) if typeof(actions.get("legal_actions", [])) == TYPE_ARRAY else []
		var combined_actions: Array = []
		combined_actions.append_array(legal_actions)
		var cheat_actions: Array = actions.get("cheat_actions", []) if typeof(actions.get("cheat_actions", [])) == TYPE_ARRAY else []
		combined_actions.append_array(cheat_actions)
		var stake_floor := maxi(1, int(actions.get("stake_floor", 1)))
		var stake_ceiling := maxi(stake_floor, int(actions.get("stake_ceiling", stake_floor)))
		var stake := clampi(10, stake_floor, stake_ceiling)
		for action_value in combined_actions:
			if typeof(action_value) != TYPE_DICTIONARY:
				continue
			var action: Dictionary = action_value
			if not bool(action.get("enabled", true)):
				continue
			var action_id := str(action.get("id", "")).strip_edges()
			if action_id.is_empty():
				continue
			var rng := run_state.create_rng("sb3_fuzz_%s_%s_%02d" % [game_id, action_id, action_index])
			var result: Dictionary = game.resolve_with_context(action_id, stake, run_state, run_state.current_environment, rng, {})
			if bool(result.get("ok", false)):
				GameModule.apply_result(run_state, result, rng)
				return true
			# Sealed games such as Bar Dice reject the legacy observer path and
			# settle only through the production Foundation host.
			if bool(result.get("sealed_action_authoritative", false)) \
					and bool(SaveFuzzTableGameAuthorityDriverScript.resolve(game, action_id, stake, run_state, run_state.current_environment).get("ok", false)):
				return true
	return false


func _save_load_fuzz_play_slot_bonus(game: GameModule, run_state: RunState, action_index: int) -> bool:
	var machine: Dictionary = SlotMachineStateScript.read_machine(run_state.current_environment, "slot")
	if machine.is_empty() or not SlotMachineStateScript.active_bonus_incomplete(machine):
		return false
	var active: Dictionary = machine.get("active_bonus", {}) if typeof(machine.get("active_bonus", {})) == TYPE_DICTIONARY else {}
	var family := str(active.get("family", machine.get("type_id", "")))
	var mode := str(active.get("mode", ""))
	var candidates := ["slot_bonus_launch"]
	if family == "pinball":
		match action_index % 3:
			1:
				candidates = ["slot_bonus_left", "slot_bonus_launch"]
			2:
				candidates = ["slot_bonus_right", "slot_bonus_launch"]
			_:
				candidates = ["slot_bonus_launch"]
		candidates.append("slot_bonus_watchdog")
	elif family == "buffalo" and mode == "wheel":
		candidates = ["slot_bonus_right", "slot_bonus_launch"]
	var ui_state := {
		"surface_time_msec": 4000 + action_index * 500,
		"drunk_scaled_surface_time_msec": 4000 + action_index * 500,
	}
	if family == "pinball":
		ui_state = {}
	for action_id in candidates:
		var rng := run_state.create_rng("sb3_fuzz_slot_bonus_%s_%02d" % [action_id, action_index])
		var result: Dictionary = game.resolve_with_context(str(action_id), 0, run_state, run_state.current_environment, rng, ui_state)
		if bool(result.get("ok", false)):
			GameModule.apply_result(run_state, result, rng)
			return true
	return false


func _save_load_checkpoint(library: ContentLibrary, run_state: RunState, label: String, assert_continuation: bool, failures: Array) -> RunState:
	var before_signature := _save_load_action_signature(library, run_state, failures)
	var before_snapshot := _save_load_canonical_run_snapshot(run_state.to_dict())
	var before_json := JSON.stringify(before_snapshot)
	var parsed: Variant = JSON.parse_string(before_json)
	if typeof(parsed) != TYPE_DICTIONARY:
		failures.append("SB.3 %s RunState snapshot did not JSON-parse." % label)
		return null
	var restored: RunState = RunStateScript.new()
	restored.from_dict(parsed as Dictionary)
	var after_snapshot := _save_load_canonical_run_snapshot(restored.to_dict())
	var after_json := JSON.stringify(after_snapshot)
	if after_json != before_json:
		failures.append("SB.3 %s RunState to_dict -> from_dict -> to_dict was not byte-identical at %s." % [label, _save_load_first_mismatch(before_snapshot, after_snapshot)])
	# Load the second clone from persisted JSON text exactly like the first and
	# like a real save. The canonical snapshot dictionary stores integral floats
	# as ints, which no save file can contain.
	var second: RunState = RunStateScript.new()
	second.from_dict(JSON.parse_string(after_json) as Dictionary)
	if JSON.stringify(_save_load_canonical_run_snapshot(second.to_dict())) != after_json:
		failures.append("SB.3 %s RunState normalization was not idempotent on the second load." % label)
	var after_signature := _save_load_action_signature(library, restored, failures)
	if JSON.stringify(before_signature) != JSON.stringify(after_signature):
		failures.append("SB.3 %s legal action signature changed after save/load." % label)
	if assert_continuation and not restored.is_terminal():
		# `second` is already the exact, independently loaded continuation clone
		# proven above; a third serialization/load adds no new assertion.
		var continuation: RunState = second
		var continuation_generator: RunGenerator = RunGeneratorScript.new(library)
		for step in range(SAVE_LOAD_FUZZ_CONTINUATION_STEPS):
			if continuation.is_terminal():
				break
			if not _save_load_fuzz_drive_action(library, continuation_generator, continuation, step, "%s/continue_%02d" % [label, step], failures):
				failures.append("SB.3 %s restored clone could not continue for step %d." % [label, step])
				break
	return restored


func _save_load_canonical_run_snapshot(snapshot: Dictionary) -> Dictionary:
	var result: Dictionary = _save_load_canonical_value(snapshot) as Dictionary
	var pending_events: Array = result.get("pending_triggered_events", []) if typeof(result.get("pending_triggered_events", [])) == TYPE_ARRAY else []
	if not pending_events.is_empty():
		result["pending_triggered_events"] = _save_load_canonical_triggered_event_entries(pending_events)
	var active_event: Dictionary = result.get("active_triggered_event", {}) if typeof(result.get("active_triggered_event", {})) == TYPE_DICTIONARY else {}
	if not active_event.is_empty() and not active_event.has("active"):
		active_event["active"] = true
		result["active_triggered_event"] = active_event
	var environment: Dictionary = result.get("current_environment", {}) if typeof(result.get("current_environment", {})) == TYPE_DICTIONARY else {}
	var suspicion: Dictionary = result.get("suspicion", {}) if typeof(result.get("suspicion", {})) == TYPE_DICTIONARY else {}
	if environment.is_empty() or suspicion.is_empty():
		return result
	var location_id := _save_load_suspicion_location_id(environment)
	if location_id.is_empty():
		return result
	var local_levels: Dictionary = suspicion.get("local_levels", {}) if typeof(suspicion.get("local_levels", {})) == TYPE_DICTIONARY else {}
	if not local_levels.has(location_id):
		local_levels[location_id] = clampi(int(suspicion.get("level", 0)), 0, 100)
		suspicion["local_levels"] = local_levels
		result["suspicion"] = suspicion
	return result


func _save_load_canonical_triggered_event_entries(entries: Array) -> Array:
	var result: Array = []
	for entry_value in entries:
		if typeof(entry_value) != TYPE_DICTIONARY:
			continue
		var entry: Dictionary = entry_value
		if str(entry.get("event_id", entry.get("id", ""))).strip_edges().is_empty():
			continue
		if not entry.has("active"):
			entry["active"] = false
		result.append(entry)
	return result


func _save_load_suspicion_location_id(environment: Dictionary) -> String:
	var archetype_id := str(environment.get("archetype_id", "")).strip_edges()
	if not archetype_id.is_empty():
		return archetype_id
	var environment_id := str(environment.get("id", "")).strip_edges()
	var separator := environment_id.rfind("_")
	if separator > 0 and separator < environment_id.length() - 1:
		var suffix := environment_id.substr(separator + 1)
		if suffix.is_valid_int():
			return environment_id.substr(0, separator)
	return environment_id


func _save_load_canonical_value(value: Variant) -> Variant:
	match typeof(value):
		TYPE_DICTIONARY:
			var source: Dictionary = value
			var result: Dictionary = {}
			for key in source.keys():
				result[key] = _save_load_canonical_value(source[key])
			return result
		TYPE_ARRAY:
			var source_array: Array = value
			var result_array: Array = []
			for entry in source_array:
				result_array.append(_save_load_canonical_value(entry))
			return result_array
		TYPE_FLOAT:
			return _save_load_canonical_float(float(value))
		TYPE_VECTOR2:
			var point: Vector2 = value
			return {
				"x": _save_load_canonical_float(point.x),
				"y": _save_load_canonical_float(point.y),
			}
		TYPE_VECTOR2I:
			var point_i: Vector2i = value
			return {
				"x": point_i.x,
				"y": point_i.y,
			}
		TYPE_RECT2:
			var rect: Rect2 = value
			return {
				"x": _save_load_canonical_float(rect.position.x),
				"y": _save_load_canonical_float(rect.position.y),
				"w": _save_load_canonical_float(rect.size.x),
				"h": _save_load_canonical_float(rect.size.y),
			}
		TYPE_RECT2I:
			var rect_i: Rect2i = value
			return {
				"x": rect_i.position.x,
				"y": rect_i.position.y,
				"w": rect_i.size.x,
				"h": rect_i.size.y,
			}
		_:
			return value


func _save_load_canonical_float(value: float) -> Variant:
	var rounded_integer: float = round(value)
	if absf(value - rounded_integer) <= SAVE_LOAD_CANONICAL_INTEGER_EPSILON:
		return int(rounded_integer)
	return snappedf(value, SAVE_LOAD_CANONICAL_FLOAT_STEP)


func _save_load_action_signature(library: ContentLibrary, run_state: RunState, failures: Array) -> Dictionary:
	var signature := {
		"terminal": run_state.run_status if run_state != null else "missing",
		"environment_id": "",
		"world_node_id": "",
		"games": [],
		"travel_targets": [],
		"pending_triggered_count": 0,
		"active_triggered_event": "",
	}
	if run_state == null:
		return signature
	signature["environment_id"] = str(run_state.current_environment.get("id", ""))
	signature["world_node_id"] = run_state.current_world_node_id()
	signature["pending_triggered_count"] = run_state.pending_triggered_events.size()
	signature["active_triggered_event"] = str(run_state.active_triggered_event.get("event_id", ""))
	if run_state.has_world_map():
		signature["travel_targets"] = JsonCoerceScript._string_array(WorldMapScript.travel_target_ids(run_state.world_map, run_state.current_world_node_id()))
	var game_signatures: Array = []
	for game_id_value in JsonCoerceScript._string_array(run_state.current_environment.get("game_ids", [])):
		var game_id := str(game_id_value)
		var game: GameModule = _load_surface_contract_game(library, game_id, failures)
		if game == null:
			continue
		var actions: Dictionary = game.actions(run_state, run_state.current_environment)
		game_signatures.append({
			"id": game_id,
			"stake_floor": int(actions.get("stake_floor", 0)),
			"stake_ceiling": int(actions.get("stake_ceiling", 0)),
			"legal": _save_load_action_id_signature(actions.get("legal_actions", [])),
			"cheat": _save_load_action_id_signature(actions.get("cheat_actions", [])),
		})
	signature["games"] = game_signatures
	return signature


func _save_load_action_id_signature(actions_value: Variant) -> Array:
	var result: Array = []
	if typeof(actions_value) != TYPE_ARRAY:
		return result
	for action_value in actions_value:
		if typeof(action_value) != TYPE_DICTIONARY:
			continue
		var action: Dictionary = action_value
		result.append({
			"id": str(action.get("id", "")),
			"enabled": bool(action.get("enabled", true)),
			"kind": str(action.get("kind", action.get("action_kind", ""))),
			"cost": int(action.get("cost", action.get("stake", 0))),
		})
	return result


func _save_load_first_mismatch(expected: Variant, actual: Variant, path: String = "$") -> String:
	if typeof(expected) != typeof(actual):
		return "%s type %d != %d" % [path, typeof(expected), typeof(actual)]
	if typeof(expected) == TYPE_DICTIONARY:
		var expected_dict: Dictionary = expected
		var actual_dict: Dictionary = actual
		for key in expected_dict.keys():
			if not actual_dict.has(key):
				return "%s.%s missing" % [path, str(key)]
			var nested := _save_load_first_mismatch(expected_dict[key], actual_dict[key], "%s.%s" % [path, str(key)])
			if not nested.is_empty():
				return nested
		for key in actual_dict.keys():
			if not expected_dict.has(key):
				return "%s.%s added" % [path, str(key)]
		return ""
	if typeof(expected) == TYPE_ARRAY:
		var expected_array: Array = expected
		var actual_array: Array = actual
		if expected_array.size() != actual_array.size():
			return "%s size %d != %d" % [path, expected_array.size(), actual_array.size()]
		for index in range(expected_array.size()):
			var nested := _save_load_first_mismatch(expected_array[index], actual_array[index], "%s[%d]" % [path, index])
			if not nested.is_empty():
				return nested
		return ""
	if expected != actual:
		return "%s %s != %s" % [path, str(expected), str(actual)]
	return ""


func _check_save_load_targeted_midstates(library: ContentLibrary, failures: Array) -> void:
	var slot_game: GameModule = _slot_game(library, failures)
	if slot_game != null:
		_check_save_load_slot_midstates(library, slot_game, failures)
	_check_save_load_skill_challenge_midstates(library, failures)
	_check_save_load_world_event_lender_midstates(library, failures)


func _check_save_load_slot_midstates(library: ContentLibrary, slot_game: GameModule, failures: Array) -> void:
	var definition := library.game("slot")
	var pinball = SlotFamilyPinballScript.new()
	var pinball_run: RunState = _slot_run_state("SB3-PINBALL-LIVE", 100000)
	var pinball_environment: Dictionary = _slot_environment()
	var pinball_machine: Dictionary = _slot_machine(definition, pinball_run, "pinball", "classic_3_reel", "standard", "plain")
	pinball_machine["active_bonus"] = pinball.open_feature(pinball_machine, 10, pinball_run.create_rng("sb3_pinball_open"), definition)
	_slot_store_machine(pinball_run, pinball_environment, pinball_machine)
	var launch_rng := pinball_run.create_rng("sb3_pinball_launch")
	var launch_result: Dictionary = slot_game.resolve_with_context("slot_bonus_launch", 0, pinball_run, pinball_environment, launch_rng, {"surface_time_msec": 1000, "drunk_scaled_surface_time_msec": 1000})
	if bool(launch_result.get("ok", false)):
		GameModule.apply_result(pinball_run, launch_result, launch_rng)
	_save_load_checkpoint(library, _save_load_canonical_run(pinball_run), "target/pinball_live_balls", true, failures)

	var buffalo = SlotFamilyBuffaloScript.new()
	var buffalo_run: RunState = _slot_run_state("SB3-BUFFALO-HOLD", 100000)
	var buffalo_environment: Dictionary = _slot_environment()
	var buffalo_machine: Dictionary = _slot_machine(definition, buffalo_run, "buffalo", "video_feature", "standard", "plain")
	buffalo_machine["active_bonus"] = buffalo.open_feature(buffalo_machine, {"classification": "hold_and_spin"}, 10, buffalo_run.create_rng("sb3_buffalo_hold_open"), definition)
	_slot_store_machine(buffalo_run, buffalo_environment, buffalo_machine)
	_save_load_checkpoint(library, _save_load_canonical_run(buffalo_run), "target/buffalo_hold_and_spin", true, failures)

	var nudge_sample := _slot_spin_until_classification(definition, "pinball", "line_5x3", "near_miss", "SB3-NUDGE-PENDING", failures)
	if not nudge_sample.is_empty():
		var nudge_run: RunState = nudge_sample.get("run_state", null)
		var nudge_environment: Dictionary = _slot_environment()
		_slot_store_machine(nudge_run, nudge_environment, _slot_dict(nudge_sample.get("machine", {})))
		_save_load_checkpoint(library, _save_load_canonical_run(nudge_run), "target/nudge_offer_pending", true, failures)

	var autoplay_run: RunState = _slot_run_state("SB3-SLOT-AUTOPLAY", 100000)
	var autoplay_environment: Dictionary = _slot_environment()
	var autoplay_machine: Dictionary = _slot_machine(definition, autoplay_run, "pinball", "line_5x3", "standard", "plain")
	autoplay_machine["slot_autoplay_active"] = true
	autoplay_machine["slot_autoplay_next_msec"] = 1500
	_slot_store_machine(autoplay_run, autoplay_environment, autoplay_machine)
	_save_load_checkpoint(library, _save_load_canonical_run(autoplay_run), "target/slot_autoplay_active", true, failures)


func _check_save_load_skill_challenge_midstates(library: ContentLibrary, failures: Array) -> void:
	var blackjack: GameModule = _load_surface_contract_game(library, "blackjack", failures)
	if blackjack != null:
		var blackjack_run: RunState = _mutation_firewall_game_run_state(library, blackjack, "blackjack")
		var deal_command: Dictionary = blackjack.surface_action_command("blackjack_deal", 0, false, {"selected_stake": 5}, blackjack_run, blackjack_run.current_environment)
		var count_command: Dictionary = blackjack.surface_action_command("blackjack_count_toggle", 0, false, deal_command.get("ui_state", {}), blackjack_run, blackjack_run.current_environment)
		var count_ui: Dictionary = count_command.get("ui_state", {}) if typeof(count_command.get("ui_state", {})) == TYPE_DICTIONARY else {}
		if JsonCoerceScript._copy_dict(count_ui.get("count_challenge", {})).is_empty():
			failures.append("SB.3 blackjack count mid-state fixture did not start count_challenge.")
		_save_load_checkpoint(library, _save_load_canonical_run(blackjack_run), "target/blackjack_count_midstep", true, failures)

	var video_poker: GameModule = _load_surface_contract_game(library, "video_poker", failures)
	if video_poker != null:
		var poker_fixture := _video_poker_holdout_item_fixture(video_poker, "")
		var poker_run := poker_fixture.get("run_state", null) as RunState
		if poker_run == null or JsonCoerceScript._copy_dict(poker_fixture.get("challenge", {})).is_empty():
			failures.append("SB.3 video poker holdout mid-state fixture did not start holdout_challenge.")
		else:
			poker_run.current_environment["game_ids"] = ["video_poker"]
			_save_load_checkpoint(library, _save_load_canonical_run(poker_run), "target/video_poker_holdout_midstep", true, failures)

	var bar_dice: GameModule = _load_surface_contract_game(library, "bar_dice", failures)
	if bar_dice != null:
		var dice_fixture := _bar_dice_controlled_roll_item_fixture(bar_dice, "")
		var dice_run := dice_fixture.get("run_state", null) as RunState
		if dice_run == null or JsonCoerceScript._copy_dict(dice_fixture.get("challenge", {})).is_empty():
			failures.append("SB.3 bar dice controlled-roll mid-state fixture did not start controlled_roll.")
		else:
			_save_load_checkpoint(library, _save_load_canonical_run(dice_run), "target/bar_dice_controlled_roll_midstep", true, failures)

	var roulette: GameModule = _load_surface_contract_game(library, "roulette", failures)
	if roulette != null:
		var roulette_fixture := _roulette_past_post_item_fixture(roulette, library, "")
		var roulette_run := roulette_fixture.get("run_state", null) as RunState
		if roulette_run == null or JsonCoerceScript._copy_dict(roulette_fixture.get("challenge", {})).is_empty():
			failures.append("SB.3 roulette past-post mid-state fixture did not start past_post_challenge.")
		else:
			_save_load_checkpoint(library, _save_load_canonical_run(roulette_run), "target/roulette_past_post_midstep", true, failures)

	var baccarat: GameModule = _load_surface_contract_game(library, "baccarat", failures)
	if baccarat != null:
		var baccarat_fixture := _baccarat_edge_sort_item_fixture(baccarat, "")
		var baccarat_run := baccarat_fixture.get("run_state", null) as RunState
		if baccarat_run == null or JsonCoerceScript._copy_dict(baccarat_fixture.get("challenge", {})).is_empty():
			failures.append("SB.3 baccarat edge-sort mid-state fixture did not start edge_sort_challenge.")
		else:
			_save_load_checkpoint(library, _save_load_canonical_run(baccarat_run), "target/baccarat_edge_sort_midstep", true, failures)


func _check_save_load_world_event_lender_midstates(library: ContentLibrary, failures: Array) -> void:
	var world_run: RunState = RunStateScript.new()
	world_run.start_new("SB3-WORLD-MAP-OPEN", RunState.custom_challenge("sb3_world", "SB3-WORLD-MAP-OPEN", {"starting_bankroll": 3000}))
	var generator: RunGenerator = RunGeneratorScript.new(library)
	_harness_arrive(generator, world_run, failures, "world-map save fixture initial arrival")
	WorldMapScript.snapshot(world_run.world_map, world_run.current_world_node_id())
	_save_load_checkpoint(library, world_run, "target/world_map_open_snapshot", true, failures)

	var travel_lock_run: RunState = RunStateScript.new()
	travel_lock_run.start_new("SB3-TRAVEL-LOCK", RunState.custom_challenge("sb3_travel_lock", "SB3-TRAVEL-LOCK", {"starting_bankroll": 3000}))
	_harness_arrive(generator, travel_lock_run, failures, "travel-lock save fixture initial arrival")
	_harness_arrive(generator, travel_lock_run, failures, "travel-lock Gas Casino arrival", "gas_station_casino")
	travel_lock_run.current_environment["travel_locked_actions"] = 3
	travel_lock_run.current_environment["travel_lock_remaining"] = 2
	_save_load_checkpoint(library, travel_lock_run, "target/travel_lock_active", true, failures)

	var event_run: RunState = RunStateScript.new()
	event_run.start_new("SB3-TRIGGERED-EVENT")
	_harness_arrive(generator, event_run, failures, "triggered-event save fixture initial arrival")
	var event_id := _save_load_first_event_id(library)
	if event_id.is_empty() or not event_run.enqueue_triggered_event(event_id, "sb3_fixture", {"trigger": "save_load"}):
		failures.append("SB.3 triggered-event queue fixture could not enqueue an event.")
	else:
		_save_load_checkpoint(library, event_run, "target/triggered_event_pending", true, failures)
		event_run.begin_triggered_event_resolution(event_run.next_pending_triggered_event())
		_save_load_checkpoint(library, event_run, "target/triggered_event_active", true, failures)

	var lender_definition := _first_definition(library.lenders)
	if lender_definition.is_empty():
		failures.append("SB.3 lender mid-schedule fixture could not find lender content.")
	else:
		# Synthetic empty layouts are no longer legal environment state; open the
		# debt in the shared real slot-schema-v2 lender room.
		var lender_id := str(lender_definition.get("id", ""))
		var lender_fixture := _lender_fixture(library, "SB3-LENDER-MID", [lender_id], [], [])
		var lender_run: RunState = lender_fixture.get("run_state", null)
		var resolver: RunActionService = lender_fixture.get("resolver", null)
		var lender_result := resolver.use_hook("lender", lender_id)
		if not bool(lender_result.get("ok", false)) or lender_run.debt.is_empty():
			failures.append("SB.3 lender mid-schedule fixture could not open debt.")
		else:
			lender_run.advance_environment_turns(1)
			_save_load_checkpoint(library, lender_run, "target/lender_mid_schedule", true, failures)

	var challenge_run: RunState = RunStateScript.new()
	challenge_run.start_new("SB3-CHALLENGE-MOD", RunState.custom_challenge("sb3_mid_modifier", "SB3-CHALLENGE-MOD", {
		"starting_bankroll": 777,
		"starting_heat": 12,
		"baseline_luck_delta": 2,
		"local_heat_turn_decay_interval_delta": -1,
	}))
	_harness_arrive(generator, challenge_run, failures, "challenge save fixture initial arrival")
	challenge_run.advance_environment_turns(2)
	_save_load_checkpoint(library, challenge_run, "target/challenge_mid_modifier", true, failures)


func _save_load_canonical_run(run_state: RunState) -> RunState:
	var restored: RunState = RunStateScript.new()
	restored.from_dict(run_state.to_dict())
	return restored


func _check_save_load_030_compat_fixture(library: ContentLibrary, failures: Array) -> void:
	if not FileAccess.file_exists(SAVE_COMPAT_030_FIXTURE_PATH):
		failures.append("SB.3 missing 0.3.0 save compatibility fixture: %s." % SAVE_COMPAT_030_FIXTURE_PATH)
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_COMPAT_030_FIXTURE_PATH))
	if typeof(parsed) != TYPE_DICTIONARY:
		failures.append("SB.3 0.3.0 save compatibility fixture did not parse as a dictionary.")
		return
	var payload: Dictionary = parsed
	var save_service: SaveService = SaveServiceScript.new()
	var run_data_value: Variant = save_service.call("_run_data_from_payload", payload)
	if typeof(run_data_value) != TYPE_DICTIONARY:
		failures.append("SB.3 0.3.0 save compatibility fixture did not produce RunState data.")
		return
	var run_data: Dictionary = run_data_value
	if not run_data.has("legacy_unknown_root"):
		failures.append("SB.3 0.3.0 save fixture no longer covers unknown root-key tolerance.")
	if int(run_data.get("act", 0)) != 1:
		failures.append("SB.3 0.3.0 save compatibility did not add the Act 1 marker.")
	var restored: RunState = RunStateScript.new()
	restored.from_dict(run_data)
	var normalized := restored.to_dict()
	if int(restored.act_index) != 1 or int(normalized.get("act", 0)) != 1:
		failures.append("SB.3 0.3.0 markerless save did not load as Act 1.")
	if normalized.has("legacy_unknown_root"):
		failures.append("SB.3 0.3.0 save compatibility kept an unknown RunState root key.")
	var second: RunState = RunStateScript.new()
	second.from_dict(normalized)
	if JSON.stringify(second.to_dict()) != JSON.stringify(normalized):
		failures.append("SB.3 0.3.0 save compatibility fixture was not idempotent after normalization.")
	_save_load_checkpoint(library, restored, "compat/0_3_0_fixture", true, failures)


func _check_save_load_033_compat_fixture(library: ContentLibrary, failures: Array) -> void:
	if not FileAccess.file_exists(SAVE_COMPAT_033_FIXTURE_PATH):
		failures.append("SB.3 missing 0.3.3 save compatibility fixture: %s." % SAVE_COMPAT_033_FIXTURE_PATH)
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_COMPAT_033_FIXTURE_PATH))
	if typeof(parsed) != TYPE_DICTIONARY:
		failures.append("SB.3 0.3.3 save compatibility fixture did not parse as a dictionary.")
		return
	var payload: Dictionary = parsed
	var source_run_data: Dictionary = payload.get("run_state", {}) if typeof(payload.get("run_state", {})) == TYPE_DICTIONARY else {}
	for absent_field in ["game_clock_minutes", "closing_time_state", "act", "act_index", "home_state", "pending_bags"]:
		if source_run_data.has(absent_field):
			failures.append("SB.3 0.3.3 fixture must stay pre-v0.4 for field %s." % absent_field)
	var save_service: SaveService = SaveServiceScript.new()
	var run_data_value: Variant = save_service.call("_run_data_from_payload", payload)
	if typeof(run_data_value) != TYPE_DICTIONARY:
		failures.append("SB.3 0.3.3 save compatibility fixture did not produce RunState data.")
		return
	var run_data: Dictionary = run_data_value
	if not run_data.has("legacy_unknown_033_root"):
		failures.append("SB.3 0.3.3 save fixture no longer covers unknown root-key tolerance.")
	var restored: RunState = RunStateScript.new()
	restored.from_dict(run_data)
	var normalized := restored.to_dict()
	if normalized.has("legacy_unknown_033_root"):
		failures.append("SB.3 0.3.3 save compatibility kept an unknown RunState root key.")
	if int(normalized.get("act", 0)) != 1 or int(restored.act_index) != 1:
		failures.append("SB.3 0.3.3 markerless save did not normalize to Act 1.")
	if int(normalized.get("game_clock_minutes", -1)) != RunState.GAME_CLOCK_START_MINUTE:
		failures.append("SB.3 0.3.3 save did not normalize the new game clock default.")
	if typeof(normalized.get("closing_time_state", null)) != TYPE_DICTIONARY:
		failures.append("SB.3 0.3.3 save did not normalize closing time state.")
	if typeof(normalized.get("home_state", null)) != TYPE_DICTIONARY:
		failures.append("SB.3 0.3.3 save did not normalize home state.")
	var bags: Array = normalized.get("pending_bags", []) if typeof(normalized.get("pending_bags", [])) == TYPE_ARRAY else []
	if bags.size() != 1:
		failures.append("SB.3 0.3.3 save did not migrate the legacy pending_bag field.")
	var talk_entry: Dictionary = restored.next_pending_talk_event()
	if str(talk_entry.get("event_id", "")) != "suspicious_patron" or str(talk_entry.get("presentation", "")) != "talk":
		failures.append("SB.3 0.3.3 save did not preserve the pending talk event.")
	if typeof(talk_entry.get("speaker", null)) != TYPE_DICTIONARY or typeof(talk_entry.get("timing", null)) != TYPE_DICTIONARY:
		failures.append("SB.3 0.3.3 save did not normalize talk speaker/timing fields.")
	var second: RunState = RunStateScript.new()
	second.from_dict(normalized)
	if JSON.stringify(second.to_dict()) != JSON.stringify(normalized):
		failures.append("SB.3 0.3.3 save compatibility fixture was not idempotent after normalization.")
	_save_load_checkpoint(library, restored, "compat/0_3_3_fixture", true, failures)


# Verifies real-time gameplay logic is derived from absolute milliseconds, not frame counts.
func _check_locked_logic_rate_foundation(library: ContentLibrary, failures: Array) -> void:
	var absorption_30: Dictionary = _locked_rate_absorption_fixture(33)
	var absorption_144: Dictionary = _locked_rate_absorption_fixture(7)
	if JSON.stringify(absorption_30) != JSON.stringify(absorption_144):
		failures.append("Alcohol absorption produced different logic events at 30fps and 144fps simulations.")

	var bar_30: Dictionary = _locked_rate_bar_dice_fixture(library, 33, failures)
	var bar_144: Dictionary = _locked_rate_bar_dice_fixture(library, 7, failures)
	if not bar_30.is_empty() and not bar_144.is_empty() and JSON.stringify(bar_30) != JSON.stringify(bar_144):
		failures.append("Bar Dice controlled-roll timing produced different outcomes at 30fps and 144fps simulations.")


func _locked_rate_absorption_fixture(step_msec: int) -> Dictionary:
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("LOCKED-RATE-ALCOHOL")
	run_state.pending_drunk_absorption = [{
		"remaining": 6,
		"interval_msec": RunState.DRUNK_ABSORPTION_INTERVAL_MSEC,
		"next_msec": RunState.DRUNK_ABSORPTION_INTERVAL_MSEC,
		"queued_msec": 0,
	}]
	var event_times := [
		RunState.DRUNK_ABSORPTION_INTERVAL_MSEC,
		RunState.DRUNK_ABSORPTION_INTERVAL_MSEC * 2,
		RunState.DRUNK_ABSORPTION_INTERVAL_MSEC * 3,
		RunState.DRUNK_ABSORPTION_INTERVAL_MSEC * 4,
		RunState.DRUNK_ABSORPTION_INTERVAL_MSEC * 5,
		RunState.DRUNK_ABSORPTION_INTERVAL_MSEC * 6,
	]
	var events: Array = []
	for time_msec_value in _locked_rate_time_points(0, RunState.DRUNK_ABSORPTION_INTERVAL_MSEC * 6, step_msec, event_times):
		var time_msec := int(time_msec_value)
		var update: Dictionary = run_state.update_drunk_absorption(time_msec)
		var applied := int(update.get("applied", 0))
		if applied > 0:
			events.append({
				"msec": time_msec,
				"applied": applied,
				"drunk": run_state.drunk_level,
				"pending": run_state.pending_drunk_absorption_amount(),
			})
	return {
		"events": events,
		"drunk": run_state.drunk_level,
		"pending": run_state.pending_drunk_absorption_amount(),
	}


func _locked_rate_bar_dice_fixture(library: ContentLibrary, step_msec: int, failures: Array) -> Dictionary:
	var game: GameModule = _load_surface_contract_game(library, "bar_dice", failures)
	if game == null:
		return {}
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("LOCKED-RATE-BAR-DICE")
	run_state.bankroll = 100000
	var environment := _surface_contract_environment()
	environment["game_states"] = {"bar_dice": _bar_dice_state_for(game, run_state, environment, "ship_captain_crew", "standard", "pot_rake")}
	run_state.current_environment = environment.duplicate(true)
	var active_environment: Dictionary = run_state.current_environment
	var start_msec := 12000
	var roll_command: Dictionary = game.surface_action_command("bar_dice_roll", 0, false, {"surface_time_msec": start_msec}, run_state, active_environment)
	if not bool(roll_command.get("handled", false)):
		failures.append("Locked-rate Bar Dice fixture could not start a roll.")
		return {}
	var roll_ui: Dictionary = roll_command.get("ui_state", {"surface_time_msec": start_msec})
	roll_ui["surface_time_msec"] = start_msec
	var cover_command: Dictionary = game.surface_action_command("bar_dice_ack_cover", 0, false, roll_ui, run_state, active_environment)
	if not bool(cover_command.get("handled", false)):
		failures.append("Locked-rate Bar Dice fixture could not acknowledge the covered roll.")
		return {}
	var covered_ui: Dictionary = cover_command.get("ui_state", roll_ui)
	covered_ui["surface_time_msec"] = start_msec
	var load_command: Dictionary = game.surface_action_command("bar_dice_load", 0, false, covered_ui, run_state, active_environment)
	if not bool(load_command.get("handled", false)):
		failures.append("Locked-rate Bar Dice fixture could not arm loaded toss.")
		return {}
	var load_ui: Dictionary = load_command.get("ui_state", roll_ui)
	var challenge: Dictionary = load_ui.get("controlled_roll", {}) if typeof(load_ui.get("controlled_roll", {})) == TYPE_DICTIONARY else {}
	if challenge.is_empty():
		failures.append("Locked-rate Bar Dice fixture did not create a controlled-roll challenge.")
		return {}
	var period := maxi(1, int(challenge.get("meter_period_msec", 1300)))
	var input_msec := int(challenge.get("target_msec", start_msec))
	while input_msec < start_msec:
		input_msec += period
	var surface_samples := 0
	for time_msec_value in _locked_rate_time_points(start_msec, input_msec, step_msec, [input_msec]):
		var sample_ui: Dictionary = load_ui.duplicate(true)
		sample_ui["surface_time_msec"] = int(time_msec_value)
		var surface: Dictionary = game.surface_state(run_state, active_environment, sample_ui)
		if str(surface.get("surface_renderer", "")) != "dice_table":
			failures.append("Locked-rate Bar Dice fixture sampled the wrong renderer.")
			return {}
		surface_samples += 1
	var release_ui: Dictionary = load_ui.duplicate(true)
	release_ui["surface_time_msec"] = input_msec
	release_ui["controlled_roll_input_msec"] = input_msec
	var release_command: Dictionary = game.surface_action_command("bar_dice_release", 0, false, release_ui, run_state, active_environment)
	if not bool(release_command.get("handled", false)):
		failures.append("Locked-rate Bar Dice fixture could not release loaded toss.")
		return {}
	var resolved_ui: Dictionary = release_command.get("ui_state", release_ui)
	var controlled: Dictionary = resolved_ui.get("controlled_roll", {}) if typeof(resolved_ui.get("controlled_roll", {})) == TYPE_DICTIONARY else {}
	# The compatibility resolver is intentionally receipt-required and read-only.
	# This locked-rate probe compares the deterministic rules proposal without
	# claiming or mutating Foundation's live settlement authority.
	var resolve_rng := run_state.create_rng("locked_rate_bar_dice_resolve")
	var proposal: Dictionary = game.call("_bar_dice_resolve_proposal", "loaded_toss", 10, run_state.to_save_snapshot(), resolve_rng.snapshot(), resolved_ui)
	var result: Dictionary = proposal.get("result", {}) if typeof(proposal.get("result", {})) == TYPE_DICTIONARY else {}
	if not bool(result.get("ok", false)):
		failures.append("Locked-rate Bar Dice fixture did not resolve loaded toss.")
		return {}
	return {
		"target_msec": int(challenge.get("target_msec", 0)),
		"input_msec": int(controlled.get("input_msec", 0)),
		"skill_grade": str(controlled.get("skill_grade", "")),
		"skill_margin_msec": int(controlled.get("skill_margin_msec", 0)),
		"skill_accuracy": int(controlled.get("skill_accuracy", 0)),
		"desired_face": int(controlled.get("desired_face", 0)),
		"desired_die_index": int(controlled.get("desired_die_index", -1)),
		"result_grade": str(result.get("bar_dice_controlled_roll_grade", "")),
		"result_margin_msec": int(result.get("bar_dice_controlled_roll_margin_msec", 0)),
		"result_applied": bool(result.get("bar_dice_controlled_roll_applied", false)),
		"player_dice": (result.get("bar_dice_player_dice", []) as Array).duplicate(),
		"outcome": str(result.get("bar_dice_outcome", "")),
		"bankroll_delta": int(result.get("bankroll_delta", 0)),
		"suspicion_delta": int(result.get("suspicion_delta", 0)),
		"surface_samples": surface_samples > 0,
	}


func _locked_rate_time_points(start_msec: int, end_msec: int, step_msec: int, scripted_times: Array) -> Array:
	var point_map := {}
	var cursor := start_msec
	var safe_end := maxi(start_msec, end_msec)
	var safe_step := maxi(1, step_msec)
	while cursor < safe_end:
		cursor = mini(safe_end, cursor + safe_step)
		point_map[str(cursor)] = true
	for value in scripted_times:
		var scripted_msec := clampi(int(value), start_msec, safe_end)
		point_map[str(scripted_msec)] = true
	var points: Array = []
	for key in point_map.keys():
		points.append(int(key))
	points.sort()
	return points


# Ensures RunState serialization stays inside simulation domains.
func _check_run_state_snapshot_keys(snapshot: Dictionary, failures: Array) -> void:
	var required_keys := [
		"seed_text",
		"seed_value",
		"rng_seed",
		"rng_state",
		"challenge_config",
		"bankroll",
		"economic_state",
		"inventory",
		"active_item_id",
		"debt",
		"suspicion",
		"current_environment",
		"world_map",
		"grand_casino_staffing",
		"environment_history",
		"unlocked_travel",
		"narrative_flags",
		"story_log",
		"run_status",
		"run_spending_score",
	]
	for key in required_keys:
		if not snapshot.has(key):
			failures.append("RunState snapshot is missing required key: %s." % key)
	var forbidden_keys := [
		"ui_selection",
		"focus",
		"hover",
		"overlay_state",
		"button_metadata",
		"transient_scene_cache",
		"profile_inventory",
		"art_layout_state",
		"game_state",
	]
	for key in forbidden_keys:
		if snapshot.has(key):
			failures.append("RunState snapshot contains forbidden UI/profile key: %s." % key)


# Compares scalar values in foundation checks.
func _check_contracts(library: ContentLibrary, failures: Array) -> void:
	var custom_challenge := RunState.custom_challenge("foundation_contracts", "FOUNDATION-CONTRACT-SEED", {"fixture": true})
	var run_state: RunState = RunStateScript.new()
	run_state.start_new("FOUNDATION-CONTRACT-SEED", custom_challenge)
	var generator: RunGenerator = RunGeneratorScript.new(library)
	var environment := _harness_arrive(generator, run_state, failures, "foundation contracts initial arrival")

	if environment.lender_hooks.is_empty():
		failures.append("Environment contract did not include debt/lender hooks.")
	if environment.suspicion_cues.is_empty():
		failures.append("Environment contract did not include behavior-first suspicion cues.")
	if environment.local_narrative_flags.is_empty():
		failures.append("Environment contract did not include local narrative flags.")
	var environment_data: Dictionary = environment.to_dict()
	environment_data["game_ids"].append("mutated_game")
	if environment.game_ids.has("mutated_game"):
		failures.append("EnvironmentInstance.to_dict leaked mutable arrays.")
	var restored_environment := EnvironmentInstance.from_dict(environment.to_dict())
	if JSON.stringify(restored_environment.to_dict()) != JSON.stringify(environment.to_dict()):
		failures.append("EnvironmentInstance.from_dict did not preserve saveable data.")

	var game := GameModule.new()
	game.setup(library.game("fixture_game"))
	var action_presentation: Dictionary = game.actions(run_state, environment.to_dict())
	if action_presentation.get("legal_actions", []).is_empty():
		failures.append("Game module contract did not present legal actions.")
	if action_presentation.get("cheat_actions", []).is_empty():
		failures.append("Game module contract did not present cheat actions.")
	var mutated_actions: Array = action_presentation.get("legal_actions", [])
	mutated_actions[0]["id"] = "mutated_action"
	if game.legal_actions(run_state, environment.to_dict())[0].get("id", "") == "mutated_action":
		failures.append("GameModule action presentation leaked mutable definitions.")
	var legal_before := _run_state_result_snapshot(run_state)
	var rng := run_state.create_rng()
	var unresolved_result: Dictionary = game.resolve("legal_fixture", 1, run_state, environment.to_dict(), rng)
	if unresolved_result.get("game_id", "") != "fixture_game":
		failures.append("Base game module did not return a structured result.")
	_check_action_result_shape(unresolved_result, "legal", failures)
	_check_action_result_applied(legal_before, run_state, unresolved_result, "legal contract result", failures)
	var cheat_before := _run_state_result_snapshot(run_state)
	var cheat_result := game.resolve("cheat_fixture", 1, run_state, environment.to_dict(), run_state.create_rng())
	_check_action_result_shape(cheat_result, "cheat", failures)
	_check_action_result_applied(cheat_before, run_state, cheat_result, "cheat contract result", failures)
	var invalid_bankroll := run_state.bankroll
	var invalid_result := game.resolve("missing_fixture", 1, run_state, environment.to_dict(), rng)
	if bool(invalid_result.get("ok", true)):
		failures.append("Game module accepted an unavailable action.")
	if run_state.bankroll != invalid_bankroll:
		failures.append("Unavailable game action mutated RunState.")

	var event := EventModule.new()
	event.setup(library.event("fixture_event"))
	if not event.can_trigger(run_state, environment.to_dict()):
		failures.append("Event module contract did not trigger from fixture state.")
	var event_before := _run_state_result_snapshot(run_state)
	var event_result := event.resolve(run_state, environment.to_dict(), "raise_heat")
	_check_event_result_delta_shape(event_result, failures)
	_check_event_result_applied(event_before, run_state, event_result, "fixture event result", failures)
	if not bool(run_state.narrative_flags.get("fixture_event_flag", false)):
		failures.append("Event module did not apply flag consequences.")

func _music_track_validation_errors(track: Dictionary) -> Array:
	var fixture: ContentLibrary = ContentLibraryScript.new()
	fixture.music_tracks = [track]
	return fixture.validate()
