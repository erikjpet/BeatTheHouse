extends SceneTree

const DurableStoreScript := preload("res://scripts/core/durable_store.gd")
const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")
const ProfileInventoryScript := preload("res://scripts/core/profile_inventory.gd")
const MetaCollectionServiceScript := preload("res://scripts/core/meta_collection_service.gd")
const UserSettingsScript := preload("res://scripts/core/user_settings.gd")
const DeveloperPlacementStoreScript := preload("res://scripts/core/developer_placement_store.gd")
const PersistencePathsScript := preload("res://scripts/core/persistence_paths.gd")
const SaveServiceScript := preload("res://scripts/core/save_service.gd")
const RunStateScript := preload("res://scripts/core/run_state.gd")

const ROOT := "user://health06_1_durable_store_contract"
const DIRECT_PATH := ROOT + "/direct.json"
const EXACT_PATH := ROOT + "/exact_primary.json"
const TRANSITION_PATH := ROOT + "/transition.json"
const PROFILE_PATH := ROOT + "/profile.json"
const META_PATH := ROOT + "/meta.json"
const SETTINGS_PATH := ROOT + "/settings.json"
const PLACEMENT_PATH := ROOT + "/placements.json"
const PROJECT_PLACEMENT_PATH := ROOT + "/project_placements.json"
const RUN_ROOT := ROOT + "/distribution"
const RUN_SLOT := "health06_1"

var failures: Array[String] = []
var _saved_environment: Dictionary = {}
var validation_calls := 0
var checks := 0


func _init() -> void:
	call_deferred("_run")


func _run() -> void:
	var shipped_placements := DurableStoreScript.read_json(DeveloperPlacementStoreScript.PROJECT_PATH)
	var shipped_payload: Dictionary = shipped_placements.get("data", {}) as Dictionary
	_expect(bool(shipped_placements.get("ok", false)) and int(shipped_payload.get("schema_version", 0)) == DeveloperPlacementStoreScript.SCHEMA_VERSION and typeof(shipped_payload.get("rooms", {})) == TYPE_DICTIONARY, "CH-01: durable project-resource reads dropped the current placement override envelope: %s" % str(shipped_placements))
	_capture_environment()
	_cleanup()
	_configure_environment()
	_check_direct_durability()
	_check_stale_rollback_cleanup()
	_check_exact_primary_proof()
	_check_transaction_transition_faults()
	_check_json_coercion()
	_check_profile_recovery()
	_check_meta_recovery()
	_check_settings_recovery()
	_check_placement_failure_reporting()
	_check_run_save_recovery_and_trust()
	_check_distribution_root_validation()
	DurableStoreScript.reset_debug_faults()
	_restore_environment()
	_cleanup()
	if failures.is_empty():
		print("HEALTH06_1_DURABLE_STORE PASS checks=%d failures=0" % checks)
		quit(0)
		return
	for failure in failures:
		push_error(failure)
	quit(1)


func _check_direct_durability() -> void:
	var first := DurableStoreScript.write_json(DIRECT_PATH, {"generation": 1}, Callable(self, "_valid_generation"))
	_expect(bool(first.get("ok", false)), "CH-01: initial durable write failed: %s" % JSON.stringify(first))
	var first_bytes := FileAccess.get_file_as_bytes(DIRECT_PATH)

	DurableStoreScript.set_debug_force_write_failure(true)
	var write_failure := DurableStoreScript.write_json(DIRECT_PATH, {"generation": 2}, Callable(self, "_valid_generation"))
	DurableStoreScript.reset_debug_faults()
	_expect(not bool(write_failure.get("ok", true)), "CH-01/02: induced write failure reported success.")
	_expect(FileAccess.get_file_as_bytes(DIRECT_PATH) == first_bytes, "CH-01: write failure changed the prior primary bytes.")

	DurableStoreScript.set_debug_force_rename_failure(true)
	var rename_failure := DurableStoreScript.write_json(DIRECT_PATH, {"generation": 2}, Callable(self, "_valid_generation"))
	DurableStoreScript.reset_debug_faults()
	_expect(not bool(rename_failure.get("ok", true)), "CH-01: induced rename failure reported success.")
	_expect(FileAccess.get_file_as_bytes(DIRECT_PATH) == first_bytes, "CH-01: rename failure did not restore the prior primary byte-for-byte.")

	var second := DurableStoreScript.write_json(DIRECT_PATH, {"generation": 2}, Callable(self, "_valid_generation"))
	_expect(bool(second.get("ok", false)), "CH-01: replacement durable write failed: %s" % JSON.stringify(second))
	var fresh_read := DurableStoreScript.read_json(DIRECT_PATH, Callable(self, "_valid_generation"))
	_expect(bool(fresh_read.get("ok", false)) and int((fresh_read.get("data", {}) as Dictionary).get("generation", 0)) == 2, "CH-01: reported-success generation was not re-readable.")
	var second_primary_bytes := FileAccess.get_file_as_bytes(DIRECT_PATH)
	var first_backup_bytes := FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(DIRECT_PATH))
	DurableStoreScript.set_debug_force_rename_failure(true)
	var third_install_failure := DurableStoreScript.write_json(DIRECT_PATH, {"generation": 3}, Callable(self, "_valid_generation"))
	DurableStoreScript.reset_debug_faults()
	_expect(not bool(third_install_failure.get("ok", true)), "RP-005: induced third-generation install failure reported success.")
	_expect(FileAccess.get_file_as_bytes(DIRECT_PATH) == second_primary_bytes, "RP-005: failed third-generation install did not preserve the generation-two primary byte-for-byte.")
	_expect(FileAccess.file_exists(DurableStoreScript.backup_path(DIRECT_PATH)), "RP-005: failed third-generation install deleted the pre-existing generation-one backup.")
	_expect(FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(DIRECT_PATH)) == first_backup_bytes, "RP-005: failed third-generation install changed the pre-existing backup bytes.")
	_write_raw(DIRECT_PATH, "{corrupt")
	var recovered := DurableStoreScript.read_json(DIRECT_PATH, Callable(self, "_valid_generation"))
	_expect(str(recovered.get("outcome", "")) == DurableStoreScript.OUTCOME_BACKUP, "CH-01: corrupt primary did not load its backup: %s" % JSON.stringify(recovered))
	_expect(int((recovered.get("data", {}) as Dictionary).get("generation", 0)) == 1, "CH-01: backup recovery returned the wrong generation.")
	var status := DurableStoreScript.status(DIRECT_PATH, Callable(self, "_valid_generation"))
	_expect(not bool(status.get("primary_loadable", true)) and bool(status.get("backup_loadable", false)), "CH-01: durable status did not distinguish corrupt primary from valid backup.")


func _check_exact_primary_proof() -> void:
	var validator := Callable(self, "_count_valid_generation")
	var first := DurableStoreScript.write_json(EXACT_PATH, {"generation": 1}, validator, true)
	_expect(bool(first.get("ok", false)), "CH-01: exact-proof first generation failed.")
	var first_digest := str(first.get("validated_sha256", ""))
	validation_calls = 0
	var second := DurableStoreScript.write_json(EXACT_PATH, {"generation": 2}, validator, true, first_digest)
	_expect(bool(second.get("ok", false)) and validation_calls == 1, "CH-01: exact prior bytes were not reused after full validated install.")
	var second_digest := str(second.get("validated_sha256", ""))
	var second_bytes := FileAccess.get_file_as_bytes(EXACT_PATH)
	var changed_valid := JSON.stringify({"generation": 7}, "\t")
	_expect(changed_valid.to_utf8_buffer().size() == second_bytes.size(), "CH-01: valid changed-image case did not preserve primary length.")
	_write_raw(EXACT_PATH, changed_valid)
	validation_calls = 0
	var third := DurableStoreScript.write_json(EXACT_PATH, {"generation": 3}, validator, true, second_digest)
	_expect(bool(third.get("ok", false)) and validation_calls == 2, "CH-01: same-length changed valid primary bypassed full validation.")
	var changed_valid_bytes := changed_valid.to_utf8_buffer()
	_expect(FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(EXACT_PATH)) == changed_valid_bytes, "CH-01: validated changed primary was not rotated into backup.")
	var third_digest := str(third.get("validated_sha256", ""))
	var third_bytes := FileAccess.get_file_as_bytes(EXACT_PATH)
	var changed_invalid := JSON.stringify({"generation": 0}, "\t")
	_expect(changed_invalid.to_utf8_buffer().size() == third_bytes.size(), "CH-01: invalid changed-image case did not preserve primary length.")
	_write_raw(EXACT_PATH, changed_invalid)
	validation_calls = 0
	var fourth := DurableStoreScript.write_json(EXACT_PATH, {"generation": 4}, validator, true, third_digest)
	_expect(bool(fourth.get("ok", false)) and validation_calls == 2, "CH-01: same-length invalid primary bypassed full validation.")
	_expect(FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(EXACT_PATH)) == changed_valid_bytes, "CH-01: invalid previous primary displaced the last good backup.")
	var fourth_bytes := FileAccess.get_file_as_bytes(EXACT_PATH)
	var backup_bytes := FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(EXACT_PATH))
	DurableStoreScript.set_debug_fail_transition(DurableStoreScript.TRANSITION_INSTALL_PRIMARY)
	var failed := DurableStoreScript.write_json(EXACT_PATH, {"generation": 5}, validator, true, str(fourth.get("validated_sha256", "")))
	DurableStoreScript.reset_debug_faults()
	_expect(not bool(failed.get("ok", true)), "CH-01: exact-proof install fault reported success.")
	_expect(FileAccess.get_file_as_bytes(EXACT_PATH) == fourth_bytes and FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(EXACT_PATH)) == backup_bytes, "CH-01: exact-proof rollback changed primary or backup bytes.")
	_expect(not FileAccess.file_exists("%s.rollback" % EXACT_PATH) and not FileAccess.file_exists("%s.bak.rollback" % EXACT_PATH), "CH-01: exact-proof rollback left transaction artifacts.")


func _check_transaction_transition_faults() -> void:
	for transition in [
		DurableStoreScript.TRANSITION_STAGE_BACKUP,
		DurableStoreScript.TRANSITION_ROTATE_PRIMARY,
		DurableStoreScript.TRANSITION_INSTALL_PRIMARY,
		DurableStoreScript.TRANSITION_VALIDATE_PRIMARY,
	]:
		_remove_generation(TRANSITION_PATH)
		_expect(bool(DurableStoreScript.write_json(TRANSITION_PATH, {"generation": 1}, Callable(self, "_valid_generation")).get("ok", false)), "RP-005: %s fixture generation one failed." % transition)
		_expect(bool(DurableStoreScript.write_json(TRANSITION_PATH, {"generation": 2}, Callable(self, "_valid_generation")).get("ok", false)), "RP-005: %s fixture generation two failed." % transition)
		var primary_before := FileAccess.get_file_as_bytes(TRANSITION_PATH)
		var backup_before := FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(TRANSITION_PATH))
		DurableStoreScript.set_debug_fail_transition(transition)
		var failed := DurableStoreScript.write_json(TRANSITION_PATH, {"generation": 3}, Callable(self, "_valid_generation"))
		DurableStoreScript.reset_debug_faults()
		_expect(not bool(failed.get("ok", true)), "RP-005: %s fault injection reported success." % transition)
		_expect(FileAccess.get_file_as_bytes(TRANSITION_PATH) == primary_before, "RP-005: %s fault changed the prior primary." % transition)
		_expect(FileAccess.get_file_as_bytes(DurableStoreScript.backup_path(TRANSITION_PATH)) == backup_before, "RP-005: %s fault changed the prior backup." % transition)
		_expect(not FileAccess.file_exists("%s.rollback" % TRANSITION_PATH) and not FileAccess.file_exists("%s.bak.rollback" % TRANSITION_PATH), "RP-005: %s fault left transaction rollback artifacts." % transition)


func _check_json_coercion() -> void:
	for malformed in [17, ["windowed"], null]:
		_expect(JsonCoerceScript.coerce_enum(malformed, ["windowed", "fullscreen"], "windowed") == "windowed", "CH-04: malformed enum did not clamp to its default.")
	var settings := UserSettingsScript.new()
	for malformed in [17, ["fullscreen"], null]:
		settings.from_dict({"window_mode": malformed, "text_size": malformed})
		_expect(settings.window_mode == "windowed", "CH-04: malformed window mode did not default.")
		_expect(settings.text_size == "normal", "CH-04: malformed text size did not default.")


func _check_profile_recovery() -> void:
	var profile := ProfileInventoryScript.new()
	profile.tutorial_completed = false
	_expect(profile.save() == OK, "CH-01: profile generation one failed to save.")
	profile.tutorial_completed = true
	_expect(profile.save() == OK, "CH-01: profile generation two failed to save.")
	_write_raw(PROFILE_PATH, "{corrupt")
	var fresh := ProfileInventoryScript.new()
	fresh.load()
	_expect(fresh.loaded_from_disk and not fresh.tutorial_completed, "CH-01: profile did not recover its prior backup generation.")
	_expect(str(fresh.last_load_outcome.get("outcome", "")) == DurableStoreScript.OUTCOME_BACKUP, "CH-01: profile did not surface backup recovery.")


func _check_meta_recovery() -> void:
	var meta := MetaCollectionServiceScript.new()
	meta.add_gold(11)
	_expect(meta.save() == OK, "CH-01: meta generation one failed to save.")
	meta.add_gold(7)
	_expect(meta.save() == OK, "CH-01: meta generation two failed to save.")
	_write_raw(META_PATH, "{corrupt")
	var fresh := MetaCollectionServiceScript.new()
	fresh.load()
	_expect(int(fresh.snapshot().get("gold_balance", 0)) == 11, "CH-01: meta collection did not recover its prior backup generation.")
	_expect(str(fresh.last_load_outcome.get("outcome", "")) == DurableStoreScript.OUTCOME_BACKUP, "CH-01: meta collection did not surface backup recovery.")


func _check_settings_recovery() -> void:
	var settings := UserSettingsScript.new()
	settings.text_size = "small"
	_expect(settings.save() == OK, "CH-02: settings generation one failed to save.")
	settings.text_size = "large"
	_expect(settings.save() == OK, "CH-02: settings generation two failed to save.")
	_write_raw(SETTINGS_PATH, "{corrupt")
	var fresh := UserSettingsScript.new()
	var outcome: Dictionary = fresh.load()
	_expect(fresh.text_size == "small", "CH-02: settings did not recover their prior backup generation.")
	_expect(str(outcome.get("code", "")) == "loaded_backup", "CH-02/03: settings did not surface backup recovery: %s" % JSON.stringify(outcome))

	_remove_generation(SETTINGS_PATH)
	_write_raw(SETTINGS_PATH, '{"unrecognized_corrupt_payload":true}')
	var corrupt_object := UserSettingsScript.new()
	var corrupt_outcome: Dictionary = corrupt_object.load()
	var preserved_path := str(corrupt_outcome.get("preserved_path", ""))
	_expect(str(corrupt_outcome.get("code", "")) == "recovered_defaults", "RP-008: object-shaped settings corruption was silently accepted: %s" % JSON.stringify(corrupt_outcome))
	_expect(corrupt_object.to_dict() == UserSettingsScript.new().to_dict(), "RP-008: object-shaped settings corruption did not restore defaults.")
	_expect(not preserved_path.is_empty() and FileAccess.file_exists(preserved_path), "RP-008: invalid object-shaped settings were not preserved for recovery/support.")
	if not preserved_path.is_empty() and FileAccess.file_exists(preserved_path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(preserved_path))

	_expect_invalid_settings_preserved(
		{"text_size": {"corrupt": true}},
		"recognized key with an invalid value type"
	)
	_expect_invalid_settings_preserved(
		{"object_labels_and_borders_enabled": "sometimes"},
		"object-label visibility with an invalid value type"
	)
	_expect(
		not bool(UserSettingsScript.new().call("_settings_payload_valid", {"resolution": "corrupt"})),
		"RP-008: malformed recognized resolution shape passed settings schema validation."
	)
	_expect_invalid_settings_preserved(
		{UserSettingsScript.SETTINGS_SCHEMA_KEY: 1.5, "text_size": "large"},
		"fractional settings schema version"
	)

	# Schema-less files from earlier releases remain valid when they contain at
	# least one recognized setting key; migration fills every omitted default.
	_remove_generation(SETTINGS_PATH)
	_write_raw(SETTINGS_PATH, '{"text_size":"large"}')
	var legacy := UserSettingsScript.new()
	var legacy_outcome: Dictionary = legacy.load()
	_expect(str(legacy_outcome.get("code", "")) == "loaded" and legacy.text_size == "large", "RP-008: recognized schema-less legacy settings did not migrate: %s" % JSON.stringify(legacy_outcome))
	_expect(legacy.object_labels_and_borders_enabled, "RP-008: legacy settings missing the object-label preference did not retain its enabled default.")


func _expect_invalid_settings_preserved(payload: Dictionary, label: String) -> void:
	_remove_generation(SETTINGS_PATH)
	_write_raw(SETTINGS_PATH, JSON.stringify(payload))
	var settings := UserSettingsScript.new()
	var outcome: Dictionary = settings.load()
	var preserved_path := str(outcome.get("preserved_path", ""))
	_expect(str(outcome.get("code", "")) == "recovered_defaults", "RP-008: %s was silently accepted: %s" % [label, JSON.stringify(outcome)])
	_expect(settings.to_dict() == UserSettingsScript.new().to_dict(), "RP-008: %s did not restore settings defaults." % label)
	_expect(not preserved_path.is_empty() and FileAccess.file_exists(preserved_path), "RP-008: %s was not preserved for recovery/support." % label)
	if not preserved_path.is_empty() and FileAccess.file_exists(preserved_path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(preserved_path))


func _check_placement_failure_reporting() -> void:
	DeveloperPlacementStoreScript.reload()
	var environment := {"archetype_id": "house"}
	var slot_id := "fixed.home_sleep"
	var first: Dictionary = DeveloperPlacementStoreScript.save_position(environment, "slot_positions", slot_id, Vector2(24, 36))
	_expect(bool(first.get("ok", false)), "CH-05: initial developer placement failed.")
	var prior_bytes := FileAccess.get_file_as_bytes(PLACEMENT_PATH)
	DurableStoreScript.set_debug_force_write_failure(true)
	var failed: Dictionary = DeveloperPlacementStoreScript.save_position(environment, "slot_positions", slot_id, Vector2(48, 72))
	DurableStoreScript.reset_debug_faults()
	_expect(not bool(failed.get("ok", true)), "CH-05: failed developer placement write reported success.")
	_expect(FileAccess.get_file_as_bytes(PLACEMENT_PATH) == prior_bytes, "CH-05: failed developer placement write changed the prior generation.")
	var still_active: Dictionary = DeveloperPlacementStoreScript.slot_overrides(environment, "slot_positions")
	_expect(still_active.get(slot_id, []) == [24.0, 36.0], "CH-05: failed developer placement write leaked into active in-memory overrides.")
	DeveloperPlacementStoreScript.reload()
	var loaded: Dictionary = DeveloperPlacementStoreScript.slot_overrides(environment, "slot_positions")
	_expect(loaded.get(slot_id, []) == [24.0, 36.0], "CH-05: developer placement was not re-readable after failure.")


func _check_run_save_recovery_and_trust() -> void:
	var service := SaveServiceScript.new()
	var run_state := RunStateScript.new()
	run_state.start_new("HEALTH06_1_DURABLE")
	_expect(service.save_run(run_state, RUN_SLOT) == OK, "CH-01/02: run generation one failed to save.")
	run_state.bankroll += 1
	_expect(service.save_run(run_state, RUN_SLOT) == OK, "CH-01/02: run generation two failed to save.")
	var primary_path := service.run_save_path(RUN_SLOT)
	_write_raw(primary_path, "{corrupt")
	var damaged_status := service.slot_status(RUN_SLOT)
	_expect(not bool(damaged_status.get("primary_loadable", true)) and not service.trusted_primary_fingerprints.has(RUN_SLOT), "CH-01: corrupt primary status retained an installed-byte proof.")
	var recovery_service := SaveServiceScript.new()
	var recovered: Variant = recovery_service.load_run(RUN_SLOT)
	_expect(recovered != null, "CH-01: run save did not recover from backup.")
	_expect(str(recovery_service.last_load_outcome.get("outcome", "")) == DurableStoreScript.OUTCOME_BACKUP, "CH-01: run recovery did not surface its backup outcome.")
	_expect(not recovery_service.trusted_primary_fingerprints.has(RUN_SLOT), "CH-01: backup recovery minted a primary-byte proof.")
	# Re-establish a valid primary, then prove a failed save invalidates its trust cache.
	_expect(service.save_run(run_state, RUN_SLOT) == OK, "CH-01: run primary could not be re-established.")
	_expect(service.trusted_primary_fingerprints.has(RUN_SLOT), "CH-01: successful run save did not establish a trusted fingerprint.")
	DurableStoreScript.set_debug_force_rename_failure(true)
	run_state.bankroll += 1
	var failed_save := service.save_run(run_state, RUN_SLOT)
	DurableStoreScript.reset_debug_faults()
	_expect(failed_save != OK, "CH-01: induced run rename failure reported success.")
	_expect(not service.trusted_primary_fingerprints.has(RUN_SLOT), "CH-01: failed run save retained a trusted-primary fingerprint.")
	_expect(service.save_run(run_state, RUN_SLOT) == OK and service.trusted_primary_fingerprints.has(RUN_SLOT), "CH-01: recovery save did not re-establish installed-byte proof.")
	var cold_service := SaveServiceScript.new()
	_expect(cold_service.load_run(RUN_SLOT) != null and cold_service._primary_digest_is_trusted(RUN_SLOT, primary_path), "CH-01: fresh primary load did not capture its validated exact bytes.")
	var primary_text := FileAccess.get_file_as_string(primary_path)
	_write_raw(primary_path, primary_text + "\n")
	_expect(not cold_service._primary_digest_is_trusted(RUN_SLOT, primary_path), "CH-01: an external byte change retained the loaded-primary proof.")
	_expect(cold_service.load_run(RUN_SLOT) != null and cold_service._primary_digest_is_trusted(RUN_SLOT, primary_path), "CH-01: the changed valid primary was not revalidated on load.")
	var raw_state := run_state.to_dict()
	_write_raw(primary_path, JSON.stringify(raw_state))
	_expect(cold_service.load_run(RUN_SLOT) != null and not cold_service.trusted_primary_fingerprints.has(RUN_SLOT), "CH-01: a legacy raw save minted a current-envelope proof.")
	var proof: Dictionary = {}
	cold_service._run_data_from_payload({"schema": SaveServiceScript.SAVE_SCHEMA, "run_state": {"bankroll": 1}}, proof)
	_expect(not bool(proof.get("loadable", false)), "CH-01: normalized defaults minted a proof for missing required stored fields.")
	proof.clear()
	cold_service._run_data_from_payload({"schema": "unknown", "seed_text": "legacy", "rng_state": "0", "challenge_config": {}, "bankroll": 1, "current_environment": {}}, proof)
	_expect(proof.is_empty(), "CH-01: an unknown envelope minted a current-envelope proof.")


func _check_distribution_root_validation() -> void:
	OS.set_environment(PersistencePathsScript.DISTRIBUTION_FEATURE_ENV, "1")
	for invalid_root in ["   ", "relative/path", "../escape", "user://safe/../escape", "C:/safe/../escape"]:
		OS.set_environment(PersistencePathsScript.DISTRIBUTION_ROOT_ENV, invalid_root)
		_expect(PersistencePathsScript.distribution_root() == PersistencePathsScript.DISTRIBUTION_ROOT, "CH-06: invalid distribution root was accepted: %s" % invalid_root)
	OS.set_environment(PersistencePathsScript.DISTRIBUTION_ROOT_ENV, "user://isolated/root/")
	_expect(PersistencePathsScript.distribution_root() == "user://isolated/root", "CH-06: valid user root was rejected or not normalized.")
	var absolute_root := ProjectSettings.globalize_path(ROOT + "/absolute")
	OS.set_environment(PersistencePathsScript.DISTRIBUTION_ROOT_ENV, absolute_root)
	_expect(PersistencePathsScript.distribution_root() == absolute_root.trim_suffix("/").trim_suffix("\\"), "CH-06: valid absolute test-isolation root was rejected.")


func _valid_generation(data: Dictionary) -> bool:
	return int(data.get("generation", 0)) > 0


func _count_valid_generation(data: Dictionary) -> bool:
	validation_calls += 1
	return _valid_generation(data)


func _capture_environment() -> void:
	for key in [
		ProfileInventoryScript.INVENTORY_PATH_ENV,
		MetaCollectionServiceScript.STORE_PATH_ENV,
		UserSettingsScript.SETTINGS_PATH_ENV,
		DeveloperPlacementStoreScript.USER_PATH_ENV,
		DeveloperPlacementStoreScript.PROJECT_PATH_ENV,
		PersistencePathsScript.DISTRIBUTION_FEATURE_ENV,
		PersistencePathsScript.DISTRIBUTION_ROOT_ENV,
	]:
		_saved_environment[key] = OS.get_environment(key)


func _configure_environment() -> void:
	OS.set_environment(ProfileInventoryScript.INVENTORY_PATH_ENV, PROFILE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, META_PATH)
	OS.set_environment(UserSettingsScript.SETTINGS_PATH_ENV, SETTINGS_PATH)
	OS.set_environment(DeveloperPlacementStoreScript.USER_PATH_ENV, PLACEMENT_PATH)
	OS.set_environment(DeveloperPlacementStoreScript.PROJECT_PATH_ENV, PROJECT_PLACEMENT_PATH)
	# Fault-injection cases require non-distribution semantics. Explicit private
	# paths above/below still isolate every write. Shipping-mode root validation
	# is exercised separately by _check_distribution_root_validation().
	OS.set_environment(PersistencePathsScript.DISTRIBUTION_FEATURE_ENV, "0")
	OS.set_environment(PersistencePathsScript.DISTRIBUTION_ROOT_ENV, RUN_ROOT)


func _restore_environment() -> void:
	for key in _saved_environment.keys():
		OS.set_environment(str(key), str(_saved_environment[key]))


func _cleanup() -> void:
	for path in [DIRECT_PATH, EXACT_PATH, TRANSITION_PATH, PROFILE_PATH, META_PATH, SETTINGS_PATH, PLACEMENT_PATH, PROJECT_PLACEMENT_PATH]:
		_remove_generation(path)
	_remove_generation("%s/saves/run_%s.json" % [RUN_ROOT, RUN_SLOT])


func _remove_generation(path: String) -> void:
	for suffix in ["", ".tmp", ".bak", ".rollback", ".bak.rollback"]:
		var absolute_path := ProjectSettings.globalize_path(path + suffix)
		if FileAccess.file_exists(absolute_path):
			DirAccess.remove_absolute(absolute_path)


func _write_raw(path: String, text: String) -> void:
	var absolute_path := ProjectSettings.globalize_path(path)
	DirAccess.make_dir_recursive_absolute(absolute_path.get_base_dir())
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		failures.append("Fixture could not write %s (error %d)." % [path, FileAccess.get_open_error()])
		return
	file.store_string(text)
	var error := file.get_error()
	file.close()
	if error != OK:
		failures.append("Fixture write failed for %s (error %d)." % [path, error])


func _expect(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)


func _check_stale_rollback_cleanup() -> void:
	for spec in [[true, ".bak.rollback"], [true, ".rollback"], [false, ".bak.rollback"]]:
		_remove_generation(TRANSITION_PATH)
		if bool(spec[0]):
			_expect(bool(DurableStoreScript.write_json(TRANSITION_PATH, {"generation": 1}, Callable(self, "_valid_generation")).get("ok", false)), "AUD061-01: baseline primary saves.")
		var stale_path := TRANSITION_PATH + str(spec[1])
		_write_raw(stale_path, "")
		var result := DurableStoreScript.write_json(TRANSITION_PATH, {"generation": 2}, Callable(self, "_valid_generation"))
		_expect(bool(result.get("ok", false)), "AUD061-01: stale %s denied the next write: %s" % [spec[1], result])
		_expect(not FileAccess.file_exists(stale_path), "AUD061-01: stale rollback name remains after a successful write.")
		var loaded := DurableStoreScript.read_json(TRANSITION_PATH, Callable(self, "_valid_generation"))
		_expect(int((loaded.get("data", {}) as Dictionary).get("generation", 0)) == 2, "AUD061-01: replacement generation is loadable.")
	_remove_generation(SETTINGS_PATH)
	var settings := UserSettingsScript.new()
	_expect(settings.save() == OK, "AUD061-01: baseline settings save.")
	_write_raw(SETTINGS_PATH + ".bak.rollback", "")
	settings.master_volume = 0.4
	_expect(settings.save() == OK and not FileAccess.file_exists(SETTINGS_PATH + ".bak.rollback"), "AUD061-01: settings save clears stale rollback.")
	var reloaded := UserSettingsScript.new()
	reloaded.load()
	_expect(is_equal_approx(reloaded.master_volume, 0.4), "AUD061-01: changed settings survive reload.")
