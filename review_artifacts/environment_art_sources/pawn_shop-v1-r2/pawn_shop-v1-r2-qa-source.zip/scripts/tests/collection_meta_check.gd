extends SceneTree

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")

const CollectionItemResolverScript := preload("res://scripts/core/collection_item_resolver.gd")
const MetaCollectionServiceScript := preload("res://scripts/core/meta_collection_service.gd")
const CollectionDropServiceScript := preload("res://scripts/core/collection_drop_service.gd")
const MetaCollectionViewModelScript := preload("res://scripts/ui/meta_collection_view_model.gd")
const MetaItemInteractionViewModelScript := preload("res://scripts/ui/meta_item_interaction_view_model.gd")
const BagOpenReelViewModelScript := preload("res://scripts/ui/bag_open_reel_view_model.gd")
const RunReportViewModelScript := preload("res://scripts/ui/run_report_view_model.gd")
const RunStateScript := preload("res://scripts/core/run_state.gd")

const TEST_STORE_PATH := "user://collection_meta_check_store.json"
const EXPECTED_TIER_COUNTS := {
	"blue": 4,
	"purple": 4,
	"pink": 3,
	"red": 2,
	"gold": 1,
}
const TIERS := ["blue", "purple", "pink", "red", "gold"]

var failures: Array[String] = []


func _init() -> void:
	call_deferred("_run")


func _run() -> void:
	var resolver: Variant = CollectionItemResolverScript.new()
	_test_collection_schema(resolver)
	_test_players_card_schema_and_fragility(resolver)
	_test_float_determinism(resolver)
	_test_usage_decay(resolver)
	_test_resolve_run_item(resolver)
	_test_store_round_trip(resolver)
	_test_sal_shelf_defaults_and_migration(resolver)
	_test_sal_float_rarity_curve(resolver)
	_test_sal_stocking_and_idempotency()
	_test_sal_purchase_and_starter_buyback()
	_test_meta_home_rules(resolver)
	_test_pawn_sale_and_trade_up(resolver)
	_test_failure_decay_and_run_modifiers(resolver)
	_test_players_card_mint_and_profile_lifecycle()
	_test_tutorial_starter_card_fragility()
	_test_uncashed_grand_casino_chips_pawn_flow()
	_test_prestige_run_modifiers_and_drop_depth()
	_test_terminal_drop_determinism()
	_test_victory_selection_grants_one_bag()
	_test_failed_run_discards_pending_bags()
	_test_daily_and_challenge_runs_are_meta_isolated()
	_test_open_bag_consumes_once()
	_test_bag_open_reel_view_model_pins_committed_item(resolver)
	_test_collection_browser_view_model_read_only(resolver)
	_test_end_summary_lists_bags()
	_finish()


func _test_collection_schema(resolver: Variant) -> void:
	var errors: Array = resolver.validate_definitions()
	for error in errors:
		failures.append(error)
	var collections: Array = resolver.collections()
	_check(collections.size() == 2, "Expected exactly 2 launch collections.")
	var used_itemdef_ids := {}
	var total_items := 0
	for collection_value in collections:
		var collection := JsonCoerceScript._copy_dict(collection_value)
		var collection_id := str(collection.get("id", ""))
		var tier_counts := {}
		for tier in TIERS:
			tier_counts[tier] = 0
		var bag_tiers := {}
		for bag_value in JsonCoerceScript._copy_array(collection.get("bag_defs", [])):
			var bag := JsonCoerceScript._copy_dict(bag_value)
			var bag_tier := str(bag.get("tier", ""))
			var bag_itemdef_id := int(bag.get("itemdef_id", -1))
			bag_tiers[bag_tier] = true
			_check(bag_itemdef_id >= 9000, "Bag %s itemdef_id must be in the 9000s." % str(bag.get("id", "")))
			_check(not used_itemdef_ids.has(bag_itemdef_id), "Duplicate itemdef_id %d." % bag_itemdef_id)
			used_itemdef_ids[bag_itemdef_id] = true
		for tier in TIERS:
			_check(bag_tiers.has(tier), "Collection %s missing %s bag definition." % [collection_id, tier])
		for item_value in JsonCoerceScript._copy_array(collection.get("items", [])):
			var item := JsonCoerceScript._copy_dict(item_value)
			var itemdef_id := int(item.get("itemdef_id", -1))
			var tier := str(item.get("tier", ""))
			_check(not used_itemdef_ids.has(itemdef_id), "Duplicate itemdef_id %d." % itemdef_id)
			used_itemdef_ids[itemdef_id] = true
			if tier_counts.has(tier):
				tier_counts[tier] = int(tier_counts.get(tier, 0)) + 1
			total_items += 1
			_check(_item_float_bindings_are_known(item), "Item %s has an unknown float binding effect key." % str(item.get("id", "")))
		for tier in TIERS:
			_check(int(tier_counts.get(tier, 0)) == int(EXPECTED_TIER_COUNTS.get(tier, 0)), "Collection %s tier %s count mismatch." % [collection_id, tier])
	_check(total_items == 28, "Expected exactly 28 draft collection items.")


func _test_players_card_schema_and_fragility(resolver: Variant) -> void:
	var special_items: Array = resolver.special_item_definitions()
	_check(special_items.size() == 2, "Collection schema must define Players Card and chip-stack special items.")
	var definition: Dictionary = resolver.item_definition(MetaCollectionServiceScript.PLAYERS_CARD_ITEMDEF_ID)
	_check(str(definition.get("item_class", "")) == CollectionItemResolverScript.ITEM_CLASS_PLAYERS_CARD, "Players Card is not a first-class players_card item.")
	var normalized: Dictionary = resolver.normalize_instance_for_definition({
		"itemdef_id": MetaCollectionServiceScript.PLAYERS_CARD_ITEMDEF_ID,
		"potency": 0.4,
		"condition": 1.0,
		"resonance": 0.6,
		"usage": 0.2,
	})
	_check(float(normalized.get("condition", 1.0)) <= 0.10 and bool(normalized.get("durability_pinned", false)), "Players Card condition was not pinned to the critical band.")
	var decayed: Dictionary = resolver.apply_usage_decay(normalized, "players-card-no-decay")
	_check(is_equal_approx(float(decayed.get("condition", 0.0)), float(normalized.get("condition", 1.0))) and is_equal_approx(float(decayed.get("usage", 0.0)), 1.0), "Players Card was not exempt from normal usage decay.")
	var rolled: Dictionary = resolver.roll_instance(MetaCollectionServiceScript.PLAYERS_CARD_ITEMDEF_ID, "players-card-roll")
	_check(is_equal_approx(float(rolled.get("condition", 1.0)), float(normalized.get("condition", 0.0))), "Players Card roll boundary did not keep durability pinned.")
	var run_item: Dictionary = resolver.resolve_run_item(normalized)
	_check(str(JsonCoerceScript._copy_dict(run_item.get("meta_collection", {})).get("condition_band", "")) == "critical", "Players Card did not resolve in the critical durability band.")
	var bronze_item: Dictionary = resolver.resolve_run_item(resolver.normalize_instance_for_definition({
		"itemdef_id": MetaCollectionServiceScript.PLAYERS_CARD_ITEMDEF_ID,
		"instance_data": {"tier_reached": "bronze"},
	}))
	var bronze_meta := JsonCoerceScript._copy_dict(bronze_item.get("meta_collection", {}))
	_check(str(bronze_meta.get("tier", "")) == "bronze" and str(bronze_item.get("description", "")).contains("Bronze card"), "A minted Bronze Players Card presented itself as the Gold template rarity.")
	var chip_definition: Dictionary = resolver.item_definition(MetaCollectionServiceScript.GRAND_CASINO_CHIPS_ITEMDEF_ID)
	_check(str(chip_definition.get("item_class", "")) == CollectionItemResolverScript.ITEM_CLASS_CHIP_STACK and not bool(chip_definition.get("loadout_eligible", true)), "Grand Casino Chips are not a first-class meta-only chip stack.")
	var chip_policy := JsonCoerceScript._copy_dict(chip_definition.get("sale_policy", {}))
	_check(str(chip_policy.get("kind", "")) == "face_value_rate" and is_equal_approx(float(chip_policy.get("gold_rate", 0.0)), 0.6), "Grand Casino Chips do not carry Sal's tuned 60% fenced rate.")


func _test_float_determinism(resolver: Variant) -> void:
	var first: Dictionary = resolver.roll_instance(1000, "determinism-seed")
	var second: Dictionary = resolver.roll_instance(1000, "determinism-seed")
	var different: Dictionary = resolver.roll_instance(1000, "determinism-seed-b")
	_check(JSON.stringify(first) == JSON.stringify(second), "Same seed did not produce identical collection item instance.")
	var variance_found := false
	for float_key in ["potency", "condition", "resonance", "usage"]:
		if absf(float(first.get(float_key, 0.0)) - float(different.get(float_key, 0.0))) > 0.000001:
			variance_found = true
		_check(float(first.get(float_key, -1.0)) >= 0.0 and float(first.get(float_key, -1.0)) <= 1.0, "Rolled float %s was outside [0,1]." % str(float_key))
	_check(variance_found, "Different seeds did not vary any rolled floats.")


func _test_usage_decay(resolver: Variant) -> void:
	var instance: Dictionary = resolver.roll_instance(1000, "decay-seed")
	instance["usage"] = 0.03
	var decayed: Dictionary = resolver.apply_usage_decay(instance, "failure-seed")
	_check(decayed.has("itemdef_id"), "Usage decay removed item identity.")
	_check(float(decayed.get("usage", 1.0)) <= float(instance.get("usage", 0.0)), "Usage decay was not monotonic.")
	_check(float(decayed.get("usage", -1.0)) >= 0.0, "Usage decay fell below zero.")
	var fresh: Dictionary = instance.duplicate(true)
	fresh["usage"] = 1.0
	var spent: Dictionary = instance.duplicate(true)
	spent["usage"] = 0.0
	var fresh_item: Dictionary = resolver.resolve_run_item(fresh)
	var spent_item: Dictionary = resolver.resolve_run_item(spent)
	var fresh_effect := JsonCoerceScript._copy_dict(fresh_item.get("effect", {}))
	var spent_effect := JsonCoerceScript._copy_dict(spent_item.get("effect", {}))
	_check(int(spent_effect.get("win_chance", 999)) < int(fresh_effect.get("win_chance", 0)), "Spent item potency was not dampened.")
	_check(float(spent_item.get("meta_value_multiplier", 1.0)) < float(fresh_item.get("meta_value_multiplier", 0.0)), "Spent item value multiplier did not bottom out.")


func _test_resolve_run_item(resolver: Variant) -> void:
	var instance: Dictionary = resolver.roll_instance(1013, "resolve-seed")
	var before_json := JSON.stringify(instance)
	var run_item: Dictionary = resolver.resolve_run_item(instance)
	_check(JSON.stringify(instance) == before_json, "resolve_run_item mutated the source instance.")
	for key in ["id", "display_name", "class", "domain", "content_groups", "sellable", "price_min", "price_max", "icon_key", "description", "effect"]:
		_check(run_item.has(key), "Resolved run item missing key %s." % str(key))
	_check(typeof(run_item.get("effect", {})) == TYPE_DICTIONARY, "Resolved run item effect must be a Dictionary.")
	var meta := JsonCoerceScript._copy_dict(run_item.get("meta_collection", {}))
	_check(int(meta.get("itemdef_id", -1)) == 1013, "Resolved run item missing meta itemdef_id.")


func _test_store_round_trip(resolver: Variant) -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	var empty_store: Dictionary = service.load()
	_check(int(empty_store.get("schema_version", 0)) == MetaCollectionServiceScript.SCHEMA_VERSION, "Default store missing schema_version.")
	_check(int(empty_store.get("gold_balance", -1)) == 0, "Default gold balance must start at 0.")
	_check(str(empty_store.get("housing_tier", "")) == MetaCollectionServiceScript.HOUSING_BACK_ALLEY, "Default housing tier must be back alley.")
	var granted: Dictionary = service.grant_instance(resolver.roll_instance(1000, "store-seed"))
	service.grant_bag(9000, "bag-seed")
	service.add_gold(17)
	var before_save: Dictionary = service.snapshot()
	var save_error: Error = service.save()
	_check(save_error == OK, "Meta collection store save failed with error %d." % int(save_error))
	var loaded_service: Variant = MetaCollectionServiceScript.new()
	var loaded: Dictionary = loaded_service.load()
	_check(JSON.stringify(before_save) == JSON.stringify(loaded), "Meta collection store did not round-trip identically.")
	_check(int(granted.get("instance_id", 0)) == 2, "First player-owned grant did not follow the starter shelf item in the shared monotonic namespace.")
	var removed: bool = loaded_service.remove_instance(int(granted.get("instance_id", 0)))
	_check(removed, "remove_instance did not remove the granted owned instance.")
	_check(loaded_service.owned_instances().is_empty(), "owned_instances still returned removed instance.")
	var corrupt_file := FileAccess.open(TEST_STORE_PATH, FileAccess.WRITE)
	if corrupt_file != null:
		corrupt_file.store_string("{corrupt")
		corrupt_file.close()
	var corrupt_service: Variant = MetaCollectionServiceScript.new()
	var corrupt_loaded: Dictionary = corrupt_service.load()
	_check(int(corrupt_loaded.get("schema_version", 0)) == MetaCollectionServiceScript.SCHEMA_VERSION, "Corrupt store did not normalize schema_version.")
	_check(JsonCoerceScript._copy_array(corrupt_loaded.get("owned_instances", [])).is_empty(), "Corrupt store did not reset owned instances.")
	_check(int(corrupt_loaded.get("gold_balance", -1)) == 0, "Corrupt store did not reset gold balance.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_meta_home_rules(resolver: Variant) -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	_check(service.housing_tier() == MetaCollectionServiceScript.HOUSING_BACK_ALLEY, "Meta home must default to back alley.")
	_check(service.storage_slots() == 0, "Back alley must not provide owned storage slots.")
	_check(service.carry_capacity() == 3, "Starter bag capacity must come from container data.")
	_check(not service.trade_up_unlocked(), "Back alley must not unlock trade-ups.")
	for index in range(3):
		service.grant_instance(resolver.roll_instance(1000, "home-cap-%d" % index))
	var bag: Dictionary = service.grant_bag(9000, "home-full-bag")
	var blocked: Dictionary = service.open_bag(int(bag.get("instance_id", 0)))
	_check(not bool(blocked.get("ok", true)), "Homeless owned-cap must block opening bags when full.")
	_check(service.unopened_bags().size() == 1, "Blocked bag open must not consume the bag.")
	service.add_gold(60)
	var motel: Dictionary = service.purchase_housing_upgrade()
	_check(bool(motel.get("ok", false)) and service.housing_tier() == MetaCollectionServiceScript.HOUSING_MOTEL_ROOM, "Gold purchase did not upgrade to motel room.")
	_check(service.storage_slots() == 8, "Motel room must provide eight storage slots.")
	_check(not service.trade_up_unlocked(), "Motel room must not unlock trade-ups.")
	var owned_ids: Array = _instance_ids(service.owned_instances())
	var packed: Dictionary = service.pack_instance(int(owned_ids[0]))
	var duplicate_pack: Dictionary = service.pack_instance(int(owned_ids[0]))
	_check(bool(packed.get("ok", false)) and JsonCoerceScript._copy_array(packed.get("packed_instance_ids", [])).size() == 1, "Housed packing did not select one item.")
	_check(JsonCoerceScript._copy_array(duplicate_pack.get("packed_instance_ids", [])).size() == 1, "Packing the same item twice duplicated it.")
	service.add_gold(250)
	var apartment: Dictionary = service.purchase_housing_upgrade()
	_check(bool(apartment.get("ok", false)) and service.housing_tier() == MetaCollectionServiceScript.HOUSING_APARTMENT, "Gold purchase did not upgrade to apartment.")
	_check(service.trade_up_unlocked(), "Apartment must unlock trade-ups.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_pawn_sale_and_trade_up(resolver: Variant) -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	service.add_gold(310)
	service.purchase_housing_upgrade()
	service.purchase_housing_upgrade()
	var ids: Array = []
	for index in range(5):
		var granted: Dictionary = service.grant_instance(resolver.roll_instance(1000, "trade-%d" % index))
		ids.append(int(granted.get("instance_id", 0)))
	var trade: Dictionary = service.arm_trade_up(ids)
	_check(bool(trade.get("ok", false)), "Apartment trade-up did not arm for five matching items.")
	var trade_result: Dictionary = service.confirm_trade_up(str(trade.get("token", "")))
	_check(bool(trade_result.get("ok", false)), "Apartment trade-up did not confirm.")
	_check(service.owned_instances().size() == 1, "Trade-up did not consume five items and grant one output.")
	var output := JsonCoerceScript._copy_dict(service.owned_instances()[0])
	var output_def: Dictionary = resolver.item_definition(int(output.get("itemdef_id", -1)))
	_check(str(output_def.get("tier", "")) == "purple", "Trade-up output did not move to the next tier.")
	var sale: Dictionary = service.arm_sale(MetaCollectionServiceScript.SALE_KIND_ITEM, int(output.get("instance_id", 0)))
	_check(bool(sale.get("ok", false)) and int(sale.get("price", 0)) > 0, "Pawn sale did not produce a deterministic item quote.")
	var sale_result: Dictionary = service.confirm_sale(str(sale.get("token", "")))
	_check(bool(sale_result.get("ok", false)) and int(sale_result.get("gold_balance", 0)) > 0, "Pawn sale did not mint gold on confirmation.")
	_check(service.owned_instances().is_empty(), "Pawn sale did not remove the sold item.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_failure_decay_and_run_modifiers(resolver: Variant) -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var granted: Dictionary = service.grant_instance(resolver.roll_instance(1000, "failure-decay"))
	var modifiers: Dictionary = service.normal_run_start_modifiers()
	_check(str(modifiers.get("home_archetype_id", "")) == MetaCollectionServiceScript.HOUSING_BACK_ALLEY, "Homeless normal run must start at the back alley archetype.")
	_check(JsonCoerceScript._copy_array(modifiers.get("meta_collection_carried_instance_ids", [])).has(int(granted.get("instance_id", 0))), "Homeless normal run must carry every owned item.")
	_check(JsonCoerceScript._copy_array(modifiers.get("meta_collection_loadout", [])).size() == 1, "Normal run modifiers did not inject resolved run items.")
	var before_condition := float(granted.get("condition", 0.0))
	var decayed: Array = service.apply_failure_decay([int(granted.get("instance_id", 0))], "failure-decay-seed")
	var after := JsonCoerceScript._copy_dict(decayed[0]) if not decayed.is_empty() else {}
	_check(is_equal_approx(float(after.get("condition", 1.0)), maxf(0.0, before_condition - MetaCollectionServiceScript.FAILURE_DURABILITY_LOSS)), "Failure decay did not reduce carried item condition by 10%.")
	var fragile := after.duplicate(true)
	fragile["condition"] = 0.05
	var fragile_grant: Dictionary = service.grant_instance(fragile)
	var fragile_id := int(fragile_grant.get("instance_id", 0))
	service.apply_failure_decay([fragile_id], "failure-delete-seed")
	_check(not _instance_ids(service.owned_instances()).has(fragile_id), "Failure decay did not delete a zero-condition carried item.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_players_card_mint_and_profile_lifecycle() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var drop_service: Variant = CollectionDropServiceScript.new()
	var clean_run: Variant = _terminal_run("players-card-clean")
	clean_run.narrative_flags["demo_victory_route"] = RunStateScript.GRAND_CASINO_HIGH_ROLLER_EVENT_ID
	clean_run.narrative_flags["grand_casino_players_card_tier"] = RunStateScript.GRAND_CASINO_PLAYERS_CARD_TIER_GOLD
	clean_run.narrative_flags["grand_casino_players_card_highest_tier"] = RunStateScript.GRAND_CASINO_PLAYERS_CARD_TIER_GOLD
	clean_run.run_spending_score = 37
	clean_run.game_clock_minutes = 1440 + 900
	clean_run.log_story({"type": "grand_casino_players_card_tier", "tier": "bronze", "games_played": 1, "net_winnings": 5})
	clean_run.log_story({"type": "grand_casino_players_card_tier", "tier": "silver", "games_played": 3, "net_winnings": 15})
	clean_run.log_story({"type": "grand_casino_players_card_tier", "tier": "gold", "games_played": 5, "net_winnings": 30})
	var mint_result: Dictionary = drop_service.apply_terminal_special_outcome(clean_run, service)
	var mint_repeat: Dictionary = drop_service.apply_terminal_special_outcome(clean_run, service)
	_check(bool(mint_result.get("mutated", false)) and not bool(mint_repeat.get("mutated", true)), "Clean win did not mint exactly one Players Card.")
	var owned: Array = service.owned_instances()
	_check(owned.size() == 1, "Clean win did not add one Players Card instance to the profile.")
	var card := JsonCoerceScript._copy_dict(owned[0]) if not owned.is_empty() else {}
	var stamp := JsonCoerceScript._copy_dict(card.get("instance_data", {}))
	_check(
		str(stamp.get("seed", "")) == "players-card-clean" and int(stamp.get("final_score", 0)) == int(clean_run.terminal_score_summary().get("score", 0)) and int(stamp.get("days_survived", 0)) == 2,
		"Players Card stamp did not preserve seed, score, and days: %s" % JSON.stringify(stamp)
	)
	_check(JsonCoerceScript._copy_array(stamp.get("tier_timeline", [])).size() == 3 and str(stamp.get("route", "")) == RunStateScript.GRAND_CASINO_HIGH_ROLLER_EVENT_ID, "Players Card stamp did not preserve tier timeline and route.")
	var report_reward := JsonCoerceScript._copy_dict(RunReportViewModelScript.build(clean_run.to_dict()).get("meta_reward", {}))
	_check(bool(report_reward.get("visible", false)) and str(report_reward.get("kind", "")) == "players_card_minted", "Run report did not surface the minted Players Card in RESULT.")
	var showdown_run: Variant = _terminal_run("players-card-showdown")
	drop_service.apply_terminal_special_outcome(showdown_run, service)
	var failed_run: Variant = _terminal_run("players-card-failed")
	failed_run.run_status = RunStateScript.RUN_STATUS_FAILED
	drop_service.apply_terminal_special_outcome(failed_run, service)
	_check(service.owned_instances().size() == 1, "Showdown or failed route incorrectly minted a Players Card.")
	var save_error: Error = service.save()
	_check(save_error == OK, "Players Card profile save failed.")
	var restored_service: Variant = MetaCollectionServiceScript.new()
	restored_service.load()
	_check(restored_service.owned_instances().size() == 1, "Players Card did not survive profile restart.")
	var prestige_modifiers: Dictionary = restored_service.normal_run_start_modifiers()
	var prestige_win: Variant = _terminal_run_with_modifiers("players-card-survival", prestige_modifiers, RunStateScript.RUN_STATUS_ENDED, RunStateScript.GRAND_CASINO_SHOWDOWN_ROUTE)
	drop_service.apply_terminal_special_outcome(prestige_win, restored_service)
	_check(restored_service.owned_instances().size() == 1 and str(JsonCoerceScript._copy_dict(prestige_win.narrative_flags.get(CollectionDropServiceScript.PRESTIGE_RESULT_FLAG, {})).get("status", "")) == "retained", "Carried Players Card was not retained after a successful prestige run.")
	var prestige_run: Variant = _terminal_run_with_modifiers("players-card-loss", prestige_modifiers, RunStateScript.RUN_STATUS_FAILED, "")
	var loss_result: Dictionary = drop_service.apply_terminal_special_outcome(prestige_run, restored_service)
	_check(JsonCoerceScript._copy_array(loss_result.get("destroyed_cards", [])).size() == 1 and restored_service.owned_instances().is_empty(), "Carried Players Card was not destroyed forever on run loss.")
	_check(restored_service.save() == OK, "Destroyed Players Card profile save failed.")
	var post_loss_service: Variant = MetaCollectionServiceScript.new()
	post_loss_service.load()
	_check(post_loss_service.owned_instances().is_empty(), "Destroyed Players Card returned after profile restart.")
	var hidden_service: Variant = MetaCollectionServiceScript.new()
	_remove_user_file(TEST_STORE_PATH)
	hidden_service.load()
	var hidden_run: Variant = _terminal_run("owner-secret-seed")
	hidden_run.challenge_config["hidden_seed"] = true
	hidden_run.narrative_flags["demo_victory_route"] = RunStateScript.GRAND_CASINO_HIGH_ROLLER_EVENT_ID
	drop_service.apply_terminal_special_outcome(hidden_run, hidden_service)
	var hidden_card := JsonCoerceScript._copy_dict(hidden_service.owned_instances()[0]) if not hidden_service.owned_instances().is_empty() else {}
	var hidden_stamp := JsonCoerceScript._copy_dict(hidden_card.get("instance_data", {}))
	_check(bool(hidden_stamp.get("seed_hidden", false)) and str(hidden_stamp.get("seed", "")).find("owner-secret-seed") < 0, "Hidden challenge seed leaked into the Players Card stamp.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_sal_shelf_defaults_and_migration(resolver: Variant) -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	var fresh: Dictionary = service.load()
	if not service.has_method("sal_shelf_rows"):
		_check(false, "Meta collection service is missing the Sal shelf API.")
		_remove_user_file(TEST_STORE_PATH)
		OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")
		return
	var rows: Array = service.sal_shelf_rows()
	_check(rows.size() == 6, "Fresh Sal shelf did not normalize to exactly six slots.")
	var occupied: Array = rows.filter(func(row: Dictionary) -> bool: return bool(row.get("occupied", false)))
	_check(occupied.size() == 1, "Fresh Sal shelf did not contain exactly one starter listing.")
	var starter := JsonCoerceScript._copy_dict(occupied[0]) if not occupied.is_empty() else {}
	var item := JsonCoerceScript._copy_dict(starter.get("item", {}))
	var rare_channel := str(starter.get("starter_rare_channel", ""))
	_check(str(starter.get("listing_mode", "")) == "starter_discount", "Starter listing did not use starter_discount mode.")
	_check(float(item.get("condition", 0.0)) > 0.0 and float(item.get("condition", 1.0)) < 0.30, "Starter condition was not inside (0, .30).")
	_check(["potency", "resonance", "usage"].has(rare_channel) and float(item.get(rare_channel, 1.0)) <= 0.01, "Starter did not record one <=1% non-condition float.")
	_check(not resolver.bag_item_options_for_bag(int(starter.get("virtual_bagdef_id", -1))).filter(func(definition: Dictionary) -> bool: return int(definition.get("itemdef_id", -1)) == int(item.get("itemdef_id", -2))).is_empty(), "Starter is not a valid item for its virtual bag.")
	var before := JSON.stringify(fresh.get("sal_resale", {}))
	_check(service.save() == OK, "Fresh Sal shelf save failed.")
	var restored: Variant = MetaCollectionServiceScript.new()
	var loaded: Dictionary = restored.load()
	_check(JSON.stringify(loaded.get("sal_resale", {})) == before, "Repeated Sal shelf load/save changed starter identity or floats.")
	var legacy_file := FileAccess.open(TEST_STORE_PATH, FileAccess.WRITE)
	if legacy_file != null:
		legacy_file.store_string(JSON.stringify({
			"schema_version": 2,
			"owned_instances": [],
			"unopened_bags": [],
			"gold_balance": 41,
			"housing_tier": "motel_room",
			"owned_containers": [{"item_id": "bag", "instance_id": 0, "capacity": 3}],
			"loadout": [],
			"meta_home": {"housing_tier": "motel_room", "current_location": "home"},
			"unknown_owner_key": {"keep": true},
			"next_instance_id": 12,
		}))
		legacy_file.close()
	var migrated: Variant = MetaCollectionServiceScript.new()
	var migrated_snapshot: Dictionary = migrated.load()
	_check(migrated.sal_shelf_rows().size() == 6 and migrated.sal_shelf_rows().filter(func(row: Dictionary) -> bool: return bool(row.get("occupied", false))).size() == 1, "Legacy store did not receive one starter and six Sal slots.")
	_check(int(migrated_snapshot.get("gold_balance", 0)) == 41 and bool(JsonCoerceScript._copy_dict(migrated_snapshot.get("unknown_owner_key", {})).get("keep", false)), "Sal migration changed legacy gold or dropped an unknown key.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_sal_float_rarity_curve(resolver: Variant) -> void:
	var service: Variant = MetaCollectionServiceScript.new()
	if not service.has_method("ordinary_collection_price_breakdown"):
		_check(false, "Meta collection service is missing the pure Sal rarity evaluator.")
		return
	var definition: Dictionary = resolver.item_definition(1000)
	var base_prices := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(resolver.meta_home_config().get("sale_prices", {})).get("items", {}))
	var base := int(base_prices.get(str(definition.get("tier", "blue")), 0))
	for value in [0.0, 0.01, 0.5, 0.99, 1.0]:
		var edge_instance := {"itemdef_id": 1000, "potency": value, "condition": 0.0, "resonance": 0.5, "usage": 0.5}
		var edge: Dictionary = service.ordinary_collection_price_breakdown(edge_instance)
		var expected_edge := pow(absf(2.0 * value - 1.0), 4.0)
		_check(is_equal_approx(float(JsonCoerceScript._copy_dict(edge.get("rarity_scores", {})).get("potency", -1.0)), expected_edge), "Potency edge fixture %.2f used the wrong fourth-power score." % value)
		_check(int(edge.get("tier_base", -1)) == base, "Rarity evaluator did not use the tier base sale value.")
	var low: Dictionary = service.ordinary_collection_price_breakdown({"itemdef_id": 1000, "potency": 0.01, "condition": 0.0, "resonance": 0.5, "usage": 0.5})
	var high: Dictionary = service.ordinary_collection_price_breakdown({"itemdef_id": 1000, "potency": 0.99, "condition": 0.0, "resonance": 0.5, "usage": 0.5})
	var middle: Dictionary = service.ordinary_collection_price_breakdown({"itemdef_id": 1000, "potency": 0.5, "condition": 0.0, "resonance": 0.5, "usage": 0.5})
	_check(is_equal_approx(float(low.get("rarity_multiplier", 0.0)), float(high.get("rarity_multiplier", -1.0))), "Symmetric .01/.99 float values did not contribute equally.")
	_check(int(low.get("pawn_quote", 0)) > int(middle.get("pawn_quote", 0)), "A 1% non-condition edge was not worth more than 50%.")
	var condition_values: Array = []
	for value in [0.0, 0.01, 0.5, 0.99, 1.0]:
		var condition: Dictionary = service.ordinary_collection_price_breakdown({"itemdef_id": 1000, "potency": 0.5, "condition": value, "resonance": 0.5, "usage": 0.5})
		condition_values.append(float(JsonCoerceScript._copy_dict(condition.get("rarity_scores", {})).get("condition", -1.0)))
		_check(float(condition.get("rarity_multiplier", 0.0)) >= 1.0 and float(condition.get("rarity_multiplier", 4.0)) <= 3.0, "Rarity multiplier left [1,3].")
	_check(condition_values == [0.0, pow(0.01, 4.0), pow(0.5, 4.0), pow(0.99, 4.0), 1.0], "Condition fixtures were not monotonic fourth-power durability.")
	var all_edges := {"itemdef_id": 1000, "potency": 0.0, "condition": 1.0, "resonance": 1.0, "usage": 0.0}
	var all_edges_before := JSON.stringify(all_edges)
	var maximum: Dictionary = service.ordinary_collection_price_breakdown(all_edges)
	_check(is_equal_approx(float(maximum.get("rarity_multiplier", 0.0)), 3.0), "All four maximum rarity contributions did not cap at 3x.")
	_check(JSON.stringify(all_edges) == all_edges_before, "Pure Sal quote evaluation mutated its input instance.")
	for channel in ["potency", "resonance", "usage"]:
		for value in [0.0, 0.01, 0.5, 0.99, 1.0]:
			var fixture := {"itemdef_id": 1000, "potency": 0.5, "condition": 0.0, "resonance": 0.5, "usage": 0.5}
			fixture[channel] = value
			var breakdown: Dictionary = service.ordinary_collection_price_breakdown(fixture)
			var expected_contribution := 0.5 * pow(absf(2.0 * value - 1.0), 4.0)
			_check(is_equal_approx(float(JsonCoerceScript._copy_dict(breakdown.get("rarity_contributions", {})).get(channel, -1.0)), expected_contribution), "%s %.2f used the wrong edge contribution." % [channel.capitalize(), value])
	var middle_instance := {"itemdef_id": 1000, "potency": 0.5, "condition": 0.0, "resonance": 0.5, "usage": 0.5}
	var normal: Dictionary = service.ordinary_collection_price_breakdown(middle_instance, "normal")
	var starter: Dictionary = service.ordinary_collection_price_breakdown(middle_instance, "starter_discount")
	_check(int(normal.get("final_price", 0)) == maxi(int(normal.get("pawn_quote", 0)) + 1, int(ceil(float(normal.get("pawn_quote", 0)) * 1.5))), "Normal listing did not use the exact ceiling/quote+1 rule.")
	_check(int(starter.get("final_price", 0)) == maxi(1, int(round(float(starter.get("pawn_quote", 0)) * 0.75))), "Starter listing did not use the exact 0.75x rounding rule.")


func _test_sal_stocking_and_idempotency() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var drop_service: Variant = CollectionDropServiceScript.new()
	if not drop_service.has_method("stock_sal_after_success"):
		_check(false, "Collection drop service is missing all-success Sal stocking.")
		_remove_user_file(TEST_STORE_PATH)
		OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")
		return
	var success: Variant = _terminal_run("sal-stock-standard")
	var first: Dictionary = drop_service.stock_sal_after_success(success, service)
	var repeat: Dictionary = drop_service.stock_sal_after_success(success, service)
	_check(bool(first.get("stocked", false)) and not bool(repeat.get("stocked", true)), "One successful run did not stock Sal exactly once.")
	_check(service.sal_shelf_rows().filter(func(row: Dictionary) -> bool: return bool(row.get("occupied", false))).size() == 2, "First success did not fill the lowest empty shelf slot.")
	var daily: Variant = _terminal_run("sal-stock-daily", "", false, "daily")
	var challenge: Variant = _terminal_run("sal-stock-challenge", "challenge_sal", false, "custom")
	var tutorial: Variant = _terminal_run("sal-stock-tutorial", "tutorial_sal", false, "custom")
	_check(bool(drop_service.stock_sal_after_success(daily, service).get("stocked", false)), "Meta-disabled daily victory did not stock Sal.")
	_check(bool(drop_service.stock_sal_after_success(challenge, service).get("stocked", false)), "Meta-disabled challenge victory did not stock Sal.")
	_check(bool(drop_service.stock_sal_after_success(tutorial, service).get("stocked", false)), "Meta-disabled tutorial victory did not stock Sal.")
	var failed: Variant = _terminal_run("sal-stock-failed")
	failed.run_status = RunStateScript.RUN_STATUS_FAILED
	var before_failed := JSON.stringify(service.sal_shelf_rows())
	_check(not bool(drop_service.stock_sal_after_success(failed, service).get("stocked", false)) and JSON.stringify(service.sal_shelf_rows()) == before_failed, "Failed run changed Sal stock.")
	var nonterminal: Variant = _terminal_run("sal-stock-active")
	nonterminal.run_status = RunStateScript.RUN_STATUS_ACTIVE
	_check(not bool(drop_service.stock_sal_after_success(nonterminal, service).get("stocked", false)) and JSON.stringify(service.sal_shelf_rows()) == before_failed, "Nonterminal run changed Sal stock.")
	var same_seed_new: Variant = _terminal_run("sal-stock-standard")
	_check(bool(drop_service.stock_sal_after_success(same_seed_new, service).get("stocked", false)), "A genuine new same-seed run did not stock again.")
	var rng_before := JSON.stringify(service.sal_resale_rng_snapshot())
	service.sal_shelf_rows()
	service.sal_shelf_row(0)
	service.snapshot()
	_check(JSON.stringify(service.sal_resale_rng_snapshot()) == rng_before, "Sal shelf views or snapshots consumed RNG.")
	while service.sal_shelf_rows().filter(func(row: Dictionary) -> bool: return bool(row.get("occupied", false))).size() < 6:
		var fill_index: int = service.sal_shelf_rows().filter(func(row: Dictionary) -> bool: return bool(row.get("occupied", false))).size()
		service.generate_and_insert_sal_stock("fill:%d" % fill_index)
	var full_before: Array = service.sal_shelf_rows()
	var protected_id := int(JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(full_before[0]).get("item", {})).get("instance_id", 0))
	var replacement: Dictionary = service.generate_and_insert_sal_stock("full:replacement")
	var full_after: Array = service.sal_shelf_rows()
	var changed_slots := 0
	for index in range(6):
		if int(JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(full_before[index]).get("item", {})).get("instance_id", 0)) != int(JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(full_after[index]).get("item", {})).get("instance_id", 0)):
			changed_slots += 1
	_check(bool(replacement.get("stocked", false)) and changed_slots == 1, "Full Sal shelf did not replace exactly one eligible slot.")
	_check(int(JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(full_after[0]).get("item", {})).get("instance_id", 0)) == protected_id, "Full-shelf replacement removed the protected starter.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_sal_purchase_and_starter_buyback() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	var resolver: Variant = CollectionItemResolverScript.new()
	service.load()
	if not service.has_method("arm_sal_shelf_purchase") or not service.has_method("resolve_starter_buyback"):
		_check(false, "Meta collection service is missing Sal purchase/buyback transaction APIs.")
		_remove_user_file(TEST_STORE_PATH)
		OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")
		return
	var starter_rows: Array = service.sal_shelf_rows().filter(func(row: Dictionary) -> bool: return bool(row.get("occupied", false)))
	var starter := JsonCoerceScript._copy_dict(starter_rows[0]) if not starter_rows.is_empty() else {}
	var slot_index := int(starter.get("slot_index", -1))
	var starter_item := JsonCoerceScript._copy_dict(starter.get("item", {}))
	var price := int(starter.get("asking_price", 0))
	service.add_gold(price)
	var armed: Dictionary = service.arm_sal_shelf_purchase(slot_index)
	var bought: Dictionary = service.confirm_sal_shelf_purchase(str(armed.get("token", "")))
	_check(bool(bought.get("ok", false)) and int(service.snapshot().get("gold_balance", -1)) == 0, "Starter purchase did not debit the exact asking price once.")
	var owned: Array = service.owned_instances()
	var purchased := JsonCoerceScript._copy_dict(owned[0]) if not owned.is_empty() else {}
	_check(owned.size() == 1 and int(purchased.get("instance_id", 0)) == int(starter_item.get("instance_id", -1)) and JSON.stringify(purchased) == JSON.stringify(starter_item), "Starter purchase did not transfer the exact persistent instance and floats.")
	var pending: Dictionary = service.pending_starter_buyback()
	_check(not pending.is_empty() and int(pending.get("offer_price", 0)) == int(ceil(float(pending.get("pawn_quote", 0)) * 1.25)), "Starter purchase did not persist the exact 1.25x pending offer.")
	_check(service.save() == OK, "Pending starter offer save failed.")
	var pending_restored: Variant = MetaCollectionServiceScript.new()
	pending_restored.load()
	_check(JSON.stringify(pending_restored.pending_starter_buyback()) == JSON.stringify(pending), "Pending starter offer did not survive profile reload exactly.")
	service = pending_restored
	var sold_back: Dictionary = service.resolve_starter_buyback("sell_back")
	var repeated: Dictionary = service.resolve_starter_buyback("sell_back")
	var relisted: Dictionary = service.sal_shelf_row(slot_index)
	_check(bool(sold_back.get("ok", false)) and not bool(repeated.get("ok", true)), "Starter buyback did not resolve exactly once.")
	_check(service.owned_instances().is_empty() and int(JsonCoerceScript._copy_dict(relisted.get("item", {})).get("instance_id", 0)) == int(starter_item.get("instance_id", -1)), "Buyback did not return the exact starter instance to its original slot.")
	_check(str(relisted.get("listing_mode", "")) == "mocking_relist" and int(relisted.get("asking_price", 0)) == int(ceil(float(sold_back.get("pawn_quote", 0)) * 10.0)), "Accepted starter buyback did not create the exact 10x mocking relist.")
	_check(int(service.snapshot().get("gold_balance", -1)) == int(sold_back.get("offer_price", -2)), "Starter buyback did not pay the exact one-time offer.")
	var relist_price := int(relisted.get("asking_price", 0))
	service.add_gold(relist_price)
	var relist_arm: Dictionary = service.arm_sal_shelf_purchase(slot_index)
	var repurchased: Dictionary = service.confirm_sal_shelf_purchase(str(relist_arm.get("token", "")))
	_check(bool(repurchased.get("ok", false)) and service.pending_starter_buyback().is_empty(), "Repurchasing the 10x relist retriggered the starter offer.")
	var shelf_before_sale := JSON.stringify(service.sal_shelf_rows())
	var sale_arm: Dictionary = service.arm_sale("item", int(starter_item.get("instance_id", 0)))
	var sale_result: Dictionary = service.confirm_sale(str(sale_arm.get("token", "")))
	_check(bool(sale_result.get("ok", false)) and JSON.stringify(service.sal_shelf_rows()) == shelf_before_sale, "Ordinary player sale copied or referenced the sold item on Sal's shelf.")

	_remove_user_file(TEST_STORE_PATH)
	var keep_service: Variant = MetaCollectionServiceScript.new()
	keep_service.load()
	var keep_starter := JsonCoerceScript._copy_dict(keep_service.sal_shelf_rows()[0])
	var keep_price := int(keep_starter.get("asking_price", 0))
	keep_service.add_gold(keep_price + 7)
	var keep_arm: Dictionary = keep_service.arm_sal_shelf_purchase(0)
	keep_service.confirm_sal_shelf_purchase(str(keep_arm.get("token", "")))
	var keep_owned_before := JSON.stringify(keep_service.owned_instances())
	var keep_gold_before := int(keep_service.snapshot().get("gold_balance", -1))
	var kept: Dictionary = keep_service.resolve_starter_buyback("keep")
	_check(bool(kept.get("ok", false)) and JSON.stringify(keep_service.owned_instances()) == keep_owned_before and int(keep_service.snapshot().get("gold_balance", -2)) == keep_gold_before, "Keep choice changed starter ownership or gold.")
	_check(not bool(keep_service.resolve_starter_buyback("keep").get("ok", true)), "Keep choice did not permanently resolve the starter offer.")

	_remove_user_file(TEST_STORE_PATH)
	var failure_service: Variant = MetaCollectionServiceScript.new()
	failure_service.load()
	var failure_starter := JsonCoerceScript._copy_dict(failure_service.sal_shelf_rows()[0])
	var failure_price := int(failure_starter.get("asking_price", 0))
	var insufficient_before := JSON.stringify(failure_service.snapshot())
	_check(not bool(failure_service.arm_sal_shelf_purchase(0).get("ok", true)) and JSON.stringify(failure_service.snapshot()) == insufficient_before, "Insufficient-gold purchase mutated profile state.")
	failure_service.add_gold(failure_price)
	failure_service.arm_sal_shelf_purchase(0)
	var stale_before := JSON.stringify(failure_service.snapshot())
	_check(not bool(failure_service.confirm_sal_shelf_purchase("stale-token").get("ok", true)) and JSON.stringify(failure_service.snapshot()) == stale_before, "Stale shelf token mutated profile state.")

	_remove_user_file(TEST_STORE_PATH)
	var full_service: Variant = MetaCollectionServiceScript.new()
	full_service.load()
	full_service.grant_container("bag")
	for seed_index in range(full_service.total_owned_capacity()):
		full_service.grant_instance(resolver.roll_instance(1000, "sal-capacity-%d" % seed_index))
	var full_starter := JsonCoerceScript._copy_dict(full_service.sal_shelf_rows()[0])
	full_service.add_gold(int(full_starter.get("asking_price", 0)))
	var capacity_before := JSON.stringify(full_service.sal_shelf_rows())
	_check(not bool(full_service.arm_sal_shelf_purchase(0).get("ok", true)) and JSON.stringify(full_service.sal_shelf_rows()) == capacity_before, "Full owned-item capacity allowed or mutated a shelf purchase.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_tutorial_starter_card_fragility() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	service.add_gold(60)
	_check(bool(service.purchase_housing_upgrade().get("ok", false)), "Tutorial starter-card fixture could not prepare an upgraded home.")
	var drop_service: Variant = CollectionDropServiceScript.new()
	var tutorial_run: Variant = RunStateScript.new()
	tutorial_run.start_new("FIRST-NIGHT-ACE-17", {
		"mode": "custom",
		"id": "tutorial_first_card",
		"seed_text": "FIRST-NIGHT-ACE-17",
		"tutorial": true,
		"exclude_profile_stats": true,
		"completion_flag": "challenge_tutorial_first_card_complete",
		"modifiers": {"tutorial_run": true, "tutorial_main_floor_only": true},
	})
	tutorial_run.run_status = RunStateScript.RUN_STATUS_ENDED
	tutorial_run.narrative_flags["demo_victory"] = true
	tutorial_run.narrative_flags["demo_victory_route"] = RunStateScript.GRAND_CASINO_HIGH_ROLLER_EVENT_ID
	tutorial_run.narrative_flags["grand_casino_players_card_tier"] = RunStateScript.GRAND_CASINO_PLAYERS_CARD_TIER_GOLD
	var reward: Dictionary = drop_service.apply_terminal_special_outcome(tutorial_run, service)
	var owned: Array = service.owned_instances()
	var card := JsonCoerceScript._copy_dict(owned[0]) if not owned.is_empty() else {}
	var stamp := JsonCoerceScript._copy_dict(card.get("instance_data", {}))
	_check(bool(reward.get("mutated", false)) and owned.size() == 1 and bool(stamp.get("starter_card", false)) and bool(stamp.get("tutorial", false)), "Tutorial clean victory did not mint one starter-stamped Players Card.")
	var card_id := int(card.get("instance_id", 0))
	_check(service.carried_instance_ids().has(card_id), "Tutorial Players Card was stored at home instead of entering the held loadout.")
	var repeated_card: Dictionary = service.mint_players_card(stamp)
	_check(int(repeated_card.get("instance_id", 0)) == card_id and service.owned_instances().size() == 1, "Replaying the first-run reward duplicated the tutorial Players Card.")
	_check(service.save() == OK, "Tutorial Players Card home/loadout save failed.")
	var legacy_home: Dictionary = service.snapshot()
	legacy_home["loadout"] = []
	legacy_home.erase("starter_card_home_grant_applied")
	var legacy_file := FileAccess.open(TEST_STORE_PATH, FileAccess.WRITE)
	if legacy_file != null:
		legacy_file.store_string(JSON.stringify(legacy_home))
		legacy_file.close()
	var restored: Variant = MetaCollectionServiceScript.new()
	restored.load()
	_check(restored.owned_instances().size() == 1 and restored.carried_instance_ids().has(card_id), "Tutorial Players Card disappeared from the held home inventory after restart.")
	var home_inventory: Dictionary = MetaItemInteractionViewModelScript.build(restored, MetaItemInteractionViewModelScript.MODE_CONTAINER)
	var home_items := JsonCoerceScript._copy_array(home_inventory.get("items", []))
	var home_card := JsonCoerceScript._copy_dict(home_items[0]) if not home_items.is_empty() else {}
	_check(home_items.size() == 1 and int(home_card.get("instance_id", 0)) == card_id and str(home_card.get("item_class", "")) == CollectionItemResolverScript.ITEM_CLASS_PLAYERS_CARD and bool(home_card.get("packed", false)), "Home inventory did not render the exact tutorial Players Card as held.")
	_check(bool(restored.unpack_instance(card_id).get("ok", false)) and restored.save() == OK, "Tutorial Players Card could not be deliberately unpacked after its initial home grant.")
	var unpacked_restore: Variant = MetaCollectionServiceScript.new()
	unpacked_restore.load()
	_check(not unpacked_restore.carried_instance_ids().has(card_id), "Starter-card migration overrode the player's later choice to unpack it.")
	unpacked_restore.ensure_players_card_carried(card_id)
	restored = unpacked_restore
	var normal_modifiers: Dictionary = restored.normal_run_start_modifiers()
	var normal_loadout := JsonCoerceScript._copy_array(normal_modifiers.get("meta_collection_loadout", []))
	var carried_card := JsonCoerceScript._copy_dict(normal_loadout[0]) if not normal_loadout.is_empty() else {}
	_check(normal_loadout.size() == 1 and str(JsonCoerceScript._copy_dict(carried_card.get("meta_collection", {})).get("item_class", "")) == CollectionItemResolverScript.ITEM_CLASS_PLAYERS_CARD, "First normal run did not receive the held tutorial Players Card as an inventory item.")
	var normal_loss: Variant = _terminal_run_with_modifiers("starter-card-loss", normal_modifiers, RunStateScript.RUN_STATUS_FAILED, "")
	var loss_result: Dictionary = drop_service.apply_terminal_special_outcome(normal_loss, restored)
	_check(JsonCoerceScript._copy_array(loss_result.get("destroyed_cards", [])).size() == 1 and restored.owned_instances().is_empty(), "Starter Players Card did not use normal carried-card fragility on a later loss.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_uncashed_grand_casino_chips_pawn_flow() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var drop_service: Variant = CollectionDropServiceScript.new()
	var shown_run: Variant = _terminal_run("shown-door-chip-stack")
	shown_run.bankroll = 123
	shown_run.grand_casino_chips = 37
	shown_run.narrative_flags["grand_casino_walked_with_chips"] = true
	shown_run.narrative_flags["grand_casino_duel_outcome"] = "shown_the_door"
	shown_run.narrative_flags["grand_casino_uncashed_chip_amount"] = 37
	var grant_result: Dictionary = drop_service.apply_terminal_special_outcome(shown_run, service)
	var repeated_result: Dictionary = drop_service.apply_terminal_special_outcome(shown_run, service)
	_check(bool(grant_result.get("mutated", false)) and not bool(repeated_result.get("mutated", true)), "Shown-door ending did not grant exactly one chip stack.")
	var owned: Array = service.owned_instances()
	_check(owned.size() == 1, "Shown-door ending did not add one Grand Casino Chips stack to meta storage.")
	var chip_stack := JsonCoerceScript._copy_dict(owned[0]) if not owned.is_empty() else {}
	_check(str(chip_stack.get("item_class", "")) == CollectionItemResolverScript.ITEM_CLASS_CHIP_STACK and int(chip_stack.get("stack_amount", 0)) == 37 and int(chip_stack.get("face_value", 0)) == 37, "Grand Casino Chips stack did not preserve the exact uncashed amount as face value.")
	var run_modifiers: Dictionary = service.normal_run_start_modifiers()
	_check(not JsonCoerceScript._copy_array(run_modifiers.get("meta_collection_carried_instance_ids", [])).has(int(chip_stack.get("instance_id", 0))) and JsonCoerceScript._copy_array(run_modifiers.get("meta_collection_loadout", [])).is_empty(), "Grand Casino Chips leaked from meta storage into a run loadout.")
	var markers: Array = drop_service.ensure_run_end_pending_bags(shown_run, null)
	_check(not markers.is_empty(), "Shown-door chip stack was not granted alongside the existing run-end drop flow.")
	var report_reward := JsonCoerceScript._copy_dict(RunReportViewModelScript.build(shown_run.to_dict()).get("meta_reward", {}))
	_check(str(report_reward.get("kind", "")) == "grand_casino_chips" and str(report_reward.get("title", "")).contains("×37"), "Run report did not surface the uncashed Grand Casino Chips stack.")
	_check(service.save() == OK, "Grand Casino Chips profile save failed.")
	var restored: Variant = MetaCollectionServiceScript.new()
	restored.load()
	var restored_owned: Array = restored.owned_instances()
	_check(restored_owned.size() == 1 and int(JsonCoerceScript._copy_dict(restored_owned[0]).get("face_value", 0)) == 37, "Grand Casino Chips did not survive profile restart with exact face value.")
	var instance_id := int(JsonCoerceScript._copy_dict(restored_owned[0]).get("instance_id", 0)) if not restored_owned.is_empty() else 0
	var quote: Dictionary = restored.sale_quote(MetaCollectionServiceScript.SALE_KIND_ITEM, instance_id)
	_check(bool(quote.get("ok", false)) and int(quote.get("price", 0)) == 22 and is_equal_approx(float(quote.get("gold_rate", 0.0)), 0.6), "Sal did not price the 37-chip stack at the tuned 60% fenced rate.")
	var run_cash_before: int = shown_run.bankroll
	var run_chips_before: int = shown_run.grand_casino_chips
	var armed: Dictionary = restored.arm_sale(MetaCollectionServiceScript.SALE_KIND_ITEM, instance_id)
	var sold: Dictionary = restored.confirm_sale(str(armed.get("token", "")))
	_check(bool(sold.get("ok", false)) and int(sold.get("gold_balance", 0)) == 22 and restored.owned_instances().is_empty(), "Sal's existing sale flow did not consume the chip stack and grant fenced gold.")
	_check(shown_run.bankroll == run_cash_before and shown_run.grand_casino_chips == run_chips_before, "Selling the meta chip stack mutated run cash or run chips.")
	var clean_showdown: Variant = _terminal_run("clean-showdown-no-chip-stack")
	drop_service.apply_terminal_special_outcome(clean_showdown, restored)
	var failed_showdown: Variant = _terminal_run("failed-showdown-no-chip-stack")
	failed_showdown.run_status = RunStateScript.RUN_STATUS_FAILED
	failed_showdown.narrative_flags["grand_casino_walked_with_chips"] = true
	failed_showdown.narrative_flags["grand_casino_duel_outcome"] = "taken_out_back"
	failed_showdown.narrative_flags["grand_casino_uncashed_chip_amount"] = 99
	drop_service.apply_terminal_special_outcome(failed_showdown, restored)
	_check(restored.owned_instances().is_empty(), "Clean or failed showdown route incorrectly granted a Grand Casino Chips stack.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_prestige_run_modifiers_and_drop_depth() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var ordinary: Variant = MetaCollectionServiceScript.new()
	ordinary.load()
	var ordinary_modifiers: Dictionary = ordinary.normal_run_start_modifiers()
	_check(not bool(ordinary_modifiers.get("grand_casino_prestige", false)), "Non-prestige profile received prestige run modifiers.")
	ordinary.mint_players_card({"seed": "prestige-origin", "final_score": 80, "days_survived": 2, "tier_timeline": [], "route": RunStateScript.GRAND_CASINO_HIGH_ROLLER_EVENT_ID})
	var prestige_modifiers: Dictionary = ordinary.normal_run_start_modifiers()
	_check(bool(prestige_modifiers.get("grand_casino_prestige", false)), "Carried Players Card did not mark the run as prestige.")
	_check(int(prestige_modifiers.get("grand_casino_prestige_recognition_heat_delta", 0)) < 0 and int(prestige_modifiers.get("grand_casino_prestige_clean_heat_ceiling_delta", 0)) < 0 and int(prestige_modifiers.get("meta_collection_drop_tier_bonus_steps", 0)) > 0, "Prestige tunables were not injected into run modifiers.")
	var prestige_run: Variant = RunStateScript.new()
	prestige_run.start_new("prestige-entry", {
		"mode": "standard",
		"id": "standard",
		"seed_text": "prestige-entry",
		"modifiers": prestige_modifiers,
	})
	prestige_run.suspicion["local_levels"] = {RunStateScript.GRAND_CASINO_ARCHETYPE_ID: 20}
	prestige_run.set_environment(_grand_casino_environment_fixture())
	var prestige_status: Dictionary = prestige_run.grand_casino_prestige_status()
	var objective: Dictionary = prestige_run.demo_objective_status()
	_check(bool(prestige_status.get("recognition_applied", false)) and prestige_run.suspicion_level() == 10, "Prestige recognition did not reduce initial Grand Casino attention by the tuned amount.")
	_check(int(objective.get("high_roller_max_heat", 30)) == 25 and int(objective.get("players_card_next_max_heat", 30)) == 25, "Prestige expectations did not tighten the clean-route heat ceiling.")
	var drop_service: Variant = CollectionDropServiceScript.new()
	var regular_drop_run: Variant = _terminal_run("prestige-drop-depth")
	var prestige_drop_run: Variant = _terminal_run_with_modifiers("prestige-drop-depth", prestige_modifiers, RunStateScript.RUN_STATUS_ENDED, RunStateScript.GRAND_CASINO_SHOWDOWN_ROUTE)
	var regular_markers: Array = drop_service.ensure_run_end_pending_bags(regular_drop_run, null)
	var prestige_markers: Array = drop_service.ensure_run_end_pending_bags(prestige_drop_run, null)
	_check(regular_markers.size() == prestige_markers.size() and not regular_markers.is_empty(), "Prestige drop comparison did not produce matching deterministic marker counts.")
	for index in range(mini(regular_markers.size(), prestige_markers.size())):
		var regular_marker := JsonCoerceScript._copy_dict(regular_markers[index])
		var regular_rolled_tier := str(regular_marker.get("rolled_tier", ""))
		var regular_tier := str(regular_marker.get("tier", ""))
		_check(regular_tier == regular_rolled_tier and int(regular_marker.get("tier_bonus_steps", -1)) == 0, "Non-prestige drop changed its existing deterministic tier roll.")
		var prestige_marker := JsonCoerceScript._copy_dict(prestige_markers[index])
		var prestige_rolled_tier := str(prestige_marker.get("rolled_tier", ""))
		var prestige_tier := str(prestige_marker.get("tier", ""))
		var bonus_steps := int(prestige_modifiers.get("meta_collection_drop_tier_bonus_steps", 0))
		var expected_index := mini(CollectionItemResolverScript.TIERS.size() - 1, CollectionItemResolverScript.TIERS.find(prestige_rolled_tier) + bonus_steps)
		_check(int(prestige_marker.get("tier_bonus_steps", -1)) == bonus_steps and CollectionItemResolverScript.TIERS.find(prestige_tier) == expected_index, "Prestige drop did not promote its existing deterministic tier roll.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_terminal_drop_determinism() -> void:
	var drop_service: Variant = CollectionDropServiceScript.new()
	var run_a: Variant = _terminal_run("p1-deterministic-seed")
	var run_b: Variant = _terminal_run("p1-deterministic-seed")
	var markers_a: Array = drop_service.ensure_run_end_pending_bags(run_a, null)
	var markers_b: Array = drop_service.ensure_run_end_pending_bags(run_b, null)
	_check(not markers_a.is_empty(), "Terminal victory did not create a pending collection bag marker.")
	_check(JSON.stringify(markers_a) == JSON.stringify(markers_b), "Same seed and outcome did not produce identical pending bag drops.")
	var restored: Variant = RunStateScript.new()
	restored.from_dict(run_a.to_dict())
	_check(JSON.stringify(restored.pending_bag_markers()) == JSON.stringify(markers_a), "Pending bag markers did not round-trip through RunState save data.")


func _test_victory_selection_grants_one_bag() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var drop_service: Variant = CollectionDropServiceScript.new()
	var run_state: Variant = _terminal_run("p1-grant-seed")
	var markers: Array = drop_service.ensure_run_end_pending_bags(run_state, null)
	_check(markers.size() >= 2, "Standard meta victory plus showdown should create at least two pending bags.")
	var selected := JsonCoerceScript._copy_dict(markers[0])
	var flush_result: Dictionary = drop_service.flush_selected_pending_bag(run_state, service, str(selected.get("marker_id", "")))
	_check(JsonCoerceScript._copy_array(flush_result.get("granted", [])).size() == 1, "Victory extraction did not grant exactly one selected bag.")
	_check(run_state.pending_bag_markers().is_empty(), "Run-end flush did not clear pending bag markers.")
	_check(bool(run_state.narrative_flags.get(CollectionDropServiceScript.FLUSHED_FLAG, false)), "Run-end flush flag was not recorded.")
	var save_error: Error = service.save()
	_check(save_error == OK, "Meta collection store save after run-end grant failed.")
	var loaded_service: Variant = MetaCollectionServiceScript.new()
	var loaded: Dictionary = loaded_service.load()
	_check(JsonCoerceScript._copy_array(loaded.get("unopened_bags", [])).size() == 1, "Selected bag did not survive meta store reload as the only grant.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_failed_run_discards_pending_bags() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var drop_service: Variant = CollectionDropServiceScript.new()
	var run_state: Variant = _terminal_run("p1-failure-pending")
	run_state.run_status = RunStateScript.RUN_STATUS_FAILED
	run_state.add_pending_bag_marker(drop_service.marker_from_static_bag(9000, "legacy_event", "removed_bag_marker", "failure-bag"))
	var flush_result: Dictionary = drop_service.flush_pending_bags(run_state, service)
	_check(JsonCoerceScript._copy_array(flush_result.get("granted", [])).is_empty(), "Failed run must not grant pending bag rewards.")
	_check(run_state.pending_bag_markers().is_empty(), "Failed run did not discard pending bag markers.")
	_check(service.unopened_bags().is_empty(), "Failed run leaked an unopened bag into meta storage.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_daily_and_challenge_runs_are_meta_isolated() -> void:
	var drop_service: Variant = CollectionDropServiceScript.new()
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var before_json := JSON.stringify(service.snapshot())
	var daily: Variant = _terminal_run("daily-meta-isolated", "", false, "daily")
	var authored: Variant = _terminal_run("challenge-meta-isolated", "challenge_complete", false, "custom")
	_check(drop_service.ensure_run_end_pending_bags(daily, null).is_empty(), "Daily runs must not create pending meta bags.")
	_check(drop_service.ensure_run_end_pending_bags(authored, null).is_empty(), "Challenge runs must not create pending meta bags.")
	drop_service.flush_pending_bags(daily, service)
	drop_service.flush_pending_bags(authored, service)
	_check(JSON.stringify(service.snapshot()) == before_json, "Daily/challenge flush must not mutate meta collection storage.")


func _test_open_bag_consumes_once() -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	var granted: Dictionary = service.grant_bag(9000, "p1-open-seed", {"display_name": "Roadside Luck Blue Bag"})
	var instance_id := int(granted.get("instance_id", 0))
	var before_rng := JSON.stringify(service.meta_rng_snapshot())
	var first: Dictionary = service.open_bag(instance_id)
	var second: Dictionary = service.open_bag(instance_id)
	var third: Dictionary = service.open_bag(instance_id)
	_check(bool(first.get("ok", false)), "First bag open did not succeed.")
	_check(not bool(second.get("ok", true)) and not bool(third.get("ok", true)), "Repeated bag opens were not rejected.")
	_check(service.unopened_bags().is_empty(), "Opened bag was not removed from unopened storage.")
	_check(service.owned_instances().size() == 1, "Opening one bag did not grant exactly one item instance.")
	_check(JSON.stringify(service.meta_rng_snapshot()) != before_rng, "Opening a bag did not advance the persisted meta RNG stream.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_bag_open_reel_view_model_pins_committed_item(resolver: Variant) -> void:
	var rarity_html := {}
	for tier in TIERS:
		var color := VisualStyle.rarity_outline_color(tier)
		_check(not rarity_html.values().has(color.to_html(false)), "Bag reel rarity outline color was not distinct for %s." % tier)
		rarity_html[tier] = color.to_html(false)
	for tier in TIERS:
		var tier_store_path := "user://collection_meta_check_reel_%s.json" % tier
		OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, tier_store_path)
		_remove_user_file(tier_store_path)
		var service: Variant = MetaCollectionServiceScript.new()
		service.load()
		var bag_defs := JsonCoerceScript._copy_array(resolver.bag_item_definitions("", tier))
		if bag_defs.is_empty():
			failures.append("No bag definition available for reel tier %s." % tier)
			_remove_user_file(tier_store_path)
			continue
		var bag_def := JsonCoerceScript._copy_dict(bag_defs[0])
		var granted_bag: Dictionary = service.grant_bag(int(bag_def.get("itemdef_id", -1)), "reel-earned:%s" % tier, {"display_name": "%s Reel Bag" % tier.capitalize()})
		var before_owned_count: int = service.owned_instances().size()
		var result: Dictionary = service.open_bag(int(granted_bag.get("instance_id", 0)))
		_check(bool(result.get("ok", false)), "Bag open failed before reel model for %s." % tier)
		if not bool(result.get("ok", false)):
			_remove_user_file(tier_store_path)
			continue
		var possible := JsonCoerceScript._copy_array(resolver.bag_item_options_for_bag(int(bag_def.get("itemdef_id", -1))))
		var model: Dictionary = BagOpenReelViewModelScript.build(result, possible, false, "unit:%s" % tier)
		var landing := JsonCoerceScript._copy_dict(BagOpenReelViewModelScript.landing_card(model))
		var item := JsonCoerceScript._copy_dict(result.get("item", {}))
		_check(int(landing.get("itemdef_id", -1)) == int(item.get("itemdef_id", -2)), "Bag reel landing itemdef was not the committed open_bag item for %s." % tier)
		_check(int(landing.get("instance_id", 0)) == int(item.get("instance_id", -1)), "Bag reel landing instance was not the granted item for %s." % tier)
		_check(int(model.get("committed_instance_id", 0)) == int(item.get("instance_id", -1)), "Bag reel model lost committed instance id for %s." % tier)
		_check(int(model.get("landing_index", -1)) == BagOpenReelViewModelScript.LANDING_INDEX, "Bag reel model landing index drifted for %s." % tier)
		_check(JsonCoerceScript._copy_array(model.get("sequence", [])).size() == BagOpenReelViewModelScript.CARD_COUNT, "Bag reel did not precompute its full card sequence for %s." % tier)
		_check(JSON.stringify(BagOpenReelViewModelScript.showcase_itemdef_ids(model)) == JSON.stringify(_itemdef_ids(possible)), "Bag reel showcase did not exactly match possible contents for %s." % tier)
		var reduced: Dictionary = BagOpenReelViewModelScript.build(result, possible, true, "unit:%s" % tier)
		_check(bool(reduced.get("reduce_motion", false)) and float(reduced.get("spin_duration_sec", 1.0)) == 0.0, "Bag reel reduce-motion model still animates for %s." % tier)
		_check(int(JsonCoerceScript._copy_dict(BagOpenReelViewModelScript.landing_card(reduced)).get("instance_id", 0)) == int(item.get("instance_id", -1)), "Bag reel reduce-motion path changed the committed item for %s." % tier)
		_check(service.owned_instances().size() == before_owned_count + 1, "Bag reel model construction double-granted an item for %s." % tier)
		var save_error: Error = service.save()
		_check(save_error == OK, "Bag reel mid-spin save simulation could not save for %s." % tier)
		var reloaded: Variant = MetaCollectionServiceScript.new()
		reloaded.load()
		var matching := 0
		for instance_value in JsonCoerceScript._copy_array(reloaded.owned_instances()):
			if int(JsonCoerceScript._copy_dict(instance_value).get("instance_id", 0)) == int(item.get("instance_id", -1)):
				matching += 1
		_check(matching == 1, "Bag reel mid-spin reload did not preserve exactly one granted item for %s." % tier)
		_remove_user_file(tier_store_path)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_collection_browser_view_model_read_only(resolver: Variant) -> void:
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, TEST_STORE_PATH)
	_remove_user_file(TEST_STORE_PATH)
	var service: Variant = MetaCollectionServiceScript.new()
	service.load()
	service.grant_instance(resolver.roll_instance(1000, "browser-owned-seed"))
	service.grant_bag(9010, "browser-bag-seed", {"display_name": "House Edge Blue Bag"})
	var before_json := JSON.stringify(service.snapshot())
	var view: Dictionary = MetaCollectionViewModelScript.build(service)
	var after_json := JSON.stringify(service.snapshot())
	_check(before_json == after_json, "Collection browser view-model mutated the meta store.")
	_check(JsonCoerceScript._copy_array(view.get("collections", [])).size() == 2, "Collection browser did not list both launch collections.")
	_check(JsonCoerceScript._copy_array(view.get("unopened_bags", [])).size() == 1, "Collection browser did not list unopened bags.")
	_check(int(view.get("owned_count", 0)) == 1, "Collection browser owned count mismatch.")
	var home := JsonCoerceScript._copy_dict(view.get("home", {}))
	_check(str(home.get("housing_tier", "")) == MetaCollectionServiceScript.HOUSING_BACK_ALLEY, "Collection browser did not expose meta home state.")
	_check(str(JsonCoerceScript._copy_dict(home.get("pawn_shop", {})).get("interaction", "")) == "buy_and_sell" and int(JsonCoerceScript._copy_dict(home.get("pawn_shop", {})).get("shelf_slots", 0)) == 6, "Collection browser did not expose Sal's six-slot buy-and-sell shop.")
	_remove_user_file(TEST_STORE_PATH)
	OS.set_environment(MetaCollectionServiceScript.STORE_PATH_ENV, "")


func _test_end_summary_lists_bags() -> void:
	var drop_service: Variant = CollectionDropServiceScript.new()
	var marker: Dictionary = drop_service.marker_from_static_bag(9000, "test", "summary")
	var lines: Array = drop_service.summary_lines_for_markers([marker])
	_check(lines.size() == 1, "Bag summary did not produce one line.")
	var text := str(lines[0]) if not lines.is_empty() else ""
	_check(text.contains("Roadside Luck") and text.contains("Blue"), "Bag summary did not include collection and tier.")


func _terminal_run(seed: String, completion_flag: String = "", meta_enabled: bool = true, mode: String = "standard") -> Variant:
	var run_state: Variant = RunStateScript.new()
	var config := {
		"mode": mode,
		"id": mode if mode != "standard" else "standard",
		"title": "P1 Meta",
		"seed_text": seed,
		"daily_id": "",
		"modifiers": {"meta_collection_enabled": true} if meta_enabled else {},
		"hidden_seed": false,
	}
	if not completion_flag.is_empty():
		config["completion_flag"] = completion_flag
	run_state.start_new(seed, config)
	run_state.bankroll = 500
	run_state.suspicion["level"] = 72
	run_state.run_status = RunStateScript.RUN_STATUS_ENDED
	run_state.narrative_flags["demo_victory"] = true
	run_state.narrative_flags["demo_victory_route"] = RunStateScript.GRAND_CASINO_SHOWDOWN_ROUTE
	return run_state


func _terminal_run_with_modifiers(seed: String, modifiers: Dictionary, status: String, route: String) -> Variant:
	var run_state: Variant = RunStateScript.new()
	run_state.start_new(seed, {
		"mode": "standard",
		"id": "standard",
		"title": "P1 Meta",
		"seed_text": seed,
		"modifiers": modifiers.duplicate(true),
	})
	run_state.bankroll = 500
	run_state.run_status = status
	if status == RunStateScript.RUN_STATUS_ENDED:
		run_state.narrative_flags["demo_victory"] = true
		run_state.narrative_flags["demo_victory_route"] = route
	return run_state


func _grand_casino_environment_fixture() -> Dictionary:
	return {
		"id": RunStateScript.GRAND_CASINO_ARCHETYPE_ID,
		"archetype_id": RunStateScript.GRAND_CASINO_ARCHETYPE_ID,
		"display_name": "Grand Casino",
		"demo_objective": {
			"id": RunStateScript.GRAND_CASINO_OBJECTIVE_ID,
			"type": "bankroll",
			"target_bankroll": 500,
			"high_roller_target_bankroll": 500,
			"high_roller_net_winnings": 30,
			"high_roller_min_grand_casino_games": 5,
			"high_roller_max_heat": 30,
			"players_card_bronze_max_heat": 30,
			"players_card_silver_max_heat": 30,
			"players_card_gold_max_heat": 30,
		},
	}


func _instance_ids(instances: Array) -> Array:
	var ids: Array = []
	for instance_value in instances:
		var instance := JsonCoerceScript._copy_dict(instance_value)
		ids.append(int(instance.get("instance_id", 0)))
	return ids


func _itemdef_ids(definitions: Array) -> Array:
	var ids: Array = []
	for definition_value in definitions:
		var definition := JsonCoerceScript._copy_dict(definition_value)
		ids.append(int(definition.get("itemdef_id", -1)))
	ids.sort()
	return ids


func _item_float_bindings_are_known(item: Dictionary) -> bool:
	var bindings := JsonCoerceScript._copy_dict(item.get("float_bindings", {}))
	for binding_key in ["potency", "resonance"]:
		var binding := JsonCoerceScript._copy_dict(bindings.get(binding_key, {}))
		var effect_key := str(binding.get("effect_key", ""))
		if not CollectionItemResolverScript.KNOWN_EFFECT_KEYS.has(effect_key):
			return false
	return true


func _check(condition: bool, message: String) -> void:
	if not condition:
		failures.append(message)


func _finish() -> void:
	if failures.is_empty():
		print("collection_meta_check: PASS")
		quit(0)
		return
	for failure in failures:
		push_error(failure)
	print("collection_meta_check: FAIL (%d failure(s))" % failures.size())
	quit(1)


# DurableStore recovers a missing primary from its rotated backup, so a fresh
# fixture store must remove every generation, not just the primary file.
func _remove_user_file(path: String) -> void:
	for generation_path in [path, DurableStore.backup_path(path)]:
		if FileAccess.file_exists(generation_path):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(generation_path))
