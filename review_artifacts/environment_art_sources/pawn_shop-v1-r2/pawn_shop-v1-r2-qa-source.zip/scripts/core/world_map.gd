class_name WorldMap
extends RefCounted

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")

# Persistent deterministic travel graph for Act 1 runs.

const VERSION := 3
const GRAND_CASINO_ID := "grand_casino"
const JAZZ_CLUB_ID := "jazz_club"
const UNDERGROUND_SHORTCUT_ID := "small_underground_casino"
const TIER_TWO_CASINO_IDS := ["kitty_cat_lounge", "delta_queen"]
const BEACH_ID := "beach"
const BEACH_GATEWAY_ID := "delta_queen"
const STATE_HIDDEN := "hidden"
const STATE_REVEALED := "revealed"
const STATE_VISITED := "visited"
const DISCOVERY_SOURCE_NONE := ""
const DISCOVERY_SOURCE_SPAWN := "spawn"
const DISCOVERY_SOURCE_EVENT := "event"
const DISCOVERY_SOURCE_TRAVEL := "travel"
const DISCOVERY_SOURCE_RUMOR := "rumor"
const DISTANCE_NEAR := "near"
const DISTANCE_LOCAL := "local"
const DISTANCE_FAR := "far"
const DISTANCE_REMOTE := "remote"
const TRAVEL_METHOD_WALK := "walk"
const TRAVEL_METHOD_BUS := "bus"
const TRAVEL_METHOD_TAXI := "taxi"
const TRAVEL_METHOD_NIGHT_CAB := "night_cab"
const MAP_BACKGROUND_PATH := "res://assets/art/map_backgrounds/cyberpunk_city_overhead.png"
const TRAVEL_NEW_TARGET_LIMIT := 2
const TRAVEL_TOTAL_TARGET_LIMIT := 3
const INITIAL_DESTINATION_POOL_IDS := [
	"corner_store",
	"back_alley",
	"motel",
	"bar",
	"gas_station_casino",
	"pawn_shop",
]
const BAND_COST_SCALE := {
	DISTANCE_NEAR: 1.0,
	DISTANCE_LOCAL: 1.35,
	DISTANCE_FAR: 1.75,
	DISTANCE_REMOTE: 2.25,
}

var library: ContentLibrary


func _init(p_library: ContentLibrary = null) -> void:
	library = p_library


func build(run_state: RunState, rng: RngStream) -> Dictionary:
	if library == null or run_state == null or rng == null:
		return {}
	var archetypes_by_id := _archetypes_by_id()
	if archetypes_by_id.is_empty():
		return {}
	var start_id := _pick_start_id(archetypes_by_id, run_state, rng)
	var ids: Array = []
	for id_value in _sorted_keys(archetypes_by_id):
		var archetype_id := str(id_value)
		var archetype: Dictionary = archetypes_by_id.get(archetype_id, {})
		if bool(archetype.get("map_hidden", false)):
			continue
		if str(archetype.get("kind", "")) == "home" and archetype_id != start_id:
			continue
		ids.append(archetype_id)
	if ids.size() < 2:
		return {}
	var nodes: Array = []
	var positions := _layout_positions(ids, archetypes_by_id, start_id, rng.fork("world_map_layout"))
	var edges := _build_edges(ids, archetypes_by_id, positions, start_id)
	var discovered_at_spawn_ids := _initial_discovered_ids(ids, start_id, edges, archetypes_by_id, rng.fork("world_map_discovery"))
	for id_value in ids:
		var archetype_id := str(id_value)
		var archetype: Dictionary = archetypes_by_id.get(archetype_id, {})
		var position: Dictionary = positions.get(archetype_id, {"x": 0.5, "y": 0.5})
		var discovered_at_spawn := discovered_at_spawn_ids.has(archetype_id)
		nodes.append({
			"id": archetype_id,
			"archetype_id": archetype_id,
			"label": _node_label(archetype),
			"kind": str(archetype.get("kind", "")),
			"tier": int(archetype.get("tier", 1)),
			"game_capacity": _archetype_game_capacity(archetype),
			"position": position.duplicate(true),
			"state": STATE_REVEALED if discovered_at_spawn else STATE_HIDDEN,
			"seen": discovered_at_spawn,
			"discovered_at_spawn": discovered_at_spawn,
			"discovery_source": DISCOVERY_SOURCE_SPAWN if discovered_at_spawn else DISCOVERY_SOURCE_NONE,
			"route_spawn_open": _route_is_spawn_open(archetype_id),
			"icon_path": _map_icon_path(archetype_id),
			"flavor": _archetype_flavor(archetype),
			"scouted": false,
			"heard": {},
			"environment": {},
		})
	var map_data := normalize({
		"version": VERSION,
		"seed_text": run_state.seed_text,
		"start_node_id": start_id,
		"current_node_id": start_id,
		"nodes": nodes,
		"edges": edges,
		"visited_path": [],
	})
	map_data = enter_node(map_data, start_id, {})
	return map_data


func route_for_target(map_data: Dictionary, current_id: String, target_id: String) -> Dictionary:
	# Route evaluation never consumes the generated environment stored on each
	# node. A late run can retain several large machine states there, so deep
	# copying the complete map for every candidate made a refresh scale with all
	# previously visited rooms. Normalize topology only on this read path.
	return route_for_target_prepared(map_data, current_id, target_id, prepare_path_query(map_data, current_id, true))


# Builds one route from a shared source-path query. The travel list asks about
# every visible destination at once; reusing this query avoids normalizing the
# same map and walking the same graph once per card.
func route_for_target_prepared(map_data: Dictionary, current_id: String, target_id: String, path_query: Dictionary) -> Dictionary:
	var normalized_value: Variant = path_query.get("normalized", {})
	var normalized: Dictionary = normalized_value if typeof(normalized_value) == TYPE_DICTIONARY and not (normalized_value as Dictionary).is_empty() else normalize_topology(map_data)
	var source_id := current_id.strip_edges()
	var destination_id := target_id.strip_edges()
	if source_id.is_empty() or destination_id.is_empty() or source_id == destination_id:
		return {}
	if not _travel_target_allowed_from_source(source_id, destination_id):
		return {}
	var source_node := node_by_id(normalized, source_id)
	var destination_node := node_by_id(normalized, destination_id)
	var direct_revisit_path := false
	var path := prepared_path(path_query, destination_id)
	if path.size() < 2:
		if source_node.is_empty() or destination_node.is_empty():
			return {}
		if str(destination_node.get("state", STATE_HIDDEN)) == STATE_VISITED:
			return {}
		if str(destination_node.get("state", STATE_HIDDEN)) != STATE_VISITED and not bool(destination_node.get("unlocked", false)):
			return {}
		path = [source_id, destination_id]
		direct_revisit_path = true
	var route := library.route(destination_id).duplicate(true) if library != null else {}
	var edge_lookup_value: Variant = path_query.get("edges_by_id", {})
	var edge_lookup: Dictionary = edge_lookup_value if typeof(edge_lookup_value) == TYPE_DICTIONARY else _edge_lookup(normalized)
	var distance_blocks := _path_distance_blocks_prepared(edge_lookup, path)
	if direct_revisit_path:
		var source_position: Dictionary = source_node.get("position", {"x": 0.5, "y": 0.5}) if typeof(source_node.get("position", {})) == TYPE_DICTIONARY else {"x": 0.5, "y": 0.5}
		var destination_position: Dictionary = destination_node.get("position", {"x": 0.5, "y": 0.5}) if typeof(destination_node.get("position", {})) == TYPE_DICTIONARY else {"x": 0.5, "y": 0.5}
		var direct_distance := Vector2(float(source_position.get("x", 0.5)), float(source_position.get("y", 0.5))).distance_to(Vector2(float(destination_position.get("x", 0.5)), float(destination_position.get("y", 0.5))))
		distance_blocks = maxi(1, ceili(direct_distance * 15.0))
	var band := _distance_band(distance_blocks)
	var base_cost := _path_base_cost_prepared(edge_lookup, path)
	var generated_cost := _path_cost_prepared(edge_lookup, path)
	var risk_decay := _path_risk_decay_prepared(edge_lookup, path, band)
	var edge_id := _route_edge_id_prepared(edge_lookup, path)
	if direct_revisit_path:
		edge_id = "revisit:%s:%s" % [source_id, destination_id]
	if route.is_empty():
		route = {
			"id": destination_id,
			"destination_archetype": destination_id,
			"distance": band,
			"risk_decay": risk_decay,
		}
	if base_cost <= 0:
		base_cost = _base_cost_for_band(band)
	if generated_cost <= 0:
		generated_cost = maxi(0, ceili(float(base_cost) * float(BAND_COST_SCALE.get(band, 1.0))))
	var destination_cost := maxi(0, int(route.get("cost", 0)))
	if destination_cost > 0:
		base_cost = maxi(base_cost, destination_cost)
		generated_cost = maxi(generated_cost, destination_cost)
	route["id"] = destination_id
	route["destination_archetype"] = destination_id
	route["from_archetype"] = source_id
	route["target_node_id"] = destination_id
	route["world_edge_id"] = edge_id
	route["world_path"] = path.duplicate(true)
	route["distance"] = band
	route["distance_blocks"] = distance_blocks
	route["base_cost"] = base_cost
	route["cost"] = generated_cost
	route["risk_decay"] = risk_decay
	route["path_stop_count"] = path.size()
	var method_kind := travel_method_kind(route, band)
	if method_kind == TRAVEL_METHOD_WALK:
		route["base_cost"] = 0
		route["cost"] = 0
	route["travel_method_kind"] = method_kind
	route["travel_method"] = travel_method_label(method_kind)
	if str(route.get("method", "")).strip_edges().is_empty():
		route["method"] = str(route.get("travel_method", ""))
	route["generated_world_route"] = true
	route = _apply_directional_route_overrides(route, source_id, destination_id)
	return route


static func _apply_directional_route_overrides(route: Dictionary, source_id: String, destination_id: String) -> Dictionary:
	var result := route.duplicate(true)
	if not _is_beach_gateway_pair(source_id, destination_id):
		return result
	result["base_cost"] = 0
	result["cost"] = 0
	result["travel_method_kind"] = TRAVEL_METHOD_WALK
	result["travel_method"] = travel_method_label(TRAVEL_METHOD_WALK)
	result["method"] = travel_method_label(TRAVEL_METHOD_WALK)
	result["beach_connector_walk"] = true
	if source_id == BEACH_ID:
		# The return still respects the River Queen environment's authored hours,
		# but never inherits its destination fare or progression schedule.
		result["requires_travel_count_min"] = 0
		result.erase("availability_window")
		result.erase("hide_until_travel_count_met")
		result.erase("travel_count_condition_text")
		result["condition_text"] = "Free walk back while the River Queen is open."
		result["beach_return_walk"] = true
	else:
		result["condition_text"] = "Free dockside walk to the beach."
		result["beach_access_walk"] = true
	return result


func preview_for_target(map_data: Dictionary, target_id: String) -> Dictionary:
	var node := node_by_id(map_data, target_id)
	if node.is_empty():
		return {}
	var environment: Dictionary = node.get("environment", {}) if typeof(node.get("environment", {})) == TYPE_DICTIONARY else {}
	return environment.duplicate(true)


static func normalize(map_data: Dictionary) -> Dictionary:
	if map_data.is_empty():
		return {}
	var normalized := map_data.duplicate(true)
	normalized["version"] = maxi(1, int(normalized.get("version", VERSION)))
	normalized["seed_text"] = str(normalized.get("seed_text", ""))
	normalized["start_node_id"] = str(normalized.get("start_node_id", ""))
	normalized["current_node_id"] = str(normalized.get("current_node_id", normalized.get("start_node_id", "")))
	normalized["revision"] = maxi(0, int(normalized.get("revision", 0)))
	normalized["nodes"] = _normalize_nodes(JsonCoerceScript._copy_array(normalized.get("nodes", [])))
	normalized["edges"] = _normalize_edges(JsonCoerceScript._copy_array(normalized.get("edges", [])))
	normalized["visited_path"] = JsonCoerceScript._string_array(normalized.get("visited_path", []))
	return _enforce_beach_gateway_access(normalized)


# Read-only path/map presentation needs node identity and topology, not the
# potentially large generated environment payload retained at every node.
static func normalize_topology(map_data: Dictionary) -> Dictionary:
	if map_data.is_empty():
		return {}
	var nodes_value: Variant = map_data.get("nodes", [])
	var edges_value: Variant = map_data.get("edges", [])
	var nodes: Array = nodes_value as Array if typeof(nodes_value) == TYPE_ARRAY else []
	var edges: Array = edges_value as Array if typeof(edges_value) == TYPE_ARRAY else []
	var normalized := {
		"version": maxi(1, int(map_data.get("version", VERSION))),
		"seed_text": str(map_data.get("seed_text", "")),
		"start_node_id": str(map_data.get("start_node_id", "")),
		"current_node_id": str(map_data.get("current_node_id", map_data.get("start_node_id", ""))),
		"revision": maxi(0, int(map_data.get("revision", 0))),
		# Both normalizers construct fresh dictionaries and do not mutate input.
		# Passing the source arrays avoids copying every node's environment before
		# the topology-only projection has a chance to omit it.
		"nodes": _normalize_nodes(nodes, false),
		"edges": _normalize_edges(edges),
		"visited_path": JsonCoerceScript._string_array(map_data.get("visited_path", [])),
	}
	return _enforce_beach_gateway_access(normalized)


static func current_node_id(map_data: Dictionary) -> String:
	return str(map_data.get("current_node_id", map_data.get("start_node_id", ""))).strip_edges()


static func node_by_id(map_data: Dictionary, node_id: String) -> Dictionary:
	var wanted_id := node_id.strip_edges()
	if wanted_id.is_empty():
		return {}
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return {}
	for node_value in nodes_value:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		if str(node.get("id", "")) == wanted_id:
			return node.duplicate(true)
	return {}


# Returns node presentation/topology fields without duplicating the generated
# environment. Use this for route checks and map UI; node_by_id remains the
# owning deep-copy API for callers that need to mutate or restore a room.
static func node_metadata_by_id(map_data: Dictionary, node_id: String) -> Dictionary:
	var wanted_id := node_id.strip_edges()
	if wanted_id.is_empty():
		return {}
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return {}
	for node_value in nodes_value as Array:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		if str(node.get("id", "")) != wanted_id:
			continue
		var metadata := node.duplicate(false)
		metadata.erase("environment")
		var position_value: Variant = metadata.get("position", {})
		if typeof(position_value) == TYPE_DICTIONARY:
			metadata["position"] = (position_value as Dictionary).duplicate(false)
		return metadata
	return {}


static func node_state(map_data: Dictionary, node_id: String) -> String:
	var node := node_metadata_by_id(map_data, node_id)
	return str(node.get("state", STATE_HIDDEN))


static func visible_node_ids(map_data: Dictionary) -> Array:
	var result: Array = []
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return result
	for node_value in nodes_value:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		var node_id := str(node.get("id", ""))
		if not node_id.is_empty() and _node_is_visible(node):
			result.append(node_id)
	if current_node_id(map_data) == BEACH_GATEWAY_ID and not result.has(BEACH_ID):
		var beach_node := node_metadata_by_id(map_data, BEACH_ID)
		if not beach_node.is_empty() and not bool(beach_node.get("home_lost", false)):
			result.append(BEACH_ID)
	return result


static func is_node_visible(map_data: Dictionary, node_id: String) -> bool:
	var node := node_metadata_by_id(map_data, node_id)
	if node.is_empty():
		return false
	if current_node_id(map_data) == BEACH_GATEWAY_ID and node_id.strip_edges() == BEACH_ID:
		return not bool(node.get("home_lost", false))
	return _node_is_visible(node)


static func neighbor_ids(map_data: Dictionary, node_id: String, visible_only: bool = false) -> Array:
	var visible_lookup := _visible_node_lookup(map_data) if visible_only else {}
	return _neighbor_ids_with_visible_lookup(map_data, node_id, visible_only, visible_lookup)


static func _neighbor_ids_with_visible_lookup(map_data: Dictionary, node_id: String, visible_only: bool, visible_lookup: Dictionary) -> Array:
	var result: Array = []
	var source_id := node_id.strip_edges()
	if source_id.is_empty():
		return result
	var edges_value: Variant = map_data.get("edges", [])
	if typeof(edges_value) != TYPE_ARRAY:
		return result
	for edge_value in edges_value:
		if typeof(edge_value) != TYPE_DICTIONARY:
			continue
		var edge: Dictionary = edge_value
		var a := str(edge.get("a", ""))
		var b := str(edge.get("b", ""))
		var other := ""
		if a == source_id:
			other = b
		elif b == source_id:
			other = a
		if other.is_empty() or result.has(other):
			continue
		if visible_only and not visible_lookup.has(other):
			continue
		result.append(other)
	return result


static func _visible_node_lookup(map_data: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	for visible_id_value in visible_node_ids(map_data):
		var visible_id := str(visible_id_value)
		if not visible_id.is_empty():
			result[visible_id] = true
	return result


static func _visible_ids_and_lookup(map_data: Dictionary) -> Dictionary:
	var ids: Array = []
	var lookup: Dictionary = {}
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return {"ids": ids, "lookup": lookup}
	for node_value in nodes_value:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		var node_id := str(node.get("id", ""))
		if node_id.is_empty() or not _node_is_visible(node):
			continue
		ids.append(node_id)
		lookup[node_id] = true
	return {"ids": ids, "lookup": lookup}


static func _node_lookup(map_data: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return result
	for node_value in nodes_value:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		var node_id := str(node.get("id", ""))
		if not node_id.is_empty():
			result[node_id] = node
	return result


static func _edge_lookup(map_data: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	var edges_value: Variant = map_data.get("edges", [])
	if typeof(edges_value) != TYPE_ARRAY:
		return result
	for edge_value in edges_value:
		if typeof(edge_value) != TYPE_DICTIONARY:
			continue
		var edge: Dictionary = edge_value
		var edge_id := str(edge.get("id", ""))
		if not edge_id.is_empty():
			result[edge_id] = edge
	return result


static func are_neighbors(map_data: Dictionary, a: String, b: String) -> bool:
	return not edge_between(map_data, a, b).is_empty()


static func has_path(map_data: Dictionary, a: String, b: String, visible_only: bool = true) -> bool:
	return path_between(map_data, a, b, visible_only).size() >= 2


static func path_between(map_data: Dictionary, a: String, b: String, visible_only: bool = true) -> Array:
	var normalized := normalize_topology(map_data)
	return _path_between_normalized(normalized, a, b, visible_only)


# Prepares every shortest path from one source with a single topology
# projection and one ordered breadth-first traversal. The adjacency lists are
# built in normalized edge order, exactly matching _neighbor_ids_with_visible_lookup,
# so each returned path is byte-identical to path_between for the same inputs.
# The query owns topology-only dictionaries and never retains environment
# payloads from the source map.
static func prepare_path_query(map_data: Dictionary, source_node_id: String, visible_only: bool = true) -> Dictionary:
	var source_id := source_node_id.strip_edges()
	var normalized := _enforce_beach_gateway_access(normalize_topology(map_data), source_id)
	var visible_lookup := _visible_node_lookup(normalized)
	var previous_by_node_id: Dictionary = {}
	var query := {
		"normalized": normalized,
		"source_node_id": source_id,
		"visible_only": visible_only,
		"previous_by_node_id": previous_by_node_id,
		"edges_by_id": _edge_lookup(normalized),
		"visible_node_ids": visible_lookup,
	}
	if source_id.is_empty():
		return query
	# path_between returns the source singleton before applying visibility
	# checks, including for a source id absent from the map.
	previous_by_node_id[source_id] = ""
	if visible_only and not visible_lookup.has(source_id):
		return query
	var adjacency: Dictionary = {}
	var edges_value: Variant = normalized.get("edges", [])
	if typeof(edges_value) == TYPE_ARRAY:
		for edge_value in edges_value as Array:
			if typeof(edge_value) != TYPE_DICTIONARY:
				continue
			var edge: Dictionary = edge_value
			var a := str(edge.get("a", ""))
			var b := str(edge.get("b", ""))
			_append_query_neighbor(adjacency, a, b, visible_only, visible_lookup)
			_append_query_neighbor(adjacency, b, a, visible_only, visible_lookup)
	var queue: Array = [source_id]
	var head := 0
	while head < queue.size():
		var current_id := str(queue[head])
		head += 1
		var neighbors_value: Variant = adjacency.get(current_id, [])
		if typeof(neighbors_value) != TYPE_ARRAY:
			continue
		for neighbor_value in neighbors_value as Array:
			var neighbor_id := str(neighbor_value)
			if previous_by_node_id.has(neighbor_id):
				continue
			previous_by_node_id[neighbor_id] = current_id
			queue.append(neighbor_id)
	query["previous_by_node_id"] = previous_by_node_id
	return query


static func prepared_path(query: Dictionary, target_node_id: String) -> Array:
	var source_id := str(query.get("source_node_id", "")).strip_edges()
	var target_id := target_node_id.strip_edges()
	var previous_value: Variant = query.get("previous_by_node_id", {})
	if source_id.is_empty() or target_id.is_empty() or typeof(previous_value) != TYPE_DICTIONARY:
		return []
	var previous_by_node_id: Dictionary = previous_value
	if not previous_by_node_id.has(target_id):
		return []
	return _reconstruct_path(previous_by_node_id, source_id, target_id)


static func prepared_has_path(query: Dictionary, target_node_id: String) -> bool:
	var source_id := str(query.get("source_node_id", "")).strip_edges()
	var target_id := target_node_id.strip_edges()
	var previous_value: Variant = query.get("previous_by_node_id", {})
	if target_id.is_empty() or target_id == source_id or typeof(previous_value) != TYPE_DICTIONARY:
		return false
	return (previous_value as Dictionary).has(target_id)


static func prepared_is_node_visible(query: Dictionary, node_id: String) -> bool:
	var visible_value: Variant = query.get("visible_node_ids", {})
	return typeof(visible_value) == TYPE_DICTIONARY and (visible_value as Dictionary).has(node_id.strip_edges())


static func prepared_path_uses_real_edges(query: Dictionary, path: Array) -> bool:
	if path.size() == 1:
		return true
	var edges_value: Variant = query.get("edges_by_id", {})
	if typeof(edges_value) != TYPE_DICTIONARY:
		return false
	var edges_by_id: Dictionary = edges_value
	for index in range(path.size() - 1):
		if not edges_by_id.has(_edge_id(str(path[index]), str(path[index + 1]))):
			return false
	return path.size() >= 2


static func _append_query_neighbor(adjacency: Dictionary, source_id: String, neighbor_id: String, visible_only: bool, visible_lookup: Dictionary) -> void:
	if source_id.is_empty() or neighbor_id.is_empty() or (visible_only and not visible_lookup.has(neighbor_id)):
		return
	var neighbors_value: Variant = adjacency.get(source_id, [])
	var neighbors: Array = neighbors_value as Array if typeof(neighbors_value) == TYPE_ARRAY else []
	if not neighbors.has(neighbor_id):
		neighbors.append(neighbor_id)
	adjacency[source_id] = neighbors


static func _path_between_normalized(normalized: Dictionary, a: String, b: String, visible_only: bool = true) -> Array:
	var visible_lookup: Dictionary = _visible_node_lookup(normalized) if visible_only else {}
	return _path_between_prepared(normalized, a, b, visible_only, visible_lookup)


static func _path_between_prepared(map_data: Dictionary, a: String, b: String, visible_only: bool, visible_lookup: Dictionary) -> Array:
	var source_id := a.strip_edges()
	var target_id := b.strip_edges()
	var result: Array = []
	if source_id.is_empty() or target_id.is_empty():
		return result
	if source_id == target_id:
		result.append(source_id)
		return result
	if visible_only:
		if not visible_lookup.has(source_id) or not visible_lookup.has(target_id):
			return result
	var queue: Array = [source_id]
	var previous_by_id: Dictionary = {}
	previous_by_id[source_id] = ""
	var head := 0
	while head < queue.size():
		var current_id := str(queue[head])
		head += 1
		for neighbor_value in _neighbor_ids_with_visible_lookup(map_data, current_id, visible_only, visible_lookup):
			var neighbor_id := str(neighbor_value)
			if previous_by_id.has(neighbor_id):
				continue
			previous_by_id[neighbor_id] = current_id
			if neighbor_id == target_id:
				return _reconstruct_path(previous_by_id, source_id, target_id)
			queue.append(neighbor_id)
	return result


static func edge_between(map_data: Dictionary, a: String, b: String) -> Dictionary:
	var edge_id := _edge_id(a, b)
	if edge_id.is_empty():
		return {}
	var edges_value: Variant = map_data.get("edges", [])
	if typeof(edges_value) != TYPE_ARRAY:
		return {}
	for edge_value in edges_value:
		if typeof(edge_value) != TYPE_DICTIONARY:
			continue
		var edge: Dictionary = edge_value
		if str(edge.get("id", "")) == edge_id:
			return edge.duplicate(true)
	return {}


static func travel_target_ids(map_data: Dictionary, node_id: String = "", max_new: int = TRAVEL_NEW_TARGET_LIMIT, max_total: int = TRAVEL_TOTAL_TARGET_LIMIT, enabled_target_ids: Array = []) -> Array:
	var normalized := normalize_topology(map_data)
	var source_id := node_id.strip_edges()
	if source_id.is_empty():
		source_id = current_node_id(normalized)
	# Callers may project choices for an explicit source before moving the map
	# cursor there. Apply the same physical dock invariant to that source rather
	# than relying only on the persisted current_node_id migration.
	normalized = _enforce_beach_gateway_access(normalized, source_id)
	var result: Array = []
	var visible_data := _visible_ids_and_lookup(normalized)
	var visible_ids: Array = visible_data.get("ids", [])
	var visible_lookup: Dictionary = visible_data.get("lookup", {})
	if source_id.is_empty() or not visible_lookup.has(source_id):
		return result
	var total_limit := maxi(0, max_total)
	var new_limit := mini(maxi(0, max_new), total_limit)
	var enabled_lookup := _enabled_target_lookup(enabled_target_ids)
	var node_lookup := _node_lookup(normalized)
	var edge_lookup := _edge_lookup(normalized)
	var visited_path := JsonCoerceScript._string_array(normalized.get("visited_path", []))
	var new_candidates := _travel_candidate_entries_prepared(normalized, source_id, false, enabled_lookup, visible_ids, visible_lookup, node_lookup, edge_lookup, visited_path)
	var old_candidates := _travel_candidate_entries_prepared(normalized, source_id, true, enabled_lookup, visible_ids, visible_lookup, node_lookup, edge_lookup, visited_path)
	var enabled_new_candidates := _filter_candidates_by_enabled(new_candidates, true)
	var fallback_new_candidates := _filter_candidates_by_enabled(new_candidates, false)
	var enabled_old_candidates := _filter_candidates_by_enabled(old_candidates, true)
	var fallback_old_candidates := _filter_candidates_by_enabled(old_candidates, false)
	var visited_path_is_initial := visited_path.size() <= 1 and (visited_path.is_empty() or str(visited_path[0]) == source_id)
	if source_id == str(normalized.get("start_node_id", "")) and visited_path_is_initial:
		enabled_new_candidates = _initial_start_candidate_order(enabled_new_candidates)
	for candidate_value in enabled_new_candidates:
		if result.size() >= new_limit:
			break
		var candidate: Dictionary = candidate_value
		var target_id := str(candidate.get("id", ""))
		if not target_id.is_empty() and not result.has(target_id):
			result.append(target_id)
	for candidate_value in enabled_old_candidates:
		if result.size() >= total_limit:
			break
		var candidate: Dictionary = candidate_value
		var target_id := str(candidate.get("id", ""))
		if target_id.is_empty() or result.has(target_id):
			continue
		result.append(target_id)
	for candidate_value in fallback_new_candidates:
		if result.size() >= total_limit or result.size() >= maxi(1, new_limit):
			break
		var candidate: Dictionary = candidate_value
		var target_id := str(candidate.get("id", ""))
		if not target_id.is_empty() and not result.has(target_id):
			result.append(target_id)
	for candidate_value in fallback_old_candidates:
		if result.size() >= total_limit:
			break
		var candidate: Dictionary = candidate_value
		var target_id := str(candidate.get("id", ""))
		if not target_id.is_empty() and not result.has(target_id):
			result.append(target_id)
	var enabled_priority_candidates := enabled_new_candidates + enabled_old_candidates
	var all_priority_candidates := enabled_priority_candidates + fallback_new_candidates + fallback_old_candidates
	if source_id == BEACH_ID:
		result = _ensure_visible_neighbor_target(result, source_id, BEACH_GATEWAY_ID, total_limit, visible_lookup, edge_lookup, node_lookup)
	# Once a Tier-2 casino has been revealed and passes its route gates, it must
	# survive the small travel-card cap. Otherwise cheaper familiar stops can
	# crowd the newly earned progression route out of the actual player UI.
	var tier_two_priority_id := _first_priority_node_id(enabled_priority_candidates, node_lookup, TIER_TWO_CASINO_IDS)
	# An explicit event lead is an equally strong player promise. In particular,
	# Parking Lot Tip unlocks The Punchline from across town; if ordinary nearby
	# stops and a newly revealed Tier-2 casino consume all three cards, the player
	# is forced through hours of incidental travel and can reach the venue only
	# after it closes. Keep one event-unlocked destination on the visible list.
	# An event promise remains useful when the route is temporarily disabled. In
	# particular, accepting the Grand invitation below its fare must show the
	# Grand card and its affordability reason instead of silently evicting it.
	var event_priority_id := _first_event_unlocked_priority_node_id(all_priority_candidates, node_lookup)
	var promised_disabled_priority_ids: Array = [event_priority_id]
	var grand_priority_node: Dictionary = node_lookup.get(GRAND_CASINO_ID, {})
	if bool(grand_priority_node.get("unlocked", false)) \
			and str(grand_priority_node.get("discovery_source", "")) == DISCOVERY_SOURCE_EVENT \
			and not promised_disabled_priority_ids.has(GRAND_CASINO_ID):
		promised_disabled_priority_ids.append(GRAND_CASINO_ID)
	# Preserve the invited Grand Casino at the same time when both progression
	# targets are live. Grand remains an explicit highest-priority promise even
	# when another event-unlocked route scores first; only actually event-unlocked
	# nodes may bypass a temporary route blocker such as insufficient fare.
	result = _ensure_priority_targets(result, all_priority_candidates, [GRAND_CASINO_ID, event_priority_id, tier_two_priority_id], total_limit, promised_disabled_priority_ids)
	# The physical dock-to-Beach exit is mandatory, but remains inside the normal
	# travel-card cap. Apply it after generic priority promotion so a later
	# replacement cannot evict it; when full, the last (lowest-ranked) ordinary
	# card yields to the local connector.
	if source_id == BEACH_GATEWAY_ID and total_limit > 0:
		result = _ensure_visible_neighbor_target(result, source_id, BEACH_ID, total_limit, visible_lookup, edge_lookup, node_lookup)
	return result


static func store_environment(map_data: Dictionary, node_id: String, environment_data: Dictionary) -> Dictionary:
	var target_id := node_id.strip_edges()
	if target_id.is_empty() or environment_data.is_empty():
		return normalize(map_data)
	var normalized := normalize(map_data)
	var nodes: Array = normalized.get("nodes", [])
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		if str(node.get("id", "")) != target_id:
			continue
		node["environment"] = environment_data.duplicate(true)
		nodes[index] = node
		break
	normalized["nodes"] = nodes
	return _bump_revision(normalized)


# RunState owns an already-normalized map and passes a detached persistence
# snapshot here. Copy only the containers that change instead of normalizing and
# deep-copying every other generated room in the map on each local interaction.
static func store_runtime_environment(map_data: Dictionary, node_id: String, environment_data: Dictionary) -> Dictionary:
	var target_id := node_id.strip_edges()
	if map_data.is_empty() or target_id.is_empty() or environment_data.is_empty():
		return map_data
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return map_data
	var nodes: Array = (nodes_value as Array).duplicate(false)
	var target_index := -1
	for index in range(nodes.size()):
		if typeof(nodes[index]) == TYPE_DICTIONARY and str((nodes[index] as Dictionary).get("id", "")) == target_id:
			target_index = index
			break
	if target_index < 0:
		return map_data
	var stored_map := map_data.duplicate(false)
	var target_node := (nodes[target_index] as Dictionary).duplicate(false)
	# The caller deliberately transfers this already-detached snapshot. Retaining
	# it avoids a second full room clone while keeping live environment mutations
	# isolated from the stored node.
	target_node["environment"] = environment_data
	nodes[target_index] = target_node
	stored_map["nodes"] = nodes
	return _bump_revision(stored_map)


static func enter_node(map_data: Dictionary, node_id: String, environment_data: Dictionary = {}) -> Dictionary:
	var target_id := node_id.strip_edges()
	if target_id.is_empty():
		return normalize(map_data)
	var normalized := normalize(map_data)
	normalized["current_node_id"] = target_id
	var nodes: Array = normalized.get("nodes", [])
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		if str(node.get("id", "")) == target_id:
			node["state"] = STATE_VISITED
			node["seen"] = true
			if not environment_data.is_empty():
				node["environment"] = environment_data.duplicate(true)
			nodes[index] = node
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		var candidate_node_id := str(node.get("id", ""))
		if candidate_node_id.is_empty() or str(node.get("state", STATE_HIDDEN)) != STATE_HIDDEN:
			continue
		if not bool(node.get("route_spawn_open", true)) and not bool(node.get("unlocked", false)):
			continue
		if not are_neighbors(normalized, target_id, candidate_node_id):
			continue
		node["state"] = STATE_REVEALED
		node["seen"] = true
		node["discovery_source"] = DISCOVERY_SOURCE_TRAVEL
		node["discovered_by_travel"] = true
		nodes[index] = node
	normalized["nodes"] = nodes
	var path: Array = JsonCoerceScript._string_array(normalized.get("visited_path", []))
	if path.is_empty() or str(path[path.size() - 1]) != target_id:
		path.append(target_id)
	normalized["visited_path"] = path
	return _bump_revision(_enforce_beach_gateway_access(normalized, target_id))


static func mark_scouted(map_data: Dictionary, node_id: String) -> Dictionary:
	var target_id := node_id.strip_edges()
	if target_id.is_empty():
		return normalize(map_data)
	var normalized := normalize(map_data)
	var nodes: Array = normalized.get("nodes", [])
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		if str(node.get("id", "")) == target_id:
			node["scouted"] = true
			node["seen"] = true
			nodes[index] = node
			break
	normalized["nodes"] = nodes
	return _bump_revision(normalized)


static func mark_heard(map_data: Dictionary, node_id: String, rumor: Dictionary) -> Dictionary:
	var target_id := node_id.strip_edges()
	if target_id.is_empty() or rumor.is_empty():
		return normalize(map_data)
	var normalized := normalize(map_data)
	var nodes: Array = normalized.get("nodes", [])
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		if str(node.get("id", "")) != target_id:
			continue
		node["heard"] = rumor.duplicate(true)
		node["seen"] = true
		if str(node.get("state", STATE_HIDDEN)) == STATE_HIDDEN:
			node["state"] = STATE_REVEALED
			node["discovery_source"] = DISCOVERY_SOURCE_RUMOR
		nodes[index] = node
		break
	normalized["nodes"] = nodes
	return _bump_revision(normalized)


static func unlock_nodes(map_data: Dictionary, node_ids: Array, source: String = DISCOVERY_SOURCE_EVENT) -> Dictionary:
	if node_ids.is_empty():
		return normalize(map_data)
	var normalized := normalize(map_data)
	var unlock_ids := JsonCoerceScript._string_array(node_ids)
	var clean_source := source.strip_edges().to_lower()
	if clean_source.is_empty():
		clean_source = DISCOVERY_SOURCE_EVENT
	var nodes: Array = normalized.get("nodes", [])
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		var node_id := str(node.get("id", ""))
		if not unlock_ids.has(node_id):
			continue
		if str(node.get("state", STATE_HIDDEN)) != STATE_VISITED:
			node["state"] = STATE_REVEALED
		node["seen"] = true
		if clean_source == DISCOVERY_SOURCE_SPAWN:
			node["discovered_at_spawn"] = true
		else:
			node["unlocked"] = true
		node["discovery_source"] = clean_source
		nodes[index] = node
	normalized["nodes"] = nodes
	return _bump_revision(normalized)


# Runtime event rewards operate on an already-normalized authoritative map.
# Copy only the map envelope, node array, and nodes that actually change so a
# route reveal does not duplicate every generated environment stored at other
# world-map nodes. Shop invalidation is folded into the same pass; the older
# unlock_nodes() API remains the owning/normalizing boundary for external data.
static func unlock_runtime_nodes(
	map_data: Dictionary,
	node_ids: Array,
	source: String = DISCOVERY_SOURCE_EVENT,
	refresh_shop_environments: bool = true
) -> Dictionary:
	if map_data.is_empty() or node_ids.is_empty():
		return map_data
	var unlock_ids := JsonCoerceScript._string_array(node_ids)
	if unlock_ids.is_empty():
		return map_data
	var unlock_lookup: Dictionary = {}
	for node_id_value in unlock_ids:
		unlock_lookup[str(node_id_value)] = true
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return map_data
	var source_nodes := nodes_value as Array
	var nodes := source_nodes.duplicate(false)
	var clean_source := source.strip_edges().to_lower()
	if clean_source.is_empty():
		clean_source = DISCOVERY_SOURCE_EVENT
	var changed := false
	for index in range(source_nodes.size()):
		if typeof(source_nodes[index]) != TYPE_DICTIONARY:
			continue
		var source_node := source_nodes[index] as Dictionary
		if not unlock_lookup.has(str(source_node.get("id", ""))):
			continue
		var node := source_node.duplicate(false)
		if str(node.get("state", STATE_HIDDEN)) != STATE_VISITED and str(node.get("state", STATE_HIDDEN)) != STATE_REVEALED:
			node["state"] = STATE_REVEALED
			changed = true
		if not bool(node.get("seen", false)):
			node["seen"] = true
			changed = true
		if clean_source == DISCOVERY_SOURCE_SPAWN:
			if not bool(node.get("discovered_at_spawn", false)):
				node["discovered_at_spawn"] = true
				changed = true
		else:
			if not bool(node.get("unlocked", false)):
				node["unlocked"] = true
				changed = true
		if str(node.get("discovery_source", "")) != clean_source:
			node["discovery_source"] = clean_source
			changed = true
		if refresh_shop_environments and str(node.get("kind", "")).strip_edges().to_lower() == "shop" \
				and typeof(node.get("environment", {})) == TYPE_DICTIONARY and not (node.get("environment", {}) as Dictionary).is_empty():
			node["environment"] = {}
			changed = true
		nodes[index] = node
	if not changed:
		return map_data
	var result := map_data.duplicate(false)
	result["nodes"] = nodes
	return _bump_revision(result)


# Makes hidden nodes eligible for the normal neighbor-discovery pass without
# revealing or directly unlocking them. This is distinct from event unlocks:
# the player must still reach a connected location before the node appears.
static func enable_node_spawns(map_data: Dictionary, node_ids: Array) -> Dictionary:
	if node_ids.is_empty():
		return normalize(map_data)
	var normalized := normalize(map_data)
	var spawn_ids := JsonCoerceScript._string_array(node_ids)
	var nodes: Array = normalized.get("nodes", [])
	var changed := false
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		if not spawn_ids.has(str(node.get("id", ""))) or bool(node.get("route_spawn_open", false)):
			continue
		node["route_spawn_open"] = true
		nodes[index] = node
		changed = true
	if not changed:
		return normalized
	normalized["nodes"] = nodes
	return _bump_revision(normalized)


# Replays only the neighbor-discovery portion of a visit for a bounded set of
# already visited sources and newly opened targets. This repairs progression
# gates without changing the current node, visit path, or stored environments.
static func discover_spawn_open_neighbors(map_data: Dictionary, source_node_ids: Array, target_node_ids: Array) -> Dictionary:
	var normalized := normalize(map_data)
	var source_ids := JsonCoerceScript._string_array(source_node_ids)
	var target_ids := JsonCoerceScript._string_array(target_node_ids)
	if source_ids.is_empty() or target_ids.is_empty():
		return normalized
	var nodes: Array = normalized.get("nodes", [])
	var changed := false
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		var candidate_id := str(node.get("id", ""))
		if not target_ids.has(candidate_id) or str(node.get("state", STATE_HIDDEN)) != STATE_HIDDEN:
			continue
		if not bool(node.get("route_spawn_open", true)) and not bool(node.get("unlocked", false)):
			continue
		var connected_to_visited_source := false
		for source_id in source_ids:
			var source_node := node_by_id(normalized, str(source_id))
			if str(source_node.get("state", STATE_HIDDEN)) == STATE_VISITED and are_neighbors(normalized, str(source_id), candidate_id):
				connected_to_visited_source = true
				break
		if not connected_to_visited_source:
			continue
		node["state"] = STATE_REVEALED
		node["seen"] = true
		node["discovery_source"] = DISCOVERY_SOURCE_TRAVEL
		node["discovered_by_travel"] = true
		nodes[index] = node
		changed = true
	if not changed:
		return normalized
	normalized["nodes"] = nodes
	return _bump_revision(normalized)
static func mark_home_lost(map_data: Dictionary, node_id: String) -> Dictionary:
	var target_id := node_id.strip_edges()
	if target_id.is_empty():
		return normalize(map_data)
	var normalized := normalize(map_data)
	var nodes: Array = normalized.get("nodes", [])
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		if str(node.get("id", "")) != target_id:
			continue
		node["home_lost"] = true
		node["environment"] = {}
		node["flavor"] = "Home access is gone; anything stored there was lost."
		nodes[index] = node
		break
	normalized["nodes"] = nodes
	return _bump_revision(normalized)


static func _bump_revision(map_data: Dictionary) -> Dictionary:
	map_data["revision"] = maxi(0, int(map_data.get("revision", 0))) + 1
	return map_data


static func snapshot(map_data: Dictionary, selected_id: String = "") -> Dictionary:
	var normalized := normalize_topology(map_data)
	var visible_ids: Array = []
	var visible_lookup: Dictionary = {}
	var visible_nodes: Array = []
	var nodes: Array = normalized.get("nodes", [])
	for node_value in nodes:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		var node_id := str(node.get("id", ""))
		if node_id.is_empty() or not _node_is_visible(node):
			continue
		visible_ids.append(node_id)
		visible_lookup[node_id] = true
		visible_nodes.append(_snapshot_node(node))
	var visible_edges: Array = []
	var edges: Array = normalized.get("edges", [])
	for edge_value in edges:
		if typeof(edge_value) != TYPE_DICTIONARY:
			continue
		var edge: Dictionary = edge_value
		if visible_lookup.has(str(edge.get("a", ""))) and visible_lookup.has(str(edge.get("b", ""))):
			visible_edges.append(edge.duplicate(true))
	var clean_selected_id := selected_id.strip_edges()
	if not visible_lookup.has(clean_selected_id):
		clean_selected_id = ""
	return {
		"version": VERSION,
		"current_node_id": current_node_id(normalized),
		"selected_node_id": clean_selected_id,
		"visible_node_ids": visible_ids,
		"nodes": visible_nodes,
		"edges": visible_edges,
		"visited_path": JsonCoerceScript._string_array(normalized.get("visited_path", [])),
		"background_path": MAP_BACKGROUND_PATH,
	}


func _archetypes_by_id() -> Dictionary:
	var result: Dictionary = {}
	for archetype_value in library.environment_archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		var id := str(archetype.get("id", "")).strip_edges()
		if id.is_empty() or bool(archetype.get("disabled", false)):
			continue
		result[id] = archetype.duplicate(true)
	return result


func _pick_start_id(archetypes_by_id: Dictionary, run_state: RunState, rng: RngStream) -> String:
	var selected_home := run_state.selected_home_archetype_id() if run_state != null else RunState.HOME_SELECTION_RANDOM
	if selected_home != RunState.HOME_SELECTION_RANDOM and archetypes_by_id.has(selected_home):
		return selected_home
	var home_ids: Array = []
	for id_value in _sorted_keys(archetypes_by_id):
		var id := str(id_value)
		var archetype: Dictionary = archetypes_by_id.get(id, {})
		if str(archetype.get("kind", "")) == "home" or bool(archetype.get("is_home_start", false)):
			home_ids.append(id)
	if not home_ids.is_empty():
		return str(rng.pick(home_ids, str(home_ids[0])))
	var shop_starts: Array = []
	var starts: Array = []
	var tier_one: Array = []
	for id_value in _sorted_keys(archetypes_by_id):
		var id := str(id_value)
		var archetype: Dictionary = archetypes_by_id.get(id, {})
		if bool(archetype.get("is_start", false)):
			starts.append(id)
			if str(archetype.get("kind", "")) == "shop":
				shop_starts.append(id)
		if int(archetype.get("tier", 1)) <= 1:
			tier_one.append(id)
	var candidates := shop_starts
	if candidates.is_empty():
		candidates = starts
	if candidates.is_empty():
		candidates = tier_one
	if candidates.is_empty():
		candidates = _sorted_keys(archetypes_by_id)
	return str(rng.pick(candidates, str(candidates[0])))


func _layout_positions(ids: Array, archetypes_by_id: Dictionary, start_id: String, rng: RngStream) -> Dictionary:
	var positions: Dictionary = {}
	for id_value in ids:
		var id := str(id_value)
		var archetype: Dictionary = archetypes_by_id.get(id, {})
		var tier := clampi(int(archetype.get("tier", 1)), 1, 4)
		var id_rng := rng.fork("node:%s" % id)
		var anchor := _city_anchor_for_node(id, archetype, tier)
		var x_jitter := float(id_rng.randi_range(-3, 3)) / 100.0
		var y_jitter := float(id_rng.randi_range(-4, 4)) / 100.0
		var x := clampf(anchor.x + x_jitter, 0.06, 0.94)
		var y := clampf(anchor.y + y_jitter, 0.08, 0.92)
		if id == GRAND_CASINO_ID:
			x = clampf(anchor.x + float(id_rng.randi_range(-1, 1)) / 100.0, 0.86, 0.95)
			y = clampf(anchor.y + float(id_rng.randi_range(-3, 3)) / 100.0, 0.24, 0.78)
		elif id == start_id:
			x = clampf(x - 0.035, 0.06, 0.94)
		positions[id] = {"x": x, "y": y}
	return _spread_positions(ids, positions)


func _city_anchor_for_node(id: String, archetype: Dictionary, tier: int) -> Vector2:
	match id:
		"apartment":
			return Vector2(0.13, 0.32)
		"motel_room":
			return Vector2(0.21, 0.19)
		"house":
			return Vector2(0.11, 0.62)
		"corner_store":
			return Vector2(0.16, 0.45)
		"back_alley":
			return Vector2(0.29, 0.70)
		"motel":
			return Vector2(0.25, 0.24)
		"jazz_club":
			return Vector2(0.42, 0.42)
		"bar":
			return Vector2(0.49, 0.64)
		"gas_station_casino":
			return Vector2(0.50, 0.22)
		"small_underground_casino":
			return Vector2(0.62, 0.78)
		"kitty_cat_lounge":
			return Vector2(0.70, 0.48)
		"delta_queen":
			return Vector2(0.76, 0.20)
		"beach":
			return Vector2(0.80, 0.22)
		GRAND_CASINO_ID:
			return Vector2(0.90, 0.49)
	var kind := str(archetype.get("kind", "")).strip_edges()
	if kind == "home":
		return Vector2(0.12, 0.38)
	var kind_offset := 0.08 if kind == "casino" else -0.04
	var x := clampf(0.16 + float(tier - 1) * 0.24 + kind_offset, 0.08, 0.90)
	var y_seed := float(abs(hash(id)) % 64) / 100.0
	return Vector2(x, clampf(0.18 + y_seed, 0.12, 0.88))


func _spread_positions(ids: Array, source_positions: Dictionary) -> Dictionary:
	var positions := source_positions.duplicate(true)
	for pass_index in range(3):
		for id_a_value in ids:
			var id_a := str(id_a_value)
			var a: Dictionary = positions.get(id_a, {"x": 0.5, "y": 0.5})
			for id_b_value in ids:
				var id_b := str(id_b_value)
				if id_a >= id_b:
					continue
				var b: Dictionary = positions.get(id_b, {"x": 0.5, "y": 0.5})
				var dx := float(a.get("x", 0.5)) - float(b.get("x", 0.5))
				var dy := float(a.get("y", 0.5)) - float(b.get("y", 0.5))
				if absf(dx) >= 0.085 or absf(dy) >= 0.085:
					continue
				var push := 0.035 + float(pass_index) * 0.01
				a["y"] = clampf(float(a.get("y", 0.5)) + push, 0.08, 0.92)
				b["y"] = clampf(float(b.get("y", 0.5)) - push, 0.08, 0.92)
				positions[id_a] = a
				positions[id_b] = b
	return _enforce_beach_delta_adjacency(positions)


func _enforce_beach_delta_adjacency(positions: Dictionary) -> Dictionary:
	if not positions.has("beach") or not positions.has("delta_queen"):
		return positions
	var delta: Dictionary = positions.get("delta_queen", {})
	var delta_position := Vector2(float(delta.get("x", 0.76)), float(delta.get("y", 0.20)))
	var beach_position := Vector2(
		clampf(delta_position.x + 0.045, 0.06, 0.94),
		clampf(delta_position.y + 0.015, 0.08, 0.92)
	)
	positions["beach"] = {"x": beach_position.x, "y": beach_position.y}
	return positions


func _build_edges(ids: Array, archetypes_by_id: Dictionary, positions: Dictionary, start_id: String) -> Array:
	var edges_by_id: Dictionary = {}
	for source_id_value in ids:
		var source_id := str(source_id_value)
		var source: Dictionary = archetypes_by_id.get(source_id, {})
		var authored_targets := _ranked_target_ids(source_id, _unique_strings(JsonCoerceScript._copy_array(source.get("next_archetypes", [])), JsonCoerceScript._copy_array(source.get("travel_hooks", []))), archetypes_by_id, positions)
		for target_id_value in authored_targets:
			var target_id := str(target_id_value)
			if not archetypes_by_id.has(target_id):
				continue
			if _node_degree(edges_by_id, source_id) >= _target_degree(source_id, archetypes_by_id):
				break
			if _node_degree(edges_by_id, target_id) >= _target_degree(target_id, archetypes_by_id) + 1:
				continue
			_add_edge(edges_by_id, source_id, target_id, positions)
	for source_id_value in ids:
		var source_id := str(source_id_value)
		var nearest := _nearest_ids(source_id, ids, archetypes_by_id, positions)
		var target_degree := mini(_target_degree(source_id, archetypes_by_id), 2 if ids.size() > 5 else 1)
		for target_id in nearest:
			if _node_degree(edges_by_id, source_id) >= target_degree:
				break
			if _node_degree(edges_by_id, str(target_id)) >= _target_degree(str(target_id), archetypes_by_id) + 1:
				continue
			_add_edge(edges_by_id, source_id, str(target_id), positions)
	_guarantee_start_edges(edges_by_id, ids, archetypes_by_id, positions, start_id)
	_guarantee_progression_edges(edges_by_id, ids, archetypes_by_id, positions)
	if archetypes_by_id.has("beach") and archetypes_by_id.has("delta_queen"):
		_add_edge(edges_by_id, "beach", "delta_queen", positions)
	if archetypes_by_id.has(UNDERGROUND_SHORTCUT_ID) and archetypes_by_id.has(GRAND_CASINO_ID):
		_add_edge(edges_by_id, UNDERGROUND_SHORTCUT_ID, GRAND_CASINO_ID, positions)
	# Punchline is the alternate Tier-2 progression milestone, so its authored
	# casino routes cannot be left to the degree-limited heuristic. Guarantee
	# both edges; the route availability layer still decides which card is open.
	if archetypes_by_id.has(UNDERGROUND_SHORTCUT_ID):
		for tier_two_id in TIER_TWO_CASINO_IDS:
			if archetypes_by_id.has(tier_two_id):
				_add_edge(edges_by_id, UNDERGROUND_SHORTCUT_ID, tier_two_id, positions)
	_connect_components(edges_by_id, ids, positions)
	var edge_ids := _sorted_keys(edges_by_id)
	var edges: Array = []
	for edge_id_value in edge_ids:
		edges.append(edges_by_id[str(edge_id_value)])
	return edges


func _guarantee_start_edges(edges_by_id: Dictionary, ids: Array, archetypes_by_id: Dictionary, positions: Dictionary, start_id: String) -> void:
	if start_id.is_empty() or not ids.has(start_id):
		return
	var open_targets: Array = []
	var fallback_targets: Array = []
	var start_archetype: Dictionary = archetypes_by_id.get(start_id, {})
	var parent_id := str(start_archetype.get("parent_archetype", "")).strip_edges()
	if not parent_id.is_empty() and ids.has(parent_id):
		open_targets.append(parent_id)
	for target_id_value in ids:
		var target_id := str(target_id_value)
		if target_id == start_id:
			continue
		var target_archetype: Dictionary = archetypes_by_id.get(target_id, {})
		if int(target_archetype.get("tier", 1)) > 2:
			continue
		if _route_is_spawn_open(target_id) and _archetype_has_games_for_discovery(target_archetype):
			if not open_targets.has(target_id):
				open_targets.append(target_id)
		elif _route_is_spawn_open(target_id) and not fallback_targets.has(target_id):
			fallback_targets.append(target_id)
	# Starting offers are selected later, but every member of this pool needs a
	# direct usable route so the seed can produce genuinely different first pairs.
	for initial_target_id_value in INITIAL_DESTINATION_POOL_IDS:
		var initial_target_id := str(initial_target_id_value)
		if initial_target_id != start_id and ids.has(initial_target_id) and _route_is_spawn_open(initial_target_id):
			_add_edge(edges_by_id, start_id, initial_target_id, positions)
	var ranked_targets := _ranked_target_ids(start_id, open_targets, archetypes_by_id, positions)
	if ranked_targets.size() < TRAVEL_NEW_TARGET_LIMIT:
		for fallback_id in _ranked_target_ids(start_id, fallback_targets, archetypes_by_id, positions):
			if not ranked_targets.has(str(fallback_id)):
				ranked_targets.append(str(fallback_id))
	for index in range(mini(TRAVEL_NEW_TARGET_LIMIT, ranked_targets.size())):
		_add_edge(edges_by_id, start_id, str(ranked_targets[index]), positions)


func _guarantee_progression_edges(edges_by_id: Dictionary, ids: Array, archetypes_by_id: Dictionary, positions: Dictionary) -> void:
	var tier_one := _ids_for_tier(ids, archetypes_by_id, 1)
	var tier_two := _ids_for_tier(ids, archetypes_by_id, 2)
	if not tier_one.is_empty() and not tier_two.is_empty():
		for target_id in tier_two:
			var nearest_tier_one := _nearest_from_pool(str(target_id), tier_one, positions)
			if not nearest_tier_one.is_empty():
				_add_edge(edges_by_id, nearest_tier_one, str(target_id), positions)
	if not tier_two.is_empty() and ids.has(GRAND_CASINO_ID):
		var grand_sources := _ranked_target_ids(GRAND_CASINO_ID, tier_two, archetypes_by_id, positions)
		for index in range(mini(2, grand_sources.size())):
			_add_edge(edges_by_id, str(grand_sources[index]), GRAND_CASINO_ID, positions)
	elif not tier_one.is_empty() and ids.has(GRAND_CASINO_ID):
		_add_edge(edges_by_id, str(tier_one[0]), GRAND_CASINO_ID, positions)


func _add_edge(edges_by_id: Dictionary, a: String, b: String, positions: Dictionary) -> void:
	var edge_id := _edge_id(a, b)
	if edge_id.is_empty() or edges_by_id.has(edge_id):
		return
	if _is_beach_route_pair(a, b) and not _is_beach_gateway_pair(a, b):
		return
	var pa: Dictionary = positions.get(a, {"x": 0.5, "y": 0.5})
	var pb: Dictionary = positions.get(b, {"x": 0.5, "y": 0.5})
	var distance := Vector2(float(pa.get("x", 0.5)), float(pa.get("y", 0.5))).distance_to(Vector2(float(pb.get("x", 0.5)), float(pb.get("y", 0.5))))
	var blocks := maxi(1, ceili(distance * 15.0))
	var band := _distance_band(blocks)
	var route := library.route(b) if library != null else {}
	var base_cost := maxi(0, int(route.get("cost", _base_cost_for_band(band))))
	var scaled_cost := maxi(0, ceili(float(base_cost) * float(BAND_COST_SCALE.get(band, 1.0))))
	var risk_decay := int(route.get("risk_decay", _risk_decay_for_band(band)))
	var method_kind := _travel_method_kind_for_band(band)
	if method_kind == TRAVEL_METHOD_WALK:
		base_cost = 0
		scaled_cost = 0
	edges_by_id[edge_id] = {
		"id": edge_id,
		"a": a,
		"b": b,
		"distance": band,
		"distance_blocks": blocks,
		"base_cost": base_cost,
		"cost": scaled_cost,
		"risk_decay": clampi(risk_decay, 0, 100),
		"travel_method_kind": method_kind,
		"travel_method": _travel_method_for_band(band),
	}


func _nearest_ids(source_id: String, ids: Array, archetypes_by_id: Dictionary, positions: Dictionary) -> Array:
	var source: Dictionary = archetypes_by_id.get(source_id, {})
	var source_tier := int(source.get("tier", 1))
	var scored: Array = []
	for target_id_value in ids:
		var target_id := str(target_id_value)
		if target_id == source_id:
			continue
		var target: Dictionary = archetypes_by_id.get(target_id, {})
		var tier_gap := absi(int(target.get("tier", 1)) - source_tier)
		var score := _position_distance_score(source_id, target_id, positions) + float(tier_gap) * 0.35
		scored.append({"id": target_id, "score": score})
	scored.sort_custom(Callable(self, "_sort_score_entry"))
	var result: Array = []
	for entry_value in scored:
		var entry: Dictionary = entry_value
		result.append(str(entry.get("id", "")))
	return result


func _ranked_target_ids(source_id: String, target_ids: Array, archetypes_by_id: Dictionary, positions: Dictionary) -> Array:
	var source: Dictionary = archetypes_by_id.get(source_id, {})
	var source_tier := int(source.get("tier", 1))
	var scored: Array = []
	for target_id_value in target_ids:
		var target_id := str(target_id_value)
		if target_id == source_id or not archetypes_by_id.has(target_id):
			continue
		var target: Dictionary = archetypes_by_id.get(target_id, {})
		var target_tier := int(target.get("tier", 1))
		var tier_gap := absi(target_tier - source_tier)
		var score := _position_distance_score(source_id, target_id, positions) + float(tier_gap) * 0.18
		if target_tier == source_tier + 1:
			score -= 0.08
		if source_id == GRAND_CASINO_ID or target_id == GRAND_CASINO_ID:
			score += 0.22 if maxi(source_tier, target_tier) < 2 else 0.0
		scored.append({"id": target_id, "score": score})
	scored.sort_custom(Callable(self, "_sort_score_entry"))
	var result: Array = []
	for entry_value in scored:
		var entry: Dictionary = entry_value
		result.append(str(entry.get("id", "")))
	return result


func _nearest_from_pool(source_id: String, pool: Array, positions: Dictionary) -> String:
	var best_id := ""
	var best_score := INF
	for target_id_value in pool:
		var target_id := str(target_id_value)
		var score := _position_distance_score(source_id, target_id, positions)
		if score < best_score:
			best_score = score
			best_id = target_id
	return best_id


func _position_distance_score(a: String, b: String, positions: Dictionary) -> float:
	var pa: Dictionary = positions.get(a, {"x": 0.5, "y": 0.5})
	var pb: Dictionary = positions.get(b, {"x": 0.5, "y": 0.5})
	return Vector2(float(pa.get("x", 0.5)), float(pa.get("y", 0.5))).distance_to(Vector2(float(pb.get("x", 0.5)), float(pb.get("y", 0.5))))


func _sort_score_entry(a: Variant, b: Variant) -> bool:
	var entry_a: Dictionary = a
	var entry_b: Dictionary = b
	if float(entry_a.get("score", 0.0)) == float(entry_b.get("score", 0.0)):
		return str(entry_a.get("id", "")) < str(entry_b.get("id", ""))
	return float(entry_a.get("score", 0.0)) < float(entry_b.get("score", 0.0))


func _node_degree(edges_by_id: Dictionary, node_id: String) -> int:
	var count := 0
	for edge_value in edges_by_id.values():
		if typeof(edge_value) != TYPE_DICTIONARY:
			continue
		var edge: Dictionary = edge_value
		if str(edge.get("a", "")) == node_id or str(edge.get("b", "")) == node_id:
			count += 1
	return count


func _target_degree(node_id: String, archetypes_by_id: Dictionary) -> int:
	if node_id == GRAND_CASINO_ID:
		return 2
	var archetype: Dictionary = archetypes_by_id.get(node_id, {})
	if int(archetype.get("tier", 1)) >= 2:
		return 3
	return 3


func _connect_components(edges_by_id: Dictionary, ids: Array, positions: Dictionary) -> void:
	var components := _edge_components(edges_by_id, ids)
	while components.size() > 1:
		var base: Array = components[0]
		var best_a := ""
		var best_b := ""
		var best_score := INF
		for component_index in range(1, components.size()):
			var component: Array = components[component_index]
			for a_value in base:
				var a := str(a_value)
				for b_value in component:
					var b := str(b_value)
					var score := _position_distance_score(a, b, positions)
					if score < best_score:
						best_score = score
						best_a = a
						best_b = b
		if best_a.is_empty() or best_b.is_empty():
			return
		_add_edge(edges_by_id, best_a, best_b, positions)
		components = _edge_components(edges_by_id, ids)


func _edge_components(edges_by_id: Dictionary, ids: Array) -> Array:
	var remaining: Array = []
	for id_value in ids:
		remaining.append(str(id_value))
	var components: Array = []
	while not remaining.is_empty():
		var start_id := str(remaining.pop_front())
		var component: Array = []
		var queue: Array = [start_id]
		while not queue.is_empty():
			var current_id := str(queue.pop_front())
			if component.has(current_id):
				continue
			component.append(current_id)
			remaining.erase(current_id)
			for neighbor_id in _edge_neighbor_ids(edges_by_id.values(), current_id):
				if not component.has(str(neighbor_id)):
					queue.append(str(neighbor_id))
		components.append(component)
	return components


func _ids_for_tier(ids: Array, archetypes_by_id: Dictionary, tier: int) -> Array:
	var result: Array = []
	for id_value in ids:
		var id := str(id_value)
		var archetype: Dictionary = archetypes_by_id.get(id, {})
		if int(archetype.get("tier", 1)) == tier:
			result.append(id)
	return result


func _node_label(archetype: Dictionary) -> String:
	var display_name := str(archetype.get("display_name", "")).strip_edges()
	if not display_name.is_empty():
		return display_name
	var nouns := JsonCoerceScript._string_array(archetype.get("name_nouns", []))
	if not nouns.is_empty():
		return str(nouns[0])
	return str(archetype.get("id", "Unknown")).replace("_", " ").capitalize()


func _archetype_flavor(archetype: Dictionary) -> String:
	var visual_context: Dictionary = archetype.get("visual_context", {}) if typeof(archetype.get("visual_context", {})) == TYPE_DICTIONARY else {}
	var description := str(visual_context.get("description", "")).strip_edges()
	if not description.is_empty():
		return description
	var objective_hint := str(archetype.get("objective_hint", "")).strip_edges()
	if not objective_hint.is_empty():
		return objective_hint
	var kind := str(archetype.get("kind", "")).strip_edges()
	if not kind.is_empty():
		return "A %s stop on the city map." % kind
	return "A stop on the city map."


func _initial_discovered_ids(ids: Array, start_id: String, edges: Array, archetypes_by_id: Dictionary, rng: RngStream) -> Array:
	var discovered: Array = [start_id]
	var start_neighbors := _edge_neighbor_ids(edges, start_id)
	var game_neighbors: Array = []
	var open_game_neighbors: Array = []
	for neighbor_id_value in start_neighbors:
		var neighbor_id := str(neighbor_id_value)
		var neighbor_archetype: Dictionary = archetypes_by_id.get(neighbor_id, {})
		if _archetype_has_games_for_discovery(neighbor_archetype):
			game_neighbors.append(neighbor_id)
			if _route_is_spawn_open(neighbor_id):
				open_game_neighbors.append(neighbor_id)
	var game_pick_pool := open_game_neighbors if not open_game_neighbors.is_empty() else game_neighbors
	if not game_pick_pool.is_empty():
		var game_pick := str(rng.pick(game_pick_pool, str(game_pick_pool[0])))
		if not discovered.has(game_pick):
			discovered.append(game_pick)
	var desired_start_destinations := mini(TRAVEL_NEW_TARGET_LIMIT, start_neighbors.size())
	var extra_guaranteed_count := maxi(0, desired_start_destinations - (discovered.size() - 1))
	if extra_guaranteed_count > 0:
		var remaining_open_game_neighbors: Array = []
		var remaining_open_neighbors: Array = []
		for neighbor_id_value in start_neighbors:
			var neighbor_id := str(neighbor_id_value)
			if discovered.has(neighbor_id):
				continue
			var neighbor_archetype: Dictionary = archetypes_by_id.get(neighbor_id, {})
			if _route_is_spawn_open(neighbor_id) and _archetype_has_games_for_discovery(neighbor_archetype):
				remaining_open_game_neighbors.append(neighbor_id)
			elif _route_is_spawn_open(neighbor_id):
				remaining_open_neighbors.append(neighbor_id)
		extra_guaranteed_count = _append_discovery_picks(discovered, remaining_open_game_neighbors, extra_guaranteed_count, rng)
		extra_guaranteed_count = _append_discovery_picks(discovered, remaining_open_neighbors, extra_guaranteed_count, rng)
	for id_value in ids:
		var id := str(id_value)
		if discovered.has(id):
			continue
		if not _route_is_spawn_open(id):
			continue
		var archetype: Dictionary = archetypes_by_id.get(id, {})
		var tier := clampi(int(archetype.get("tier", 1)), 1, 4)
		var roll := rng.randi_range(1, 100)
		var chance := 0
		if tier <= 1:
			chance = 10
		elif tier == 2:
			chance = 6
		if str(archetype.get("rarity", "")).to_lower() == "rare":
			chance = mini(chance, 8)
		if id == GRAND_CASINO_ID:
			chance = 0
		if roll <= chance:
			discovered.append(id)
	return discovered


func _append_discovery_picks(discovered: Array, candidates: Array, remaining_count: int, rng: RngStream) -> int:
	if remaining_count <= 0 or candidates.is_empty():
		return remaining_count
	for picked_id in rng.pick_many(candidates, mini(remaining_count, candidates.size())):
		var picked_text := str(picked_id)
		if not discovered.has(picked_text):
			discovered.append(picked_text)
			remaining_count -= 1
			if remaining_count <= 0:
				return 0
	return remaining_count


func _archetype_has_games_for_discovery(archetype: Dictionary) -> bool:
	return _archetype_game_capacity(archetype) > 0


func _archetype_game_capacity(archetype: Dictionary) -> int:
	var game_ids := JsonCoerceScript._string_array(archetype.get("game_pool", []))
	var required_ids := JsonCoerceScript._string_array(archetype.get("required_game_ids", []))
	for required_id in required_ids:
		if not game_ids.has(str(required_id)):
			game_ids.append(str(required_id))
	if game_ids.is_empty():
		return 0
	# An optional [0, N] machine must not turn a non-gambling stop into a
	# guaranteed game destination or perturb shipped early-map reachability.
	if required_ids.is_empty() and _count_floor(archetype.get("game_count", 0)) <= 0:
		return 0
	return mini(game_ids.size(), maxi(_count_ceiling(archetype.get("game_count", 0)), required_ids.size()))


func _count_floor(value: Variant) -> int:
	if typeof(value) == TYPE_ARRAY:
		var values: Array = value
		if values.is_empty():
			return 0
		var min_count := int(values[0])
		for entry in values:
			min_count = mini(min_count, int(entry))
		return min_count
	return int(value)


func _count_ceiling(value: Variant) -> int:
	if typeof(value) == TYPE_ARRAY:
		var values: Array = value
		var max_count := 0
		for entry in values:
			max_count = maxi(max_count, int(entry))
		return max_count
	return int(value)


func _route_is_spawn_open(archetype_id: String) -> bool:
	if library == null:
		return true
	var route := library.route(archetype_id)
	if route.is_empty():
		return true
	return JsonCoerceScript._copy_dict(route.get("requires_flags", {})).is_empty() and maxi(0, int(route.get("requires_travel_count_min", 0))) == 0 and not bool(route.get("hide_until_travel_count_met", false)) and JsonCoerceScript._copy_dict(route.get("availability_window", {})).is_empty()


func _edge_neighbor_ids(edges: Array, source_id: String) -> Array:
	var result: Array = []
	for edge_value in edges:
		if typeof(edge_value) != TYPE_DICTIONARY:
			continue
		var edge: Dictionary = edge_value
		var a := str(edge.get("a", ""))
		var b := str(edge.get("b", ""))
		var other := ""
		if a == source_id:
			other = b
		elif b == source_id:
			other = a
		if not other.is_empty() and not result.has(other):
			result.append(other)
	result.sort()
	return result


static func _map_icon_path(archetype_id: String) -> String:
	var clean_id := archetype_id.strip_edges()
	if clean_id.is_empty():
		return ""
	return "res://assets/art/map_icons/%s.png" % clean_id


static func _normalize_nodes(nodes: Array, include_environment: bool = true) -> Array:
	var result: Array = []
	for node_value in nodes:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var source: Dictionary = node_value
		var id := str(source.get("id", source.get("archetype_id", ""))).strip_edges()
		if id.is_empty():
			continue
		var position := JsonCoerceScript._copy_dict(source.get("position", {}))
		var discovery_source := str(source.get("discovery_source", source.get("unlock_source", ""))).strip_edges().to_lower()
		var discovered_at_spawn := bool(source.get("discovered_at_spawn", false))
		var unlocked := bool(source.get("unlocked", false))
		if discovered_at_spawn and discovery_source.is_empty():
			discovery_source = DISCOVERY_SOURCE_SPAWN
		elif unlocked and discovery_source.is_empty():
			discovery_source = DISCOVERY_SOURCE_EVENT
		var normalized_state := _normalized_state(str(source.get("state", STATE_HIDDEN)))
		var legacy_seen := normalized_state == STATE_VISITED or (normalized_state == STATE_REVEALED and (discovered_at_spawn or unlocked or discovery_source in [DISCOVERY_SOURCE_SPAWN, DISCOVERY_SOURCE_EVENT, DISCOVERY_SOURCE_TRAVEL]))
		var normalized_node := {
			"id": id,
			"archetype_id": str(source.get("archetype_id", id)),
			"label": str(source.get("label", id.replace("_", " ").capitalize())),
			"kind": str(source.get("kind", "")),
			"tier": int(source.get("tier", 1)),
			"game_capacity": maxi(0, int(source.get("game_capacity", 0))),
			"position": {
				"x": clampf(float(position.get("x", 0.5)), 0.0, 1.0),
				"y": clampf(float(position.get("y", 0.5)), 0.0, 1.0),
			},
			"state": normalized_state,
			"seen": bool(source.get("seen", legacy_seen)),
			"discovered_at_spawn": discovered_at_spawn,
			"unlocked": unlocked,
			"discovery_source": discovery_source,
			"route_spawn_open": bool(source.get("route_spawn_open", true)),
			"icon_path": str(source.get("icon_path", _map_icon_path(id))),
			"flavor": str(source.get("flavor", "")),
			"scouted": bool(source.get("scouted", false)),
			"heard": JsonCoerceScript._copy_dict(source.get("heard", {})),
			"home_lost": bool(source.get("home_lost", false)),
		}
		if include_environment:
			normalized_node["environment"] = JsonCoerceScript._copy_dict(source.get("environment", {}))
		result.append(normalized_node)
	return result


static func _normalize_edges(edges: Array) -> Array:
	var result: Array = []
	var seen: Dictionary = {}
	for edge_value in edges:
		if typeof(edge_value) != TYPE_DICTIONARY:
			continue
		var source: Dictionary = edge_value
		var a := str(source.get("a", "")).strip_edges()
		var b := str(source.get("b", "")).strip_edges()
		var edge_id := _edge_id(a, b)
		if edge_id.is_empty() or seen.has(edge_id):
			continue
		seen[edge_id] = true
		var distance_band := _distance_band(maxi(1, int(source.get("distance_blocks", 1))))
		if source.has("distance"):
			var authored_distance := str(source.get("distance", "")).strip_edges().to_lower()
			if BAND_COST_SCALE.has(authored_distance):
				distance_band = authored_distance
		var method_kind := travel_method_kind(source, distance_band)
		result.append({
			"id": edge_id,
			"a": a,
			"b": b,
			"distance": distance_band,
			"distance_blocks": maxi(1, int(source.get("distance_blocks", 1))),
			"base_cost": maxi(0, int(source.get("base_cost", source.get("cost", 0)))),
			"cost": maxi(0, int(source.get("cost", 0))),
			"risk_decay": clampi(int(source.get("risk_decay", _risk_decay_for_band(distance_band))), 0, 100),
			"travel_method_kind": method_kind,
			"travel_method": travel_method_label(method_kind),
		})
	return result


static func _enforce_beach_gateway_access(map_data: Dictionary, source_id: String = "") -> Dictionary:
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return map_data
	var nodes: Array = nodes_value
	var beach_index := -1
	var has_gateway := false
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node_id := str((nodes[index] as Dictionary).get("id", ""))
		if node_id == BEACH_ID:
			beach_index = index
		elif node_id == BEACH_GATEWAY_ID:
			has_gateway = true
	if beach_index < 0 or not has_gateway:
		return map_data
	# A continued run can carry the Beach as hidden even while the player is on
	# the boat. Repair that old discovery record at the shared normalization seam
	# used by both save restoration and the live read-only UI projection.
	var effective_source_id := source_id.strip_edges()
	if effective_source_id.is_empty():
		effective_source_id = current_node_id(map_data)
	if effective_source_id == BEACH_GATEWAY_ID:
		var beach_node: Dictionary = nodes[beach_index]
		if str(beach_node.get("state", STATE_HIDDEN)) != STATE_VISITED:
			beach_node["state"] = STATE_REVEALED
		beach_node["seen"] = true
		beach_node["unlocked"] = true
		beach_node["route_spawn_open"] = true
		beach_node["discovered_by_travel"] = true
		if str(beach_node.get("discovery_source", "")).strip_edges().is_empty():
			beach_node["discovery_source"] = DISCOVERY_SOURCE_TRAVEL
		nodes[beach_index] = beach_node
		map_data["nodes"] = nodes
	return map_data


static func _normalized_state(state: String) -> String:
	var normalized := state.strip_edges().to_lower()
	if [STATE_HIDDEN, STATE_REVEALED, STATE_VISITED].has(normalized):
		return normalized
	return STATE_HIDDEN


static func _node_is_visible(node: Dictionary) -> bool:
	if bool(node.get("seen", false)):
		return true
	var state := str(node.get("state", STATE_HIDDEN))
	if state == STATE_VISITED:
		return true
	if state != STATE_REVEALED:
		return false
	var discovery_source := str(node.get("discovery_source", node.get("unlock_source", ""))).strip_edges().to_lower()
	return bool(node.get("discovered_at_spawn", false)) or bool(node.get("unlocked", false)) or discovery_source == DISCOVERY_SOURCE_SPAWN or discovery_source == DISCOVERY_SOURCE_EVENT or discovery_source == DISCOVERY_SOURCE_TRAVEL


static func _snapshot_node(node: Dictionary) -> Dictionary:
	return {
		"id": str(node.get("id", "")),
		"archetype_id": str(node.get("archetype_id", node.get("id", ""))),
		"label": str(node.get("label", "")),
		"kind": str(node.get("kind", "")),
		"tier": int(node.get("tier", 1)),
		"game_capacity": int(node.get("game_capacity", 0)),
		"position": JsonCoerceScript._copy_dict(node.get("position", {})),
		"state": str(node.get("state", STATE_HIDDEN)),
		"seen": bool(node.get("seen", false)),
		"discovered_at_spawn": bool(node.get("discovered_at_spawn", false)),
		"unlocked": bool(node.get("unlocked", false)),
		"discovery_source": str(node.get("discovery_source", "")),
		"route_spawn_open": bool(node.get("route_spawn_open", true)),
		"scouted": bool(node.get("scouted", false)),
		"heard": JsonCoerceScript._copy_dict(node.get("heard", {})),
		"icon_path": str(node.get("icon_path", _map_icon_path(str(node.get("archetype_id", node.get("id", "")))))),
		"flavor": str(node.get("flavor", "")),
		"home_lost": bool(node.get("home_lost", false)),
	}


static func _enabled_target_lookup(enabled_target_ids: Array) -> Dictionary:
	var result: Dictionary = {}
	for id_value in JsonCoerceScript._string_array(enabled_target_ids):
		result[str(id_value)] = true
	return result


static func _candidate_enabled_hint(node: Dictionary, target_id: String, enabled_lookup: Dictionary) -> bool:
	if not enabled_lookup.is_empty():
		return bool(enabled_lookup.get(target_id, false))
	return bool(node.get("route_spawn_open", true))


static func _filter_candidates_by_enabled(candidates: Array, enabled: bool) -> Array:
	var result: Array = []
	for candidate_value in candidates:
		if typeof(candidate_value) != TYPE_DICTIONARY:
			continue
		var candidate: Dictionary = candidate_value
		if bool(candidate.get("enabled_hint", true)) == enabled:
			result.append(candidate)
	return result


static func _ensure_priority_targets(result: Array, candidates: Array, target_ids: Array, total_limit: int, allowed_disabled_target_ids: Array = []) -> Array:
	var normalized_result := result.duplicate(true)
	if total_limit <= 0:
		return normalized_result
	var eligible_candidate_ids: Array = []
	var visited_ids: Array = []
	for candidate_value in candidates:
		if typeof(candidate_value) != TYPE_DICTIONARY:
			continue
		var candidate: Dictionary = candidate_value
		var candidate_id := str(candidate.get("id", ""))
		if bool(candidate.get("visited", false)) and not candidate_id.is_empty() and not visited_ids.has(candidate_id):
			visited_ids.append(candidate_id)
		var enabled_or_promised := bool(candidate.get("enabled_hint", true)) or allowed_disabled_target_ids.has(candidate_id)
		if target_ids.has(candidate_id) and not candidate_id.is_empty() and enabled_or_promised and not eligible_candidate_ids.has(candidate_id):
			eligible_candidate_ids.append(candidate_id)
	# The caller's order is the progression contract. Candidate score order may
	# put a lower-priority revealed casino ahead of an event-promised destination,
	# especially when every other visible card is a protected revisit.
	var eligible_ids: Array = []
	for target_id_value in target_ids:
		var target_id := str(target_id_value)
		if eligible_candidate_ids.has(target_id) and not eligible_ids.has(target_id):
			eligible_ids.append(target_id)
	for priority_index in range(eligible_ids.size()):
		var target_id := str(eligible_ids[priority_index])
		if normalized_result.has(target_id):
			continue
		if normalized_result.size() < total_limit:
			normalized_result.append(target_id)
			continue
		var replacement_index := -1
		for index in range(normalized_result.size() - 1, -1, -1):
			var existing_id := str(normalized_result[index])
			# Revisit routes are intentionally additive to the new-destination cap.
			# A progression priority must replace another new candidate, never erase
			# a known way back to a previously visited stop.
			if visited_ids.has(existing_id):
				continue
			if not eligible_ids.has(existing_id):
				replacement_index = index
				break
		# Keep every declared priority when a non-priority card can move. Only a
		# lower-priority new card may yield when revisits consume every other slot.
		if replacement_index < 0:
			for index in range(normalized_result.size() - 1, -1, -1):
				var existing_id := str(normalized_result[index])
				if visited_ids.has(existing_id):
					continue
				var existing_priority_index := eligible_ids.find(existing_id)
				if existing_priority_index > priority_index:
					replacement_index = index
					break
		# A disabled event-promised destination still needs a visible card with its
		# blocker. If every capped slot is a revisit, one lowest-ranked ordinary
		# revisit yields only when no stronger promise is already represented; lower
		# promises cannot drain the familiar-route surface. Already-promoted
		# priorities stay intact.
		var promised_priority_visible := false
		for promised_id_value in allowed_disabled_target_ids:
			var promised_id := str(promised_id_value)
			if not promised_id.is_empty() and normalized_result.has(promised_id):
				promised_priority_visible = true
				break
		if replacement_index < 0 \
				and not promised_priority_visible \
				and allowed_disabled_target_ids.has(target_id):
			for index in range(normalized_result.size() - 1, -1, -1):
				var existing_id := str(normalized_result[index])
				if not visited_ids.has(existing_id) or eligible_ids.has(existing_id):
					continue
				replacement_index = index
				break
		if replacement_index >= 0:
			normalized_result[replacement_index] = target_id
	return normalized_result


static func _first_priority_node_id(candidates: Array, node_lookup: Dictionary, allowed_ids: Array) -> String:
	for candidate_value in candidates:
		if typeof(candidate_value) != TYPE_DICTIONARY:
			continue
		var candidate: Dictionary = candidate_value
		if not bool(candidate.get("enabled_hint", true)):
			continue
		var candidate_id := str(candidate.get("id", ""))
		if not allowed_ids.has(candidate_id):
			continue
		var node: Dictionary = node_lookup.get(candidate_id, {})
		if int(node.get("tier", 0)) == 2 and str(node.get("kind", "")).strip_edges().to_lower() == "casino":
			return candidate_id
	return ""


static func _first_event_unlocked_priority_node_id(candidates: Array, node_lookup: Dictionary) -> String:
	for candidate_value in candidates:
		if typeof(candidate_value) != TYPE_DICTIONARY:
			continue
		var candidate: Dictionary = candidate_value
		var candidate_id := str(candidate.get("id", ""))
		var node: Dictionary = node_lookup.get(candidate_id, {})
		if bool(node.get("unlocked", false)) and str(node.get("discovery_source", "")) == DISCOVERY_SOURCE_EVENT:
			return candidate_id
	return ""


static func _ensure_visible_neighbor_target(result: Array, source_id: String, target_id: String, total_limit: int, visible_lookup: Dictionary, edge_lookup: Dictionary, node_lookup: Dictionary) -> Array:
	var normalized_result := result.duplicate(true)
	if total_limit <= 0 or source_id.is_empty() or target_id.is_empty() or normalized_result.has(target_id):
		return normalized_result
	if not visible_lookup.has(source_id) or not visible_lookup.has(target_id):
		return normalized_result
	if not edge_lookup.has(_edge_id(source_id, target_id)):
		return normalized_result
	var target_node: Dictionary = node_lookup.get(target_id, {})
	if target_node.is_empty() or bool(target_node.get("home_lost", false)):
		return normalized_result
	if normalized_result.size() < total_limit:
		normalized_result.append(target_id)
	elif not normalized_result.is_empty():
		normalized_result[normalized_result.size() - 1] = target_id
	return normalized_result
static func _travel_candidate_entries_prepared(map_data: Dictionary, source_id: String, visited_only: bool, enabled_lookup: Dictionary, visible_ids: Array, visible_lookup: Dictionary, node_lookup: Dictionary, edge_lookup: Dictionary, visited_path: Array) -> Array:
	var entries: Array = []
	for target_id_value in visible_ids:
		var target_id := str(target_id_value)
		if target_id == source_id:
			continue
		if not _travel_target_allowed_from_source(source_id, target_id):
			continue
		var node: Dictionary = node_lookup.get(target_id, {})
		if node.is_empty():
			continue
		if bool(node.get("home_lost", false)):
			continue
		var is_visited := str(node.get("state", STATE_HIDDEN)) == STATE_VISITED
		if is_visited != visited_only:
			continue
		var path := _path_between_prepared(map_data, source_id, target_id, true, visible_lookup)
		if path.size() < 2:
			if visited_only:
				continue
			if not visited_only and not bool(node.get("unlocked", false)):
				continue
			path = [source_id, target_id]
		var blocks := _path_distance_blocks_prepared(edge_lookup, path)
		var direct_edge: Dictionary = edge_lookup.get(_edge_id(str(path[0]), str(path[1])), {})
		if path.size() == 2 and direct_edge.is_empty():
			var source_node: Dictionary = node_lookup.get(source_id, {})
			var source_position: Dictionary = source_node.get("position", {"x": 0.5, "y": 0.5}) if typeof(source_node.get("position", {})) == TYPE_DICTIONARY else {"x": 0.5, "y": 0.5}
			var target_position: Dictionary = node.get("position", {"x": 0.5, "y": 0.5}) if typeof(node.get("position", {})) == TYPE_DICTIONARY else {"x": 0.5, "y": 0.5}
			var direct_distance := Vector2(float(source_position.get("x", 0.5)), float(source_position.get("y", 0.5))).distance_to(Vector2(float(target_position.get("x", 0.5)), float(target_position.get("y", 0.5))))
			blocks = maxi(1, ceili(direct_distance * 15.0))
		var cost := _path_cost_prepared(edge_lookup, path)
		if cost <= 0:
			var band := _distance_band(blocks)
			cost = maxi(0, ceili(float(_base_cost_for_band(band)) * float(BAND_COST_SCALE.get(band, 1.0))))
		var last_visit_index := _last_index_of(visited_path, target_id)
		var enabled_hint := _candidate_enabled_hint(node, target_id, enabled_lookup)
		var score := float(blocks) + float(cost) * 0.08 + float(int(node.get("tier", 1))) * 0.18
		if visited_only:
			score = float(blocks) * 0.55 + float(cost) * 0.06 - float(last_visit_index) * 0.10
		else:
			var kind := str(node.get("kind", "")).strip_edges()
			if kind == "casino" or kind == "boss":
				score -= 1.5
			elif kind == "shop":
				# Early supply stops should compete with gambling rooms instead of
				# being crowded out by them. The Jazz Club stays uncommon, but its
				# single pull-tabs machine no longer makes it practically invisible.
				score -= 2.0
				if target_id == JAZZ_CLUB_ID:
					score -= 3.0
			var game_capacity := int(node.get("game_capacity", 0))
			if game_capacity >= 2:
				score -= 4.0
			elif game_capacity == 1:
				score += 0.5
		if not enabled_hint:
			score += 100.0
		var initial_variance_rank := absi(hash("%s|%s|%s" % [str(map_data.get("seed_text", "")), source_id, target_id]))
		if target_id == JAZZ_CLUB_ID:
			# Preserve the club's uncommon evening-start appearance while the
			# larger daytime shop pool gains the Pawn Shop. The Pawn Shop is still
			# open at dusk, so the club needs this head start to keep its earlier
			# rate of roughly one evening start in five.
			initial_variance_rank = int(float(initial_variance_rank) * 0.6)
		entries.append({
			"id": target_id,
			"kind": str(node.get("kind", "")).strip_edges().to_lower(),
			"path": path.duplicate(true),
			"distance_blocks": blocks,
			"cost": cost,
			"visited": is_visited,
			"enabled_hint": enabled_hint,
			"last_visit_index": last_visit_index,
			"score": score,
			"initial_variance_rank": initial_variance_rank,
		})
	entries.sort_custom(Callable(WorldMap, "_sort_travel_candidate"))
	return entries


static func _initial_start_candidate_order(candidates: Array) -> Array:
	var casinos: Array = []
	var shops: Array = []
	var remaining: Array = []
	for candidate_value in candidates:
		if typeof(candidate_value) != TYPE_DICTIONARY:
			continue
		var candidate: Dictionary = candidate_value
		match str(candidate.get("kind", "")):
			"casino":
				casinos.append(candidate)
			"shop":
				shops.append(candidate)
			_:
				remaining.append(candidate)
	casinos.sort_custom(Callable(WorldMap, "_sort_initial_candidate"))
	shops.sort_custom(Callable(WorldMap, "_sort_initial_candidate"))
	remaining.sort_custom(Callable(WorldMap, "_sort_initial_candidate"))
	var result: Array = []
	if not casinos.is_empty():
		result.append(casinos.pop_front())
	if not shops.is_empty():
		result.append(shops.pop_front())
	var unused := casinos + shops + remaining
	unused.sort_custom(Callable(WorldMap, "_sort_initial_candidate"))
	result.append_array(unused)
	return result


static func _sort_initial_candidate(a: Variant, b: Variant) -> bool:
	var entry_a: Dictionary = a
	var entry_b: Dictionary = b
	var rank_a := int(entry_a.get("initial_variance_rank", 0))
	var rank_b := int(entry_b.get("initial_variance_rank", 0))
	if rank_a == rank_b:
		return str(entry_a.get("id", "")) < str(entry_b.get("id", ""))
	return rank_a < rank_b


static func _travel_target_allowed_from_source(source_id: String, target_id: String) -> bool:
	var source := source_id.strip_edges()
	var target := target_id.strip_edges()
	if target != BEACH_ID:
		return true
	return source == BEACH_GATEWAY_ID


static func _is_beach_route_pair(a: String, b: String) -> bool:
	return a.strip_edges() == BEACH_ID or b.strip_edges() == BEACH_ID


static func _is_beach_gateway_pair(a: String, b: String) -> bool:
	var left := a.strip_edges()
	var right := b.strip_edges()
	return (left == BEACH_ID and right == BEACH_GATEWAY_ID) or (left == BEACH_GATEWAY_ID and right == BEACH_ID)


static func _sort_travel_candidate(a: Variant, b: Variant) -> bool:
	var entry_a: Dictionary = a
	var entry_b: Dictionary = b
	var score_a := float(entry_a.get("score", 0.0))
	var score_b := float(entry_b.get("score", 0.0))
	if score_a == score_b:
		return str(entry_a.get("id", "")) < str(entry_b.get("id", ""))
	return score_a < score_b


static func _reconstruct_path(previous_by_id: Dictionary, source_id: String, target_id: String) -> Array:
	var path: Array = [target_id]
	var current_id := target_id
	var guard := 0
	while current_id != source_id and guard < previous_by_id.size() + 2:
		current_id = str(previous_by_id.get(current_id, ""))
		if current_id.is_empty():
			return []
		path.push_front(current_id)
		guard += 1
	if path.is_empty() or str(path[0]) != source_id:
		return []
	return path
static func _path_distance_blocks_prepared(edge_lookup: Dictionary, path: Array) -> int:
	var blocks := 0
	for index in range(path.size() - 1):
		var edge: Dictionary = edge_lookup.get(_edge_id(str(path[index]), str(path[index + 1])), {})
		if edge.is_empty():
			return 1
		blocks += maxi(1, int(edge.get("distance_blocks", 1)))
	return maxi(1, blocks)


static func _path_base_cost_prepared(edge_lookup: Dictionary, path: Array) -> int:
	var total := 0
	for index in range(path.size() - 1):
		var edge: Dictionary = edge_lookup.get(_edge_id(str(path[index]), str(path[index + 1])), {})
		if edge.is_empty():
			return 0
		total += maxi(0, int(edge.get("base_cost", edge.get("cost", 0))))
	return total


static func _path_cost_prepared(edge_lookup: Dictionary, path: Array) -> int:
	var total := 0
	for index in range(path.size() - 1):
		var edge: Dictionary = edge_lookup.get(_edge_id(str(path[index]), str(path[index + 1])), {})
		if edge.is_empty():
			return 0
		total += maxi(0, int(edge.get("cost", edge.get("base_cost", 0))))
	return total


static func _path_risk_decay_prepared(edge_lookup: Dictionary, path: Array, band: String) -> int:
	var risk_decay := _risk_decay_for_band(band)
	for index in range(path.size() - 1):
		var edge: Dictionary = edge_lookup.get(_edge_id(str(path[index]), str(path[index + 1])), {})
		if edge.is_empty():
			return clampi(risk_decay, 0, 100)
		risk_decay = maxi(risk_decay, int(edge.get("risk_decay", 0)))
	return clampi(risk_decay, 0, 100)


static func _route_edge_id_prepared(edge_lookup: Dictionary, path: Array) -> String:
	if path.size() == 2:
		var edge: Dictionary = edge_lookup.get(_edge_id(str(path[0]), str(path[1])), {})
		if not edge.is_empty():
			return str(edge.get("id", _edge_id(str(path[0]), str(path[1]))))
	return "path:%s" % "->".join(path)


static func _last_index_of(values: Array, target_id: String) -> int:
	for index in range(values.size() - 1, -1, -1):
		if str(values[index]) == target_id:
			return index
	return -1


static func _travel_method_for_band(band: String) -> String:
	return travel_method_label(_travel_method_kind_for_band(band))


# Returns a stable gameplay key while accepting legacy player-facing route copy.
static func travel_method_kind(value: Variant, fallback_distance: String = "") -> String:
	var method_value: Variant = value
	var distance_value := fallback_distance
	if typeof(value) == TYPE_DICTIONARY:
		var source: Dictionary = value
		var explicit_kind: Variant = source.get("travel_method_kind")
		if typeof(explicit_kind) == TYPE_STRING and _is_canonical_travel_method_kind(explicit_kind as String):
			return explicit_kind as String
		if typeof(explicit_kind) == TYPE_STRING:
			var normalized_kind := (explicit_kind as String).strip_edges().to_lower()
			if _is_canonical_travel_method_kind(normalized_kind):
				return normalized_kind
		method_value = source.get("travel_method", source.get("method", ""))
		distance_value = str(source.get("distance", fallback_distance))
	var raw_method := str(method_value)
	match raw_method:
		TRAVEL_METHOD_WALK, "Walk":
			return TRAVEL_METHOD_WALK
		TRAVEL_METHOD_BUS, "Bus ticket":
			return TRAVEL_METHOD_BUS
		TRAVEL_METHOD_TAXI, "Taxi ride":
			return TRAVEL_METHOD_TAXI
		TRAVEL_METHOD_NIGHT_CAB, "Night cab":
			return TRAVEL_METHOD_NIGHT_CAB
	var method_text := raw_method.strip_edges().to_lower()
	if method_text == TRAVEL_METHOD_WALK or method_text.contains("walk"):
		return TRAVEL_METHOD_WALK
	if method_text == TRAVEL_METHOD_BUS or method_text.contains("bus"):
		return TRAVEL_METHOD_BUS
	if method_text == TRAVEL_METHOD_TAXI or method_text.contains("taxi"):
		return TRAVEL_METHOD_TAXI
	if method_text == TRAVEL_METHOD_NIGHT_CAB or method_text.contains("night cab"):
		return TRAVEL_METHOD_NIGHT_CAB
	return _travel_method_kind_for_band(distance_value)


# Derives all route UI copy from the same canonical key used by event logic.
static func travel_method_label(kind: String) -> String:
	match kind:
		TRAVEL_METHOD_WALK:
			return "Walk"
		TRAVEL_METHOD_BUS:
			return "Bus ticket"
		TRAVEL_METHOD_TAXI:
			return "Taxi ride"
		TRAVEL_METHOD_NIGHT_CAB:
			return "Night cab"
	var normalized := kind.strip_edges().to_lower()
	if normalized != kind:
		return travel_method_label(normalized)
	return "Travel"


static func _travel_method_kind_for_band(band: String) -> String:
	match band:
		DISTANCE_NEAR:
			return TRAVEL_METHOD_WALK
		DISTANCE_LOCAL:
			return TRAVEL_METHOD_BUS
		DISTANCE_FAR:
			return TRAVEL_METHOD_TAXI
		DISTANCE_REMOTE:
			return TRAVEL_METHOD_NIGHT_CAB
	var normalized := band.strip_edges().to_lower()
	if normalized != band:
		return _travel_method_kind_for_band(normalized)
	return TRAVEL_METHOD_NIGHT_CAB


static func _is_canonical_travel_method_kind(kind: String) -> bool:
	match kind:
		TRAVEL_METHOD_WALK, TRAVEL_METHOD_BUS, TRAVEL_METHOD_TAXI, TRAVEL_METHOD_NIGHT_CAB:
			return true
	return false


static func _distance_band(blocks: int) -> String:
	if blocks <= 3:
		return DISTANCE_NEAR
	if blocks <= 6:
		return DISTANCE_LOCAL
	if blocks <= 10:
		return DISTANCE_FAR
	return DISTANCE_REMOTE


static func _base_cost_for_band(band: String) -> int:
	match band:
		DISTANCE_NEAR:
			return 1
		DISTANCE_LOCAL:
			return 2
		DISTANCE_FAR:
			return 5
		_:
			return 10


static func _risk_decay_for_band(band: String) -> int:
	match band:
		DISTANCE_NEAR:
			return 18
		DISTANCE_LOCAL:
			return 35
		DISTANCE_FAR:
			return 70
		_:
			return 95


static func _edge_id(a: String, b: String) -> String:
	var left := a.strip_edges()
	var right := b.strip_edges()
	if left.is_empty() or right.is_empty() or left == right:
		return ""
	if left < right:
		return "%s--%s" % [left, right]
	return "%s--%s" % [right, left]


static func _sorted_keys(source: Dictionary) -> Array:
	var result: Array = []
	for key in source.keys():
		result.append(str(key))
	result.sort()
	return result


static func _unique_strings(a: Array, b: Array = []) -> Array:
	var result: Array = []
	for source in [a, b]:
		for value in source:
			var text := str(value).strip_edges()
			if not text.is_empty() and not result.has(text):
				result.append(text)
	return result
