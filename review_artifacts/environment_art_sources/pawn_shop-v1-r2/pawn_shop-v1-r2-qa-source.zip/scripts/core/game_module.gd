class_name GameModule
extends RefCounted

const IoResultScript := preload("res://scripts/core/io_result.gd")
const KeysScript := preload("res://scripts/core/keys.gd")

# Base contract for foundation gambling modules.

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")
const PlayerTextScript := preload("res://scripts/ui/player_text.gd")

const RESULT_CONTINUE := "continue"
const RESULT_ENDED := "ended"
const GAMEPLAY_MODEL_GENERIC_ODDS := "generic_odds"
const GAMEPLAY_MODEL_FULL_SIMULATION := "full_simulation"
const TABLE_ROUND_START_DELAY_MSEC := 20000
const TABLE_ROUND_WARNING_MSEC := 5000
const APPLIED_CURRENCY_SETTLEMENT_SCHEMA := "bth.applied_currency_settlement/v1"

var definition: Dictionary = {}
var library: ContentLibrary
var _transient_state_key_context := ""


# Stores the game definition used by this module.
func setup(p_definition: Dictionary, p_library: ContentLibrary = null) -> void:
	definition = p_definition.duplicate(true)
	library = p_library


# Returns this game id.
func get_id() -> String:
	return str(definition.get("id", ""))


# Returns the player-facing game name.
func get_display_name() -> String:
	return str(definition.get("display_name", get_id()))


# Returns the game family used by item modifiers.
func get_family() -> String:
	return str(definition.get("family", ""))


# Selects a generated fixture for the current host interaction without writing
# that presentation choice into RunState. Hosts may temporarily override this
# context while advancing another fixture in the background.
func set_transient_state_key_context(state_key: String) -> void:
	_transient_state_key_context = state_key.strip_edges()


# Returns the host-selected fixture key used for the current read/action only.
func transient_state_key_context() -> String:
	return _transient_state_key_context


# Distinguishes simple data-authored odds games from modules that own their
# full subgame state and rules.
func gameplay_model() -> String:
	if bool(definition.get("full_simulation", false)):
		return GAMEPLAY_MODEL_FULL_SIMULATION
	var model := str(definition.get("gameplay_model", GAMEPLAY_MODEL_GENERIC_ODDS))
	return GAMEPLAY_MODEL_FULL_SIMULATION if model == GAMEPLAY_MODEL_FULL_SIMULATION else GAMEPLAY_MODEL_GENERIC_ODDS


# Convenience predicate for hosts choosing between generic odds and a complete
# module-owned surface/state lifecycle.
func is_full_simulation() -> bool:
	return gameplay_model() == GAMEPLAY_MODEL_FULL_SIMULATION


# Optional closed authority provider for modules whose live actions require a
# Foundation-owned sealed transaction host. Generic modules return no provider.
func sealed_action_authority_script() -> Script:
	return null


# Module-owned vocabulary for the optional sealed authority provider. The live
# host consumes generic field names and never infers game identity from methods.
func sealed_action_authority_contract() -> Dictionary:
	return {}


# Creates the entry message shown when a player enters the game.
func enter(_run_state: RunState, environment: Dictionary) -> Dictionary:
	return {
		"ok": true,
		"type": "game_enter",
		"game_id": get_id(),
		"environment_id": environment.get("id", ""),
		"message": str(definition.get("intro", "You sit down to play.")),
	}


# Returns legal actions from the game definition.
func legal_actions(run_state: RunState, environment: Dictionary) -> Array:
	var result := _copy_array(definition.get("legal_actions", []))
	if run_state != null:
		result.append_array(run_state.crew_play_actions(get_id(), environment))
	return result


# Returns cheat actions from the game definition.
func cheat_actions(run_state: RunState, environment: Dictionary) -> Array:
	if run_state != null and run_state.challenge_cheat_actions_disabled():
		return []
	var actions := _copy_array(definition.get("cheat_actions", []))
	var result: Array = []
	var security_bonus := run_state.security_risk_bonus("cheat") if run_state != null else 0
	var pit_boss_status := run_state.pit_boss_watch_status(environment) if run_state != null else {}
	var pit_boss_bonus := int(pit_boss_status.get("cheat_heat_bonus", 0)) if bool(pit_boss_status.get("active", false)) else 0
	for action in actions:
		if typeof(action) != TYPE_DICTIONARY:
			continue
		var action_data := (action as Dictionary).duplicate(true)
		var base_delta := int(action_data.get("suspicion_delta", 0))
		action_data["base_suspicion_delta"] = base_delta
		action_data["suspicion_delta"] = maxi(0, base_delta + security_bonus + pit_boss_bonus)
		action_data["security_pressure_bonus"] = security_bonus
		action_data["pit_boss_heat_bonus"] = pit_boss_bonus
		action_data["pit_boss_watched"] = bool(pit_boss_status.get("watched", false))
		if run_state != null:
			action_data["security_pressure"] = run_state.security_pressure_label()
			action_data["security_pressure_summary"] = run_state.security_pressure_summary()
			if bool(pit_boss_status.get("active", false)):
				var pit_summary := str(pit_boss_status.get("summary", ""))
				if not pit_summary.is_empty():
					action_data["security_pressure_summary"] = "%s %s" % [action_data["security_pressure_summary"], pit_summary]
		result.append(action_data)
	return result


# Packages all actions and stake bounds for the UI.
func actions(run_state: RunState, environment: Dictionary) -> Dictionary:
	var economic_profile: Dictionary = environment.get("economic_profile", {}) if typeof(environment.get("economic_profile", {})) == TYPE_DICTIONARY else {}
	var base_stake_ceiling := stake_ceiling_for_game(environment, get_id(), run_state.wager_capacity_for_game(get_id(), environment))
	var economy_stake_ceiling := run_state.economy_stake_ceiling(base_stake_ceiling)
	var wager_stake_ceiling := run_state.wager_stake_ceiling(base_stake_ceiling)
	return {
		"ok": true,
		"type": "game_actions",
		"game_id": get_id(),
		"legal_actions": legal_actions(run_state, environment),
		"cheat_actions": cheat_actions(run_state, environment),
		"stake_floor": stake_floor_for_game(environment, get_id(), int(economic_profile.get("stake_floor", 1))),
		"stake_ceiling": wager_stake_ceiling,
		"base_stake_ceiling": base_stake_ceiling,
		"economy_stake_ceiling": economy_stake_ceiling,
		"economy_state": run_state.economy(),
		"economy_pressure_applied": economy_stake_ceiling < wager_stake_ceiling,
}


# Returns the room stake floor, optionally overridden per game id.
static func stake_floor_for_game(environment: Dictionary, game_id: String, fallback_floor: int = 1) -> int:
	var economic_profile: Dictionary = environment.get("economic_profile", {}) if typeof(environment.get("economic_profile", {})) == TYPE_DICTIONARY else {}
	var floor := int(economic_profile.get("stake_floor", fallback_floor))
	var overrides: Dictionary = economic_profile.get("game_stake_floor_overrides", {}) if typeof(economic_profile.get("game_stake_floor_overrides", {})) == TYPE_DICTIONARY else {}
	var normalized_game_id := game_id.strip_edges()
	if not normalized_game_id.is_empty() and overrides.has(normalized_game_id):
		floor = int(overrides.get(normalized_game_id, floor))
	return maxi(0, floor)


# Returns the room stake ceiling, optionally overridden per game id.
static func stake_ceiling_for_game(environment: Dictionary, game_id: String, fallback_ceiling: int = 1) -> int:
	var economic_profile: Dictionary = environment.get("economic_profile", {}) if typeof(environment.get("economic_profile", {})) == TYPE_DICTIONARY else {}
	var ceiling := int(economic_profile.get("stake_ceiling", fallback_ceiling))
	var overrides: Dictionary = economic_profile.get("game_stake_ceiling_overrides", {}) if typeof(economic_profile.get("game_stake_ceiling_overrides", {})) == TYPE_DICTIONARY else {}
	var normalized_game_id := game_id.strip_edges()
	if not normalized_game_id.is_empty() and overrides.has(normalized_game_id):
		ceiling = int(overrides.get(normalized_game_id, ceiling))
	return maxi(0, ceiling)


# Optional game-specific surface presentation. Returned data is display/input
# state only; simulation changes still happen through resolve/apply_result.
func surface_state(_run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> Dictionary:
	return {}


# Optional complete action-boundary patch for an embedded surface. Unlike a
# result-carried patch, this is derived after the sealed candidate has published
# and therefore does not enlarge replay receipts with presentation-only state.
func embedded_action_view_patch(_run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> Dictionary:
	return {}


# Most embedded game actions refresh their complete presentation before the
# input callback returns. Solver-heavy modules may opt into the same next-frame
# presentation handoff used by autoplay after their authoritative result and
# post-action interrupt boundaries have completed synchronously.
func defers_embedded_action_presentation_refresh(_run_state: RunState, _environment: Dictionary) -> bool:
	return false


# Solver-heavy modules may provide a small exact rollback token for mutations
# they make before the host's atomic environment-turn boundary. An empty token
# keeps the conservative whole-run snapshot used by every other game.
func host_action_rollback_snapshot(_action_id: String, _run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {}


# Restores a module-provided rollback capsule after the host rejects publication.
# Returning false asks the host to use its conservative whole-run fallback.
func restore_host_action_rollback(_snapshot: Dictionary, _run_state: RunState, _environment: Dictionary) -> bool:
	return false


# Exposes sparse, action-boundary tutorial facts without teaching the UI any
# game-specific state schema.
func coach_state(_run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> Dictionary:
	return {}


# Reports whether a wager that already started still needs player/automatic
# actions before its outcome is final. Venue closing may block a new wager, but
# must never strand one of these in-progress activities.
func wager_activity_incomplete(_run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> bool:
	return false


# Optional game-owned renderer for the active surface. The shared UI canvas
# passes itself in only as a draw/hit host; game-specific scene composition must
# stay in the concrete game module.
func draw_surface(_surface_canvas, _surface_state: Dictionary, _render_context: Dictionary = {}) -> bool:
	return false


# Optional game-specific state generated with an environment before the UI sees
# it. This lets involved games own machine/table state without mutating on
# selection or entry.
func generate_environment_state(_run_state: RunState, _environment: Dictionary, _rng: RngStream) -> Dictionary:
	return {}


# Commits effects that belong to canonical environment generation rather than
# to a UI read. RunGenerator invokes this only after it creates and stores a
# new game state; previews operate on their cloned RunState.
func environment_state_generated(_run_state: RunState, _environment: Dictionary, _generated_state: Dictionary) -> void:
	pass


# Optional translation layer for visible game-surface clicks. Modules can
# update UI-local state or nominate an existing legal/cheat action to resolve.
func surface_action_command(_surface_action: String, _index: int, _confirm_requested: bool, _ui_state: Dictionary, _run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {"handled": false}


# Button-native surfaces can opt out of cloning the complete retained UI
# session before every click. Their action and direct-resolve paths must consume
# only the declared keys plus the host-owned selected action/stake scalars.
func surface_action_uses_lightweight_ui_state(_surface_action: String) -> bool:
	return false


# Declares the retained UI keys required by lightweight surface action commands.
func surface_action_ui_state_keys() -> Array:
	return []


# Commits UI-local interaction state only when a surface is being dismissed.
# This preserves the non-mutating click contract while allowing physical
# partially opened objects to survive travel, closure, inventory, and save UI.
func checkpoint_surface_ui_state(_ui_state: Dictionary, _run_state: RunState, _environment: Dictionary) -> void:
	pass


# Autosaves and actual surface dismissal are different lifecycle boundaries.
# Most modules use the same checkpoint for both; continuous simulations may
# defer a save until they have produced a natural settled snapshot.
func checkpoint_surface_ui_state_for_save(ui_state: Dictionary, run_state: RunState, environment: Dictionary) -> void:
	checkpoint_surface_ui_state(ui_state, run_state, environment)


# Modules whose save checkpoint is entirely backed by durable/runtime state can
# skip construction of the retained surface UI snapshot. That snapshot may hold
# a complete card shoe, roulette undo history, or dense physical-machine view.
func checkpoint_surface_ui_state_for_save_requires_ui_state() -> bool:
	return true


# A module may restore a small durable in-progress surface after Continue or
# after leaving and re-entering its room. The default keeps existing games' UI
# lifecycle unchanged.
func restored_surface_ui_state(_run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {}


# Reports whether the module has reached a durable state safe for Foundation's
# normal save path; continuous simulations can hold this false while settling.
func foundation_save_ready(_run_state: RunState, _environment: Dictionary) -> bool:
	return true


# Selects the bounded multi-frame exit-settlement protocol instead of immediate
# checkpointing for a dense continuous simulation.
func requires_chunked_exit_settle(_run_state: RunState, _environment: Dictionary) -> bool:
	return false


# Starts module-owned chunked settlement and returns progress metadata for the
# host. The default is already complete.
func begin_chunked_exit_settle(_run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {"started": false, "done": true}


# Advances at most tick_budget settlement steps and reports completion/progress.
func advance_chunked_exit_settle(_run_state: RunState, _environment: Dictionary, _tick_budget: int = 8) -> Dictionary:
	return {"done": true, "ticks": 0}


# Publishes the final durable checkpoint after chunked settlement completes.
func finalize_chunked_exit_settle(_run_state: RunState, _environment: Dictionary) -> void:
	pass


# Cancels transient work when the host abandons a chunked exit during a broader
# lifecycle reset (load, main menu, test-room replacement, or scene teardown).
# Modules must not publish additional durable state from this callback.
func cancel_chunked_exit_settle() -> void:
	pass


# Optional pointer-capture path for drag-native surfaces. Positions are in the
# shared board design space and phases are begin, move, or end.
func surface_pointer_command(_surface_action: String, _index: int, _phase: String, _board_position: Vector2, _ui_state: Dictionary, _run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {"handled": false}


# Drag-heavy surfaces can opt out of rebuilding time/status/talk UI state for
# every pointer sample. Their pointer handler must only consume UI-local keys.
func surface_pointer_uses_lightweight_ui_state(_surface_action: String) -> bool:
	return false


# Optional per-frame game-surface automation hook. The foundation UI provides
# only UI-local state, the current environment, and a surface snapshot; modules
# decide whether to request a resolved action.
func surface_uses_auto_tick() -> bool:
	return false


# Optional allocation-free guard for surfaces whose automatic action loop is
# normally dormant. FoundationMain calls this before constructing timestamps,
# stake data, or a tick snapshot. Returning false must mean that no automatic
# command can become due until a player command changes the retained UI state.
func surface_auto_tick_may_be_active(_retained_ui_state: Dictionary) -> bool:
	return true


# Exact due predicate for automatic surface commands. It is evaluated without
# making animation liveness depend on pointer input.
func surface_needs_auto_tick(_ui_state: Dictionary, _run_state: RunState, _environment: Dictionary) -> bool:
	return false


# Declares the retained UI keys required by the automatic surface due predicate
# and command when lightweight state is enabled.
func surface_auto_tick_state_keys() -> Array:
	return []


# Automation normally receives the complete surface UI state at the action
# boundary. Modules whose command and resolution paths consume only the
# lightweight tick keys can opt out of that deep copy.
func surface_auto_action_uses_lightweight_ui_state() -> bool:
	return false


# Realtime simulations that consume only a few UI-local fields can opt out of
# duplicating the complete retained surface session on every fixed tick.
func surface_realtime_uses_lightweight_ui_state() -> bool:
	return false


# Declares the retained UI keys required to build a lightweight realtime patch.
func surface_realtime_ui_state_keys() -> Array:
	return []


# Modules whose realtime patch cannot change bankroll, pressure, intoxication,
# selection, or accessibility host state may retain those existing surface
# fields until the next normal action/refresh boundary.
func surface_realtime_patch_preserves_host_state() -> bool:
	return false


# Foreground games can suspend background machine/runtime ticks while a player
# decision is unresolved. The default is intentionally a zero-allocation false;
# modules that need the gate can inspect their authoritative retained state
# directly instead of asking FoundationMain to construct a complete surface.
func foreground_blocks_environment_runtime(_run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> bool:
	return false


# Indicates whether a still-playing foreground presentation also suspends that
# fixture's background runtime to prevent double advancement.
func foreground_blocks_environment_runtime_during_surface_presentation() -> bool:
	return false


# Returns one host-normalized automatic command when due; it does not apply the
# result itself.
func surface_auto_action_command(_ui_state: Dictionary, _run_state: RunState, _environment: Dictionary, _surface_status: Dictionary = {}) -> Dictionary:
	return {"handled": false}


# Optional hook for stopping repeating surface actions before the shared UI opens
# a blocking decision popup such as an all-in wager confirmation.
func surface_pause_repeating_action_for_confirmation(_ui_state: Dictionary, _run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {"handled": false}


# Optional environment-level runtime state. Games use this for persistent
# machine/table activity that should continue while the detailed surface is
# closed, such as an autoplaying slot cabinet.
func environment_runtime_enabled() -> bool:
	return false


# Returns the player-safe current background-runtime projection for this fixture.
func environment_runtime_state(_run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {}


# Cheap exact predicate used by the scheduler at or after the declared due time.
func environment_runtime_needs_tick(_run_state: RunState, _environment: Dictionary, _now_msec: int) -> bool:
	return false


# Returns the next monotonic simulation timestamp this fixture needs. A
# negative value means inactive. Modules with background runtime should
# override this so the host does not poll every fixture every frame.
func environment_runtime_next_due_msec(run_state: RunState, environment: Dictionary, now_msec: int) -> int:
	return now_msec if environment_runtime_needs_tick(run_state, environment, now_msec) else -1


# Advances one background-runtime boundary and returns a host-normalized patch or
# action request; modules must not perform unrelated RunState work here.
func environment_runtime_tick(_run_state: RunState, _environment: Dictionary, _rng: RngStream, _now_msec: int) -> Dictionary:
	return {"handled": false}


# Optional game-authored presentation payload for the room sprite/object.
# Foundation UI merges this with the data definition and runtime state.
func environment_object_state(_run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {}


# Optional game-authored room objects, such as a cashier or attendant attached
# to a specific machine. Foundation UI renders and activates these generically.
func environment_interactable_objects(_run_state: RunState, _environment: Dictionary) -> Array:
	return []


# Causal room publication calls this before discovering read-only hooks. A
# module with visit/time-driven physical occupants must commit its own state
# and matching membership here; ordinary modules have nothing to prepare.
func prepare_environment_presentation_boundary(_run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {"ok": true, "changed": false, "errors": []}


# Optional action resolver for game-authored room objects.
func environment_action_command(_hook_id: String, _action_id: String, _run_state: RunState, _environment: Dictionary, _rng: RngStream) -> Dictionary:
	return {"handled": false}


# Optional action resolver for active inventory items used against the current
# game surface or environment.
func active_item_command(_item_id: String, _run_state: RunState, _environment: Dictionary, _rng: RngStream) -> Dictionary:
	return {"handled": false}


# Optional resolve entry point that receives UI-local surface context. The
# default preserves the existing foundation GameModule behavior.
func resolve_with_context(action_id: String, stake: int, run_state: RunState, environment: Dictionary, rng: RngStream, _ui_state: Dictionary = {}) -> Dictionary:
	if action_id.begins_with("crew_play:"):
		return run_state.crew_play_activate(action_id.trim_prefix("crew_play:"), get_id(), environment)
	return resolve(action_id, stake, run_state, environment, rng)


# Returns the bankroll at risk for a selected action before the result is known.
# Concrete games can override this when free plays or fixed-price tickets apply.
func wager_cost_for_context(action_id: String, stake: int, _run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> int:
	if action_id.begins_with("crew_play:"):
		return 0
	return maxi(0, stake)


# Returns cash guaranteed to be credited back even in the action's worst
# possible bankroll outcome. Games can override this for refund effects.
func minimum_wager_return_for_context(_action_id: String, _stake: int, _wager_cost: int, _run_state: RunState, _environment: Dictionary, _ui_state: Dictionary = {}) -> int:
	return 0


# Returns the shared result-delta shape used by foundation modules.
static func empty_result_deltas() -> Dictionary:
	return {
		"bankroll_delta": 0,
		"chips_delta": 0,
		"suspicion_delta": 0,
		"alcohol_intake": 0,
		"drunk_delta": 0,
		"pending_drunk_absorption_delta": 0,
		"drunk_distortion_suppression_turns": 0,
		"heat_cooldown_actions": 0,
		"heat_cooldown_per_action": 0,
		"alcoholic_delta": 0,
		"baseline_luck_delta": 0,
		"debt_changes": [],
		"inventory_add": [],
		"inventory_remove": [],
		"flags_set": {},
		"story_flags_set": {},
		"environment_layer_discovery": {},
		"travel_hooks_add": [],
		"travel_changes": {},
		"story_log": [],
		"messages": [],
		"pending_bags": [],
		"ended": false,
		"item_hooks": [],
		"event_hooks": [],
		"demo_finale": {},
		"discounted_debt_settlement": {},
	}


# Builds the shared game-surface state shape. Concrete modules can still add
# any renderer-specific fields; these keys are the reusable host contract.
static func surface_spec(payload: Dictionary = {}) -> Dictionary:
	var spec := payload.duplicate(true)
	spec["surface_renderer"] = str(spec.get("surface_renderer", spec.get("renderer", "result")))
	spec["surface_life"] = str(spec.get("surface_life", spec.get("surface_renderer", "result")))
	spec["surface_cast"] = str(spec.get("surface_cast", "none"))
	spec["surface_controls_native"] = bool(spec.get("surface_controls_native", false))
	spec["surface_fixed_price_actions"] = bool(spec.get("surface_fixed_price_actions", false))
	spec["surface_stake_controls_required"] = bool(spec.get("surface_stake_controls_required", true))
	spec["surface_animates_idle"] = bool(spec.get("surface_animates_idle", false))
	spec["surface_realtime_state_refresh"] = bool(spec.get("surface_realtime_state_refresh", false))
	spec["surface_embeds_outcomes"] = bool(spec.get("surface_embeds_outcomes", false))
	spec["surface_suppresses_game_result_burst"] = bool(spec.get("surface_suppresses_game_result_burst", false))
	# The full payload copy above already owns every nested container. Reusing
	# those owned values avoids copying the largest renderer fields a second time.
	spec["surface_action_bindings"] = _owned_dict(spec.get("surface_action_bindings", {}))
	spec["native_selected_surface_actions"] = _owned_array(spec.get("native_selected_surface_actions", []))
	spec["surface_animation_channels"] = _normalize_surface_animation_channels(spec.get("surface_animation_channels", []), true)
	spec["surface_audio"] = _owned_dict(spec.get("surface_audio", {}))
	spec["surface_action_blocks"] = _owned_array(spec.get("surface_action_blocks", []))
	spec["surface_state_labels"] = _owned_array(spec.get("surface_state_labels", []))
	spec["surface_result_display"] = _owned_dict(spec.get("surface_result_display", {}))
	spec["surface_ui_preference_keys"] = _owned_array(spec.get("surface_ui_preference_keys", []))
	return spec


# Declares one reusable animation channel for GameSurfaceCanvas. The module owns
# the ids and timing; the canvas only tracks elapsed time.
static func surface_animation_channel(channel_id: String, active_id: String = "", duration_msec: int = 0, started_msec: int = 0, payload: Dictionary = {}) -> Dictionary:
	var channel := payload.duplicate(true)
	channel["id"] = channel_id
	channel["active_id"] = active_id
	channel["duration_msec"] = maxi(0, duration_msec)
	channel["started_msec"] = maxi(0, started_msec)
	if not channel.has("active"):
		channel["active"] = not active_id.is_empty()
	if not channel.has("restart_on_active_id_change"):
		channel["restart_on_active_id_change"] = true
	if not channel.has("metadata"):
		channel["metadata"] = {}
	return channel


# Normalizes the semantic audio profile, deterministic selection seed, action
# cues, and state-sync values consumed by SfxPlayer.
static func surface_audio_spec(payload: Dictionary = {}) -> Dictionary:
	var spec := payload.duplicate(true)
	spec["profile_id"] = str(spec.get("profile_id", "default"))
	spec["selection_seed"] = maxi(1, int(spec.get("selection_seed", 1)))
	spec["action_cues"] = _owned_dict(spec.get("action_cues", {}))
	spec["state_sync"] = _owned_dict(spec.get("state_sync", {}))
	return spec


# Returns and, when requested, starts the shared between-round timer stored in
# the mutable table dictionary.
static func table_round_timer_status(table: Dictionary, now_msec: int, label: String = "Next round", duration_msec: int = TABLE_ROUND_START_DELAY_MSEC, auto_start: bool = true) -> Dictionary:
	return _table_round_timer_status_impl(table, now_msec, label, duration_msec, auto_start, true)


# Read-only timer projection; unlike table_round_timer_status, it never writes a
# missing start timestamp into the table.
static func table_round_timer_status_peek(table: Dictionary, now_msec: int, label: String = "Next round", duration_msec: int = TABLE_ROUND_START_DELAY_MSEC, auto_start: bool = true) -> Dictionary:
	return _table_round_timer_status_impl(table, now_msec, label, duration_msec, auto_start, false)


static func _table_round_timer_status_impl(table: Dictionary, now_msec: int, label: String, duration_msec: int, auto_start: bool, mutate_start: bool) -> Dictionary:
	var safe_duration := maxi(1000, duration_msec)
	var started := int(table.get("table_round_timer_started_msec", 0))
	if auto_start and mutate_start and started == 0:
		started = now_msec
		table["table_round_timer_started_msec"] = started
	var elapsed := maxi(0, now_msec - started) if started != 0 else 0
	var remaining := maxi(0, safe_duration - elapsed)
	return {
		"active": started != 0,
		"label": label,
		"started_msec": started,
		"duration_msec": safe_duration,
		"elapsed_msec": elapsed,
		"remaining_msec": remaining,
		"remaining_seconds": int(ceil(float(remaining) / 1000.0)),
		"progress": clampf(float(elapsed) / float(safe_duration), 0.0, 1.0),
		"due": started != 0 and elapsed >= safe_duration,
		"warning": remaining <= TABLE_ROUND_WARNING_MSEC,
	}


# Clears the shared timer or restarts it from an explicit monotonic timestamp.
static func reset_table_round_timer(table: Dictionary, now_msec: int = 0) -> void:
	if now_msec > 0:
		table["table_round_timer_started_msec"] = now_msec
	else:
		table["table_round_timer_started_msec"] = 0


# Selects the host-provided presentation clock when available, otherwise the
# deterministic RunState simulation clock; it never returns zero.
static func deterministic_time_msec(run_state: RunState, ui_state: Dictionary = {}) -> int:
	if ui_state.has("surface_time_msec"):
		return maxi(1, int(ui_state.get("surface_time_msec", 0)))
	if run_state != null:
		return maxi(1, run_state.simulation_time_msec())
	return 1


static func _is_skill_action_kind(action_kind: String) -> bool:
	return action_kind == "cheat" or action_kind == "risky" or action_kind == "advantage"


# Normalizes UI-local command responses from surface click handlers.
static func surface_command(payload: Dictionary = {}, zero_copy_transient: bool = false) -> Dictionary:
	var command := payload.duplicate(not zero_copy_transient)
	command["handled"] = bool(command.get("handled", true))
	var ui_state_value: Variant = command.get("ui_state", {})
	command["ui_state"] = (ui_state_value as Dictionary).duplicate(not zero_copy_transient) if typeof(ui_state_value) == TYPE_DICTIONARY else {}
	command["surface_transient"] = bool(command.get("surface_transient", zero_copy_transient))
	command["selected_index"] = int(command.get("selected_index", -1))
	command["action_id"] = str(command.get("action_id", ""))
	command["action_kind"] = str(command.get("action_kind", ""))
	command["resolve"] = bool(command.get("resolve", false))
	command["direct_resolve"] = bool(command.get("direct_resolve", false))
	command["skip_stake_validation"] = bool(command.get("skip_stake_validation", false))
	command["preserve_surface_ui_state"] = bool(command.get("preserve_surface_ui_state", false))
	if command.has("set_stake"):
		command["set_stake"] = int(command.get("set_stake", 0))
	if command.has("stake_multiplier"):
		command["stake_multiplier"] = int(command.get("stake_multiplier", 1))
	command["message"] = str(command.get("message", ""))
	return command
# Orders and clamps timing windows so perfect is contained by good, which is
# contained by close.
static func normalize_skill_timing_windows(perfect_msec: int, good_msec: int, close_msec: int, min_perfect_msec: int = 1) -> Dictionary:
	var perfect := maxi(maxi(1, min_perfect_msec), perfect_msec)
	var good := maxi(perfect, good_msec)
	var close := maxi(good, close_msec)
	return {
		"perfect_window_msec": perfect,
		"good_window_msec": good,
		"close_window_msec": close,
	}


# Grades an absolute timing distance against normalized windows and returns the
# shared grade, accuracy, distance, and effective windows.
static func skill_timing_grade_from_distance(distance_msec: int, perfect_msec: int, good_msec: int, close_msec: int, min_perfect_msec: int = 1) -> Dictionary:
	var windows := normalize_skill_timing_windows(perfect_msec, good_msec, close_msec, min_perfect_msec)
	var distance := maxi(0, distance_msec)
	var perfect := int(windows.get("perfect_window_msec", 1))
	var good := int(windows.get("good_window_msec", perfect))
	var close := int(windows.get("close_window_msec", good))
	var grade := "blown"
	if distance <= perfect:
		grade = "perfect"
	elif distance <= good:
		grade = "good"
	elif distance <= close:
		grade = "partial"
	var accuracy := 0
	if grade != "blown":
		accuracy = clampi(100 - int(round(float(distance) / float(close) * 100.0)), 0, 100)
	return {
		"skill_grade": grade,
		"skill_accuracy": accuracy,
		"skill_distance_msec": distance,
		"windows": windows,
	}


# True for grades that apply the attempted advantage rather than a complete miss.
static func skill_grade_applies(grade: String) -> bool:
	return grade == "perfect" or grade == "good" or grade == "partial"


# Builds the stable shared outcome key for a game-specific skill prefix/grade.
static func skill_outcome_for_grade(prefix: String, grade: String, fallback_grade: String = "miss") -> String:
	var resolved_grade := grade if not grade.is_empty() else fallback_grade
	return "%s_%s" % [prefix, resolved_grade]


# Builds a normalized ActionResult dictionary from module payload data.
static func build_action_result(payload: Dictionary = {}) -> Dictionary:
	return _build_action_result(payload, false)


# Builds a normalized ActionResult while taking ownership of the payload's
# delta containers. Use this only for fresh, action-local payloads that are not
# retained by their producer. The public result shape and alias boundaries are
# identical to build_action_result. Legacy aliases or unknown delta keys fall
# back to the copying builder; only canonical single-owner deltas take the fast
# path.
static func build_owned_action_result(payload: Dictionary = {}) -> Dictionary:
	var deltas_value: Variant = payload.get("deltas", {})
	if typeof(deltas_value) != TYPE_DICTIONARY or not _has_only_canonical_result_delta_keys(deltas_value as Dictionary):
		return _build_action_result(payload, false)
	return _build_action_result(payload, true)


# Fast path for trusted action-local payloads already known to contain only the
# canonical result-delta vocabulary.
static func build_canonical_owned_action_result(payload: Dictionary = {}) -> Dictionary:
	# Hot paths that construct only canonical delta keys can transfer ownership
	# directly. The normal public builder remains fail-safe for untrusted shapes.
	return _build_action_result(payload, true)


static func _build_action_result(payload: Dictionary, take_delta_ownership: bool) -> Dictionary:
	var source_deltas := _owned_dict(payload.get("deltas", {})) if take_delta_ownership else _copy_dict(payload.get("deltas", {}))
	for key in ["bankroll_delta", "suspicion_delta", "alcohol_intake", "drunk_delta", "pending_drunk_absorption_delta", "drunk_distortion_suppression_turns", "heat_cooldown_actions", "heat_cooldown_per_action", "alcoholic_delta", "baseline_luck_delta", "ended"]:
		if payload.has(key) and not source_deltas.has(key):
			source_deltas[key] = payload[key]
	if payload.has("messages") and not source_deltas.has("messages"):
		source_deltas["messages"] = _owned_array(payload.get("messages", [])) if take_delta_ownership else _copy_array(payload.get("messages", []))
	var deltas := _normalize_result_deltas(source_deltas, take_delta_ownership)
	var message := str(payload.get("message", ""))
	if message.is_empty() and not deltas["messages"].is_empty():
		message = str(deltas["messages"][0])
	if not message.is_empty() and deltas["messages"].is_empty():
		deltas["messages"] = [message]
	var ended := bool(deltas.get("ended", false))
	var result := {
		"ok": bool(payload.get("ok", true)),
		"type": str(payload.get("type", "game_action")),
		"source_id": str(payload.get("source_id", "")),
		"game_id": str(payload.get("game_id", "")),
		"action_id": str(payload.get("action_id", "")),
		"action_kind": str(payload.get("action_kind", "unknown")),
		"stake": int(payload.get("stake", 0)),
		"bankroll_delta": int(deltas.get("bankroll_delta", 0)),
		"suspicion_delta": int(deltas.get("suspicion_delta", 0)),
		"deltas": deltas,
		"won": bool(payload.get("won", false)),
		"ended": ended,
		"state": RESULT_ENDED if ended else RESULT_CONTINUE,
		"environment_id": str(payload.get("environment_id", "")),
		"environment_archetype_id": str(payload.get("environment_archetype_id", "")),
		"message": message,
		"messages": _copy_array(deltas.get("messages", [])),
	}
	return normalize_skill_cheat_contract(result, payload, take_delta_ownership)


# Adds the cross-game skill-cheat contract to cheat/risky/advantage results.
# Game-specific modules still own their rules; this keeps shared systems from
# chasing blackjack_*, slot_*, roulette_*, etc. variants for the same facts.
static func normalize_skill_cheat_contract(result: Dictionary, payload: Dictionary = {}, take_delta_ownership: bool = false) -> Dictionary:
	var action_kind := str(result.get("action_kind", ""))
	if not _is_skill_action_kind(action_kind):
		return result
	var deltas := _normalize_result_deltas(result.get("deltas", {}), take_delta_ownership)
	var story_entries := _owned_array(deltas.get("story_log", [])) if take_delta_ownership else _copy_array(deltas.get("story_log", []))
	var story_context := _matching_story_entry(story_entries, result)
	var suspicion_delta := int(result.get("suspicion_delta", deltas.get("suspicion_delta", 0)))
	var bankroll_delta := int(result.get("bankroll_delta", deltas.get("bankroll_delta", 0)))
	var watched := _skill_bool_value("pit_boss_watched", result, payload, story_context, false)
	var pit_boss_heat_bonus := _skill_int_value("pit_boss_heat_bonus", result, payload, story_context, 0)
	var pressure_checked_default := true
	var pressure_checked := _skill_bool_value("skill_security_pressure_checked", result, payload, story_context, pressure_checked_default)
	var skill_outcome := _skill_string_value("skill_outcome", result, payload, story_context, "")
	if skill_outcome.is_empty():
		skill_outcome = _default_skill_outcome(action_kind, bool(result.get("won", false)), suspicion_delta, bankroll_delta)
	var skill_grade := _skill_string_value("skill_grade", result, payload, story_context, "")
	if skill_grade.is_empty():
		skill_grade = _default_skill_grade(skill_outcome, action_kind, bool(result.get("won", false)), suspicion_delta, bankroll_delta)
	var skill_accuracy := clampi(_skill_int_value("skill_accuracy", result, payload, story_context, _default_skill_accuracy(skill_grade, action_kind, bool(result.get("won", false)), suspicion_delta, bankroll_delta)), 0, 100)
	var skill_margin_msec := maxi(0, _skill_int_value("skill_margin_msec", result, payload, story_context, 0))
	var base_suspicion_delta := _skill_int_value("base_suspicion_delta", result, payload, story_context, -1)
	if base_suspicion_delta < 0 and deltas.has("base_suspicion_delta"):
		base_suspicion_delta = int(deltas.get("base_suspicion_delta", -1))
	if base_suspicion_delta < 0:
		base_suspicion_delta = _skill_int_value("base_heat", result, payload, story_context, -1)
	if base_suspicion_delta < 0:
		base_suspicion_delta = _skill_int_value("tab_detector_base_heat", result, payload, story_context, -1)
	if base_suspicion_delta < 0:
		base_suspicion_delta = suspicion_delta
	base_suspicion_delta = maxi(0, base_suspicion_delta)
	var security_message := _skill_string_value("security_message", result, payload, story_context, "")
	var skill_context := _copy_dict(payload.get("skill_story_context", story_context.get("skill_story_context", {})))
	if skill_context.is_empty():
		skill_context = {
			"game_id": str(result.get("game_id", "")),
			"action_id": str(result.get("action_id", "")),
			"action_kind": action_kind,
			"environment_id": str(result.get("environment_id", "")),
		}
	skill_context["skill_outcome"] = skill_outcome
	skill_context["skill_grade"] = skill_grade
	skill_context["skill_accuracy"] = skill_accuracy
	skill_context["skill_margin_msec"] = skill_margin_msec
	skill_context["suspicion_delta"] = suspicion_delta
	skill_context["base_suspicion_delta"] = base_suspicion_delta
	skill_context["bankroll_delta"] = bankroll_delta
	skill_context["watched"] = watched
	skill_context["pit_boss_heat_bonus"] = pit_boss_heat_bonus
	skill_context["security_pressure_checked"] = pressure_checked

	result["skill_cheat_contract"] = true
	result["skill_outcome"] = skill_outcome
	result["skill_grade"] = skill_grade
	result["skill_accuracy"] = skill_accuracy
	result["skill_margin_msec"] = skill_margin_msec
	result["skill_watched"] = watched
	result["watched"] = watched
	result["pit_boss_watched"] = watched
	result["pit_boss_heat_bonus"] = pit_boss_heat_bonus
	result["skill_suspicion_delta"] = suspicion_delta
	result["base_suspicion_delta"] = base_suspicion_delta
	result["skill_payoff_delta"] = bankroll_delta
	result["skill_security_pressure_checked"] = pressure_checked
	result["skill_story_context"] = skill_context.duplicate(true)
	if not security_message.is_empty():
		result["security_message"] = security_message

	var normalized_story: Array = story_entries if take_delta_ownership else []
	for story_index in range(story_entries.size()):
		var story_value: Variant = story_entries[story_index]
		if typeof(story_value) != TYPE_DICTIONARY:
			if not take_delta_ownership:
				normalized_story.append(story_value)
			continue
		var entry: Dictionary = (story_value as Dictionary) if take_delta_ownership else (story_value as Dictionary).duplicate(true)
		if _story_entry_matches_result(entry, result):
			entry["action_kind"] = str(entry.get("action_kind", action_kind))
			entry["skill_outcome"] = skill_outcome
			entry["skill_grade"] = skill_grade
			entry["skill_accuracy"] = skill_accuracy
			entry["skill_margin_msec"] = skill_margin_msec
			entry["suspicion_delta"] = suspicion_delta
			entry["base_suspicion_delta"] = base_suspicion_delta
			var applied := applied_currency_settlement(entry)
			entry["bankroll_delta"] = int(applied.get("delta", bankroll_delta))
			entry["skill_watched"] = watched
			entry["watched"] = watched
			entry["pit_boss_watched"] = watched
			entry["pit_boss_heat_bonus"] = pit_boss_heat_bonus
			entry["skill_security_pressure_checked"] = pressure_checked
			entry["skill_story_context"] = skill_context.duplicate(true)
			if not security_message.is_empty():
				entry["security_message"] = security_message
		if take_delta_ownership:
			normalized_story[story_index] = entry
		else:
			normalized_story.append(entry)
	deltas["story_log"] = normalized_story
	result["deltas"] = deltas
	return result
# Copies patrons and marks the TalkDock-focused patron as visibly speaking and
# watching without mutating the module's stored patron array.
static func patrons_with_talk_focus(patrons: Array, focused_speaker_value: Variant) -> Array:
	var focused_speaker := _copy_dict(focused_speaker_value)
	if focused_speaker.is_empty() or str(focused_speaker.get("role", "")) != "patron":
		return patrons.duplicate(true)
	var focused_index := int(focused_speaker.get("patron_index", -1))
	var focused_name := str(focused_speaker.get("name", "")).strip_edges()
	var result: Array = []
	for index in range(patrons.size()):
		var patron_value: Variant = patrons[index]
		if typeof(patron_value) != TYPE_DICTIONARY:
			result.append(patron_value)
			continue
		var patron: Dictionary = (patron_value as Dictionary).duplicate(true)
		var matches_index := focused_index >= 0 and index == focused_index
		var matches_name := not focused_name.is_empty() and str(patron.get("name", "")).strip_edges() == focused_name
		if matches_index or matches_name:
			patron["watching_player"] = true
			patron["tell_active"] = true
			if str(patron.get("behavior", "")).strip_edges().is_empty():
				patron["behavior"] = "speaking"
		result.append(patron)
	return result


# Returns the player-facing wager currency for this game/context; Grand Casino
# chip games use chips and all other contexts use cash.
static func presentation_currency_for_game(run_state: RunState, game_id: String, environment: Dictionary = {}) -> String:
	if run_state != null and run_state.grand_casino_game_uses_chips(game_id, environment):
		return "chips"
	return "cash"


# Compatibility entry point for callers that only own a transient result. New
# action settlement uses finalize_routed_settlement() so the durable embedded
# surface receives the same structured currency record.
static func finalize_routed_player_message(result: Dictionary, deltas: Dictionary) -> void:
	finalize_routed_settlement(null, result, deltas)


# Establishes one post-routing settlement authority for transient and persisted
# presentation. Zero-net results are intentional records too: a push still has
# a routed account and must not fall back to pre-routing Bankroll/CASH copy.
static func finalize_routed_settlement(run_state: RunState, result: Dictionary, deltas: Dictionary, sync_persisted: bool = true) -> void:
	var applied := applied_currency_settlement(result)
	var cash_delta := int(applied.get("cash_delta", deltas.get("bankroll_delta", 0)))
	var chips_delta := int(applied.get("chips_delta", deltas.get("chips_delta", 0)))
	if applied.is_empty() and cash_delta == 0 and chips_delta == 0 and not _zero_routed_settlement_is_authoritative(run_state, result):
		return
	var currency := _routed_settlement_currency(result, cash_delta, chips_delta)
	var delta := chips_delta if currency == "chips" else cash_delta
	var settlement_message := PlayerTextScript.format_settlement_delta(currency, delta)
	var settlement := {
		"currency": currency,
		"delta": delta,
		"message": settlement_message,
	}
	var authored_message := str(result.get("message", ""))
	var player_message := _routed_settlement_message(authored_message, currency, delta, settlement_message)
	var player_messages := _merge_routed_settlement_messages(result, deltas, authored_message, player_message, settlement_message)
	var message_key := "game.result.currency_settlement"
	var message_params := {
		"currency": currency,
		"delta": delta,
		"cash_delta": cash_delta,
		"chips_delta": chips_delta,
	}
	if not authored_message.is_empty() and authored_message != player_message:
		result["diagnostic_message"] = authored_message
	result["currency"] = currency
	result["currency_delta"] = delta
	result["settlement"] = settlement.duplicate(true)
	result["message_key"] = message_key
	result["message_params"] = message_params.duplicate(true)
	result["message"] = player_message
	result["messages"] = player_messages.duplicate()
	deltas["settlement"] = settlement.duplicate(true)
	deltas["message_key"] = message_key
	deltas["message_params"] = message_params.duplicate(true)
	deltas["message"] = player_message
	deltas["messages"] = player_messages.duplicate()
	if not applied.is_empty():
		_sync_applied_currency_story_settlement(deltas, settlement, message_key, message_params, player_message)
	result["deltas"] = deltas
	if sync_persisted:
		_sync_persisted_routed_settlement(run_state, result, settlement, message_key, message_params)


static func _zero_routed_settlement_is_authoritative(run_state: RunState, result: Dictionary) -> bool:
	if typeof(result.get("settlement", null)) == TYPE_DICTIONARY and not (result.get("settlement", {}) as Dictionary).is_empty():
		return true
	if run_state == null:
		return false
	var environment := run_state.current_environment
	var states_value: Variant = environment.get("game_states", {})
	if typeof(states_value) != TYPE_DICTIONARY:
		return false
	var states := states_value as Dictionary
	var game_id := str(result.get("game_id", result.get("source_id", ""))).strip_edges()
	var state_key := _routed_settlement_state_key(environment, states, game_id, result)
	if state_key.is_empty() or typeof(states.get(state_key, null)) != TYPE_DICTIONARY:
		return false
	var state := states.get(state_key, {}) as Dictionary
	var last_value: Variant = state.get("last_result", {})
	if typeof(last_value) != TYPE_DICTIONARY or (last_value as Dictionary).is_empty():
		return false
	var last_result := last_value as Dictionary
	if not last_result.has("bankroll_delta") or int(last_result.get("bankroll_delta", 1)) != 0:
		return false
	var result_action := str(result.get("action_id", "")).strip_edges()
	var stored_action := str(last_result.get("action_id", "")).strip_edges()
	if not result_action.is_empty() and stored_action == result_action:
		return true
	var authored_message := str(result.get("message", "")).strip_edges().to_lower()
	var stored_message := str(last_result.get("message", last_result.get("summary", ""))).strip_edges().to_lower()
	return not authored_message.is_empty() \
		and not stored_message.is_empty() \
		and (authored_message.find(stored_message) >= 0 or stored_message.find(authored_message) >= 0)


static func _routed_settlement_currency(result: Dictionary, cash_delta: int, chips_delta: int) -> String:
	var authored_currency := str(result.get("currency", "")).strip_edges().to_lower()
	if authored_currency == "chips" or (chips_delta != 0 and cash_delta == 0):
		return "chips"
	return "cash"


static func _routed_settlement_message(authored_message: String, currency: String, delta: int, settlement_message: String) -> String:
	var routed_authored := authored_message.strip_edges()
	if currency == "chips":
		routed_authored = _replace_cash_amounts_with_chips(routed_authored)
		routed_authored = routed_authored.replace("Bankroll", "Chip balance").replace("bankroll", "chip balance")
		routed_authored = routed_authored.replace("Cash", "Chips").replace("cash", "chips")
	if routed_authored.to_lower().find(settlement_message.to_lower()) >= 0:
		return routed_authored
	return PlayerTextScript.join_sentences([routed_authored, settlement_message]) if not routed_authored.is_empty() else settlement_message


static func _merge_routed_settlement_messages(result: Dictionary, deltas: Dictionary, authored_message: String, player_message: String, settlement_message: String) -> Array:
	var source_messages := _copy_array(deltas.get("messages", []))
	for value in _copy_array(result.get("messages", [])):
		if not source_messages.has(value):
			source_messages.append(value)
	var merged: Array = []
	if not player_message.is_empty():
		merged.append(player_message)
	for value in source_messages:
		var message := str(value).strip_edges()
		if message.is_empty() \
				or message == authored_message.strip_edges() \
				or message == settlement_message.strip_edges() \
				or merged.has(message):
			continue
		merged.append(message)
	return merged


static func _replace_cash_amounts_with_chips(message: String) -> String:
	# Hand-rolled scan for "$[+-]digits[,digits]": the Web release template is built without the RegEx module.
	var result := ""
	var index := 0
	while index < message.length():
		var start := index + 1
		if message[index] == "$" and start < message.length() and "+-".contains(message[start]):
			start += 1
		var end := start
		if message[index] == "$" and end < message.length() and message[end].is_valid_int():
			while end < message.length() and (message[end].is_valid_int() or message[end] == ","):
				end += 1
			var amount_text := message.substr(index + 1, end - index - 1)
			var amount := int(amount_text.replace(",", ""))
			var noun := "chip" if absi(amount) == 1 else "chips"
			result += "%s %s" % [amount_text, noun]
			index = end
			continue
		result += message[index]
		index += 1
	return result


# A measured zero differs from missing legacy history. Never infer this witness
# from a wallet observed after a later action or after Continue.
static func applied_currency_settlement(value: Dictionary) -> Dictionary:
	var raw: Variant = value.get("applied_currency_settlement", null)
	if typeof(raw) != TYPE_DICTIONARY:
		return {}
	var applied := raw as Dictionary
	if str(applied.get("schema", "")) != APPLIED_CURRENCY_SETTLEMENT_SCHEMA or str(applied.get("currency", "")) != "chips":
		return {}
	for key in ["delta", "cash_delta", "chips_delta", "nominal_cash_delta", "nominal_chips_delta"]:
		if not applied.has(key) or typeof(applied[key]) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(applied[key])) or float(applied[key]) != float(int(applied[key])):
			return {}
	if int(applied.cash_delta) != 0 or int(applied.nominal_cash_delta) != 0 \
			or int(applied.delta) != int(applied.chips_delta) \
			or int(applied.chips_delta) > 0 or int(applied.chips_delta) < int(applied.nominal_chips_delta):
		return {}
	return applied.duplicate(true)


static func _record_blackjack_penalty_applied_currency(run_state: RunState, result: Dictionary, deltas: Dictionary, cash_before: int, chips_before: int) -> void:
	# The original debit already ran. Preserve its nominal instructions and
	# confiscation metadata; the receipt records the observed wallet difference.
	var applied := {
		"schema": APPLIED_CURRENCY_SETTLEMENT_SCHEMA, "currency": "chips",
		"delta": run_state.grand_casino_chips - chips_before,
		"cash_delta": run_state.bankroll - cash_before,
		"chips_delta": run_state.grand_casino_chips - chips_before,
		"nominal_cash_delta": int(deltas.get("bankroll_delta", 0)),
		"nominal_chips_delta": int(deltas.get("chips_delta", 0)),
	}
	result["applied_currency_settlement"] = applied.duplicate(true)
	deltas["applied_currency_settlement"] = applied.duplicate(true)
	var story := _copy_array(deltas.get("story_log", []))
	for index in range(story.size()):
		if typeof(story[index]) != TYPE_DICTIONARY:
			continue
		var entry: Dictionary = story[index]
		if str(entry.get("type", "")) != "game_action" or str(entry.get("game_id", "")) != "blackjack" \
				or int(entry.get("bankroll_delta", 0)) != int(applied.nominal_chips_delta):
			continue
		entry = entry.duplicate(true)
		entry["nominal_bankroll_delta"] = int(entry.get("bankroll_delta", 0))
		entry["bankroll_delta"] = int(applied.delta)
		entry["chips_delta"] = int(applied.chips_delta)
		entry["currency"] = "chips"
		entry["applied_currency_settlement"] = applied.duplicate(true)
		story[index] = entry
	deltas["story_log"] = story


static func _sync_applied_currency_story_settlement(deltas: Dictionary, settlement: Dictionary, message_key: String, message_params: Dictionary, message: String) -> void:
	var story := _copy_array(deltas.get("story_log", []))
	for index in range(story.size()):
		if typeof(story[index]) != TYPE_DICTIONARY or applied_currency_settlement(story[index]).is_empty():
			continue
		var entry := _copy_dict(story[index])
		entry["currency_delta"] = int(settlement.get("delta", 0))
		entry["settlement"] = settlement.duplicate(true)
		entry["message_key"] = message_key
		entry["message_params"] = message_params.duplicate(true)
		entry["message"] = message
		story[index] = entry
	deltas["story_log"] = story


static func _sync_persisted_routed_settlement(run_state: RunState, result: Dictionary, settlement: Dictionary, message_key: String, message_params: Dictionary) -> void:
	if run_state == null or settlement.is_empty():
		return
	var environment := run_state.current_environment
	var states_value: Variant = environment.get("game_states", {})
	if typeof(states_value) != TYPE_DICTIONARY:
		return
	var states := states_value as Dictionary
	var game_id := str(result.get("game_id", result.get("source_id", ""))).strip_edges()
	var state_key := _routed_settlement_state_key(environment, states, game_id, result)
	if state_key.is_empty() or typeof(states.get(state_key, null)) != TYPE_DICTIONARY:
		return
	var state := (states.get(state_key, {}) as Dictionary).duplicate(false)
	var last_value: Variant = state.get("last_result", {})
	if typeof(last_value) != TYPE_DICTIONARY or (last_value as Dictionary).is_empty():
		return
	var last_result := (last_value as Dictionary).duplicate(true)
	var authored_message := str(last_result.get("message", last_result.get("summary", "")))
	var persisted_message := _routed_settlement_message(
		authored_message,
		str(settlement.get("currency", "cash")),
		int(settlement.get("delta", 0)),
		str(settlement.get("message", ""))
	)
	if not authored_message.is_empty() and authored_message != persisted_message:
		last_result["diagnostic_message"] = authored_message
	last_result["currency"] = str(settlement.get("currency", "cash"))
	last_result["currency_delta"] = int(settlement.get("delta", 0))
	last_result["settlement"] = settlement.duplicate(true)
	last_result["message_key"] = message_key
	last_result["message_params"] = message_params.duplicate(true)
	last_result["message"] = persisted_message
	last_result["summary"] = persisted_message
	var applied := applied_currency_settlement(result)
	if not applied.is_empty():
		last_result["applied_currency_settlement"] = applied
		last_result["nominal_bankroll_delta"] = int(last_result.get("nominal_bankroll_delta", last_result.get("bankroll_delta", 0)))
		last_result["bankroll_delta"] = int(applied.delta)
	state["last_result"] = last_result
	states[state_key] = state
	environment["game_states"] = states
	run_state.current_environment = environment


static func _routed_settlement_state_key(environment: Dictionary, states: Dictionary, game_id: String, result: Dictionary) -> String:
	for explicit_value in [result.get("game_state_key", ""), result.get("state_key", "")]:
		var explicit_key := str(explicit_value).strip_edges()
		if not explicit_key.is_empty() and states.has(explicit_key):
			return explicit_key
	var active_keys: Dictionary = environment.get("active_game_state_keys", {}) if typeof(environment.get("active_game_state_keys", {})) == TYPE_DICTIONARY else {}
	var active_key := str(active_keys.get(game_id, "")).strip_edges()
	if not active_key.is_empty() and states.has(active_key):
		return active_key
	if not game_id.is_empty() and states.has(game_id):
		return game_id
	var candidates: Array[String] = []
	for key_value in states.keys():
		var candidate := str(key_value)
		var candidate_state_value: Variant = states.get(key_value, {})
		if candidate.begins_with("%s:" % game_id) \
				and typeof(candidate_state_value) == TYPE_DICTIONARY \
				and typeof((candidate_state_value as Dictionary).get("last_result", null)) == TYPE_DICTIONARY:
			candidates.append(candidate)
	return candidates[0] if candidates.size() == 1 else ""


# Applies structured module changes through RunState.
static func apply_result(run_state: RunState, result: Dictionary, rng: RngStream = null, trusted_result_fingerprint: String = "") -> Dictionary:
	if run_state == null:
		return IoResultScript.failed(ERR_INVALID_PARAMETER, "missing_run_state", "Run state is required to apply a game result.")
	# Reject before receipt consumption, currency routing, or any other mutation.
	# Explicit terminal settlements are the only results allowed to finalize an
	# already-ended run.
	if bool(result.get(KeysScript.OK, false)) and run_state.is_terminal() and not bool(result.get("terminal_settlement", false)):
		return IoResultScript.failed(FAILED, "terminal_state_rejected", "A non-terminal result cannot be applied after the run has ended.")
	if not bool(result.get(KeysScript.OK, false)):
		run_state.clear_deferred_bankroll_zero_resolution()
		return IoResultScript.failed(
			int(result.get(IoResultScript.KEY_ERROR, FAILED)),
			str(result.get(IoResultScript.KEY_ERROR_CODE, "result_rejected")),
			str(result.get(KeysScript.MESSAGE, "Game result was rejected.")),
			{"result": result.duplicate(true)}
		)
	var result_game_id := str(result.get("game_id", result.get("source_id", "")))
	if (result_game_id == "blackjack" \
			or bool(result.get("table_game_authoritative", false)) \
			or bool(result.get("sealed_action_authoritative", false))) \
			and not run_state.consume_blackjack_authority_result_receipt(result, trusted_result_fingerprint):
		return IoResultScript.failed(ERR_INVALID_DATA, "authority_receipt_rejected", "The authoritative game receipt was rejected.")
	normalize_skill_cheat_contract(result)
	var deltas := _normalize_result_deltas(result.get("deltas", {}))
	run_state.record_score_spending_from_result(result, deltas)
	deltas = run_state.route_grand_casino_game_currency(result, deltas)
	var observe_chip_penalty := result_game_id == "blackjack" \
		and (bool(result.get("blackjack_watched_peek", false)) or bool(result.get("blackjack_cheat_caught", false))) \
		and str(result.get("currency", "")) == "chips" \
		and int(deltas.get("bankroll_delta", 0)) == 0 and int(deltas.get("chips_delta", 0)) <= 0
	if not observe_chip_penalty:
		finalize_routed_settlement(run_state, result, deltas, false)
	var defer_bankroll_zero := bool(result.get("defer_bankroll_zero_failure", false)) or run_state.defer_next_bankroll_zero_failure
	if defer_bankroll_zero:
		result["defer_bankroll_zero_failure"] = true
	var bankroll_delta := int(deltas.get(KeysScript.BANKROLL_DELTA, 0))
	var failed_before_money := run_state.run_status == RunState.RUN_STATUS_FAILED
	var cash_before := run_state.bankroll
	var chips_before := run_state.grand_casino_chips
	if bankroll_delta != 0:
		run_state.change_bankroll(bankroll_delta, defer_bankroll_zero)
	var chips_delta := int(deltas.get("chips_delta", 0))
	if chips_delta != 0:
		run_state.change_grand_casino_chips(chips_delta, defer_bankroll_zero)
	if observe_chip_penalty:
		_record_blackjack_penalty_applied_currency(run_state, result, deltas, cash_before, chips_before)
		finalize_routed_settlement(run_state, result, deltas, false)
	if not failed_before_money and run_state.run_status == RunState.RUN_STATUS_FAILED and not bool(result.get("terminal_settlement", false)):
		run_state.clear_deferred_bankroll_zero_resolution()
		return IoResultScript.failed(FAILED, "terminal_settlement_rejected", "The game settlement ended the run before it could be published.")
	_sync_persisted_routed_settlement(
		run_state,
		result,
		result.get("settlement", {}) if typeof(result.get("settlement", {})) == TYPE_DICTIONARY else {},
		str(result.get("message_key", "")),
		result.get("message_params", {}) if typeof(result.get("message_params", {})) == TYPE_DICTIONARY else {}
	)
	var suspicion_delta := int(deltas.get("suspicion_delta", 0))
	var blackjack_heat_attempt := suspicion_delta > 0 and result_game_id == "blackjack"
	if blackjack_heat_attempt:
		var capped_blackjack_delta := run_state.blackjack_suspicion_delta_before_backoff(suspicion_delta)
		if capped_blackjack_delta != suspicion_delta:
			deltas["base_suspicion_delta"] = suspicion_delta
			deltas["suspicion_delta"] = capped_blackjack_delta
			result["suspicion_delta"] = capped_blackjack_delta
			result["deltas"] = deltas
			suspicion_delta = capped_blackjack_delta
	var applied_suspicion_delta := 0
	if suspicion_delta != 0:
		var suspicion_context := {
			"environment_id": result.get("environment_id", ""),
			"action_kind": str(result.get("action_kind", "")),
			"source_id": str(result.get("source_id", "")),
		}
		if result.has("environment_archetype_id"):
			suspicion_context["environment_archetype_id"] = result.get("environment_archetype_id", "")
		applied_suspicion_delta = run_state.add_suspicion(
			"%s:%s" % [result.get("source_id", ""), result.get("action_id", "")],
			suspicion_delta,
			"behavior",
			false,
			suspicion_context,
			defer_bankroll_zero
		)
		if applied_suspicion_delta != suspicion_delta:
			deltas["base_suspicion_delta"] = suspicion_delta
			deltas["suspicion_delta"] = applied_suspicion_delta
			result["suspicion_delta"] = applied_suspicion_delta
			result["deltas"] = deltas
			normalize_skill_cheat_contract(result)
	var blackjack_backoff := run_state.apply_blackjack_heat_backoff(result) if blackjack_heat_attempt and run_state.suspicion_level() >= RunState.BLACKJACK_BACKOFF_HEAT else {}
	if not blackjack_backoff.is_empty():
		result["blackjack_backoff"] = blackjack_backoff
		result["blackjack_table_barred"] = true
		var backoff_message := str(blackjack_backoff.get("message", ""))
		var messages := _copy_array(deltas.get("messages", []))
		if not backoff_message.is_empty():
			messages.append(backoff_message)
			deltas["messages"] = messages
			result["message"] = "%s %s" % [str(result.get("message", "")).strip_edges(), backoff_message]
			result["message"] = str(result.get("message", "")).strip_edges()
		var story_log := _copy_array(deltas.get("story_log", []))
		story_log.append(_copy_dict(blackjack_backoff.get("story_entry", {})))
		deltas["story_log"] = story_log
		result["deltas"] = deltas
	if applied_suspicion_delta > 0 and run_state.suspicion_level() >= 100 and blackjack_backoff.is_empty() and not run_state.handle_grand_casino_heat_reroute("game_result"):
		run_state.fail_run(RunState.FAILURE_POLICE_CAPTURE, RunState.POLICE_CAPTURE_FAILURE_MESSAGE)
	var alcohol_intake := int(deltas.get("alcohol_intake", 0))
	if alcohol_intake != 0:
		run_state.drink_alcohol(alcohol_intake)
	var pending_drunk_absorption_delta := int(deltas.get("pending_drunk_absorption_delta", 0))
	if pending_drunk_absorption_delta != 0:
		run_state.change_pending_drunk_absorption(pending_drunk_absorption_delta)
	var drunk_delta := int(deltas.get("drunk_delta", 0))
	if drunk_delta != 0:
		run_state.change_drunk(drunk_delta)
	var drunk_distortion_suppression_turns := int(deltas.get("drunk_distortion_suppression_turns", 0))
	if drunk_distortion_suppression_turns > 0:
		run_state.suppress_drunk_distortion(drunk_distortion_suppression_turns)
	var heat_cooldown_actions := int(deltas.get("heat_cooldown_actions", 0))
	var heat_cooldown_per_action := int(deltas.get("heat_cooldown_per_action", 0))
	if heat_cooldown_actions > 0 and heat_cooldown_per_action > 0:
		run_state.start_heat_cooldown(heat_cooldown_actions, heat_cooldown_per_action)
	var alcoholic_delta := int(deltas.get("alcoholic_delta", 0))
	if alcoholic_delta != 0:
		run_state.change_alcoholic(alcoholic_delta)
	var baseline_luck_delta := int(deltas.get("baseline_luck_delta", 0))
	if baseline_luck_delta != 0:
		run_state.change_baseline_luck(baseline_luck_delta)
	for debt_change in deltas.get("debt_changes", []):
		if typeof(debt_change) == TYPE_DICTIONARY:
			run_state.add_debt(debt_change)
	for item_id in deltas.get("inventory_add", []):
		run_state.add_item(str(item_id))
	for item_id in deltas.get("inventory_remove", []):
		run_state.remove_item(str(item_id))
	for bag_marker_value in deltas.get("pending_bags", []):
		if typeof(bag_marker_value) == TYPE_DICTIONARY:
			run_state.add_pending_bag_marker(bag_marker_value)
	var flags := _copy_dict(deltas.get("flags_set", {}))
	for key in flags.keys():
		run_state.narrative_flags[str(key)] = flags[key]
	var story_flags := _copy_dict(deltas.get("story_flags_set", {}))
	for key in story_flags.keys():
		run_state.set_story_flag(str(key), story_flags[key])
	var layer_discovery := _copy_dict(deltas.get("environment_layer_discovery", {}))
	var discovered_layer_id := str(layer_discovery.get("layer_id", "")).strip_edges()
	if not discovered_layer_id.is_empty():
		run_state.discover_environment_layer(discovered_layer_id, str(layer_discovery.get("method", "event")))
	var travel_hooks := _copy_array(deltas.get("travel_hooks_add", []))
	if not travel_hooks.is_empty():
		run_state.add_next_archetypes(travel_hooks)
	var travel_changes := _copy_dict(deltas.get("travel_changes", {}))
	if travel_changes.has("set_next_archetypes"):
		run_state.set_next_archetypes(_copy_array(travel_changes.get("set_next_archetypes", [])))
	if travel_changes.has("add_next_archetypes"):
		run_state.add_next_archetypes(_copy_array(travel_changes.get("add_next_archetypes", [])))
	if flags.has(RunState.GRAND_CASINO_INVITATION_EVENT_ID):
		run_state.reconcile_grand_casino_invitation_uniqueness()
	for story_entry in deltas.get("story_log", []):
		if typeof(story_entry) == TYPE_DICTIONARY:
			run_state.log_story(story_entry)
	run_state.sync_grand_casino_entry_bankroll_after_travel_result(result)
	var demo_finale := _copy_dict(deltas.get("demo_finale", {}))
	if not demo_finale.is_empty():
		run_state.apply_demo_finale_result(demo_finale)
	run_state.record_profile_game_result(result)
	run_state.record_grand_casino_game_result(result)
	run_state.crew_record_game_result(result, deltas)
	run_state.record_reputation_from_result(result, deltas)
	if bool(deltas.get("ended", false)) and bool(run_state.narrative_flags.get("demo_victory", false)):
		run_state.run_status = RESULT_ENDED
		run_state.run_failure_reason = RunState.FAILURE_NONE
		run_state.run_failure_message = ""
	else:
		run_state.evaluate_immediate_terminal_state(defer_bankroll_zero)
		if run_state.run_status != RunState.RUN_STATUS_FAILED:
			run_state.evaluate_environment_objective_state()
			if bool(run_state.narrative_flags.get("demo_victory", false)):
				deltas["ended"] = true
				result["deltas"] = deltas
				result["ended"] = true
				result["state"] = RESULT_ENDED
				var victory_message := run_state.current_demo_victory_message()
				var messages := _copy_array(deltas.get("messages", []))
				if not victory_message.is_empty() and not messages.has(victory_message):
					messages.append(victory_message)
					deltas["messages"] = messages
					result["deltas"] = deltas
					result["messages"] = messages
					result["message"] = "%s %s" % [str(result.get("message", "")).strip_edges(), victory_message]
					result["message"] = str(result.get("message", "")).strip_edges()
		if bool(deltas.get("ended", false)) and run_state.run_status != RunState.RUN_STATUS_FAILED:
			run_state.run_status = RESULT_ENDED
	if not demo_finale.is_empty() and run_state.is_terminal():
		deltas["ended"] = true
		result["deltas"] = deltas
		result["ended"] = true
		result["state"] = RESULT_ENDED
	run_state.scenario_publish_game_result(result, deltas)
	if rng != null:
		run_state.save_rng(rng)
	run_state.clear_deferred_bankroll_zero_resolution()
	return IoResultScript.ok({"result": result})


# Resolves one action with data-driven odds and item modifiers.
#
# `payout_mult` is the gross casino payout, including the returned wager. A
# 2x payout therefore nets +1 stake on a win and -1 stake on a loss. This keeps
# the generic game contract aligned with slot and pull-tab modules, where the
# wager is always paid before any winnings are awarded.
func resolve(action_id: String, stake: int, run_state: RunState, environment: Dictionary, rng: RngStream) -> Dictionary:
	var action := _action(action_id)
	if action.is_empty():
		return _empty_result(action_id, stake, environment, "That move is closed from here. Pick a lit action.")

	var is_cheat := _is_cheat_action(action_id)
	var economic_profile: Dictionary = environment.get("economic_profile", {}) if typeof(environment.get("economic_profile", {})) == TYPE_DICTIONARY else {}
	var stake_floor := stake_floor_for_game(environment, get_id(), int(economic_profile.get("stake_floor", 1)))
	var stake_ceiling := run_state.wager_stake_ceiling(stake_ceiling_for_game(environment, get_id(), run_state.bankroll))
	if stake_ceiling < stake_floor or stake_ceiling <= 0:
		return _empty_result(action_id, stake, environment, "Economy pressure leaves no valid stake.")
	var adjusted_stake := clampi(stake, stake_floor, stake_ceiling)
	adjusted_stake = mini(adjusted_stake, maxi(0, run_state.bankroll))
	if adjusted_stake <= 0:
		return _empty_result(action_id, stake, environment, "You do not have enough bankroll to act.")

	var luck_modifier := run_state.luck_win_chance_bonus()
	var chance := clampi(int(action.get("win_chance", 45)) + _item_bonus("win_chance", run_state, is_cheat) + luck_modifier, 5, 95)
	var won := rng.randi_range(1, 100) <= chance
	var payout := int(action.get("payout_mult", 2))
	var stake_cost := adjusted_stake
	var gross_payout := adjusted_stake * payout if won else 0
	var bankroll_delta := gross_payout - stake_cost
	var luck_payout_bonus := run_state.luck_payout_bonus(adjusted_stake, won)
	if won:
		bankroll_delta = maxi(1, bankroll_delta + luck_payout_bonus)
		bankroll_delta += _item_bonus("win_bonus", run_state, is_cheat)
	else:
		bankroll_delta = mini(0, bankroll_delta + _item_bonus("loss_reduction", run_state, is_cheat))

	var suspicion_delta := int(action.get("suspicion_delta", 0))
	var pit_boss_status := run_state.pit_boss_watch_status(environment) if is_cheat else {}
	var pit_boss_bonus := int(pit_boss_status.get("cheat_heat_bonus", 0)) if bool(pit_boss_status.get("active", false)) else 0
	if is_cheat:
		suspicion_delta = maxi(0, suspicion_delta + _item_bonus("cheat_suspicion_delta", run_state, true) + run_state.security_risk_bonus("cheat") + pit_boss_bonus)
	var security_summary := run_state.security_pressure_summary() if is_cheat and run_state.security_risk_bonus("cheat") > 0 else ""
	var pit_boss_summary := str(pit_boss_status.get("summary", "")) if bool(pit_boss_status.get("active", false)) else ""
	if is_cheat and not pit_boss_summary.is_empty():
		security_summary = "%s %s" % [security_summary, pit_boss_summary]
	var security_pressure := run_state.security_action_pressure("cheat", adjusted_stake, run_state.suspicion_level() + suspicion_delta) if is_cheat else {}
	var security_bankroll_delta := int(security_pressure.get("bankroll_delta", 0))
	var security_message := str(security_pressure.get("message", ""))
	if security_bankroll_delta != 0:
		bankroll_delta += security_bankroll_delta
	var message := _result_message(action, won, bankroll_delta, suspicion_delta, security_summary)
	if not security_message.is_empty():
		message = "%s %s" % [message, security_message]
	var story_entry := {
		"type": "game_action",
		"game_id": get_id(),
		"action_id": action_id,
		"won": won,
		"payout": gross_payout,
		"stake_cost": stake_cost,
		"bankroll_delta": bankroll_delta,
		"suspicion_delta": suspicion_delta,
		"luck_modifier": luck_modifier,
		"luck_payout_bonus": luck_payout_bonus,
		"environment_id": environment.get("id", ""),
		"security_pressure": run_state.security_pressure_label() if is_cheat else "",
		"security_bankroll_delta": security_bankroll_delta,
		"security_message": security_message,
		"pit_boss_watched": bool(pit_boss_status.get("watched", false)),
		"pit_boss_heat_bonus": pit_boss_bonus,
		"pit_boss_summary": pit_boss_summary,
	}
	var deltas := empty_result_deltas()
	deltas["bankroll_delta"] = bankroll_delta
	deltas["suspicion_delta"] = suspicion_delta
	deltas["story_log"] = [story_entry]
	deltas["messages"] = [message]
	deltas["ended"] = bool(security_pressure.get("ended", false))
	var result := build_action_result({
		"ok": true,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": "cheat" if is_cheat else "legal",
		"stake": adjusted_stake,
		"bankroll_delta": bankroll_delta,
		"suspicion_delta": suspicion_delta,
		"deltas": deltas,
		"won": won,
		"environment_id": environment.get("id", ""),
		"message": message,
	})
	apply_result(run_state, result, rng)
	return result


# Returns a no-op result when an action cannot run.
func _empty_result(action_id: String, stake: int, environment: Dictionary, text: String) -> Dictionary:
	return build_action_result({
		"ok": false,
		"type": "game_action",
		"source_id": get_id(),
		"game_id": get_id(),
		"action_id": action_id,
		"action_kind": "unknown",
		"stake": stake,
		"won": false,
		"environment_id": environment.get("id", ""),
		"message": text,
	})


# Finds an action definition across legal and cheat actions.
func _action(action_id: String) -> Dictionary:
	for action in definition.get("legal_actions", []):
		if action.get("id", "") == action_id:
			return action.duplicate(true)
	for action in definition.get("cheat_actions", []):
		if action.get("id", "") == action_id:
			return action.duplicate(true)
	return {}


# Checks whether an action is a cheat or advantage action.
func _is_cheat_action(action_id: String) -> bool:
	for action in definition.get("cheat_actions", []):
		if action.get("id", "") == action_id:
			return true
	return false


# Sums matching item bonuses for this game context.
func _item_bonus(key: String, run_state: RunState, is_cheat: bool) -> int:
	if run_state == null or library == null:
		return 0
	if run_state.has_method("item_effect_total"):
		var action_kind := "cheat" if is_cheat else "legal"
		return int(run_state.item_effect_total(key, get_family(), action_kind))
	var total := 0
	for inventory_entry in run_state.inventory:
		var item_id := _inventory_item_id(inventory_entry)
		if item_id.is_empty():
			continue
		var item := library.item(item_id)
		if item.is_empty():
			continue
		var effect := _copy_dict(item.get("effect", {}))
		total += int(effect.get(key, 0))
		if is_cheat:
			total += int(effect.get("cheat_%s" % key, 0))
		else:
			total += int(effect.get("legal_%s" % key, 0))
		var families := _copy_dict(effect.get("families", {}))
		var family_effect := _copy_dict(families.get(get_family(), {}))
		total += int(family_effect.get(key, 0))
	return total


# Returns UI-ready item badges for skill-cheat modifiers on the current game.
func skill_item_modifier_badges(run_state: RunState, effect_keys: Array) -> Array:
	if run_state == null or library == null:
		return []
	var wanted := {}
	for key_value in effect_keys:
		var key := str(key_value).strip_edges()
		if not key.is_empty():
			wanted[key] = true
	if wanted.is_empty():
		return []
	var badges: Array = []
	for inventory_entry in run_state.inventory:
		var item_id := _inventory_item_id(inventory_entry).strip_edges()
		if item_id.is_empty():
			continue
		var item := library.item(item_id)
		if item.is_empty():
			continue
		var effect := _copy_dict(item.get("effect", {}))
		var modifiers := _skill_item_modifier_values(effect, wanted, get_family())
		if modifiers.is_empty():
			continue
		badges.append({
			"item_id": item_id,
			"label": str(item.get("display_name", item_id)),
			"icon_key": str(item.get("icon_key", item_id)),
			"item_class": str(item.get("class", "")),
			"modifiers": modifiers,
		})
	return badges


func _skill_item_modifier_values(effect: Dictionary, wanted: Dictionary, family_id: String) -> Dictionary:
	var values := {}
	_merge_skill_item_modifier_values(values, effect, wanted)
	var families := _copy_dict(effect.get("families", {}))
	var family_effect := _copy_dict(families.get(family_id, {}))
	_merge_skill_item_modifier_values(values, family_effect, wanted)
	return values


func _merge_skill_item_modifier_values(target: Dictionary, source: Dictionary, wanted: Dictionary) -> void:
	if source.is_empty():
		return
	for key_value in wanted.keys():
		var key := str(key_value)
		var value := _numeric_item_modifier_value(source.get(key, 0))
		if value == 0:
			continue
		target[key] = int(target.get(key, 0)) + value


func _numeric_item_modifier_value(value: Variant) -> int:
	if typeof(value) == TYPE_INT:
		return int(value)
	if typeof(value) == TYPE_FLOAT:
		return int(round(float(value)))
	return 0


# Builds the player-facing result message.
func _result_message(action: Dictionary, won: bool, bankroll_delta: int, suspicion_delta: int, security_summary: String = "") -> String:
	var outcome := "won" if won else "lost"
	var suspicion_text := "" if suspicion_delta <= 0 else " Suspicion pressure rises."
	if not security_summary.is_empty():
		suspicion_text += " %s" % security_summary
	return "%s %s. Bankroll %+d.%s" % [
		action.get("label", action.get("id", "Action")),
		outcome,
		bankroll_delta,
		suspicion_text,
	]


# Returns an item id from the foundation string form or a future-safe dictionary.
func _inventory_item_id(entry: Variant) -> String:
	if typeof(entry) == TYPE_DICTIONARY:
		return str((entry as Dictionary).get("id", ""))
	return str(entry)


func _item_effect_total(key: String, run_state: RunState) -> int:
	if run_state == null:
		return 0
	return run_state.item_effect_total(key, get_family()) if run_state.has_method("item_effect_total") else 0


func _stable_hash(text: String) -> int:
	var value := 216613626
	for index in range(text.length()):
		value = value ^ text.unicode_at(index)
		value = int((value * 16777619) & 0x7fffffff)
	return maxi(1, value)


func _fallback_state(run_state: RunState, environment: Dictionary) -> Dictionary:
	var rng := RngStream.new()
	rng.configure(_stable_hash("%s:%s:%s" % [get_id(), str(run_state.seed_text if run_state != null else "fallback"), str(environment.get("id", ""))]))
	return generate_environment_state(run_state, environment, rng)


# Returns the stored game state for read-only, per-frame checks.
func _peek_table_state(environment: Dictionary) -> Dictionary:
	var states: Variant = environment.get("game_states", {})
	if typeof(states) != TYPE_DICTIONARY:
		return {}
	var table: Variant = (states as Dictionary).get(get_id(), {})
	if typeof(table) != TYPE_DICTIONARY or (table as Dictionary).is_empty():
		return {}
	return table as Dictionary


# Safely duplicates array content.
static func _copy_array(value: Variant) -> Array:
	return JsonCoerceScript._copy_array(value)


# Safely duplicates dictionary content.
static func _copy_dict(value: Variant) -> Dictionary:
	return JsonCoerceScript._copy_dict(value)


static func _dictionary_array(value: Variant) -> Array:
	return JsonCoerceScript._dictionary_array(value)


static func _string_array(value: Variant) -> Array:
	return JsonCoerceScript._string_array(value)


static func _int_array(value: Variant) -> Array:
	return JsonCoerceScript._int_array(value)


static func _owned_array(value: Variant) -> Array:
	return value as Array if typeof(value) == TYPE_ARRAY else []


static func _owned_dict(value: Variant) -> Dictionary:
	return value as Dictionary if typeof(value) == TYPE_DICTIONARY else {}


static func _normalize_surface_animation_channels(value: Variant, take_ownership: bool = false) -> Array:
	var entries: Array = []
	if typeof(value) == TYPE_DICTIONARY:
		var channels: Dictionary = value
		for key in channels.keys():
			var channel := _owned_dict(channels.get(key, {})) if take_ownership else _copy_dict(channels.get(key, {}))
			if channel.is_empty():
				continue
			if not channel.has("id"):
				channel["id"] = str(key)
			entries.append(channel)
	elif typeof(value) == TYPE_ARRAY:
		for entry in value:
			if typeof(entry) == TYPE_DICTIONARY:
				entries.append(entry if take_ownership else (entry as Dictionary).duplicate(true))

	var result: Array = []
	for entry in entries:
		var channel: Dictionary = entry
		var channel_id := str(channel.get("id", ""))
		if channel_id.is_empty():
			continue
		var active_id := str(channel.get("active_id", ""))
		var normalized := channel
		normalized["id"] = channel_id
		normalized["active_id"] = active_id
		normalized["started_msec"] = maxi(0, int(channel.get("started_msec", 0)))
		normalized["duration_msec"] = maxi(0, int(channel.get("duration_msec", 0)))
		normalized["active"] = bool(channel.get("active", not active_id.is_empty()))
		normalized["restart_on_active_id_change"] = bool(channel.get("restart_on_active_id_change", true))
		normalized["metadata"] = _owned_dict(channel.get("metadata", {}))
		result.append(normalized)
	return result


static func _matching_story_entry(story_entries: Array, result: Dictionary) -> Dictionary:
	for story_value in story_entries:
		if typeof(story_value) != TYPE_DICTIONARY:
			continue
		var entry: Dictionary = story_value
		if _story_entry_matches_result(entry, result):
			return entry
	for story_value in story_entries:
		if typeof(story_value) == TYPE_DICTIONARY:
			return story_value
	return {}


static func _story_entry_matches_result(entry: Dictionary, result: Dictionary) -> bool:
	var story_game_id := str(entry.get("game_id", ""))
	var result_game_id := str(result.get("game_id", ""))
	if not story_game_id.is_empty() and not result_game_id.is_empty() and story_game_id != result_game_id:
		return false
	var story_action_id := str(entry.get("action_id", ""))
	var result_action_id := str(result.get("action_id", ""))
	if not story_action_id.is_empty() and not result_action_id.is_empty() and story_action_id != result_action_id:
		return false
	return true


static func _skill_bool_value(base_key: String, result: Dictionary, payload: Dictionary, story: Dictionary, default_value: bool) -> bool:
	if payload.has(base_key):
		return bool(payload.get(base_key, default_value))
	if result.has(base_key):
		return bool(result.get(base_key, default_value))
	if story.has(base_key):
		return bool(story.get(base_key, default_value))
	var suffix := "_%s" % base_key
	for key in result.keys():
		if str(key).ends_with(suffix):
			return bool(result.get(key, default_value))
	for key in story.keys():
		if str(key).ends_with(suffix):
			return bool(story.get(key, default_value))
	return default_value


static func _skill_int_value(base_key: String, result: Dictionary, payload: Dictionary, story: Dictionary, default_value: int) -> int:
	if payload.has(base_key):
		return int(payload.get(base_key, default_value))
	if result.has(base_key):
		return int(result.get(base_key, default_value))
	if story.has(base_key):
		return int(story.get(base_key, default_value))
	var suffix := "_%s" % base_key
	for key in result.keys():
		if str(key).ends_with(suffix):
			return int(result.get(key, default_value))
	for key in story.keys():
		if str(key).ends_with(suffix):
			return int(story.get(key, default_value))
	return default_value


static func _skill_string_value(base_key: String, result: Dictionary, payload: Dictionary, story: Dictionary, default_value: String) -> String:
	if payload.has(base_key):
		return str(payload.get(base_key, default_value))
	if result.has(base_key):
		return str(result.get(base_key, default_value))
	if story.has(base_key):
		return str(story.get(base_key, default_value))
	var suffix := "_%s" % base_key
	for key in result.keys():
		if str(key).ends_with(suffix):
			return str(result.get(key, default_value))
	for key in story.keys():
		if str(key).ends_with(suffix):
			return str(story.get(key, default_value))
	return default_value


static func _default_skill_outcome(action_kind: String, won: bool, suspicion_delta: int, bankroll_delta: int) -> String:
	if action_kind == "advantage":
		return "edge_found"
	if action_kind == "risky":
		return "risk_taken"
	if won or bankroll_delta > 0:
		return "cheat_paid"
	if suspicion_delta > 0:
		return "heat_taken"
	return "cheat_resolved"


static func _default_skill_grade(skill_outcome: String, action_kind: String, won: bool, suspicion_delta: int, bankroll_delta: int) -> String:
	var outcome := skill_outcome.to_lower()
	if outcome.find("perfect") >= 0:
		return "perfect"
	if outcome.find("good") >= 0:
		return "good"
	if outcome.find("partial") >= 0 or outcome.find("close") >= 0:
		return "partial"
	if outcome.find("blown") >= 0 or outcome.find("caught") >= 0:
		return "blown"
	if outcome.find("miss") >= 0:
		return "miss"
	if action_kind == "advantage":
		return "edge"
	if action_kind == "risky":
		return "risk"
	if won or bankroll_delta > 0:
		return "success"
	if suspicion_delta > 0:
		return "heat"
	return "resolved"


static func _default_skill_accuracy(skill_grade: String, action_kind: String, won: bool, suspicion_delta: int, bankroll_delta: int) -> int:
	match skill_grade:
		"perfect":
			return 100
		"good", "success", "edge":
			return 75
		"partial", "close", "risk":
			return 50
		"miss", "blown", "clean_miss":
			return 0
	if won or bankroll_delta > 0:
		return 75
	if action_kind == "advantage":
		return 75
	if suspicion_delta > 0:
		return 25
	return 50


# Normalizes legacy or partial result-delta dictionaries into the shared shape.
static func _normalize_result_deltas(value: Variant, take_ownership: bool = false) -> Dictionary:
	var source := _owned_dict(value) if take_ownership else _copy_dict(value)
	if source.has("bankroll") and not source.has("bankroll_delta"):
		source["bankroll_delta"] = source["bankroll"]
	if source.has("suspicion") and not source.has("suspicion_delta"):
		source["suspicion_delta"] = source["suspicion"]
	if source.has("alcohol") and not source.has("alcohol_intake"):
		source["alcohol_intake"] = source["alcohol"]
	if source.has("drunk") and not source.has("drunk_delta"):
		source["drunk_delta"] = source["drunk"]
	if source.has("alcoholic") and not source.has("alcoholic_delta"):
		source["alcoholic_delta"] = source["alcoholic"]
	if source.has("luck") and not source.has("baseline_luck_delta"):
		source["baseline_luck_delta"] = source["luck"]
	if source.has("flags") and not source.has("flags_set"):
		source["flags_set"] = source["flags"]
	if source.has("add_next_archetypes") or source.has("set_next_archetypes"):
		var travel_changes := _copy_dict(source.get("travel_changes", {}))
		if source.has("add_next_archetypes") and not travel_changes.has("add_next_archetypes"):
			travel_changes["add_next_archetypes"] = _copy_array(source.get("add_next_archetypes", []))
		if source.has("set_next_archetypes") and not travel_changes.has("set_next_archetypes"):
			travel_changes["set_next_archetypes"] = _copy_array(source.get("set_next_archetypes", []))
		source["travel_changes"] = travel_changes

	if take_ownership:
		var defaults := empty_result_deltas()
		for key in defaults.keys():
			if not source.has(key):
				source[key] = defaults[key]
				continue
			if key == "bankroll_delta" or key == "chips_delta" or key == "suspicion_delta" or key == "alcohol_intake" or key == "drunk_delta" or key == "pending_drunk_absorption_delta" or key == "drunk_distortion_suppression_turns" or key == "heat_cooldown_actions" or key == "heat_cooldown_per_action" or key == "alcoholic_delta" or key == "baseline_luck_delta":
				source[key] = int(source[key])
			elif key == "ended":
				source[key] = bool(source[key])
			elif key == "flags_set" or key == "story_flags_set" or key == "travel_changes" or key == "demo_finale" or key == "environment_layer_discovery" or key == "discounted_debt_settlement":
				if typeof(source[key]) != TYPE_DICTIONARY:
					source[key] = {}
			elif typeof(source[key]) != TYPE_ARRAY:
				source[key] = []
		return source

	var result := empty_result_deltas()
	for key in result.keys():
		if not source.has(key):
			continue
		if key == "bankroll_delta" or key == "chips_delta" or key == "suspicion_delta" or key == "alcohol_intake" or key == "drunk_delta" or key == "pending_drunk_absorption_delta" or key == "drunk_distortion_suppression_turns" or key == "heat_cooldown_actions" or key == "heat_cooldown_per_action" or key == "alcoholic_delta" or key == "baseline_luck_delta":
			result[key] = int(source[key])
		elif key == "ended":
			result[key] = bool(source[key])
		elif key == "flags_set" or key == "story_flags_set" or key == "travel_changes" or key == "demo_finale" or key == "environment_layer_discovery" or key == "discounted_debt_settlement":
			result[key] = _copy_dict(source[key])
		else:
			result[key] = _copy_array(source[key])
	return result


static func _has_only_canonical_result_delta_keys(deltas: Dictionary) -> bool:
	var canonical := empty_result_deltas()
	for key in deltas.keys():
		if not canonical.has(key):
			return false
	return true


# Read-only presentation policy. The shell coordinates these contracts without
# interpreting any game's private receipt, selector or tutorial state.
func restored_surface_stake(_ui_state: Dictionary) -> int:
	return 0

func environment_hook_is_recovery(_hook_id: String, _action_id: String) -> bool:
	return false

func environment_coach_state(_run_state: RunState, _environment: Dictionary) -> Dictionary:
	return {}

func uses_round_net_feedback() -> bool:
	return false

func round_net_feedback_delta(_result: Dictionary) -> Variant:
	return null

func round_net_feedback_lead(_result: Dictionary) -> String:
	return ""

func story_is_unwagered_observation(_entry: Dictionary) -> bool:
	return false

func story_is_unmeasured_penalty(_entry: Dictionary) -> bool:
	return false

func story_feedback_keys() -> Array:
	return []

func unmeasured_penalty_message(_entry: Dictionary, _nominal: int) -> String:
	return ""

func settled_round_message() -> String:
	return ""

func terminal_checkpoint_uses_web_phases(_environment: Dictionary) -> bool:
	return false
