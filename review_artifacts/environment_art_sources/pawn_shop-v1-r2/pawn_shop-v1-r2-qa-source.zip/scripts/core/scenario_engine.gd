class_name ScenarioEngine
extends RefCounted

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")

const SequenceRuntimeScript := preload("res://scripts/core/scenario_sequence_runtime.gd")
const SequenceSchemaScript := preload("res://scripts/core/scenario_sequence_schema.gd")
const SequenceCatalogScript := preload("res://scripts/core/scenario_sequence_catalog.gd")
const SequenceRolloutManifestScript := preload("res://scripts/core/scenario_sequence_rollout_manifest.gd")
const OperationRegistryScript := preload("res://scripts/core/scenario_operation_registry.gd")
const ScenarioExtensionDispatchScript := preload("res://scripts/core/scenario_extension_dispatch.gd")
const ScenarioLayoutResolverScript := preload("res://scripts/core/scenario_layout_resolver.gd")
const VALIDATED_SEQUENCE_MARKER := "__scenario_sequence_runtime_validated"
const RESOLVED_SEQUENCE_CATALOG_MARKER := "__scenario_sequence_catalog_resolved"
const TRUSTED_STATE_REFERENCE_KEY := "_scenario_trusted_state_digest"
const TRUSTED_LAYOUT_INPUT_DIGEST_KEY := "_scenario_trusted_layout_input_digest"
const SEQUENCE_SUPPRESSION_KEY := "sequence_suppressed"
const EnvironmentSemanticInventoryScript := preload("res://scripts/core/environment_semantic_inventory.gd")
const LEGACY_GALA_TERMINAL_PATH := "res://data/environments/scenario_sequence_compatibility/grand_casino_gala_night_v1.json"
const LEGACY_GALA_TERMINAL_TEXT_SHA256 := "ebc129f575b5c286bd6989fdc8eb445dac7ba326f8dda4ca918680b54856aa93"
static var _legacy_gala_terminal_definition: Dictionary = {}

# Deterministic scenario overlays. Selection belongs to RunGenerator; this
# module only builds and advances the selected node-owned state.

const STATE_SCHEMA_VERSION := 1
const ALLOWED_MUTATION_KEYS := [
	"patron_set",
	"staff_set",
	"event_pool_add",
	"event_pool_remove",
	"travel_hooks_add",
	"item_offer_add",
	"item_offer_remove",
	"economic_profile_overrides",
	"game_modifier_hooks",
	"service_add",
	"service_remove",
	"music_profile_override",
	"presentation",
	"exclusive_opportunity",
	"security_overrides",
	"hook_flags",
	"travel_lock_actions",
]
const ALLOWED_PRESENTATION_KEYS := ["palette_tint", "lighting_key", "crowd_density", "signage_line"]
const ALLOWED_EXCLUSIVE_KEYS := ["event_id", "game_id"]
const ALLOWED_SECURITY_KEYS := ["strictness_band", "cheat_risk_window", "machine_alarm_tolerance_band"]


static func initial_state(definition: Dictionary) -> Dictionary:
	if definition.is_empty():
		return {}
	var result := {
		"schema_version": STATE_SCHEMA_VERSION,
		"id": str(definition.get("id", "")).strip_edges(),
		"archetype_id": str(definition.get("archetype_id", "")).strip_edges(),
		"layer_id": str(definition.get("layer_id", "")).strip_edges(),
		"display_name": str(definition.get("display_name", "")).strip_edges(),
		"placeholder": bool(definition.get("placeholder", false)),
		"phase_index": 0,
		"phase_action_counter": 0,
		"mutations": JsonCoerceScript._copy_dict(definition.get("mutations", {})),
		"phases": JsonCoerceScript._copy_array(definition.get("phases", [])),
		"town_weight_tags": JsonCoerceScript._unique_string_array(definition.get("town_weight_tags", [])),
	}
	if bool(definition.get(SEQUENCE_SUPPRESSION_KEY, false)):
		result[SEQUENCE_SUPPRESSION_KEY] = true
	return result


static func normalize_state(value: Variant) -> Dictionary:
	if typeof(value) != TYPE_DICTIONARY:
		return {}
	var source: Dictionary = value
	var scenario_id := str(source.get("id", "")).strip_edges()
	if scenario_id.is_empty():
		return {}
	var phases := JsonCoerceScript._copy_array(source.get("phases", []))
	var phase_index := maxi(0, int(source.get("phase_index", 0)))
	if not phases.is_empty():
		phase_index = mini(phase_index, phases.size() - 1)
	else:
		phase_index = 0
	var result := {
		"schema_version": STATE_SCHEMA_VERSION,
		"id": scenario_id,
		"archetype_id": str(source.get("archetype_id", "")).strip_edges(),
		"layer_id": str(source.get("layer_id", "")).strip_edges(),
		"display_name": str(source.get("display_name", scenario_id)).strip_edges(),
		"placeholder": bool(source.get("placeholder", false)),
		"phase_index": phase_index,
		"phase_action_counter": maxi(0, int(source.get("phase_action_counter", 0))),
		"mutations": JsonCoerceScript._copy_dict(source.get("mutations", {})),
		"phases": phases,
		"town_weight_tags": JsonCoerceScript._unique_string_array(source.get("town_weight_tags", [])),
	}
	if bool(source.get(SEQUENCE_SUPPRESSION_KEY, false)):
		result[SEQUENCE_SUPPRESSION_KEY] = true
	return result


static func apply_to_archetype(archetype: Dictionary, state_value: Variant) -> Dictionary:
	var state := normalize_state(state_value)
	if state.is_empty():
		return archetype
	var result := archetype.duplicate(true)
	if not _state_targets_layer(state, result):
		return result
	_apply_mutations(result, JsonCoerceScript._copy_dict(state.get("mutations", {})), true)
	var phases := JsonCoerceScript._copy_array(state.get("phases", []))
	var phase_index := mini(maxi(0, int(state.get("phase_index", 0))), phases.size() - 1)
	for index in range(phase_index + 1):
		if index < phases.size() and typeof(phases[index]) == TYPE_DICTIONARY:
			_apply_mutations(result, JsonCoerceScript._copy_dict((phases[index] as Dictionary).get("mutations", {})), true)
	return result


static func attach_to_environment(environment: Dictionary, state_value: Variant, definition: Dictionary = {}) -> void:
	var state := normalize_state(state_value)
	if state.is_empty():
		return
	environment["scenario_state"] = state
	environment["scenario_id"] = str(state.get("id", ""))
	environment["scenario_phase_index"] = int(state.get("phase_index", 0))
	environment["scenario_phase_action_counter"] = int(state.get("phase_action_counter", 0))
	var targets_layer := _state_targets_layer(state, environment)
	environment["scenario_applied_phase_index"] = int(state.get("phase_index", 0)) if targets_layer else -1
	# A layered venue carries one scenario cursor so returning to its authored
	# floor resumes deterministically. Its sequence projection is physical room
	# state, however, and must never be installed on another floor.
	if not targets_layer:
		deactivate_environment_sequence_projection(environment)
		return
	_apply_exclusive_opportunity(environment)
	migrate_environment_sequence(environment, definition, str(environment.get("id", "")))


static func state_targets_environment(state_value: Variant, environment: Dictionary) -> bool:
	var state := normalize_state(state_value)
	return not state.is_empty() and _state_targets_layer(state, environment)


static func deactivate_environment_sequence_projection(environment: Dictionary) -> void:
	_clear_environment_sequence(environment)
	for key in [
		"scenario_base_interactions", "scenario_base_actors", "scenario_base_producer_context",
		"scenario_semantic_action_digest", "scenario_semantic_inventory",
		"scenario_semantic_inventory_version", "scenario_semantic_digest", "scenario_semantic_ready",
		"scenario_event_choices", "scenario_restore_contract", "scenario_restore_pending_trusted_rebuild",
		"scenario_sequence_pending_visit_id", "scenario_sequence_lifecycle_errors",
		"scenario_sequence_migration_error",
	]:
		environment.erase(key)
	environment["scenario_applied_phase_index"] = -1


# Public sequence API. Producers publish through enqueue/flush and never mutate
# sequence internals. RunState supplies the node-owned definition/state seam.
static func sequence_definition_for_environment(environment: Dictionary, preferred: Dictionary = {}) -> Dictionary:
	var scenario_id := str(JsonCoerceScript._copy_dict(environment.get("scenario_state", {})).get("id", environment.get("scenario_id", ""))).strip_edges()
	if scenario_id.is_empty():
		return {}
	if _sequence_is_suppressed(environment, preferred):
		var suppressed_source := preferred if not preferred.is_empty() and str(preferred.get("id", preferred.get("scenario_id", ""))).strip_edges() == scenario_id else {"id": scenario_id, "archetype_id": str(JsonCoerceScript._copy_dict(environment.get("scenario_state", {})).get("archetype_id", environment.get("archetype_id", "")))}
		return suppress_sequence_definition(suppressed_source)
	var recorded_definition := recorded_terminal_definition(environment, preferred)
	if not recorded_definition.is_empty():
		return recorded_definition
	# RunState caches the immutable resolved definition. Preserve that owned
	# validation receipt so refresh/presentation reads never re-run the schema.
	if not preferred.is_empty() \
		and str(preferred.get("id", preferred.get("scenario_id", ""))).strip_edges() == scenario_id \
		and (bool(preferred.get(VALIDATED_SEQUENCE_MARKER, false)) \
			or (bool(preferred.get(RESOLVED_SEQUENCE_CATALOG_MARKER, false)) and not SequenceSchemaScript.is_sequence(preferred))):
		return preferred
	var candidate: Dictionary = {}
	if not preferred.is_empty() and str(preferred.get("id", preferred.get("scenario_id", ""))).strip_edges() == scenario_id:
		candidate = SequenceCatalogScript.apply_overlay(preferred)
	else:
		candidate = SequenceCatalogScript.legacy_definition(scenario_id)
	if SequenceSchemaScript.is_sequence(candidate):
		var errors := SequenceSchemaScript.validate_definition(candidate, OperationRegistryScript)
		if candidate.has("sequence_package_id"):
			var registered_overlay := SequenceCatalogScript.overlay_for(scenario_id)
			if registered_overlay.is_empty() or str(registered_overlay.get("package_id", "")) != str(candidate.get("sequence_package_id", "")):
				errors.append("scenario sequence package is not active in the fail-closed content catalog")
			errors.append_array(ScenarioExtensionDispatchScript.validate_package_extensions(
				str(candidate.get("sequence_package_id", "")),
				str(candidate.get("sequence_handler_pack", "")),
				str(candidate.get("sequence_renderer_id", ""))
			))
		if not errors.is_empty():
			return _without_sequence_overlay(candidate)
		candidate[VALIDATED_SEQUENCE_MARKER] = true
	return candidate


static func recorded_terminal_definition(environment: Dictionary, preferred: Dictionary = {}) -> Dictionary:
	# These two old Gala routes committed different authored outcomes. Keep their
	# exact trusted content for causal replay; never rewrite accepted journals or
	# interpret an active/new run through the historical definition.
	var installed_id := str(JsonCoerceScript._copy_dict(environment.get("scenario_state", {})).get("id", environment.get("scenario_id", "")))
	if installed_id != "grand_casino_gala_night" or (not preferred.is_empty() and str(preferred.get("id", "")) != installed_id):
		return {}
	var state := JsonCoerceScript._copy_dict(environment.get("scenario_sequence_state", {}))
	if str(state.get("scenario_id", "")) != "grand_casino_gala_night" or str(state.get("status", "")) != SequenceRuntimeScript.STATUS_AFTERMATH:
		return {}
	var outcomes := JsonCoerceScript._copy_array(state.get("resolved_outcomes", []))
	var old_failure := str(state.get("phase_id", "")) == "terminal_failure" and outcomes == ["public_floor_reopened"]
	var old_public_floor := false
	if str(state.get("phase_id", "")) == "terminal_success" and outcomes == ["cover_identity_accepted"]:
		for record_value in JsonCoerceScript._copy_array(state.get("command_receipt_records", [])):
			var record := JsonCoerceScript._copy_dict(record_value)
			if str(JsonCoerceScript._copy_dict(record.get("envelope", {})).get("command_id", "")) == "reopen_public_gala_floor": old_public_floor = true
	if not old_failure and not old_public_floor:
		return {}
	if not _legacy_gala_terminal_definition.is_empty():
		return _legacy_gala_terminal_definition
	if not FileAccess.file_exists(LEGACY_GALA_TERMINAL_PATH):
		return {}
	var trusted_text := FileAccess.get_file_as_string(LEGACY_GALA_TERMINAL_PATH).replace("\r\n", "\n")
	if trusted_text.sha256_text() != LEGACY_GALA_TERMINAL_TEXT_SHA256:
		return {}
	var parsed: Variant = JSON.parse_string(trusted_text)
	if typeof(parsed) != TYPE_DICTIONARY or str(parsed.get("scenario_id", "")) != "grand_casino_gala_night":
		return {}
	var legacy := preferred.duplicate(true) if not preferred.is_empty() else SequenceCatalogScript.legacy_definition("grand_casino_gala_night")
	if str(legacy.get("id", "")) != "grand_casino_gala_night":
		return {}
	legacy["sequence"] = JsonCoerceScript._copy_dict(parsed.get("sequence", {})).duplicate(true)
	legacy["sequence_authoring"] = JsonCoerceScript._copy_dict(parsed.get("authoring", {})).duplicate(true)
	legacy.erase(VALIDATED_SEQUENCE_MARKER)
	if SequenceSchemaScript.calculated_signature_hash(legacy) != str(legacy.sequence.get("sequence_signature", "")):
		return {}
	# Like an embedded definition, this remains provisional until the installed
	# room finalizer validates it against the independently sealed target catalog.
	# The finalizer stamps the shared immutable definition only after that proof.
	_legacy_gala_terminal_definition = legacy
	return _legacy_gala_terminal_definition


static func migrate_environment_sequence(environment: Dictionary, preferred: Dictionary = {}, seed_token: String = "", compute_changed: bool = true, definition_prevalidated: bool = false) -> Dictionary:
	var legacy := normalize_state(environment.get("scenario_state", {}))
	if legacy.is_empty():
		return {"ok": true, "changed": false, "active": false, "scenario_id": ""}
	var scenario_id := str(legacy.get("id", ""))
	if _sequence_is_suppressed(environment, preferred):
		var suppressed_before := JSON.stringify(_sequence_migration_change_snapshot(environment))
		_clear_environment_sequence(environment)
		return {"ok": true, "changed": suppressed_before != JSON.stringify(_sequence_migration_change_snapshot(environment)), "active": false, "suppressed": true, "scenario_id": scenario_id, "definition": sequence_definition_for_environment(environment, preferred)}
	var definition := sequence_definition_for_environment(environment, preferred)
	# A runtime installed before its content packages must leave legacy snapshots
	# exactly alone. Once an overlay exists, migration is deterministic and in-place.
	if not SequenceSchemaScript.is_sequence(definition):
		return {"ok": true, "changed": false, "active": false, "scenario_id": scenario_id, "definition": definition}
	# Dynamic state, its migration receipt, and semantic authority are one atomic
	# installation. Until finalization seals the exact room inventory, legacy
	# phase/mutation fields remain the only active contract and stay byte-identical.
	if not bool(environment.get("scenario_semantic_ready", false)):
		return {"ok": true, "changed": false, "active": false, "pending": true, "scenario_id": scenario_id, "definition": definition}
	# Migration owns scenario-prefixed fields plus the four materialized gameplay
	# catalogs below. Serializing the complete room here also serialized unrelated
	# machine physics state twice (most visibly Coin Pusher) merely to populate the
	# informational `changed` bit.
	var before := JSON.stringify(_sequence_migration_change_snapshot(environment)) if compute_changed else ""
	var migration := {
		"schema_version": SequenceRuntimeScript.STATE_SCHEMA_VERSION,
		"scenario_id": scenario_id,
		"receipt_id": "legacy:%s:v%d" % [scenario_id, SequenceRuntimeScript.STATE_SCHEMA_VERSION],
		"status": "sequence_active",
	}
	environment["scenario_sequence_migration"] = migration
	ensure_sequence_state(environment, definition, seed_token, definition_prevalidated)
	var changed := before != JSON.stringify(_sequence_migration_change_snapshot(environment)) if compute_changed else true
	return {"ok": true, "changed": changed, "active": true, "scenario_id": scenario_id, "definition": definition}


static func _sequence_migration_change_snapshot(environment: Dictionary) -> Dictionary:
	var snapshot: Dictionary = {}
	for key_value in environment.keys():
		var key := str(key_value)
		if key.begins_with("scenario_") \
				or key in [TRUSTED_STATE_REFERENCE_KEY, TRUSTED_LAYOUT_INPUT_DIGEST_KEY, "game_ids", "service_ids", "travel_hooks", "scenario_game_modifiers"]:
			snapshot[key] = environment.get(key_value)
	return snapshot


static func ensure_sequence_state(environment: Dictionary, definition: Dictionary, seed_token: String = "", definition_prevalidated: bool = false) -> Dictionary:
	if _sequence_is_suppressed(environment, definition):
		_clear_environment_sequence(environment)
		return {}
	definition = sequence_definition_for_environment(environment, definition)
	if not SequenceSchemaScript.is_sequence(definition):
		return {}
	if not bool(environment.get("scenario_semantic_ready", false)):
		return {}
	var stored_state_value: Variant = environment.get("scenario_sequence_state", {})
	var trusted_state_value: Variant = environment.get(TRUSTED_STATE_REFERENCE_KEY, "")
	if typeof(stored_state_value) == TYPE_DICTIONARY \
		and typeof(trusted_state_value) == TYPE_STRING \
		and typeof(environment.get("scenario_semantic_inventory_version")) == TYPE_INT \
		and typeof(environment.get("scenario_semantic_digest")) == TYPE_STRING \
		and typeof(environment.get("scenario_semantic_action_digest")) == TYPE_STRING:
		var trusted_state := stored_state_value as Dictionary
		var trusted_semantic := JsonCoerceScript._copy_dict(trusted_state.get("semantic_state", {}))
		if int(trusted_state.get("schema_version", 0)) == SequenceRuntimeScript.STATE_SCHEMA_VERSION \
			and str(trusted_state.get("scenario_id", "")) == str(definition.get("id", definition.get("scenario_id", ""))) \
			and str(trusted_state.get("node_id", "")) == str(environment.get("world_node_id", environment.get("archetype_id", environment.get("id", "")))) \
			and _trusted_host_semantics_match(environment, trusted_semantic) \
			and int(trusted_semantic.get("inventory_schema_version", 0)) == int(environment.get("scenario_semantic_inventory_version", 0)) \
			and str(trusted_semantic.get("inventory_digest", "")) == str(environment.get("scenario_semantic_digest", "")) \
			and str(trusted_state_value) == SequenceRuntimeScript.content_fingerprint(trusted_state):
			return trusted_state
	if not str(environment.get("scenario_sequence_migration_error", "")).is_empty():
		environment["scenario_sequence_lifecycle_errors"] = [str(environment.get("scenario_sequence_migration_error", ""))]
		environment.erase("scenario_semantic_ready")
		return {}
	var node_id := str(environment.get("world_node_id", environment.get("archetype_id", environment.get("id", "")))).strip_edges()
	var host_semantics := sequence_host_semantics(environment)
	var state := SequenceRuntimeScript.normalize_state(environment.get("scenario_sequence_state", {}), definition, host_semantics)
	if state.is_empty() and environment.has("scenario_sequence_state"):
		environment["scenario_sequence_migration_error"] = "Persisted dynamic room sequence state cannot be normalized; explicit migration is required."
		environment["scenario_sequence_lifecycle_errors"] = [str(environment.get("scenario_sequence_migration_error", ""))]
		environment.erase("scenario_semantic_ready")
		return {}
	if state.is_empty():
		_capture_sequence_baseline(environment)
		state = SequenceRuntimeScript.initial_state(definition, node_id, seed_token, host_semantics, definition_prevalidated)
	else:
		var node_binding_failed := false
		if str(state.get("node_id", "")) != node_id:
			if _sequence_state_can_bind_initial_node(state, environment, definition, host_semantics):
				# Initial operation/transition receipts are structurally bound to the
				# old node. Recreate the semantically pristine initial state instead
				# of rewriting its node while retaining contradictory journals.
				state = SequenceRuntimeScript.initial_state(definition, node_id, str(state.get("seed_token", "")), host_semantics)
				if state.is_empty() or str(state.get("status", "")) == SequenceRuntimeScript.STATUS_CLEANED:
					node_binding_failed = true
			else:
				node_binding_failed = true
				var quarantine_cleanup := SequenceRuntimeScript._apply_cleanup(state, definition, "node_binding_mismatch")
				if bool(quarantine_cleanup.get("ok", false)):
					state = JsonCoerceScript._copy_dict(quarantine_cleanup.get("state", state))
				state["status"] = SequenceRuntimeScript.STATUS_CLEANED
				state["errors"] = ["scenario progressed sequence state is bound to another world node; explicit migration is required"]
				if not bool(quarantine_cleanup.get("ok", false)):
					state["errors"].append_array(JsonCoerceScript._copy_array(quarantine_cleanup.get("errors", [])))
		if not node_binding_failed and not JsonCoerceScript._copy_array(host_semantics.get("inventory_errors", [])).is_empty():
			state["status"] = SequenceRuntimeScript.STATUS_CLEANED
			state["errors"] = JsonCoerceScript._copy_array(host_semantics.get("inventory_errors", []))
		elif not node_binding_failed and (int(JsonCoerceScript._copy_dict(state.get("semantic_state", {})).get("inventory_schema_version", 0)) != int(host_semantics.get("inventory_schema_version", 0)) or str(JsonCoerceScript._copy_dict(state.get("semantic_state", {})).get("inventory_digest", "")) != str(host_semantics.get("inventory_digest", ""))):
			state["status"] = SequenceRuntimeScript.STATUS_CLEANED
			state["errors"] = ["scenario semantic inventory digest changed; explicit migration is required"]
		elif not node_binding_failed:
			# Saved authorization arrays are never trusted. Rebuild and replace them
			# from the immutable current EnvironmentInstance proof on every ingress.
			var semantic := JsonCoerceScript._copy_dict(state.get("semantic_state", {}))
			var target_inventory := JsonCoerceScript._copy_dict(host_semantics.get("target_inventory", {}))
			target_inventory["event_choices"] = JsonCoerceScript._copy_dict(host_semantics.get("event_choices", {}))
			semantic["target_inventory"] = target_inventory
			semantic["declared_targets"] = SequenceSchemaScript.verified_declared_targets(definition, target_inventory)
			semantic["base_interactions"] = JsonCoerceScript._copy_array(host_semantics.get("base_interactions", []))
			semantic["event_choices"] = JsonCoerceScript._copy_dict(host_semantics.get("event_choices", {}))
			state["semantic_state"] = semantic
			var rebuilt := _rebuild_receipted_semantic_mutations(state, definition, host_semantics)
			if not bool(rebuilt.get("ok", false)):
				state["status"] = SequenceRuntimeScript.STATUS_CLEANED
				state["errors"] = JsonCoerceScript._copy_array(rebuilt.get("errors", []))
			else:
				state = JsonCoerceScript._copy_dict(rebuilt.get("state", state))
	environment["scenario_sequence_state"] = state
	environment[TRUSTED_STATE_REFERENCE_KEY] = SequenceRuntimeScript.content_fingerprint(state)
	return state.duplicate(true)


static func _rebuild_receipted_semantic_mutations(state_value: Dictionary, definition: Dictionary, host_semantics: Dictionary) -> Dictionary:
	var state := state_value.duplicate(true)
	var errors: Array = []
	var causal_record_total := JsonCoerceScript._copy_array(state.get("command_receipt_records", [])).size() + JsonCoerceScript._copy_array(state.get("fact_receipt_records", [])).size() + JsonCoerceScript._copy_array(state.get("visit_receipt_records", [])).size() + JsonCoerceScript._copy_array(state.get("expiry_boundary_records", [])).size()
	if causal_record_total > SequenceRuntimeScript.MAX_RECEIPTS or causal_record_total + JsonCoerceScript._copy_array(state.get("fact_queue", [])).size() > SequenceRuntimeScript.MAX_RECEIPTS:
		errors.append("scenario causal journal plus pending facts exceeds the lifetime receipt limit")
	var cause_validation := _validated_cause_records(state, definition, host_semantics)
	errors.append_array(JsonCoerceScript._copy_array(cause_validation.get("errors", [])))
	var expiry_validation := _validated_expiry_boundary_records(state, definition)
	errors.append_array(JsonCoerceScript._copy_array(expiry_validation.get("errors", [])))
	var visit_validation := _validated_visit_records(state)
	errors.append_array(JsonCoerceScript._copy_array(visit_validation.get("errors", [])))
	var delivery_validation := _validated_event_request_deliveries(state)
	errors.append_array(JsonCoerceScript._copy_array(delivery_validation.get("errors", [])))
	if not errors.is_empty(): return {"ok": false, "errors": errors}
	var causal_records := JsonCoerceScript._copy_array(cause_validation.get("ordered_records", []))
	causal_records.append_array(JsonCoerceScript._copy_array(expiry_validation.get("ordered_records", [])))
	causal_records.append_array(JsonCoerceScript._copy_array(visit_validation.get("ordered_records", [])))
	causal_records.sort_custom(func(a: Variant, b: Variant) -> bool: return int(JsonCoerceScript._copy_dict(a).get("cause_ordinal", -1)) < int(JsonCoerceScript._copy_dict(b).get("cause_ordinal", -1)))
	for record_index in range(causal_records.size()):
		if int(JsonCoerceScript._copy_dict(causal_records[record_index]).get("cause_ordinal", -1)) != record_index:
			errors.append("scenario causal journal ordinals are incomplete, duplicated, or reordered")
	if not errors.is_empty(): return {"ok": false, "errors": errors}
	var replay := SequenceRuntimeScript.initial_state(definition, str(state.get("node_id", "")), str(state.get("seed_token", "")), host_semantics)
	if replay.is_empty() or str(replay.get("status", "")) == SequenceRuntimeScript.STATUS_CLEANED:
		return {"ok": false, "errors": ["scenario causal replay could not initialize trusted host semantics"]}
	var replay_result := _replay_causal_records(replay, definition, causal_records, JsonCoerceScript._copy_array(cause_validation.get("fact_batch_records", [])), JsonCoerceScript._copy_array(delivery_validation.get("history", [])), JsonCoerceScript._copy_array(delivery_validation.get("receipts", [])))
	if not bool(replay_result.get("ok", false)):
		return {"ok": false, "errors": JsonCoerceScript._copy_array(replay_result.get("errors", []))}
	replay = JsonCoerceScript._copy_dict(replay_result.get("state", replay))
	errors.append_array(_exact_replay_journal_errors(state, replay))
	if not errors.is_empty(): return {"ok": false, "errors": errors}
	# Preserve only pending ingress, which has not crossed a causal boundary.
	# Every applied mutation and visit comes from the trusted replay above.
	replay["fact_queue"] = JsonCoerceScript._copy_array(state.get("fact_queue", []))
	replay["fact_serial_next"] = maxi(int(replay.get("fact_serial_next", 1)), int(state.get("fact_serial_next", 1)))
	var semantic := JsonCoerceScript._copy_dict(replay.get("semantic_state", {}))
	# Transition operations are one-shot presentation effects. Their receipts
	# prove they ran, but save/revisit reconstruction must never replay them.
	semantic["transition_queue"] = []
	replay["semantic_state"] = semantic
	return {"ok": true, "state": replay, "errors": []}


static func _validated_event_request_deliveries(state: Dictionary) -> Dictionary:
	var errors: Array = []
	var history := JsonCoerceScript._copy_array(state.get("event_request_history", []))
	var receipts := JsonCoerceScript._copy_array(state.get("event_request_delivery_receipts", []))
	var seen: Dictionary = {}
	if history.size() != receipts.size():
		errors.append("scenario event-request delivery history and receipts differ in size")
	for index in range(history.size()):
		var request := JsonCoerceScript._copy_dict(history[index])
		var request_id := str(request.get("request_id", "")).strip_edges()
		if request_id.is_empty() or index >= receipts.size() or typeof(receipts[index]) != TYPE_STRING or str(receipts[index]) != request_id or seen.has(request_id):
			errors.append("scenario event-request delivery history is not exactly authenticated by ordered receipts")
			continue
		seen[request_id] = true
	return {"history": history, "receipts": receipts, "errors": errors}


static func _validated_cause_records(state: Dictionary, definition: Dictionary, host_semantics: Dictionary) -> Dictionary:
	var errors: Array = []
	var causes: Dictionary = {}
	var ordered_records: Array = []
	var validated_command_records: Array = []
	var command_receipts := JsonCoerceScript._copy_array(state.get("command_receipts", []))
	var command_fingerprints := JsonCoerceScript._copy_dict(state.get("command_fingerprints", {}))
	var command_records := JsonCoerceScript._copy_array(state.get("command_receipt_records", []))
	for record_index in range(command_records.size()):
		var record := JsonCoerceScript._copy_dict(command_records[record_index])
		var envelope := JsonCoerceScript._copy_dict(record.get("envelope", {}))
		var causal_descriptor := JsonCoerceScript._copy_dict(record.get("causal_action_descriptor", {}))
		if record.size() != 6 or not _exact_string_fields(record, ["receipt_key", "fingerprint", "causal_action_descriptor_fingerprint"]) or not JsonCoerceScript._valid_sha256(str(record.get("fingerprint", ""))) or not JsonCoerceScript._valid_sha256(str(record.get("causal_action_descriptor_fingerprint", ""))) or typeof(record.get("cause_ordinal")) != TYPE_INT or int(record.get("cause_ordinal", -1)) < 0 or envelope.size() != 13 or typeof(envelope.get("schema_version")) != TYPE_INT or int(envelope.get("schema_version", 0)) != SequenceRuntimeScript.COMMAND_SCHEMA_VERSION or typeof(envelope.get("payload")) != TYPE_DICTIONARY or causal_descriptor.is_empty():
			errors.append("scenario command receipt record is not closed and typed")
			continue
		var command_strings := ["command_id", "node_id", "expected_phase", "idempotency_key", "owner_namespace", "stable_object_id", "action_origin_owner_namespace", "action_origin_stable_object_id", "action_origin_receipt_key", "action_origin_boundary_id", "action_origin_fingerprint"]
		if not _exact_string_values(envelope, command_strings, ["action_origin_receipt_key", "action_origin_boundary_id", "action_origin_fingerprint"]):
			errors.append("scenario command receipt envelope contains non-exact string fields")
			continue
		var receipt_key := str(record.get("receipt_key", ""))
		var fingerprint := SequenceRuntimeScript.content_fingerprint(envelope)
		var cause_key := "command|%s" % receipt_key
		if record_index >= command_receipts.size() or str(command_receipts[record_index]) != receipt_key or str(envelope.get("idempotency_key", "")) != receipt_key or str(envelope.get("node_id", "")) != str(state.get("node_id", "")) or SequenceSchemaScript.phase(definition, str(envelope.get("expected_phase", ""))).is_empty() or OperationRegistryScript.parse_owned_identity(OperationRegistryScript.identity(str(envelope.get("owner_namespace", "")), str(envelope.get("stable_object_id", "")))).is_empty() or str(record.get("fingerprint", "")) != fingerprint or str(command_fingerprints.get(receipt_key, "")) != fingerprint or str(record.get("causal_action_descriptor_fingerprint", "")) != SequenceRuntimeScript.content_fingerprint(causal_descriptor) or not SequenceRuntimeScript.validate_causal_action_descriptor(state, definition, envelope, causal_descriptor).is_empty() or causes.has(cause_key):
			errors.append("scenario command receipt record does not authenticate its exact envelope")
			continue
		validated_command_records.append(record)
		causes[cause_key] = {"kind": "command", "receipt_key": receipt_key, "fingerprint": fingerprint, "envelope": envelope}
		ordered_records.append({"kind": "command", "cause_ordinal": int(record.get("cause_ordinal", -1)), "record": record})
	if command_receipts.size() != validated_command_records.size() or command_fingerprints.size() != validated_command_records.size():
		errors.append("scenario command receipts contain unauthenticated entries")
	var fact_receipts := JsonCoerceScript._copy_array(state.get("fact_receipts", []))
	var fact_fingerprints := JsonCoerceScript._copy_dict(state.get("fact_fingerprints", {}))
	var fact_records := JsonCoerceScript._copy_array(state.get("fact_receipt_records", []))
	var fact_validation_state := state.duplicate(true)
	fact_validation_state["status"] = SequenceRuntimeScript.STATUS_ACTIVE
	var trusted_semantic := JsonCoerceScript._copy_dict(fact_validation_state.get("semantic_state", {}))
	trusted_semantic["event_choices"] = JsonCoerceScript._copy_dict(host_semantics.get("event_choices", {}))
	fact_validation_state["semantic_state"] = trusted_semantic
	var validated_fact_records: Array = []
	for record_index in range(fact_records.size()):
		var record := JsonCoerceScript._copy_dict(fact_records[record_index])
		var envelope := JsonCoerceScript._copy_dict(record.get("envelope", {}))
		if record.size() != 6 or not _exact_string_fields(record, ["receipt_key", "fingerprint"]) or not JsonCoerceScript._valid_sha256(str(record.get("fingerprint", ""))) or typeof(record.get("cause_ordinal")) != TYPE_INT or int(record.get("cause_ordinal", -1)) < 0 or typeof(record.get("flush_batch_ordinal")) != TYPE_INT or int(record.get("flush_batch_ordinal", -1)) < 0 or typeof(record.get("flush_boundary_serial")) != TYPE_INT or int(record.get("flush_boundary_serial", -1)) < 0 or envelope.size() != 8 or not SequenceRuntimeScript.validate_fact(fact_validation_state, envelope).is_empty():
			errors.append("scenario fact receipt record is not a closed valid envelope")
			continue
		var receipt_key := str(record.get("receipt_key", ""))
		var fingerprint := SequenceRuntimeScript.content_fingerprint(envelope)
		var cause_key := "fact|%s" % receipt_key
		if record_index >= fact_receipts.size() or str(fact_receipts[record_index]) != receipt_key or str(envelope.get("fact_id", "")) != receipt_key or int(record.get("flush_boundary_serial", -1)) < int(envelope.get("boundary_serial", 0)) or str(record.get("fingerprint", "")) != fingerprint or str(fact_fingerprints.get(receipt_key, "")) != fingerprint or causes.has(cause_key):
			errors.append("scenario fact receipt record does not authenticate its exact envelope")
			continue
		validated_fact_records.append(record)
		causes[cause_key] = {"kind": "fact", "receipt_key": receipt_key, "fingerprint": fingerprint, "envelope": envelope}
		ordered_records.append({"kind": "fact", "cause_ordinal": int(record.get("cause_ordinal", -1)), "record": record})
	if fact_receipts.size() != validated_fact_records.size() or fact_fingerprints.size() != validated_fact_records.size():
		errors.append("scenario fact receipts contain unauthenticated entries")
	var batch_records := JsonCoerceScript._copy_array(state.get("fact_flush_batch_records", []))
	var validated_batch_records: Array = []
	var next_fact_record_index := 0
	var prior_batch_fingerprint := "0".repeat(64)
	var prior_effective_boundary := 0
	for batch_index in range(batch_records.size()):
		var batch := JsonCoerceScript._copy_dict(batch_records[batch_index])
		var receipt_keys := JsonCoerceScript._copy_array(batch.get("fact_receipt_keys", []))
		var batch_fingerprints := JsonCoerceScript._copy_array(batch.get("fact_fingerprints", []))
		if batch.size() != 8 or typeof(batch.get("batch_ordinal")) != TYPE_INT or int(batch.get("batch_ordinal", -1)) != batch_index or typeof(batch.get("requested_boundary_serial")) != TYPE_INT or int(batch.get("requested_boundary_serial", -1)) < 0 or typeof(batch.get("effective_boundary_serial")) != TYPE_INT or int(batch.get("effective_boundary_serial", -1)) < 0 or typeof(batch.get("first_cause_ordinal")) != TYPE_INT or int(batch.get("first_cause_ordinal", -1)) < 0 or typeof(batch.get("fact_receipt_keys")) != TYPE_ARRAY or typeof(batch.get("fact_fingerprints")) != TYPE_ARRAY or receipt_keys.is_empty() or receipt_keys.size() != batch_fingerprints.size() or not _exact_string_fields(batch, ["prior_batch_fingerprint", "batch_fingerprint"]):
			errors.append("scenario fact flush batch delimiter is not closed and typed")
			continue
		if str(batch.get("prior_batch_fingerprint", "")) != prior_batch_fingerprint or not JsonCoerceScript._valid_sha256(str(batch.get("batch_fingerprint", ""))) or str(batch.get("batch_fingerprint", "")) != SequenceRuntimeScript.fact_flush_batch_fingerprint(batch) or int(batch.get("effective_boundary_serial", -1)) != maxi(prior_effective_boundary, int(batch.get("requested_boundary_serial", -1))):
			errors.append("scenario fact flush batch delimiter chain/fingerprint is invalid")
			continue
		var batch_valid := true
		for batch_fact_index in range(receipt_keys.size()):
			if next_fact_record_index >= validated_fact_records.size():
				batch_valid = false
				break
			var fact_record := JsonCoerceScript._copy_dict(validated_fact_records[next_fact_record_index])
			if typeof(receipt_keys[batch_fact_index]) != TYPE_STRING or typeof(batch_fingerprints[batch_fact_index]) != TYPE_STRING or str(receipt_keys[batch_fact_index]) != str(fact_record.get("receipt_key", "")) or str(batch_fingerprints[batch_fact_index]) != str(fact_record.get("fingerprint", "")) or int(fact_record.get("flush_batch_ordinal", -1)) != batch_index or int(fact_record.get("flush_boundary_serial", -1)) != int(batch.get("effective_boundary_serial", -1)) or int(fact_record.get("cause_ordinal", -1)) != int(batch.get("first_cause_ordinal", -1)) + batch_fact_index:
				batch_valid = false
			next_fact_record_index += 1
		if not batch_valid:
			errors.append("scenario fact flush batch delimiter does not authenticate its exact ordered facts")
			continue
		validated_batch_records.append(batch)
		prior_batch_fingerprint = str(batch.get("batch_fingerprint", ""))
		prior_effective_boundary = int(batch.get("effective_boundary_serial", 0))
	if next_fact_record_index != validated_fact_records.size() or validated_batch_records.size() != batch_records.size():
		errors.append("scenario fact receipt records are not covered exactly once by authenticated flush batches")
	return {"causes": causes, "command_records": validated_command_records, "fact_records": validated_fact_records, "fact_batch_records": validated_batch_records, "ordered_records": ordered_records, "errors": errors}


static func _validated_visit_records(state: Dictionary) -> Dictionary:
	var errors: Array = []
	var ordered_records: Array = []
	var receipts := JsonCoerceScript._copy_array(state.get("visit_receipts", []))
	var records := JsonCoerceScript._copy_array(state.get("visit_receipt_records", []))
	var seen: Dictionary = {}
	for record_index in range(records.size()):
		var record := JsonCoerceScript._copy_dict(records[record_index])
		if record.size() != 3 or not _exact_string_fields(record, ["receipt_key", "visit_id"]) or typeof(record.get("cause_ordinal")) != TYPE_INT or int(record.get("cause_ordinal", -1)) < 0 or str(record.get("visit_id", "")).length() > OperationRegistryScript.MAX_VARIANT_TEXT:
			errors.append("scenario visit receipt record is not closed, typed, and bounded")
			continue
		var receipt_key := str(record.get("receipt_key", ""))
		var expected := "visit:%s" % str(record.get("visit_id", ""))
		if record_index >= receipts.size() or str(receipts[record_index]) != receipt_key or receipt_key != expected or seen.has(receipt_key):
			errors.append("scenario visit receipt record does not authenticate its exact visit")
			continue
		seen[receipt_key] = true
		ordered_records.append({"kind": "visit", "cause_ordinal": int(record.get("cause_ordinal", -1)), "record": record})
	if receipts.size() != ordered_records.size():
		errors.append("scenario visit receipts contain unauthenticated entries")
	return {"ordered_records": ordered_records, "errors": errors}


static func _validated_expiry_boundary_records(state: Dictionary, definition: Dictionary) -> Dictionary:
	var errors: Array = []
	var ordered_records: Array = []
	var authored_boundary := str(JsonCoerceScript._copy_dict(SequenceSchemaScript.sequence(definition).get("expiry", {})).get("boundary", "none"))
	for record_value in JsonCoerceScript._copy_array(state.get("expiry_boundary_records", [])):
		var record := JsonCoerceScript._copy_dict(record_value)
		if record.size() != 3 or typeof(record.get("cause_ordinal")) != TYPE_INT or int(record.get("cause_ordinal", -1)) < 0 or typeof(record.get("boundary")) != TYPE_STRING or str(record.get("boundary", "")) != str(record.get("boundary", "")).strip_edges() or str(record.get("boundary", "")).is_empty() or typeof(record.get("amount")) != TYPE_INT or int(record.get("amount", 0)) < 1:
			errors.append("scenario expiry boundary record is not closed and typed")
			continue
		if authored_boundary == "none" or str(record.get("boundary", "")) != authored_boundary:
			errors.append("scenario expiry boundary record does not match the authored boundary")
			continue
		ordered_records.append({"kind": "expiry", "cause_ordinal": int(record.get("cause_ordinal", -1)), "record": record})
	return {"ordered_records": ordered_records, "errors": errors}


static func _replay_causal_records(initial: Dictionary, definition: Dictionary, causal_records: Array, fact_batch_records: Array, delivered_history: Array = [], delivery_receipts: Array = []) -> Dictionary:
	var state := initial.duplicate(true)
	var initial_delivery_restore := _restore_replayed_event_request_deliveries(state, delivered_history, delivery_receipts)
	if not bool(initial_delivery_restore.get("ok", false)):
		return {"ok": false, "state": initial, "errors": JsonCoerceScript._copy_array(initial_delivery_restore.get("errors", []))}
	state = JsonCoerceScript._copy_dict(initial_delivery_restore.get("state", state))
	var record_index := 0
	var expected_fact_batch_ordinal := 0
	while record_index < causal_records.size():
		var causal := JsonCoerceScript._copy_dict(causal_records[record_index])
		var kind := str(causal.get("kind", ""))
		if kind == "fact":
			var first_fact_record := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(causal_records[record_index]).get("record", {}))
			var batch_ordinal := int(first_fact_record.get("flush_batch_ordinal", -1))
			var batch := JsonCoerceScript._copy_dict(fact_batch_records[expected_fact_batch_ordinal] if expected_fact_batch_ordinal < fact_batch_records.size() else {})
			var expected_receipt_keys := JsonCoerceScript._copy_array(batch.get("fact_receipt_keys", []))
			var requested_boundary := int(batch.get("requested_boundary_serial", -1))
			var target_boundary := int(batch.get("effective_boundary_serial", -1))
			if batch_ordinal != expected_fact_batch_ordinal or int(batch.get("batch_ordinal", -1)) != batch_ordinal or requested_boundary < 0 or target_boundary < 0:
				return {"ok": false, "state": initial, "errors": ["scenario causal fact batches are missing, duplicated, or reordered"]}
			var batch_fact_index := 0
			while record_index < causal_records.size() and str(JsonCoerceScript._copy_dict(causal_records[record_index]).get("kind", "")) == "fact" and int(JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(causal_records[record_index]).get("record", {})).get("flush_batch_ordinal", -1)) == batch_ordinal:
				var fact_record := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(causal_records[record_index]).get("record", {}))
				if batch_fact_index >= expected_receipt_keys.size() or str(fact_record.get("receipt_key", "")) != str(expected_receipt_keys[batch_fact_index]) or int(fact_record.get("flush_boundary_serial", -1)) != target_boundary:
					return {"ok": false, "state": initial, "errors": ["scenario causal fact batch contains conflicting flush boundaries"]}
				var envelope := JsonCoerceScript._copy_dict(fact_record.get("envelope", {}))
				var queued := SequenceRuntimeScript.enqueue_fact(state, definition, envelope)
				if not bool(queued.get("ok", false)) or bool(queued.get("duplicate", false)):
					return {"ok": false, "state": initial, "errors": ["scenario causal replay rejected a journaled fact: %s" % JSON.stringify(queued.get("errors", []))]}
				state = JsonCoerceScript._copy_dict(queued.get("state", state))
				record_index += 1
				batch_fact_index += 1
			if batch_fact_index != expected_receipt_keys.size():
				return {"ok": false, "state": initial, "errors": ["scenario causal fact batch delimiter count does not match its facts"]}
			var flushed := SequenceRuntimeScript.flush_facts(state, definition, requested_boundary)
			if not bool(flushed.get("ok", false)):
				return {"ok": false, "state": initial, "errors": ["scenario causal replay rejected a journaled fact batch: %s" % JSON.stringify(flushed.get("errors", []))]}
			state = JsonCoerceScript._copy_dict(flushed.get("state", state))
			var fact_delivery_restore := _restore_replayed_event_request_deliveries(state, delivered_history, delivery_receipts)
			if not bool(fact_delivery_restore.get("ok", false)):
				return {"ok": false, "state": initial, "errors": JsonCoerceScript._copy_array(fact_delivery_restore.get("errors", []))}
			state = JsonCoerceScript._copy_dict(fact_delivery_restore.get("state", state))
			var replayed_batches := JsonCoerceScript._copy_array(state.get("fact_flush_batch_records", []))
			if replayed_batches.is_empty() or SequenceRuntimeScript.content_fingerprint(replayed_batches.back()) != SequenceRuntimeScript.content_fingerprint(batch):
				return {"ok": false, "state": initial, "errors": ["scenario causal replay did not reproduce the exact authenticated fact batch delimiter"]}
			expected_fact_batch_ordinal += 1
			continue
		var record := JsonCoerceScript._copy_dict(causal.get("record", {}))
		var result: Dictionary = {}
		if kind == "command":
			result = SequenceRuntimeScript.apply_command(state, definition, JsonCoerceScript._copy_dict(record.get("envelope", {})), {"available_funds": 9223372036854775807, "causal_action_descriptor": JsonCoerceScript._copy_dict(record.get("causal_action_descriptor", {}))})
		elif kind == "visit":
			result = SequenceRuntimeScript.record_visit(state, definition, str(record.get("visit_id", "")))
		elif kind == "expiry":
			result = SequenceRuntimeScript.apply_expiry_boundary(state, definition, str(record.get("boundary", "")), int(record.get("amount", 1)))
		else:
			return {"ok": false, "state": initial, "errors": ["scenario causal replay encountered an unknown journal kind"]}
		if not bool(result.get("ok", false)):
			return {"ok": false, "state": initial, "errors": ["scenario causal replay rejected a journaled %s: %s" % [kind, JSON.stringify(result.get("errors", []))]]}
		state = JsonCoerceScript._copy_dict(result.get("state", state))
		var delivery_restore := _restore_replayed_event_request_deliveries(state, delivered_history, delivery_receipts)
		if not bool(delivery_restore.get("ok", false)):
			return {"ok": false, "state": initial, "errors": JsonCoerceScript._copy_array(delivery_restore.get("errors", []))}
		state = JsonCoerceScript._copy_dict(delivery_restore.get("state", state))
		record_index += 1
	if expected_fact_batch_ordinal != fact_batch_records.size():
		return {"ok": false, "state": initial, "errors": ["scenario causal replay did not consume every authenticated fact batch delimiter"]}
	if SequenceRuntimeScript.content_fingerprint(state.get("event_request_history", [])) != SequenceRuntimeScript.content_fingerprint(delivered_history) or SequenceRuntimeScript.content_fingerprint(state.get("event_request_delivery_receipts", [])) != SequenceRuntimeScript.content_fingerprint(delivery_receipts):
		return {"ok": false, "state": initial, "errors": ["scenario causal replay did not restore every authenticated event-request delivery"]}
	return {"ok": true, "state": state, "errors": []}


static func _restore_replayed_event_request_deliveries(state_value: Dictionary, delivered_history: Array, delivery_receipts: Array) -> Dictionary:
	var state := state_value.duplicate(true)
	var restored_history := JsonCoerceScript._copy_array(state.get("event_request_history", []))
	var restored_receipts := JsonCoerceScript._copy_array(state.get("event_request_delivery_receipts", []))
	if restored_history.size() != restored_receipts.size() or restored_history.size() > delivered_history.size():
		return {"ok": false, "state": state_value, "errors": ["scenario replayed event-request delivery prefix is invalid"]}
	var queue := JsonCoerceScript._copy_array(state.get("event_request_queue", []))
	while restored_history.size() < delivered_history.size():
		var index := restored_history.size()
		var expected := JsonCoerceScript._copy_dict(delivered_history[index])
		var expected_id := str(delivery_receipts[index]) if index < delivery_receipts.size() else ""
		var queue_index := -1
		for candidate_index in range(queue.size()):
			if str(JsonCoerceScript._copy_dict(queue[candidate_index]).get("request_id", "")) == expected_id:
				queue_index = candidate_index
				break
		if queue_index < 0:
			break
		var replayed_request := JsonCoerceScript._copy_dict(queue[queue_index])
		if SequenceRuntimeScript.content_fingerprint(replayed_request) != SequenceRuntimeScript.content_fingerprint(expected):
			return {"ok": false, "state": state_value, "errors": ["scenario replayed event request differs from its authenticated delivery history"]}
		queue.remove_at(queue_index)
		restored_history.append(expected)
		restored_receipts.append(expected_id)
	state["event_request_queue"] = queue
	state["event_request_history"] = restored_history
	state["event_request_delivery_receipts"] = restored_receipts
	return {"ok": true, "state": state, "errors": []}


static func _exact_replay_journal_errors(stored: Dictionary, replayed: Dictionary) -> Array:
	var errors: Array = []
	for key in ["command_receipts", "command_receipt_records", "command_results", "command_fingerprints", "fact_receipts", "fact_receipt_records", "fact_flush_batch_records", "fact_fingerprints", "visit_receipts", "visit_receipt_records", "expiry_boundary_records", "branch_resolution_records", "transition_receipts", "transition_receipt_records", "cleanup_receipts", "cleanup_receipt_records", "cleanup_fingerprints", "cleanup_content_fingerprint", "event_correlations"]:
		if SequenceRuntimeScript.content_fingerprint(stored.get(key)) != SequenceRuntimeScript.content_fingerprint(replayed.get(key)):
			errors.append("scenario saved %s does not exactly match causal replay" % key)
	var stored_semantic := JsonCoerceScript._copy_dict(stored.get("semantic_state", {}))
	var replayed_semantic := JsonCoerceScript._copy_dict(replayed.get("semantic_state", {}))
	for key in ["operation_receipts", "operation_receipt_records", "operation_fingerprints"]:
		if SequenceRuntimeScript.content_fingerprint(stored_semantic.get(key)) != SequenceRuntimeScript.content_fingerprint(replayed_semantic.get(key)):
			errors.append("scenario saved semantic %s does not exactly match causal replay" % key)
	return errors
static func _exact_string_values(value: Dictionary, fields: Array, allow_empty: Array = []) -> bool:
	for field_value in fields:
		var field := str(field_value)
		if typeof(value.get(field)) != TYPE_STRING or str(value.get(field, "")) != str(value.get(field, "")).strip_edges() or str(value.get(field, "")).is_empty() and not allow_empty.has(field): return false
	return true
static func _exact_string_fields(value: Dictionary, fields: Array) -> bool:
	for field_value in fields:
		var field := str(field_value)
		if typeof(value.get(field)) != TYPE_STRING or str(value.get(field, "")) != str(value.get(field, "")).strip_edges() or str(value.get(field, "")).is_empty(): return false
	return true
static func sequence_apply_reentry(environment: Dictionary, definition: Dictionary, visit_id: String) -> Dictionary:
	var candidate := environment.duplicate(false)
	var state := ensure_sequence_state(candidate, definition)
	if state.is_empty(): return {"ok": false, "errors": ["No dynamic room sequence is active."]}
	return _commit_sequence_candidate(environment, candidate, definition, SequenceRuntimeScript.apply_reentry(state, definition, visit_id, sequence_host_semantics(candidate), true))


static func sequence_apply_expiry_boundary(environment: Dictionary, definition: Dictionary, boundary: String, amount: int = 1) -> Dictionary:
	var candidate := environment.duplicate(false)
	var state := ensure_sequence_state(candidate, definition)
	if state.is_empty(): return {"ok": false, "errors": ["No dynamic room sequence is active."]}
	return _commit_sequence_candidate(environment, candidate, definition, SequenceRuntimeScript.apply_expiry_boundary(state, definition, boundary, amount, true))


static func sequence_host_semantics(environment: Dictionary) -> Dictionary:
	var base_interactions := JsonCoerceScript._copy_array(environment.get("scenario_base_interactions", []))
	var sealed_inventory := JsonCoerceScript._copy_dict(environment.get("scenario_semantic_inventory", {}))
	if not bool(environment.get("scenario_semantic_ready", false)) or sealed_inventory.is_empty():
		return {"target_inventory": {}, "inventory_schema_version": 0, "inventory_digest": "", "inventory_errors": ["scenario semantic records are not finalized"], "base_interactions": [], "event_choices": {}}
	if typeof(environment.get("scenario_semantic_inventory_version")) != TYPE_INT or typeof(environment.get("scenario_semantic_digest")) != TYPE_STRING:
		return {"target_inventory": {}, "inventory_schema_version": 0, "inventory_digest": "", "inventory_errors": ["scenario semantic proof reference is missing or malformed"], "base_interactions": [], "event_choices": {}}
	if typeof(environment.get("scenario_semantic_action_digest")) != TYPE_STRING or not JsonCoerceScript._valid_sha256(str(environment.get("scenario_semantic_action_digest", ""))) or str(environment.get("scenario_semantic_action_digest", "")) != SequenceRuntimeScript.base_interaction_action_authority_digest(base_interactions):
		return {"target_inventory": {}, "inventory_schema_version": 0, "inventory_digest": "", "inventory_errors": ["scenario semantic action authority is missing or stale"], "base_interactions": [], "event_choices": {}}
	if int(environment.get("scenario_semantic_inventory_version", 0)) != int(sealed_inventory.get("schema_version", 0)) or str(environment.get("scenario_semantic_digest", "")) != str(sealed_inventory.get("digest", "")):
		return {"target_inventory": {}, "inventory_schema_version": 0, "inventory_digest": "", "inventory_errors": ["scenario semantic proof reference does not match the sealed inventory"], "base_interactions": [], "event_choices": {}}
	# The sealed inventory is the immutable authority envelope. Live environment
	# geometry and material hooks may only constrain a candidate and are checked
	# during its atomic materialization/layout pass; they can never add a target
	# that is absent from these exact sealed collections.
	return {"target_inventory": EnvironmentSemanticInventoryScript.exact_collections(sealed_inventory), "inventory_schema_version": int(sealed_inventory.get("schema_version", 0)), "inventory_digest": str(sealed_inventory.get("digest", "")), "inventory_errors": [], "base_interactions": base_interactions, "event_choices": JsonCoerceScript._copy_dict(environment.get("scenario_event_choices", {}))}


static func _trusted_host_semantics_match(environment: Dictionary, trusted_semantic: Dictionary) -> bool:
	# The trusted hot path needs only to prove that the sealed host authority has
	# not changed. Avoid materializing a second full target inventory merely to
	# compare its already-sealed version and digest.
	if not bool(environment.get("scenario_semantic_ready", false)):
		return false
	var sealed_inventory_value: Variant = environment.get("scenario_semantic_inventory", {})
	var base_interactions_value: Variant = environment.get("scenario_base_interactions", [])
	var event_choices_value: Variant = environment.get("scenario_event_choices", {})
	if typeof(sealed_inventory_value) != TYPE_DICTIONARY or (sealed_inventory_value as Dictionary).is_empty() \
		or typeof(base_interactions_value) != TYPE_ARRAY or typeof(event_choices_value) != TYPE_DICTIONARY:
		return false
	if typeof(environment.get("scenario_semantic_inventory_version")) != TYPE_INT \
		or typeof(environment.get("scenario_semantic_digest")) != TYPE_STRING \
		or typeof(environment.get("scenario_semantic_action_digest")) != TYPE_STRING:
		return false
	var sealed_inventory := sealed_inventory_value as Dictionary
	var base_interactions := base_interactions_value as Array
	var action_digest := str(environment.get("scenario_semantic_action_digest", ""))
	# The action digest is the closed authority subset consumed by commands. The
	# sealed inventory independently binds presentation identities and the trusted
	# state fingerprint binds the state-carried copy.
	return JsonCoerceScript._valid_sha256(action_digest) \
		and action_digest == SequenceRuntimeScript.base_interaction_action_authority_digest(base_interactions) \
		and int(environment.get("scenario_semantic_inventory_version", 0)) == int(sealed_inventory.get("schema_version", 0)) \
		and str(environment.get("scenario_semantic_digest", "")) == str(sealed_inventory.get("digest", "")) \
		and JSON.stringify(trusted_semantic.get("base_interactions", [])) == JSON.stringify(base_interactions) \
		and JSON.stringify(trusted_semantic.get("event_choices", {})) == JSON.stringify(event_choices_value)


static func sequence_command(environment: Dictionary, definition: Dictionary, command: Dictionary, context: Dictionary = {}) -> Dictionary:
	definition = sequence_definition_for_environment(environment, definition)
	# Sequence transactions replace top-level environment fields with freshly
	# normalized state/projection/layout values. A shallow envelope is therefore
	# the exact isolation boundary we need; cloning every immutable room asset and
	# content record here made a single authored command scale with room size.
	var candidate := environment.duplicate(false)
	var state := ensure_sequence_state(candidate, definition)
	if state.is_empty():
		return {"ok": false, "errors": ["No dynamic room sequence is active."]}
	var quarantine := _node_binding_quarantine_result(state)
	if not quarantine.is_empty():
		return _commit_sequence_candidate(environment, candidate, definition, quarantine)
	var dispatched := ScenarioExtensionDispatchScript.prepare_command(definition, command, context)
	if not bool(dispatched.get("ok", false)):
		return {"ok": false, "errors": JsonCoerceScript._copy_array(dispatched.get("errors", [])), "state": state}
	var result := SequenceRuntimeScript.apply_command(state, definition, JsonCoerceScript._copy_dict(dispatched.get("command", command)), JsonCoerceScript._copy_dict(dispatched.get("context", context)), true)
	return _commit_sequence_candidate(environment, candidate, definition, result)


static func enqueue_sequence_fact(environment: Dictionary, definition: Dictionary, fact: Dictionary) -> Dictionary:
	definition = sequence_definition_for_environment(environment, definition)
	var candidate := environment.duplicate(false)
	var state := ensure_sequence_state(candidate, definition)
	if state.is_empty():
		return {"ok": false, "errors": ["No dynamic room sequence is active."]}
	var quarantine := _node_binding_quarantine_result(state)
	if not quarantine.is_empty():
		return _commit_sequence_candidate(environment, candidate, definition, quarantine)
	var result := SequenceRuntimeScript.enqueue_fact(state, definition, fact, true)
	return _commit_sequence_candidate(environment, candidate, definition, result)


static func _node_binding_quarantine_result(state: Dictionary) -> Dictionary:
	var binding_error := "scenario progressed sequence state is bound to another world node; explicit migration is required"
	if str(state.get("status", "")) != SequenceRuntimeScript.STATUS_CLEANED or not JsonCoerceScript._copy_array(state.get("errors", [])).has(binding_error):
		return {}
	return {"ok": false, "quarantine_kind": "node_binding", "errors": JsonCoerceScript._copy_array(state.get("errors", [])), "state": state.duplicate(true)}


static func flush_sequence_facts(environment: Dictionary, definition: Dictionary, boundary_serial: int) -> Dictionary:
	var prepared := prepare_sequence_fact_flush(environment, definition, boundary_serial)
	return _commit_sequence_candidate(environment, prepared["candidate"], prepared["definition"], prepared["result"])


# One synchronous, detached preparation. The identity receipt is computed from
# this invocation's authenticated inputs; it is never read from saved state.
static func prepare_sequence_fact_flush(environment: Dictionary, definition: Dictionary, boundary_serial: int) -> Dictionary:
	definition = sequence_definition_for_environment(environment, definition)
	var candidate := environment.duplicate(false)
	var prior_state: Variant = environment.get("scenario_sequence_state")
	var state := ensure_sequence_state(candidate, definition)
	if state.is_empty():
		return {"candidate": candidate, "definition": definition, "result": {"ok": false, "errors": ["No dynamic room sequence is active."]}, "unchanged_state": false}
	var result := SequenceRuntimeScript.flush_facts(state, definition, boundary_serial, true)
	return {"candidate": candidate, "definition": definition, "result": result,
		"unchanged_state": bool(result.get("ok", false)) and is_same(state, prior_state) and is_same(result.get("state"), state)}


static func unchanged_sequence_flush_result(environment: Dictionary, prepared: Dictionary) -> Dictionary:
	if not bool(prepared.get("unchanged_state", false)):
		return {}
	var candidate: Dictionary = prepared["candidate"]
	var state: Dictionary = prepared["result"]["state"]
	var definition: Dictionary = prepared["definition"]
	var audit := JsonCoerceScript._copy_dict(candidate.get("scenario_layout_audit", {}))
	var renderer := JsonCoerceScript._copy_dict(candidate.get("scenario_render_snapshot", {}))
	var digest := str(candidate.get("scenario_layout_authority_digest", ""))
	var authority := JsonCoerceScript._copy_dict(candidate.get("scenario_layout_authority", {}))
	if not bool(audit.get("valid", false)) \
			or not JsonCoerceScript._valid_sha256(digest) or str(audit.get("authority_digest", "")) != digest \
			or not bool(renderer.get("ok", false)) or str(renderer.get("layout_authority_digest", "")) != digest:
		return {}
	var projection := SequenceRuntimeScript.public_projection(state, definition, true)
	if projection.is_empty() or typeof(candidate.get("scenario_layout_base_records")) != TYPE_ARRAY \
			or typeof(candidate.get("scenario_layout_context", {})) != TYPE_DICTIONARY \
			or str(candidate.get(TRUSTED_LAYOUT_INPUT_DIGEST_KEY, "")) != _sequence_layout_input_digest(candidate, projection):
		return {}
	var stored_projection := JsonCoerceScript._copy_dict(candidate.get("scenario_sequence_projection", {}))
	if bool(audit.get("active", true)):
		# Same authenticated input digest and the same sealed-renderer validation
		# as _commit_reused_sequence_layout; no geometry/readiness bypass.
		projection["semantic_state"] = JsonCoerceScript._copy_dict(stored_projection.get("semantic_state", {}))
		var verified_renderer := ScenarioLayoutResolverScript.sealed_renderer_snapshot({"ok": true,
			"projection": projection, "layout_authority": authority,
			"layout_authority_digest": digest, "layout_audit": audit, "warnings": []})
		if not bool(verified_renderer.get("ok", false)) or verified_renderer != renderer:
			return {}
	else:
		if not bool(audit.get("sealed_passive", false)) or not authority.is_empty() \
				or not bool(renderer.get("sealed_passive", false)) or str(renderer.get("presentation_mode", "")) != "passive":
			return {}
		var semantic := JsonCoerceScript._copy_dict(projection.get("semantic_state", {}))
		semantic["layout_authority_digest"] = digest
		projection["semantic_state"] = semantic
	if projection != candidate.get("scenario_sequence_projection", {}):
		return {}
	# Detect materialized-catalog/baseline mutations instead of trusting the
	# projection alone. Any normalization/replacement takes the regular commit.
	_materialize_sequence_services_games_routes(candidate, projection)
	if candidate != environment:
		return {}
	return {"ok": true, "unchanged": true, "processed": [], "errors": [],
		"state": state.duplicate(true), "projection": projection,
		"layout_authority": authority, "layout_authority_digest": digest,
		"layout_audit": audit, "renderer_snapshot": renderer, "warnings": []}


static func sequence_projection(environment: Dictionary, definition: Dictionary = {}) -> Dictionary:
	if _sequence_is_suppressed(environment, definition):
		_clear_environment_sequence(environment)
		return {}
	definition = sequence_definition_for_environment(environment, definition)
	if not SequenceSchemaScript.is_sequence(definition): return {}
	var host_semantics := sequence_host_semantics(environment)
	if not JsonCoerceScript._copy_array(host_semantics.get("inventory_errors", [])).is_empty(): return {}
	var state := SequenceRuntimeScript.normalize_state(environment.get("scenario_sequence_state", {}), definition, host_semantics)
	return SequenceRuntimeScript.public_projection(state, definition) if not state.is_empty() else {}


static func sequence_reentry(environment: Dictionary, definition: Dictionary, visit_id: String) -> Dictionary:
	definition = sequence_definition_for_environment(environment, definition)
	var candidate := environment.duplicate(false)
	var state := ensure_sequence_state(candidate, definition)
	if state.is_empty():
		return {"ok": false, "inactive": true, "errors": []}
	# ensure_sequence_state already proved that the state-carried semantics match
	# the live host. Re-entry can therefore use its exact sealed fallback without
	# rebuilding a second full host inventory.
	var result := SequenceRuntimeScript.apply_reentry(state, definition, visit_id, {}, true)
	return _commit_sequence_candidate(environment, candidate, definition, result)


static func sequence_expiry(environment: Dictionary, definition: Dictionary, boundary: String, boundary_serial: int) -> Dictionary:
	definition = sequence_definition_for_environment(environment, definition)
	var candidate := environment.duplicate(false)
	var state := ensure_sequence_state(candidate, definition)
	if state.is_empty():
		return {"ok": false, "inactive": true, "errors": []}
	var result := SequenceRuntimeScript.apply_expiry(state, definition, boundary, boundary_serial, true)
	return _commit_sequence_candidate(environment, candidate, definition, result)


static func drain_sequence_transitions(environment: Dictionary, definition: Dictionary, reduced_motion: bool = false) -> Dictionary:
	if _sequence_is_suppressed(environment, definition):
		_clear_environment_sequence(environment)
		return {"ok": false, "inactive": true, "transitions": [], "errors": []}
	definition = sequence_definition_for_environment(environment, definition)
	var stored_state := JsonCoerceScript._copy_dict(environment.get("scenario_sequence_state", {}))
	var stored_semantic := JsonCoerceScript._copy_dict(stored_state.get("semantic_state", {}))
	if JsonCoerceScript._copy_array(stored_semantic.get("transition_queue", [])).is_empty():
		return {"ok": true, "state": stored_state, "transitions": [], "errors": []}
	var state := SequenceRuntimeScript.normalize_state(stored_state, definition)
	if state.is_empty():
		return {"ok": false, "inactive": true, "transitions": [], "errors": []}
	var result := SequenceRuntimeScript.drain_transitions(state, definition, reduced_motion, true)
	return _commit_sequence_drain(environment, definition, result)


static func drain_sequence_event_requests(environment: Dictionary, definition: Dictionary) -> Dictionary:
	if _sequence_is_suppressed(environment, definition):
		_clear_environment_sequence(environment)
		return {"ok": false, "inactive": true, "requests": [], "errors": []}
	definition = sequence_definition_for_environment(environment, definition)
	var stored_state := JsonCoerceScript._copy_dict(environment.get("scenario_sequence_state", {}))
	if JsonCoerceScript._copy_array(stored_state.get("event_request_queue", [])).is_empty():
		return {"ok": true, "state": stored_state, "requests": [], "errors": []}
	var state := SequenceRuntimeScript.normalize_state(stored_state, definition)
	if state.is_empty():
		return {"ok": false, "inactive": true, "requests": [], "errors": []}
	var result := SequenceRuntimeScript.drain_event_requests(state, definition, true)
	return _commit_sequence_drain(environment, definition, result)


# Draining a presentation transition or event-request envelope cannot mutate
# scene objects, actors, interactions, services, games, routes, objectives, or
# phase authority. Commit only the causal queues/receipts and refresh the three
# public drain fields; rerunning the full layout resolver here made every room
# action validate identical geometry two additional times on the main thread.
static func _commit_sequence_drain(environment: Dictionary, definition: Dictionary, result_value: Dictionary) -> Dictionary:
	var result := result_value.duplicate(true)
	if not bool(result.get("ok", false)):
		return result
	var next := JsonCoerceScript._copy_dict(result.get("state", {}))
	var current_projection := JsonCoerceScript._copy_dict(environment.get("scenario_sequence_projection", {}))
	var render_snapshot := JsonCoerceScript._copy_dict(environment.get("scenario_render_snapshot", {}))
	if next.is_empty() or current_projection.is_empty() or render_snapshot.is_empty():
		return _sequence_candidate_failure(environment, result, ["Scenario drain requires committed projection and renderer authority."])
	var fresh_projection := SequenceRuntimeScript.public_projection(next, definition)
	if fresh_projection.is_empty():
		return _sequence_candidate_failure(environment, result, ["Scenario drain produced no public projection."])
	for stable_key in ["scenario_id", "node_id", "phase_id", "status", "boundary_serial", "objectives", "local_state", "resolved_outcomes", "last_feedback"]:
		if JSON.stringify(current_projection.get(stable_key)) != JSON.stringify(fresh_projection.get(stable_key)):
			return _sequence_candidate_failure(environment, result, ["Scenario drain attempted to mutate non-drain projection authority: %s." % stable_key])
	for drain_key in ["pending_transition_count", "active_stages", "pending_event_request_count"]:
		current_projection[drain_key] = fresh_projection.get(drain_key)
	render_snapshot["active_stages"] = JsonCoerceScript._copy_array(fresh_projection.get("active_stages", []))
	environment["scenario_sequence_state"] = next
	environment[TRUSTED_STATE_REFERENCE_KEY] = SequenceRuntimeScript.content_fingerprint(next)
	environment["scenario_sequence_projection"] = current_projection
	environment["scenario_render_snapshot"] = render_snapshot
	result["state"] = next.duplicate(true)
	result["projection"] = current_projection.duplicate(true)
	result["layout_authority"] = JsonCoerceScript._copy_dict(environment.get("scenario_layout_authority", {}))
	result["layout_authority_digest"] = str(environment.get("scenario_layout_authority_digest", ""))
	result["layout_audit"] = JsonCoerceScript._copy_dict(environment.get("scenario_layout_audit", {}))
	result["renderer_snapshot"] = render_snapshot.duplicate(true)
	result["warnings"] = []
	return result


static func refresh_sequence_snapshots(environment: Dictionary, definition: Dictionary = {}) -> Dictionary:
	if _sequence_is_suppressed(environment, definition):
		_clear_environment_sequence(environment)
		return {}
	definition = sequence_definition_for_environment(environment, definition)
	return _refresh_sequence_snapshots(environment, definition)


static func suppress_sequence_definition(definition: Dictionary) -> Dictionary:
	var result := _without_sequence_overlay(definition)
	result[SEQUENCE_SUPPRESSION_KEY] = true
	return result


static func _sequence_is_suppressed(environment: Dictionary, preferred: Dictionary = {}) -> bool:
	return bool(JsonCoerceScript._copy_dict(environment.get("scenario_state", {})).get(SEQUENCE_SUPPRESSION_KEY, false)) or bool(preferred.get(SEQUENCE_SUPPRESSION_KEY, false))


static func _clear_environment_sequence(environment: Dictionary) -> void:
	# A world-only owner shares the sealed host layout, but is not the primary
	# environment sequence being cleared. Its causal proof must survive restore.
	var retain_world_layout := false
	var world_instances: Variant = environment.get("world_sequence_instances", {})
	if not environment.has("scenario_sequence_state") and typeof(world_instances) == TYPE_DICTIONARY:
		for entry in (world_instances as Dictionary).values():
			if typeof(entry) == TYPE_DICTIONARY and str(entry.get("lifecycle", "")) in ["active", "cleanup_pending", "cleaned"]:
				retain_world_layout = true
				break
	var baseline_arrays := {
		"scenario_sequence_base_game_ids": "game_ids",
		"scenario_sequence_base_service_ids": "service_ids",
		"scenario_sequence_base_travel_hooks": "travel_hooks",
	}
	for baseline_key_value in baseline_arrays.keys():
		var baseline_key := str(baseline_key_value)
		if environment.has(baseline_key):
			environment[str(baseline_arrays.get(baseline_key_value, ""))] = JsonCoerceScript._copy_array(environment.get(baseline_key, []))
	if environment.has("scenario_sequence_base_game_modifiers"):
		environment["scenario_game_modifiers"] = JsonCoerceScript._copy_dict(environment.get("scenario_sequence_base_game_modifiers", {}))
	for key in [
		"scenario_sequence_state", "scenario_sequence_projection", "scenario_render_snapshot",
		"scenario_sequence_migration", "scenario_sequence_definition",
		"scenario_sequence_base_game_ids", "scenario_sequence_base_service_ids",
		"scenario_sequence_base_travel_hooks", "scenario_sequence_base_game_modifiers",
		"scenario_sequence_base_layout_object_rects",
		"scenario_layout_base_records", "scenario_layout_context", "scenario_layout_authority",
		"scenario_layout_audit", "scenario_layout_authority_digest",
	]:
		if retain_world_layout and key in ["scenario_layout_base_records", "scenario_layout_authority", "scenario_layout_authority_digest"]:
			continue
		environment.erase(key)
	environment.erase(TRUSTED_STATE_REFERENCE_KEY)
	environment.erase(TRUSTED_LAYOUT_INPUT_DIGEST_KEY)


static func _refresh_sequence_snapshots(environment: Dictionary, definition: Dictionary) -> Dictionary:
	var state := SequenceRuntimeScript.normalize_state(environment.get("scenario_sequence_state", {}), definition)
	if state.is_empty():
		return {"ok": false, "errors": ["Scenario snapshot refresh requires normalized state."]}
	var candidate := environment.duplicate(false)
	var committed := _commit_sequence_candidate(environment, candidate, definition, {"ok": true, "state": state, "errors": []})
	if not bool(committed.get("ok", false)):
		return {"ok": false, "errors": JsonCoerceScript._copy_array(committed.get("errors", []))}
	return JsonCoerceScript._copy_dict(environment.get("scenario_render_snapshot", {}))


static func _commit_sequence_candidate(environment: Dictionary, candidate_value: Dictionary, definition: Dictionary, result_value: Dictionary) -> Dictionary:
	var result := result_value.duplicate(false)
	if not bool(result.get("ok", false)):
		return result
	var candidate := candidate_value.duplicate(false)
	var next := (result.get("state", {}) as Dictionary).duplicate(false) if typeof(result.get("state", {})) == TYPE_DICTIONARY else {}
	if next.is_empty():
		return _sequence_candidate_failure(environment, result, ["Scenario operation produced no authoritative next state."])
	candidate["scenario_sequence_state"] = next
	candidate[TRUSTED_STATE_REFERENCE_KEY] = SequenceRuntimeScript.content_fingerprint(next)
	var projection := SequenceRuntimeScript.public_projection(next, definition, true)
	if projection.is_empty():
		return _sequence_candidate_failure(environment, result, ["Scenario operation produced no public projection."])
	if not bool(candidate.get("scenario_semantic_ready", false)):
		return _sequence_candidate_failure(environment, result, ["Scenario post-operation layout requires finalized semantic records."])
	if typeof(candidate.get("scenario_layout_base_records")) != TYPE_ARRAY or typeof(candidate.get("scenario_layout_context", {})) != TYPE_DICTIONARY:
		return _sequence_candidate_failure(environment, result, ["Scenario post-operation layout authority inputs are missing."])
	var passive_commit := _commit_passive_sequence_candidate(environment, candidate, next, projection, result)
	if not passive_commit.is_empty():
		return passive_commit
	var layout_input_digest := _sequence_layout_input_digest(candidate, projection)
	var reused_commit := _commit_reused_sequence_layout(environment, candidate, next, projection, result, layout_input_digest)
	if not reused_commit.is_empty():
		return reused_commit
	var layout_environment := candidate.duplicate(false)
	var layout_context := JsonCoerceScript._copy_dict(candidate.get("scenario_layout_context", {}))
	if not layout_context.is_empty():
		layout_environment["_scenario_layout_context"] = layout_context
	var layout_result := ScenarioLayoutResolverScript.resolve(JsonCoerceScript._copy_array(candidate.get("scenario_layout_base_records", [])), projection, layout_environment)
	if not bool(layout_result.get("ok", false)):
		return _sequence_candidate_failure(environment, result, JsonCoerceScript._copy_array(layout_result.get("errors", ["Scenario post-operation layout validation failed closed."])))
	var sealed_projection := JsonCoerceScript._copy_dict(layout_result.get("projection", {}))
	var renderer_snapshot := ScenarioLayoutResolverScript.sealed_renderer_snapshot(layout_result)
	if not bool(renderer_snapshot.get("ok", false)):
		return _sequence_candidate_failure(environment, result, JsonCoerceScript._copy_array(renderer_snapshot.get("errors", ["Scenario post-operation renderer validation failed closed."])))
	var authority_digest := str(layout_result.get("layout_authority_digest", ""))
	if authority_digest.is_empty() or str(renderer_snapshot.get("layout_authority_digest", "")) != authority_digest:
		return _sequence_candidate_failure(environment, result, ["Scenario post-operation renderer authority diverged from sealed layout geometry."])
	candidate["scenario_sequence_projection"] = sealed_projection
	candidate["scenario_layout_authority"] = JsonCoerceScript._copy_dict(layout_result.get("layout_authority", {}))
	candidate["scenario_layout_audit"] = JsonCoerceScript._copy_dict(layout_result.get("layout_audit", {}))
	candidate["scenario_layout_authority_digest"] = authority_digest
	candidate["scenario_render_snapshot"] = renderer_snapshot
	candidate[TRUSTED_LAYOUT_INPUT_DIGEST_KEY] = layout_input_digest
	_materialize_sequence_services_games_routes(candidate, sealed_projection)
	environment.clear()
	environment.merge(candidate, true)
	result["state"] = next.duplicate(true)
	result["projection"] = sealed_projection.duplicate(true)
	result["layout_authority"] = JsonCoerceScript._copy_dict(layout_result.get("layout_authority", {}))
	result["layout_authority_digest"] = authority_digest
	result["layout_audit"] = JsonCoerceScript._copy_dict(layout_result.get("layout_audit", {}))
	result["renderer_snapshot"] = renderer_snapshot.duplicate(true)
	result["warnings"] = JsonCoerceScript._copy_array(layout_result.get("warnings", []))
	return result


static func _sequence_layout_input_digest(candidate: Dictionary, projection: Dictionary) -> String:
	# This receipt binds every input consumed by ScenarioLayoutResolver.resolve().
	# It permits exact reuse only for presentation-neutral operations such as a
	# visit receipt or aftermath re-entry; any semantic, room, or viewport change
	# necessarily changes the digest and takes the full resolver path.
	return SequenceRuntimeScript.content_fingerprint({
		"scenario_id": str(projection.get("scenario_id", "")),
		"phase_id": str(projection.get("phase_id", "")),
		"status": str(projection.get("status", "")),
		"semantic_state": projection.get("semantic_state", {}),
		"active_stages": projection.get("active_stages", []),
		"base_records": candidate.get("scenario_layout_base_records", []),
		"resolved_event_ids": candidate.get("resolved_event_ids", []),
		"layout_context": candidate.get("scenario_layout_context", {}),
	})


static func _commit_reused_sequence_layout(environment: Dictionary, candidate: Dictionary, next: Dictionary, projection: Dictionary, result_value: Dictionary, input_digest: String) -> Dictionary:
	var stored_input_value: Variant = candidate.get(TRUSTED_LAYOUT_INPUT_DIGEST_KEY, "")
	if typeof(stored_input_value) != TYPE_STRING \
		or not JsonCoerceScript._valid_sha256(str(stored_input_value)) \
		or str(stored_input_value) != input_digest:
		return {}
	var stored_projection := JsonCoerceScript._copy_dict(candidate.get("scenario_sequence_projection", {}))
	var authority := JsonCoerceScript._copy_dict(candidate.get("scenario_layout_authority", {}))
	var audit := JsonCoerceScript._copy_dict(candidate.get("scenario_layout_audit", {}))
	var authority_digest := str(candidate.get("scenario_layout_authority_digest", ""))
	if stored_projection.is_empty() or not bool(audit.get("active", false)) or not bool(audit.get("valid", false)) \
		or not JsonCoerceScript._valid_sha256(authority_digest) \
		or str(audit.get("authority_digest", "")) != authority_digest:
		return {}
	var sealed_projection := projection.duplicate(true)
	sealed_projection["semantic_state"] = JsonCoerceScript._copy_dict(stored_projection.get("semantic_state", {}))
	var renderer_snapshot := ScenarioLayoutResolverScript.sealed_renderer_snapshot({
		"ok": true,
		"projection": sealed_projection,
		"layout_authority": authority,
		"layout_authority_digest": authority_digest,
		"layout_audit": audit,
		"warnings": [],
	})
	if not bool(renderer_snapshot.get("ok", false)) or str(renderer_snapshot.get("layout_authority_digest", "")) != authority_digest:
		return {}
	candidate["scenario_sequence_projection"] = sealed_projection
	candidate["scenario_render_snapshot"] = renderer_snapshot
	candidate[TRUSTED_LAYOUT_INPUT_DIGEST_KEY] = input_digest
	_materialize_sequence_services_games_routes(candidate, sealed_projection)
	environment.clear()
	environment.merge(candidate, true)
	var result := result_value.duplicate(false)
	result["state"] = next.duplicate(true)
	result["projection"] = sealed_projection.duplicate(true)
	result["layout_authority"] = authority.duplicate(true)
	result["layout_authority_digest"] = authority_digest
	result["layout_audit"] = audit.duplicate(true)
	result["renderer_snapshot"] = renderer_snapshot.duplicate(true)
	result["warnings"] = []
	return result


static func _commit_passive_sequence_candidate(environment: Dictionary, candidate: Dictionary, next: Dictionary, projection_value: Dictionary, result_value: Dictionary) -> Dictionary:
	var audit := JsonCoerceScript._copy_dict(candidate.get("scenario_layout_audit", {}))
	if bool(audit.get("active", true)):
		return {}
	var renderer := JsonCoerceScript._copy_dict(candidate.get("scenario_render_snapshot", {}))
	var authority := JsonCoerceScript._copy_dict(candidate.get("scenario_layout_authority", {}))
	var authority_digest := str(candidate.get("scenario_layout_authority_digest", ""))
	if not bool(audit.get("valid", false)) \
		or not bool(audit.get("sealed_passive", false)) \
		or not authority.is_empty() \
		or not JsonCoerceScript._valid_sha256(authority_digest) \
		or str(audit.get("authority_digest", "")) != authority_digest \
		or not bool(renderer.get("ok", false)) \
		or not bool(renderer.get("sealed_passive", false)) \
		or str(renderer.get("presentation_mode", "")) != "passive" \
		or str(renderer.get("layout_authority_digest", "")) != authority_digest:
		return _sequence_candidate_failure(environment, result_value, ["Scenario passive post-operation commit requires an exact sealed passive layout authority."])
	var projection := projection_value.duplicate(true)
	var semantic := JsonCoerceScript._copy_dict(projection.get("semantic_state", {}))
	semantic["layout_authority_digest"] = authority_digest
	projection["semantic_state"] = semantic
	candidate["scenario_sequence_projection"] = projection
	candidate[TRUSTED_LAYOUT_INPUT_DIGEST_KEY] = _sequence_layout_input_digest(candidate, projection_value)
	_materialize_sequence_services_games_routes(candidate, projection)
	environment.clear()
	environment.merge(candidate, true)
	var result := result_value.duplicate(true)
	result["state"] = next.duplicate(true)
	result["projection"] = projection.duplicate(true)
	result["layout_authority"] = {}
	result["layout_authority_digest"] = authority_digest
	result["layout_audit"] = audit.duplicate(true)
	result["renderer_snapshot"] = renderer.duplicate(true)
	result["warnings"] = []
	return result


static func _sequence_candidate_failure(environment: Dictionary, result_value: Dictionary, errors_value: Array) -> Dictionary:
	var result := result_value.duplicate(true)
	var errors: Array = []
	for value in errors_value:
		var message := str(value).strip_edges()
		if not message.is_empty() and not errors.has(message):
			errors.append(message)
	if errors.is_empty():
		errors.append("Scenario post-operation candidate failed closed.")
	result["ok"] = false
	result["errors"] = errors
	result["state"] = JsonCoerceScript._copy_dict(environment.get("scenario_sequence_state", {}))
	for collection_key in ["processed", "requests", "transitions"]:
		if result.has(collection_key):
			result[collection_key] = []
	if result.has("cost"):
		result["cost"] = 0
	if result.has("applied"):
		result["applied"] = false
	return result


static func _capture_sequence_baseline(environment: Dictionary) -> void:
	if not environment.has("scenario_sequence_base_game_ids"):
		environment["scenario_sequence_base_game_ids"] = JsonCoerceScript._unique_string_array(environment.get("game_ids", []))
	if not environment.has("scenario_sequence_base_service_ids"):
		environment["scenario_sequence_base_service_ids"] = JsonCoerceScript._unique_string_array(environment.get("service_ids", []))
	if not environment.has("scenario_sequence_base_travel_hooks"):
		environment["scenario_sequence_base_travel_hooks"] = JsonCoerceScript._unique_string_array(environment.get("travel_hooks", []))
	if not environment.has("scenario_sequence_base_game_modifiers"):
		environment["scenario_sequence_base_game_modifiers"] = JsonCoerceScript._copy_dict(environment.get("scenario_game_modifiers", {}))
	if not environment.has("scenario_sequence_base_layout_object_rects"):
		# Runtime-owned occupants can already be present when a room sequence starts.
		# They are not immutable room authority, so never capture their geometry in
		# the baseline that survives after the occupant moves away.
		environment["scenario_sequence_base_layout_object_rects"] = EnvironmentSemanticInventoryScript._base_layout_object_rects(environment)


static func _materialize_sequence_services_games_routes(environment: Dictionary, projection: Dictionary) -> void:
	_capture_sequence_baseline(environment)
	var semantic := JsonCoerceScript._copy_dict(projection.get("semantic_state", {}))
	var services := JsonCoerceScript._unique_string_array(environment.get("scenario_sequence_base_service_ids", []))
	for value in JsonCoerceScript._copy_dict(semantic.get("services", {})).values():
		var record := JsonCoerceScript._copy_dict(value)
		var service_id := str(record.get("id", record.get("stable_object_id", ""))).strip_edges()
		if service_id.is_empty(): continue
		if bool(record.get("enabled", true)):
			if not services.has(service_id): services.append(service_id)
		else:
			services.erase(service_id)
	environment["service_ids"] = services
	var games := JsonCoerceScript._unique_string_array(environment.get("scenario_sequence_base_game_ids", []))
	var modifiers := JsonCoerceScript._copy_dict(environment.get("scenario_sequence_base_game_modifiers", {}))
	for value in JsonCoerceScript._copy_dict(semantic.get("games", {})).values():
		var record := JsonCoerceScript._copy_dict(value)
		var game_id := str(record.get("id", record.get("stable_object_id", ""))).strip_edges()
		if game_id.is_empty(): continue
		if bool(record.get("enabled", true)):
			if not games.has(game_id): games.append(game_id)
		else:
			games.erase(game_id)
		var modifier := JsonCoerceScript._copy_dict(record.get("modifier", {}))
		if not modifier.is_empty(): modifiers[game_id] = modifier
	environment["game_ids"] = games
	environment["scenario_game_modifiers"] = modifiers
	var routes := JsonCoerceScript._unique_string_array(environment.get("scenario_sequence_base_travel_hooks", []))
	for value in JsonCoerceScript._copy_dict(semantic.get("routes", {})).values():
		var record := JsonCoerceScript._copy_dict(value)
		var route_id := str(record.get("stable_object_id", "")).strip_edges()
		var source_id := str(record.get("source_id", route_id.trim_prefix("world:"))).strip_edges()
		if not route_id.is_empty(): routes.erase(route_id)
		if not source_id.is_empty(): routes.erase(source_id)
		if bool(record.get("enabled", true)) and not source_id.is_empty() and not routes.has(source_id): routes.append(source_id)
	environment["travel_hooks"] = routes


static func validate_sequence_definition(definition: Dictionary, references: Dictionary = {}, target_inventory: Dictionary = {}) -> Array:
	var errors := SequenceSchemaScript.validate_definition(definition, OperationRegistryScript, target_inventory)
	if not SequenceSchemaScript.is_sequence(definition):
		return errors
	var scenario_id := str(definition.get("id", ""))
	if definition.has("sequence_package_id"):
		errors.append_array(ScenarioExtensionDispatchScript.validate_package_extensions(
			str(definition.get("sequence_package_id", "")),
			str(definition.get("sequence_handler_pack", "")),
			str(definition.get("sequence_renderer_id", ""))
		))
	var archetype_id := str(definition.get("archetype_id", ""))
	if not JsonCoerceScript._copy_dict(references.get("archetype_ids", {})).has(archetype_id):
		errors.append("scenario %s sequence references unknown archetype %s." % [scenario_id, archetype_id])
	var authoring := JsonCoerceScript._copy_dict(definition.get("sequence_authoring", {}))
	if str(authoring.get("arrival_summary", "")).strip_edges().is_empty() or JsonCoerceScript._unique_string_array(authoring.get("player_verbs", [])).is_empty() or JsonCoerceScript._unique_string_array(authoring.get("world_connections", [])).is_empty():
		errors.append("scenario %s sequence authoring requires arrival_summary, player_verbs, and world_connections." % scenario_id)
	if JsonCoerceScript._unique_string_array(authoring.get("capture_ids", [])).is_empty() or JsonCoerceScript._copy_dict(authoring.get("seed_evidence", {})).is_empty():
		errors.append("scenario %s sequence authoring requires capture_ids and seed_evidence." % scenario_id)
	var scenario_local_actor_ids := _valid_scenario_local_actor_ids(definition)
	_validate_sequence_references(scenario_id, authoring, references, scenario_local_actor_ids, errors)
	var archetype := JsonCoerceScript._copy_dict(references.get("archetype", {}))
	for operation_value in _sequence_operations(definition):
		var operation := JsonCoerceScript._copy_dict(operation_value)
		var owner := str(operation.get("owner_namespace", ""))
		var identity := OperationRegistryScript.identity(owner, str(operation.get("stable_object_id", "")))
		if owner != "scenario" and not JsonCoerceScript._unique_string_array(JsonCoerceScript._copy_dict(authoring.get("references", {})).get("objects", [])).has(identity):
			errors.append("scenario %s sequence operation %s mutates unreferenced host identity %s." % [scenario_id, str(operation.get("receipt_id", "")), identity])
		for anchor_key in ["anchor_id", "zone_id"]:
			var anchor := str(operation.get(anchor_key, "")).strip_edges()
			if anchor.is_empty():
				var payload := JsonCoerceScript._copy_dict(operation.get("object", operation.get("actor", {})))
				anchor = str(payload.get(anchor_key, "")).strip_edges()
			if not anchor.is_empty() and not _sequence_anchor_exists(archetype, anchor_key, anchor):
				errors.append("scenario %s sequence references unknown %s %s." % [scenario_id, anchor_key, anchor])
		if str(operation.get("family", "")) == "actor_ops" and str(operation.get("op", "")) == "spawn":
			var actor_id := str(JsonCoerceScript._copy_dict(operation.get("actor", {})).get("actor_id", "")).strip_edges()
			var local_identity := OperationRegistryScript.identity(str(operation.get("owner_namespace", "")).strip_edges(), str(operation.get("stable_object_id", "")).strip_edges())
			if not JsonCoerceScript._copy_dict(references.get("actor_ids", {})).has(actor_id) and str(scenario_local_actor_ids.get(local_identity, "")) != actor_id:
				errors.append("scenario %s sequence references unknown actor %s." % [scenario_id, actor_id])
	if errors.is_empty():
		var layout_environment := {
			"id": "validation_%s" % scenario_id,
			"archetype_id": archetype_id,
			"world_node_id": "validation_%s" % scenario_id,
			"layout": JsonCoerceScript._copy_dict(archetype.get("layout", {})),
			"semantic_zones": JsonCoerceScript._copy_dict(archetype.get("semantic_zones", {})),
			"semantic_anchors": JsonCoerceScript._copy_dict(archetype.get("semantic_anchors", {})),
			"scenario_semantic_inventory": JsonCoerceScript._copy_dict(references.get("scenario_semantic_inventory", {})),
			"travel_hooks": JsonCoerceScript._copy_array(archetype.get("travel_hooks", [])),
			"next_archetypes": JsonCoerceScript._copy_array(archetype.get("next_archetypes", [])),
		}
		var initial := SequenceRuntimeScript.initial_state(definition, str(layout_environment.get("world_node_id", "")), "content_validation", {
			"target_inventory": target_inventory,
			"event_choices": JsonCoerceScript._copy_dict(target_inventory.get("event_choices", {})),
		})
		var prepared := ScenarioExtensionDispatchScript.prepare_render(definition, layout_environment, SequenceRuntimeScript.public_projection(initial, definition))
		if not bool(prepared.get("ok", false)):
			for layout_error_value in JsonCoerceScript._copy_array(prepared.get("errors", [])):
				errors.append("scenario %s layout: %s" % [scenario_id, str(layout_error_value)])
	return errors


static func sequence_catalog_audit(definitions: Array, expected_count: int, masked_visual_explanations: Dictionary = {}, target_inventories: Dictionary = {}) -> Dictionary:
	return SequenceSchemaScript.catalog_uniqueness_report(definitions, expected_count, OperationRegistryScript, masked_visual_explanations, target_inventories)


# Validates each definition through the full Engine path and consumes the
# resulting receipts inside this call. Callers cannot request a bypass or
# provide validation authority. Any incomplete or stale receipt set takes the
# unchanged public Schema audit path.
static func validate_sequence_catalog_and_audit(definitions: Array, validation_references: Array, expected_count: int, masked_visual_explanations: Dictionary = {}, target_inventories: Dictionary = {}) -> Dictionary:
	var validation_errors: Array = []
	var validation_receipts: Array = []
	var registry_context_fingerprint := _sequence_validation_registry_context_fingerprint()
	for definition_index in range(definitions.size()):
		var definition := JsonCoerceScript._copy_dict(definitions[definition_index])
		var references := JsonCoerceScript._copy_dict(validation_references[definition_index]) if definition_index < validation_references.size() else {}
		var scenario_id := str(definition.get("id", "")).strip_edges()
		var target_inventory := JsonCoerceScript._copy_dict(target_inventories.get(scenario_id, {}))
		var definition_fingerprint_before := SequenceRuntimeScript.content_fingerprint(definition)
		var target_inventory_fingerprint_before := SequenceRuntimeScript.content_fingerprint(target_inventory)
		var definition_errors := validate_sequence_definition(definition, references, target_inventory)
		var definition_fingerprint_after := SequenceRuntimeScript.content_fingerprint(definition)
		var target_inventory_fingerprint_after := SequenceRuntimeScript.content_fingerprint(target_inventory)
		validation_errors.append_array(definition_errors)
		if definition_errors.is_empty() and definition_fingerprint_before == definition_fingerprint_after and target_inventory_fingerprint_before == target_inventory_fingerprint_after:
			# Receipt creation is deliberately adjacent to the successful full
			# validation; no mutable or cross-instance state exists between them.
			validation_receipts.append(_sequence_validation_receipt(definition, target_inventory, registry_context_fingerprint, definition_fingerprint_after, target_inventory_fingerprint_after))
	var reuse_validations := _sequence_validation_receipts_match(definitions, expected_count, target_inventories, validation_receipts, registry_context_fingerprint)
	validation_receipts.clear() # One-shot authority is consumed in this call.
	var audit := SequenceSchemaScript._catalog_uniqueness_report_after_same_call_validation(definitions, expected_count, OperationRegistryScript, masked_visual_explanations, target_inventories) if reuse_validations else SequenceSchemaScript.catalog_uniqueness_report(definitions, expected_count, OperationRegistryScript, masked_visual_explanations, target_inventories)
	return {"validation_errors": validation_errors, "audit": audit}


static func _sequence_validation_registry_context_fingerprint() -> String:
	return SequenceRuntimeScript.content_fingerprint({
		"registry": "res://scripts/core/scenario_operation_registry.gd",
		"operation_families": OperationRegistryScript.registered_operations(),
		"handlers": OperationRegistryScript.registered_handlers(),
		"max_operations_per_batch": OperationRegistryScript.MAX_OPERATIONS_PER_BATCH,
		"max_actions_per_interaction": OperationRegistryScript.MAX_ACTIONS_PER_INTERACTION,
		"max_variant_depth": OperationRegistryScript.MAX_VARIANT_DEPTH,
		"max_variant_values": OperationRegistryScript.MAX_VARIANT_VALUES,
		"max_variant_text": OperationRegistryScript.MAX_VARIANT_TEXT,
		"max_variant_collection": OperationRegistryScript.MAX_VARIANT_COLLECTION,
	})


static func _sequence_validation_receipt(definition: Dictionary, target_inventory: Dictionary, registry_context_fingerprint: String, definition_fingerprint: String = "", target_inventory_fingerprint: String = "") -> Dictionary:
	var authority := {
		"scenario_id": str(definition.get("id", "")).strip_edges(),
		"definition_fingerprint": definition_fingerprint if not definition_fingerprint.is_empty() else SequenceRuntimeScript.content_fingerprint(definition),
		"target_inventory_fingerprint": target_inventory_fingerprint if not target_inventory_fingerprint.is_empty() else SequenceRuntimeScript.content_fingerprint(target_inventory),
		"registry_context_fingerprint": registry_context_fingerprint,
	}
	var receipt := authority.duplicate(true)
	receipt["receipt_fingerprint"] = SequenceRuntimeScript.content_fingerprint(authority)
	return receipt


static func _sequence_validation_receipts_match(definitions: Array, expected_count: int, target_inventories: Dictionary, receipts: Array, registry_context_fingerprint: String) -> bool:
	if expected_count != SequenceRolloutManifestScript.EXPECTED_COUNT or definitions.size() != expected_count or receipts.size() != expected_count:
		return false
	var seen_ids: Dictionary = {}
	var actual_ids: Array = []
	for definition_index in range(definitions.size()):
		var definition := JsonCoerceScript._copy_dict(definitions[definition_index])
		var scenario_id := str(definition.get("id", "")).strip_edges()
		if scenario_id.is_empty() or seen_ids.has(scenario_id) or definition_index >= receipts.size():
			return false
		seen_ids[scenario_id] = true
		actual_ids.append(scenario_id)
		var expected_receipt := _sequence_validation_receipt(definition, JsonCoerceScript._copy_dict(target_inventories.get(scenario_id, {})), registry_context_fingerprint)
		var actual_receipt := JsonCoerceScript._copy_dict(receipts[definition_index])
		if str(actual_receipt.get("scenario_id", "")) != str(expected_receipt.get("scenario_id", "")) \
				or str(actual_receipt.get("definition_fingerprint", "")) != str(expected_receipt.get("definition_fingerprint", "")) \
				or str(actual_receipt.get("target_inventory_fingerprint", "")) != str(expected_receipt.get("target_inventory_fingerprint", "")) \
				or str(actual_receipt.get("registry_context_fingerprint", "")) != str(expected_receipt.get("registry_context_fingerprint", "")) \
				or str(actual_receipt.get("receipt_fingerprint", "")) != str(expected_receipt.get("receipt_fingerprint", "")):
			return false
	actual_ids.sort()
	return actual_ids == SequenceRolloutManifestScript.expected_ids()


static func _without_sequence_overlay(definition: Dictionary) -> Dictionary:
	var result := definition.duplicate(true)
	for key in ["sequence", "sequence_package_id", "sequence_handler_pack", "sequence_renderer_id", "sequence_authoring", VALIDATED_SEQUENCE_MARKER, RESOLVED_SEQUENCE_CATALOG_MARKER]:
		result.erase(key)
	return result


static func _validate_sequence_references(scenario_id: String, authoring: Dictionary, references: Dictionary, scenario_local_actor_ids: Dictionary, errors: Array) -> void:
	var authored_refs := JsonCoerceScript._copy_dict(authoring.get("references", {}))
	var known := {
		"events": "event_ids", "games": "game_ids", "services": "service_ids",
		"items": "item_ids", "actors": "actor_ids",
	}
	for key_value in authored_refs.keys():
		var key := str(key_value)
		if key == "objects":
			for identity_value in JsonCoerceScript._unique_string_array(authored_refs.get(key, [])):
				var identity := str(identity_value)
				var parts := identity.split("::", false)
				if parts.size() != 2 or not OperationRegistryScript.OWNER_NAMESPACES.has(str(parts[0])):
					errors.append("scenario %s sequence references invalid object identity %s." % [scenario_id, identity])
			continue
		if not known.has(key):
			errors.append("scenario %s sequence authoring references unknown registry %s." % [scenario_id, key])
			continue
		var valid := JsonCoerceScript._copy_dict(references.get(str(known.get(key, "")), {}))
		for id_value in JsonCoerceScript._unique_string_array(authored_refs.get(key, [])):
			var reference_id := str(id_value)
			if not valid.has(reference_id) and not (key == "actors" and scenario_local_actor_ids.values().has(reference_id)):
				errors.append("scenario %s sequence references unknown %s id %s." % [scenario_id, key, str(id_value)])


static func _sequence_operations(definition: Dictionary) -> Array:
	var result: Array = []
	var authored := SequenceSchemaScript.sequence(definition)
	for phase_value in JsonCoerceScript._copy_array(JsonCoerceScript._copy_dict(authored.get("phase_graph", {})).get("phases", [])):
		var phase := JsonCoerceScript._copy_dict(phase_value)
		for family in ["scene_ops", "interaction_ops", "actor_ops", "transition_ops"]:
			result.append_array(JsonCoerceScript._copy_array(phase.get(family, [])))
	result.append_array(JsonCoerceScript._copy_array(JsonCoerceScript._copy_dict(authored.get("cleanup", {})).get("operations", [])))
	for aftermath_value in JsonCoerceScript._copy_dict(authored.get("aftermath", {})).values():
		var aftermath := JsonCoerceScript._copy_dict(aftermath_value)
		for family in ["scene_ops", "interaction_ops", "actor_ops", "service_ops", "game_ops", "route_ops"]:
			result.append_array(JsonCoerceScript._copy_array(aftermath.get(family, [])))
	return result


static func _valid_scenario_local_actor_ids(definition: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	for operation_value in _sequence_operations(definition):
		var operation := JsonCoerceScript._copy_dict(operation_value)
		if str(operation.get("family", "")) != "actor_ops" or str(operation.get("op", "")) != "spawn":
			continue
		if str(operation.get("owner_namespace", "")).strip_edges() != "scenario":
			continue
		if str(operation.get("stable_object_id", "")).strip_edges().is_empty():
			continue
		var actor := JsonCoerceScript._copy_dict(operation.get("actor", {}))
		var actor_id := str(actor.get("actor_id", "")).strip_edges()
		if actor_id.is_empty() or str(actor.get("label", "")).strip_edges().is_empty():
			continue
		if str(actor.get("anchor_id", "")).strip_edges().is_empty() and str(actor.get("zone_id", "")).strip_edges().is_empty():
			continue
		result[OperationRegistryScript.identity("scenario", str(operation.get("stable_object_id", "")).strip_edges())] = actor_id
	return result


static func _sequence_anchor_exists(archetype: Dictionary, anchor_kind: String, anchor: String) -> bool:
	if anchor_kind == "zone_id":
		if JsonCoerceScript._copy_dict(archetype.get("semantic_zones", {})).has(anchor):
			return true
		return anchor in ["left", "right", "center", "foreground", "background", "exit_lane", "service_lane"]
	if JsonCoerceScript._copy_dict(archetype.get("semantic_anchors", {})).has(anchor):
		return true
	var parts := anchor.split(":", false)
	if parts.size() != 3 or str(parts[0]) != "layout" or not str(parts[2]).is_valid_int():
		return false
	var field: String = str({
		"game": "game_spots", "event": "event_spots", "item": "item_spots",
		"service": "service_spots", "lender": "lender_spots", "travel": "travel_spots",
		"shopkeeper": "shopkeeper_spots", "game_hook": "game_hook_spots",
	}.get(str(parts[1]), ""))
	if field.is_empty():
		return false
	return int(parts[2]) >= 0 and int(parts[2]) < JsonCoerceScript._copy_array(JsonCoerceScript._copy_dict(archetype.get("layout", {})).get(field, [])).size()


static func _sequence_state_can_bind_initial_node(state: Dictionary, environment: Dictionary, definition: Dictionary = {}, host_semantics: Dictionary = {}) -> bool:
	var original := str(state.get("node_id", "")).strip_edges()
	var archetype_id := str(environment.get("archetype_id", "")).strip_edges()
	if original.is_empty() or original != archetype_id or not SequenceSchemaScript.is_sequence(definition): return false
	var expected := SequenceRuntimeScript.initial_state(definition, original, str(state.get("seed_token", "")), host_semantics)
	return not expected.is_empty() and SequenceRuntimeScript.content_fingerprint(state) == SequenceRuntimeScript.content_fingerprint(expected)


static func advance_environment(environment: Dictionary, amount: int) -> bool:
	if amount <= 0:
		return false
	var state := normalize_state(environment.get("scenario_state", {}))
	if state.is_empty():
		return false
	var phases := JsonCoerceScript._copy_array(state.get("phases", []))
	if phases.is_empty():
		return false
	var changed := false
	var applies_here := _state_targets_layer(state, environment)
	var remaining := amount
	while remaining > 0:
		var phase_index := mini(maxi(0, int(state.get("phase_index", 0))), phases.size() - 1)
		var phase: Dictionary = phases[phase_index] if typeof(phases[phase_index]) == TYPE_DICTIONARY else {}
		var threshold := maxi(0, int(phase.get("advance_after_actions", 0)))
		if threshold <= 0 or phase_index >= phases.size() - 1:
			state["phase_action_counter"] = maxi(0, int(state.get("phase_action_counter", 0))) + remaining
			remaining = 0
			continue
		var counter := maxi(0, int(state.get("phase_action_counter", 0)))
		var consumed := mini(remaining, maxi(1, threshold - counter))
		counter += consumed
		remaining -= consumed
		if counter < threshold:
			state["phase_action_counter"] = counter
			continue
		phase_index += 1
		state["phase_index"] = phase_index
		state["phase_action_counter"] = 0
		var next_phase: Dictionary = phases[phase_index] if typeof(phases[phase_index]) == TYPE_DICTIONARY else {}
		if applies_here:
			_apply_mutations(environment, JsonCoerceScript._copy_dict(next_phase.get("mutations", {})), false)
			environment["scenario_applied_phase_index"] = phase_index
			_apply_exclusive_opportunity(environment)
		changed = true
	environment["scenario_state"] = state
	environment["scenario_id"] = str(state.get("id", ""))
	environment["scenario_phase_index"] = int(state.get("phase_index", 0))
	environment["scenario_phase_action_counter"] = int(state.get("phase_action_counter", 0))
	return changed


# Synchronizes a stored layer with the authoritative node scenario cursor.
static func reconcile_environment(environment: Dictionary, state_value: Variant) -> void:
	var state := normalize_state(state_value)
	if state.is_empty():
		return
	environment["scenario_state"] = state
	environment["scenario_id"] = str(state.get("id", ""))
	environment["scenario_phase_index"] = int(state.get("phase_index", 0))
	environment["scenario_phase_action_counter"] = int(state.get("phase_action_counter", 0))
	if not _state_targets_layer(state, environment):
		return
	var phases := JsonCoerceScript._copy_array(state.get("phases", []))
	var applied_index := int(environment.get("scenario_applied_phase_index", -1))
	var target_index := mini(maxi(0, int(state.get("phase_index", 0))), phases.size() - 1) if not phases.is_empty() else -1
	for index in range(applied_index + 1, target_index + 1):
		if index >= 0 and index < phases.size() and typeof(phases[index]) == TYPE_DICTIONARY:
			_apply_mutations(environment, JsonCoerceScript._copy_dict((phases[index] as Dictionary).get("mutations", {})), false)
	environment["scenario_applied_phase_index"] = target_index
	_apply_exclusive_opportunity(environment)


static func public_snapshot(state_value: Variant) -> Dictionary:
	var state := normalize_state(state_value)
	if state.is_empty():
		return {}
	return {
		"id": str(state.get("id", "")),
		"archetype_id": str(state.get("archetype_id", "")),
		"layer_id": str(state.get("layer_id", "")),
		"display_name": str(state.get("display_name", "")),
		"phase_index": int(state.get("phase_index", 0)),
		"phase_action_counter": int(state.get("phase_action_counter", 0)),
	}


static func _state_targets_layer(state: Dictionary, target: Dictionary) -> bool:
	var wanted := str(state.get("layer_id", "")).strip_edges()
	if wanted.is_empty():
		return true
	return str(target.get("current_layer_id", "")).strip_edges() == wanted


static func _apply_mutations(target: Dictionary, mutations: Dictionary, generation: bool) -> void:
	if mutations.is_empty():
		return
	if mutations.has("patron_set"):
		target["scenario_patron_ids"] = JsonCoerceScript._unique_string_array(mutations.get("patron_set", []))
	if mutations.has("staff_set"):
		target["scenario_staff_ids"] = JsonCoerceScript._unique_string_array(mutations.get("staff_set", []))
	_apply_id_delta(target, "event_pool" if generation else "event_ids", mutations.get("event_pool_add", []), mutations.get("event_pool_remove", []))
	_apply_id_delta(target, "travel_hooks", mutations.get("travel_hooks_add", []), [])
	_apply_id_delta(target, "service_pool" if generation else "service_ids", mutations.get("service_add", []), mutations.get("service_remove", []))
	_apply_item_offer_delta(target, "scenario_item_offers" if generation else "item_offers", mutations.get("item_offer_add", []), mutations.get("item_offer_remove", []))
	if mutations.has("economic_profile_overrides"):
		target["economic_profile"] = _deep_merge(JsonCoerceScript._copy_dict(target.get("economic_profile", {})), JsonCoerceScript._copy_dict(mutations.get("economic_profile_overrides", {})))
	if mutations.has("game_modifier_hooks"):
		target["scenario_game_modifiers"] = _deep_merge(JsonCoerceScript._copy_dict(target.get("scenario_game_modifiers", {})), JsonCoerceScript._copy_dict(mutations.get("game_modifier_hooks", {})))
	if mutations.has("music_profile_override"):
		target["music_profile"] = _deep_merge(JsonCoerceScript._copy_dict(target.get("music_profile", {})), JsonCoerceScript._copy_dict(mutations.get("music_profile_override", {})))
	if mutations.has("presentation"):
		var presentation := _deep_merge(JsonCoerceScript._copy_dict(target.get("scenario_presentation", {})), JsonCoerceScript._copy_dict(mutations.get("presentation", {})))
		target["scenario_presentation"] = presentation
		target["visual_context"] = _deep_merge(JsonCoerceScript._copy_dict(target.get("visual_context", {})), presentation)
	if mutations.has("exclusive_opportunity"):
		target["scenario_exclusive_opportunity"] = JsonCoerceScript._copy_dict(mutations.get("exclusive_opportunity", {}))
	if mutations.has("security_overrides"):
		target["security_profile"] = _deep_merge(JsonCoerceScript._copy_dict(target.get("security_profile", {})), JsonCoerceScript._copy_dict(mutations.get("security_overrides", {})))
	if mutations.has("hook_flags"):
		target["scenario_hook_flags"] = _deep_merge(JsonCoerceScript._copy_dict(target.get("scenario_hook_flags", {})), JsonCoerceScript._copy_dict(mutations.get("hook_flags", {})))
	if mutations.has("travel_lock_actions"):
		var lock_actions := maxi(0, int(mutations.get("travel_lock_actions", 0)))
		target["travel_locked_actions"] = lock_actions
		if not generation:
			target["travel_lock_remaining"] = lock_actions


static func _apply_exclusive_opportunity(environment: Dictionary) -> void:
	var opportunity := JsonCoerceScript._copy_dict(environment.get("scenario_exclusive_opportunity", {}))
	var event_id := str(opportunity.get("event_id", "")).strip_edges()
	if not event_id.is_empty():
		_apply_id_delta(environment, "event_ids", [event_id], [])
	var game_id := str(opportunity.get("game_id", "")).strip_edges()
	if not game_id.is_empty():
		_apply_id_delta(environment, "game_ids", [game_id], [])


static func _apply_id_delta(target: Dictionary, key: String, additions_value: Variant, removals_value: Variant) -> void:
	var values := JsonCoerceScript._unique_string_array(target.get(key, []))
	for remove_id in JsonCoerceScript._unique_string_array(removals_value):
		while values.has(remove_id):
			values.erase(remove_id)
	for add_id in JsonCoerceScript._unique_string_array(additions_value):
		if not values.has(add_id):
			values.append(add_id)
	target[key] = values


static func _apply_item_offer_delta(target: Dictionary, key: String, additions_value: Variant, removals_value: Variant) -> void:
	var offers := JsonCoerceScript._copy_array(target.get(key, []))
	var remove_ids := JsonCoerceScript._unique_string_array(removals_value)
	for index in range(offers.size() - 1, -1, -1):
		if typeof(offers[index]) == TYPE_DICTIONARY and remove_ids.has(str((offers[index] as Dictionary).get("id", ""))):
			offers.remove_at(index)
	for offer_value in JsonCoerceScript._copy_array(additions_value):
		if typeof(offer_value) != TYPE_DICTIONARY:
			continue
		var offer := (offer_value as Dictionary).duplicate(true)
		var item_id := str(offer.get("id", "")).strip_edges()
		if item_id.is_empty():
			continue
		for index in range(offers.size() - 1, -1, -1):
			if typeof(offers[index]) == TYPE_DICTIONARY and str((offers[index] as Dictionary).get("id", "")) == item_id:
				offers.remove_at(index)
		offers.append(offer)
	target[key] = offers


static func _deep_merge(base: Dictionary, overlay: Dictionary) -> Dictionary:
	var result := base.duplicate(true)
	for key_value in overlay.keys():
		var value: Variant = overlay.get(key_value)
		if typeof(value) == TYPE_DICTIONARY and typeof(result.get(key_value)) == TYPE_DICTIONARY:
			result[key_value] = _deep_merge(result.get(key_value, {}) as Dictionary, value as Dictionary)
		elif typeof(value) == TYPE_DICTIONARY:
			result[key_value] = (value as Dictionary).duplicate(true)
		elif typeof(value) == TYPE_ARRAY:
			result[key_value] = (value as Array).duplicate(true)
		else:
			result[key_value] = value
	return result
