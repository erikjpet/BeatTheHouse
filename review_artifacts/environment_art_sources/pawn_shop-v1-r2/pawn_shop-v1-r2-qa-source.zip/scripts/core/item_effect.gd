class_name ItemEffect
extends RefCounted

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")

# Base contract for data-backed item effects.

const DIRECT_DELTA_KEYS := [
	"bankroll_delta",
	"suspicion_delta",
	"alcohol_intake",
	"drunk_delta",
	"pending_drunk_absorption_delta",
	"drunk_distortion_suppression_turns",
	"alcoholic_delta",
	"baseline_luck_delta",
	"debt_changes",
	"inventory_add",
	"inventory_remove",
	"flags_set",
	"travel_hooks_add",
	"travel_changes",
	"story_log",
	"messages",
	"ended",
	"item_hooks",
	"event_hooks",
]

const EFFECT_METADATA_KEYS := [
	"families",
	"synergies",
]

var definition: Dictionary = {}


# Stores the item definition used by this effect.
func setup(p_definition: Dictionary) -> void:
	definition = p_definition.duplicate(true)


# Returns this item effect id.
func get_id() -> String:
	return str(definition.get("id", ""))


# Returns the item class from README itemization.
func get_item_class() -> String:
	return str(definition.get("class", ""))


# Returns the effect domain.
func get_domain() -> String:
	return str(definition.get("domain", "global"))


# Returns a copy of the effect payload.
func effect_data() -> Dictionary:
	return JsonCoerceScript._copy_dict(definition.get("effect", {}))


# Checks whether the effect applies to the supplied context.
func applies(context: Dictionary) -> bool:
	var domain := get_domain()
	if domain == "global":
		return true
	var context_domain := str(context.get("domain", ""))
	if context_domain == domain:
		return true
	var domains := JsonCoerceScript._raw_string_array(context.get("domains", []))
	if domains.has(domain):
		return true
	if domain == "games" and (context_domain == "game" or domains.has("game")):
		return true
	if domain == "security" and (context_domain == "suspicion" or domains.has("suspicion") or str(context.get("action_kind", "")) == "cheat"):
		return true
	return false


# Returns modifiers that affect the supplied domain context.
func modifiers_for(context: Dictionary) -> Dictionary:
	if not applies(context):
		return {}
	var effect := effect_data()
	var modifiers: Dictionary = {}
	_merge_modifier_source(modifiers, effect)
	var family := str(context.get("game_family", context.get("family", "")))
	var families := JsonCoerceScript._copy_dict(effect.get("families", {}))
	if not family.is_empty() and families.has(family):
		_merge_modifier_source(modifiers, JsonCoerceScript._copy_dict(families.get(family, {})))
	var action_kind := str(context.get("action_kind", ""))
	if action_kind == "legal":
		_merge_prefixed_modifiers(modifiers, effect, "legal_")
	elif action_kind == "cheat":
		_merge_prefixed_modifiers(modifiers, effect, "cheat_")
	return modifiers


# Adds effect data to the supplied context and optionally applies direct deltas.
func apply(context: Dictionary, run_state: RunState = null) -> Dictionary:
	var applied := applies(context)
	var modifiers := modifiers_for(context) if applied else {}
	var deltas := _result_deltas(context, modifiers, applied)
	var result: Dictionary = context.duplicate(true)
	result["item_effect_id"] = get_id()
	result["item_id"] = get_id()
	result["item_class"] = get_item_class()
	result["domain"] = get_domain()
	result["applied"] = applied
	result["ok"] = applied
	result["type"] = "item_effect"
	result["source_id"] = get_id()
	result["action_id"] = str(context.get("action_id", ""))
	result["action_kind"] = str(context.get("action_kind", ""))
	result["environment_id"] = str(context.get("environment_id", ""))
	result["effect"] = effect_data() if applied else {}
	result["modifiers"] = modifiers
	result["deltas"] = deltas
	result["message"] = ""
	result["messages"] = JsonCoerceScript._copy_array(deltas.get("messages", []))
	result["ended"] = bool(deltas.get("ended", false))
	result["state"] = GameModule.RESULT_ENDED if bool(result["ended"]) else GameModule.RESULT_CONTINUE
	if run_state != null:
		GameModule.apply_result(run_state, result)
	return result


# Builds shared result deltas from direct effect keys and passive modifiers.
func _result_deltas(context: Dictionary, modifiers: Dictionary, applied: bool) -> Dictionary:
	var deltas := GameModule.empty_result_deltas()
	if not applied:
		return deltas
	var effect := effect_data()
	deltas["bankroll_delta"] = int(effect.get("bankroll_delta", 0))
	deltas["suspicion_delta"] = int(effect.get("suspicion_delta", 0))
	deltas["alcohol_intake"] = int(effect.get("alcohol_intake", 0))
	deltas["drunk_delta"] = int(effect.get("drunk_delta", 0))
	deltas["pending_drunk_absorption_delta"] = int(effect.get("pending_drunk_absorption_delta", 0))
	deltas["drunk_distortion_suppression_turns"] = int(effect.get("drunk_distortion_suppression_turns", 0))
	deltas["alcoholic_delta"] = int(effect.get("alcoholic_delta", 0))
	deltas["baseline_luck_delta"] = int(effect.get("baseline_luck_delta", 0))
	deltas["debt_changes"] = JsonCoerceScript._copy_array(effect.get("debt_changes", []))
	deltas["inventory_add"] = JsonCoerceScript._copy_array(effect.get("inventory_add", []))
	deltas["inventory_remove"] = JsonCoerceScript._copy_array(effect.get("inventory_remove", []))
	deltas["flags_set"] = JsonCoerceScript._copy_dict(effect.get("flags_set", {}))
	deltas["travel_hooks_add"] = JsonCoerceScript._copy_array(effect.get("travel_hooks_add", []))
	deltas["travel_changes"] = JsonCoerceScript._copy_dict(effect.get("travel_changes", {}))
	deltas["story_log"] = JsonCoerceScript._copy_array(effect.get("story_log", []))
	deltas["messages"] = JsonCoerceScript._copy_array(effect.get("messages", []))
	deltas["ended"] = bool(effect.get("ended", false))
	deltas["event_hooks"] = JsonCoerceScript._copy_array(effect.get("event_hooks", []))
	if not modifiers.is_empty():
		deltas["item_hooks"] = [{
			"item_id": get_id(),
			"item_class": get_item_class(),
			"domain": get_domain(),
			"context_domain": str(context.get("domain", "")),
			"game_family": str(context.get("game_family", context.get("family", ""))),
			"action_kind": str(context.get("action_kind", "")),
			"modifiers": modifiers.duplicate(true),
		}]
	else:
		deltas["item_hooks"] = JsonCoerceScript._copy_array(effect.get("item_hooks", []))
	return deltas


# Adds non-delta effect keys as passive modifiers.
func _merge_modifier_source(target: Dictionary, source: Dictionary) -> void:
	for key in source.keys():
		var key_text := str(key)
		if DIRECT_DELTA_KEYS.has(key_text) or EFFECT_METADATA_KEYS.has(key_text) or _is_action_prefixed_key(key_text):
			continue
		_merge_modifier_value(target, key_text, source[key])


# Adds action-kind modifiers in their base form, such as legal_win_chance -> win_chance.
func _merge_prefixed_modifiers(target: Dictionary, source: Dictionary, prefix: String) -> void:
	for key in source.keys():
		var key_text := str(key)
		if not key_text.begins_with(prefix):
			continue
		var base_key := key_text.substr(prefix.length())
		if base_key.is_empty():
			continue
		_merge_modifier_value(target, base_key, source[key])


# Keeps legal_/cheat_ effects scoped to their matching action context.
func _is_action_prefixed_key(key: String) -> bool:
	return key.begins_with("legal_") or key.begins_with("cheat_")


# Merges numeric modifiers additively and copies structured modifiers.
func _merge_modifier_value(target: Dictionary, key: String, value: Variant) -> void:
	var value_type := typeof(value)
	if value_type == TYPE_INT or value_type == TYPE_FLOAT:
		var existing: Variant = target.get(key, 0)
		target[key] = existing + value if _modifier_type_family(existing) == "number" else value
	elif value_type == TYPE_DICTIONARY:
		target[key] = JsonCoerceScript._copy_dict(value)
	elif value_type == TYPE_ARRAY:
		target[key] = JsonCoerceScript._copy_array(value)
	else:
		target[key] = value


static func modifier_type_conflicts(effect: Dictionary) -> Array:
	var conflicts: Array = []
	var seen: Dictionary = {}
	var families := JsonCoerceScript._copy_dict(effect.get("families", {}))
	var family_ids: Array = [""] + families.keys()
	for family_id_value in family_ids:
		var family_id := str(family_id_value)
		for action_kind in ["", "legal", "cheat"]:
			var types: Dictionary = {}
			_collect_modifier_types(effect, "", types, conflicts, seen, family_id, action_kind)
			if not family_id.is_empty():
				_collect_modifier_types(JsonCoerceScript._copy_dict(families.get(family_id, {})), "", types, conflicts, seen, family_id, action_kind)
			if not action_kind.is_empty():
				_collect_modifier_types(effect, "%s_" % action_kind, types, conflicts, seen, family_id, action_kind)
	return conflicts


static func _collect_modifier_types(source: Dictionary, prefix: String, types: Dictionary, conflicts: Array, seen: Dictionary, family_id: String, action_kind: String) -> void:
	for key_value in source.keys():
		var source_key := str(key_value)
		if prefix.is_empty():
			if DIRECT_DELTA_KEYS.has(source_key) or EFFECT_METADATA_KEYS.has(source_key) or source_key.begins_with("legal_") or source_key.begins_with("cheat_"):
				continue
		else:
			if not source_key.begins_with(prefix):
				continue
		var modifier_key := source_key if prefix.is_empty() else source_key.trim_prefix(prefix)
		if modifier_key.is_empty():
			continue
		var type_family := _modifier_type_family(source.get(key_value))
		if types.has(modifier_key) and str(types.get(modifier_key)) != type_family:
			var context := "%s/%s" % [family_id if not family_id.is_empty() else "all", action_kind if not action_kind.is_empty() else "all"]
			var signature := "%s:%s" % [context, modifier_key]
			if not seen.has(signature):
				seen[signature] = true
				conflicts.append("%s modifier %s mixes %s and %s" % [context, modifier_key, str(types.get(modifier_key)), type_family])
		else:
			types[modifier_key] = type_family


static func _modifier_type_family(value: Variant) -> String:
	return "number" if typeof(value) in [TYPE_INT, TYPE_FLOAT] else type_string(typeof(value))
