class_name RunGenerator
extends RefCounted

const EnvironmentSlotBinderScript := preload("res://scripts/core/environment_slot_binder.gd")
const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")
const GameModuleRegistryScript := preload("res://scripts/core/game_module_registry.gd")

# Builds and installs deterministic starting/travel environments from content,
# WorldMap state, challenges, scenarios, game fixtures, and placement authority.
# Installation is atomic and exposes explicit rollback/failure evidence.

const GrandCasinoShowdownModelScript := preload("res://scripts/core/grand_casino_showdown_model.gd")
const CrewRecruitmentModelScript := preload("res://scripts/core/crew_recruitment_model.gd")
const ScenarioEngineScript := preload("res://scripts/core/scenario_engine.gd")
const ScenarioSequenceSchemaScript := preload("res://scripts/core/scenario_sequence_schema.gd")
const TutorialFlowScript := preload("res://scripts/core/tutorial_flow.gd")
const ScenarioVenueCycleScript := preload("res://scripts/core/scenario_venue_cycle.gd")
const ENVIRONMENT_SITUATION_NONE_PERCENT := 25
const ENVIRONMENT_SITUATION_CYCLE_KEY := "environment_situation_cycle_id"

var library: ContentLibrary
var _last_environment_install_errors: Array = []
var _last_environment_install_failure: Dictionary = {}
var _world_environment_timing_enabled := false
var _last_world_environment_timing_usec: Dictionary = {}
var _last_preview_environment_timing_usec: Dictionary = {}
var _world_environment_build_stages_usec: Dictionary = {}
var _world_environment_install_stages_usec: Dictionary = {}
var _world_scenario_prime_stages_usec: Dictionary = {}
var _world_scenario_select_stages_usec: Dictionary = {}
var _caller_owns_result_rollback := false


func set_world_environment_timing_enabled(enabled: bool) -> void:
	_world_environment_timing_enabled = enabled
	if not enabled:
		_last_world_environment_timing_usec = {}


func world_environment_timing_snapshot() -> Dictionary:
	return _last_world_environment_timing_usec.duplicate(true)


func preview_environment_timing_snapshot() -> Dictionary:
	return _last_preview_environment_timing_usec.duplicate(true)


# Exposes only the deterministic identity needed by the run-start recovery
# boundary. The failed environment itself can contain large machine state and
# must not be retained after rollback.
func environment_install_failure_snapshot() -> Dictionary:
	return _last_environment_install_failure.duplicate(true)


func cache_game_module_script(module_path: String, module_script: Script) -> void:
	GameModuleRegistryScript.cache_script(module_path, module_script)


# Stores the content library used for generation.
func _init(p_library: ContentLibrary) -> void:
	library = p_library


func _install_environment(run_state: RunState, environment_data: Dictionary) -> Dictionary:
	return _install_environment_with_rollback(run_state, environment_data, _travel_rollback_snapshot(run_state))


# Generates an environment-practice room through the production world-room
# pipeline. The caller owns the practice RunState, allowing UI code to replace
# sessions without touching a real run, save slot, or world map.
func environment_test_result(run_state: RunState, request: Dictionary) -> Dictionary:
	if run_state == null or library == null:
		return {"ok": false, "errors": ["Environment practice requires a run state and content library."]}
	var archetype_id := str(request.get("archetype_id", "")).strip_edges()
	var archetype := _archetype_by_id(archetype_id)
	if archetype.is_empty():
		return {"ok": false, "errors": ["Unknown environment: %s" % archetype_id]}
	var scenario_id := str(request.get("scenario_id", "__default")).strip_edges()
	if not scenario_id in ["__default", "__none"]:
		var definition := library._scenario_readonly(scenario_id)
		if definition.is_empty() or str(definition.get("archetype_id", "")) != archetype_id:
			return {"ok": false, "errors": ["Scenario %s does not belong to %s." % [scenario_id, archetype_id]]}
	var rng := run_state.create_rng("environment_practice:%s" % str(request.get("generation_key", archetype_id)))
	var options := request.duplicate(true)
	options["environment_test"] = true
	var condition_overrides := JsonCoerceScript._copy_dict(options.get("condition_overrides", {}))
	if not condition_overrides.is_empty() and run_state.town_state != null:
		var override_result := run_state.town_state.apply_generation_overrides(condition_overrides)
		if not bool(override_result.get("ok", false)):
			return {"ok": false, "errors": JsonCoerceScript._copy_array(override_result.get("errors", []))}
		options["conditions_prepared"] = true
	# Normal generation configures the living town from a deterministic world
	# graph before selecting/building a room. Practice keeps that exact model
	# setup, but deliberately does not install the graph as a travel map.
	var practice_map := WorldMap.new(library).build(run_state, rng.fork("world_map"))
	if not practice_map.is_empty():
		run_state.configure_town_world(practice_map, false)
	var environment_data := _world_environment_data_for_node(run_state, {}, {"id": archetype_id}, rng, options)
	if environment_data.is_empty():
		return {"ok": false, "errors": ["The selected environment could not be generated."]}
	var installed := _install_environment_with_rollback(run_state, environment_data, _travel_rollback_snapshot(run_state))
	if not bool(installed.get("ok", false)):
		return installed
	var warnings := JsonCoerceScript._copy_array(installed.get("warnings", []))
	var layer_id := str(request.get("layer_id", "")).strip_edges()
	if layer_id.is_empty():
		var installed_scenario_id := str(run_state.current_environment.get("scenario_id", "")).strip_edges()
		var installed_scenario := library._scenario_readonly(installed_scenario_id)
		layer_id = str(installed_scenario.get("layer_id", "")).strip_edges()
	if not layer_id.is_empty() and run_state.is_layered_environment() and layer_id != str(run_state.current_environment.get("current_layer_id", "")):
		var layer_result := _install_environment_test_layer(run_state, layer_id)
		if not bool(layer_result.get("ok", false)):
			return {"ok": false, "errors": [str(layer_result.get("message", "The selected starting area could not be entered."))]}
		warnings = JsonCoerceScript._copy_array(layer_result.get("warnings", []))
	if not warnings.is_empty():
		run_state.current_environment["environment_test_layout_warnings"] = warnings.duplicate(true)
	else:
		run_state.current_environment.erase("environment_test_layout_warnings")
	return {"ok": true, "errors": [], "warnings": warnings, "environment": run_state.current_environment.duplicate(true)}


func _install_environment_test_layer(run_state: RunState, layer_id: String) -> Dictionary:
	var target_id := layer_id.strip_edges()
	var layer_state := run_state.environment_layer_state(target_id)
	if layer_state.is_empty():
		return {"ok": false, "message": "Unknown starting area: %s" % target_id}
	run_state.discover_environment_layer(target_id, "environment_practice")
	run_state.apply_town_generation_modifiers(layer_state)
	var game_rng := run_state.create_rng("environment_practice_layer_games:%s" % target_id)
	layer_state["game_states"] = _generated_game_states(run_state, layer_state, game_rng)
	var archetype_id := str(layer_state.get("archetype_id", run_state.current_environment.get("archetype_id", "")))
	layer_state["next_archetypes"] = [archetype_id]
	layer_state["travel_hooks"] = [archetype_id]
	layer_state["world_map_travel"] = false
	_stamp_environment_test_exit(layer_state)
	layer_state["layout"] = EnvironmentInstance.ensure_generated_layout(layer_state, library)
	if not run_state.install_environment_layer_state(target_id, layer_state, library):
		return {"ok": false, "message": "The selected starting area could not be installed."}
	# Practice uses the same authenticated Crew-owner boundary as ordinary
	# layer entry. Never mutate selected event inputs behind an installed seal.
	var crew_membership := _prepare_layer_crew_membership(run_state)
	if not bool(crew_membership.get("ok", false)):
		var membership_errors := JsonCoerceScript._copy_array(crew_membership.get("errors", []))
		return {"ok": false, "message": str(membership_errors[0]) if not membership_errors.is_empty() else "The starting area's Crew presence could not be prepared safely."}
	var finalized := run_state.scenario_finalize_installed_environment(library)
	if not bool(finalized.get("ok", false)):
		var errors := JsonCoerceScript._copy_array(finalized.get("errors", []))
		return {"ok": false, "message": str(errors[0]) if not errors.is_empty() else "The selected starting area could not be finalized."}
	# Scenario projection can replace flat actor/event arrays during finalization.
	var final_membership := _prepare_layer_crew_membership(run_state)
	if not bool(final_membership.get("ok", false)):
		var final_errors := JsonCoerceScript._copy_array(final_membership.get("errors", []))
		return {"ok": false, "message": str(final_errors[0]) if not final_errors.is_empty() else "The starting area's final Crew presence could not be prepared safely."}
	var publication := run_state.publish_room_presentation()
	if not bool(publication.get("ok", false)):
		var publication_errors := JsonCoerceScript._copy_array(publication.get("errors", []))
		return {"ok": false, "message": str(publication_errors[0]) if not publication_errors.is_empty() else "The selected starting area could not be published safely."}
	return {"ok": true, "layer_id": target_id, "warnings": JsonCoerceScript._copy_array(finalized.get("warnings", []))}


# Travel callers already hold the exact atomic rollback snapshot. Reuse it so
# large visited-room machines are not copied a second time at every transition.
func _install_environment_with_rollback(run_state: RunState, environment_data: Dictionary, rollback: Dictionary, restore_on_failure: bool = true) -> Dictionary:
	var perf_stage_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
	_world_environment_install_stages_usec = {}
	var trusted := _trusted_scenario_install_data(run_state, environment_data)
	if _world_environment_timing_enabled:
		_world_environment_install_stages_usec["trusted_data"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	if not bool(trusted.get("ok", false)):
		if restore_on_failure:
			_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "applied": false, "errors": JsonCoerceScript._copy_array(trusted.get("errors", []))}
	var trusted_definition_value: Variant = trusted.get("scenario_definition", {})
	if typeof(trusted_definition_value) == TYPE_DICTIONARY:
		# Keep validation/catalog receipts in RunState's process-local cache. The
		# living-world seed intentionally remains persistent authored data only.
		run_state.cache_runtime_scenario_definition(trusted_definition_value as Dictionary)
	var install_data: Dictionary = JsonCoerceScript._copy_dict(trusted.get("environment", {}))
	if _world_environment_timing_enabled:
		_world_environment_install_stages_usec["trusted_copy"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var state_timing := {"enabled": true} if _world_environment_timing_enabled else {}
	var installed := run_state.set_environment(install_data, state_timing)
	if _world_environment_timing_enabled:
		_world_environment_install_stages_usec["set_environment"] = Time.get_ticks_usec() - perf_stage_started_usec
		_world_environment_install_stages_usec["set_environment_stages"] = state_timing
		perf_stage_started_usec = Time.get_ticks_usec()
	if not bool(installed.get("ok", false)):
		return installed
	var finalized := run_state.scenario_finalize_installed_environment(library)
	if _world_environment_timing_enabled:
		_world_environment_install_stages_usec["scenario_finalize"] = Time.get_ticks_usec() - perf_stage_started_usec
	if not bool(finalized.get("ok", false)):
		if restore_on_failure:
			_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "applied": true, "errors": JsonCoerceScript._copy_array(finalized.get("errors", []))}
	return {
		"ok": true,
		"applied": true,
		"inactive": bool(finalized.get("inactive", false)),
		"warnings": JsonCoerceScript._copy_array(finalized.get("warnings", [])),
		"errors": [],
	}


func _trusted_scenario_install_data(run_state: RunState, environment_data: Dictionary) -> Dictionary:
	if environment_data.is_empty() or str(environment_data.get("id", "")).strip_edges().is_empty() or str(environment_data.get("archetype_id", "")).strip_edges().is_empty():
		return {"ok": false, "environment": {}, "errors": ["Travel destination has no valid room identity."]}
	var install_data := environment_data.duplicate(true)
	# Never trust a caller-carried definition. Production reconstructs it from the
	# selected destination authority immediately before the environment is sealed.
	install_data.erase("scenario_sequence_definition")
	var scenario_id := str(install_data.get("scenario_id", "")).strip_edges()
	if scenario_id.is_empty():
		return {"ok": true, "environment": install_data, "errors": []}
	if library == null or not library.has_method("scenario"):
		return {"ok": false, "environment": {}, "errors": ["Selected scenario %s cannot be resolved without ContentLibrary." % scenario_id]}
	var catalog_definition: Dictionary = library._scenario_readonly(scenario_id)
	var archetype_id := str(install_data.get("archetype_id", "")).strip_edges()
	if catalog_definition.is_empty() or str(catalog_definition.get("id", "")).strip_edges() != scenario_id:
		return {"ok": false, "environment": {}, "errors": ["Selected scenario %s is not an exact catalog definition." % scenario_id]}
	if archetype_id.is_empty() or str(catalog_definition.get("archetype_id", "")).strip_edges() != archetype_id:
		return {"ok": false, "environment": {}, "errors": ["Selected scenario %s does not belong to destination archetype %s." % [scenario_id, archetype_id]]}
	var definition := catalog_definition
	var destination_id := str(install_data.get("world_node_id", archetype_id)).strip_edges()
	var map_seeded_definition: Dictionary = {}
	if run_state != null and run_state.has_world_map():
		var seeded := run_state._seeded_scenario_definition_for_node_readonly(destination_id)
		if seeded.is_empty() or str(seeded.get("id", "")).strip_edges() != scenario_id or str(seeded.get("archetype_id", "")).strip_edges() != archetype_id:
			return {"ok": false, "environment": {}, "errors": ["Selected scenario %s does not match the destination node's seeded definition." % scenario_id]}
		# The node seed proves the chosen identity. Use the library's exact accepted
		# overlay so its runtime package receipt survives installation; the primed
		# seed intentionally carries no receipt before the room is selected.
		definition = seeded if bool(seeded.get("sequence_suppressed", false)) else catalog_definition
		map_seeded_definition = run_state._seeded_scenario_definition_for_node_readonly(destination_id)
		if not bool(definition.get("sequence_suppressed", false)) and bool(catalog_definition.get(ScenarioEngineScript.VALIDATED_SEQUENCE_MARKER, false)):
			map_seeded_definition[ScenarioEngineScript.VALIDATED_SEQUENCE_MARKER] = true
	var trusted_suppression := bool(definition.get("sequence_suppressed", false))
	if ScenarioSequenceSchemaScript.is_sequence(catalog_definition) and not ScenarioSequenceSchemaScript.is_sequence(definition) and not trusted_suppression:
		return {"ok": false, "environment": {}, "errors": ["Selected scenario %s lost its valid destination sequence definition." % scenario_id]}
	# A generated town already retains the exact selected definition in TownState.
	# Do not embed the same large sequence payload into every environment copy.
	if (ScenarioSequenceSchemaScript.is_sequence(definition) or trusted_suppression) and map_seeded_definition.is_empty():
		install_data["scenario_sequence_definition"] = definition.duplicate(true)
	return {"ok": true, "environment": install_data, "scenario_definition": definition, "errors": []}


# Production travel facade. Legacy generation still returns EnvironmentInstance,
# while this closed result lets callers distinguish a rejected departure from an
# arrival at the unchanged source room.
func travel_environment_result_with_caller_rollback(run_state: RunState, target_archetype_id: String, target_prevalidated: bool = false) -> Dictionary:
	var previous_owner := _caller_owns_result_rollback
	_caller_owns_result_rollback = true
	var result := travel_environment_result(run_state, target_archetype_id, target_prevalidated)
	_caller_owns_result_rollback = previous_owner
	return result


func travel_environment_result(run_state: RunState, target_archetype_id: String, target_prevalidated: bool = false) -> Dictionary:
	if run_state == null:
		return {"ok": false, "errors": ["Travel requires an active run."], "environment": {}}
	var caller_owns_rollback := _caller_owns_result_rollback
	var source_id := run_state.current_world_node_id()
	var target_id := target_archetype_id.strip_edges()
	var preflight := run_state.scenario_preflight_environment_change(source_id, target_id, "world")
	if not bool(preflight.get("ok", false)):
		return {"ok": false, "errors": JsonCoerceScript._copy_array(preflight.get("errors", [])), "environment": run_state.current_environment.duplicate(true)}
	var rollback := {} if caller_owns_rollback else _travel_rollback_snapshot(run_state)
	_last_environment_install_errors = []
	# The facade already owns the exact rollback snapshot and has accepted this
	# source/destination scenario boundary. Pass both facts into the private world
	# path instead of copying the entire run and repeating the same preflight.
	if run_state.has_world_map() or run_state.current_environment.is_empty():
		_next_world_environment(run_state, target_id, run_state.create_rng(), target_prevalidated, rollback, true, false)
	else:
		next_environment(run_state, target_id, target_prevalidated)
	var arrived_id := run_state.current_world_node_id()
	if target_id.is_empty() or arrived_id != target_id:
		if not caller_owns_rollback:
			_restore_travel_snapshot(run_state, rollback)
		var errors := _last_environment_install_errors.duplicate(true)
		if errors.is_empty():
			errors = ["Travel destination was not installed."]
		return {"ok": false, "errors": errors, "environment": JsonCoerceScript._copy_dict(rollback.get("environment", run_state.current_environment))}
	# Arrival belongs to the destination phase installed by this transaction.
	# Leaving it queued lets zero-turn room commands advance the sequence before
	# the next event/game flush, which then mistakes this trip for later pressure.
	var arrival := run_state.scenario_flush_facts()
	if not bool(arrival.get("ok", false)) and not bool(arrival.get("inactive", false)):
		if not caller_owns_rollback:
			_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "errors": JsonCoerceScript._copy_array(arrival.get("errors", [])), "environment": JsonCoerceScript._copy_dict(rollback.get("environment", run_state.current_environment))}
	return {
		"ok": true,
		"errors": [],
		"environment": run_state.current_environment.duplicate(true),
		"source_id": source_id,
		"target_id": arrived_id,
		# _install_environment_with_rollback is the authority that seals scenario
		# semantics. Presentation callers can trust this marker and avoid rebuilding
		# the same immutable proof immediately after installation.
		"scenario_finalized": true,
	}


func enter_grand_casino_room_result_with_caller_rollback(run_state: RunState, target_archetype_id: String) -> Dictionary:
	var previous_owner := _caller_owns_result_rollback
	_caller_owns_result_rollback = true
	var result := enter_grand_casino_room_result(run_state, target_archetype_id)
	_caller_owns_result_rollback = previous_owner
	return result


func enter_grand_casino_room_result(run_state: RunState, target_archetype_id: String) -> Dictionary:
	if run_state == null:
		return {"ok": false, "errors": ["Casino room travel requires an active run."]}
	var caller_owns_rollback := _caller_owns_result_rollback
	var source_id := str(run_state.current_environment.get("archetype_id", "")).strip_edges()
	var target_id := target_archetype_id.strip_edges()
	var preflight := run_state.scenario_preflight_environment_change(source_id, target_id, "grand_room") if source_id != target_id else {"ok": true, "inactive": true, "errors": []}
	if not bool(preflight.get("ok", false)):
		return {"ok": false, "errors": JsonCoerceScript._copy_array(preflight.get("errors", []))}
	var rollback := {} if caller_owns_rollback else _travel_rollback_snapshot(run_state)
	if not _enter_grand_casino_room(run_state, target_id, rollback, true, false):
		if not caller_owns_rollback:
			_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "errors": _last_environment_install_errors.duplicate(true)}
	return {"ok": true, "errors": [], "source_id": source_id, "target_id": target_id, "environment": run_state.current_environment.duplicate(true), "scenario_finalized": true}


func _commit_travel_departure(_run_state: RunState, _source_id: String, _target_id: String, _travel_kind: String) -> Dictionary:
	# Departure is not a situation outcome. The source snapshot is retained until
	# its venue closes and a later opening creates a new operating cycle.
	return {"ok": true, "inactive": true, "errors": []}


func _travel_rollback_snapshot(run_state: RunState) -> Dictionary:
	return {
		# Seeded scenario definitions are trusted immutable catalog projections.
		# Own their outer map but share the authored nested payload on the success
		# path; a rare rollback deep-copies it while restoring through from_dict().
		"run": run_state.to_save_snapshot(false),
		"environment": run_state.current_environment.duplicate(true),
		"world_map": run_state.world_map.duplicate(true),
		"room_states": run_state.grand_casino_room_states.duplicate(true),
		"scenario_definition_cache": run_state.scenario_definition_cache_snapshot(),
	}


func _restore_travel_snapshot(run_state: RunState, rollback: Dictionary) -> void:
	run_state.from_dict(JsonCoerceScript._copy_dict(rollback.get("run", {})))
	run_state.current_environment = JsonCoerceScript._copy_dict(rollback.get("environment", {}))
	run_state.world_map = JsonCoerceScript._copy_dict(rollback.get("world_map", {}))
	run_state.grand_casino_room_states = JsonCoerceScript._copy_dict(rollback.get("room_states", {}))
	run_state.restore_scenario_definition_cache(JsonCoerceScript._copy_dict(rollback.get("scenario_definition_cache", {})))


# Builds and assigns the next environment for a run. A prevalidated target is
# reserved for the travel UI after it validates arrival hours, then advances the clock.
func next_environment(run_state: RunState, target_archetype_id: String = "", target_prevalidated: bool = false) -> EnvironmentInstance:
	_last_environment_install_failure = {}
	# An explicit legacy destination is already authoritative at this boundary.
	# Reserve departure plus expiry before RNG creation or room generation so a
	# capacity rejection leaves even a save-loaded RunState byte-identical.
	if not run_state.has_world_map() and not run_state.current_environment.is_empty() and not target_archetype_id.strip_edges().is_empty():
		var legacy_preflight := run_state.scenario_preflight_environment_change(run_state.current_world_node_id(), target_archetype_id.strip_edges(), "legacy")
		if not bool(legacy_preflight.get("ok", false)):
			return EnvironmentInstance.from_dict(run_state.current_environment)
	var rng := run_state.create_rng()
	if run_state.has_world_map() or run_state.current_environment.is_empty():
		return _next_world_environment(run_state, target_archetype_id, rng, target_prevalidated)
	return _legacy_next_environment(run_state, target_archetype_id, rng)


# Builds the next environment from a cloned run so route previews do not mutate state.
func preview_environment(run_state: RunState, target_archetype_id: String = "", target_prevalidated: bool = false) -> Dictionary:
	var perf_total_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
	var perf_stage_started_usec := perf_total_started_usec
	var perf_stages: Dictionary = {}
	if run_state == null:
		return {}
	var stored_preview := _stored_world_environment_preview(run_state, target_archetype_id)
	if not stored_preview.is_empty():
		return stored_preview
	if _world_environment_timing_enabled:
		perf_stages["stored_lookup"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	# Exact scouting reads most run state and mutates only preview-local scenario,
	# rumor, and recent-selection indexes. Fork that narrow graph directly instead
	# of round-tripping the run through its persistence codec on the UI thread.
	# Home initialization intentionally keeps the conservative full candidate.
	var target_archetype := _archetype_by_id(target_archetype_id.strip_edges())
	var preview_state: RunState
	if run_state.has_world_map() and str(target_archetype.get("kind", "")) != "home":
		preview_state = run_state.detached_travel_preview_candidate()
		if _world_environment_timing_enabled:
			perf_stages["candidate"] = Time.get_ticks_usec() - perf_stage_started_usec
			perf_stage_started_usec = Time.get_ticks_usec()
	else:
		preview_state = RunState.new()
		var preview_data := run_state.to_travel_preview_snapshot()
		if _world_environment_timing_enabled:
			perf_stages["snapshot"] = Time.get_ticks_usec() - perf_stage_started_usec
			perf_stage_started_usec = Time.get_ticks_usec()
		preview_state.from_dict(preview_data)
		if _world_environment_timing_enabled:
			perf_stages["restore"] = Time.get_ticks_usec() - perf_stage_started_usec
			perf_stage_started_usec = Time.get_ticks_usec()
	var environment_data: Dictionary
	if preview_state.has_world_map():
		environment_data = _preview_world_environment_data(preview_state, target_archetype_id, target_prevalidated)
	else:
		environment_data = next_environment(preview_state, target_archetype_id).to_dict()
	if _world_environment_timing_enabled:
		perf_stages["generate"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var projection := _travel_preview_environment_projection(environment_data)
	if _world_environment_timing_enabled:
		perf_stages["projection"] = Time.get_ticks_usec() - perf_stage_started_usec
		_last_preview_environment_timing_usec = {
			"target_id": target_archetype_id,
			"stages_usec": perf_stages,
			"build_stages_usec": _world_environment_build_stages_usec.duplicate(true),
			"total_usec": Time.get_ticks_usec() - perf_total_started_usec,
		}
	return projection


# Exact route cards consume only the destination's public offer projection.
# Building installable game machines, layouts, semantic receipts, and rollback
# state here used to cold-load every game shown on the card, even though none of
# that state is rendered or retained by scouting.
func _preview_world_environment_data(run_state: RunState, target_archetype_id: String, target_prevalidated: bool) -> Dictionary:
	var perf_stage_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
	_world_environment_build_stages_usec = {}
	var target_id := target_archetype_id.strip_edges()
	var map_data := run_state.world_map
	var current_node_id := run_state.current_world_node_id()
	if target_id.is_empty() or not target_prevalidated and not _world_target_is_available(run_state, map_data, current_node_id, target_id):
		return run_state.current_environment
	var node := WorldMap.node_metadata_by_id(map_data, target_id)
	if node.is_empty():
		return run_state.current_environment
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["target_lookup"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	# preview_environment() restores a travel-preview snapshot before reaching
	# this path. RunState.from_dict() already configures the restored TownState
	# against this exact map, so rebuilding its node/edge indexes and sweep graph
	# here was duplicate work on the player's first destination click.
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["town_already_configured"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var scenario_seed_rng := run_state.create_rng("town_scenario_seed:%s" % target_id)
	var seeded_scenario := _select_scenario(run_state, target_id, scenario_seed_rng, false)
	if not seeded_scenario.is_empty():
		run_state.seed_scenario_for_node(target_id, seeded_scenario)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["scenario_seed"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var rng := run_state.create_rng()
	var depth := run_state.environment_travel_count() + (0 if run_state.current_environment.is_empty() else 1)
	var archetype := _archetype_by_id(target_id)
	if archetype.is_empty():
		archetype = _pick_archetype(run_state, depth, rng, target_id)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["archetype"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var scenario := _select_scenario(run_state, str(archetype.get("id", target_id)), rng, false)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["scenario_select"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var environment_data := EnvironmentInstance.travel_preview_from_archetype(archetype, depth, rng, library, run_state.challenge_config, scenario)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["environment_from_archetype"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	run_state.apply_town_generation_modifiers(environment_data, rng)
	if str(archetype.get("kind", "")) == "home":
		_apply_home_profile(run_state, environment_data, archetype, target_id, rng.fork("home_profile:%s" % target_id))
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["town_and_home"] = Time.get_ticks_usec() - perf_stage_started_usec
	return environment_data


func _stored_world_environment_preview(run_state: RunState, target_archetype_id: String) -> Dictionary:
	if not run_state.has_world_map():
		return {}
	var clean_target := target_archetype_id.strip_edges()
	var nodes_value: Variant = run_state.world_map.get("nodes", [])
	if clean_target.is_empty() or typeof(nodes_value) != TYPE_ARRAY:
		return {}
	for node_value in nodes_value as Array:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = node_value
		if str(node.get("id", "")) != clean_target:
			continue
		var environment_value: Variant = node.get("environment", {})
		if typeof(environment_value) == TYPE_DICTIONARY and not (environment_value as Dictionary).is_empty() \
				and _stored_environment_matches_situation_cycle(run_state, clean_target, environment_value as Dictionary):
			return _travel_preview_environment_projection(environment_value as Dictionary)
		return {}
	return {}


func _travel_preview_environment_projection(environment: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	for key in ["tier", "kind", "game_ids", "service_ids", "lender_hooks", "item_offers", "travel_locked_actions"]:
		if not environment.has(key):
			continue
		var value: Variant = environment.get(key)
		if typeof(value) == TYPE_ARRAY:
			result[key] = (value as Array).duplicate(true)
		elif typeof(value) == TYPE_DICTIONARY:
			result[key] = (value as Dictionary).duplicate(true)
		else:
			result[key] = value
	return result


# Swaps casino sub-environments without moving the world-map cursor.
func enter_grand_casino_room(run_state: RunState, target_archetype_id: String) -> bool:
	return _enter_grand_casino_room(run_state, target_archetype_id)


func _enter_grand_casino_room(run_state: RunState, target_archetype_id: String, prepared_rollback: Dictionary = {}, source_preflight_complete: bool = false, restore_on_failure: bool = true) -> bool:
	_last_environment_install_errors = ["The interior casino room could not be installed."]
	if run_state == null or not run_state.is_grand_casino_environment(run_state.current_environment):
		return false
	var target_id := target_archetype_id.strip_edges()
	if not RunState.GRAND_CASINO_ARCHETYPE_IDS.has(target_id):
		return false
	var flags: Dictionary = run_state.current_environment.get("local_narrative_flags", {}) if typeof(run_state.current_environment.get("local_narrative_flags", {})) == TYPE_DICTIONARY else {}
	var access := run_state.grand_casino_room_access_status(target_id, int(flags.get("casino_high_limit_buy_in", 60)))
	if not bool(access.get("available", false)):
		_last_environment_install_errors = [str(access.get("reason", "That casino room is locked."))]
		return false
	var source_room_id := str(run_state.current_environment.get("archetype_id", "")).strip_edges()
	if source_room_id != target_id and not source_preflight_complete and not bool(run_state.scenario_preflight_environment_change(source_room_id, target_id, "grand_room").get("ok", false)):
		return false
	var rollback := prepared_rollback if not prepared_rollback.is_empty() else (_travel_rollback_snapshot(run_state) if restore_on_failure else {})
	if source_room_id != target_id:
		if not bool(_commit_travel_departure(run_state, source_room_id, target_id, "grand_room").get("ok", false)):
			if restore_on_failure:
				_restore_travel_snapshot(run_state, rollback)
			return false
	run_state.store_grand_casino_room_environment(run_state.current_environment)
	var environment_data := run_state.grand_casino_room_environment(target_id)
	# A cache key is not proof of the saved room's identity. Reject mismatches
	# without regenerating over its stock, games, or progression. Older rooms
	# can name themselves as their node; the room id still has to match exactly.
	if not environment_data.is_empty() and (str(environment_data.get("archetype_id", "")) != target_id \
			or str(environment_data.get("world_node_id", "")) not in ["", target_id, RunState.GRAND_CASINO_ARCHETYPE_ID]):
		_last_environment_install_errors = ["The saved casino room does not match destination %s." % target_id]
		if restore_on_failure:
			_restore_travel_snapshot(run_state, rollback)
		return false
	if environment_data.is_empty():
		var archetype := _archetype_by_id(target_id)
		if archetype.is_empty():
			if restore_on_failure:
				_restore_travel_snapshot(run_state, rollback)
			return false
		var rng := run_state.create_rng()
		var depth := maxi(0, int(run_state.current_environment.get("depth", run_state.environment_travel_count())))
		var environment := EnvironmentInstance.from_archetype(archetype, depth, rng, library, run_state.challenge_config)
		environment_data = environment.to_dict()
		run_state.apply_town_generation_modifiers(environment_data, rng)
		environment_data["game_states"] = _generated_game_states(run_state, environment_data, rng)
		run_state.save_rng(rng)
	_apply_cage_gift_shop_stock(run_state, environment_data)
	environment_data["world_node_id"] = RunState.GRAND_CASINO_ARCHETYPE_ID
	environment_data["world_map_travel"] = true
	_apply_world_travel_targets(environment_data, run_state, run_state.world_map, RunState.GRAND_CASINO_ARCHETYPE_ID)
	# Grand Casino subrooms share one canonical world node. Apply seeded Crew
	# placement only after that identity is present, and reapply it for restored
	# rooms so itinerary rotation happens at the same revisit boundary as town.
	CrewRecruitmentModelScript.apply_to_environment(run_state, environment_data)
	environment_data["layout"] = EnvironmentInstance.ensure_generated_layout(environment_data, library)
	_align_world_map_scenario_layout_baseline(environment_data)
	var installed := _install_environment_with_rollback(run_state, environment_data, rollback, false)
	if not bool(installed.get("ok", false)):
		_last_environment_install_errors = JsonCoerceScript._copy_array(installed.get("errors", []))
		if restore_on_failure:
			_restore_travel_snapshot(run_state, rollback)
		return false
	# A room without a scenario still needs a complete physical envelope. In
	# particular, a late Crew encounter must not turn a successful Cage arrival
	# into a blank room when the renderer first authenticates its slots.
	var room_errors := _grand_casino_room_install_errors(run_state.current_environment, target_id)
	if not room_errors.is_empty():
		_last_environment_install_errors = room_errors
		if restore_on_failure:
			_restore_travel_snapshot(run_state, rollback)
		return false
	if source_room_id != target_id:
		run_state.scenario_publish_travel("travel_arrived", source_room_id, target_id, "grand_room")
	return true


func _grand_casino_room_install_errors(environment: Dictionary, target_id: String) -> Array:
	var errors := EnvironmentInstance.object_manifest_errors(environment)
	var authority := EnvironmentSlotBinderScript.validate_base_layout_authority(environment)
	errors.append_array(JsonCoerceScript._copy_array(authority.get("errors", [])))
	errors.append_array(JsonCoerceScript._copy_array(JsonCoerceScript._copy_dict(environment.get("layout", {})).get("placement_errors", [])))
	if target_id == RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID:
		var flags := JsonCoerceScript._copy_dict(environment.get("local_narrative_flags", {}))
		var authored_flags := JsonCoerceScript._copy_dict(_archetype_by_id(target_id).get("local_narrative_flags", {}))
		if JsonCoerceScript._raw_string_array(flags.get("casino_room_targets", [])) != JsonCoerceScript._raw_string_array(authored_flags.get("casino_room_targets", [])):
			errors.append("The saved Cage doors do not match the authored room destinations.")
		var bindings := JsonCoerceScript._copy_dict(authority.get("slot_bindings", {}))
		for object_id in ["casino_fixture:cage_counter", "casino_fixture:cage_atm", "travel:grand_casino"]:
			if str(JsonCoerceScript._copy_dict(bindings.get(object_id, {})).get("presentation_mode", "")) != "room":
				errors.append("The Cage requires its authored counter, ATM, and Main Floor exit: %s." % object_id)
	return errors


# Changes floors inside one layered venue without world travel or route cost.
func enter_environment_layer(run_state: RunState, target_layer_id: String, advance_action: bool = true) -> Dictionary:
	if run_state == null or not run_state.is_layered_environment():
		return {"ok": false, "message": "This venue has no interior layers."}
	var target_id := target_layer_id.strip_edges()
	var access := run_state.environment_layer_access_status(target_id)
	if not bool(access.get("available", false)):
		return {"ok": false, "hidden": bool(access.get("hidden", false)), "message": str(access.get("reason", "The door stays shut."))}
	var source_layer_id := str(run_state.current_environment.get("current_layer_id", "")).strip_edges()
	var preflight := run_state.scenario_preflight_environment_change(source_layer_id, target_id, "layer") if source_layer_id != target_id else {"ok": true, "inactive": true, "errors": []}
	if not bool(preflight.get("ok", false)):
		var preflight_errors := JsonCoerceScript._copy_array(preflight.get("errors", []))
		return {"ok": false, "message": str(preflight_errors[0]) if not preflight_errors.is_empty() else "The room boundary could not begin safely."}
	var rollback := _travel_rollback_snapshot(run_state)
	if bool(access.get("discover_on_enter", false)):
		run_state.discover_environment_layer(target_id, str(access.get("access_method", "access")))
	if advance_action:
		var advance_result := run_state.advance_environment_turns(1)
		if not bool(advance_result.get("ok", false)):
			_restore_travel_snapshot(run_state, rollback)
			return {"ok": false, "message": str(JsonCoerceScript._copy_array(advance_result.get("errors", []))[0]) if not JsonCoerceScript._copy_array(advance_result.get("errors", [])).is_empty() else "The room boundary could not advance safely."}
	var layer_state := run_state.environment_layer_state(target_id)
	if layer_state.is_empty():
		var archetype_id := str(run_state.current_environment.get("archetype_id", "")).strip_edges()
		var archetype := _archetype_by_id(archetype_id)
		if archetype.is_empty():
			_restore_travel_snapshot(run_state, rollback)
			return {"ok": false, "message": "The room definition is missing."}
		var layer_rng := run_state.create_rng("environment_layer:%s:%s" % [str(run_state.current_environment.get("world_node_id", archetype_id)), target_id])
		var scenario_state := ScenarioEngineScript.normalize_state(run_state.current_environment.get("scenario_state", {}))
		var generated := EnvironmentInstance.from_archetype_layer(
			archetype,
			target_id,
			int(run_state.current_environment.get("depth", 0)),
			layer_rng,
			library,
			run_state.challenge_config,
			scenario_state
		)
		layer_state = generated.to_dict()
	if layer_state.is_empty():
		_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "message": "The room could not be restored."}
	if not layer_state.has("town_conditions"):
		run_state.apply_town_generation_modifiers(layer_state)
	var stored_game_states: Variant = layer_state.get("game_states", null)
	if typeof(stored_game_states) != TYPE_DICTIONARY or (stored_game_states as Dictionary).is_empty() and not JsonCoerceScript._copy_array(layer_state.get("game_ids", [])).is_empty():
		var game_rng := run_state.create_rng("environment_layer_games:%s:%s" % [str(run_state.current_environment.get("world_node_id", run_state.current_environment.get("archetype_id", ""))), target_id])
		layer_state["game_states"] = _generated_game_states(run_state, layer_state, game_rng)
	if run_state.has_world_map():
		_apply_world_travel_targets(layer_state, run_state, run_state.world_map, run_state.current_world_node_id())
	layer_state["layout"] = EnvironmentInstance.ensure_generated_layout(layer_state, library)
	if source_layer_id != target_id:
		var departed := _commit_travel_departure(run_state, source_layer_id, target_id, "layer")
		if not bool(departed.get("ok", false)):
			_restore_travel_snapshot(run_state, rollback)
			return {"ok": false, "message": str(JsonCoerceScript._copy_array(departed.get("errors", []))[0]) if not JsonCoerceScript._copy_array(departed.get("errors", [])).is_empty() else "The room departure could not be recorded."}
	if not run_state.install_environment_layer_state(target_id, layer_state, library):
		_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "message": "The room could not be entered."}
	# Crew presence is an authoritative dynamic actor input to scenario semantic
	# sealing. Apply it before the first seal so a save made in this layer can
	# rebuild the identical inventory in a fresh process. The post-reconciliation
	# application below remains necessary because scenario projection can replace
	# the flat event arrays.
	var crew_membership := _prepare_layer_crew_membership(run_state)
	if not bool(crew_membership.get("ok", false)):
		_restore_travel_snapshot(run_state, rollback)
		var membership_errors := JsonCoerceScript._copy_array(crew_membership.get("errors", []))
		return {"ok": false, "message": str(membership_errors[0]) if not membership_errors.is_empty() else "The room's Crew presence could not be prepared safely."}
	var layer_finalized := run_state.scenario_finalize_installed_environment(library)
	if not bool(layer_finalized.get("ok", false)):
		_restore_travel_snapshot(run_state, rollback)
		var layer_errors := JsonCoerceScript._copy_array(layer_finalized.get("errors", []))
		return {"ok": false, "message": str(layer_errors[0]) if not layer_errors.is_empty() else "The room semantic contract could not be finalized."}
	# Scenario reconciliation and layer installation can replace flat event
	# arrays. Recompute recruitment against the final layer before publication.
	var final_membership := _prepare_layer_crew_membership(run_state)
	if not bool(final_membership.get("ok", false)):
		_restore_travel_snapshot(run_state, rollback)
		var final_membership_errors := JsonCoerceScript._copy_array(final_membership.get("errors", []))
		return {"ok": false, "message": str(final_membership_errors[0]) if not final_membership_errors.is_empty() else "The room's final Crew presence could not be prepared safely."}
	var publication := run_state.publish_room_presentation()
	if not bool(publication.get("ok", false)):
		_restore_travel_snapshot(run_state, rollback)
		var publication_errors := JsonCoerceScript._copy_array(publication.get("errors", []))
		return {"ok": false, "message": str(publication_errors[0]) if not publication_errors.is_empty() else "The room could not be published safely."}
	var exit_errors := _crew_room_exit_errors(run_state.current_environment)
	if not exit_errors.is_empty():
		_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "message": "The private room could not provide a safe exit.", "errors": exit_errors}
	if source_layer_id != target_id:
		run_state.scenario_publish_travel("travel_arrived", source_layer_id, target_id, "layer")
		# Settle arrival in the installed destination phase before the player can
		# accept a zero-turn task. A later room action must not replay this return
		# as pressure against that newly accepted task.
		var arrival := run_state.scenario_flush_facts()
		if not bool(arrival.get("ok", false)) and not bool(arrival.get("inactive", false)):
			_restore_travel_snapshot(run_state, rollback)
			var arrival_errors := JsonCoerceScript._copy_array(arrival.get("errors", []))
			return {"ok": false, "message": str(arrival_errors[0]) if not arrival_errors.is_empty() else "The room arrival could not be recorded.", "errors": arrival_errors}
	if run_state.has_world_map():
		run_state.store_current_world_node_environment()
	return {
		"ok": true,
		"layer_id": target_id,
		"access_method": str(access.get("access_method", "open")),
		"message": str(layer_state.get("layer_entry_message", "You pass through the interior door.")),
	}


func _prepare_layer_crew_membership(run_state: RunState) -> Dictionary:
	# Authenticate the installed baseline before this owner changes its derived
	# Crew inputs. Reconciliation below authorizes that mutation, never a repair
	# of arbitrary stale or edited incoming room authority.
	var errors := EnvironmentInstance.object_manifest_errors(run_state.current_environment)
	var authority := EnvironmentSlotBinderScript.validate_base_layout_authority(run_state.current_environment)
	errors.append_array(JsonCoerceScript._copy_array(authority.get("errors", [])))
	if not errors.is_empty():
		return {"ok": false, "errors": errors}
	CrewRecruitmentModelScript.apply_to_environment(run_state, run_state.current_environment)
	# Newly selected Crew events need their authored physical/art metadata before
	# membership is sealed. The installed baseline was authenticated above.
	run_state.current_environment["layout"] = EnvironmentInstance.ensure_generated_layout(run_state.current_environment, library)
	return run_state.reconcile_environment_object_membership(run_state.current_environment)


# A failed room projection must not trap a run. This deliberately narrow route
# returns only from the Punchline private room to its authored public parent;
# it never admits a player, grants credentials, charges time, or regenerates loot.
# The prior room payload remains in layer_states for diagnosis/reentry. Destination
# finalization and exit proof must pass before the recovery commits.
func recover_punchline_back_room_exit(run_state: RunState) -> Dictionary:
	if run_state == null or str(run_state.current_environment.get("archetype_id", "")) != "small_underground_casino" or str(run_state.current_environment.get("current_layer_id", "")) != "back_room":
		return {"ok": false, "message": "This recovery door is not available here."}
	var rollback := _travel_rollback_snapshot(run_state)
	var source := run_state.current_environment.duplicate(true)
	var states := JsonCoerceScript._copy_dict(source.get("layer_states", {}))
	var target := JsonCoerceScript._copy_dict(states.get("casino", {}))
	if target.is_empty() or str(target.get("archetype_id", "")) != "small_underground_casino" or str(target.get("current_layer_id", "")) != "casino":
		return {"ok": false, "message": "The saved casino room is missing or invalid; your run has been kept intact."}
	# Preserve even a rejected source envelope; no reconciliation of the broken
	# floor is required to authorize leaving for this known, saved parent.
	var preserved := source.duplicate(true)
	preserved.erase("layer_states")
	states["back_room"] = preserved
	run_state.current_environment["layer_states"] = states
	if not run_state.install_environment_layer_state("casino", target, library):
		_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "message": "The saved casino could not be restored; your run has been kept intact."}
	CrewRecruitmentModelScript.apply_to_environment(run_state, run_state.current_environment)
	# Restore trusted catalog contact bindings before reconstructing the immutable
	# parent baseline; saved presentation hints may predate those contacts.
	run_state.current_environment["layout"] = EnvironmentInstance.ensure_generated_layout(run_state.current_environment, library)
	var finalized := run_state.scenario_finalize_installed_environment(library)
	run_state.reconcile_current_environment_object_manifest(true)
	var errors := JsonCoerceScript._copy_array(finalized.get("errors", []))
	errors.append_array(EnvironmentInstance.object_manifest_errors(run_state.current_environment))
	var authority := EnvironmentSlotBinderScript.validate_base_layout_authority(run_state.current_environment)
	errors.append_array(JsonCoerceScript._copy_array(authority.get("errors", [])))
	if not bool(finalized.get("ok", false)) or not bool(authority.get("ok", false)) or not errors.is_empty():
		_restore_travel_snapshot(run_state, rollback)
		return {"ok": false, "message": "The saved casino could not be validated; your run has been kept intact.", "errors": errors}
	# Installation may reconcile the previous floor; retain the exact failed
	# payload rather than silently replacing the evidence with a regenerated room.
	var retained_states := JsonCoerceScript._copy_dict(run_state.current_environment.get("layer_states", {}))
	retained_states["back_room"] = preserved
	run_state.current_environment["layer_states"] = retained_states
	run_state.log_story({"type": "environment_layer_recovery", "source_layer_id": "back_room", "target_layer_id": "casino", "message": "The private room could not be displayed. You returned to the casino; your progress was kept."})
	return {"ok": true, "message": "Returned to the casino. Your cash, items, and private-room state were kept."}


func _crew_room_exit_errors(environment: Dictionary) -> Array:
	if str(environment.get("archetype_id", "")) != "small_underground_casino" or str(environment.get("current_layer_id", "")) != "back_room":
		return []
	var errors := EnvironmentInstance.object_manifest_errors(environment)
	var authority := EnvironmentSlotBinderScript.validate_base_layout_authority(environment)
	errors.append_array(JsonCoerceScript._copy_array(authority.get("errors", [])))
	var bindings := JsonCoerceScript._copy_dict(authority.get("slot_bindings", {}))
	var exit_binding := JsonCoerceScript._copy_dict(bindings.get("environment_layer:casino", {}))
	if not bool(authority.get("ok", false)) or str(exit_binding.get("presentation_mode", "")) != "room" or str(exit_binding.get("slot_family", "")) != "exit":
		errors.append("Crew Back Room requires its authored casino exit with valid room geometry.")
	return errors


func _apply_cage_gift_shop_stock(run_state: RunState, environment_data: Dictionary) -> void:
	if str(environment_data.get("archetype_id", "")) != RunState.GRAND_CASINO_CAGE_ARCHETYPE_ID:
		return
	if typeof(environment_data.get("cage_gift_shop_state", {})) == TYPE_DICTIONARY and not (environment_data.get("cage_gift_shop_state", {}) as Dictionary).is_empty():
		return
	var flags: Dictionary = environment_data.get("local_narrative_flags", {}) if typeof(environment_data.get("local_narrative_flags", {})) == TYPE_DICTIONARY else {}
	var shop_config: Dictionary = flags.get("casino_gift_shop", {}) if typeof(flags.get("casino_gift_shop", {})) == TYPE_DICTIONARY else {}
	var showdown_event := library.event(RunState.GRAND_CASINO_SHOWDOWN_EVENT_ID) if library != null else {}
	var showdown_payload: Dictionary = showdown_event.get("payload", {}) if typeof(showdown_event.get("payload", {})) == TYPE_DICTIONARY else {}
	var pat_down_config: Dictionary = showdown_payload.get("pat_down", {}) if typeof(showdown_payload.get("pat_down", {})) == TYPE_DICTIONARY else {}
	var allowed: Array = []
	var seen := {}
	for candidate_value in JsonCoerceScript._copy_array(shop_config.get("candidate_offers", [])):
		if typeof(candidate_value) != TYPE_DICTIONARY:
			continue
		var candidate := (candidate_value as Dictionary).duplicate(true)
		var item_id := str(candidate.get("item_id", candidate.get("id", ""))).strip_edges()
		if item_id.is_empty() or seen.has(item_id) or library.item(item_id).is_empty():
			continue
		if GrandCasinoShowdownModelScript.item_forbidden_by_pat_down(item_id, pat_down_config):
			continue
		seen[item_id] = true
		candidate["id"] = item_id
		candidate["item_id"] = item_id
		candidate["chip_price"] = maxi(1, int(candidate.get("chip_price", 1)))
		candidate["sold"] = false
		allowed.append(candidate)
	var stock_range := _int_range(shop_config.get("stock_count", [3, 4]), 3, 4)
	var minimum := clampi(int(stock_range[0]), 3, 4)
	var maximum := clampi(int(stock_range[1]), minimum, 4)
	if allowed.size() < minimum:
		environment_data["cage_gift_shop_state"] = {"version": 1, "stock": [], "error": "Fewer than three pat-down-safe candidates."}
		return
	var stock_rng := run_state.create_rng("cage_gift_shop").fork("stock:%s:%d" % [run_state.seed_text, int(environment_data.get("depth", 0))])
	var count := stock_rng.randi_range(minimum, mini(maximum, allowed.size()))
	var stock: Array = []
	for selected_value in stock_rng.pick_many(allowed, count):
		stock.append((selected_value as Dictionary).duplicate(true))
	environment_data["cage_gift_shop_state"] = {
		"version": 1,
		"stock": stock,
		"stock_count": stock.size(),
		"fork_state": stock_rng.state_value,
	}


func world_route_for_target(run_state: RunState, target_archetype_id: String) -> Dictionary:
	if run_state == null or not run_state.has_world_map():
		return library.route(target_archetype_id) if library != null else {}
	var map := WorldMap.new(library)
	return map.route_for_target(run_state.world_map, run_state.current_world_node_id(), target_archetype_id)


func world_route_for_target_prepared(run_state: RunState, target_archetype_id: String, path_query: Dictionary) -> Dictionary:
	if run_state == null or not run_state.has_world_map():
		return library.route(target_archetype_id) if library != null else {}
	var map := WorldMap.new(library)
	return map.route_for_target_prepared(run_state.world_map, run_state.current_world_node_id(), target_archetype_id, path_query)


func world_map_snapshot(run_state: RunState, selected_id: String = "") -> Dictionary:
	if run_state == null:
		return {}
	return WorldMap.snapshot(run_state.world_map, selected_id)


func _next_world_environment(run_state: RunState, target_archetype_id: String, rng: RngStream, target_prevalidated: bool = false, prepared_rollback: Dictionary = {}, source_preflight_complete: bool = false, restore_on_failure: bool = true) -> EnvironmentInstance:
	var perf_total_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
	var perf_stage_started_usec := perf_total_started_usec
	var perf_stages: Dictionary = {}
	var rollback := prepared_rollback if not prepared_rollback.is_empty() else (_travel_rollback_snapshot(run_state) if restore_on_failure else {})
	var had_source := not run_state.current_environment.is_empty()
	var map := WorldMap.new(library)
	var initialized_tutorial_map := false
	if not run_state.has_world_map():
		var initial_map := map.build(run_state, rng.fork("world_map"))
		run_state.set_world_map(_apply_tutorial_initial_map_targets(initial_map, run_state))
		initialized_tutorial_map = run_state.is_tutorial_run()
	var map_data := run_state.world_map
	run_state.configure_town_world(map_data)
	if _world_environment_timing_enabled:
		perf_stages["map_configure"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	_prime_town_scenarios(run_state, map_data)
	if _world_environment_timing_enabled:
		perf_stages["scenario_prime"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stages["scenario_prime_nodes"] = _world_scenario_prime_stages_usec.duplicate(true)
		perf_stage_started_usec = Time.get_ticks_usec()
	var target_id := target_archetype_id.strip_edges()
	var current_node_id := run_state.current_world_node_id()
	if run_state.current_environment.is_empty() and target_id.is_empty():
		target_id = WorldMap.current_node_id(map_data)
	elif not target_id.is_empty() and not target_prevalidated and not _world_target_is_available(run_state, map_data, current_node_id, target_id):
		if had_source and restore_on_failure: _restore_travel_snapshot(run_state, rollback)
		return EnvironmentInstance.from_dict(run_state.current_environment)
	elif target_id.is_empty():
		target_id = _fallback_world_neighbor(run_state, map_data, current_node_id)
	if target_id.is_empty():
		if had_source and restore_on_failure: _restore_travel_snapshot(run_state, rollback)
		return EnvironmentInstance.from_dict(run_state.current_environment) if not run_state.current_environment.is_empty() else _legacy_next_environment(run_state, target_archetype_id, rng)
	var node := WorldMap.node_by_id(map_data, target_id)
	if node.is_empty():
		_last_environment_install_errors = ["Travel destination node %s is missing from the active map." % target_id]
		if had_source and restore_on_failure: _restore_travel_snapshot(run_state, rollback)
		return EnvironmentInstance.from_dict(run_state.current_environment) if not run_state.current_environment.is_empty() else _legacy_next_environment(run_state, target_archetype_id, rng)
	if not run_state.current_environment.is_empty() and not source_preflight_complete:
		var arrival_preflight := run_state.scenario_preflight_environment_change(current_node_id, target_id, "world")
		if not bool(arrival_preflight.get("ok", false)):
			_last_environment_install_errors = JsonCoerceScript._copy_array(arrival_preflight.get("errors", []))
			if restore_on_failure:
				_restore_travel_snapshot(run_state, rollback)
			return EnvironmentInstance.from_dict(run_state.current_environment)
	if run_state.has_world_map() and not run_state.current_environment.is_empty():
		if current_node_id != target_id:
			var departure := _commit_travel_departure(run_state, current_node_id, target_id, "world")
			if not bool(departure.get("ok", false)):
				_last_environment_install_errors = JsonCoerceScript._copy_array(departure.get("errors", []))
				if restore_on_failure:
					_restore_travel_snapshot(run_state, rollback)
				return EnvironmentInstance.from_dict(run_state.current_environment)
	if _world_environment_timing_enabled:
		perf_stages["route_departure"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var environment_data := _world_environment_data_for_node(run_state, map_data, node, rng)
	if _world_environment_timing_enabled:
		perf_stages["environment_build"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	# A failed lazy restore is an explicit rejection, never a Base / No Scenario
	# room. Do not let set_environment() evaluate the economy against an empty
	# destination, even when the outer UI owns transaction rollback.
	var installed := {"ok": false, "errors": _last_environment_install_errors.duplicate(true)} if environment_data.is_empty() else _install_environment_with_rollback(run_state, environment_data, rollback, false)
	if environment_data.is_empty() and JsonCoerceScript._copy_array(installed.get("errors", [])).is_empty():
		installed["errors"] = ["Travel destination could not be generated."]
	if not bool(installed.get("ok", false)):
		_last_environment_install_errors = JsonCoerceScript._copy_array(installed.get("errors", []))
		_last_environment_install_failure = {
			"target_id": target_id,
			"scenario_id": str(environment_data.get("scenario_id", "")).strip_edges(),
			"had_source": had_source,
			"errors": _last_environment_install_errors.duplicate(true),
		}
		if _world_environment_timing_enabled:
			perf_stages["environment_install"] = Time.get_ticks_usec() - perf_stage_started_usec
			_last_world_environment_timing_usec = {
				"target_id": target_id,
				"failed": true,
				"stages_usec": perf_stages,
				"build_stages_usec": _world_environment_build_stages_usec.duplicate(true),
				"install_stages_usec": _world_environment_install_stages_usec.duplicate(true),
				"total_usec": Time.get_ticks_usec() - perf_total_started_usec,
			}
		if restore_on_failure:
			_restore_travel_snapshot(run_state, rollback)
		return EnvironmentInstance.from_dict(run_state.current_environment)
	if _world_environment_timing_enabled:
		perf_stages["environment_install"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	run_state.enter_world_node(target_id, run_state.current_environment)
	_apply_scenario_authored_travel_targets(run_state, target_id)
	if not current_node_id.is_empty() and current_node_id != target_id:
		run_state.scenario_publish_travel("travel_arrived", current_node_id, target_id, "world")
	_apply_tutorial_authored_travel_targets(run_state, target_id)
	if initialized_tutorial_map:
		# enter_node() normally reveals every neighbor. Reapply the authored first
		# reveal after entering the apartment so Gas Casino cannot leak onto the
		# first tutorial map before the Corner Store route beat.
		run_state.set_world_map(_apply_tutorial_initial_map_targets(run_state.world_map, run_state))
	run_state.save_rng(rng)
	var result := EnvironmentInstance.from_dict(run_state.current_environment)
	if _world_environment_timing_enabled:
		perf_stages["post_install"] = Time.get_ticks_usec() - perf_stage_started_usec
		_last_world_environment_timing_usec = {
			"target_id": target_id,
			"stages_usec": perf_stages,
			"build_stages_usec": _world_environment_build_stages_usec.duplicate(true),
			"install_stages_usec": _world_environment_install_stages_usec.duplicate(true),
			"total_usec": Time.get_ticks_usec() - perf_total_started_usec,
		}
	return result


func _apply_scenario_authored_travel_targets(run_state: RunState, node_id: String) -> void:
	if run_state == null or node_id.is_empty():
		return
	var definition := _apply_scenario_pin_suppression(
		run_state,
		node_id,
		run_state._seeded_scenario_definition_for_node_readonly(node_id)
	)
	if definition.is_empty():
		return
	var mutations := JsonCoerceScript._copy_dict(definition.get("mutations", {}))
	var target_ids := JsonCoerceScript._raw_string_array(mutations.get("travel_hooks_add", []))
	if not target_ids.is_empty():
		run_state.add_next_archetypes(target_ids)


func _apply_tutorial_authored_travel_targets(run_state: RunState, environment_id: String) -> void:
	if run_state == null or not run_state.is_tutorial_run():
		return
	var modifiers := run_state.challenge_modifiers()
	var overrides: Dictionary = modifiers.get("tutorial_environment_overrides", {}) if typeof(modifiers.get("tutorial_environment_overrides", {})) == TYPE_DICTIONARY else {}
	var override: Dictionary = overrides.get(environment_id, {}) if typeof(overrides.get(environment_id, {})) == TYPE_DICTIONARY else {}
	if not override.has("next_archetypes") and not override.has("travel_hooks"):
		return
	var targets: Array = []
	for source in [JsonCoerceScript._raw_string_array(override.get("next_archetypes", [])), JsonCoerceScript._raw_string_array(override.get("travel_hooks", []))]:
		for target_id_value in source:
			var target_id := str(target_id_value)
			if not target_id.is_empty() and not targets.has(target_id):
				targets.append(target_id)
	run_state.set_next_archetypes(targets)
	run_state.current_environment["travel_hooks"] = targets.duplicate()
	run_state.current_environment["layout"] = EnvironmentInstance.ensure_generated_layout(run_state.current_environment, library)
	if run_state.has_world_map():
		run_state.store_current_world_node_environment()


# Constrains only the tutorial's first map reveal. Later event choices unlock
# their authored destinations through RunState.add_next_archetypes().
func _apply_tutorial_initial_map_targets(map_data: Dictionary, run_state: RunState) -> Dictionary:
	if run_state == null or not run_state.is_tutorial_run():
		return map_data
	var configured: Variant = run_state.challenge_modifiers().get("tutorial_initial_map_targets", [])
	if typeof(configured) != TYPE_ARRAY or (configured as Array).is_empty():
		return map_data
	var allowed := {str(map_data.get("start_node_id", "")): true}
	for target_value in configured:
		var target_id := str(target_value).strip_edges()
		if not target_id.is_empty():
			allowed[target_id] = true
	var constrained := map_data.duplicate(true)
	var nodes: Array = constrained.get("nodes", [])
	for index in range(nodes.size()):
		if typeof(nodes[index]) != TYPE_DICTIONARY:
			continue
		var node: Dictionary = nodes[index]
		var node_id := str(node.get("id", ""))
		if allowed.has(node_id):
			node["seen"] = true
			if node_id != str(constrained.get("start_node_id", "")):
				node["state"] = WorldMap.STATE_REVEALED
				node["discovered_at_spawn"] = true
				node["discovery_source"] = WorldMap.DISCOVERY_SOURCE_SPAWN
		else:
			node["state"] = WorldMap.STATE_HIDDEN
			node["seen"] = false
			node["discovered_at_spawn"] = false
			node["discovery_source"] = WorldMap.DISCOVERY_SOURCE_NONE
			node.erase("discovered_by_travel")
			node.erase("unlocked")
		nodes[index] = node
	constrained["nodes"] = nodes
	return constrained


func _legacy_next_environment(run_state: RunState, target_archetype_id: String, rng: RngStream) -> EnvironmentInstance:
	var rollback := _travel_rollback_snapshot(run_state)
	var source_id := run_state.current_world_node_id()
	var had_source := not run_state.current_environment.is_empty()
	var depth := run_state.environment_travel_count()
	if had_source:
		depth += 1
	var archetype := _pick_archetype(run_state, depth, rng, target_archetype_id)
	var scenario := _select_scenario(run_state, str(archetype.get("id", "")), rng)
	var environment := EnvironmentInstance.from_archetype(archetype, depth, rng, library, run_state.challenge_config, scenario)
	var environment_data := environment.to_dict()
	var destination_id := str(environment_data.get("world_node_id", "")).strip_edges()
	if destination_id.is_empty():
		destination_id = str(environment_data.get("archetype_id", "")).strip_edges()
	if had_source:
		# Legacy travel learns its destination through generation, so reserve both
		# the departure fact and leave/visit-end expiry only after that identity is
		# known, but before any generated-room mutation is committed to the run.
		var preflight := run_state.scenario_preflight_environment_change(source_id, destination_id, "legacy")
		if destination_id.is_empty() or not bool(preflight.get("ok", false)):
			_last_environment_install_errors = ["Generated travel destination identity is empty."] if destination_id.is_empty() else JsonCoerceScript._copy_array(preflight.get("errors", []))
			_restore_travel_snapshot(run_state, rollback)
			return EnvironmentInstance.from_dict(run_state.current_environment)
	run_state.apply_town_generation_modifiers(environment_data, rng)
	CrewRecruitmentModelScript.apply_to_environment(run_state, environment_data)
	environment_data["game_states"] = _generated_game_states(run_state, environment_data, rng)
	environment_data["layout"] = EnvironmentInstance.ensure_generated_layout(environment_data, library)
	if had_source:
		var departure := _commit_travel_departure(run_state, source_id, destination_id, "legacy")
		if not bool(departure.get("ok", false)):
			_last_environment_install_errors = JsonCoerceScript._copy_array(departure.get("errors", []))
			_restore_travel_snapshot(run_state, rollback)
			return EnvironmentInstance.from_dict(run_state.current_environment)
	run_state.save_rng(rng)
	var installed := _install_environment_with_rollback(run_state, environment_data, rollback, false)
	if not bool(installed.get("ok", false)):
		_last_environment_install_errors = JsonCoerceScript._copy_array(installed.get("errors", []))
		_restore_travel_snapshot(run_state, rollback)
		return EnvironmentInstance.from_dict(run_state.current_environment)
	if had_source:
		run_state.scenario_publish_travel("travel_arrived", source_id, run_state.current_world_node_id(), "legacy")
	return EnvironmentInstance.from_dict(run_state.current_environment)


func _world_environment_data_for_node(run_state: RunState, map_data: Dictionary, node: Dictionary, rng: RngStream, generation_options: Dictionary = {}) -> Dictionary:
	var perf_stage_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
	_world_environment_build_stages_usec = {}
	var node_id := str(node.get("id", "")).strip_edges()
	var stored_environment: Dictionary = node.get("environment", {}) if typeof(node.get("environment", {})) == TYPE_DICTIONARY else {}
	if generation_options.is_empty() and not stored_environment.is_empty() and str(node.get("state", "")) == WorldMap.STATE_VISITED:
		var actual_source := run_state.current_environment
		run_state.current_environment = stored_environment.duplicate(true)
		var refreshed := refresh_current_venue_scenario_cycle(run_state, false, actual_source)
		stored_environment = run_state.current_environment.duplicate(true)
		run_state.current_environment = actual_source
		if not bool(refreshed.get("ok", false)):
			_last_environment_install_errors = JsonCoerceScript._copy_array(refreshed.get("errors", []))
			return {}
	var restore_stored := generation_options.is_empty() and not stored_environment.is_empty() \
		and str(node.get("state", "")) == WorldMap.STATE_VISITED \
		and _stored_environment_matches_situation_cycle(run_state, node_id, stored_environment)
	if restore_stored:
		var restored := stored_environment.duplicate(true)
		if not restored.has(ENVIRONMENT_SITUATION_CYCLE_KEY):
			restored[ENVIRONMENT_SITUATION_CYCLE_KEY] = _environment_situation_cycle_id(run_state, node_id)
		run_state.apply_town_living_world_context(restored, rng.fork("town_reentry:%s" % node_id))
		CrewRecruitmentModelScript.apply_to_environment(run_state, restored)
		_apply_world_travel_targets(restored, run_state, map_data, node_id)
		restored["world_node_id"] = node_id
		var restored_definition := _apply_scenario_pin_suppression(run_state, node_id, run_state._seeded_scenario_definition_for_node_readonly(node_id))
		_apply_scenario_sequence_travel_targets(restored, restored_definition)
		ScenarioEngineScript.ensure_sequence_state(restored, restored_definition)
		restored["layout"] = EnvironmentInstance.ensure_generated_layout(restored, library)
		_align_world_map_scenario_layout_baseline(restored)
		return restored
	var depth := maxi(0, int(generation_options.get("depth", run_state.environment_travel_count())))
	if generation_options.is_empty() and not run_state.current_environment.is_empty():
		depth += 1
	var archetype := _archetype_by_id(node_id)
	if archetype.is_empty():
		archetype = _pick_archetype(run_state, depth, rng, node_id)
	var condition_overrides := JsonCoerceScript._copy_dict(generation_options.get("condition_overrides", {}))
	if not bool(generation_options.get("conditions_prepared", false)) and not condition_overrides.is_empty() and run_state.town_state != null:
		run_state.town_state.apply_generation_overrides(condition_overrides)
	var scenario: Dictionary = {}
	var requested_scenario_id := str(generation_options.get("scenario_id", "__default")).strip_edges()
	if requested_scenario_id == "__default":
		scenario = _select_scenario(run_state, str(archetype.get("id", node_id)), rng)
	elif requested_scenario_id != "__none":
		scenario = library._runtime_validated_scenario_definition(library._scenario_readonly(requested_scenario_id))
	if not scenario.is_empty():
		run_state.seed_scenario_for_node(node_id, scenario)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["scenario_select"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	var environment := EnvironmentInstance.from_archetype(archetype, depth, rng, library, run_state.challenge_config, scenario)
	var environment_data := environment.to_dict()
	environment_data[ENVIRONMENT_SITUATION_CYCLE_KEY] = _environment_situation_cycle_id(run_state, str(archetype.get("id", node_id)))
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["environment_from_archetype"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	run_state.apply_town_generation_modifiers(environment_data, rng)
	# Game generation hooks may publish node-scoped facts. Give them the stable
	# world-node identity before generating their canonical machine state.
	environment_data["world_node_id"] = node_id
	ScenarioEngineScript.ensure_sequence_state(environment_data, scenario)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["town_and_sequence"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	CrewRecruitmentModelScript.apply_to_environment(run_state, environment_data)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["crew"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	environment_data["game_states"] = _generated_game_states(run_state, environment_data, rng)
	# Reopening refreshes a venue's situation, not its persistent machines.
	if not stored_environment.is_empty() and typeof(stored_environment.get("game_states", {})) == TYPE_DICTIONARY:
		var persistent_games: Dictionary = stored_environment.get("game_states", {})
		for game_id_value in persistent_games.keys():
			if environment_data["game_states"].has(game_id_value):
				environment_data["game_states"][game_id_value] = JsonCoerceScript._copy_dict(persistent_games.get(game_id_value, {}))
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["games"] = Time.get_ticks_usec() - perf_stage_started_usec
		perf_stage_started_usec = Time.get_ticks_usec()
	if str(archetype.get("kind", "")) == "home":
		_apply_home_profile(run_state, environment_data, archetype, node_id, rng.fork("home_profile:%s" % node_id))
	if bool(generation_options.get("environment_test", false)):
		var practice_exit_target := str(environment_data.get("archetype_id", node_id))
		environment_data["next_archetypes"] = [practice_exit_target]
		environment_data["travel_hooks"] = [practice_exit_target]
		environment_data["world_map_travel"] = false
		_stamp_environment_test_exit(environment_data)
	else:
		_apply_world_travel_targets(environment_data, run_state, map_data, node_id)
	_apply_scenario_sequence_travel_targets(environment_data, scenario)
	# from_archetype seals a provisional manifest before town modifiers, generated
	# machine state, and world routes are installed. This branch owns a freshly
	# generated candidate, so that preliminary source digest is not persistence
	# authority: rebuild it once from the complete trusted destination. Restored
	# rooms take the branch above and retain their fail-closed manifest validation.
	environment_data.erase("object_manifest")
	environment_data.erase("object_manifest_digest")
	environment_data.erase("object_manifest_revision")
	environment_data["layout"] = EnvironmentInstance.ensure_generated_layout(environment_data, library)
	_align_world_map_scenario_layout_baseline(environment_data)
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["targets_and_layout"] = Time.get_ticks_usec() - perf_stage_started_usec
	return environment_data


func _stamp_environment_test_exit(environment_data: Dictionary) -> void:
	var flags := JsonCoerceScript._copy_dict(environment_data.get("local_narrative_flags", {}))
	flags["environment_test_session"] = true
	environment_data["local_narrative_flags"] = flags
	var layer_states := JsonCoerceScript._copy_dict(environment_data.get("layer_states", {}))
	for layer_id_value in layer_states.keys():
		var layer_state := JsonCoerceScript._copy_dict(layer_states.get(layer_id_value, {}))
		var layer_flags := JsonCoerceScript._copy_dict(layer_state.get("local_narrative_flags", {}))
		layer_flags["environment_test_session"] = true
		layer_state["local_narrative_flags"] = layer_flags
		var practice_exit_target := str(layer_state.get("archetype_id", environment_data.get("archetype_id", "")))
		layer_state["next_archetypes"] = [practice_exit_target]
		layer_state["travel_hooks"] = [practice_exit_target]
		layer_state["world_map_travel"] = false
		layer_states[layer_id_value] = layer_state
	if not layer_states.is_empty():
		environment_data["layer_states"] = layer_states


func _environment_situation_cycle_id(run_state: RunState, archetype_id: String) -> String:
	return str(EnvironmentHours.scenario_cycle_status(_archetype_by_id(archetype_id), run_state.game_clock_minutes).get("cycle_id", ""))


# One owner transaction for clock, action, Continue and lazy destination entry.
# No visit, wager, reward or root-RNG boundary is manufactured by a rollover.
func refresh_current_venue_scenario_cycle(run_state: RunState, persist_world_room: bool = true, rollback_source_environment: Dictionary = {}) -> Dictionary:
	if run_state == null or library == null or run_state.current_environment.is_empty() or run_state.is_terminal():
		return {"ok": true, "changed": false}
	var source := run_state.current_environment
	var archetype_id := str(source.get("archetype_id", ""))
	if library._scenarios_for_archetype_readonly(archetype_id).is_empty(): return {"ok": true, "changed": false}
	if bool(JsonCoerceScript._copy_dict(source.get("local_narrative_flags", {})).get("environment_test_session", false)):
		return {"ok": true, "changed": false}
	var archetype := _archetype_by_id(archetype_id)
	var now := run_state.game_clock_minutes
	var cycle := EnvironmentHours.scenario_cycle_status(archetype, now)
	var record := run_state.environment_situation_cycle(archetype_id)
	var phase := "active" if bool(cycle.active) else "closed"
	var stamp := str(source.get(ENVIRONMENT_SITUATION_CYCLE_KEY, ""))
	# Town-wide priming can close this selection before its stored room is
	# revisited. The opening stamp stays the same at close, so the global phase
	# alone cannot prove that every retained room body has retired its scenario.
	if stamp == str(cycle.cycle_id) and int(record.get("schedule_version", 0)) == 1 and str(record.get("phase", "")) == phase \
			and (bool(cycle.active) or not _venue_cycle_room_has_retained_scenario(source)):
		return {"ok": true, "changed": false}
	var old_cycle := ScenarioVenueCycleScript.cycle_for_existing_room(source, archetype, now)
	# Adopt a legacy accepted situation only while its recorded opening is still
	# current. Closed/dead-zone and elapsed-cycle saves retire before rendering.
	if int(record.get("schedule_version", 0)) != 1 and bool(cycle.active) and str(old_cycle.cycle_id) == str(cycle.cycle_id):
		source[ENVIRONMENT_SITUATION_CYCLE_KEY] = cycle.cycle_id
		record.merge({"cycle_id": cycle.cycle_id, "scenario_id": str(source.get("scenario_id", "")), "schedule_version": 1,
			"phase": phase, "opened_at": cycle.opened_at, "closes_at": cycle.closes_at}, true)
		run_state.environment_situation_cycles_by_node[archetype_id] = record
		return {"ok": true, "changed": true, "adopted_legacy": true}
	# A lazy destination is temporarily current, but failed installation must
	# restore the actual source context (including its room-scoped Heat), not
	# normalize the player's economy against an unaccepted destination.
	if not rollback_source_environment.is_empty(): run_state.current_environment = rollback_source_environment
	var rollback := _travel_rollback_snapshot(run_state)
	run_state.current_environment = source
	var result := _refresh_venue_scenario_cycle_candidate(run_state, archetype, cycle, old_cycle, record)
	if not bool(result.get("ok", false)):
		_restore_travel_snapshot(run_state, rollback)
		return result
	var candidate := run_state.current_environment
	# Retain canonical aliases used by Grand room storage and world snapshots.
	source.clear(); source.merge(candidate, true); run_state.current_environment = source
	if persist_world_room:
		run_state.store_current_world_node_environment()
		run_state.store_grand_casino_room_environment(source)
	return {"ok": true, "changed": true, "phase": phase, "cycle_id": cycle.cycle_id, "scenario_id": source.get("scenario_id", "")}


func _venue_cycle_room_has_retained_scenario(environment: Dictionary) -> bool:
	var rooms: Array = [environment]
	var current_layer := str(environment.get("current_layer_id", "room"))
	var layers := JsonCoerceScript._copy_dict(environment.get("layer_states", {}))
	for layer_value in layers.keys():
		# The exposed body is authoritative for its current layer, just as in the
		# retirement transaction below; its stored mirror may predate that body.
		if str(layer_value) != current_layer:
			rooms.append(JsonCoerceScript._copy_dict(layers[layer_value]))
	for room_value in rooms:
		var room: Dictionary = room_value
		if not str(room.get("scenario_id", "")).strip_edges().is_empty() \
				or not JsonCoerceScript._copy_dict(room.get("scenario_state", {})).is_empty() \
				or not JsonCoerceScript._copy_dict(room.get("scenario_sequence_state", {})).is_empty():
			return true
	return false


func _refresh_venue_scenario_cycle_candidate(run_state: RunState, archetype: Dictionary, cycle: Dictionary, old_cycle: Dictionary, record: Dictionary) -> Dictionary:
	var source := run_state.current_environment.duplicate(true)
	var archetype_id := str(source.get("archetype_id", ""))
	var node_id := str(source.get("world_node_id", archetype_id))
	var current_layer := str(source.get("current_layer_id", "room"))
	var rooms := JsonCoerceScript._copy_dict(source.get("layer_states", {}))
	var current_body := source.duplicate(true); current_body.erase("layer_states")
	rooms[current_layer] = current_body
	var history := JsonCoerceScript._copy_dict(record.get("history", {}))
	var profiles := JsonCoerceScript._copy_dict(record.get("base_profiles", {}))
	var base_rooms: Dictionary = {}
	var layer_keys := rooms.keys(); layer_keys.sort()
	for layer_value in layer_keys:
		var layer := str(layer_value)
		var room := JsonCoerceScript._copy_dict(rooms[layer])
		# Keep the existing missing-key legacy fallback, but never clear retained
		# authority when neither the explicit identity nor that fallback resolves.
		var legacy_state := JsonCoerceScript._copy_dict(room.get("scenario_state", {}))
		var definition_id := str(room.get("scenario_id", legacy_state.get("id", ""))).strip_edges()
		if definition_id.is_empty() and (not legacy_state.is_empty() or not JsonCoerceScript._copy_dict(room.get("scenario_sequence_state", {})).is_empty()):
			return {"ok": false, "errors": ["Retiring room retains scenario authority without an exact scenario identity."]}
		var definition := library._runtime_validated_scenario_definition(library._scenario_readonly(definition_id)) if not definition_id.is_empty() else {}
		run_state.current_environment = room
		if not definition_id.is_empty():
			# Rebuild saved causal authority before invoking its authored cleanup.
			# The town's selection already belongs to the NEW cycle. Retirement
			# must authenticate the saved room against its own exact old catalog
			# definition, without reseeding the town or replaying its selector.
			if definition.is_empty() or not run_state.cache_runtime_scenario_definition(definition):
				return {"ok": false, "errors": ["Retiring scenario %s has no validated catalog definition." % definition_id]}
			var before := run_state.scenario_finalize_installed_environment(library)
			if not bool(before.get("ok", false)): return before
			room = run_state.current_environment
			var retired := ScenarioVenueCycleScript.retirement_record(room, definition, old_cycle, run_state.game_clock_minutes)
			if not bool(retired.get("ok", false)): return retired
			var retirement := JsonCoerceScript._copy_dict(retired.get("record", {}))
			var history_key := "%s|%s" % [str(old_cycle.cycle_id), layer]
			if history.has(history_key) and str(JsonCoerceScript._copy_dict(history[history_key]).get("source_fingerprint", "")) != str(retirement.get("source_fingerprint", "")):
				return {"ok": false, "errors": ["Venue retirement journal conflicts with accepted scenario history."]}
			if not history.has(history_key): history[history_key] = retirement
		var flat := EnvironmentInstance._archetype_for_layer(archetype, layer) if layer != "room" else archetype
		var tutorial_layer := _prepare_legacy_tutorial_layer_for_cycle(run_state, room, flat)
		if not bool(tutorial_layer.get("ok", false)): return tutorial_layer
		var base := ScenarioVenueCycleScript.clear_scenario(room, flat, JsonCoerceScript._copy_dict(profiles.get(layer, {})))
		profiles[layer] = ScenarioVenueCycleScript.base_profiles(base)
		base[ENVIRONMENT_SITUATION_CYCLE_KEY] = cycle.cycle_id
		base_rooms[layer] = base
	# A nonempty prior record prevents the legacy-seed compatibility branch from
	# reusing an expired selection. The ordinary selector owns its new RNG lease.
	record.merge({"history": history, "base_profiles": profiles}, true)
	# _prime_town_scenarios may already have selected this opening's situation.
	# Keep that selection (including None) instead of rolling again with a changed
	# recent-scenario history when a previously visited room is retired lazily.
	if str(record.get("cycle_id", "")) != str(cycle.cycle_id):
		record.merge({"cycle_id": "retired:%s" % str(old_cycle.cycle_id), "scenario_id": "", "schedule_version": 1,
			"phase": "closed", "opened_at": cycle.opened_at, "closes_at": cycle.closes_at}, true)
	run_state.environment_situation_cycles_by_node[archetype_id] = record
	var selected: Dictionary = {}
	if bool(cycle.active):
		var rng := RngStream.new(); rng.configure(run_state.seed_value, run_state.seed_value)
		selected = _select_scenario(run_state, archetype_id, rng)
		if not selected.is_empty():
			run_state.seed_scenario_for_node(node_id, selected)
			run_state.cache_runtime_scenario_definition(selected)
	else:
		_remember_scenario_situation(run_state, archetype_id, str(cycle.cycle_id), "")
	record = run_state.environment_situation_cycle(archetype_id).duplicate(true)
	record.merge({"schedule_version": 1, "phase": "active" if bool(cycle.active) else "closed", "opened_at": cycle.opened_at, "closes_at": cycle.closes_at}, true)
	run_state.environment_situation_cycles_by_node[archetype_id] = record
	var finished: Dictionary = {}
	for layer_value in layer_keys:
		var layer := str(layer_value)
		var room := JsonCoerceScript._copy_dict(base_rooms[layer])
		var flat := EnvironmentInstance._archetype_for_layer(archetype, layer) if layer != "room" else archetype
		ScenarioVenueCycleScript.attach(room, selected, flat)
		if bool(room.get("world_map_travel", false)):
			_apply_world_travel_targets(room, run_state, run_state.world_map, node_id)
		_apply_scenario_sequence_travel_targets(room, selected)
		run_state.current_environment = room
		run_state.reconcile_current_environment_object_manifest(true)
		var membership_errors := EnvironmentInstance.object_manifest_errors(run_state.current_environment)
		if not membership_errors.is_empty(): return {"ok": false, "errors": membership_errors}
		var finalized := run_state.scenario_finalize_installed_environment(library)
		if not bool(finalized.get("ok", false)): return finalized
		finished[layer] = run_state.current_environment
	var final := JsonCoerceScript._copy_dict(finished[current_layer])
	if source.has("layer_states"): final["layer_states"] = finished
	run_state.current_environment = final
	return {"ok": true, "errors": []}


func _prepare_legacy_tutorial_layer_for_cycle(run_state: RunState, room: Dictionary, archetype: Dictionary) -> Dictionary:
	# Old tutorial generation copied the configured Casino game's override onto
	# inactive floors too. Retire only that exact, never-played accidental table
	# when the authored floor has no games. This happens inside the existing cycle
	# transaction: publication failure restores the complete incoming room/run.
	if not run_state.is_tutorial_run() or not JsonCoerceScript._copy_array(archetype.get("game_pool", [])).is_empty():
		return {"ok": true}
	var modifiers := JsonCoerceScript._copy_dict(run_state.challenge_config.get("modifiers", {}))
	var archetype_id := str(room.get("archetype_id", ""))
	var layer := str(room.get("current_layer_id", ""))
	var target := str(JsonCoerceScript._copy_dict(modifiers.get("environment_layer_overrides", {})).get(archetype_id, ""))
	if layer.is_empty() or target.is_empty() or layer == target:
		return {"ok": true}
	var override := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(modifiers.get("tutorial_environment_overrides", {})).get(archetype_id, {}))
	var injected := JsonCoerceScript._raw_string_array(override.get("game_pool", []))
	var games := JsonCoerceScript._raw_string_array(room.get("game_ids", []))
	if injected.is_empty() or games != injected or not str(room.get("scenario_id", "")).is_empty() \
			or not JsonCoerceScript._copy_dict(room.get("scenario_state", {})).is_empty() \
			or room.has("scenario_sequence_state"):
		return {"ok": true}
	# Authenticate before the owned membership change. Never bless edited slot or
	# manifest proofs, and never discard a historical hand, stake or game result.
	var errors := EnvironmentInstance.object_manifest_errors(room)
	errors.append_array(JsonCoerceScript._copy_array(EnvironmentSlotBinderScript.validate_base_layout_authority(room).get("errors", [])))
	if not errors.is_empty(): return {"ok": false, "errors": errors}
	var stored_games: Variant = room.get("game_states", {})
	if typeof(stored_games) != TYPE_DICTIONARY or not (stored_games as Dictionary).is_empty():
		return {"ok": false, "errors": ["Off-layer tutorial table has stored play state; its game state was preserved."]}
	room["game_ids"] = []
	return {"ok": true}


func _stored_environment_matches_situation_cycle(run_state: RunState, archetype_id: String, environment: Dictionary) -> bool:
	if library == null or library._scenarios_for_archetype_readonly(archetype_id).is_empty():
		return true
	var stored_cycle := str(environment.get(ENVIRONMENT_SITUATION_CYCLE_KEY, "")).strip_edges()
	if stored_cycle.is_empty():
		# Older layer handoffs dropped the top-level stamp while the retained
		# source floor still carried it. Recover only an unambiguous stamp from
		# this exact venue; never rebind scenario identity or edit saved progress.
		var layers_value: Variant = environment.get("layer_states", {})
		if typeof(layers_value) == TYPE_DICTIONARY:
			for layer_value in (layers_value as Dictionary).values():
				if typeof(layer_value) != TYPE_DICTIONARY:
					continue
				var layer: Dictionary = layer_value
				if str(layer.get("archetype_id", "")) != str(environment.get("archetype_id", archetype_id)) \
					or str(layer.get("world_node_id", "")) != archetype_id:
					continue
				var layer_cycle := str(layer.get(ENVIRONMENT_SITUATION_CYCLE_KEY, "")).strip_edges()
				if layer_cycle.is_empty():
					continue
				if not stored_cycle.is_empty() and stored_cycle != layer_cycle:
					return true
				stored_cycle = layer_cycle
	# Existing saves predate cycle metadata. Preserve their room once and stamp it
	# on restoration instead of silently deleting in-progress player state.
	if stored_cycle.is_empty():
		return true
	return stored_cycle == _environment_situation_cycle_id(run_state, archetype_id)


func _apply_world_travel_targets(environment_data: Dictionary, run_state: RunState, map_data: Dictionary, node_id: String) -> void:
	var targets := _world_travel_target_ids(run_state, map_data, node_id)
	for local_target_id in _grand_casino_local_target_ids(environment_data):
		if not targets.has(local_target_id):
			targets.append(local_target_id)
	environment_data["next_archetypes"] = targets.duplicate(true)
	environment_data["travel_hooks"] = targets.duplicate(true)
	environment_data["world_map_travel"] = true


# A sequence may deliberately retarget an authored base route during its
# aftermath. World-map generation replaces an archetype's static route list
# with its current graph neighbors, so retain every exact base route that the
# selected sequence declares before sealing semantic inventory and layout.
# Every town node exists in the generated map; this only makes the scenario's
# explicitly authored route reachable from its host node.
func _apply_scenario_sequence_travel_targets(environment_data: Dictionary, definition: Dictionary) -> void:
	if not ScenarioSequenceSchemaScript.is_sequence(definition):
		return
	var sequence := ScenarioSequenceSchemaScript.sequence(definition)
	var declared := JsonCoerceScript._copy_dict(sequence.get("declared_targets", {}))
	var targets := JsonCoerceScript._raw_string_array(environment_data.get("next_archetypes", []))
	for identity_value in JsonCoerceScript._copy_array(declared.get("routes", [])):
		var identity := str(identity_value).strip_edges()
		if not identity.begins_with("base::world:"):
			continue
		var route_id := identity.trim_prefix("base::world:").strip_edges()
		if route_id.is_empty() or library == null or library.route(route_id).is_empty():
			continue
		if not targets.has(route_id):
			targets.append(route_id)
	environment_data["next_archetypes"] = targets.duplicate(true)
	environment_data["travel_hooks"] = targets.duplicate(true)


func _grand_casino_local_target_ids(environment_data: Dictionary) -> Array:
	var local_flags: Dictionary = environment_data.get("local_narrative_flags", {}) if typeof(environment_data.get("local_narrative_flags", {})) == TYPE_DICTIONARY else {}
	var result: Array = []
	for target_id_value in local_flags.get("casino_room_targets", []):
		var target_id := str(target_id_value).strip_edges()
		if not target_id.is_empty() and RunState.GRAND_CASINO_ARCHETYPE_IDS.has(target_id) and not result.has(target_id):
			result.append(target_id)
	return result


# Sequence initialization captures the authored room before world-map travel
# replaces its static per-destination doors with the single map exit. Keep that
# immutable baseline for games/services/events, but reconcile its travel subset
# to the final world-room layout so stale route hotspots cannot reject arrival.
func _align_world_map_scenario_layout_baseline(environment_data: Dictionary) -> void:
	if not bool(environment_data.get("world_map_travel", false)) or not environment_data.has("scenario_sequence_base_layout_object_rects"):
		return
	var baseline_rects := JsonCoerceScript._copy_dict(environment_data.get("scenario_sequence_base_layout_object_rects", {}))
	var final_rects := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(environment_data.get("layout", {})).get("object_rects", {}))
	var allowed_travel_ids := {"travel:leave": true}
	for target_id_value in _grand_casino_local_target_ids(environment_data):
		allowed_travel_ids["travel:%s" % str(target_id_value)] = true
	for object_id_value in baseline_rects.keys():
		var object_id := str(object_id_value)
		if object_id.begins_with("travel:") and not allowed_travel_ids.has(object_id):
			baseline_rects.erase(object_id_value)
	for object_id_value in allowed_travel_ids.keys():
		var object_id := str(object_id_value)
		if final_rects.has(object_id):
			baseline_rects[object_id] = JsonCoerceScript._copy_dict(final_rects.get(object_id, {}))
		else:
			baseline_rects.erase(object_id)
	environment_data["scenario_sequence_base_layout_object_rects"] = baseline_rects


func _fallback_world_neighbor(run_state: RunState, map_data: Dictionary, source_id: String) -> String:
	var travel_targets := _available_world_travel_target_ids(run_state, map_data, source_id)
	if not travel_targets.is_empty():
		return str(travel_targets[0])
	return ""


func _world_travel_target_ids(run_state: RunState, map_data: Dictionary, source_id: String) -> Array:
	var option_bonus := run_state.travel_option_bonus()
	return WorldMap.travel_target_ids(map_data, source_id, WorldMap.TRAVEL_NEW_TARGET_LIMIT + option_bonus, WorldMap.TRAVEL_TOTAL_TARGET_LIMIT + option_bonus, _enabled_world_route_ids(run_state, map_data, source_id))


func _available_world_travel_target_ids(run_state: RunState, map_data: Dictionary, source_id: String) -> Array:
	var option_bonus := run_state.travel_option_bonus()
	return WorldMap.travel_target_ids(map_data, source_id, WorldMap.TRAVEL_NEW_TARGET_LIMIT + option_bonus, WorldMap.TRAVEL_TOTAL_TARGET_LIMIT + option_bonus, _available_world_route_ids(run_state, map_data, source_id))


func _world_target_is_available(run_state: RunState, map_data: Dictionary, source_id: String, target_id: String) -> bool:
	if not _world_travel_target_ids(run_state, map_data, source_id).has(target_id):
		return false
	var map := WorldMap.new(library)
	var route := map.route_for_target(map_data, source_id, target_id)
	if route.is_empty():
		return false
	var status := run_state.travel_route_status(route)
	if not bool(status.get("available", false)) or bool(status.get("hidden", false)) or bool(status.get("locked", false)):
		return false
	var archetype := _archetype_by_id(target_id)
	var arrival_minute := (run_state.game_minute_of_day() + maxi(1, int(route.get("distance_blocks", 1))) * 6) % EnvironmentHours.MINUTES_PER_DAY
	return TutorialFlowScript.environment_open_at(run_state, archetype, arrival_minute)


func _enabled_world_route_ids(run_state: RunState, map_data: Dictionary, source_id: String) -> Array:
	return _world_route_ids(run_state, map_data, source_id, true)


func _available_world_route_ids(run_state: RunState, map_data: Dictionary, source_id: String) -> Array:
	return _world_route_ids(run_state, map_data, source_id, false)


func _world_route_ids(run_state: RunState, map_data: Dictionary, source_id: String, include_locked: bool) -> Array:
	var result: Array = []
	if run_state == null:
		return result
	var map := WorldMap.new(library)
	for target_id_value in WorldMap.visible_node_ids(map_data):
		var target_id := str(target_id_value)
		if target_id == source_id or not WorldMap.has_path(map_data, source_id, target_id, true):
			continue
		var route := map.route_for_target(map_data, source_id, target_id)
		if route.is_empty():
			continue
		var archetype := _archetype_by_id(target_id)
		var arrival_minute := (run_state.game_minute_of_day() + maxi(1, int(route.get("distance_blocks", 1))) * 6) % EnvironmentHours.MINUTES_PER_DAY
		if not TutorialFlowScript.environment_open_at(run_state, archetype, arrival_minute):
			continue
		var status := run_state.travel_route_status(route)
		if not bool(status.get("hidden", false)) and (bool(status.get("available", true)) or (include_locked and bool(status.get("locked", false)))):
			result.append(target_id)
	return result


# Picks the starting, routed, or tier fallback archetype.
func _pick_archetype(run_state: RunState, depth: int, rng: RngStream, target_archetype_id: String = "") -> Dictionary:
	if depth == 0:
		var selected_home := run_state.selected_home_archetype_id()
		if selected_home != RunState.HOME_SELECTION_RANDOM:
			var selected_archetype := _archetype_by_id(selected_home)
			if not selected_archetype.is_empty():
				return selected_archetype
		var starts := _start_archetypes()
		var shop_starts := _archetypes_with_shop_items(starts, true, run_state.challenge_config)
		if not shop_starts.is_empty():
			return rng.pick(shop_starts, {})
		var shop_tier_one := _archetypes_with_shop_items(library.archetypes_for(1), false, run_state.challenge_config)
		if not shop_tier_one.is_empty():
			return rng.pick(shop_tier_one, {})
		var playable_starts := _archetypes_with_games(starts, true, run_state.challenge_config)
		if not playable_starts.is_empty():
			return rng.pick(playable_starts, {})
		var playable_tier_one := _archetypes_with_games(library.archetypes_for(1), false, run_state.challenge_config)
		if not playable_tier_one.is_empty():
			return rng.pick(playable_tier_one, {})
		if not starts.is_empty():
			return rng.pick(starts, {})

	var next_ids: Array = []
	for routed_id in JsonCoerceScript._copy_array(run_state.current_environment.get("next_archetypes", [])) + JsonCoerceScript._copy_array(run_state.current_environment.get("travel_hooks", [])):
		var clean_routed_id := str(routed_id).strip_edges()
		if not clean_routed_id.is_empty() and not next_ids.has(clean_routed_id):
			next_ids.append(clean_routed_id)
	if not target_archetype_id.is_empty() and next_ids.has(target_archetype_id):
		var target := _archetype_by_id(target_archetype_id)
		if not target.is_empty():
			return target

	var routed := _archetypes_by_id(next_ids)
	if not routed.is_empty():
		return _weighted_pick_archetype(routed, rng)

	var tier := clampi(depth + 1, 1, 4)
	return _weighted_pick_archetype(library.archetypes_for(tier), rng)


# Returns archetypes marked as valid run starts.
func _start_archetypes() -> Array:
	var starts: Array = []
	for archetype in library.environment_archetypes:
		if bool(archetype.get("is_start", false)):
			starts.append(archetype)
	return starts


# Returns shop archetypes that can offer items before the first wager.
func _archetypes_with_shop_items(archetypes: Array, include_rare: bool = true, challenge_config: Dictionary = {}) -> Array:
	var matches: Array = []
	for archetype in archetypes:
		if typeof(archetype) != TYPE_DICTIONARY:
			continue
		var data: Dictionary = archetype
		if str(data.get("kind", "")) != "shop":
			continue
		var filtered_item_pool := library.shop_item_pool_for_challenge(data.get("item_pool", []), challenge_config) if library != null else JsonCoerceScript._raw_string_array(data.get("item_pool", []))
		if filtered_item_pool.is_empty():
			continue
		if _count_ceiling(data.get("item_count", 0)) <= 0:
			continue
		if not include_rare and str(data.get("rarity", "")).to_lower() == "rare":
			continue
		matches.append(data)
	return matches


# Returns archetypes with at least one game option.
func _archetypes_with_games(archetypes: Array, include_rare: bool = true, challenge_config: Dictionary = {}) -> Array:
	var matches: Array = []
	for archetype in archetypes:
		if typeof(archetype) != TYPE_DICTIONARY:
			continue
		var data: Dictionary = archetype
		var filtered_game_pool := library.filter_game_ids_for_challenge(data.get("game_pool", []), challenge_config) if library != null else JsonCoerceScript._raw_string_array(data.get("game_pool", []))
		if filtered_game_pool.is_empty():
			continue
		if not include_rare and str(data.get("rarity", "")).to_lower() == "rare":
			continue
		matches.append(data)
	return matches


# Returns archetypes matching a list of ids.
func _archetypes_by_id(ids: Array) -> Array:
	var matches: Array = []
	for archetype in library.environment_archetypes:
		if ids.has(archetype.get("id", "")):
			matches.append(archetype)
	return matches


# Returns one archetype matching an id.
func _archetype_by_id(id: String) -> Dictionary:
	for archetype in library.environment_archetypes:
		if archetype.get("id", "") == id:
			return archetype
	return {}


func _prime_town_scenarios(run_state: RunState, map_data: Dictionary) -> void:
	_world_scenario_prime_stages_usec = {}
	_world_scenario_select_stages_usec = {}
	if run_state == null or library == null:
		return
	var node_ids: Array = []
	var nodes_value: Variant = map_data.get("nodes", [])
	if typeof(nodes_value) != TYPE_ARRAY:
		return
	for node_value in nodes_value as Array:
		if typeof(node_value) != TYPE_DICTIONARY:
			continue
		var node_id := str((node_value as Dictionary).get("id", "")).strip_edges()
		if not node_id.is_empty():
			node_ids.append(node_id)
	node_ids.sort()
	for node_id_value in node_ids:
		var node_id := str(node_id_value)
		var perf_node_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
		var scenario_rng := run_state.create_rng("town_scenario_seed:%s" % node_id)
		var perf_rng_finished_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
		var scenario := _select_scenario(run_state, node_id, scenario_rng, false)
		var perf_select_finished_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
		if not scenario.is_empty():
			run_state.seed_scenario_for_node(node_id, scenario)
		if _world_environment_timing_enabled:
			_world_scenario_prime_stages_usec[node_id] = {
				"rng": perf_rng_finished_usec - perf_node_started_usec,
				"select": perf_select_finished_usec - perf_rng_finished_usec,
				"seed": Time.get_ticks_usec() - perf_select_finished_usec,
				"select_stages": _world_scenario_select_stages_usec.get(node_id, {}),
			}


func _remember_scenario_situation(run_state: RunState, archetype_id: String, cycle_id: String, scenario_id: String) -> void:
	run_state.remember_environment_situation_cycle(archetype_id, cycle_id, scenario_id)
	var record := run_state.environment_situation_cycle(archetype_id).duplicate(true)
	var cycle := EnvironmentHours.scenario_cycle_status(_archetype_by_id(archetype_id), run_state.game_clock_minutes)
	record.merge({"schedule_version": 1, "phase": "active" if bool(cycle.active) else "closed", "opened_at": cycle.opened_at, "closes_at": cycle.closes_at}, true)
	run_state.environment_situation_cycles_by_node[archetype_id] = record


func _select_scenario(run_state: RunState, archetype_id: String, rng: RngStream, validate_runtime: bool = true) -> Dictionary:
	var perf_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
	var perf_stage_usec := perf_started_usec
	var perf_stages: Dictionary = {}
	if run_state == null or library == null or rng == null:
		return {}
	var modifiers := JsonCoerceScript._copy_dict(run_state.challenge_config.get("modifiers", {}))
	var pins := JsonCoerceScript._copy_dict(modifiers.get("scenario_pins", {}))
	var pinned_id := str(pins.get(archetype_id, "")).strip_edges()
	var tutorial_overrides := JsonCoerceScript._copy_dict(modifiers.get("tutorial_environment_overrides", {}))
	if _world_environment_timing_enabled:
		perf_stages["modifiers"] = Time.get_ticks_usec() - perf_stage_usec
		perf_stage_usec = Time.get_ticks_usec()
	var pool := library._scenarios_for_archetype_readonly(archetype_id)
	if _world_environment_timing_enabled:
		perf_stages["pool"] = Time.get_ticks_usec() - perf_stage_usec
		perf_stage_usec = Time.get_ticks_usec()
	if pool.is_empty():
		if _world_environment_timing_enabled:
			_world_scenario_select_stages_usec[archetype_id] = perf_stages
		return {}
	var cycle_id := _environment_situation_cycle_id(run_state, archetype_id)
	if not bool(EnvironmentHours.scenario_cycle_status(_archetype_by_id(archetype_id), run_state.game_clock_minutes).get("active", false)):
		_remember_scenario_situation(run_state, archetype_id, cycle_id, "")
		return {}
	var lifecycle := run_state.environment_situation_cycle(archetype_id)
	if str(lifecycle.get("cycle_id", "")) == cycle_id:
		var retained_id := str(lifecycle.get("scenario_id", "")).strip_edges()
		if retained_id.is_empty():
			return {}
		return _scenario_definition_from_pool(run_state, archetype_id, retained_id, pool, validate_runtime)
	# Saves made before cycle tracking retain their active situation once. New
	# cycles below always roll independently, including the empty result.
	if lifecycle.is_empty():
		var legacy_seeded := run_state._seeded_scenario_definition_for_node_readonly(archetype_id)
		var legacy_id := str(legacy_seeded.get("id", "")).strip_edges()
		if not legacy_id.is_empty():
			_remember_scenario_situation(run_state, archetype_id, cycle_id, legacy_id)
			var resolved_legacy := library._runtime_validated_scenario_definition(legacy_seeded) if validate_runtime else legacy_seeded
			return _apply_scenario_pin_suppression(run_state, archetype_id, resolved_legacy)
	# Tutorial overrides author the complete room unless explicitly pinned.
	if tutorial_overrides.has(archetype_id) and pinned_id.is_empty():
		_remember_scenario_situation(run_state, archetype_id, cycle_id, "")
		return {}
	if not pinned_id.is_empty():
		for definition_value in pool:
			if typeof(definition_value) != TYPE_DICTIONARY:
				continue
			var pinned: Dictionary = definition_value
			if str(pinned.get("id", "")) == pinned_id:
				run_state.remember_scenario_selection(archetype_id, pinned_id)
				_remember_scenario_situation(run_state, archetype_id, cycle_id, pinned_id)
				var resolved_pinned := library._runtime_validated_scenario_definition(pinned) if validate_runtime else library._runtime_scenario_definition_unvalidated(pinned)
				return _apply_scenario_pin_suppression(run_state, archetype_id, resolved_pinned)
		_remember_scenario_situation(run_state, archetype_id, cycle_id, "")
		return {}
	var excludes := JsonCoerceScript._copy_dict(modifiers.get("scenario_excludes", {}))
	var excluded_ids := JsonCoerceScript._raw_string_array(excludes.get(archetype_id, []))
	var candidates: Array = []
	for definition_value in pool:
		if typeof(definition_value) != TYPE_DICTIONARY:
			continue
		var definition: Dictionary = definition_value
		var scenario_id := str(definition.get("id", "")).strip_edges()
		if scenario_id.is_empty() or excluded_ids.has(scenario_id):
			continue
		candidates.append(definition)
	if candidates.is_empty():
		_remember_scenario_situation(run_state, archetype_id, cycle_id, "")
		return {}
	# Situation identity belongs to the venue cycle, not to whichever unrelated
	# RNG-consuming UI preview or travel-risk check happened immediately before it.
	var situation_rng := RngStream.new()
	situation_rng.configure(run_state.seed_value, run_state.seed_value)
	situation_rng = situation_rng.fork("environment_situation:%s:%s" % [archetype_id, cycle_id])
	if situation_rng.randi_range(1, 100) <= ENVIRONMENT_SITUATION_NONE_PERCENT:
		_remember_scenario_situation(run_state, archetype_id, cycle_id, "")
		return {}
	var recent := run_state.recent_scenario_ids(archetype_id)
	if _world_environment_timing_enabled:
		perf_stages["candidates"] = Time.get_ticks_usec() - perf_stage_usec
		perf_stage_usec = Time.get_ticks_usec()
	var weighted: Array = []
	var total_weight := 0
	for definition_value in candidates:
		var definition: Dictionary = definition_value
		var scenario_id := str(definition.get("id", ""))
		var repeat_multiplier := 1.0
		var recent_index := recent.find(scenario_id)
		if recent_index == 0 and candidates.size() > 1:
			repeat_multiplier = 0.0
		elif recent_index == 1:
			repeat_multiplier = 0.35
		elif recent_index >= 2:
			repeat_multiplier = 0.60
		var town_multiplier := 1.0
		if run_state.has_method("scenario_weight_multiplier"):
			town_multiplier = maxf(0.0, float(run_state.call("scenario_weight_multiplier", archetype_id, scenario_id, JsonCoerceScript._raw_string_array(definition.get("town_weight_tags", [])))))
		var scaled_weight := maxi(0, int(round(float(definition.get("weight", 1.0)) * repeat_multiplier * town_multiplier * 1000.0)))
		if scaled_weight <= 0:
			continue
		total_weight += scaled_weight
		weighted.append({"definition": definition, "ceiling": total_weight})
	if weighted.is_empty() or total_weight <= 0:
		_remember_scenario_situation(run_state, archetype_id, cycle_id, "")
		return {}
	if _world_environment_timing_enabled:
		perf_stages["weights"] = Time.get_ticks_usec() - perf_stage_usec
		perf_stage_usec = Time.get_ticks_usec()
	var roll := situation_rng.randi_range(1, total_weight)
	var selected: Dictionary = weighted[weighted.size() - 1].get("definition", {})
	for entry_value in weighted:
		var entry: Dictionary = entry_value
		if roll <= int(entry.get("ceiling", total_weight)):
			selected = entry.get("definition", {})
			break
	var selected_id := str(selected.get("id", ""))
	run_state.remember_scenario_selection(archetype_id, selected_id)
	_remember_scenario_situation(run_state, archetype_id, cycle_id, selected_id)
	if _world_environment_timing_enabled:
		perf_stages["choose"] = Time.get_ticks_usec() - perf_stage_usec
		perf_stage_usec = Time.get_ticks_usec()
	var resolved_selected := library._runtime_validated_scenario_definition(selected) if validate_runtime else library._runtime_scenario_definition_unvalidated(selected)
	if _world_environment_timing_enabled:
		perf_stages["resolve"] = Time.get_ticks_usec() - perf_stage_usec
		perf_stages["total"] = Time.get_ticks_usec() - perf_started_usec
		_world_scenario_select_stages_usec[archetype_id] = perf_stages
	# Both resolution paths return an owned or immutable canonical definition.
	# Generation only reads it, and town seeding owns its outer record, so another
	# recursive copy here doubled the largest first-travel scenario payloads.
	return resolved_selected


func _scenario_definition_from_pool(run_state: RunState, archetype_id: String, scenario_id: String, pool: Array, validate_runtime: bool) -> Dictionary:
	for definition_value in pool:
		if typeof(definition_value) != TYPE_DICTIONARY:
			continue
		var definition: Dictionary = definition_value
		if str(definition.get("id", "")) != scenario_id:
			continue
		var resolved := library._runtime_validated_scenario_definition(definition) if validate_runtime else library._runtime_scenario_definition_unvalidated(definition)
		return _apply_scenario_pin_suppression(run_state, archetype_id, resolved)
	return {}


func _apply_scenario_pin_suppression(run_state: RunState, archetype_id: String, definition: Dictionary) -> Dictionary:
	var result := definition.duplicate(true)
	if run_state == null:
		return result
	var scenario_id := str(result.get("id", "")).strip_edges()
	if scenario_id.is_empty():
		scenario_id = str(JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(run_state.challenge_config.get("modifiers", {})).get("scenario_pins", {})).get(archetype_id, "")).strip_edges()
	if not run_state.scenario_sequence_is_suppressed(scenario_id, archetype_id):
		return result
	if result.is_empty():
		result = {"id": scenario_id, "archetype_id": archetype_id}
	# Challenge authors may pin the name of tonight without letting its legacy
	# mutations, phases, or dynamic sequence disturb a controlled environment.
	result["mutations"] = {}
	result["phases"] = []
	return ScenarioEngineScript.suppress_sequence_definition(result)


# Picks one archetype while respecting optional low-weight rare venues.
func _weighted_pick_archetype(archetypes: Array, rng: RngStream) -> Dictionary:
	var weighted: Array = []
	for archetype_value in archetypes:
		if typeof(archetype_value) != TYPE_DICTIONARY:
			continue
		var archetype: Dictionary = archetype_value
		var weight := maxi(1, int(archetype.get("spawn_weight", 10)))
		if str(archetype.get("rarity", "")).to_lower() == "rare" and not archetype.has("spawn_weight"):
			weight = 1
		var remaining := weight
		while remaining > 0:
			weighted.append(archetype)
			remaining -= 1
	return rng.pick(weighted, {})


func _apply_home_profile(run_state: RunState, environment_data: Dictionary, archetype: Dictionary, node_id: String, rng: RngStream) -> void:
	var effective_archetype := library.environment_archetype_for_challenge(archetype, run_state.challenge_config) if library != null else archetype
	var profile := JsonCoerceScript._copy_dict(environment_data.get("home_profile", effective_archetype.get("home_profile", {})))
	if profile.is_empty():
		return
	run_state.initialize_home_from_profile(effective_archetype, node_id, profile)
	var cash_range := _int_range(profile.get("starting_cash", [RunState.DEFAULT_BANKROLL, RunState.DEFAULT_BANKROLL]), RunState.DEFAULT_BANKROLL, RunState.DEFAULT_BANKROLL)
	var starting_cash := rng.randi_range(int(cash_range[0]), int(cash_range[1]))
	run_state.change_bankroll(starting_cash - run_state.bankroll)
	var starting_pool := _home_starting_item_pool(profile, run_state.challenge_config)
	var starting_item_offers := _home_starting_item_offers(profile, starting_pool, rng)
	var containers := _meta_collection_starting_containers(run_state.challenge_config)
	if containers.is_empty():
		containers = _home_starting_containers(profile, starting_pool, rng)
	environment_data["home_profile"] = profile.duplicate(true)
	environment_data["item_offers"] = starting_item_offers
	environment_data["home_containers"] = containers
	environment_data["home_container_index"] = containers.size()
	environment_data["home_lost"] = false


func _home_starting_item_offers(profile: Dictionary, starting_pool: Array, rng: RngStream) -> Array:
	var offers: Array = []
	var starting_items_count := maxi(0, int(profile.get("starting_items", 0)))
	for item_id_value in rng.pick_many(starting_pool, starting_items_count):
		var item_id := str(item_id_value).strip_edges()
		if item_id.is_empty():
			continue
		var definition: Dictionary = library.item(item_id) if library != null else {}
		offers.append({
			"id": item_id,
			"display_name": str(definition.get("display_name", item_id.replace("_", " ").capitalize())),
			"price": 0,
			"pickup": true,
			"source": "home_start",
		})
	return offers


func _home_starting_item_pool(profile: Dictionary, challenge_config: Dictionary) -> Array:
	var pool := JsonCoerceScript._raw_string_array(profile.get("starting_item_pool", []))
	if pool.is_empty():
		if library == null:
			return pool
		for item_value in library.items:
			if typeof(item_value) != TYPE_DICTIONARY:
				continue
			var item: Dictionary = item_value
			var item_id := str(item.get("id", "")).strip_edges()
			if item_id.is_empty():
				continue
			var item_class := str(item.get("class", "")).strip_edges().to_lower()
			if item_class == "container":
				continue
			pool.append(item_id)
	if library != null:
		pool = library.filter_item_ids_for_challenge(pool, challenge_config)
	return pool


func _home_starting_containers(profile: Dictionary, starting_pool: Array, rng: RngStream) -> Array:
	var containers: Array = []
	var index := 0
	for container_value in JsonCoerceScript._copy_array(profile.get("starting_containers", [])):
		if typeof(container_value) != TYPE_DICTIONARY:
			continue
		var entry: Dictionary = container_value
		var item_id := str(entry.get("item_id", entry.get("id", ""))).strip_edges()
		if item_id.is_empty():
			continue
		index += 1
		var definition: Dictionary = library.item(item_id) if library != null else {}
		var capacity := _container_capacity(item_id, int(entry.get("capacity", 0)))
		var stored_items: Array = []
		var random_count := maxi(0, int(entry.get("contains_random_items", 0)))
		for stored_item_value in rng.pick_many(starting_pool, random_count):
			var stored_item_id := str(stored_item_value).strip_edges()
			if not stored_item_id.is_empty():
				stored_items.append(stored_item_id)
		if capacity > 0 and stored_items.size() > capacity:
			stored_items = stored_items.slice(0, capacity)
		containers.append({
			"id": "%s_%02d" % [item_id, index],
			"item_id": item_id,
			"display_name": str(definition.get("display_name", item_id.replace("_", " ").capitalize())),
			"capacity": capacity,
			"items": stored_items,
		})
	return containers


func _meta_collection_starting_containers(challenge_config: Dictionary) -> Array:
	var modifiers := JsonCoerceScript._copy_dict(challenge_config.get("modifiers", {}))
	if not bool(modifiers.get("meta_collection_enabled", false)):
		return []
	var containers: Array = []
	for container_value in JsonCoerceScript._copy_array(modifiers.get("meta_collection_containers", [])):
		if typeof(container_value) != TYPE_DICTIONARY:
			continue
		var container: Dictionary = JsonCoerceScript._copy_dict(container_value)
		var item_id := str(container.get("item_id", "")).strip_edges()
		var capacity := _container_capacity(item_id, int(container.get("capacity", 0)))
		if item_id.is_empty() or capacity <= 0:
			continue
		var definition: Dictionary = library.item(item_id) if library != null else {}
		container["display_name"] = str(definition.get("display_name", item_id.replace("_", " ").capitalize()))
		container["capacity"] = capacity
		container["meta_loadout"] = true
		containers.append(container)
	return containers


func _container_capacity(item_id: String, fallback: int) -> int:
	var capacity := maxi(0, fallback)
	var definition: Dictionary = library.item(item_id) if library != null else {}
	if definition.is_empty():
		return capacity
	capacity = maxi(capacity, int(definition.get("container_capacity", 0)))
	var effect := JsonCoerceScript._copy_dict(definition.get("effect", {}))
	return maxi(capacity, int(effect.get("container_capacity", 0)))


func _int_range(value: Variant, fallback_min: int, fallback_max: int) -> Array:
	if typeof(value) == TYPE_ARRAY:
		var values: Array = value
		if values.size() >= 2:
			var first := int(values[0])
			var second := int(values[1])
			return [mini(first, second), maxi(first, second)]
	return [mini(fallback_min, fallback_max), maxi(fallback_min, fallback_max)]


# Lets GameModule instances attach generated per-environment state before entry.
func _generated_game_states(run_state: RunState, environment_data: Dictionary, rng: RngStream) -> Dictionary:
	var states := JsonCoerceScript._copy_dict(environment_data.get("game_states", {}))
	var perf_games_detail: Dictionary = {}
	for game_id in JsonCoerceScript._raw_string_array(environment_data.get("game_ids", [])):
		var perf_game_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
		var definition := library.game(game_id)
		var game: GameModule = _create_game_module(definition)
		if game == null:
			continue
		var perf_module_usec := Time.get_ticks_usec() - perf_game_started_usec if _world_environment_timing_enabled else 0
		var state_rng := rng.fork("environment_game_state:%s:%s" % [str(environment_data.get("id", "")), game_id])
		var generated_base := false
		if not states.has(game_id):
			var perf_generate_started_usec := Time.get_ticks_usec() if _world_environment_timing_enabled else 0
			if _world_environment_timing_enabled and game.has_method("set_generation_timing_enabled"):
				game.call("set_generation_timing_enabled", true)
			var generated: Dictionary = game.generate_environment_state(run_state, environment_data, state_rng)
			var perf_generate_usec := Time.get_ticks_usec() - perf_generate_started_usec if _world_environment_timing_enabled else 0
			if typeof(generated) == TYPE_DICTIONARY and not (generated as Dictionary).is_empty():
				states[game_id] = (generated as Dictionary).duplicate(true)
				game.environment_state_generated(run_state, environment_data, states[game_id] as Dictionary)
				generated_base = true
			if _world_environment_timing_enabled:
				perf_games_detail[game_id] = {
					"module": perf_module_usec,
					"generate": perf_generate_usec,
					"base_total": Time.get_ticks_usec() - perf_game_started_usec,
				}
				if game.has_method("generation_timing_snapshot"):
					perf_games_detail[game_id]["generation_detail"] = game.call("generation_timing_snapshot")
		var fixture_count := maxi(1, int(JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(environment_data.get("layout", {})).get("game_fixture_counts", {})).get(game_id, 1)))
		if fixture_count <= 1 or not game.has_method("generate_environment_fixture_states"):
			continue
		var fixture_states_value: Variant = game.call("generate_environment_fixture_states", run_state, environment_data, state_rng.fork("fixtures"), fixture_count)
		if typeof(fixture_states_value) != TYPE_DICTIONARY:
			continue
		for fixture_key_value in (fixture_states_value as Dictionary).keys():
			var fixture_key := str(fixture_key_value)
			if fixture_key.is_empty():
				continue
			if states.has(fixture_key) and not (fixture_key == game_id and generated_base):
				continue
			var fixture_state_value: Variant = (fixture_states_value as Dictionary).get(fixture_key, {})
			if typeof(fixture_state_value) == TYPE_DICTIONARY and not (fixture_state_value as Dictionary).is_empty():
				states[fixture_key] = (fixture_state_value as Dictionary).duplicate(true)
		if _world_environment_timing_enabled:
			var game_detail: Dictionary = perf_games_detail.get(game_id, {}) if typeof(perf_games_detail.get(game_id, {})) == TYPE_DICTIONARY else {}
			game_detail["total"] = Time.get_ticks_usec() - perf_game_started_usec
			perf_games_detail[game_id] = game_detail
	if _world_environment_timing_enabled:
		_world_environment_build_stages_usec["games_detail"] = perf_games_detail
	return states


func _create_game_module(definition: Dictionary) -> GameModule:
	return GameModuleRegistryScript.create_module(definition, library)


func _count_ceiling(value: Variant) -> int:
	if typeof(value) == TYPE_ARRAY:
		var values: Array = value
		var max_count := 0
		for entry in values:
			max_count = maxi(max_count, int(entry))
		return max_count
	return int(value)
