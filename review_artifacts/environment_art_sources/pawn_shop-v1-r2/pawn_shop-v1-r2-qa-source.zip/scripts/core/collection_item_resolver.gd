class_name CollectionItemResolver
extends RefCounted

# Loads collection/item definitions and resolves their effects, presentation,
# and validation through one cached, read-only catalog boundary.

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")

const StaticDataCacheScript := preload("res://scripts/core/static_data_cache.gd")

const COLLECTIONS_PATH := "res://data/collections/collections.json"
const SCHEMA_VERSION := 1
const HASH_MODULUS := 4294967296
const INSTANCE_ID_BASE := 1000000
const INSTANCE_ID_SPAN := 900000000
const FLOAT_KEYS := ["potency", "condition", "resonance", "usage"]
const ITEM_CLASS_COLLECTION := "collection"
const ITEM_CLASS_PLAYERS_CARD := "players_card"
const ITEM_CLASS_CHIP_STACK := "chip_stack"
const TIERS := ["blue", "purple", "pink", "red", "gold"]
const TIER_COUNTS := {
	"blue": 4,
	"purple": 4,
	"pink": 3,
	"red": 2,
	"gold": 1,
}
const KNOWN_EFFECT_KEYS := [
	"baseline_luck_delta",
	"win_chance",
	"win_bonus",
	"legal_win_chance",
	"loss_reduction",
	"cheat_suspicion_delta",
	"travel_option_bonus",
	"travel_scouting_level",
	"debt_grace_turns",
	"debt_default_heat_delta",
	"blackjack_peek_heat_delta",
	"blackjack_peek_loss_reduction",
	"baccarat_edge_sort_memory_tolerance",
	"slot_nudge_perfect_msec_bonus",
	"slot_cold_quarter_heat_reduction",
	"video_poker_holdout_heat_delta",
	"video_poker_holdout_perfect_msec",
	"slot_split_reel_note_perfect_msec_bonus",
	"roulette_past_post_base_heat",
	"blackjack_failed_peek_heat_absorb",
]
const DEFINITION_CACHE_MAX_ENTRIES := 2

static var _definition_parse_count := 0

var _definitions_ready := false
var _root: Dictionary = {}
var _collections: Array = []
var _special_items: Array = []
var _items_by_itemdef_id: Dictionary = {}
var _bags_by_itemdef_id: Dictionary = {}
var _validation_errors: Array[String] = []


func load_definitions() -> void:
	var cached_value: Variant = StaticDataCacheScript.get_or_load(
		COLLECTIONS_PATH,
		Callable(self, "_load_definition_bundle"),
		DEFINITION_CACHE_MAX_ENTRIES
	)
	_apply_definition_bundle(cached_value)


func _load_definition_bundle(_path: String) -> Dictionary:
	_definition_parse_count += 1
	_definitions_ready = true
	_root = {}
	_collections = []
	_special_items = []
	_items_by_itemdef_id = {}
	_bags_by_itemdef_id = {}
	_validation_errors = []
	if not FileAccess.file_exists(COLLECTIONS_PATH):
		_validation_errors.append("Missing collection schema: %s" % COLLECTIONS_PATH)
		return _definition_bundle()
	var text := FileAccess.get_file_as_string(COLLECTIONS_PATH)
	var parsed: Variant = JSON.parse_string(text)
	if typeof(parsed) == TYPE_ARRAY:
		var entries: Array = parsed
		if entries.is_empty():
			_validation_errors.append("Collection schema bundle is empty.")
			return _definition_bundle()
		_root = JsonCoerceScript._copy_dict(entries[0])
	elif typeof(parsed) == TYPE_DICTIONARY:
		_root = JsonCoerceScript._copy_dict(parsed)
	else:
		_validation_errors.append("Collection schema root must be an object or single-object array.")
		return _definition_bundle()
	_index_definitions()
	return _definition_bundle()


func _definition_bundle() -> Dictionary:
	return {
		"root": _root.duplicate(true),
		"collections": _collections.duplicate(true),
		"special_items": _special_items.duplicate(true),
		"items_by_itemdef_id": _items_by_itemdef_id.duplicate(true),
		"bags_by_itemdef_id": _bags_by_itemdef_id.duplicate(true),
		"validation_errors": _validation_errors.duplicate(),
	}


func _apply_definition_bundle(value: Variant) -> void:
	var bundle: Dictionary = value if typeof(value) == TYPE_DICTIONARY else {}
	_definitions_ready = true
	_root = (bundle.get("root", {}) as Dictionary).duplicate(true)
	_collections = (bundle.get("collections", []) as Array).duplicate(true)
	_special_items = (bundle.get("special_items", []) as Array).duplicate(true)
	_items_by_itemdef_id = (bundle.get("items_by_itemdef_id", {}) as Dictionary).duplicate(true)
	_bags_by_itemdef_id = (bundle.get("bags_by_itemdef_id", {}) as Dictionary).duplicate(true)
	_validation_errors.clear()
	for error_value in bundle.get("validation_errors", []):
		_validation_errors.append(str(error_value))


static func debug_clear_definition_cache() -> void:
	StaticDataCacheScript.erase(COLLECTIONS_PATH)
	_definition_parse_count = 0


static func debug_definition_parse_count() -> int:
	return _definition_parse_count


func validate_definitions() -> Array[String]:
	_ensure_loaded()
	var errors: Array[String] = []
	for error in _validation_errors:
		errors.append(error)
	return errors


func collections() -> Array:
	_ensure_loaded()
	return _collections.duplicate(true)


func item_definitions() -> Array:
	_ensure_loaded()
	var items: Array = []
	for itemdef_id in _items_by_itemdef_id.keys():
		items.append(JsonCoerceScript._copy_dict(_items_by_itemdef_id[itemdef_id]))
	return items


func special_item_definitions() -> Array:
	_ensure_loaded()
	return _special_items.duplicate(true)


func item_definition(itemdef_id: int) -> Dictionary:
	_ensure_loaded()
	return JsonCoerceScript._copy_dict(_items_by_itemdef_id.get(itemdef_id, {}))


func bag_definition(itemdef_id: int) -> Dictionary:
	_ensure_loaded()
	return JsonCoerceScript._copy_dict(_bags_by_itemdef_id.get(itemdef_id, {}))


func item_definitions_for_collection_tier(collection_id: String, tier: String) -> Array:
	_ensure_loaded()
	var clean_collection_id := collection_id.strip_edges()
	var clean_tier := tier.strip_edges()
	var items: Array = []
	for item_value in _items_by_itemdef_id.values():
		var item := JsonCoerceScript._copy_dict(item_value)
		if str(item.get("collection_id", "")) == clean_collection_id and str(item.get("tier", "")) == clean_tier:
			items.append(item)
	items.sort_custom(func(left: Dictionary, right: Dictionary) -> bool:
		return int(left.get("itemdef_id", 0)) < int(right.get("itemdef_id", 0))
	)
	return items


func bag_item_definitions(collection_id: String = "", tier: String = "") -> Array:
	_ensure_loaded()
	var clean_collection_id := collection_id.strip_edges()
	var clean_tier := tier.strip_edges()
	var bags: Array = []
	for bag_value in _bags_by_itemdef_id.values():
		var bag := JsonCoerceScript._copy_dict(bag_value)
		if not clean_collection_id.is_empty() and str(bag.get("collection_id", "")) != clean_collection_id:
			continue
		if not clean_tier.is_empty() and str(bag.get("tier", "")) != clean_tier:
			continue
		bags.append(bag)
	bags.sort_custom(func(left: Dictionary, right: Dictionary) -> bool:
		return int(left.get("itemdef_id", 0)) < int(right.get("itemdef_id", 0))
	)
	return bags


func collection_definition(collection_id: String) -> Dictionary:
	_ensure_loaded()
	var clean_id := collection_id.strip_edges()
	for collection_value in _collections:
		var collection := JsonCoerceScript._copy_dict(collection_value)
		if str(collection.get("id", "")) == clean_id:
			return collection
	return {}


func meta_home_config() -> Dictionary:
	_ensure_loaded()
	return JsonCoerceScript._copy_dict(_root.get("meta_home", {}))


func prestige_config() -> Dictionary:
	return JsonCoerceScript._copy_dict(meta_home_config().get("prestige", {}))


func players_card_help() -> Dictionary:
	# Prestige is granted at run start, outside the ordinary scaled item effects.
	# Both inventory presentations must describe that same authored configuration.
	var prestige := prestige_config()
	var lines: Array = [
		"First Grand Casino entry: Heat %d (minimum 0)." % mini(0, int(prestige.get("recognition_heat_delta", -10))),
		"Clean-play maximum Heat: %d from the usual ceiling." % mini(0, int(prestige.get("clean_heat_ceiling_delta", -5))),
		"Collection reward drops improve by %d tier(s), up to Gold." % maxi(0, int(prestige.get("drop_tier_bonus_steps", 1))),
	]
	return {
		"effect_lines": lines,
		"use_instructions": "Pack this Card before starting a standard run. No activation is needed. If carried during a failed or abandoned run, it is permanently destroyed; Cards left in home storage stay safe. Its Critical condition does not decay and cannot be repaired.",
	}


func bag_item_options_for_bag(bagdef_id: int) -> Array:
	var bag := bag_definition(bagdef_id)
	if bag.is_empty():
		return []
	return item_definitions_for_collection_tier(str(bag.get("collection_id", "")), str(bag.get("tier", "")))


func roll_virtual_bag_item(rng: RngStream, generation_seed: String) -> Dictionary:
	_ensure_loaded()
	if rng == null or _collections.is_empty():
		return {}
	var collection := JsonCoerceScript._copy_dict(_collections[rng.randi_range(0, _collections.size() - 1)])
	var tier := _roll_weighted_collection_tier(collection, rng)
	var bag_options := bag_item_definitions(str(collection.get("id", "")), tier)
	if bag_options.is_empty():
		return {}
	var virtual_bag := JsonCoerceScript._copy_dict(bag_options[rng.randi_range(0, bag_options.size() - 1)])
	var item_options := bag_item_options_for_bag(int(virtual_bag.get("itemdef_id", -1)))
	if item_options.is_empty():
		return {}
	var definition := JsonCoerceScript._copy_dict(item_options[rng.randi_range(0, item_options.size() - 1)])
	var roll_seed := "%s|collection:%s|tier:%s|bag:%d|item:%d|state:%d" % [
		generation_seed,
		str(collection.get("id", "")),
		tier,
		int(virtual_bag.get("itemdef_id", -1)),
		int(definition.get("itemdef_id", -1)),
		rng.state_value,
	]
	var item := roll_instance(int(definition.get("itemdef_id", -1)), roll_seed)
	return {
		"collection": collection,
		"tier": tier,
		"virtual_bag": virtual_bag,
		"definition": definition,
		"item": item,
		"generation_seed": roll_seed,
		"rng_snapshot": rng.snapshot(),
	}


func roll_instance(itemdef_id: int, rng_seed: String) -> Dictionary:
	_ensure_loaded()
	var definition := item_definition(itemdef_id)
	if definition.is_empty():
		return {}
	var seed := "%s|%d" % [rng_seed, itemdef_id]
	var instance_id := INSTANCE_ID_BASE + (_hash_u32("%s|instance" % seed) % INSTANCE_ID_SPAN)
	return normalize_instance_for_definition({
		"schema_version": SCHEMA_VERSION,
		"instance_id": instance_id,
		"itemdef_id": itemdef_id,
		"potency": _unit_float(seed, "potency"),
		"condition": _unit_float(seed, "condition"),
		"resonance": _unit_float(seed, "resonance"),
		"usage": clampf(0.82 + (_unit_float(seed, "usage") * 0.18), 0.0, 1.0),
	})


func apply_usage_decay(instance: Dictionary, rng_seed: String) -> Dictionary:
	_ensure_loaded()
	var next := normalize_instance_for_definition(instance)
	var itemdef_id := int(next.get("itemdef_id", -1))
	var definition := item_definition(itemdef_id)
	if definition.is_empty():
		return next
	if str(definition.get("item_class", ITEM_CLASS_COLLECTION)) != ITEM_CLASS_COLLECTION:
		return next
	var usage_binding := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(definition.get("float_bindings", {})).get("usage", {}))
	var decay_min := maxf(0.0, float(usage_binding.get("decay_min", 0.02)))
	var decay_max := maxf(decay_min, float(usage_binding.get("decay_max", decay_min)))
	var decay := lerpf(decay_min, decay_max, _unit_float("%s|%d" % [rng_seed, itemdef_id], "usage_decay"))
	var current_usage := clampf(float(next.get("usage", 0.0)), 0.0, 1.0)
	next["usage"] = 0.0 if current_usage <= decay else clampf(current_usage - decay, 0.0, 1.0)
	return next


func resolved_effect(definition: Dictionary, instance: Dictionary) -> Dictionary:
	_ensure_loaded()
	if definition.is_empty():
		return {}
	return _scaled_effect(definition, instance)


func resolve_run_item(instance: Dictionary) -> Dictionary:
	_ensure_loaded()
	var normalized := normalize_instance_for_definition(instance)
	var itemdef_id := int(normalized.get("itemdef_id", -1))
	var definition := item_definition(itemdef_id)
	if definition.is_empty():
		return {}
	var band := condition_band(definition, normalized)
	var effect := _scaled_effect(definition, normalized)
	var instance_id := int(normalized.get("instance_id", 0))
	var item_id := str(definition.get("id", "collection_item"))
	var item_class := str(definition.get("item_class", ITEM_CLASS_COLLECTION))
	var instance_data := JsonCoerceScript._copy_dict(normalized.get("instance_data", {}))
	var presentation_tier := str(definition.get("tier", ""))
	var description := str(definition.get("flavor", ""))
	var display_name := "%s (%s)" % [str(definition.get("display_name", "Collection Item")), str(band.get("display_name", "Unknown"))]
	if item_class == ITEM_CLASS_CHIP_STACK:
		display_name = "%s ×%d" % [str(definition.get("display_name", "Grand Casino Chips")), maxi(0, int(normalized.get("stack_amount", 0)))]
	elif item_class == ITEM_CLASS_PLAYERS_CARD:
		# The definition is the single collectible card template. The casino tier
		# belongs to the minted instance, so Bronze must not present as template Gold.
		var earned_tier := str(instance_data.get("tier_reached", "")).strip_edges().to_lower()
		if earned_tier in ["bronze", "silver", "gold"]:
			presentation_tier = earned_tier
			description = "Linda's %s card, stamped with the run that paid for it." % earned_tier.capitalize()
		display_name = str(definition.get("display_name", "Grand Casino Players Card"))
	return {
		"id": "meta_%s_%d" % [item_id, instance_id],
		"display_name": display_name,
		"class": "meta_only" if item_class == ITEM_CLASS_CHIP_STACK else "permanent",
		"domain": "meta" if item_class == ITEM_CLASS_CHIP_STACK else "global",
		"content_groups": ["meta_collection"],
		"sellable": false,
		"sale_price": 0,
		"price_min": 0,
		"price_max": 0,
		"icon_key": str(definition.get("icon_key", "")),
		"description": description,
		"effect": effect,
		"meta_collection": {
			"schema_version": SCHEMA_VERSION,
			"item_class": item_class,
			"collection_id": str(definition.get("collection_id", "")),
			"itemdef_id": itemdef_id,
			"instance_id": instance_id,
			"tier": presentation_tier,
			"players_card_tier": presentation_tier if item_class == ITEM_CLASS_PLAYERS_CARD else "",
			"condition_band": str(band.get("id", "")),
			"floats": {
				"potency": float(normalized.get("potency", 0.0)),
				"condition": float(normalized.get("condition", 0.0)),
				"resonance": float(normalized.get("resonance", 0.0)),
				"usage": float(normalized.get("usage", 0.0)),
			},
			"instance_data": instance_data,
			"stack_amount": maxi(0, int(normalized.get("stack_amount", 0))),
			"face_value": maxi(0, int(normalized.get("face_value", 0))),
			"loadout_eligible": bool(definition.get("loadout_eligible", true)),
		},
		"meta_value_multiplier": value_multiplier(definition, normalized),
	}


func condition_band(definition: Dictionary, instance: Dictionary) -> Dictionary:
	if str(definition.get("item_class", ITEM_CLASS_COLLECTION)) == ITEM_CLASS_CHIP_STACK:
		return {"id": "stack", "display_name": "Stack", "max": 1.0, "value_multiplier": 1.0}
	if str(definition.get("item_class", ITEM_CLASS_COLLECTION)) == ITEM_CLASS_PLAYERS_CARD:
		return {
			"id": "critical",
			"display_name": "Critical",
			"max": _players_card_condition(definition),
			"value_multiplier": 1.0,
		}
	var condition := clampf(float(instance.get("condition", 0.0)), 0.0, 1.0)
	var condition_binding := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(definition.get("float_bindings", {})).get("condition", {}))
	var bands := JsonCoerceScript._copy_array(condition_binding.get("bands", []))
	var fallback: Dictionary = {"id": "unknown", "display_name": "Unknown", "value_multiplier": 1.0}
	for band_value in bands:
		var band := JsonCoerceScript._copy_dict(band_value)
		if band.is_empty():
			continue
		fallback = band
		var max_value := clampf(float(band.get("max", 1.0)), 0.0, 1.0)
		if condition <= max_value:
			return band
	return fallback


func value_multiplier(definition: Dictionary, instance: Dictionary) -> float:
	if str(definition.get("item_class", ITEM_CLASS_COLLECTION)) != ITEM_CLASS_COLLECTION:
		return 1.0
	var condition_binding := JsonCoerceScript._copy_dict(JsonCoerceScript._copy_dict(definition.get("float_bindings", {})).get("condition", {}))
	var spent_value_multiplier := maxf(0.0, float(condition_binding.get("spent_value_multiplier", 0.08)))
	var usage := clampf(float(instance.get("usage", 0.0)), 0.0, 1.0)
	if usage <= 0.0:
		return spent_value_multiplier
	var band := condition_band(definition, instance)
	var condition_multiplier := maxf(0.0, float(band.get("value_multiplier", 1.0)))
	return snappedf(condition_multiplier * lerpf(spent_value_multiplier, 1.0, usage), 0.001)


static func normalize_instance(instance: Dictionary) -> Dictionary:
	var normalized := instance.duplicate(true)
	normalized["schema_version"] = int(normalized.get("schema_version", SCHEMA_VERSION))
	normalized["instance_id"] = maxi(0, int(normalized.get("instance_id", 0)))
	normalized["itemdef_id"] = int(normalized.get("itemdef_id", -1))
	for float_key in FLOAT_KEYS:
		normalized[float_key] = clampf(float(normalized.get(float_key, 0.0)), 0.0, 1.0)
	return normalized


func normalize_instance_for_definition(instance: Dictionary) -> Dictionary:
	var normalized := normalize_instance(instance)
	var definition := item_definition(int(normalized.get("itemdef_id", -1)))
	if definition.is_empty():
		return normalized
	var item_class := str(definition.get("item_class", ITEM_CLASS_COLLECTION)).strip_edges().to_lower()
	normalized["item_class"] = item_class
	if item_class == ITEM_CLASS_PLAYERS_CARD:
		normalized["condition"] = _players_card_condition(definition)
		normalized["usage"] = 1.0
		normalized["durability_pinned"] = true
		normalized["instance_data"] = JsonCoerceScript._copy_dict(normalized.get("instance_data", {}))
	elif item_class == ITEM_CLASS_CHIP_STACK:
		var stack_amount := maxi(0, int(normalized.get("stack_amount", normalized.get("face_value", 0))))
		normalized["stack_amount"] = stack_amount
		normalized["face_value"] = maxi(0, int(normalized.get("face_value", stack_amount)))
		normalized["condition"] = 1.0
		normalized["usage"] = 1.0
		normalized["instance_data"] = JsonCoerceScript._copy_dict(normalized.get("instance_data", {}))
	return normalized


func is_players_card_instance(instance: Dictionary) -> bool:
	var definition := item_definition(int(instance.get("itemdef_id", -1)))
	return str(definition.get("item_class", "")) == ITEM_CLASS_PLAYERS_CARD


func is_chip_stack_instance(instance: Dictionary) -> bool:
	var definition := item_definition(int(instance.get("itemdef_id", -1)))
	return str(definition.get("item_class", "")) == ITEM_CLASS_CHIP_STACK


func is_loadout_eligible(instance: Dictionary) -> bool:
	var definition := item_definition(int(instance.get("itemdef_id", -1)))
	return not definition.is_empty() and bool(definition.get("loadout_eligible", true))


func _ensure_loaded() -> void:
	if not _definitions_ready:
		load_definitions()


func _index_definitions() -> void:
	if int(_root.get("schema_version", 0)) != SCHEMA_VERSION:
		_validation_errors.append("Collection schema_version must be %d." % SCHEMA_VERSION)
	if not bool(_root.get("draft", false)):
		_validation_errors.append("Collection schema must carry draft=true for P0 owner review.")
	var bundle_collections := JsonCoerceScript._copy_array(_root.get("collections", []))
	if bundle_collections.size() != 2:
		_validation_errors.append("Collection schema must define exactly 2 launch collections.")
	var used_itemdef_ids := {}
	for collection_value in bundle_collections:
		var collection := JsonCoerceScript._copy_dict(collection_value)
		var collection_id := str(collection.get("id", "")).strip_edges()
		if collection_id.is_empty():
			_validation_errors.append("Collection is missing id.")
			continue
		_index_collection(collection, collection_id, used_itemdef_ids)
	_index_special_items(JsonCoerceScript._copy_array(_root.get("special_items", [])), used_itemdef_ids)


func _index_special_items(items: Array, used_itemdef_ids: Dictionary) -> void:
	for item_value in items:
		var item := JsonCoerceScript._copy_dict(item_value)
		var item_id := str(item.get("id", "")).strip_edges()
		var itemdef_id := int(item.get("itemdef_id", -1))
		var item_class := str(item.get("item_class", "")).strip_edges().to_lower()
		if item_id.is_empty():
			_validation_errors.append("Special collection item is missing id.")
			continue
		if itemdef_id <= 0:
			_validation_errors.append("Special item %s is missing a positive itemdef_id." % item_id)
			continue
		if used_itemdef_ids.has(itemdef_id):
			_validation_errors.append("Duplicate itemdef_id %d." % itemdef_id)
			continue
		if not [ITEM_CLASS_PLAYERS_CARD, ITEM_CLASS_CHIP_STACK].has(item_class):
			_validation_errors.append("Special item %s has unknown item_class '%s'." % [item_id, item_class])
			continue
		if item_class == ITEM_CLASS_PLAYERS_CARD:
			var durability := JsonCoerceScript._copy_dict(item.get("durability_policy", {}))
			var condition := float(durability.get("condition", -1.0))
			if condition <= 0.0 or condition > 0.10:
				_validation_errors.append("Players Card %s must pin condition inside the critical band (0, 0.10]." % item_id)
			if bool(durability.get("normal_decay", true)) or bool(durability.get("repairable", true)) or not bool(durability.get("destroy_on_carried_failure", false)):
				_validation_errors.append("Players Card %s has an invalid fragility policy." % item_id)
		elif bool(item.get("loadout_eligible", true)):
			_validation_errors.append("Chip stack %s must remain meta-only." % item_id)
		else:
			var sale_policy := JsonCoerceScript._copy_dict(item.get("sale_policy", {}))
			var gold_rate := float(sale_policy.get("gold_rate", -1.0))
			if str(sale_policy.get("kind", "")) != "face_value_rate" or gold_rate <= 0.0 or gold_rate > 1.0:
				_validation_errors.append("Chip stack %s has an invalid fenced sale policy." % item_id)
		used_itemdef_ids[itemdef_id] = true
		item["item_class"] = item_class
		_special_items.append(item)
		_items_by_itemdef_id[itemdef_id] = item


func _index_collection(collection: Dictionary, collection_id: String, used_itemdef_ids: Dictionary) -> void:
	var items := JsonCoerceScript._copy_array(collection.get("items", []))
	var bag_defs := JsonCoerceScript._copy_array(collection.get("bag_defs", []))
	var tier_counts := {}
	var bag_tiers := {}
	for tier in TIERS:
		tier_counts[tier] = 0
	for bag_value in bag_defs:
		var bag := JsonCoerceScript._copy_dict(bag_value)
		var bag_tier := str(bag.get("tier", "")).strip_edges()
		var bag_itemdef_id := int(bag.get("itemdef_id", -1))
		if not TIERS.has(bag_tier):
			_validation_errors.append("Bag %s has invalid tier '%s'." % [str(bag.get("id", "")), bag_tier])
		if bag_itemdef_id <= 0:
			_validation_errors.append("Bag %s is missing a positive itemdef_id." % str(bag.get("id", "")))
		elif used_itemdef_ids.has(bag_itemdef_id):
			_validation_errors.append("Duplicate itemdef_id %d." % bag_itemdef_id)
		else:
			used_itemdef_ids[bag_itemdef_id] = true
			bag["collection_id"] = collection_id
			_bags_by_itemdef_id[bag_itemdef_id] = bag
		bag_tiers[bag_tier] = true
	for tier in TIERS:
		if not bag_tiers.has(tier):
			_validation_errors.append("Collection %s is missing a %s bag definition." % [collection_id, tier])
	for item_value in items:
		var item := JsonCoerceScript._copy_dict(item_value)
		var item_tier := str(item.get("tier", "")).strip_edges()
		var itemdef_id := int(item.get("itemdef_id", -1))
		if not TIERS.has(item_tier):
			_validation_errors.append("Item %s has invalid tier '%s'." % [str(item.get("id", "")), item_tier])
			continue
		tier_counts[item_tier] = int(tier_counts.get(item_tier, 0)) + 1
		if itemdef_id <= 0:
			_validation_errors.append("Item %s is missing a positive itemdef_id." % str(item.get("id", "")))
		elif used_itemdef_ids.has(itemdef_id):
			_validation_errors.append("Duplicate itemdef_id %d." % itemdef_id)
		else:
			used_itemdef_ids[itemdef_id] = true
			item["collection_id"] = collection_id
			_items_by_itemdef_id[itemdef_id] = item
		_validate_item_bindings(collection_id, item)
	for tier in TIERS:
		var expected := int(TIER_COUNTS.get(tier, 0))
		var actual := int(tier_counts.get(tier, 0))
		if actual != expected:
			_validation_errors.append("Collection %s tier %s count was %d, expected %d." % [collection_id, tier, actual, expected])
	_collections.append(collection)


func _validate_item_bindings(collection_id: String, item: Dictionary) -> void:
	var item_id := str(item.get("id", ""))
	var effect := JsonCoerceScript._copy_dict(item.get("base_effect", {}))
	for effect_key in effect.keys():
		if not KNOWN_EFFECT_KEYS.has(str(effect_key)):
			_validation_errors.append("Collection %s item %s has unknown base effect key %s." % [collection_id, item_id, str(effect_key)])
	var bindings := JsonCoerceScript._copy_dict(item.get("float_bindings", {}))
	for float_key in FLOAT_KEYS:
		if not bindings.has(float_key):
			_validation_errors.append("Collection %s item %s is missing %s binding." % [collection_id, item_id, str(float_key)])
	var potency := JsonCoerceScript._copy_dict(bindings.get("potency", {}))
	var potency_key := str(potency.get("effect_key", ""))
	if potency_key.is_empty() or not KNOWN_EFFECT_KEYS.has(potency_key):
		_validation_errors.append("Collection %s item %s has unknown potency effect key %s." % [collection_id, item_id, potency_key])
	var resonance := JsonCoerceScript._copy_dict(bindings.get("resonance", {}))
	var resonance_key := str(resonance.get("effect_key", ""))
	if resonance_key.is_empty() or not KNOWN_EFFECT_KEYS.has(resonance_key):
		_validation_errors.append("Collection %s item %s has unknown resonance effect key %s." % [collection_id, item_id, resonance_key])
	var usage := JsonCoerceScript._copy_dict(bindings.get("usage", {}))
	var decay_min := float(usage.get("decay_min", -1.0))
	var decay_max := float(usage.get("decay_max", -1.0))
	if decay_min < 0.0 or decay_max < decay_min:
		_validation_errors.append("Collection %s item %s has invalid usage decay range." % [collection_id, item_id])


func _scaled_effect(definition: Dictionary, instance: Dictionary) -> Dictionary:
	var effect := JsonCoerceScript._copy_dict(definition.get("base_effect", {}))
	var bindings := JsonCoerceScript._copy_dict(definition.get("float_bindings", {}))
	var potency := JsonCoerceScript._copy_dict(bindings.get("potency", {}))
	var effect_key := str(potency.get("effect_key", ""))
	if not effect_key.is_empty():
		var raw_value := lerpf(float(potency.get("min", 0)), float(potency.get("max", 0)), clampf(float(instance.get("potency", 0.0)), 0.0, 1.0))
		if float(instance.get("usage", 0.0)) <= 0.0:
			var condition_binding := JsonCoerceScript._copy_dict(bindings.get("condition", {}))
			raw_value *= clampf(float(condition_binding.get("spent_potency_factor", 0.35)), 0.0, 1.0)
		effect[effect_key] = int(round(raw_value))
	var resonance := JsonCoerceScript._copy_dict(bindings.get("resonance", {}))
	var resonance_key := str(resonance.get("effect_key", ""))
	if not resonance_key.is_empty() and clampf(float(instance.get("resonance", 0.0)), 0.0, 1.0) >= clampf(float(resonance.get("threshold", 1.0)), 0.0, 1.0):
		effect[resonance_key] = int(effect.get(resonance_key, 0)) + int(resonance.get("value", 0))
	return effect


func _roll_weighted_collection_tier(collection: Dictionary, rng: RngStream) -> String:
	var drop_table := JsonCoerceScript._copy_dict(collection.get("drop_table", {}))
	var weighted: Array = []
	var total := 0
	for tier_value in TIERS:
		var tier := str(tier_value)
		var weight := maxi(0, int(drop_table.get(tier, 0)))
		if weight <= 0:
			continue
		weighted.append({"tier": tier, "weight": weight})
		total += weight
	if weighted.is_empty() or total <= 0:
		return "blue"
	var roll := rng.randi_range(1, total)
	var running := 0
	for entry_value in weighted:
		var entry := JsonCoerceScript._copy_dict(entry_value)
		running += int(entry.get("weight", 0))
		if roll <= running:
			return str(entry.get("tier", "blue"))
	return "blue"


func _players_card_condition(definition: Dictionary) -> float:
	var policy := JsonCoerceScript._copy_dict(definition.get("durability_policy", {}))
	return clampf(float(policy.get("condition", 0.08)), 0.001, 0.10)


static func _unit_float(seed: String, channel: String) -> float:
	return clampf(float(_hash_u32("%s|%s" % [seed, channel])) / float(HASH_MODULUS - 1), 0.0, 1.0)


static func _hash_u32(text: String) -> int:
	var hash := 2166136261
	for index in range(text.length()):
		var code := text.unicode_at(index)
		hash = int(((hash ^ code) * 16777619) % HASH_MODULUS)
		if hash < 0:
			hash += HASH_MODULUS
	return hash
