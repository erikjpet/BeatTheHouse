import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,json,hashlib,shutil
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'tools'))
from bth_qa_storage import plan_layout,prepare_layout,validate_layout
from bth_qa_guarded_run import execute
tokens=sys.argv[1:]; split=tokens.index('--') if '--' in tokens else len(tokens)
p=argparse.ArgumentParser(); p.add_argument('name'); p.add_argument('--timeout',type=int,default=300); p.add_argument('--cold-import',action='store_true')
a=p.parse_args(tokens[:split]); command=tokens[split+1:]
l=prepare_layout(plan_layout(root=r'E:\CodexQA\BTH',workspace=str(W),run_id='BTH-ENVART-PAWN-20261114-'+a.name))
validate_layout(l)
shutil.copyfile(__file__,l.evidence/'adapter.py')
proof=json.loads((W/'pawn_source_identity.json').read_text())
assert proof['commit']=='173b235da9171a5369894bdfb5e9f901d009e018'
for rel,expected in proof['files'].items():
    assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==expected,rel
assert not (W/'data/art/environments/pawn_shop.json').exists()
(l.evidence/'source_identity.json').write_text(json.dumps(proof,indent=2))
for f in W.glob('tools/envart_pawn_*'):
    shutil.copyfile(f,l.evidence/f.name)
shutil.copyfile(W/'pawn_capture_inputs.json',l.evidence/'pawn_capture_inputs.json')
command=[x.replace('{workspace}',str(W)).replace('{evidence}',str(l.evidence)) for x in command]
if not command: print('PREPARED',l.evidence); sys.exit(0)
override=W/'override.cfg'; policy=b'[editor]\nimport/use_multiple_threads=false\n\n[threading]\nworker_pool/max_threads=1\n'
if a.cold_import:
    validate_layout(l,extra_write_paths=(override,))
    with override.open('xb') as f:f.write(policy)
try: result=execute(l,command,timeout=a.timeout)
finally:
    if a.cold_import and override.read_bytes()==policy:override.unlink()
print(json.dumps({k:result.get(k) for k in ['command','exit_code','error','cleanup_errors','timed_out','active_at_release']})); print('EVIDENCE',l.evidence)
sys.exit(0 if result.get('exit_code')==0 and result.get('active_at_release')==0 and not result.get('error') and not result.get('cleanup_errors') and not result.get('timed_out') else 1)
