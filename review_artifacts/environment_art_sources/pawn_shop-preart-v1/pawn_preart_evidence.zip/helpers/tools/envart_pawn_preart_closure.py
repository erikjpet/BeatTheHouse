import sys,os,json,hashlib,zipfile
from pathlib import Path
sys.dont_write_bytecode=True
w=Path(os.environ['BTH_QA_WORKSPACE']);out=Path(os.environ['BTH_QA_EVIDENCE_DIR']);root=Path(r'E:\CodexQA\BTH\runs')
cap=root/'BTH-ENVART-PAWN-20261114-current-four-01'/'evidence';uni=root/'BTH-ENVART-PAWN-20261114-union-01'/'evidence'
u=json.loads((uni/'pawn_preart_union.json').read_text());source=json.loads((w/'pawn_source_identity.json').read_text())
assert u['checks']==449 and u['findings']==[] and len(u['contexts'])==4
assert u['totals']['actual_canvas_objects']==53 and u['totals']['selected_cards']==53
assert source['commit']=='173b235da9171a5369894bdfb5e9f901d009e018'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipts={}
for name in ['source','source2','cold-import-01','current-four-01','union-01']:
 p=root/('BTH-ENVART-PAWN-20261114-'+name)/'evidence'/'job.json';j=json.loads(p.read_text())
 if name!='source':assert j['exit_code']==0 and j['active_at_release']==0 and j['assigned_before_execution'] and not j['error'] and not j['cleanup_errors'] and not j['timed_out']
 receipts[name]={'path':str(p),'sha256':sha(p),'exit_code':j.get('exit_code'),'active_at_release':j.get('active_at_release'),'assigned_before_execution':j.get('assigned_before_execution'),'error':j.get('error'),'cleanup_errors':j.get('cleanup_errors'),'timed_out':j.get('timed_out'),'limits':j.get('limits')}
images={p.name:sha(p) for p in cap.glob('*.png')};assert len(images)==12
helper_paths=['pawn_adapter.py','tools/envart_pawn_preart_metadata.gd','tools/envart_pawn_preart_metadata_lf_v2.gd','tools/envart_pawn_preart_union.py','tools/envart_pawn_preart_closure.py','pawn_capture_inputs.json']
summary={'status':'PASS_SMALL_CURRENT_PREART_ONLY','source_commit':source['commit'],'placement_override_sha256':source['files']['data/environments/developer_placement_overrides.json'],'source_archive':str(w/'delivered-173b235d.zip'),'source_archive_sha256':source['archive_sha256'],'source_identity_manifest':str(w/'pawn_source_identity.json'),'source_identity_manifest_sha256':sha(w/'pawn_source_identity.json'),'native_checks':449,'findings':[],'contexts':{n:{'objects':c['actual_canvas_object_count'],'selected_cards':c['selected_card_count'],'remaining_arrivals':c['arrival']['remaining_person_transits'],'hidden_nonroom_count':len(c['runtime_excluded'])+len(c['published_nonroom_records']),'authored_hosted_or_hidden_exclusions':c['authored_projection_exclusions']} for n,c in u['contexts'].items()},'totals':u['totals'],'unique_object_ids':len(u['object_union']),'union_path':str(uni/'pawn_preart_union.json'),'union_sha256':sha(uni/'pawn_preart_union.json'),'metadata_path':str(cap/'pawn_preart_metadata.json'),'metadata_sha256':sha(cap/'pawn_preart_metadata.json'),'helpers':{p:sha(w/p) for p in helper_paths},'png_sha256':images,'job_receipts':receipts,'engine_release':'Both owned native Jobs are complete and drained with active_at_release=0. No further Godot is planned. Native ownership explicitly released to parent before union.','scope':u['scope'],'caveats':['Coordinates are board900x430 geometry, not exact opaque paint masks.','Source-current initial contexts only; no work/outcome/save/revisit lifecycle or art acceptance.','Initial source contains no hidden/non-room/hosted visual exclusions in these four contexts; all 12 Runtime visuals are accounted for in canvas geometry.','One early archive attempt failed before worker execution because bare git executable was not resolved; absolute-path retry completed cleanly.']}
for c in summary['contexts'].values():assert c['remaining_arrivals']==0
(out/'pawn_preart_closure.json').write_text(json.dumps(summary,indent=2))
with zipfile.ZipFile(out/'pawn_preart_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in cap.iterdir():
  if p.is_file():z.write(p,'capture/'+p.name)
 for p in uni.iterdir():
  if p.is_file():z.write(p,'union/'+p.name)
 for p in helper_paths:z.write(w/p,'helpers/'+p)
 z.write(w/'pawn_source_identity.json','source/pawn_source_identity.json')
 z.write(out/'pawn_preart_closure.json','pawn_preart_closure.json')
 for name,r in receipts.items():z.write(r['path'],'receipts/'+name+'-job.json')
print(json.dumps({'status':summary['status'],'closure':str(out/'pawn_preart_closure.json'),'closure_sha256':sha(out/'pawn_preart_closure.json'),'evidence_zip':str(out/'pawn_preart_evidence.zip'),'evidence_zip_sha256':sha(out/'pawn_preart_evidence.zip'),'union_sha256':summary['union_sha256'],'metadata_sha256':summary['metadata_sha256'],'images':len(images),'totals':u['totals']},indent=2))
