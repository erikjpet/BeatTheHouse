import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw
REPO=Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers');sys.path.insert(0,str(REPO/'tools'))
from bth_qa_storage import Layout,validate_layout
from check_environment_art_pack import validate_manifest,counter_rectangles
e=Path(os.environ['BTH_QA_EVIDENCE_DIR']);m=json.loads((e/'storage-manifest.json').read_text());l=Layout(**{k:Path(v) for k,v in m['paths'].items()},run_id=m['run_id'],token=m['token'],prepared=True,expected_write_bytes=m['expected_write_bytes'],reserve_bytes=m['reserve_bytes']);w=l.workspace;artist=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-ARTIST-20261114/jazz_club-v1');raw=artist/'source/background-guide-v1.png'
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert H(raw)=='074a63ef8b9998bf03381cc09c2f3c07a9787b5eab623c92643097c01ded59ed';s=Image.open(raw).convert('RGB').resize((900,430),Image.Resampling.NEAREST);b=s.copy();q=s.copy()
root=w/'packages/jazz_club-v1-r3';validate_layout(l,extra_write_paths=(root,));assert not root.exists();asset=root/'assets/art/environments/jazz_club';(asset/'anim').mkdir(parents=True);(asset/'counters').mkdir();(root/'data/art/environments').mkdir(parents=True)
def fit(im,box,size):return im.crop(box).resize(size,Image.Resampling.NEAREST)
def nine(im,sx,sy,tx,ty):
 for yi in range(len(sy)-1):
  for xi in range(len(sx)-1):b.paste(fit(im,(sx[xi],sy[yi],sx[xi+1],sy[yi+1]),(tx[xi+1]-tx[xi],ty[yi+1]-ty[yi])),(tx[xi],ty[yi]))
# Source floor is already full depth at246. Preserve its SAME-SCALE wood, no floor module.
b.paste(s.crop((0,246,900,430)),(0,246))
# Remove old band-rail ridges BEFORE fitting the curtain, using the same-column cloth below.
q.paste(s.crop((68,160,544,167)),(68,151))
# Existing source side-reveal spill is replaced with source masonry, never new furniture.
b.paste(s.crop((35,58,38,246)),(45,58));b.paste(s.crop((1,58,22,246)),(558,58))
# Source cobalt side reveals+walnut frame form the exact outer stage; cloth is independently fitted.
nine(q,(45,85,535,576),(59,76,211,246),(48,70,536,558),(58,76,214,248))
# Source-shaped shade on REAL lit velvet folds, not title-sized rectangles/global grading.
p=b.load();cloth_changed=0
for yy in range(76,150):
 for xx in range(70,536):
  r,g,bl=p[xx,yy]
  if r>g*.92 and g>bl*1.35 and g>35:
   # Deeper burnt-orange/burgundy velvet absorbs the practical light; hard detail survives.
   p[xx,yy]=(round(r*.65+8),round(g*.40+3),round(bl*.62+3));cloth_changed+=1
# The three compact frame practicals retain clear warm origins at190/330/470.
# Quiet only original tiny header emitters, then replay the SAME source fixture at exact centers.
for yy in range(67,76):
 for xx in range(70,536):
  r,g,bl=p[xx,yy]
  if r>145 and g>75 and r>bl*1.8:p[xx,yy]=(round(r*.43),round(g*.36),round(bl*.52))
header_donor=b.crop((250,68,274,76))
for oldx in (190,306,475):b.paste(header_donor,(oldx-12,68))
lamp=fit(s,(193,70,211,76),(16,5))
for x in (190,330,470):b.paste(lamp,(x-8,70))
# Exact rail150..158: bright contact only150, detailed dark walnut face below.
rail=fit(s,(66,151,544,158),(476,8));rp=rail.load()
for yy in range(8):
 for xx in range(476):
  r,g,bl=rp[xx,yy]
  if yy==0:rp[xx,yy]=s.getpixel((67+int(xx*476/476),152))
  else:rp[xx,yy]=(round(r*.37+7),round(g*.31+4),round(bl*.46+4))
b.paste(rail,(66,150))
# Exact stage208..242; maintain a thin contact edge and dark real216 inset/title material.
stage=fit(s,(66,208,545,242),(476,34));pp=stage.load()
for yy in range(1,34):
 for xx in range(476):
  r,g,bl=pp[xx,yy];factor=.39 if yy<19 else .72;pp[xx,yy]=(round(r*factor+4),round(g*factor*.83+3),round(bl*factor+3))
b.paste(stage,(66,208))
# Re-fit the existing stage inset exactly82,216,444,8; keep grain, not the source bright orange slab.
inset=fit(s,(82,217,526,226),(444,8));ip=inset.load()
for yy in range(8):
 for xx in range(444):
  r,g,bl=ip[xx,yy];ip[xx,yy]=(round(r*.31+7),round(g*.28+4),round(bl*.46+4))
b.paste(inset,(82,216))
# Trim only old bar-front spill; restore source brick reveals below/outside exact front.
b.paste(s.crop((0,184,8,242)),(582,184));b.paste(s.crop((0,184,16,242)),(874,184));b.paste(s.crop((600,36,884,42)),(590,236))
b.paste(s.crop((0,184,10,188)),(590,184));b.paste(s.crop((0,184,20,188)),(854,184))
# Empty backbar outer60072/inner61888,218x62: no reintroduced bottle stock.
nine(s,(598,614,839,858),(72,91,160,185),(600,618,836,854),(72,88,150,194))
# Exact main front188..236, dark real wood under Guest cyan189 and gold staff209.
front=fit(s,(583,186,881,239),(284,48));fp=front.load()
for yy in range(1,48):
 for xx in range(284):
  r,g,bl=fp[xx,yy];fac=.36 if yy<7 else .70;fp[xx,yy]=(round(r*fac+5),round(g*fac*.85+3),round(bl*fac+4))
for xx in range(284):front.putpixel((xx,0),s.getpixel((584+int(xx*295/284),186)))
b.paste(front,(590,188))
# Exact low foreground service shelf404..412; no legs or new foreground barrier.
shelf=fit(s,(40,405,860,412),(820,8));sp=shelf.load()
for yy in range(8):
 for xx in range(820):
  r,g,bl=sp[xx,yy]
  sp[xx,yy]=s.getpixel((40+xx,406)) if yy==0 else (round(r*.35+4),round(g*.32+3),round(bl*.44+3))
b.paste(shelf,(40,404));b.paste(s.crop((864,404,866,413)),(860,404))
# Replay actual source wordmark pixels LAST, matching original neon-after-construction order.
# The exact stage top58 otherwise clips the lower glyph rows of AFTER HOURS/JAZZ.
for box,kind in [((120,42,255,65),'cyan'),((370,38,438,65),'gold')]:
 for yy in range(box[1],box[3]):
  for xx in range(box[0],box[2]):
   r,g,bl=s.getpixel((xx,yy))
   ok=(g>65 and bl>65 and g>r*1.4 and bl>r*1.3) if kind=='cyan' else (r>90 and g>70 and r>bl*1.4 and g>bl*1.4)
   if ok:b.putpixel((xx,yy),(r,g,bl))
b.save(root/'background-board-review.png');b.resize((1800,860),Image.Resampling.NEAREST).save(asset/'background.png');b.crop((590,188,874,236)).convert('RGBA').resize((568,96),Image.Resampling.NEAREST).save(asset/'counters/jazz_bar.png')
animations=[]
def save2(im,name):im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST).save(asset/'anim'/name)
glyph=Image.new('RGBA',(68,26));gp=glyph.load()
for yy in range(26):
 for xx in range(68):
  r,g,bl=b.getpixel((370+xx,40+yy))
  if r>130 and g>85 and r>bl*1.5:gp[xx,yy]=(r,g,bl,215)
save2(glyph,'jazz_glyph_pulse.png');period=math.pi/3.6;animations.append({'id':'jazz_glyph_pulse','type':'pulse','texture':'anim/jazz_glyph_pulse.png','rect':[370,40,68,26],'min_opacity':.12,'max_opacity':.28,'period':period,'phase':1.16/3.6-period/4,'blend':'add','still':'first'})
pink=Image.new('RGBA',(124,34));pd=ImageDraw.Draw(pink)
for x in range(124):
 if x%17 not in (0,1,2):pd.point((x,28),fill=(226,75,153,115))
 if x%11 not in (0,1,2,3):pd.point((x,29),fill=(203,61,139,68))
save2(pink,'backbar_magenta_light.png');period=math.pi/4.8;animations.append({'id':'backbar_magenta_light','type':'pulse','texture':'anim/backbar_magenta_light.png','rect':[696,146,124,34],'min_opacity':.20,'max_opacity':.40,'period':period,'phase':6.96/4.8-period/4,'blend':'add','still':'first'})
# BOTH distinct high-air families, each translating five ribbons into two sparse coherent fields.
for family,x0,y0,ww,color,alpha in [('amber',58,70,768,(207,142,75),12),('cyan',140,126,620,(72,169,206),7)]:
 for layer,bands,speed in [(0,((6,180,0),(42,148,250),(78,116,510)),(10,.30)),(1,((24,164,140),(60,132,420)),(16,-.26))]:
  im=Image.new('RGBA',(ww,90));d=ImageDraw.Draw(im)
  for j,(y,width,start) in enumerate(bands):
   for x in range(width):
    yy=y+round(math.sin((x+j*19)*.028)*2);taper=max(0,min(1,x/18,(width-1-x)/18))
    for dy in range(-3,4):
     a=round(alpha*taper*(1-abs(dy)/4))
     if (x+j*17+dy)%43 not in (0,1):d.point(((start+x)%ww,yy+dy),fill=(*color,a))
  name=f'{family}_air_{layer}.png';save2(im,name);animations.append({'id':f'{family}_air_{layer}','type':'scroll','texture':'anim/'+name,'rect':[x0,y0,ww,90],'speed':list(speed),'opacity':.95,'blend':'add','still':'hide'})
fold=Image.new('RGBA',(6,8));fd=ImageDraw.Draw(fold);fd.line((3,0,3,2),fill=(238,179,84,155));fd.line((2,4,2,7),fill=(246,205,122,155));fd.line((1,4,4,4),fill=(255,232,172,185));save2(fold,'fold_reflection.png')
wood=Image.new('RGBA',(8,6));wd=ImageDraw.Draw(wood);wd.line((0,3,2,3),fill=(239,182,83,160));wd.line((4,2,7,2),fill=(249,213,139,170));wd.point((5,3),fill=(255,238,175,190));save2(wood,'bar_trim_reflection.png')
for i,(rect,texture) in enumerate([([181,114,6,8],'fold_reflection.png'),([319,112,6,8],'fold_reflection.png'),([463,114,6,8],'fold_reflection.png'),([700,182,8,6],'bar_trim_reflection.png')]):
 period=math.pi/4.2;animations.append({'id':f'warm_glint_{i}','type':'pulse','texture':'anim/'+texture,'rect':rect,'min_opacity':.18,'max_opacity':.36,'period':period,'phase':i*1.7/4.2-period/4,'blend':'add','still':'hide'})
for i,color in enumerate(((185,135,65),(74,126,195),(159,86,141),(197,146,75),(70,131,197),(158,85,140),(190,139,67))):
 width=72-4*i;im=Image.new('RGBA',(width,2));p=im.load()
 for x in range(width):
  a=round(110*max(0,min(1,x/9,(width-1-x)/9)));a=round(a*.4) if (x+3*i)%19 in (0,1) else a;p[x,0]=(*color,a)
  if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
 save2(im,f'floor_glint_{i}.png');speed=18+2.5*i;y=274+(i%4)*14;animations.append({'id':f'floor_glint_{i}','type':'mover','texture':f'anim/floor_glint_{i}.png','size':[width,2],'from':[-90,y],'to':[950,y],'duration':1040/speed,'phase':137*i/speed,'opacity':.18,'blend':'add','still':'hide'})
assert len(animations)==17
manifest={'schema':'bth.environment_art/v1','environment_id':'jazz_club','board_size':[900,430],'pixel_scale':2,'background':{'texture':'background.png'},'animations':animations,'counters':{'jazz_bar':{'texture':'counters/jazz_bar.png','bleed':[0,0,0,0]}}};(root/'data/art/environments/jazz_club.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'data/art/environments/index.json').write_text(json.dumps({'enabled':['gas_station_casino','corner_store','back_alley','motel','bar','pawn_shop','jazz_club']},indent=2)+'\n');validate_manifest(manifest,'jazz_club',asset,counter_rectangles(REPO,'jazz_club'))
files={}
for path in sorted(list((root/'assets').rglob('*.png'))+list((root/'data').rglob('*.json'))):
 v={'sha256':H(path),'bytes':path.stat().st_size}
 if path.suffix=='.png':
  im=Image.open(path);v.update(size=list(im.size),mode=im.mode)
  if im.mode=='RGBA':v['alpha_extrema']=list(im.getchannel('A').getextrema())
 files[path.relative_to(root).as_posix()]=v
package_sha=hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(files.items())).encode()).hexdigest()
record={'package_id':'jazz_club-v1-r3','status':'SEALED_TRIAL_NOT_PASSED','package_sha256':package_sha,'files':files,'sources':{str(raw):H(raw)},'frozen_generation_inputs':json.loads((artist/'inputs/input-provenance-generation-v1.json').read_text()),'notes':['Own burgundy/walnut/cobalt/plum/brass identity; no Bar/Gas material donor. All source originals preserved.','Exact stageouter48,58,510,190,inner70,76,466,138; rail66,150,476,8; lowstage66,208,476,34 and dark inset82,216,444,8; backbar60072/inner61888; opaque568x96mainfront59018828448; foregroundshelf404..412.','Old misplaced rail removed before replay. Source-shaped burnt-orange/burgundy velvet regrade on actual hot lit cloth, retaining detail and3compact frame practicals at190/330/470. No label-sized patch or global grade.','Single same-scale full-depth original woodfloor retained at246; no floor module,stretch or erased-table reveal. No painted cast,instruments,stock,new chairs/tables/legs.','17moving entries:2distinct pulses,2amber+2cyan sparse high-air fields translating both5-ribbon families,4material reflections,7room floor movers. Both air families distinct; no static cones counted as motion.','Buried old704196glint adapted to existing upperbartrim at704185,entire6pxrect182..188above solidfront188; no alpha holes or renderer exception.','Seven floor movers explicitly consolidate shared sheen+older reflection family. Warmamber/cobalt/plum on dry indoor wood,no raised dashes/wetpavement.','Air peak effective alpha amber12/255*.95=.044706,cyan7/255*.95=.026078, sparse stepped cores/no blur.','R2: first exact-fit R1 had lower source wordmark rows clipped by stage top58 and missed near-white cloth cores in the warm mask. R1 preserved as internal failed static; replay actual glyph pixels last and quiet ALL source-shaped warm upper velvet through150, retaining warm lower cloth below the rail. No text/contact movement or global grade.','R3: remove the old shifted micro-emitter/body remnants on the same physical upper walnut frame before replaying exactly3source-derived static practicals at190/330/470,y70. Decorative interpretation of legacy cone origins, not literal y34 emitter equivalence; no added independent motion.','Actual current5union/readability,motion/RM/replay/source-context acceptance still pending.']};(root/'package-seal.json').write_text(json.dumps(record,indent=2));(root/'edit-record.json').write_text(json.dumps(record,indent=2));print(json.dumps({'package':str(root),'package_sha256':package_sha,'background_sha256':files['assets/art/environments/jazz_club/background.png']['sha256'],'files':len(files),'entries':17,'cloth_pixels_locally_regraded':cloth_changed,'validator':'PASS'}))


