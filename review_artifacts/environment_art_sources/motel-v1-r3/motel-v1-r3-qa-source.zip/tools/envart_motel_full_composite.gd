extends SceneTree
const MainScene := preload("res://scenes/main.tscn")
const CanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const ScenarioEngineScript := preload("res://scripts/core/scenario_engine.gd")
class FixedClockCanvas:
    extends CanvasScript
    var qa_fixed_draw := false
    var qa_object_clock := 0.0
    var qa_route_clock := 0.0
    var qa_art_clock := 0.0
    var qa_last_view: Dictionary = {}
    func _draw() -> void:
        if not qa_fixed_draw:
            super._draw()
            return
        var normal_clock := flicker
        var normal_route_clock := actor_route_time
        flicker = qa_object_clock
        actor_route_time = qa_route_clock
        super._draw()
        qa_last_view = current_view_snapshot()
        qa_last_view["qa_draw_route_clock"] = actor_route_time
        qa_last_view["qa_draw_art_clock"] = qa_art_clock
        flicker = normal_clock
        actor_route_time = normal_route_clock
    func _draw_environment_art_animations(pack: EnvironmentArtPack) -> void:
        if not qa_fixed_draw:
            super._draw_environment_art_animations(pack)
            return
        var object_clock := flicker
        flicker = qa_art_clock
        super._draw_environment_art_animations(pack)
        flicker = object_clock
var output := ""
var checks := 0
var findings: Array[String] = []
var results: Array = []
func _initialize() -> void:
    output = OS.get_environment("BTH_QA_EVIDENCE_DIR")
    call_deferred("_run")
func _check(ok: bool,label: String) -> void:
    checks += 1
    if not ok:
        findings.append(label)
        push_error(label)
func _json(value: Variant) -> Variant:
    return JSON.parse_string(JSON.stringify(value))
func _settle(frames: int = 8) -> void:
    for i in range(frames):
        await process_frame
        await RenderingServer.frame_post_draw
func _arrivals(canvas: Control) -> void:
    await create_timer(4.0).timeout
    var waited := 4.0
    while not (canvas.get("person_transits") as Dictionary).is_empty() and waited < 12.0:
        await create_timer(0.25).timeout
        waited += 0.25
    _check((canvas.get("person_transits") as Dictionary).is_empty(),"Natural person arrivals completed")
    await RenderingServer.frame_post_draw
func _image(viewport: SubViewport,canvas: FixedClockCanvas,art_clock: float) -> Dictionary:
    canvas.qa_art_clock = art_clock
    for i in range(6):
        canvas.queue_redraw()
        await process_frame
        await RenderingServer.frame_post_draw
    return {"image":viewport.get_texture().get_image(),"view":_json(canvas.qa_last_view)}
func _run() -> void:
    _check(output.begins_with("E:"),"Admitted E evidence required")
    root.size = Vector2i(1280,720)
    var app := MainScene.instantiate()
    app.set("script_prewarm_stopping",true)
    root.add_child(app)
    await _settle()
    var neutral := InputEventMouseMotion.new()
    neutral.position = Vector2(900,100)
    neutral.global_position = neutral.position
    root.push_input(neutral,true)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id",app.get("environment_test_archetype_option"),"motel")
    app.call("_refresh_environment_test_identity_options")
    var catalog: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/environments/scenarios.json"))
    var selections: Array[String] = ["__none"]
    for row in catalog["motel"]:
        selections.append(str(row["id"]))
    var full_pack := PackScript.load_pack("motel")
    _check(full_pack != null and full_pack.animations.size()==14,"Exact Motel14 compiled animation entries")
    if full_pack == null:
        quit(1)
        return
    for scenario in selections:
        app.call("_environment_test_select_id",app.get("environment_test_scenario_option"),scenario)
        app.get("environment_test_seed_input").text = "LAYOUT-SURVEY-QA"
        var generated: Dictionary = app.call("start_environment_test_session")
        _check(bool(generated.get("ok",false)),scenario+" production practice generation")
        await _settle()
        var state: Variant = app.get("run_state")
        var resolved: Dictionary = {}
        if scenario != "__none":
            var candidate: Dictionary = state.current_environment.duplicate(true)
            var definition: Dictionary = candidate.get("scenario_sequence_definition",{})
            var current_state: Dictionary = candidate.get("scenario_sequence_state",{}).duplicate(true)
            var committed: Dictionary = ScenarioEngineScript._commit_sequence_candidate(candidate,candidate.duplicate(true),definition,{"ok":true,"state":current_state,"errors":[]})
            _check(bool(committed.get("ok",false)),scenario+" unchanged Engine commit")
            resolved = state.call("_publish_scenario_membership_candidate",candidate,committed,"qa_initial_same_state") if bool(committed.get("ok",false)) else committed
            _check(bool(resolved.get("ok",false)),scenario+" production physical publication")
            app.call("_set_current_screen","ENVIRONMENT")
            app.call("_clear_selected_game_action")
            app.call("_render_environment_screen")
        await _settle()
        var actual: Control = app.get("environment_canvas")
        await _arrivals(actual)
        _check(bool(state.call("validate_room_action_authority").get("ok",false)),scenario+" live room authority")
        var snapshot: Dictionary = actual.get("foundation_snapshot").duplicate(true)
        var actual_view: Dictionary = _json(actual.call("current_view_snapshot"))
        var source_json := JSON.stringify(snapshot)
        root.get_texture().get_image().save_png(output.path_join(scenario+"_actual.png"))
        var viewport := SubViewport.new()
        viewport.size = Vector2i(1800,860)
        viewport.disable_3d = true
        viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
        viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
        root.add_child(viewport)
        var canvas := FixedClockCanvas.new()
        canvas.size = Vector2(1800,860)
        viewport.add_child(canvas)
        canvas.call("render_environment_snapshot",snapshot)
        await _arrivals(canvas)
        canvas.qa_object_clock = float(actual.get("flicker"))
        canvas.qa_route_clock = float(canvas.get("actor_route_time"))
        canvas.qa_fixed_draw = true
        var entries: Array = []
        for entry in full_pack.animations:
            # Full all-entry proof in Base; repeat occlusion-sensitive CRT/glints in all4 scenarios.
            if scenario != "__none" and not (entry.id.begins_with("crt_") or entry.id.begins_with("glass_glint_")):
                continue
            var solo := PackScript.new()
            solo.environment_id = full_pack.environment_id
            solo.background = full_pack.background
            solo.background_rect = full_pack.background_rect
            solo.counters = full_pack.counters
            solo.animations.append(entry)
            canvas.call("_set_environment_art_pack",solo)
            var t0 := 0.0
            var t1 := 0.5
            match entry.kind:
                PackScript.AnimationKind.PULSE:
                    t0 = entry.period * 10.25 - entry.phase
                    t1 = t0 + entry.period * 0.5
                PackScript.AnimationKind.MOVER:
                    t0 = (entry.duration+entry.gap)*2.0-entry.phase+entry.duration*0.5
                    t1 = t0+1.0
                PackScript.AnimationKind.FRAMES:
                    t0 = 0.05 / entry.fps - entry.phase
                    t1 = float(entry.frame_count-1)+0.05
                    t1 = t1 / entry.fps - entry.phase
                    if entry.id == "crt_fast_scan":
                        t0 = 7.05/entry.fps-entry.phase
                        t1 = 18.05/entry.fps-entry.phase
            var a := await _image(viewport,canvas,t0)
            var same := await _image(viewport,canvas,t0)
            var b := await _image(viewport,canvas,t1)
            var ia: Image = a["image"]
            var ib: Image = b["image"]
            var identical_control: bool = ia.get_data()==(same["image"] as Image).get_data()
            var geometry: bool = a["view"]["object_layout"]==b["view"]["object_layout"] and a["view"]["object_layout"]==actual_view["object_layout"]
            var objects: bool = a["view"]["objects"]==b["view"]["objects"] and a["view"]["objects"]==actual_view["objects"]
            var clocks: bool = a["view"]["scene_animation_time"]==b["view"]["scene_animation_time"] and a["view"]["qa_draw_route_clock"]==b["view"]["qa_draw_route_clock"]
            _check(identical_control,scenario+"/"+entry.id+" fixed-clock control pair pixel-identical")
            _check(geometry and objects,scenario+"/"+entry.id+" exact actual objects/layout/labels unchanged")
            _check(clocks,scenario+"/"+entry.id+" identical object/route/label draw clocks")
            _check(ia.get_data()!=ib.get_data(),scenario+"/"+entry.id+" real full-composite pixels change")
            var prefix := scenario+"__"+entry.id
            ia.save_png(output.path_join(prefix+"_a.png"))
            ib.save_png(output.path_join(prefix+"_b.png"))
            entries.append({"id":entry.id,"a":prefix+"_a.png","b":prefix+"_b.png","art_clock_a":t0,"art_clock_b":t1,"frame_a":entry.frame_at(t0,false),"frame_b":entry.frame_at(t1,false),"identical_control_pixels":identical_control,"actual_objects_layout_equal":geometry and objects,"object_route_label_clocks_equal":clocks,"visible_composite_change":ia.get_data()!=ib.get_data(),"view_a":a["view"],"view_b":b["view"]})
        _check(JSON.stringify(snapshot)==source_json,scenario+" original production snapshot unchanged")
        results.append({"scenario":scenario,"actual_view":actual_view,"source_snapshot":snapshot,"publication":resolved,"entries":entries,"processing_remained_active":canvas.is_processing()})
        viewport.free()
        await process_frame
        _save()
    app.queue_free()
    await process_frame
    PackScript.shutdown_loading()
    _save()
    print("MOTEL_FULL_COMPOSITE_RESULT ",JSON.stringify({"checks":checks,"findings":findings,"scenarios":results.size()}))
    quit(0 if findings.is_empty() else 1)
func _save() -> void:
    var report := {"checks":checks,"findings":findings,"scenarios":results,"scope":"QA-only full-canvas diagnostic complementary to autonomous normal production excerpt. Exact production snapshot, draw order, labels, live objects, fronts, unchanged EnvironmentArtRenderer and original single-entry art bytes. Draw-time object/route/label clocks held identical; only renderer art clock differs. All inherited processing active, no source edits, no alpha/opacity/brightness boost. Quantify pixel visibility outside conservative occluder masks separately. Not a final art acceptance claim."}
    var f := FileAccess.open(output.path_join("motel_full_composite.json"),FileAccess.WRITE)
    f.store_string(JSON.stringify(report,"\t"))
    f.close()
