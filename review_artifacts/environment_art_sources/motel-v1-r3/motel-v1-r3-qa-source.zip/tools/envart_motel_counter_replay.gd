extends SceneTree
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const CanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
class FixtureCanvas:
    extends CanvasScript
    var replay := false
    var front: Dictionary = {}
    var foot := Vector2.ZERO
    func _ensure_room_surface_draw_cache() -> void:
        room_surface_counters_by_id_cache = {str(front["id"]):front}
        room_surface_slots_by_id_cache = {"fixed.qa_counter_person":{"support_id":str(front["id"])}}
    func _draw() -> void:
        flicker = 0.0
        _scale_canvas()
        _bg()
        _draw_environment_art_animations(environment_art_pack)
        _draw_counter_foreground_art(front)
        _draw_named_character("nell",foot,1.0,"staff","left")
        if replay:
            _draw_room_foreground_occluders([{"slot_id":"fixed.qa_counter_person"}])
        draw_string(ThemeDB.fallback_font,Vector2(10,426),"QA-ONLY COUNTER PERSON FIXTURE. No production placement changed.",HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color.WHITE)
        draw_set_transform(Vector2.ZERO,0.0,Vector2.ONE)
var output := ""
func _initialize() -> void:
    output = OS.get_environment("BTH_QA_EVIDENCE_DIR")
    call_deferred("_run")
func _run() -> void:
    if not output.begins_with("E:"):
        quit(1)
        return
    var pack := PackScript.load_pack("motel")
    if pack == null:
        push_error("Actual sealed Motel trial pack failed to load")
        quit(1)
        return
    var surfaces: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/environments/placement_surfaces.json"))
    var room: Dictionary = surfaces["maps"].filter(func(m): return m["id"]=="motel")[0]
    var rows: Array = []
    var passed := true
    for id in ["motel_lobby_table","motel_merchandise_counter"]:
        var front: Dictionary = room["counters"].filter(func(c): return str(c.get("foreground_art_id",""))==id)[0]
        var rect := Rect2(float(front["x0"]),float(front["top_y"]),float(front["x1"])-float(front["x0"]),float(front["front_y"])-float(front["top_y"]))
        var view := SubViewport.new()
        view.size = Vector2i(1800,860)
        view.disable_3d = true
        view.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
        view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
        root.add_child(view)
        var canvas := FixtureCanvas.new()
        canvas.size = Vector2(1800,860)
        canvas.environment_id = "motel"
        canvas.front = front
        canvas.foot = Vector2(rect.get_center().x,rect.position.y+32.0)
        view.add_child(canvas)
        canvas.call("_set_environment_art_pack",pack)
        var without := await _image(view)
        without.save_png(output.path_join(id+"_without_replay.png"))
        canvas.replay = true
        canvas.queue_redraw()
        var with_replay := await _image(view)
        with_replay.save_png(output.path_join(id+"_with_replay.png"))
        var region := Rect2i(Vector2i(rect.position*2.0),Vector2i(rect.size*2.0))
        var texture: Image = pack.counters[id].texture.get_image()
        var mismatch := 0
        var covered := 0
        var alpha_min := 1.0
        var alpha_max := 0.0
        for y in range(region.size.y):
            for x in range(region.size.x):
                var expected := texture.get_pixel(x,y)
                var actual := with_replay.get_pixel(region.position.x+x,region.position.y+y)
                alpha_min = minf(alpha_min,expected.a)
                alpha_max = maxf(alpha_max,expected.a)
                if absf(actual.r-expected.r)>0.008 or absf(actual.g-expected.g)>0.008 or absf(actual.b-expected.b)>0.008:
                    mismatch += 1
                if without.get_pixel(region.position.x+x,region.position.y+y)!=actual:
                    covered += 1
        var upper_unchanged := true
        for y in range(int((rect.position.y-36.0)*2.0),int(rect.position.y*2.0)):
            for x in range(int((canvas.foot.x-32.0)*2.0),int((canvas.foot.x+32.0)*2.0)):
                if without.get_pixel(x,y)!=with_replay.get_pixel(x,y):
                    upper_unchanged = false
        var ok := mismatch==0 and covered>0 and upper_unchanged and alpha_min==1.0 and alpha_max==1.0
        passed = passed and ok
        rows.append({"counter_id":id,"source_front":front,"qa_person_foot":[canvas.foot.x,canvas.foot.y],"counter_pixel_mismatches":mismatch,"covered_body_pixels":covered,"upper_person_unchanged":upper_unchanged,"alpha_min":alpha_min,"alpha_max":alpha_max,"ok":ok})
        view.free()
        await process_frame
    var result := {"qa_only":true,"production_objects_moved":false,"synthetic_person":"Unchanged Nell painter; QA-only feet at front.top+32, center x. Production actors untouched.","replay_method":"_draw_room_foreground_occluders","cases":rows,"ok":passed}
    var file := FileAccess.open(output.path_join("motel_counter_replay.json"),FileAccess.WRITE)
    file.store_string(JSON.stringify(result,"\t"))
    file.close()
    print("MOTEL_COUNTER_REPLAY ",JSON.stringify(result))
    PackScript.shutdown_loading()
    await process_frame
    quit(0 if passed else 1)
func _image(view: SubViewport) -> Image:
    for i in range(6):
        await process_frame
        await RenderingServer.frame_post_draw
    return view.get_texture().get_image()
