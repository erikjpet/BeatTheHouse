extends "res://tools/environment_art_baseline_capture.gd"
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const CanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
var baseline_source := ""
var findings: Array[String] = []
var checks := 0


func _initialize() -> void:
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--baseline-source="):
            baseline_source = argument.trim_prefix("--baseline-source=")


func _run() -> void:
    if baseline_source.is_empty() or not FileAccess.file_exists(baseline_source):
        push_error("Back proof requires the exact Phase0 canvas source.")
        quit(1)
        return
    root.size = Vector2i(1280, 720)
    app = MainScene.instantiate()
    app.set("script_prewarm_stopping", true)
    root.add_child(app)
    await _settle(8)
    DirAccess.make_dir_recursive_absolute(out_dir)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id", app.get("environment_test_archetype_option"), "back_alley")
    app.call("_refresh_environment_test_identity_options")
    var selections := ["__none", "back_alley_street_craps", "back_alley_cruiser_parked", "back_alley_fence_night", "back_alley_nothing_moving"]
    var original := GDScript.new()
    original.source_code = FileAccess.get_file_as_string(baseline_source).replace("class_name PixelSceneCanvas", "class_name EnvartBackOriginalCanvas")
    if original.reload() != OK:
        quit(1)
        return
    for scenario in selections:
        app.call("_environment_test_select_id", app.get("environment_test_scenario_option"), scenario)
        app.get("environment_test_seed_input").text = SEED_TEXT
        var generated: Dictionary = app.call("start_environment_test_session")
        _check(bool(generated.get("ok", false)), "Production practice generation: " + scenario)
        if not bool(generated.get("ok", false)):
            continue
        await _settle(8)
        var canvas: Control = app.get("environment_canvas")
        var arrival := await _settle_production_arrivals(canvas)
        _check(int(arrival["remaining_person_transits"]) == 0, "Actual initial actor arrival completed: " + scenario)
        var snapshot: Dictionary = canvas.get("foundation_snapshot")
        _check(str(snapshot.get("scenario_id", "")) == ("" if scenario == "__none" else scenario), "Exact scenario selected: " + scenario)
        await RenderingServer.frame_post_draw
        root.get_texture().get_image().save_png(out_dir.path_join(scenario + "_play.png"))
        var pair := await _compare_pair(original, snapshot, scenario)
        report[scenario] = {"actual_view": canvas.call("current_view_snapshot"), "snapshot": snapshot, "comparison": pair, "actual_arrival_wait": arrival}
        # Normal Reduce Motion setting, never process disabling, gives an exact
        # static geometry and image comparison as well as the live paired views.
        var reduced := snapshot.duplicate(true)
        reduced["reduce_motion"] = true
        var still_pair := await _compare_pair(original, reduced, scenario + "_reduced")
        report[scenario]["reduce_motion_comparison"] = still_pair
    # Back Alley has null open_hours: verify the actual always-open rule instead
    # of fabricating a closing-grace context borrowed from another room.
    app.call("_environment_test_select_id", app.get("environment_test_scenario_option"), "__none")
    app.get("environment_test_seed_input").text = SEED_TEXT
    var fresh_base: Dictionary = app.call("start_environment_test_session")
    _check(bool(fresh_base.get("ok", false)), "Fresh Base generation for always-open boundary")
    await _settle(8)
    var run_state: Variant = app.get("run_state")
    var archetype: Dictionary = app.call("_current_environment_archetype")
    _check(archetype.get("open_hours") == null, "Authored Back Alley hours are null")
    var open_rows: Array = []
    for minute in [1380, 0, 720]:
        var before_minute: int = run_state.game_minute_of_day()
        var clock_result: Dictionary = run_state.advance_game_clock_minutes(posmod(minute-before_minute,1440))
        var open_status: Dictionary = app.call("_environment_open_status", archetype)
        var boundary_result: bool = app.call("_apply_closing_time_clock_boundary")
        _check(bool(clock_result.get("ok", false)) and bool(open_status.get("open", false)) and not run_state.closing_time_active(), "Always-open normal clock boundary at minute"+str(minute))
        open_rows.append({"minute":minute,"clock_result":clock_result,"open_status":open_status,"boundary_result":boundary_result,"closing_active":run_state.closing_time_active()})
    app.call("_refresh")
    await _settle(8)
    var closing_canvas: Control = app.get("environment_canvas")
    _check(closing_canvas.get("environment_art_pack") != null, "Always-open time changes retain room art")
    report["always_open"] = {"authored_open_hours":archetype.get("open_hours"),"checks":open_rows,"scope":"Normal clock/boundary paths, no forced closing state."}
    closing_canvas.call("set_developer_slot_placement_mode", true)
    var began: Dictionary = closing_canvas.call("current_view_snapshot")
    await RenderingServer.frame_post_draw
    var first := root.get_texture().get_image()
    await create_timer(0.45).timeout
    await RenderingServer.frame_post_draw
    var second := root.get_texture().get_image()
    var ended: Dictionary = closing_canvas.call("current_view_snapshot")
    _check(float(ended["scene_animation_time"]) > float(began["scene_animation_time"]) and int(ended["scene_idle_animation_redraw_count"]) > int(began["scene_idle_animation_redraw_count"]), "Packed clock and redraws advance autonomously while placement is open.")
    _check(first.get_data() != second.get_data(), "Packed play visibly changes with no pointer input.")
    first.save_png(out_dir.path_join("placement_idle_a.png"))
    second.save_png(out_dir.path_join("placement_idle_b.png"))
    report["placement_liveness"] = {"before": began, "after": ended}
    var file := FileAccess.open(out_dir.path_join("back_proof.json"), FileAccess.WRITE)
    file.store_string(JSON.stringify({"checks": checks, "findings": findings, "views": report}, "\t"))
    file.close()
    print("ENVART_BACK_PROOF " + JSON.stringify({"checks": checks, "findings": findings, "scenario_count": 4}))
    app.queue_free()
    await process_frame
    quit(0 if findings.is_empty() else 1)


func _compare_pair(original: GDScript, snapshot: Dictionary, name_value: String) -> Dictionary:
    var before_view := SubViewport.new()
    var after_view := SubViewport.new()
    before_view.size = Vector2i(900, 430)
    after_view.size = before_view.size
    before_view.disable_3d = true
    after_view.disable_3d = true
    before_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    after_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    root.add_child(before_view)
    root.add_child(after_view)
    var before: Control = original.new()
    var after: Control = CanvasScript.new()
    before.size = Vector2(900, 430)
    after.size = before.size
    before_view.add_child(before)
    after_view.add_child(after)
    before.call("render_environment_snapshot", snapshot)
    after.call("render_environment_snapshot", snapshot)
    await _settle(8)
    await RenderingServer.frame_post_draw
    var before_layout: Dictionary = before.call("current_view_snapshot")
    var after_layout: Dictionary = after.call("current_view_snapshot")
    var equal_layout: bool = before_layout["object_layout"] == after_layout["object_layout"]
    _check(equal_layout, "Every object, label, footprint, hit rectangle and z order matches the original at the same live clock: " + name_value)
    var before_image := before_view.get_texture().get_image()
    var after_image := after_view.get_texture().get_image()
    before_image.save_png(out_dir.path_join(name_value + "_original.png"))
    after_image.save_png(out_dir.path_join(name_value + "_pack.png"))
    var stable := true
    if bool(snapshot.get("reduce_motion", false)):
        await create_timer(0.3).timeout
        await RenderingServer.frame_post_draw
        stable = after_image.get_data() == after_view.get_texture().get_image().get_data()
        _check(stable, "Reduce Motion stays pixel-identical over time: " + name_value)
    var result := {"layout_equal": equal_layout, "before_layout": before_layout["object_layout"], "after_layout": after_layout["object_layout"], "reduce_motion_stable": stable, "pack_active": after.get("environment_art_pack") != null}
    _check(bool(result["pack_active"]), "The proof actually uses the pack: " + name_value)
    before_view.free()
    after_view.free()
    return result


func _check(value: bool, message: String) -> void:
    checks += 1
    if not value:
        findings.append(message)
        push_error(message)

func _settle_production_arrivals(canvas: Control) -> Dictionary:
    var clock_before: float = canvas.get("flicker")
    var waited := 0.0
    await create_timer(4.0).timeout
    waited = 4.0
    while not (canvas.get("person_transits") as Dictionary).is_empty() and waited < 12.0:
        await create_timer(0.25).timeout
        waited += 0.25
    await RenderingServer.frame_post_draw
    return {"clock_before": clock_before, "clock_after": canvas.get("flicker"), "timer_wait_seconds": waited, "remaining_person_transits": (canvas.get("person_transits") as Dictionary).size(), "input_during_wait": false, "positions_modified": false}
