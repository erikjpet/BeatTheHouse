extends SceneTree
const CanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
const PackScript := preload("res://scripts/ui/environment_art_pack.gd")
const RendererScript := preload("res://scripts/ui/environment_art_renderer.gd")
const SOURCE := "E:/CodexQA/BTH/runs/BTH-ENVART-MOTELTRIAL-20261114-r3-composite-01/evidence"
class ActorMaskCanvas:
    extends CanvasScript
    var qa_clock := 0.0
    var qa_rect := Rect2()
    var qa_record: Dictionary = {}
    func _draw() -> void:
        flicker = qa_clock
        _scale_canvas()
        _draw_character_actor(qa_rect,qa_record)
        draw_set_transform(Vector2.ZERO,0.0,Vector2.ONE)
var output := ""
func _initialize() -> void:
    output = OS.get_environment("BTH_QA_EVIDENCE_DIR")
    call_deferred("_run")
func _render(node: Node,viewport: SubViewport = null) -> Image:
    for i in range(6):
        await process_frame
        await RenderingServer.frame_post_draw
    return (node.get("texture") as Texture2D).get_image() if viewport == null else viewport.get_texture().get_image()
func _run() -> void:
    var proof: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(SOURCE.path_join("motel_full_composite.json")))
    var context: Dictionary = proof["scenarios"].filter(func(c): return c["scenario"]=="motel_wedding_overflow")[0]
    var pair: Dictionary = context["entries"].filter(func(e): return e["id"]=="glass_glint_1")[0]
    var identity := "scenario::motel_wedding_overflow_desk_clerk"
    var object_data: Dictionary = context["actual_view"]["objects"].filter(func(o): return o["id"]==identity)[0]
    var geometry: Dictionary = context["actual_view"]["object_layout"]["objects"].filter(func(o): return o["id"]==identity)[0]
    var r: Dictionary = geometry["rect"]
    var viewport := SubViewport.new()
    viewport.size = Vector2i(1800,860)
    viewport.disable_3d = true
    viewport.transparent_bg = true
    viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    root.add_child(viewport)
    var mask_canvas := ActorMaskCanvas.new()
    mask_canvas.size = Vector2(1800,860)
    mask_canvas.qa_clock = float(pair["view_a"]["scene_animation_time"])
    mask_canvas.qa_record = object_data
    mask_canvas.qa_rect = Rect2(float(r["x"]),float(r["y"]),float(r["w"]),float(r["h"]))
    viewport.add_child(mask_canvas)
    var mask := await _render(mask_canvas,viewport)
    var mask_control := await _render(mask_canvas,viewport)
    mask.save_png(output.path_join("wedding_clerk_actual_painted_mask.png"))
    var actual_a := Image.load_from_file(SOURCE.path_join(pair["a"]))
    var actual_b := Image.load_from_file(SOURCE.path_join(pair["b"]))
    var pack := PackScript.load_pack("motel")
    var entry: EnvironmentArtPack.AnimationEntry = pack.animations.filter(func(e): return e.id=="glass_glint_1")[0]
    var solo := PackScript.new()
    solo.environment_id = pack.environment_id
    solo.background = pack.background
    solo.background_rect = pack.background_rect
    solo.animations.append(entry)
    var renderer := RendererScript.new()
    root.add_child(renderer)
    renderer.configure(solo)
    renderer.present(float(pair["art_clock_a"]),false,false)
    var under_a := await _render(renderer)
    renderer.present(float(pair["art_clock_b"]),false,false)
    var under_b := await _render(renderer)
    under_a.save_png(output.path_join("wedding_glint_underlying_a.png"))
    under_b.save_png(output.path_join("wedding_glint_underlying_b.png"))
    var changed := 0
    var opaque_covered := 0
    var actual_clerk_pixels_equal := 0
    var actual_changed_in_support := 0
    for y in range(860):
        for x in range(1800):
            if under_a.get_pixel(x,y)==under_b.get_pixel(x,y):
                continue
            changed += 1
            var sprite := mask.get_pixel(x,y)
            if sprite.a==1.0:
                opaque_covered += 1
            var actual := actual_a.get_pixel(x,y)
            if absf(actual.r-sprite.r)<0.008 and absf(actual.g-sprite.g)<0.008 and absf(actual.b-sprite.b)<0.008:
                actual_clerk_pixels_equal += 1
            if actual!=actual_b.get_pixel(x,y):
                actual_changed_in_support += 1
    var ok := changed>0 and opaque_covered==changed and actual_clerk_pixels_equal==changed and actual_changed_in_support==0 and mask.get_data()==mask_control.get_data()
    var result := {"ok":ok,"qa_only":true,"source_pair":SOURCE.path_join("motel_full_composite.json"),"source_actor_id":identity,"source_actor_record":object_data,"actual_geometry":geometry,"fixed_object_clock":mask_canvas.qa_clock,"art_clock_a":pair["art_clock_a"],"art_clock_b":pair["art_clock_b"],"mask_renderer":"Unchanged production _draw_character_actor and TableGameVisuals._draw_table_character, exact actual object/rect/clock onto transparent viewport. No actor moved or hidden in actual app.","underlying_original_entry_changed_pixels":changed,"all_underlying_changed_pixels_covered_by_actual_opaque_clerk":opaque_covered,"actual_final_composite_rgb_matches_clerk_mask_pixels":actual_clerk_pixels_equal,"actual_final_composite_changed_pixels_in_glint_support":actual_changed_in_support,"actor_mask_control_identical":mask.get_data()==mask_control.get_data(),"original171_check_1_finding_receipt_preserved":true,"scope":"Attribute only Wedding glint1 invisibility to correct later live-actor layer. Do not claim Wedding visibility or move art over actor. Auditor/director must adjudicate predicate."}
    var file := FileAccess.open(output.path_join("wedding_glint_occlusion.json"),FileAccess.WRITE)
    file.store_string(JSON.stringify(result,"\t"))
    file.close()
    print("MOTEL_WEDDING_GLINT_OCCLUSION ",JSON.stringify({"ok":ok,"underlying_changed":changed,"opaque_covered":opaque_covered,"actual_rgb_matches":actual_clerk_pixels_equal,"actual_changed":actual_changed_in_support}))
    renderer.free()
    viewport.free()
    PackScript.shutdown_loading()
    await process_frame
    quit(0 if ok else 1)
