extends "res://tools/envart_back_settled_r3.gd"
func _run() -> void:
    if baseline_source.is_empty() or not FileAccess.file_exists(baseline_source):
        push_error("Motel sequence proof requires exact Phase0 canvas source")
        quit(1)
        return
    # Launch admission and capped native process ownership belong to the caller.
    # Require its evidence directory rather than accepting an inherited default.
    var admitted_output := OS.get_environment("BTH_QA_EVIDENCE_DIR").replace("\\", "/").trim_suffix("/")
    var requested_output := out_dir.replace("\\", "/").trim_suffix("/")
    if admitted_output.is_empty() or requested_output != admitted_output or not DirAccess.dir_exists_absolute(admitted_output):
        push_error("Motel proof requires --out exactly equal to existing admitted BTH_QA_EVIDENCE_DIR")
        quit(1)
        return
    root.size=Vector2i(1280,720)
    app=MainScene.instantiate()
    app.set("script_prewarm_stopping",true)
    root.add_child(app)
    await _settle(8)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id",app.get("environment_test_archetype_option"),"motel")
    app.call("_refresh_environment_test_identity_options")
    var catalog: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tools/envart_motel_sequence_cases.json"))
    var cases: Array=catalog["cases"]
    var expected_scenarios := ["motel_conventioneers", "motel_stakeout", "motel_weekly_rates", "motel_wedding_overflow"]
    var source_matches := FileAccess.get_sha256("res://"+str(catalog.get("source",""))) == str(catalog.get("source_sha256",""))
    _check(source_matches and cases.size()==40,"Exact source-derived 40-case Motel catalog")
    if not source_matches or cases.size()!=40:
        quit(1)
        return
    for test_case in cases:
        if not expected_scenarios.has(str(test_case.get("scenario_id",""))):
            push_error("Unexpected scenario in Motel catalog")
            quit(1)
            return
    var full_case_ids: Array = cases.map(func(c): return str(c["scenario_id"])+"__"+str(c["kind"])+"_"+str(c.get("outcome",c.get("phase",""))))
    var requested_filters: Array[String] = []
    var skipped_case_ids: Array[String] = []
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--motel-") or argument == "--smoke-motel-work":
            requested_filters.append(argument)
        if argument.begins_with("--motel-skip-case="):
            var skipped_case := argument.trim_prefix("--motel-skip-case=")
            if not full_case_ids.has(skipped_case):
                push_error("Unknown Motel skipped case: "+skipped_case)
                quit(1)
                return
            skipped_case_ids.append(skipped_case)
        elif argument.begins_with("--motel-scenario="):
            var selected_scenario := argument.trim_prefix("--motel-scenario=")
            if not expected_scenarios.has(selected_scenario):
                push_error("Unknown Motel scenario: "+selected_scenario)
                quit(1)
                return
            cases = cases.filter(func(c): return c["scenario_id"] == selected_scenario)
        if argument == "--smoke-motel-work":
            cases = cases.filter(func(c): return c["scenario_id"] == "motel_conventioneers" and c.get("phase", "") == "beat_1")
        elif argument.begins_with("--motel-case="):
            var selected_case := argument.trim_prefix("--motel-case=")
            cases = cases.filter(func(c): return str(c["scenario_id"])+"__"+str(c["kind"])+"_"+str(c.get("outcome",c.get("phase",""))) == selected_case)
    cases = cases.filter(func(c): return not skipped_case_ids.has(str(c["scenario_id"])+"__"+str(c["kind"])+"_"+str(c.get("outcome",c.get("phase","")))))
    if cases.is_empty():
        push_error("Motel case selection matched no cases")
        quit(1)
        return
    catalog = catalog.duplicate(true)
    catalog["cases"] = cases
    var batch_scope := {"full_catalog_count":40,"selected_count":cases.size(),"selected_case_ids":cases.map(func(c): return str(c["scenario_id"])+"__"+str(c["kind"])+"_"+str(c.get("outcome",c.get("phase","")))),"requested_filters":requested_filters,"explicitly_skipped_case_ids":skipped_case_ids,"baseline_source":baseline_source,"baseline_source_sha256":FileAccess.get_sha256(baseline_source),"helper_sha256":FileAccess.get_sha256("res://tools/envart_motel_sequence_proof_r1.gd")}

    var library: Variant=app.get("library")
    var definitions:=_rw06_1_review_definitions(library,cases)
    var original:=GDScript.new()
    original.source_code=FileAccess.get_file_as_string(baseline_source).replace("class_name PixelSceneCanvas","class_name EnvartMotelSequenceOriginalCanvas")
    if original.reload()!=OK:
        quit(1)
        return
    var completed: Array=[]
    var serial:=0
    for scenario_value in definitions.keys():
        var scenario:=str(scenario_value)
        var definition: Dictionary=definitions[scenario]
        app.call("_environment_test_select_id",app.get("environment_test_scenario_option"),scenario)
        app.get("environment_test_seed_input").text=SEED_TEXT
        var generated: Dictionary=app.call("start_environment_test_session")
        _check(bool(generated.get("ok",false)),"Initial production practice generation: "+scenario)
        if not bool(generated.get("ok",false)):
            continue
        await _settle(8)
        var run_state: Variant=app.get("run_state")
        var initial_environment: Dictionary=run_state.current_environment.duplicate(true)
        var initial_state: Dictionary=initial_environment.get("scenario_sequence_state",{}).duplicate(true)
        for case_value in cases:
            var test_case: Dictionary=case_value
            if test_case["scenario_id"]!=scenario:
                continue
            var name_value:=scenario+"__"+str(test_case["kind"])+"_"+str(test_case.get("outcome",test_case.get("phase","")))
            var case_findings_start := findings.size()
            var state:=initial_state.duplicate(true)
            var transactions: Array=[]
            var ok:=true
            for command_value in test_case["commands"]:
                var applied:=_rw06_1_apply_trace_command(state,definition,str(command_value),serial,transactions.size())
                serial+=1
                _check(bool(applied.get("ok",false)),name_value+" authoredcommand "+str(command_value)+": "+str(applied.get("errors",[])))
                transactions.append({"command":command_value,"ok":applied.get("ok",false),"errors":applied.get("errors",[])})
                if not bool(applied.get("ok",false)):
                    ok=false
                    break
                state=_dict(applied.get("state",{}))
            if ok and test_case.has("fact"):
                var applied:=_rw06_1_apply_trace_fact(state,definition,test_case["fact"],serial,transactions.size())
                serial+=1
                _check(bool(applied.get("ok",false)),name_value+" supportedfacttransaction: "+str(applied.get("errors",[])))
                transactions.append({"fact":test_case["fact"],"ok":applied.get("ok",false),"errors":applied.get("errors",[])})
                ok=bool(applied.get("ok",false))
                if ok:
                    state=_dict(applied.get("state",{}))
            if not ok:
                report[name_value]={"case":test_case,"transactions":transactions,"prepared":false}
                continue
            var identity_ok: bool=(str(state.get("status",""))=="aftermath" and _array(state.get("resolved_outcomes",[])).has(test_case.get("outcome",""))) if test_case["kind"]=="aftermath" else (str(state.get("status",""))=="active" and str(state.get("phase_id",""))==test_case["phase"])
            _check(identity_ok,name_value+" exactstatus/phase/outcome identity")
            var candidate := initial_environment.duplicate(true)
            var committed := ScenarioEngineScript._commit_sequence_candidate(candidate, candidate.duplicate(true), definition, {"ok":true,"state":state,"errors":[]})
            _check(bool(committed.get("ok",false)), name_value+" unchanged production engine commit: "+str(committed.get("errors",[])))
            var resolved: Dictionary = run_state.call("_publish_scenario_membership_candidate",candidate,committed,"qa_authored_state") if bool(committed.get("ok",false)) else committed
            _check(bool(resolved.get("ok",false)),name_value+" existingproductionseam resolves sealed snapshot: "+str(resolved.get("errors",[])))
            if not bool(resolved.get("ok",false)):
                report[name_value]={"case":test_case,"transactions":transactions,"prepared":false,"resolve_errors":resolved.get("errors",[])}
                continue
            var live_authority: Dictionary = run_state.call("validate_room_action_authority")
            _check(bool(live_authority.get("ok",false)), name_value+" causal live room authority: "+str(live_authority.get("errors",[])))
            app.call("_set_current_screen","ENVIRONMENT")
            app.call("_clear_selected_game_action")
            app.call("_render_environment_screen")
            # Local viewport input only, before natural waits; no desktop pointer warp.
            var neutral_motion := InputEventMouseMotion.new()
            neutral_motion.position = Vector2(900,100)
            neutral_motion.global_position = neutral_motion.position
            root.push_input(neutral_motion)
            await _settle(8)
            var canvas: Control=app.get("environment_canvas")
            var arrival := await _settle_production_arrivals(canvas)
            _check(int(arrival["remaining_person_transits"]) == 0, name_value+" actual actor arrival completed")
            var snapshot: Dictionary=canvas.get("foundation_snapshot")
            var actual_state: Dictionary=snapshot.get("scenario_sequence_state",{})
            var actual_identity: bool=str(actual_state.get("status",""))==str(state.get("status","")) and _array(actual_state.get("resolved_outcomes",[]))==_array(state.get("resolved_outcomes",[])) and str(actual_state.get("phase_id",""))==str(state.get("phase_id",""))
            _check(actual_identity,name_value+" actualapp retains preparedphase/outcome")
            var authority: Dictionary=snapshot.get("scenario_layout_authority",{})
            var actual_view: Dictionary = canvas.call("current_view_snapshot")
            var actual_objects: Array = actual_view.get("objects",[])
            var actual_geometry: Array = actual_view.get("object_layout",{}).get("objects",[])
            var projected_semantic: Dictionary = resolved.get("projection",{}).get("semantic_state",{})
            var resolved_visuals: Array = resolved.get("renderer_snapshot",{}).get("visual_objects",[])
            _check(not projected_semantic.is_empty(),name_value+" resolved semantic projection is nonempty")
            _check(not resolved_visuals.is_empty(),name_value+" actual resolved renderer visual list is nonempty")
            var material_evidence: Dictionary = {}
            for expected_value in test_case["expected_material_ids"]:
                var identity := "scenario::"+str(expected_value)
                var authority_row: Dictionary = authority.get(identity,{})
                var object_id := str(authority_row.get("presentation_object_id",identity))
                var matches: Array = actual_objects.filter(func(o): return str(o.get("id","")) == object_id)
                var geometry_matches: Array = actual_geometry.filter(func(o): return str(o.get("id","")) == object_id)
                var projected_material: Dictionary = projected_semantic.get("scene_objects",{}).get(identity,{})
                var resolved_material: Array = resolved_visuals.filter(func(v): return str(v.get("object_id","")) == object_id and bool(v.get("visible",true)) and str(v.get("presentation_mode","room")) == "room")
                _check(not projected_material.is_empty() and bool(projected_material.get("present",true)) and resolved_material.size()==1,name_value+" catalog material survives projected publication: "+identity)
                _check(not authority_row.is_empty(), name_value+" expected authority present: "+identity)
                _check(matches.size()==1 and geometry_matches.size()==1, name_value+" expected actual rendered object and geometry: "+identity)
                var label := str(matches[0].get("label","")) if matches.size()==1 else ""
                var label_rect: Dictionary = geometry_matches[0].get("label_rect",{}) if geometry_matches.size()==1 else {}
                _check(not label.is_empty() and float(label_rect.get("w",0))>0 and float(label_rect.get("h",0))>0, name_value+" expected actual label and nonempty rectangle: "+identity)
                material_evidence[identity] = {"authority":authority_row,"object_id":object_id,"actual_objects":matches,"actual_geometry":geometry_matches,"label":label}
            var actor_evidence: Dictionary = {}
            for expected_actor in test_case.get("expected_actor_ids",[]):
                var actor_id := "scenario::"+str(expected_actor)
                var actor_authority: Dictionary = authority.get(actor_id,{})
                var actor_object_id := str(actor_authority.get("presentation_object_id",actor_id))
                var projected_actor: Dictionary = projected_semantic.get("actors",{}).get(actor_id,{})
                var actor_visuals: Array = resolved_visuals.filter(func(v): return str(v.get("object_id","")) == actor_object_id and bool(v.get("visible",true)) and str(v.get("presentation_mode","room")) == "room")
                var actor_matches: Array = actual_objects.filter(func(o): return str(o.get("id","")) == actor_object_id)
                var actor_geometry: Array = actual_geometry.filter(func(o): return str(o.get("id","")) == actor_object_id)
                var actor_published: Array = snapshot.get("interactable_objects",[]).filter(func(o): return str(o.get("object_id","")) == actor_object_id)
                var actor_interaction: Dictionary = projected_semantic.get("interactions",{}).get(actor_object_id,{})
                var actor_source_label := str(actor_visuals[0].get("label","")) if actor_visuals.size()==1 else ""
                var actor_has_interaction := not actor_interaction.is_empty() and bool(actor_interaction.get("present",true))
                var actor_expected_label := str(actor_interaction.get("label",actor_source_label)) if actor_has_interaction else actor_source_label
                var actor_actual_label := str(actor_matches[0].get("label","")) if actor_matches.size()==1 else ""
                var actor_label_rect: Dictionary = actor_geometry[0].get("label_rect",{}) if actor_geometry.size()==1 else {}
                _check(not actor_authority.is_empty() and not projected_actor.is_empty() and bool(projected_actor.get("present",true)) and actor_visuals.size()==1,name_value+" catalog actor survives projected publication: "+actor_id)
                _check(actor_matches.size()==1 and actor_geometry.size()==1,name_value+" expected arrived actor geometry: "+actor_id)
                _check(not actor_expected_label.is_empty() and actor_actual_label==actor_expected_label and actor_published.size()==1 and str(actor_published[0].get("label",""))==actor_expected_label,name_value+" exact post-projection actor label: "+actor_id)
                _check(float(actor_label_rect.get("w",0))>0 and float(actor_label_rect.get("h",0))>0,name_value+" actor nonempty label rectangle: "+actor_id)
                actor_evidence[actor_id] = {"authority":actor_authority,"projected_actor":projected_actor,"resolved_visuals":actor_visuals,"actual_objects":actor_matches,"actual_geometry":actor_geometry,"published_objects":actor_published,"expected_label":actor_expected_label,"actual_label":actor_actual_label,"label_rect":actor_label_rect}
            var exclusion_evidence: Array = []
            for excluded in test_case.get("excluded_materials",[]):
                var excluded_id := "scenario::"+str(excluded.get("id",""))
                var excluded_objects: Array = actual_objects.filter(func(o): return str(o.get("id","")) == excluded_id)
                var excluded_geometry: Array = actual_geometry.filter(func(o): return str(o.get("id","")) == excluded_id)
                _check(excluded_objects.is_empty() and excluded_geometry.is_empty(),name_value+" excluded control has no standalone room geometry: "+excluded_id)
                var excluded_visuals: Array = resolved_visuals.filter(func(v): return str(v.get("object_id","")) == excluded_id and bool(v.get("visible",true)) and str(v.get("presentation_mode","room")) == "room")
                _check(excluded_visuals.is_empty(),name_value+" excluded hosted control absent from resolved room publication: "+excluded_id)
                exclusion_evidence.append({"resolved_room_visuals":excluded_visuals,"source":excluded,"actual_objects":excluded_objects,"actual_geometry":excluded_geometry})
            var source_visual_evidence: Array = []
            for visual_value in resolved_visuals:
                var visual: Dictionary = visual_value
                var object_id := str(visual.get("object_id",""))
                var matches: Array = actual_objects.filter(func(o): return str(o.get("id","")) == object_id)
                var geometry_matches: Array = actual_geometry.filter(func(o): return str(o.get("id","")) == object_id)
                var visible: bool = bool(visual.get("visible",true)) and str(visual.get("presentation_mode","room")) == "room"
                var source_label := str(visual.get("label",""))
                var semantic: Dictionary = projected_semantic
                var interaction: Dictionary = semantic.get("interactions",{}).get(object_id,{})
                var present_interaction: bool = not interaction.is_empty() and bool(interaction.get("present",true))
                var expected_label := str(interaction.get("label",source_label)) if present_interaction else source_label
                var published: Array = snapshot.get("interactable_objects",[]).filter(func(o): return str(o.get("object_id","")) == object_id)

                var actual_label := str(matches[0].get("label","")) if matches.size()==1 else ""
                var label_rect: Dictionary = geometry_matches[0].get("label_rect",{}) if geometry_matches.size()==1 else {}
                if visible:
                    _check(matches.size()==1 and geometry_matches.size()==1, name_value+" every source-visible visual reaches actual canvas geometry: "+object_id)
                    _check(published.size()==1 and str(published[0].get("label",""))==expected_label, name_value+" exact source-composed label published: "+object_id)
                    _check(not expected_label.is_empty() and actual_label==expected_label and float(label_rect.get("w",0))>0 and float(label_rect.get("h",0))>0, name_value+" exact production label reaches actual canvas: "+object_id)
                else:
                    _check(matches.is_empty() and geometry_matches.is_empty(),name_value+" hidden/non-room visual excluded from actual geometry: "+object_id)
                source_visual_evidence.append({"id":object_id,"source_visual":visual,"room_visible":visible,"source_label":source_label,"expected_final_label":expected_label,"interaction_label":interaction.get("label"),"present_interaction":present_interaction,"published_objects":published,"actual_label":actual_label,"actual_objects":matches,"actual_geometry":geometry_matches,"exclusion":"" if visible else "Source explicitly hidden or non-room presentation; no in-room label claim."})
            await RenderingServer.frame_post_draw
            root.get_texture().get_image().save_png(out_dir.path_join(name_value+"_play.png"))
            var pair:=await _compare_pair(original,snapshot,name_value)
            var reduced:=snapshot.duplicate(true)
            reduced["reduce_motion"]=true
            var still_pair:=await _compare_pair(original,reduced,name_value+"_reduced")
            report[name_value]={"case":test_case,"transactions":transactions,"prepared":true,"actual_arrival_wait":arrival,"snapshot":snapshot,"comparison":pair,"reduce_motion_comparison":still_pair,"state_status":actual_state.get("status"),"resolved_outcomes":actual_state.get("resolved_outcomes",[]),"phase":actual_state.get("phase_id"),"authority_keys":authority.keys(),"live_authority":live_authority,"material_evidence":material_evidence,"actual_view":actual_view,"source_visual_evidence":source_visual_evidence,"actor_evidence":actor_evidence,"exclusion_evidence":exclusion_evidence,"projected_semantic_state":projected_semantic}
            var selected_evidence: Array = []
            for actual_object in actual_objects:
                var selected_id := str(actual_object.get("id",""))
                canvas.call("set_selected_object",selected_id)
                await _settle(2)
                await RenderingServer.frame_post_draw
                var selected_view: Dictionary = canvas.call("current_view_snapshot")
                var info: Dictionary = selected_view.get("selected_info",{})
                var info_rect: Dictionary = info.get("rect",{})
                var selected_matches: Array = selected_view.get("objects",[]).filter(func(o): return str(o.get("id",""))==selected_id)
                var selected_geometry: Array = selected_view.get("object_layout",{}).get("objects",[]).filter(func(o): return str(o.get("id",""))==selected_id)
                var expected_selected_label := str(actual_object.get("label","")).strip_edges()
                _check(str(selected_view.get("selected_object_id",""))==selected_id and bool(info.get("visible",false)) and str(info.get("object_id",""))==selected_id,name_value+" actual selected object/card identity: "+selected_id)
                _check(not expected_selected_label.is_empty() and str(info.get("title",""))==expected_selected_label,name_value+" actual selected title retains source label: "+selected_id)
                _check(selected_matches.size()==1 and selected_geometry.size()==1 and float(info_rect.get("w",0))>0 and float(info_rect.get("h",0))>0,name_value+" selected geometry and card rectangle nonempty: "+selected_id)
                selected_evidence.append({"id":selected_id,"expected_title":expected_selected_label,"actual_selected_info":info,"actual_geometry":selected_geometry})
                if selected_evidence.size()==1:
                    root.get_texture().get_image().save_png(out_dir.path_join(name_value+"_selected_play.png"))
            canvas.call("set_selected_object","")
            await _settle(2)
            report[name_value]["selected_label_evidence"] = selected_evidence
            report[name_value]["case_findings"] = findings.slice(case_findings_start)
            report[name_value]["case_passed"] = findings.size() == case_findings_start
            var case_receipt := FileAccess.open(out_dir.path_join(name_value+"_receipt.json"),FileAccess.WRITE)
            if case_receipt == null:
                _check(false,name_value+" per-case receipt could not be written")
            else:
                case_receipt.store_string(JSON.stringify({"batch_scope":batch_scope,"case_id":name_value,"view":report[name_value]},"\t"))
                case_receipt.close()
            completed.append(name_value)
            print("MOTEL_SEQUENCE_CAPTURED ",name_value)
    _check(completed.size()==cases.size(),"All declared contexts captured")
    var file:=FileAccess.open(out_dir.path_join("motel_sequence_live_proof.json"),FileAccess.WRITE)
    if file == null:
        push_error("Unable to create Motel proof report in admitted evidence directory")
        quit(1)
        return
    file.store_string(JSON.stringify({"checks":checks,"findings":findings,"case_catalog":catalog,"batch_scope":batch_scope,"completed":completed,"views":report,"scope":"QA-owned valid Runtime command/fact transactions followed by unchanged production ScenarioEngine commit and RunState physical-membership publication; actual canvas object/label/geometry assertions. Not UI-click end-to-end/revisit/save coverage."},"\t"))
    file.close()
    print("ENVART_MOTEL_SEQUENCE_PROOF ",JSON.stringify({"checks":checks,"findings":findings,"completed":completed.size(),"expected":cases.size()}))
    app.queue_free()
    await process_frame
    quit(0 if findings.is_empty() else 1)
