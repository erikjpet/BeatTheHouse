import os,sys,json,hashlib,shutil,collections,tarfile
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-INTEGRATION-20261114');R=Path(r'E:/CodexQA/BTH/runs');O=Path(os.environ['BTH_QA_EVIDENCE_DIR']);assert str(O).lower().startswith('e:') and O.is_dir()
prefix='BTH-ENVART-MOTELTRIAL-20261114-'
def ep(n,f):return R/(prefix+n)/'evidence'/f
def read(n,f):return json.loads(ep(n,f).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
stage=read('r3-stage-01','stage.json');assert stage['package_sha256']=='4b22c9cfda8ad88f0d989b544c50cc84efd4fc290583a3e87464f9963821b971'
protected={**stage['accepted_prior_payloads_preserved'],**stage['c5_production_inputs_preserved']}
for p,h in protected.items():assert sha(W/p)==h,p
for p,v in stage['files'].items():assert sha(W/p)==v['sha256'],p
baseline_root=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-MOTEL-C5-20261114')
archive_tar=Path(r'E:/CodexQA/BTH/runs/BTH-ENVART-MOTEL-20261114-c5-archive-01/evidence/c5.tar')
assert sha(archive_tar)=='846e3129fb5aa4751b60d47312cb0bdf3189a8ad846b4db514d5964509586dd3'
baseline_verified={}
with tarfile.open(archive_tar) as tf:
 for member in tf:
  name=member.name
  if not member.isfile() or not (name.startswith(('scripts/','data/','scenes/')) or name in ('project.godot','export_presets.cfg')):continue
  h=hashlib.sha256(tf.extractfile(member).read()).hexdigest();assert sha(baseline_root/name)==h,name;baseline_verified[name]=h
assert len(baseline_verified)==914,len(baseline_verified)
(O/'strict-c5-baseline-inputs.json').write_text(json.dumps(baseline_verified,indent=2))
cases={};reports={};report_paths=[];selected_count=0;checks=0
sequence_names=['r3-sequence-smoke-01','r3-sequence-conventioneers-01','r3-sequence-stakeout-01','r3-sequence-weekly-01','r3-sequence-wedding-01']
for n in sequence_names:
 d=read(n,'motel_sequence_live_proof.json');assert not d['findings'];checks+=d['checks'];assert len(d['completed'])==len(d['views'])
 for k,v in d['views'].items():
  assert k not in cases,k;assert v['case_passed'] and not v['case_findings'];assert v['actual_arrival_wait']['remaining_person_transits']==0
  assert v['comparison']['layout_equal'] and v['reduce_motion_comparison']['layout_equal'] and v['reduce_motion_comparison']['reduce_motion_stable']
  selected_count+=len(v['selected_label_evidence']);cases[k]={'scenario':v['case']['scenario_id'],'kind':v['case']['kind'],'phase':v['phase'],'outcomes':v['resolved_outcomes'],'actual_objects':len(v['actual_view']['objects']),'selected_labels':len(v['selected_label_evidence']),'source_visible_objects':len([x for x in v['source_visual_evidence'] if x['room_visible']]),'material_ids':list(v['material_evidence']),'actor_ids':list(v['actor_evidence']),'case_passed':True,'primary_png':str(ep(n,k+'_play.png')),'receipt':str(ep(n,k+'_receipt.json'))}
 report_paths.append(ep(n,'motel_sequence_live_proof.json'))
catalog=json.loads((W/'tools/envart_motel_sequence_cases.json').read_text());expected={c['scenario_id']+'__'+c['kind']+'_'+c.get('outcome',c.get('phase','')) for c in catalog['cases']};assert set(cases)==expected and len(cases)==40
settled=read('r3-settled-01','motel_r3_settled_metadata.json');assert not settled['findings'] and settled['checks']==500 and len(settled['views'])==5
composite=read('r3-composite-01','motel_full_composite.json');assert composite['checks']==171 and composite['findings']==['motel_wedding_overflow/glass_glint_1 real full-composite pixels change']
rm=read('r3-composite-rm-01','motel_full_composite_rm.json');assert rm['checks']==63 and not rm['findings'] and len(rm['scenarios'][0]['entries'])==14
occlusion=read('r3-wedding-occlusion-01','wedding_glint_occlusion.json');assert occlusion['ok'] and occlusion['underlying_original_entry_changed_pixels']==occlusion['all_underlying_changed_pixels_covered_by_actual_opaque_clerk']==occlusion['actual_final_composite_rgb_matches_clerk_mask_pixels']==28
counter=read('r3-counter-replay-01','motel_counter_replay.json');assert counter['ok'] and len(counter['cases'])==2
floor=read('r3-floor-wrap-01','floor_wrap_probe.json');assert not floor['failures'] and len(floor['glints'])==7
assert 'Animation liveness without pointer input: PASS' in ep('r3-liveness-01','worker.log').read_text()
run_names=['r3-import-01','r3-base-preview-01','r3-settled-01','r3-composite-01','r3-composite-pixels-01','r3-composite-rm-01','r3-wedding-occlusion-01']+sequence_names+['r3-counter-replay-01','r3-floor-wrap-01','r3-liveness-01']
jobs=[];pngs={}
for n in run_names:
 d=read(n,'job.json');assert d['exit_code']==(1 if n=='r3-composite-01' else 0);assert d['active_at_release']==0 and d['assigned_before_execution'] and not d['error'] and not d['cleanup_errors'] and not d['timed_out'];assert d['limits']['cpu_rate']==1200 and d['limits']['job_memory_limit_bytes']==2147483648
 jobs.append({'run':n,'receipt':str(ep(n,'job.json')),'sha256':sha(ep(n,'job.json')),'exit_code':d['exit_code'],'active_at_release':0,'assigned_before_execution':True,'cpu_percent':12,'job_memory_bytes':2147483648})
 for p in ep(n,'').rglob('*.png'):pngs[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
for n,f in [('r3-settled-01','motel_r3_settled_metadata.json'),('r3-base-preview-01','frames/animation_capture.json'),('r3-composite-01','motel_full_composite.json'),('r3-composite-pixels-01','motel_composite_pixels.json'),('r3-composite-rm-01','motel_full_composite_rm.json'),('r3-wedding-occlusion-01','wedding_glint_occlusion.json'),('occlusion-source-bind-01','source_binding.json'),('r3-counter-replay-01','motel_counter_replay.json'),('r3-floor-wrap-01','floor_wrap_probe.json'),('r3-early-summary-01','motel-r3-early-trial-summary.json'),('r2-settled-comparison-01','comparison.json')]:report_paths.append(ep(n,f))
reports={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in report_paths}
archive=O/'qa-source-archive';archive.mkdir(exist_ok=True);inputs={}
paths=[W/'motel_trial_adapter.py',W/'tools/environment_art_baseline_capture.gd',W/'tools/environment_layout_screenshots.gd',W/'tools/envart_back_settled_r3.gd',W/'scripts/tests/animation_liveness_without_pointer_check.gd']+list((W/'tools').glob('envart_motel*'))
for p in paths:
 if not p.is_file():continue
 rel=p.relative_to(W);dest=archive/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);inputs[rel.as_posix()]={'sha256':sha(dest),'bytes':dest.stat().st_size}
source=Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers/tools')
for name in ['bth_qa_storage.py','bth_qa_guarded_run.py']:
 p=source/name;dest=archive/'guarded_tools'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);inputs['guarded_tools/'+name]={'sha256':sha(dest),'bytes':dest.stat().st_size}
base=Path(r'E:/CodexQA/BTH/runs/BTH-ENVART-CORNER-20261114-r6-repro-archive-02/evidence/qa-source-archive/baseline/pixel_scene_canvas.e5152c34.gd');assert sha(base)=='78058e0092552e4aef4d6339041f9d1768af3c14f837ec4eed65e832ae88ee0d';dest=archive/'baseline'/base.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base,dest);inputs['baseline/'+base.name]={'sha256':sha(dest),'bytes':dest.stat().st_size}
(O/'qa-source-archive-manifest.json').write_text(json.dumps(inputs,indent=2));(O/'native-png-manifest.json').write_text(json.dumps(pngs,indent=2));(O/'protected-inputs.json').write_text(json.dumps(protected,indent=2))
summary={'status':'NATIVE_QA_COMPLETE_AWAITING_FINAL_ART_AUDITOR_PASS','package_sha256':stage['package_sha256'],'package_payloads':stage['files'],'source_commit':'c5d5d17f691a010ac3173ac2a8c42232777081e5','placement_sha256':'c5c9808497ee3d4f056bb5a7f24a64524d4e59ee50e3fff106eb41e09383245f','strict_c5_baseline_preserved':True,'strict_c5_baseline_production_files_reverified':len(baseline_verified),'protected_c5_core_inputs':len(stage['c5_production_inputs_preserved']),'protected_prior_room_payloads':len(stage['accepted_prior_payloads_preserved']),'preexisting_eol_only_encoding':stage['preexisting_eol_only_encoding'],'settled_checks':500,'settled_contexts':5,'source_case_checks':checks,'source_case_count':40,'distinct_Base_plus_authored_contexts':41,'actual_selected_titles_asserted':selected_count,'cases':cases,'all14_full_composite_base_visible':True,'CRT_both_motifs_visible_in_all5_current_contexts':True,'CRT_pixels_report':str(ep('r3-composite-pixels-01','motel_composite_pixels.json')),'full_composite_RM_checks':63,'all14_full_composite_RM_stable':True,'counter_replay':counter,'floor_wrap_checks':floor['checks'],'mandatory_no_pointer_liveness':'PASS','preserved_diagnostics':[{'run':'r2-settled-01','exit_code':1,'finding':'Five in-memory Vector2 vs JSON representation equality failures. Independent exact persisted comparison clean, corrected R3 native500checks0findings.'},{'run':'r3-composite-01','exit_code':1,'checks':171,'findings':composite['findings'],'resolution':'Wedding-only glass_glint_1 correctly hidden behind actual later-layer Clerk. Exact28/28 original changed pixels under alpha1 actor paint and matching final RGB. No claim Wedding visibility; original receipt unchanged.'}],'jobs':jobs,'native_png_count':len(pngs),'native_png_manifest':str(O/'native-png-manifest.json'),'source_archive':str(archive),'source_archive_manifest_sha256':sha(O/'qa-source-archive-manifest.json'),'reports':reports,'limits':['No UI-click/save/revisit/travel E2E claim. Authored Runtime transactions use unchanged ScenarioEngine commit and real RunState physical-membership publication.','1800/900 diagnostic replays complement actual full-app PNGs; no clone substituted for the actual scene.','Fixed-clock composite proof is independent of normal11.583379-second88-frame production excerpt. No alpha/brightness/timing boost.','Luminance is visible in real Drink sprite gaps, not outside conservative model box. Vending/title/outsideglass remain unchanged.','No target repository, activation index or site/deployment edits. Final exact art PASS belongs to auditor; Web release is separate.']}
(O/'motel-r3-native-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'status':summary['status'],'package':summary['package_sha256'],'sequence_checks':checks,'cases':len(cases),'selected_titles':selected_count,'jobs':len(jobs),'pngs':len(pngs),'summary':str(O/'motel-r3-native-summary.json'),'summary_sha256':sha(O/'motel-r3-native-summary.json')}))
