import os,sys,json,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
sys.dont_write_bytecode=True
src=Path(sys.argv[1]);out=Path(os.environ['BTH_QA_EVIDENCE_DIR'])
assert str(out).lower().startswith('e:') and out.is_dir()
d=json.loads((src/'motel_full_composite.json').read_text())
u=json.loads(Path(r'E:/CodexQA/BTH/runs/BTH-ENVART-MOTEL-20261114-c5-preart-union-02/evidence/motel_preart_union.json').read_text())
y,x=np.mgrid[0:860,0:1800];bx=(x+.5)/2;by=(y+.5)/2
def rect(r):
 if isinstance(r,dict):r=[r[k] for k in ['x','y','w','h']]
 a,b,c,e=r;return (bx>=a)&(bx<a+c)&(by>=b)&(by<b+e)
def count(delta,mask):
 changed=np.any(delta[:,:,:3]!=0,axis=2)&mask
 points=np.argwhere(changed)
 z=np.max(delta[:,:,:3],axis=2)
 return {'region_pixels':int(mask.sum()),'changed_pixels':int(changed.sum()),'max_channel_delta_8bit':int(z[mask].max()) if mask.any() else 0,'mean_channel_delta_on_changed':float(delta[:,:,:3][changed].mean()) if changed.any() else 0.,'bbox_native_xyxy': [int(points[:,1].min()),int(points[:,0].min()),int(points[:,1].max()+1),int(points[:,0].max()+1)] if len(points) else None}
rows=[]
for context in d['scenarios']:
 scenario=context['scenario'];geometry=context['actual_view']['object_layout']['objects'];drink=next(v for v in geometry if v['id']=='service:house_drink')
 title=rect(drink['label_rect']);body=rect(drink['rect']);vending=rect(u['regions']['vending_static_body']);glass=rect(u['regions']['crt_glass'])
 opaque=np.zeros_like(glass)
 for part in u['contexts'][scenario]['drink_source_opaque_body_rects']:opaque|=rect(part['rect'])
 translucent=np.zeros_like(glass)
 for part in u['contexts'][scenario]['drink_source_translucent_body_rects']:translucent|=rect(part['rect'])
 for entry in context['entries']:
  a=np.asarray(Image.open(src/entry['a']).convert('RGBA')).astype('int16');b=np.asarray(Image.open(src/entry['b']).convert('RGBA')).astype('int16');delta=np.abs(a-b)
  row={'scenario':scenario,'entry':entry['id'],'a_sha256':hashlib.sha256((src/entry['a']).read_bytes()).hexdigest(),'b_sha256':hashlib.sha256((src/entry['b']).read_bytes()).hexdigest(),'full_canvas':count(delta,np.ones_like(glass)),'fixed_control_identical':entry['identical_control_pixels'],'same_objects_layout':entry['actual_objects_layout_equal'],'same_object_route_label_clocks':entry['object_route_label_clocks_equal']}
  if entry['id'].startswith('crt_'):
   row.update({'glass_outside_conservative_title_model_vending':count(delta,glass&~title&~body&~vending),'glass_outside_source_body_title_vending':count(delta,glass&~title&~opaque&~translucent&~vending),'visible_glass_including_drink_gaps':count(delta,glass&~title&~vending),'static_vending_change':count(delta,vending),'gold_title_change':count(delta,title),'outside_glass_change':count(delta,~glass),'conservative_body_rect':drink['rect'],'actual_title_rect':drink['label_rect'],'vending_rect':u['regions']['vending_static_body']})
  rows.append(row)
report={'scope':'Exact full-composite fixed-clock pairs; unchanged inherited production draw and original art alpha. Raw native RGB difference quantified, no recolor/boost. Conservative model box is not a solid real sprite; source-shaped opaque+translucent body masks reported separately. Meaningful visibility still requires visual review; nonzero alone is not full acceptance.','native_report':str(src/'motel_full_composite.json'),'native_checks':d['checks'],'native_findings':d['findings'],'pairs':rows}
(out/'motel_composite_pixels.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'pairs':len(rows),'native_findings':d['findings'],'crt':[{'scenario':r['scenario'],'entry':r['entry'],'conservative':r['glass_outside_conservative_title_model_vending'],'source_shaped':r['glass_outside_source_body_title_vending'],'vending':r['static_vending_change']['changed_pixels'],'title':r['gold_title_change']['changed_pixels']} for r in rows if r['entry'].startswith('crt_')]},indent=2))
