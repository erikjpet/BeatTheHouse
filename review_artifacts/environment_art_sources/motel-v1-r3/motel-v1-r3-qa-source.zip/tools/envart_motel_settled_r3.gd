extends SceneTree
const MainScene := preload("res://scenes/main.tscn")
const CanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
const ScenarioEngineScript := preload("res://scripts/core/scenario_engine.gd")
const SEED_TEXT := "LAYOUT-SURVEY-QA"
var app: Node
var out_dir := ""
var checks := 0
var findings: Array[String] = []
var views: Dictionary = {}
var baseline: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("E:/CodexQA/BTH/runs/BTH-ENVART-MOTEL-20261114-c5-preart-capture-02/evidence/motel_preart_metadata.json"))

func _init() -> void:
    out_dir = OS.get_environment("BTH_QA_EVIDENCE_DIR")
    call_deferred("_run")

func _check(value: bool, message: String) -> void:
    checks += 1
    if not value:
        findings.append(message)
        push_error(message)

func _settle(frames: int = 8) -> void:
    for i in range(frames):
        await process_frame

func _arrivals(canvas: Control) -> Dictionary:
    var before: float = canvas.get("flicker")
    var waited := 4.0
    await create_timer(waited).timeout
    while not (canvas.get("person_transits") as Dictionary).is_empty() and waited < 12.0:
        await create_timer(0.25).timeout
        waited += 0.25
    await RenderingServer.frame_post_draw
    return {"clock_before":before,"clock_after":canvas.get("flicker"),"timer_wait_seconds":waited,"remaining_person_transits":(canvas.get("person_transits") as Dictionary).size(),"input_during_wait":false,"positions_modified":false}

func _run() -> void:
    if not out_dir.begins_with("E:") and not out_dir.begins_with("E:/"):
        push_error("Explicit admitted E evidence required")
        quit(1)
        return
    root.size = Vector2i(1280,720)
    app = MainScene.instantiate()
    app.set("script_prewarm_stopping",true)
    root.add_child(app)
    await _settle()
    var neutral := InputEventMouseMotion.new()
    neutral.position = Vector2(900,100)
    neutral.global_position = neutral.position
    root.push_input(neutral,true)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id",app.get("environment_test_archetype_option"),"motel")
    app.call("_refresh_environment_test_identity_options")
    var catalog: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/environments/scenarios.json"))
    var selections: Array[String] = ["__none"]
    for row in catalog["motel"]:
        selections.append(str(row["id"]))
    selections = ["__none","motel_wedding_overflow","motel_weekly_rates","motel_conventioneers","motel_stakeout"]
    _check(selections.size()==catalog["motel"].size()+1,"All actual catalog scenarios retained in priority order")
    for scenario in selections:
        app.call("_environment_test_select_id",app.get("environment_test_scenario_option"),scenario)
        app.get("environment_test_seed_input").text = SEED_TEXT
        var generated: Dictionary = app.call("start_environment_test_session")
        _check(bool(generated.get("ok",false)),scenario+" production practice generation")
        if not bool(generated.get("ok",false)):
            continue
        await _settle()
        var run_state: Variant = app.get("run_state")
        var resolved: Dictionary = {}
        var initial_state: Dictionary = run_state.current_environment.get("scenario_sequence_state",{}).duplicate(true)
        if scenario != "__none":
            var candidate: Dictionary = run_state.current_environment.duplicate(true)
            var definition: Dictionary = candidate.get("scenario_sequence_definition",{})
            var committed: Dictionary = ScenarioEngineScript._commit_sequence_candidate(candidate,candidate.duplicate(true),definition,{"ok":true,"state":initial_state,"errors":[]})
            _check(bool(committed.get("ok",false)),scenario+" unchanged Engine same-state commit")
            resolved = run_state.call("_publish_scenario_membership_candidate",candidate,committed,"qa_initial_same_state") if bool(committed.get("ok",false)) else committed
            _check(bool(resolved.get("ok",false)),scenario+" actual physical-membership publication")
            _check(not (resolved.get("renderer_snapshot",{}).get("visual_objects",[]) as Array).is_empty(),scenario+" nonempty Runtime renderer source")
            app.call("_set_current_screen","ENVIRONMENT")
            app.call("_clear_selected_game_action")
            app.call("_render_environment_screen")
            await _settle()
        var canvas: Control = app.get("environment_canvas")
        var arrival := await _arrivals(canvas)
        _check(int(arrival["remaining_person_transits"])==0,scenario+" natural arrivals completed")
        var authority: Dictionary = run_state.call("validate_room_action_authority")
        _check(bool(authority.get("ok",false)),scenario+" live production room authority")
        var snapshot: Dictionary = canvas.get("foundation_snapshot").duplicate(true)
        _check(str(snapshot.get("scenario_id",""))==("" if scenario=="__none" else scenario),scenario+" exact scenario identity")
        _check(canvas.get("environment_art_pack")!=null,scenario+" exact sealed Motel R3 pack active")
        var view: Dictionary = canvas.call("current_view_snapshot")
        var old: Dictionary = baseline["views"][scenario]["actual_view"]
        _check(JSON.parse_string(JSON.stringify(view["object_layout"]))==old["object_layout"],scenario+" exact actual geometry/label rectangles equal strict c5")
        for row in view["objects"]:
            var matches: Array = old["objects"].filter(func(o): return str(o.get("id",""))==str(row.get("id","")))
            _check(matches.size()==1 and str(matches[0].get("label",""))==str(row.get("label","")),scenario+" exact c5 label "+str(row.get("id","")))
        _check(bool(view.get("object_labels_and_borders_enabled",false)),scenario+" labels enabled")
        var objects: Array = view.get("objects",[])
        var geometry: Array = view.get("object_layout",{}).get("objects",[])
        var published: Array = snapshot.get("interactable_objects",[])
        var render_snapshot: Dictionary = resolved.get("renderer_snapshot",{})
        var semantic: Dictionary = resolved.get("projection",{}).get("semantic_state",{})
        if scenario != "__none":
            _check(str(snapshot.get("scenario_sequence_state",{}).get("phase_id",""))==str(initial_state.get("phase_id","")) and str(snapshot.get("scenario_sequence_state",{}).get("status",""))==str(initial_state.get("status","")),scenario+" initial phase/status unchanged")
        var pub_evidence: Array = []
        for row_value in published:
            var row: Dictionary = row_value
            var id := str(row.get("object_id",""))
            var room_visible: bool = bool(row.get("visible",true)) and str(row.get("presentation_mode","room"))=="room"
            var actual: Array = objects.filter(func(o): return str(o.get("id",""))==id)
            var actual_geometry: Array = geometry.filter(func(o): return str(o.get("id",""))==id)
            var label := str(row.get("label",""))
            var label_rect: Dictionary = actual_geometry[0].get("label_rect",{}) if actual_geometry.size()==1 else {}
            if room_visible:
                _check(actual.size()==1 and actual_geometry.size()==1,scenario+" published room object reaches actual canvas: "+id)
                _check(actual.size()==1 and str(actual[0].get("label",""))==label,scenario+" exact published label on canvas: "+id)
                _check(not label.is_empty() and float(label_rect.get("w",0))>0 and float(label_rect.get("h",0))>0,scenario+" actual nonempty label rectangle: "+id)
            var object_type := str(actual[0].get("type","")) if actual.size()==1 else ""
            var color: Color = canvas.call("_color_for_object_type",object_type)
            pub_evidence.append({"id":id,"room_visible":room_visible,"published_record":row,"label":label,"actual_objects":actual,"actual_geometry":actual_geometry,"type_color_rgba":[color.r,color.g,color.b,color.a],"disabled":bool(actual[0].get("disabled",false)) if actual.size()==1 else false,"exclusion":"" if room_visible else "Published record explicitly hidden or non-room; no in-room label claim."})
        var source_evidence: Array = []
        for value in render_snapshot.get("visual_objects",[]):
            var visual: Dictionary = value
            var id := str(visual.get("object_id",""))
            var room_visible: bool = bool(visual.get("visible",true)) and str(visual.get("presentation_mode","room"))=="room"
            var interaction: Dictionary = semantic.get("interactions",{}).get(id,{})
            var present: bool = not interaction.is_empty() and bool(interaction.get("present",true))
            var source_label := str(visual.get("label",""))
            var expected := str(interaction.get("label",source_label)) if present else source_label
            var actual: Array = objects.filter(func(o): return str(o.get("id",""))==id)
            var actual_geometry: Array = geometry.filter(func(o): return str(o.get("id",""))==id)
            var pub: Array = published.filter(func(o): return str(o.get("object_id",""))==id)
            if room_visible:
                _check(actual.size()==1 and actual_geometry.size()==1 and pub.size()==1,scenario+" every Runtime room visual published and rendered: "+id)
                _check(pub.size()==1 and str(pub[0].get("label",""))==expected and actual.size()==1 and str(actual[0].get("label",""))==expected,scenario+" source-composed interaction label precedence: "+id)
            source_evidence.append({"id":id,"room_visible":room_visible,"source_visual":visual,"source_label":source_label,"interaction":interaction,"present_interaction":present,"expected_final_label":expected,"published_objects":pub,"actual_objects":actual,"actual_geometry":actual_geometry,"exclusion":"" if room_visible else "Runtime visual explicitly hidden or non-room; no in-room label claim."})
        var exclusions: Array = []
        for collection in ["actors","scene_objects","interactions"]:
            var rows: Dictionary = semantic.get(collection,{})
            for identity in rows:
                var row: Dictionary = rows[identity]
                if not bool(row.get("present",true)) or str(row.get("presentation_mode","room"))!="room":
                    exclusions.append({"collection":collection,"identity":identity,"record":row,"reason":"Semantic record explicitly absent or non-room. No visual assertion."})
        await RenderingServer.frame_post_draw
        root.get_texture().get_image().save_png(out_dir.path_join(scenario+"_actual_play.png"))
        var replay := await _board_replay(snapshot,scenario)
        views[scenario] = {"generated":generated,"arrival":arrival,"snapshot":snapshot,"actual_view":view,"published_evidence":pub_evidence,"runtime_visual_evidence":source_evidence,"semantic_exclusions":exclusions,"board_replay":replay}
        var reduced := snapshot.duplicate(true)
        reduced["reduce_motion"] = true
        views[scenario]["reduced_board_replay"] = await _board_replay(reduced,scenario+"_reduced")
        views[scenario]["live_authority"] = authority
        views[scenario]["same_state_publication"] = resolved
        views[scenario]["initial_runtime_state"] = initial_state
        var partial := FileAccess.open(out_dir.path_join(scenario+"_metadata.json"),FileAccess.WRITE)
        partial.store_string(JSON.stringify(views[scenario],"\t"))
        partial.close()
        print("MOTEL_PREART_CAPTURED ",scenario)
    _check(views.size()==selections.size(),"All actual catalog scenarios and Base captured")
    var live_canvas: Control = app.get("environment_canvas")
    live_canvas.call("set_developer_slot_placement_mode",true)
    var before: Dictionary = live_canvas.call("current_view_snapshot")
    await RenderingServer.frame_post_draw
    var image_a := root.get_texture().get_image()
    await create_timer(0.6).timeout
    await RenderingServer.frame_post_draw
    var image_b := root.get_texture().get_image()
    var after: Dictionary = live_canvas.call("current_view_snapshot")
    _check(float(after["scene_animation_time"])>float(before["scene_animation_time"]) and int(after["scene_idle_animation_redraw_count"])>int(before["scene_idle_animation_redraw_count"]),"Motel no-input clock/redraw advance with placement overlay")
    _check(image_a.get_data()!=image_b.get_data(),"Motel placement no-input actual pixels change")
    image_a.save_png(out_dir.path_join("placement_no_input_a.png"))
    image_b.save_png(out_dir.path_join("placement_no_input_b.png"))
    var report := {"commit":"c5d5d17f691a010ac3173ac2a8c42232777081e5","checks":checks,"findings":findings,"scenarios":selections,"catalog_motel":catalog["motel"],"views":views,"scope":"Unchanged c5 production code, data and placement; exact sealed Motel R3 cumulative art index. Actual Base and each current initial settled scenario. Production practice menu generation, unchanged Engine same-initial-state commit, RunState physical-membership publication and native arrivals. No work/outcome transitions. Observational helpers only. Exact R3 native settled proof only; work/outcomes are separate. No final art PASS.","label_precedence_source":"environment_interaction_controller.gd _compose_projected_records merges visuals, then present interactions; _merge_projected_interaction sets label from semantic interaction. Actual published record and canvas label asserted.","label_color_source":"pixel_scene_canvas.gd _draw_object_label: type color, normal alpha0.72, active0.94, disabled C_SOFT alpha0.56."}
    var file := FileAccess.open(out_dir.path_join("motel_r3_settled_metadata.json"),FileAccess.WRITE)
    file.store_string(JSON.stringify(report,"\t"))
    file.close()
    print("MOTEL_R3_SETTLED_RESULT ",JSON.stringify({"checks":checks,"findings":findings,"contexts":views.size()}))
    app.queue_free()
    await process_frame
    quit(0 if findings.is_empty() else 1)

func _board_replay(snapshot: Dictionary,name_value: String) -> Dictionary:
    var viewport := SubViewport.new()
    viewport.size = Vector2i(1800,860)
    viewport.disable_3d = true
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    root.add_child(viewport)
    var canvas: Control = CanvasScript.new()
    canvas.size = Vector2(1800,860)
    viewport.add_child(canvas)
    canvas.call("render_environment_snapshot",snapshot)
    await _settle()
    var arrival := await _arrivals(canvas)
    await RenderingServer.frame_post_draw
    viewport.get_texture().get_image().save_png(out_dir.path_join(name_value+"_production_board_1800x860.png"))
    var view: Dictionary = canvas.call("current_view_snapshot")
    var stable := true
    if bool(snapshot.get("reduce_motion",false)):
        var image_a := viewport.get_texture().get_image()
        await create_timer(0.4).timeout
        await RenderingServer.frame_post_draw
        stable = image_a.get_data()==viewport.get_texture().get_image().get_data()
        _check(stable,name_value+" actual full canvas Reduce Motion pixels stable")
    viewport.free()
    return {"scope":"Unchanged production canvas, actual captured snapshot, natural settled arrival, 2x board replay. Full app pixels captured separately.","arrival":arrival,"view":view,"reduce_motion_stable":stable}
