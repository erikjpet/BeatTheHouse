"""Local ENVART evidence adapter; every actual worker uses maintained gates/Job."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
SOURCE = Path(r"D:\Projects\Beat-The-House\.tmp\environment-art-layers")
sys.path.insert(0, str(SOURCE / "tools"))
import argparse, hashlib, json, os, shutil
from bth_qa_storage import plan_layout, prepare_layout, validate_layout
from bth_qa_guarded_run import execute

parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("--timeout", type=int, default=240)
parser.add_argument("--sync", action="store_true")
parser.add_argument("--sync-file", action="append", default=[])
parser.add_argument("--compose", action="store_true")
parser.add_argument("--cold-import", action="store_true")
parser.add_argument("--web-template", action="store_true")
parser.add_argument("--web-addon", action="store_true")
parser.add_argument("--env", action="append", default=[])
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
assert not args.sync, "Full source sync is forbidden after candidate staging."
layout = plan_layout(root=r"E:\CodexQA\BTH", workspace=r"E:\CodexQA\BTH\workspaces\BTH-ENVART-INTEGRATION-20261114", run_id="BTH-ENVART-MOTELTRIAL-20261114-" + args.name)
layout = prepare_layout(layout)
validate_layout(layout)
shutil.copyfile(__file__, layout.evidence / "adapter.py")
for relative in args.sync_file:
    src = SOURCE / relative
    target = layout.workspace / relative
    validate_layout(layout, extra_write_paths=(target.parent,))
    assert src.resolve().is_relative_to(SOURCE.resolve())
    if target.is_symlink() or (target.exists() and not target.is_file()):
        raise RuntimeError('Unsafe sync file: ' + str(target))
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, target)
    shutil.copyfile(src, layout.evidence / ('input-' + src.name))
if args.sync:
    copied = []
    for directory, dirs, files in os.walk(SOURCE):
        dirs[:] = [d for d in dirs if d not in (".git", ".tmp", ".godot", ".tools", "__pycache__")]
        for name in files:
            if name == ".git":
                continue
            src = Path(directory) / name
            target = layout.workspace / src.relative_to(SOURCE)
            if not target.exists() or hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(src.read_bytes()).digest():
                validate_layout(layout, extra_write_paths=(target.parent,))
                if target.is_symlink() or (target.exists() and not target.is_file()):
                    raise RuntimeError('Unsafe sync file: ' + str(target))
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, target)
                copied.append({"path": src.relative_to(SOURCE).as_posix(), "sha256": hashlib.sha256(src.read_bytes()).hexdigest()})
    (layout.evidence / "source-sync.json").write_text(json.dumps(copied, indent=2))
if args.compose:
    # Same fragment order and omission rules as the maintained split runner.
    import re
    source = (layout.workspace / "tools/check_godot.ps1").read_text(encoding="utf-8-sig")
    block = source.split('$script:FoundationSplitSourceRelativePaths = @(',1)[1].split(')',1)[0]
    fragments = re.findall(r'"([^"]+\.gd)"', block)
    assert len(fragments) == 9
    combined, seen_json = [], False
    for number, path in enumerate(fragments):
        omit = False
        for index, line in enumerate((layout.workspace/path).read_text(encoding="utf-8-sig").splitlines()):
            if line.strip() == '# SPLIT_RUNNER_OMIT_BEGIN':
                assert not omit
                omit = True
                continue
            if line.strip() == '# SPLIT_RUNNER_OMIT_END':
                assert omit
                omit = False
                continue
            if omit or (number and index == 0 and re.match(r'^(extends|class_name)\s',line)):
                continue
            if line.startswith('const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")'):
                if seen_json:
                    continue
                seen_json = True
            combined.append(line)
        assert not omit
        combined.append('')
    destination = layout.workspace / '.tmp/generated_tests/foundation_check_split_runner.gd'
    validate_layout(layout, extra_write_paths=(destination.parent,))
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text('\n'.join(combined)+'\n', encoding='utf-8')
    shutil.copyfile(destination, layout.evidence / 'foundation_check_split_runner.gd')
if args.web_template:
    src = Path('D:/Projects/site/state/bth-next/appdata/Godot/export_templates/4.6.stable/web_dlink_nothreads_release.zip')
    assert hashlib.sha256(src.read_bytes()).hexdigest() == 'cf371f607aa9cb18e690bd595976c1baaf00c8cec24078e4a307fd515ad07913'
    target = layout.appdata / 'Godot/export_templates/4.6.stable/web_dlink_nothreads_release.zip'
    validate_layout(layout, extra_write_paths=(target.parent,))
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,target)
    (layout.evidence/'template.json').write_text(json.dumps({'source':str(src),'target':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}),encoding='utf-8')
if args.web_addon:
    served = Path('D:/Projects/site/projects/beat-the-house/public/play/dev/e5152c34bfe146600214fb206ec80a5e3e8a27cb')
    manifest = json.loads((served/'build_manifest.json').read_text(encoding='utf-8-sig'))
    assert manifest['source_commit'] == 'e5152c34bfe146600214fb206ec80a5e3e8a27cb'
    assert manifest['native_library_sha256'] == '9c34c4ea306efe66a13a9707a64f53573a31779e3b300bd359ed61c2f2ec33fc'
    src=served/manifest['native_library_path']
    assert hashlib.sha256(src.read_bytes()).hexdigest() == manifest['native_library_sha256']
    target=layout.workspace/'addons/coin_pusher_native/bin'/src.name
    validate_layout(layout,extra_write_paths=(target.parent,))
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,target)
    config=layout.workspace/'addons/coin_pusher_native/coin_pusher_native.gdextension'
    shutil.copyfile(SOURCE/'native/coin_pusher/coin_pusher_native.gdextension.template',config)
    (layout.evidence/'web-addon.json').write_text(json.dumps({'served_manifest':manifest,'target':str(target),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'scope':'Isolated branch art Web QA; current main native sources identical, no native gameplay claim.'},indent=2),encoding='utf-8')
command = args.command
if command and command[0] == '--':
    command = command[1:]
command = [s.replace('{workspace}', str(layout.workspace)).replace('{evidence}', str(layout.evidence)).replace('{save}', str(layout.save_dir)).replace('{profile}', str(layout.profile)).replace('{cache}', str(layout.cache)) for s in command]
if command:
    if '--export-release' in command:
        assert not args.cold_import, 'Cold-import policy must be removed before export; use separate import/export workers.'
        assert not (layout.workspace/'override.cfg').exists(), 'Unexpected import override at export boundary.'
        (layout.evidence/'export-policy.json').write_text(json.dumps({'override_absent':True,'presets_sha256':hashlib.sha256((layout.workspace/'export_presets.cfg').read_bytes()).hexdigest(),'project_sha256':hashlib.sha256((layout.workspace/'project.godot').read_bytes()).hexdigest()}),encoding='utf-8')
    for entry in args.env:
        key, value = entry.split('=', 1)
        os.environ[key] = value
    override = layout.workspace / 'override.cfg'
    policy = b'[editor]\nimport/use_multiple_threads=false\n\n[threading]\nworker_pool/max_threads=1\n'
    if args.cold_import:
        validate_layout(layout, extra_write_paths=(override.parent,))
        with override.open('xb') as handle:
            handle.write(policy)
    try:
        result = execute(layout, command, timeout=args.timeout)
    finally:
        if args.cold_import and override.read_bytes() == policy:
            override.unlink()
    print(json.dumps({k: result.get(k) for k in ('command','exit_code','error','cleanup_errors','timed_out','active_at_release')}))
    print('EVIDENCE', layout.evidence)
    sys.exit(0 if result.get('exit_code') == 0 and result.get('active_at_release') == 0 and not result.get('error') and not result.get('cleanup_errors') and not result.get('timed_out') else 1)
print('PREPARED', layout.evidence)
