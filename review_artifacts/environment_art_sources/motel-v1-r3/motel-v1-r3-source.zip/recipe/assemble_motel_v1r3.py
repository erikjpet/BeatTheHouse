import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw
sys.path.insert(0,r'D:/Projects/Beat-The-House/.tmp/environment-art-layers/tools')
from bth_qa_storage import Layout,validate_layout
m=json.loads((Path(os.environ['BTH_QA_EVIDENCE_DIR'])/'storage-manifest.json').read_text());l=Layout(**{k:Path(v) for k,v in m['paths'].items()},run_id=m['run_id'],token=m['token'],prepared=True,expected_write_bytes=m['expected_write_bytes'],reserve_bytes=m['reserve_bytes']);w=l.workspace;artist=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-ARTIST-20261114/motel-v1');sources={}
def source(name,h):
 p=artist/'source'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;sources[name]={'path':str(p),'sha256':h,'size':list(Image.open(p).size)};return Image.open(p).convert('RGB').resize((900,430),Image.Resampling.NEAREST)
s=source('background-guide-v1.png','d95f3252cc5b4b09adcf5b03364b9548585c96b278ad1fbe7eccec44c55e9af7');floor=source('floor-material-v1.png','c5535504cf57a43fe1355b32e07ff609ebf3668fe81fe14055943e2ec8abb64a');root=w/'packages/motel-v1-r3';validate_layout(l,extra_write_paths=(root,));assert not root.exists();asset=root/'assets/art/environments/motel';(asset/'anim').mkdir(parents=True);(asset/'counters').mkdir();(root/'data/art/environments').mkdir(parents=True);b=s.copy()
def fit(box,size):return s.crop(box).resize(size,Image.Resampling.NEAREST)
def patch(box,donor):b.paste(s.crop((donor[0],donor[1],donor[0]+box[2]-box[0],donor[1]+box[3]-box[1])),box[:2])
# Match exact wall/floor246 using one unscaled184px-deep plate crop. Existing upholstered/support foregrounds are replayed below.
b.paste(floor.crop((0,90,900,274)),(0,246));ImageDraw.Draw(b).line((0,246,899,246),fill=(30,18,39))
# Window: keep current inner glass/wordmark positions; only fit its existing lower physical frame plinth to224.
b.paste(fit((42,188,284,209),(242,36)),(42,188))
# Curtain/posts go behind door/front. Original overly short cloth is fitted, not replaced by wall fill.
patch((285,39,288,224),(820,39));patch((612,39,615,236),(825,39));patch((285,37,615,50),(285,23))
b.paste(fit((314,43,586,50),(272,6)),(314,44));b.paste(fit((314,49,586,174),(272,178)),(314,50));b.paste(fit((286,39,314,225),(26,192)),(288,44));b.paste(fit((585,39,614,231),(26,192)),(586,44))
# Door body stays260,84,86,126; the source's upper angled painted trim remains decorative in its original place.
patch((260,210,346,224),(812,210));b.paste(fit((260,94,345,224),(86,126)),(260,84))
header=fit((264,69,346,94),(74,22));hm=Image.new('L',(74,22),0);ImageDraw.Draw(hm).polygon([(0,16),(71,0),(73,4),(2,21)],fill=255);b.paste(header,(266,72),hm)
# Remove old main-front outer fringes before exact replay, retaining surrounding cloth/plaster/low masonry.
patch((630,173,634,231),(638,173));patch((548,228,630,232),(810,228))
front=fit((369,174,631,229),(260,52));p=front.load()
# The source's pale repair panel is not Phone backing. Make its real wood/laminate face dark for staff gold; preserve seams/chips.
for y in range(8,49):
 for x in range(2,48):
  r,g,bl=p[x,y];p[x,y]=(round(r*.36),round(g*.30),round(bl*.48))
# Keep one thin pink contact ridge, not the broad fitted-source lip.
front.paste(front.crop((0,2,260,3)),(0,0));b.paste(front,(370,176))
# Exact CRT body and BG-overlapping vending silhouette. Visible right casing is fitted separately, not a scaled duplicate cabinet.
patch((662,104,664,222),(650,104));patch((810,104,817,222),(820,104));patch((664,104,810,106),(664,101));patch((664,218,810,224),(664,224))
crt=fit((663,104,812,218),(146,112));b.paste(crt,(664,106));b.paste(fit((806,106,812,218),(14,112)),(796,106))
# Existing lower glass/bezel accent remains under the vending body, as in the original draw order.
b.paste(fit((685,195,787,207),(102,10)),(686,196))
vending=fit((740,55,805,209),(54,146));b.paste(vending,(742,58))
# Remove the old right-front pink ridge above246, then replay exact170x40 opaque front.
b.paste(s.crop((698,239,873,242)),(698,243));right=fit((698,243,873,287),(170,40));right.paste(right.crop((0,2,170,3)),(0,0));b.paste(right,(700,246))
# Public waiting banquette, same96,224,452,72 footprint, no pillows/bed/extra rail.
bench=fit((93,224,550,300),(452,72));b.paste(bench,(96,224))
# Low item-support contact/front and its two exact legs. No baked phone or inventory.
desk=fit((449,282,674,326),(224,38));desk.paste(desk.crop((0,2,224,3)),(0,0));dp=desk.load()
for y in range(3,36):
 for x in range(2,222):
  r,g,bl=dp[x,y];dp[x,y]=(round(r*.78),round(g*.74),round(bl*.86))
b.paste(desk,(450,286))
for box,x in [((461,325,476,373),466),((644,325,660,373),646)]:
 leg=fit(box,(12,48));b.paste(leg,(x,324));ImageDraw.Draw(b).line((x-1,372,x+12,372),fill=(28,17,34))
animations=[]
def save2(im,name):im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST).save(asset/'anim'/name)
# Actual pink glyph pixels pulse; no broad opaque neon rectangle.
sign=Image.new('RGBA',(202,116),(0,0,0,0));sp=sign.load()
for yy in range(86,114):
 for xx in range(76,196):
  r,g,bl=b.getpixel((xx,yy))
  if r>125 and r>g*1.6 and bl>60:sp[xx-62,yy-72]=(r,g,bl,210)
save2(sign,'motel_sign_pulse.png');per=math.pi/5;animations.append({'id':'motel_sign_pulse','type':'pulse','texture':'anim/motel_sign_pulse.png','rect':[62,72,202,116],'min_opacity':.12,'max_opacity':.40,'period':per,'phase':.62/5-per/4,'blend':'add','still':'first'})
band=Image.new('RGBA',(150,8),(0,0,0,0));d=ImageDraw.Draw(band)
for x in range(150):
 if x%37 not in (0,1):d.line((x,5,x,6),fill=(234,38,145,180))
save2(band,'sign_lower_light.png');animations.append({'id':'motel_lower_sign_band','type':'pulse','texture':'anim/sign_lower_light.png','rect':[82,118,150,8],'min_opacity':.22,'max_opacity':.40,'period':per,'phase':-per/4,'blend':'add','still':'first'})
# Ten CRT row sites share one one-second ramp. Cabinet occlusion and quiet gold-name band are fixed alpha masks, not scrolling masks.
CW,CH=62,68
F=16;lum=Image.new('RGBA',(CW*F,CH),(0,0,0,0));lp=lum.load()
for f in range(F):
 alpha=round(255*(.12+(f/F)*.18))
 for i in range(10):
  yy=126+i*6
  for y in range(yy,yy+2):
   if 124<=y<140:continue
   for x in range(684,742):lp[f*CW+x-680,y-122]=(179,207,213,alpha)
save2(lum,'crt_luminance_rows.png');animations.append({'id':'crt_shared_luminance_rows','type':'frames','texture':'anim/crt_luminance_rows.png','rect':[680,122,CW,CH],'frames':F,'fps':16,'loop':'loop','blend':'add','still':0})
# Distinct80fps two-pixel scan steps reproduce160px/s within62px height; atlas3844native wide fits Web texture cap.
F=31;scan=Image.new('RGBA',(CW*F,CH),(0,0,0,0));p=scan.load()
for f in range(F):
 yy=126+f*2
 for y,a in [(yy,95),(yy+1,95),(126+(f*2+19)%62,42)]:
  if y>=188 or 124<=y<140:continue
  for x in range(680,742):p[f*CW+x-680,y-122]=(189,217,220,a)
save2(scan,'crt_fast_scan.png');animations.append({'id':'crt_fast_scan','type':'frames','texture':'anim/crt_fast_scan.png','rect':[680,122,CW,CH],'frames':F,'fps':80,'loop':'loop','blend':'add','still':'hide'})
star=Image.new('RGBA',(6,6),(0,0,0,0));d=ImageDraw.Draw(star);d.line((0,3,5,3),fill=(57,195,215,175));d.line((3,0,3,5),fill=(113,224,233,175));d.point((3,3),fill=(205,255,250,220));save2(star,'cyan_glint.png')
fabric=Image.new('RGBA',(6,6),(0,0,0,0));fd=ImageDraw.Draw(fabric);fd.line((2,0,2,2),fill=(87,178,185,145));fd.line((3,3,3,5),fill=(117,199,202,155));fd.point((2,4),fill=(76,156,166,110));save2(fabric,'curtain_fold_reflection.png')
for i,(x,y) in enumerate(((420,148),(524,154),(746,194))):
 period=math.pi/4.2;animations.append({'id':f'glass_glint_{i}','type':'pulse','texture':('anim/curtain_fold_reflection.png' if i<2 else 'anim/cyan_glint.png'),'rect':[x-3,y-3,6,6],'min_opacity':.14,'max_opacity':.30,'period':period,'phase':i/4.2-period/4,'blend':'add','still':'hide'})
# Seven quiet matte-floor moving reflections translate the approved shared families in local honey/pink/teal colors.
colors=((148,178,177),(226,174,103),(186,111,157),(105,169,173),(228,182,121),(178,110,162),(118,164,171))
for i,color in enumerate(colors):
 width=72-4*i;im=Image.new('RGBA',(width,2),(0,0,0,0));p=im.load()
 for x in range(width):
  a=round(110*max(0,min(1,x/9,(width-1-x)/9)))
  if (x+3*i)%19 in (0,1):a=round(a*.4)
  p[x,0]=(*color,a)
  if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
 save2(im,f'floor_glint_{i}.png');speed=18+2.5*i;y=274+(i%4)*14;animations.append({'id':f'floor_glint_{i}','type':'mover','texture':f'anim/floor_glint_{i}.png','size':[width,2],'from':[-90,y],'to':[950,y],'duration':1040/speed,'phase':137*i/speed,'opacity':.18,'blend':'add','still':'hide'})
assert len(animations)==14
# Bounded real-material legibility correction after the measured current-label union.
# Entire first existing back-cushion face, not a label patch: wine piping/black seam/source weave remain.
p=b.load()
for yy in range(225,263):
 for xx in range(98,205):
  r,g,bl=p[xx,yy];p[xx,yy]=(round(r*.36+4),round(g*.38+3),round(bl*.45+4))
# One bright contact row286. Existing lowdesk lip287..289 is dark physical material below it.
for yy in range(287,290):
 for xx in range(450,674):
  r,g,bl=p[xx,yy];p[xx,yy]=(round(r*.32),round(g*.37),round(bl*.38))
b.save(root/'background-board-review.png');b.resize((1800,860),Image.Resampling.NEAREST).save(asset/'background.png')
for id,box in [('motel_lobby_table',(370,176,630,228)),('motel_merchandise_counter',(700,246,870,286))]:b.crop(box).convert('RGBA').resize(((box[2]-box[0])*2,(box[3]-box[1])*2),Image.Resampling.NEAREST).save(asset/'counters'/f'{id}.png')
manifest={'schema':'bth.environment_art/v1','environment_id':'motel','board_size':[900,430],'pixel_scale':2,'background':{'texture':'background.png'},'animations':animations,'counters':{id:{'texture':f'counters/{id}.png','bleed':[0,0,0,0]} for id in ['motel_lobby_table','motel_merchandise_counter']}}
(root/'data/art/environments/motel.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'data/art/environments/index.json').write_text(json.dumps({'enabled':['gas_station_casino','corner_store','back_alley','motel']},indent=2)+'\n')
files={}
for p in sorted(list((root/'assets').rglob('*.png'))+list((root/'data').rglob('*.json'))):
 data=p.read_bytes();e={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 if p.suffix=='.png':
  im=Image.open(p);e.update(size=list(im.size),mode=im.mode)
  if im.mode=='RGBA':e['alpha_extrema']=list(im.getchannel('A').getextrema())
 files[p.relative_to(root).as_posix()]=e
sha=hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(files.items())).encode()).hexdigest();record={'package_id':'motel-v1-r3','status':'SEALED_TRIAL_NOT_PASSED','package_sha256':sha,'files':files,'sources':sources,'frozen_generation_inputs':json.loads((artist/'inputs/input-provenance.json').read_text()),'changes':['Nearest900-grid exact2x assembly; raw originals preserved.','Visible floor246 uses original-scale184px-deep matching material crop, no stretching or wet gloss.','Same-footprint public banquette, door210end, windowplinth224, curtains236, exact main/right/low supports and leg contacts.','Dark real staff wood and low support face, no speculative pale Phone backing or moved label.','14 entries:2sign pulses, shared-clock10siteCRT row ramp, distinct160px/s scan,3glints and7floor movers. CRT alpha excludes BG cabinet x742..796 and diagnostic gold title y124..140; live Drink occlusion remains natural. Actual visibility gate pending.','R3 narrow material change: inkplum first backcushion face preserves piping/weave and supports pink Parking plus gold Wedding Bestperson; lowdesk bright row286 only, dark physical lip287..289. No other room style/CRT/motion changes.','First two tiny reflections are broken cloth-fold highlights, not glass stars; third is on existing appliance trim.','Two opaque mapped fronts identical to BG crops; cumulative accepted Gas/Corner/Back activation preserved, no prior bytes changed.','No cast,stock,phone,rain,staticCRTscan or newprops baked. No renderer/placement changes.']};(root/'package-seal.json').write_text(json.dumps(record,indent=2));(root/'edit-record.json').write_text(json.dumps(record,indent=2));print(json.dumps({'package':str(root),'package_sha256':sha,'background':files['assets/art/environments/motel/background.png']['sha256'],'textures':sum(k.endswith('.png') for k in files),'animations':14,'files':len(files)}))


