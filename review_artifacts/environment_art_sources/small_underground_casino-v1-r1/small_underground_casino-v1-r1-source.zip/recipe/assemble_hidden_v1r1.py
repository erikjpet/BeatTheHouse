import os,sys,json,hashlib,math
from pathlib import Path
from PIL import Image,ImageDraw
REPO=Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers');sys.path.insert(0,str(REPO/'tools'))
from bth_qa_storage import Layout,validate_layout
from check_environment_art_pack import validate_manifest,counter_rectangles
e=Path(os.environ['BTH_QA_EVIDENCE_DIR']);m=json.loads((e/'storage-manifest.json').read_bytes());l=Layout(**{k:Path(v) for k,v in m['paths'].items()},run_id=m['run_id'],token=m['token'],prepared=True,expected_write_bytes=m['expected_write_bytes'],reserve_bytes=m['reserve_bytes']);w=l.workspace;artist=Path(r'E:/CodexQA/BTH/workspaces/BTH-ENVART-ARTIST-20261114/small_underground_casino-v1');rawp=artist/'source/background-guide-v1.png';floorp=artist/'source/floor-material-v1.png'
def H(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert H(rawp)=='27156ddb75d7a70f41d1e78fb333f4ef8dba2a56184104ce1c5b4181bfbb341d';assert H(floorp)=='159b69b0466557a9b4d3140deb635d80032d4396f948d51ad73676dad18c437c'
provenance=json.loads((artist/'inputs/input-provenance-generation-v1.json').read_bytes())
for v in provenance['inputs']:assert H(artist/'inputs'/v['file'])==v['sha256']
raw=Image.open(rawp).convert('RGB');s=raw.resize((900,430),Image.Resampling.NEAREST);q=s.copy();b=s.copy();root=w/'packages/small_underground_casino-v1-r1';validate_layout(l,extra_write_paths=(root,));assert not root.exists();asset=root/'assets/art/environments/small_underground_casino';(asset/'anim').mkdir(parents=True);(asset/'counters').mkdir();(root/'data/art/environments').mkdir(parents=True)
def fit(im,box,size):return im.crop(box).resize(size,Image.Resampling.NEAREST)
# Repair only old source fixture footprints before exact modules. Donors stay
# on the same masonry/plaster course; almost all repaired area is re-covered.
old=[(98,149,345,244),(432,137,730,249),(742,86,855,271),(37,166,112,273)]
def blocked(x,y):return any(a<=x<c and bb<=y<d for a,bb,c,d in old)
healed=0
for a,bb,c,d in old:
 for y in range(bb,d):
  valid=[x for x in range(900) if not blocked(x,y)]
  for x in range(a,c):
   choices=[xx for xx in (x+47*k for k in range(-20,21)) if 0<=xx<900 and not blocked(xx,y)] or valid;xx=min(choices,key=lambda xx:abs(xx-x));q.putpixel((x,y),s.getpixel((xx,y)));healed+=1
# Fit source low construction to the actual fixed beam rows. Small piecewise
# changes affect real wall planes, never floor grain or live coordinates.
sy=[0,22,34,44,60,66,69,78,104,113,249,267];ty=[0,26,34,42,56,62,68,76,102,110,236,245]
observed=[96,169,240,311,383,455,527,600,671,744,816,888];sx=[0]+observed+[900];tx=[0]+[96+72*i for i in range(12)]+[900]
for yi in range(len(sy)-1):
 for xi in range(len(sx)-1):b.paste(fit(q,(sx[xi],sy[yi],sx[xi+1],sy[yi+1]),(tx[xi+1]-tx[xi],ty[yi+1]-ty[yi])),(tx[xi],ty[yi]))
# Only the real68/102 steel/wood beam faces lose continuous hot orange lips.
# Source pitting, bolts, dark plum and selective worn edges remain.
beam_changed=0
for ya,yb in ((68,76),(102,110)):
 for y in range(ya,yb):
  for x in range(900):
   r,g,bl=b.getpixel((x,y))
   if r>80 and r>g*1.25 and g>bl*.72:
    f=.62 if y==ya else .39;b.putpixel((x,y),(round(r*f+4),round(g*f*.78+3),round(bl*.70+4)));beam_changed+=1
# Original-scale370-native-pixel floor plate crop, no stretching or repetition.
floor_raw=Image.open(floorp).convert('RGB');floorbox=(7,150,1807,520);floor=fit(floor_raw,floorbox,(900,185));b.paste(floor,(0,245))
# Exact left body. No foreground replay exists for this table.
table_metrics={}
def table(box,size,name):
 im=fit(s,box,size);p=im.load();n=0
 for y in range(size[1]):
  for x in range(size[0]):
   r,g,bl=p[x,y];edge=(x<11 or x>=size[0]-11 or y<11 or y>=size[1]-10)
   if edge and r>90 and r>g*1.2 and g>bl*.72:
    f=.65 if y==0 else .38;p[x,y]=(round(r*f+4),round(g*f*.84+3),round(bl*.66+4));n+=1
   elif not edge and g>r*1.08:p[x,y]=(round(r*.83),round(g*.76),round(bl*.83))
 table_metrics[name]={'source_box':list(box),'size':list(size),'warm_frame_pixels_quieted':n};return im
b.paste(table((99,150,344,242),(242,86),'left_table'),(100,154));b.paste(table((434,138,728,247),(286,98),'mapped_right_table'),(438,142))
# Source cart and doorway, exact original footprints. No bottles/cast added.
cart=fit(s,(38,187,111,272),(70,82));cp=cart.load()
for y in range(82):
 for x in range(70):
  r,g,bl=cp[x,y]
  if r>125 and g>65 and r>bl*1.25:cp[x,y]=(round(r*.60+4),round(g*.53+3),round(bl*.75+3))
b.paste(cart,(40,188));top=fit(s,(47,167,103,188),(54,20));tp=top.load()
for y in range(20):
 for x in range(54):
  r,g,bl=tp[x,y]
  if y>0:tp[x,y]=(round(r*.66+3),round(g*.62+2),round(bl*.8+2))
b.paste(top,(48,168));b.paste(fit(s,(744,88,853,268),(108,178)),(744,88))
# Keep all twelve existing wire/housing sites. Fit source glass colors to the
# approved independently seeded first-ten core identities; final two steady.
colors=[(196,77,255),(255,45,120),(0,255,213)];core_masks=[];core_counts=[]
for i in range(12):
 cx=96+72*i;color=colors[i%3] if i<10 else (255,45,120);mask=Image.new('L',(8,8));mp=mask.load();n=0
 for yy in range(8):
  for xx in range(8):
   x,y=cx-4+xx,52+yy;r,g,bl=b.getpixel((x,y));bright=max(r,g,bl)
   if (xx-3.5)**2+(yy-3.5)**2<=16 and ((bright>110 and bl>g*.70 and bl>55) or min(r,g,bl)>130):mp[xx,yy]=255;n+=1
 assert n>0,(i,n)
 core_masks.append(mask);core_counts.append(n)
 for y in range(48,64):
  for x in range(cx-6,cx+6):
   r,g,bl=b.getpixel((x,y));bright=max(r,g,bl)
   if (bright>110 and bl>g*.70 and bl>55) or min(r,g,bl)>130:
    strength=.13+.15*bright/255 if i<10 else .24+.14*bright/255;b.putpixel((x,y),tuple(round(c*strength+5) for c in color))
b.save(root/'background-board-review.png');bg=b.resize((1800,860),Image.Resampling.NEAREST);bg.save(asset/'background.png');right=b.crop((438,142,724,240)).convert('RGBA');right.resize((572,196),Image.Resampling.NEAREST).save(asset/'counters/punchline_right_table.png')
animations=[]
def save2(im,name):im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST).save(asset/'anim'/name)
# Thirty-two samples of the original abs-sine, exact source phase offsets.
period=math.pi/3.2
for i in range(10):
 im=Image.new('RGBA',(8*32,8));p=im.load();color=colors[i%3]
 for f in range(32):
  alpha=round((.16+abs(math.sin(math.pi*f/32))*.24)*255)
  for yy in range(8):
   for xx in range(8):
    if core_masks[i].getpixel((xx,yy)):p[f*8+xx,yy]=(*color,alpha)
 name=f'string_core_{i}.png';save2(im,name);animations.append({'id':f'string_core_{i}','type':'frames','texture':'anim/'+name,'rect':[92+72*i,52,8,8],'frames':32,'fps':32/period,'phase':i*.8/3.2,'blend':'add','still':round((i*.8/math.pi%1)*32)%32})
# Six distinct16px long bands retain16board/s, with full offscreen entry/exit.
pink=(255,45,120);long=Image.new('RGBA',(260,16));p=long.load()
for y in range(16):
 for x in range(260):
  taper=max(0,min(1,x/20,(259-x)/20));edge=1 if 3<=y<13 else .66 if 1<=y<15 else .33;a=round(12*taper*edge)
  if (x+y*7)%73 in (0,1):a=round(a*.55)
  p[x,y]=(*pink,a)
save2(long,'long_pink_band.png')
for i in range(6):animations.append({'id':f'long_pink_drift_{i}','type':'mover','texture':'anim/long_pink_band.png','size':[260,16],'from':[-260,116+i*18],'to':[900,116+i*18],'duration':1160/16,'phase':(140+i*160)/16,'opacity':.95625,'blend':'mix','still':'hide'})
# Five separately bobbing ribbons preserve rows92+18i,10..18px/s,4.488s bob.
bob_period=2*math.pi/1.4;fps=8/bob_period
for i in range(5):
 ww=180-16*i;speed=10+2*i;phase=(ww+i*150-86)/speed;im=Image.new('RGBA',(ww*8,20));p=im.load()
 for f in range(8):
  yy0=5+round(math.sin((f/fps-phase)*1.4+i)*5)
  for y in range(10):
   for x in range(ww):
    taper=max(0,min(1,x/14,(ww-1-x)/14));edge=1 if 2<=y<8 else .55;a=round(13*taper*edge)
    if (x+i*19+y*11)%61 in (0,1):a=round(a*.5)
    p[f*ww+x,yy0+y]=(*pink,a)
 name=f'thin_pink_ribbon_{i}.png';save2(im,name);animations.append({'id':f'thin_bobbing_ribbon_{i}','type':'mover','texture':'anim/'+name,'size':[ww,20],'from':[-ww,87+i*18],'to':[900,87+i*18],'duration':(900+ww)/speed,'phase':phase,'frames':8,'fps':fps,'opacity':.9807692307692307,'blend':'mix','still':'hide'})
# Broken source-material edge glints, not floating cross/star sprites.
glint_counts=[]
for i,(cx,cy) in enumerate(((154,134),(505,136),(772,142))):
 im=Image.new('RGBA',(8,8));p=im.load();candidates=[]
 for yy in range(1,7):
  for xx in range(1,7):
   x,y=cx-4+xx,cy-4+yy;v=b.getpixel((x,y));n=b.getpixel((x+1,y)) if i<2 else b.getpixel((x,y+1));delta=max(abs(a-bb) for a,bb in zip(v,n));candidates.append((delta,xx,yy))
 chosen=sorted(candidates,reverse=True)[:10]
 for delta,xx,yy in chosen:p[xx,yy]=(0,255,213,180 if delta>15 else 140)
 name=f'teal_material_glint_{i}.png';save2(im,name);glint_counts.append(len(chosen));pp=math.pi/4.2;animations.append({'id':f'teal_material_glint_{i}','type':'pulse','texture':'anim/'+name,'rect':[cx-4,cy-4,8,8],'min_opacity':.16,'max_opacity':.32,'period':pp,'phase':i*1.7/4.2-pp/4,'blend':'add','still':'hide'})
# Seven dry-material movers explicitly consolidate BOTH old floor families.
for i,color in enumerate(((158,65,131),(43,139,154),(185,93,97),(154,66,136),(51,141,147),(175,99,85),(160,69,132))):
 ww=72-4*i;im=Image.new('RGBA',(ww,2));p=im.load()
 for x in range(ww):
  a=round(110*max(0,min(1,x/9,(ww-1-x)/9)));a=round(a*.4) if (x+3*i)%19 in (0,1) else a;p[x,0]=(*color,a)
  if (x+i)%7 not in (0,1):p[x,1]=(*color,round(a*.45))
 name=f'floor_glint_{i}.png';save2(im,name);speed=18+2.5*i;y=278+(i%4)*14;animations.append({'id':f'floor_glint_{i}','type':'mover','texture':'anim/'+name,'size':[ww,2],'from':[-90,y],'to':[950,y],'duration':1040/speed,'phase':137*i/speed,'opacity':.16,'blend':'add','still':'hide'})
assert len(animations)==31;room='small_underground_casino';counters=counter_rectangles(REPO,room);assert counters=={'punchline_right_table':[438,142,286,98]},counters
manifest={'schema':'bth.environment_art/v1','environment_id':room,'board_size':[900,430],'pixel_scale':2,'background':{'texture':'background.png'},'animations':animations,'counters':{'punchline_right_table':{'texture':'counters/punchline_right_table.png','bleed':[0,0,0,0]}}};(root/f'data/art/environments/{room}.json').write_text(json.dumps(manifest,indent=2)+'\n');(root/'data/art/environments/index.json').write_text(json.dumps({'enabled':['gas_station_casino','corner_store','back_alley','motel','bar','pawn_shop','jazz_club','punchline_club',room]},indent=2)+'\n');validate_manifest(manifest,room,asset,counters)
files={}
for path in sorted(list((root/'assets').rglob('*.png'))+list((root/'data').rglob('*.json'))):
 v={'sha256':H(path),'bytes':path.stat().st_size}
 if path.suffix=='.png':
  im=Image.open(path);v.update(size=list(im.size),mode=im.mode)
  if im.mode=='RGBA':v['alpha_extrema']=list(im.getchannel('A').getextrema())
 files[path.relative_to(root).as_posix()]=v
package_sha=hashlib.sha256('\n'.join(k+' '+v['sha256'] for k,v in sorted(files.items())).encode()).hexdigest();record={'package_id':'small_underground_casino-v1-r1','status':'SEALED_STATIC_TRIAL_NOT_PASSED','package_sha256':package_sha,'files':files,'sources':{str(rawp):H(rawp),str(floorp):H(floorp)},'frozen_generation_inputs':provenance,'recipe':str(Path(__file__)),'recipe_sha256':H(__file__),'construction_metrics':{'healed_old_fixture_source_pixels':healed,'beam_warm_pixels_quieted':beam_changed,'table_modules':table_metrics,'floor_plate_native_crop':list(floorbox),'core_source_mask_pixels':core_counts,'glint_source_edge_pixels':glint_counts},'notes':['Hidden :casino only. Own patched plum/charcoal wall,old wood/metal,deepgreen felt,dry matte slab floor. No public/private palette,motion or painted cast/stock. Original source and floor plate immutable.','Exact low beam rows34..42/68..76/102..110,soffit26,12fixed housing centers96+72i at56;left10015424286,no left foreground. Right43814228698 is exact572x196opaque BG crop. Cart401887082/top481685420,door74488108178,floor245.','Source wire/housing top strip and wall courses piecewise fitted,not moved gameplay data. Warm real68/102beam faces and table frame/felt material locally quieted while preserving source grain/bolts/patches;not label rectangles or global grade.','Original usable floor328nativepixels vs370required. One same-source floor plate fills exact native[7,150,1800,370] crop at original scale;no stretch/repeated grain/wet gloss.','Ten distinct32-frame actual abs-sine alpha samplings preserve source3.2angularspeed,0.8phaseoffset and Purple2/Pink/Teal seeded identities while aligning FIRSTten physical housing sites. Last2steady pink. Max core atlas512nativepixels;not12movingcores or exact old97+74i positions.','Six long16-highpinkdrifts at116+18i retain16board/s;five separate10-highribbons at92+18i retain10+2i speed and sin1.4 bob sampled8frames over4.488seconds. Full offscreen mover wraps intentionally replace old partially visible procedural resets;not literal seeded trajectory equivalence. Air max effective alpha.045/.05,stepped source-shaped edges/no blur or blanket haze.','31genuine moving entries:10cores+6longdrifts+5bobbingribbons+3teal source-material glints+7dryfloor movers. Sevenfloor consolidate common sheen+older lower reflection family. No static entry counted as motion,new sign/rain/scan or counter holes.','Source-material edge masks make glints broken reflections on existing plaster/doorgrain at154134/505136/772142,not floating stars.','Current4 actual composition/title and source-painted motion/RM/replay/hit/work-outcome/liveness acceptance remain pending. Compact title/housing overlaps may remain naturally covered;never infer opacity from model envelopes.']};(root/'package-seal.json').write_text(json.dumps(record,indent=2));(root/'edit-record.json').write_text(json.dumps(record,indent=2));print(json.dumps({'package':str(root),'package_sha256':package_sha,'background_sha256':files[f'assets/art/environments/{room}/background.png']['sha256'],'files':len(files),'entries':31,'core_pixels':core_counts,'validator':'PASS'}))
