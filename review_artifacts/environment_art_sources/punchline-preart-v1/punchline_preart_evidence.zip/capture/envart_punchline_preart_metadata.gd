extends SceneTree
const MainScene := preload("res://scenes/main.tscn")
const CanvasScript := preload("res://scripts/ui/pixel_scene_canvas.gd")
const PlacementStoreScript := preload("res://scripts/core/developer_placement_store.gd")
const DiagnosticCanvasScript := preload("res://tools/envart_punchline_comic_diagnostic.gd")
const ScenarioEngineScript := preload("res://scripts/core/scenario_engine.gd")
const SEED_TEXT := "LAYOUT-SURVEY-QA"
var app: Node
var out_dir := ""
var checks := 0
var findings: Array[String] = []
var views: Dictionary = {}

func _init() -> void:
    out_dir = OS.get_environment("BTH_QA_EVIDENCE_DIR")
    call_deferred("_run")

func _check(value: bool, message: String) -> void:
    checks += 1
    if not value:
        findings.append(message)
        push_error(message)

func _settle(frames: int = 8) -> void:
    for i in range(frames):
        await process_frame

func _arrivals(canvas: Control) -> Dictionary:
    var before: float = canvas.get("flicker")
    var waited := 4.0
    await create_timer(waited).timeout
    while not (canvas.get("person_transits") as Dictionary).is_empty() and waited < 12.0:
        await create_timer(0.25).timeout
        waited += 0.25
    await RenderingServer.frame_post_draw
    return {"clock_before":before,"clock_after":canvas.get("flicker"),"timer_wait_seconds":waited,"remaining_person_transits":(canvas.get("person_transits") as Dictionary).size(),"input_during_wait":false,"positions_modified":false}

func _run() -> void:
    if not out_dir.begins_with("E:") and not out_dir.begins_with("E:/"):
        push_error("Explicit admitted E evidence required")
        quit(1)
        return
    _check(not FileAccess.file_exists("res://data/art/environments/punchline_club.json"),"No Punchline pack in strict baseline")
    var inputs: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://punchline_capture_inputs.json"))
    for path in inputs["source_hashes"]:
        _check(FileAccess.get_sha256("res://"+str(path))==str(inputs["source_hashes"][path]),"Strict baseline source: "+str(path))
    if not findings.is_empty():
        quit(1)
        return
    root.size = Vector2i(1280,720)
    app = MainScene.instantiate()
    app.set("script_prewarm_stopping",true)
    root.add_child(app)
    await _settle()
    var neutral := InputEventMouseMotion.new()
    neutral.position = Vector2(900,100)
    neutral.global_position = neutral.position
    root.push_input(neutral,true)
    app.call("open_environment_test_menu")
    app.call("_environment_test_select_id",app.get("environment_test_archetype_option"),"small_underground_casino")
    app.call("_refresh_environment_test_identity_options")
    var catalog: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/environments/scenarios.json"))
    var selections: Array[String] = ["__none"]
    for row in catalog["small_underground_casino"]:
        if str(row.get("layer_id",""))=="club":
            selections.append(str(row["id"]))
    _check(selections.size()==6,"Exact current public catalog: Base and five initial scenarios")
    for scenario in selections:
        app.call("_environment_test_select_id",app.get("environment_test_scenario_option"),scenario)
        app.call("_sync_environment_test_layer_to_scenario")
        if scenario=="__none":
            _check(bool(app.call("_environment_test_select_id",app.get("environment_test_layer_option"),"club")),"Base public club layer selected")
        app.get("environment_test_seed_input").text = SEED_TEXT
        var generated: Dictionary = app.call("start_environment_test_session")
        _check(bool(generated.get("ok",false)),scenario+" production practice generation")
        if not bool(generated.get("ok",false)):
            continue
        await _settle()
        var run_state: Variant = app.get("run_state")
        var resolved: Dictionary = {}
        var initial_state: Dictionary = run_state.current_environment.get("scenario_sequence_state",{}).duplicate(true)
        if scenario != "__none":
            var candidate: Dictionary = run_state.current_environment.duplicate(true)
            var definition: Dictionary = candidate.get("scenario_sequence_definition",{})
            var committed: Dictionary = ScenarioEngineScript._commit_sequence_candidate(candidate,candidate.duplicate(true),definition,{"ok":true,"state":initial_state,"errors":[]})
            _check(bool(committed.get("ok",false)),scenario+" unchanged Engine same-state commit")
            resolved = run_state.call("_publish_scenario_membership_candidate",candidate,committed,"qa_initial_same_state") if bool(committed.get("ok",false)) else committed
            _check(bool(resolved.get("ok",false)),scenario+" actual physical-membership publication")
            _check(not (resolved.get("renderer_snapshot",{}).get("visual_objects",[]) as Array).is_empty(),scenario+" nonempty Runtime renderer source")
            app.call("_set_current_screen","ENVIRONMENT")
            app.call("_clear_selected_game_action")
            app.call("_render_environment_screen")
            await _settle()
        var canvas: Control = app.get("environment_canvas")
        var arrival := await _arrivals(canvas)
        _check(int(arrival["remaining_person_transits"])==0,scenario+" natural arrivals completed")
        var authority: Dictionary = run_state.call("validate_room_action_authority")
        _check(bool(authority.get("ok",false)),scenario+" live production room authority")
        await RenderingServer.frame_post_draw
        var snapshot: Dictionary = canvas.get("foundation_snapshot").duplicate(true)
        var capture_clock: float = canvas.get("flicker")
        var capture_frame := Engine.get_process_frames()
        var frozen_image := root.get_texture().get_image()
        _check(str(snapshot.get("scenario_id",""))==("" if scenario=="__none" else scenario),scenario+" exact scenario identity")
        _check(canvas.get("environment_art_pack")==null,scenario+" unchanged strictab0 legacy public Punchline fallback")
        var view: Dictionary = canvas.call("current_view_snapshot")
        _check(str(snapshot.get("archetype_id",""))=="small_underground_casino",scenario+" actual archetype")
        _check(str(snapshot.get("current_layer_id",""))=="club",scenario+" actual public layer")
        _check(PlacementStoreScript.room_key(snapshot)=="small_underground_casino:club",scenario+" actual override key")
        _check(str(snapshot.get("visual_context",{}).get("art_key",""))=="punchline_club",scenario+" actual snapshot art identity")
        _check(str(view.get("environment_id",""))=="punchline_club",scenario+" actual canvas dispatch")
        _check(bool(view.get("object_labels_and_borders_enabled",false)),scenario+" labels enabled")
        _check(is_equal_approx(float(view["scene_animation_time"]),capture_clock),scenario+" same-frame image/view clock")
        _check(str(view.get("hovered_object_id",""))=="",scenario+" neutral owned-window pointer")
        var objects: Array = view.get("objects",[])
        var geometry: Array = view.get("object_layout",{}).get("objects",[])
        var actual_canvas_evidence: Array = []
        for actual_object in objects:
            var actual_id := str(actual_object.get("id",""))
            var actual_geometry: Array = geometry.filter(func(o): return str(o.get("id",""))==actual_id)
            var actual_label := str(actual_object.get("label",""))
            var actual_label_rect: Dictionary = actual_geometry[0].get("label_rect",{}) if actual_geometry.size()==1 else {}
            var color: Color = canvas.call("_color_for_object_type",str(actual_object.get("type","")))
            _check(actual_geometry.size()==1 and not actual_label.is_empty() and float(actual_label_rect.get("w",0))>0 and float(actual_label_rect.get("h",0))>0,scenario+" every actual canvas object has positive label geometry: "+actual_id)
            actual_canvas_evidence.append({"id":actual_id,"label":actual_label,"object":actual_object,"geometry":actual_geometry,"body_draw_layer":canvas.call("_scene_object_draw_layer",actual_object),"type_color_rgba":[color.r,color.g,color.b,color.a]})
        var published: Array = snapshot.get("interactable_objects",[])
        var render_snapshot: Dictionary = resolved.get("renderer_snapshot",{})
        var semantic: Dictionary = resolved.get("projection",{}).get("semantic_state",{})
        if scenario != "__none":
            _check(str(snapshot.get("scenario_sequence_state",{}).get("phase_id",""))==str(initial_state.get("phase_id","")) and str(snapshot.get("scenario_sequence_state",{}).get("status",""))==str(initial_state.get("status","")),scenario+" initial phase/status unchanged")
        var pub_evidence: Array = []
        for row_value in published:
            var row: Dictionary = row_value
            var id := str(row.get("object_id",""))
            var room_visible: bool = bool(row.get("visible",true)) and str(row.get("presentation_mode","room"))=="room"
            var actual: Array = objects.filter(func(o): return str(o.get("id",""))==id)
            var actual_geometry: Array = geometry.filter(func(o): return str(o.get("id",""))==id)
            var label := str(row.get("label",""))
            var label_rect: Dictionary = actual_geometry[0].get("label_rect",{}) if actual_geometry.size()==1 else {}
            if room_visible:
                _check(actual.size()==1 and actual_geometry.size()==1,scenario+" published room object reaches actual canvas: "+id)
                _check(actual.size()==1 and str(actual[0].get("label",""))==label,scenario+" exact published label on canvas: "+id)
                _check(not label.is_empty() and float(label_rect.get("w",0))>0 and float(label_rect.get("h",0))>0,scenario+" actual nonempty label rectangle: "+id)
            else:
                _check(actual.is_empty() and actual_geometry.is_empty(),scenario+" hidden/non-room publication absent from actual canvas: "+id)
            var object_type := str(actual[0].get("type","")) if actual.size()==1 else ""
            var color: Color = canvas.call("_color_for_object_type",object_type)
            pub_evidence.append({"id":id,"room_visible":room_visible,"published_record":row,"label":label,"actual_objects":actual,"actual_geometry":actual_geometry,"type_color_rgba":[color.r,color.g,color.b,color.a],"disabled":bool(actual[0].get("disabled",false)) if actual.size()==1 else false,"exclusion":"" if room_visible else "Published record explicitly hidden or non-room; no in-room label claim."})
        var source_evidence: Array = []
        for value in render_snapshot.get("visual_objects",[]):
            var visual: Dictionary = value
            var id := str(visual.get("object_id",""))
            var room_visible: bool = bool(visual.get("visible",true)) and str(visual.get("presentation_mode","room"))=="room"
            var interaction: Dictionary = semantic.get("interactions",{}).get(id,{})
            var present: bool = not interaction.is_empty() and bool(interaction.get("present",true))
            var source_label := str(visual.get("label",""))
            var expected := str(interaction.get("label",source_label)) if present else source_label
            var actual: Array = objects.filter(func(o): return str(o.get("id",""))==id)
            var actual_geometry: Array = geometry.filter(func(o): return str(o.get("id",""))==id)
            var pub: Array = published.filter(func(o): return str(o.get("object_id",""))==id)
            if room_visible:
                _check(actual.size()==1 and actual_geometry.size()==1 and pub.size()==1,scenario+" every Runtime room visual published and rendered: "+id)
                _check(pub.size()==1 and str(pub[0].get("label",""))==expected and actual.size()==1 and str(actual[0].get("label",""))==expected,scenario+" source-composed interaction label precedence: "+id)
            else:
                _check(actual.is_empty() and actual_geometry.is_empty(),scenario+" hidden/non-room Runtime visual absent from canvas: "+id)
            source_evidence.append({"id":id,"room_visible":room_visible,"source_visual":visual,"source_label":source_label,"interaction":interaction,"present_interaction":present,"expected_final_label":expected,"published_objects":pub,"actual_objects":actual,"actual_geometry":actual_geometry,"exclusion":"" if room_visible else "Runtime visual explicitly hidden or non-room; no in-room label claim."})
        var exclusions: Array = []
        for collection in ["actors","scene_objects","interactions"]:
            var rows: Dictionary = semantic.get(collection,{})
            for identity in rows:
                var row: Dictionary = rows[identity]
                if not bool(row.get("present",true)) or str(row.get("presentation_mode","room"))!="room":
                    exclusions.append({"collection":collection,"identity":identity,"record":row,"reason":"Semantic record explicitly absent or non-room. No visual assertion."})
        frozen_image.save_png(out_dir.path_join(scenario+"_actual_play.png"))
        var replay := await _board_replay(snapshot,scenario)
        views[scenario] = {"generated":generated,"arrival":arrival,"snapshot":snapshot,"actual_view":view,"published_evidence":pub_evidence,"runtime_visual_evidence":source_evidence,"semantic_exclusions":exclusions,"board_replay":replay}
        views[scenario]["actual_canvas_evidence"] = actual_canvas_evidence
        views[scenario]["comic_body_diagnostic"] = await _comic_diagnostic(snapshot,scenario)
        views[scenario]["capture_clock"] = capture_clock
        views[scenario]["capture_process_frame"] = capture_frame
        views[scenario]["selected_label_evidence"] = await _selected_labels(canvas,objects,scenario)
        views[scenario]["live_authority"] = authority
        views[scenario]["same_state_publication"] = resolved
        views[scenario]["initial_runtime_state"] = initial_state
        var partial := FileAccess.open(out_dir.path_join(scenario+"_metadata.json"),FileAccess.WRITE)
        partial.store_string(JSON.stringify(views[scenario],"\t"))
        partial.close()
        print("PUNCHLINE_PREART_CAPTURED ",scenario)
    _check(views.size()==selections.size(),"All actual catalog scenarios and Base captured")
    var report := {"commit":"ab0b49deeab019deac7ef30b79b17f86ffbc521d","checks":checks,"findings":findings,"scenarios":selections,"catalog_public_punchline":inputs["catalog"],"views":views,"scope":"Unchanged strictab0 production app, code, data, placement and art index. Actual Base and each current initial settled scenario. Production practice menu generation, unchanged Engine same-initial-state commit, RunState physical-membership publication and native arrivals. No work/outcome transitions. Observational helpers only. This is PRE-ART layout metadata, not a Punchline art PASS or work/outcome coverage.","label_precedence_source":"environment_interaction_controller.gd _compose_projected_records merges visuals, then present interactions; _merge_projected_interaction sets label from semantic interaction. Actual published record and canvas label asserted.","label_color_source":"pixel_scene_canvas.gd _draw_object_label: type color, normal alpha0.72, active0.94, disabled C_SOFT alpha0.56."}
    for path in inputs["source_hashes"]:
        _check(FileAccess.get_sha256("res://"+str(path))==str(inputs["source_hashes"][path]),"Unchanged after capture: "+str(path))
    report["checks"] = checks
    report["findings"] = findings
    var file := FileAccess.open(out_dir.path_join("punchline_preart_metadata.json"),FileAccess.WRITE)
    file.store_string(JSON.stringify(report,"\t"))
    file.close()
    print("PUNCHLINE_PREART_RESULT ",JSON.stringify({"checks":checks,"findings":findings,"contexts":views.size()}))
    app.queue_free()
    await process_frame
    quit(0 if findings.is_empty() else 1)

func _board_replay(snapshot: Dictionary,name_value: String) -> Dictionary:
    var viewport := SubViewport.new()
    viewport.size = Vector2i(1800,860)
    viewport.disable_3d = true
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    root.add_child(viewport)
    var canvas: Control = CanvasScript.new()
    canvas.size = Vector2(1800,860)
    viewport.add_child(canvas)
    canvas.call("render_environment_snapshot",snapshot)
    await _settle()
    var arrival := await _arrivals(canvas)
    await RenderingServer.frame_post_draw
    viewport.get_texture().get_image().save_png(out_dir.path_join(name_value+"_production_board_1800x860.png"))
    var view: Dictionary = canvas.call("current_view_snapshot")
    _check(str(view.get("environment_id",""))=="punchline_club",name_value+" board replay public dispatch")
    _check(canvas.get("environment_art_pack")==null,name_value+" board replay legacy fallback")
    var capture_clock: float = canvas.get("flicker")
    var capture_frame := Engine.get_process_frames()
    viewport.free()
    return {"scope":"Unchanged production canvas, actual captured snapshot, natural settled arrival, 2x board replay. Full app pixels captured separately.","arrival":arrival,"view":view,"capture_clock":capture_clock,"capture_process_frame":capture_frame}

func _selected_labels(canvas: Control, objects: Array, scenario: String) -> Array:
    var evidence: Array = []
    for actual_object in objects:
        var selected_id := str(actual_object.get("id",""))
        canvas.call("set_selected_object",selected_id)
        await _settle(2)
        await RenderingServer.frame_post_draw
        var selected_view: Dictionary = canvas.call("current_view_snapshot")
        var info: Dictionary = selected_view.get("selected_info",{})
        var info_rect: Dictionary = info.get("rect",{})
        var selected_matches: Array = selected_view.get("objects",[]).filter(func(o): return str(o.get("id",""))==selected_id)
        var selected_geometry: Array = selected_view.get("object_layout",{}).get("objects",[]).filter(func(o): return str(o.get("id",""))==selected_id)
        var expected := str(actual_object.get("label","")).strip_edges()
        _check(str(selected_view.get("selected_object_id",""))==selected_id and bool(info.get("visible",false)) and str(info.get("object_id",""))==selected_id,scenario+" actual selected object/card identity: "+selected_id)
        _check(not expected.is_empty() and str(info.get("title",""))==expected,scenario+" actual selected title retains source label: "+selected_id)
        _check(selected_matches.size()==1 and selected_geometry.size()==1 and float(info_rect.get("w",0))>0 and float(info_rect.get("h",0))>0,scenario+" selected geometry/card positive rectangle: "+selected_id)
        var image_name := scenario+"_selected_"+str(evidence.size()).pad_zeros(2)+".png"
        if evidence.is_empty() or not selected_id.is_empty():
            root.get_texture().get_image().save_png(out_dir.path_join(image_name))
        else:
            image_name = ""
        evidence.append({"id":selected_id,"expected_title":expected,"actual_selected_info":info,"actual_geometry":selected_geometry,"capture_clock":selected_view["scene_animation_time"],"capture_process_frame":Engine.get_process_frames(),"png":image_name})
    canvas.call("set_selected_object","")
    await _settle(2)
    return evidence

func _comic_diagnostic(snapshot: Dictionary,name_value: String) -> Dictionary:
    var viewport := SubViewport.new()
    viewport.size = Vector2i(1800,860)
    viewport.disable_3d = true
    viewport.transparent_bg = true
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    root.add_child(viewport)
    var canvas: Control = DiagnosticCanvasScript.new()
    canvas.size = Vector2(1800,860)
    viewport.add_child(canvas)
    canvas.call("render_environment_snapshot",snapshot)
    await _settle()
    var arrival := await _arrivals(canvas)
    await RenderingServer.frame_post_draw
    var view: Dictionary = canvas.call("current_view_snapshot")
    var matching: Array = view.get("objects",[]).filter(func(o): return str(o.get("id",""))=="environment_layer:ambient")
    var geom: Array = view.get("object_layout",{}).get("objects",[]).filter(func(o): return str(o.get("id",""))=="environment_layer:ambient")
    _check(str(view.get("environment_id",""))=="punchline_club",name_value+" diagnostic source public dispatch")
    _check(matching.size()==1 and geom.size()==1,name_value+" diagnostic actual ambient object available")
    var png := name_value+"_comic_body_DIAGNOSTIC_transparent_1800x860.png"
    viewport.get_texture().get_image().save_png(out_dir.path_join(png))
    var result := {"scope":"DIAGNOSTIC ONLY: actual unchanged production snapshot rendered by a canvas subclass that calls the unchanged production body painter ONLY for environment_layer:ambient at its natural actual coordinates. Transparent; no room background, labels, fake placement, asset/model injection, or full-context proof. Actual context PNG is separate.","objects":matching,"geometry":geom,"arrival":arrival,"png":png,"capture_clock":view.get("scene_animation_time"),"capture_process_frame":Engine.get_process_frames()}
    viewport.free()
    return result
