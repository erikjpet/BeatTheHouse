extends "res://scripts/ui/pixel_scene_canvas.gd"
# Diagnostic-only transparent rendering of the actual snapshot's ambient object.
# No objects, positions, model fields, labels or production scripts are changed.
func _draw() -> void:
    for value in _active_scene_objects():
        if str(value.get("id",""))=="environment_layer:ambient":
            _draw_scene_object_body(value)
