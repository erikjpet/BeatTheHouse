extends RefCounted

# Orchestrates environment interaction records across sealed base geometry,
# scenario projection, dynamic hooks, services, games, homes, and travel exits.

const JsonCoerceScript := preload("res://scripts/core/json_coerce.gd")

const ScenarioSequenceSchemaScript := preload("res://scripts/core/scenario_sequence_schema.gd")
const ScenarioSemanticViewModelScript := preload("res://scripts/ui/scenario_semantic_view_model.gd")
const EnvironmentPlacementScript := preload("res://scripts/core/environment_placement.gd")
const EnvironmentInstanceScript := preload("res://scripts/core/environment_instance.gd")
const EnvironmentObjectManifestScript := preload("res://scripts/core/environment_object_manifest.gd")
const EnvironmentSlotBinderScript := preload("res://scripts/core/environment_slot_binder.gd")
const RoomPresentationPublicationScript := preload("res://scripts/core/room_presentation_publication.gd")
const CharacterOfferModelScript := preload("res://scripts/core/character_offer_model.gd")

const LIVE_MEMBERSHIP_OBJECT_TYPES := ["event", "service", "lender"]
const LIVE_PRESENTATION_FIELDS := [
	"visual_type", "short_description", "identity_summary", "presence",
	"status_summary", "effect_summary", "impact_summary", "risk_summary",
	"cost_summary", "choice_summary", "classification_summary",
	"attribute_badges", "visual_key", "prop", "surface", "icon_key",
	"asset_path", "icon_sprite", "character_actor",
]
const LIVE_AVAILABILITY_ACTION_FIELDS := [
	"interactive", "decorative", "enabled", "disabled_reason", "action_summary",
	"available_actions", "inline_actions", "confirm_action_id", "state_badge",
	"non_color_state",
]
const LIVE_RENDER_FIELDS := [
	"visible", "presentation_required", "presentation_mode", "hovered", "focused", "selected",
]
const LIVE_SLOT_VISUAL_STATE_FIELDS := [
	"machine_family", "machine_format", "machine_key", "cabinet_variant_id",
	"cabinet_identity", "cabinet_title", "cabinet_material", "cabinet_topper_style",
	"cabinet_motion_style", "cabinet_background_path", "cabinet_palette", "feature_name",
	"pay_model", "reel_count", "row_count", "last_classification", "last_payout",
	"free_spins", "active_bonus_family", "slot_preview",
]
const LIVE_SLOT_RUNTIME_STATE_FIELDS := [
	"active", "status_label", "status_summary", "spin_count",
	"slot_autoplay_active", "slot_bonus_active", "slot_pending_feature",
	"slot_pending_feature_alert", "slot_bonus_family", "slot_feature_audio_cue",
	"slot_feature_audio_volume_db", "slot_free_spins", "slot_last_payout",
	"slot_last_classification", "slot_preview_phase", "slot_preview_caption",
	"slot_nudge_chain_active",
]


static func _service_options_with_exact_hosts(options: Array, action_hosts: Dictionary) -> Array:
	var result: Array = []
	for option_value in options:
		if typeof(option_value) != TYPE_DICTIONARY:
			continue
		var option := _dict(option_value).duplicate(true)
		var service_id := str(option.get("id", "")).strip_edges()
		var object_id := "service:%s" % service_id
		if not service_id.is_empty() \
				and str(option.get("slot_binding_source_id", "")).strip_edges().is_empty() \
				and action_hosts.has(object_id):
			option["slot_binding_source_id"] = str(action_hosts.get(object_id, "")).strip_edges()
		result.append(option)
	return result


static func _event_option_with_exact_host(option_value: Dictionary, action_hosts: Dictionary) -> Dictionary:
	var option := option_value.duplicate(true)
	var event_id := str(option.get("id", "")).strip_edges()
	var object_id := "event:%s" % event_id
	if not event_id.is_empty() and action_hosts.has(object_id):
		option["slot_binding_source_id"] = str(action_hosts.get(object_id, "")).strip_edges()
	else:
		# Event definitions document their canonical scenario host, but that
		# relationship is valid only while the matching exact layout is active. A
		# deliberately pre-seeded/standalone event keeps its ordinary event slot.
		option.erase("slot_binding_source_id")
	return option


static func interactable_object_view_list(host: Variant) -> Array:
	# Meta fixtures are profile projections and do not use run-room publication.
	if host._is_meta_session():
		return host._meta_interactable_object_view_list()
	# The owner refresh publishes this detached catalog. Looking it up cannot
	# synchronize runtime producers, finalize semantics or repair physical state.
	return host.room_catalog_snapshot()


static func prepare_room_catalog_at_boundary(host: Variant) -> Array:
	if host.run_state == null or host.library == null:
		return []
	if host._is_meta_session():
		return host._meta_interactable_object_view_list()
	var publication: Dictionary = host.run_state.room_presentation_snapshot()
	if publication.is_empty():
		return _fail_closed_room_records([], "Room presentation awaits its state boundary.")
	var environment := _dict(publication.get("environment", {}))
	var proof := _dict(publication.get("proof", {}))
	var live := _join_object_manifest(_gather_live_records(host), environment, true, proof)
	live = _attach_delivery_handoff_to_contact(host, live)
	live = _attach_action_only_records(live, _dict(EnvironmentPlacementScript.surface_map(environment).get("scenario_instance_action_host_ids", {})))
	var finalized := _dict(publication.get("finalized", {}))
	var result := live
	if not bool(finalized.get("inactive", true)):
		# Authenticate the complete immutable baseline first. Filtering a consumed
		# clerk/contact here makes the sealed-coverage validator reject every room
		# control. restore_live_presentation_fields below already suppresses resolved
		# ordinary events against the committed journal, after strict validation.
		var sealed := _array(finalized.get("records", []))
		var projected := project_finalized_sequence_interaction_result(sealed, finalized)
		if not bool(projected.get("ok", false)):
			return _fail_closed_room_records(live, "Committed room projection is invalid.")
		result = restore_live_presentation_fields(_array(projected.get("records", [])), live, _array(environment.get("resolved_event_ids", [])))
		result = append_unsealed_live_records(result, live, sealed, environment)
	result = _join_object_manifest(result, environment, false, proof)
	return _attach_action_only_records(_attach_delivery_handoff_to_contact(host, result))


static func _gather_live_records(host: Variant) -> Array:
	var failed = host._run_failed_without_recovery()
	var failed_reason = host._pressure_status_text(host._run_pressure_view())
	if failed_reason.strip_edges().is_empty():
		failed_reason = "Run failed."
	var game_sources: Array = []
	var game_ids = JsonCoerceScript._raw_string_array(host.run_state.current_environment.get("game_ids", []))
	for index in range(game_ids.size()):
		var game_id := str(game_ids[index])
		game_sources.append({
			"id": game_id,
			"index": index,
			"definition": host.library.game(game_id),
			"runtime_state": host._environment_game_runtime_state(game_id),
			"object_state": host._environment_game_object_state(game_id),
			"fixture_object_states": host._environment_game_fixture_object_states(game_id),
		})
	var before_travel_objects: Array = []
	var all_event_options: Array = host._eligible_event_option_view_list()
	before_travel_objects.append_array(host._game_hook_interactable_objects())
	before_travel_objects.append_array(host._home_interactable_objects())
	before_travel_objects.append_array(casino_spatial_interactable_objects(host))
	before_travel_objects.append_array(environment_layer_interactable_objects(host))
	before_travel_objects.append_array(numbers_interactable_objects(host))
	before_travel_objects.append_array(crew_presence_interactable_objects(host, all_event_options))
	var scenario_action_hosts := _dict(
		EnvironmentPlacementScript.surface_map(host.run_state.current_environment).get(
			"scenario_instance_action_host_ids", {}
		)
	)
	var after_travel_objects: Array = []
	var room_return_object = host._parent_home_return_interactable_object()
	if not room_return_object.is_empty():
		after_travel_objects.append(room_return_object)
	var service_options := _service_options_with_exact_hosts(
		host._service_hook_view_list(), scenario_action_hosts
	)
	after_travel_objects.append_array(
		host._hook_interactable_objects(host.CONTEXT_MODE_SERVICE, service_options)
	)
	after_travel_objects.append_array(host._hook_interactable_objects(host.CONTEXT_MODE_LENDER, host._lender_hook_view_list()))
	var event_options: Array = []
	var contact_event_ids: Array = []
	for presence_value in JsonCoerceScript._copy_array(host.run_state.current_environment.get("crew_presence", [])):
		if typeof(presence_value) == TYPE_DICTIONARY:
			var contact_event_id := str((presence_value as Dictionary).get("contact_event_id", "")).strip_edges()
			if not contact_event_id.is_empty():
				contact_event_ids.append(contact_event_id)
	for event_value in all_event_options:
		if typeof(event_value) != TYPE_DICTIONARY:
			continue
		var event_option := _event_option_with_exact_host(
			event_value as Dictionary,
			scenario_action_hosts
		)
		var event_id := str(event_option.get("id", ""))
		if event_id != "numbers_desk" and not contact_event_ids.has(event_id):
			event_options.append(event_option)
	var travel_choices = host._travel_choice_view_list()
	var delivery_occupied := before_travel_objects + after_travel_objects
	var layout: Dictionary = host._current_environment_layout()
	var game_fixture_counts := _dict(layout.get("game_fixture_counts", {}))
	var game_layout_index := 0
	for game_source_value in game_sources:
		var game_source: Dictionary = game_source_value
		var game_id := str(game_source.get("id", ""))
		var fixture_count := maxi(1, int(game_fixture_counts.get(game_id, 1)))
		for fixture_index in range(fixture_count):
			var game_object_id := "game:%s" % game_id if fixture_index == 0 else "game:%s:%d" % [game_id, fixture_index + 1]
			delivery_occupied.append({"focus_rect": host._interaction_rect_for_object(game_object_id, host.CONTEXT_MODE_GAME, game_layout_index)})
			game_layout_index += 1
	var event_layout_index := 0
	for event_value in event_options:
		if typeof(event_value) != TYPE_DICTIONARY:
			continue
		var event_id := str((event_value as Dictionary).get("id", ""))
		if event_id.is_empty():
			continue
		delivery_occupied.append({"focus_rect": host._interaction_rect_for_object("event:%s" % event_id, host.CONTEXT_MODE_EVENT, event_layout_index)})
		event_layout_index += 1
	var item_offers: Array = host._item_offer_view_list()
	var item_layout_index := 0
	for offer_value in item_offers:
		if typeof(offer_value) != TYPE_DICTIONARY:
			continue
		var offer: Dictionary = offer_value
		var item_id := str(offer.get("id", ""))
		if item_id.is_empty():
			continue
		var item_object_id := str(offer.get("object_id", "item:%s" % item_id))
		var resolved_item_index := int(offer.get("layout_index", item_layout_index))
		delivery_occupied.append({"focus_rect": host._interaction_rect_for_object(item_object_id, host.CONTEXT_MODE_ITEM, resolved_item_index)})
		item_layout_index += 1
	if host._shopkeeper_should_draw():
		delivery_occupied.append({"focus_rect": host._interaction_rect_for_object("shopkeeper:merchant", host.CONTEXT_MODE_SHOPKEEPER, 0)})
	for travel_index in range(travel_choices.size()):
		var travel_choice: Dictionary = travel_choices[travel_index] if typeof(travel_choices[travel_index]) == TYPE_DICTIONARY else {}
		delivery_occupied.append({
			"focus_rect": host._interaction_rect_for_object("travel:%s" % str(travel_choice.get("id", "")), host.CONTEXT_MODE_TRAVEL, travel_index),
		})
	before_travel_objects.append_array(delivery_interactable_objects(host, delivery_occupied))
	var result: Array = _array(host.EnvironmentInteractionViewModelScript.interactable_object_view_list(host.run_state, host.library, {
		"run_failed_without_recovery": failed,
		"failed_reason": failed_reason,
		"selection": {
			"hover_target_id": host.hover_target_id,
			"focus_target_id": host.focus_target_id,
			"selected_object_id": host.selected_object_id,
		},
		"layout": host._current_environment_layout(),
		"game_sources": game_sources,
		"event_options": event_options,
		"event_choice_summary": Callable(host, "_event_choice_list_summary"),
		"event_inline_actions": Callable(host, "_event_inline_response_actions"),
		"item_offers": item_offers,
		"shopkeeper_should_draw": host._shopkeeper_should_draw(),
		"shopkeeper_available": host._shopkeeper_available(),
		"shopkeeper_label": host._shopkeeper_label(),
		"shop_description": host._shop_description(),
		"before_travel_objects": before_travel_objects,
		"travel_choices": _authorized_room_exit_choices(host.run_state.current_environment, travel_choices),
		"direct_room_exit": host._local_parent_home_door_travel_choice(host._parent_home_parent_target_id()),
		"travel_risk_summary": Callable(host, "_travel_risk_summary"),
		"travel_preview_summary": Callable(host, "_travel_preview_summary"),
		"after_travel_objects": after_travel_objects,
		"closing_time_locked": host._closing_time_blocks_environment_actions(),
		"closing_time_reason": host._closing_time_disabled_reason(),
	}))
	return result


# Inspectable map routes may exist while no local exit is part of the committed
# room (for example every destination is currently closed). They must not mint
# an unsealed door and invalidate otherwise valid room geometry. The global map
# remains available; ordinary sealed exits and initial construction are unchanged.
static func _authorized_room_exit_choices(environment: Dictionary, choices: Array) -> Array:
	var rows := _array(_dict(environment.get("object_manifest", {})).get("rows", []))
	if rows.is_empty():
		return choices
	for value in rows:
		var row := _dict(value)
		var identity := str(row.get("presentation_object_id", row.get("object_id", "")))
		if identity == "travel:leave" and bool(row.get("active", true)) and bool(row.get("physical", true)):
			return choices
	return []


static func compile_room_catalog_at_boundary(host: Variant) -> Array:
	if host.run_state == null or host.library == null:
		return []
	if host._is_meta_session():
		return host._meta_interactable_object_view_list()
	# Some normal preparation helpers populate public scenario context. If the
	# persisted base envelope later fails authentication, restore the exact entry
	# environment so a read-only catalog request cannot partially mutate it.
	var entry_environment := JsonCoerceScript._copy_dict(host.run_state.current_environment)
	var preparation: Dictionary = _dict(host.run_state.scenario_prepare_semantic_finalization())
	var world_preparation: Dictionary = _dict(host.run_state.world_sequence_prepare_semantic_finalization())
	var result := _gather_live_records(host)
	var layout: Dictionary = host._current_environment_layout()
	var scenario_action_hosts := _dict(EnvironmentPlacementScript.surface_map(host.run_state.current_environment).get("scenario_instance_action_host_ids", {}))
	# A cold save intentionally omits renderer caches. Authenticate its durable
	# envelope for this provisional base pass. The existing production finalizers
	# rebuild scenario/world projections below, and the complete strict proof must
	# pass before the completed room can be published.
	var restoring_saved_projection := bool(entry_environment.get("scenario_restore_pending_trusted_rebuild", false)) \
			and not entry_environment.has("scenario_layout_audit") \
			and not entry_environment.has("scenario_render_snapshot") \
			and not entry_environment.has("scenario_sequence_projection")
	var initial_authority_proof := _object_manifest_join_proof(host.run_state.current_environment, not restoring_saved_projection)
	var initial_authority_errors := _array(initial_authority_proof.get("errors", []))
	if not bool(initial_authority_proof.get("ok", false)) or not initial_authority_errors.is_empty():
		# Preparing semantic projections is allowed to populate transient context,
		# but an unauthenticated object/slot envelope must never reach the binder.
		# Restore the exact entry state and expose only a non-spatial failure surface.
		host.run_state.set("current_environment", entry_environment)
		return _fail_closed_room_records(result, "object authority preflight failed")
	result = _join_object_manifest(result, host.run_state.current_environment, true, initial_authority_proof)
	# Action-only records used to consume a second, geometry-free UI plane. Fold
	# them into a visible person or fixture before the slot binder sees the live
	# inventory, so every record that survives this point owns room geometry.
	# Delivery handoffs must claim their destination person first so their
	# owner-scoped world-sequence token is not flattened into a generic attached
	# action by this pass.
	result = _attach_delivery_handoff_to_contact(host, result)
	# Exact scenario hosts are introduced by finalization below, so their action
	# aliases are intentionally hostless during this base-only pass. Defer only
	# those known pairs; the authoritative final pass still reports a missing host.
	result = _attach_action_only_records(result, scenario_action_hosts)
	# Seal the complete live base inventory against authored slots before scenario
	# composition. Runtime-only physical objects consume remaining compatible room
	# capacity; abstract controls retain their existing action-list presentation.
	var binding_environment: Dictionary = host.run_state.current_environment.duplicate(false)
	binding_environment["layout"] = layout
	var room_slot_occupancy: Dictionary = {}
	var record_binding := EnvironmentSlotBinderScript.bind_base_records(
		binding_environment,
		result,
		_dict(layout.get("slot_bindings", {})),
		room_slot_occupancy
	)
	if not bool(record_binding.get("ok", false)):
		var binding_failure := projection_failure_result(result, _array(record_binding.get("errors", [])))
		# The persisted base envelope failed before scenario composition. Present the
		# read-only failure surface, but do not let scenario rejection mutate or heal
		# the exact hostile/current environment being diagnosed.
		host.run_state.set("current_environment", entry_environment)
		return _fail_closed_room_records(
			_array(binding_failure.get("records", result)),
			"base slot binding failed: %s" % JSON.stringify(record_binding.get("errors", []))
		)
	result = _array(record_binding.get("records", result))
	# The exact fixed-slot result is semantic authority, not an ephemeral view
	# detail. Commit it atomically before any sequence stamps records so a real
	# late overflow has the same identity/membership/digest proof after reload.
	layout = commit_base_record_binding(host.run_state, layout, record_binding)
	var definition: Dictionary = _dict(host.run_state.scenario_sequence_definition())
	var scenario_active := ScenarioSequenceSchemaScript.is_sequence(definition)
	var world_sequence_active := bool(world_preparation.get("active", false))
	# Ordinary/no-scene rooms stop at the already authenticated base binding.
	# Only an active sequence needs a rollback copy plus scenario reservation data.
	var trusted_base_result := result.duplicate(true) if scenario_active or world_sequence_active else result
	var layout_context: Dictionary = {}
	if scenario_active or world_sequence_active:
		if host.environment_canvas != null and host.environment_canvas.has_method("scenario_layout_context"):
			layout_context = _dict(host.environment_canvas.call("scenario_layout_context"))
		# The sealed scenario inventory deliberately excludes runtime-only controls
		# such as Numbers, Crew arrivals, and live game clerks. They are already bound
		# to authored base slots above. Feed those immutable rectangles into scenario
		# validation so fixed/event/exit occupancy remains disjoint from the scenario
		# family; these records authorize no scenario behavior.
		layout_context["base_occupied_records"] = _base_layout_reservations(trusted_base_result, layout)
		layout_context["slot_occupancy"] = room_slot_occupancy.duplicate(true)
	if not bool(preparation.get("ok", false)):
		if restoring_saved_projection:
			return _fail_pending_restore(host, entry_environment, result, _array(preparation.get("errors", [])))
		var preparation_failure := projection_failure_result(result, _array(preparation.get("errors", [])))
		var committed_preparation_failure := committed_projection_status_result(host.run_state, preparation_failure, trusted_base_result)
		return _attach_action_only_records(_array(committed_preparation_failure.get("records", trusted_base_result)))
	if not bool(world_preparation.get("ok", false)):
		if restoring_saved_projection:
			return _fail_pending_restore(host, entry_environment, result, _array(world_preparation.get("errors", [])))
		var world_preparation_failure := projection_failure_result(result, _array(world_preparation.get("errors", [])))
		var committed_world_preparation_failure := committed_projection_status_result(host.run_state, world_preparation_failure, trusted_base_result)
		return _attach_action_only_records(_array(committed_world_preparation_failure.get("records", trusted_base_result)))
	if scenario_active:
		var finalized: Dictionary = _dict(host.run_state.scenario_finalize_installed_environment(host.library, layout_context))
		if not bool(finalized.get("ok", false)):
			if restoring_saved_projection:
				return _fail_pending_restore(host, entry_environment, result, _array(finalized.get("errors", [])))
			var finalization_failure := projection_failure_result(result, _array(finalized.get("errors", [])), _dict(finalized.get("layout_audit", {})))
			var committed_finalization_failure := committed_projection_status_result(host.run_state, finalization_failure, trusted_base_result)
			return _attach_action_only_records(_array(committed_finalization_failure.get("records", trusted_base_result)))
		var sealed_base_records: Array = _without_resolved_event_presence(JsonCoerceScript._copy_array(finalized.get("records", [])), _array(host.run_state.current_environment.get("resolved_event_ids", [])))
		result = sealed_base_records.duplicate(true)
		var projection_result := project_finalized_sequence_interaction_result(result, finalized)
		var committed_result := committed_projection_status_result(host.run_state, projection_result, trusted_base_result)
		result = _array(committed_result.get("records", trusted_base_result))
		if bool(committed_result.get("ok", false)):
			result = restore_live_presentation_fields(
				result,
				trusted_base_result,
				JsonCoerceScript._copy_array(host.run_state.current_environment.get("resolved_event_ids", []))
			)
			result = append_unsealed_live_records(result, trusted_base_result, sealed_base_records, host.run_state.current_environment)
	elif world_sequence_active:
		var world_finalized: Dictionary = _dict(host.run_state.world_sequence_finalize_base_semantics(result, host.library, layout_context))
		if not bool(world_finalized.get("ok", false)):
			if restoring_saved_projection:
				return _fail_pending_restore(host, entry_environment, result, _array(world_finalized.get("errors", [])))
			var world_finalization_failure := projection_failure_result(result, _array(world_finalized.get("errors", [])), _dict(world_finalized.get("layout_audit", {})))
			var committed_world_finalization_failure := committed_projection_status_result(host.run_state, world_finalization_failure, trusted_base_result)
			return _attach_action_only_records(_array(committed_world_finalization_failure.get("records", trusted_base_result)))
		var sealed_world_base_records := _without_resolved_event_presence(JsonCoerceScript._copy_array(world_finalized.get("records", [])), _array(host.run_state.current_environment.get("resolved_event_ids", [])))
		result = sealed_world_base_records.duplicate(true)
		var world_projection_result := project_finalized_sequence_interaction_result(result, world_finalized)
		var committed_world_result := committed_projection_status_result(host.run_state, world_projection_result, trusted_base_result)
		result = _array(committed_world_result.get("records", trusted_base_result))
		if bool(committed_world_result.get("ok", false)):
			result = restore_live_presentation_fields(
				result,
				trusted_base_result,
				JsonCoerceScript._copy_array(host.run_state.current_environment.get("resolved_event_ids", []))
			)
			result = append_unsealed_live_records(result, trusted_base_result, sealed_world_base_records, host.run_state.current_environment)
	else:
		host.run_state.current_environment.erase("scenario_sequence_lifecycle_errors")
		host.run_state.current_environment.erase("scenario_layout_audit")
		host.run_state.current_environment.erase("scenario_layout_authority_digest")
	var final_authority_proof := _object_manifest_join_proof(host.run_state.current_environment)
	var final_authority_errors := _array(final_authority_proof.get("errors", []))
	if not final_authority_errors.is_empty():
		host.run_state.set("current_environment", entry_environment)
		return _fail_closed_room_records(
			result,
			"final object authority preflight failed: %s" % JSON.stringify(final_authority_errors)
		)
	result = _join_object_manifest(result, host.run_state.current_environment, false, final_authority_proof)
	result = _attach_delivery_handoff_to_contact(host, result)
	result = _attach_action_only_records(result)
	return result


# Optional offers decorate an existing authenticated host after all room and
# scenario composition. They do not add physical members, replace existing
# services, or change the sealed manifest action/geometry authority.
static func _attach_character_offers(host: Variant, records: Array) -> Array:
	var result := records.duplicate(false)
	var offer_eligibility := func(offer: Dictionary) -> bool:
		return _character_offer_route_available(host, offer)
	for index in range(records.size()):
		var record := _dict(records[index])
		if not bool(record.get("manifest_physical", false)) \
				or not bool(record.get("visible", true)) \
				or str(record.get("presentation_mode", "room")) != "room":
			continue
		var offer: Dictionary = CharacterOfferModelScript.prepared_view_for_host(host.run_state, host.library, record, offer_eligibility)
		if offer.is_empty():
			continue
		record = record.duplicate(false)
		if bool(offer.get("free_home_ride", false)) or not str(offer.get("ride_target_node_id", "")).is_empty():
			var route_preview: Dictionary = host._character_offer_route_preview(offer)
			if route_preview.is_empty():
				continue
			offer["route_preview"] = route_preview
			var summary := str(offer.get("summary", "")).strip_edges()
			offer["summary"] = "%s%s%s" % [summary, "\n" if not summary.is_empty() else "", str(route_preview.get("summary", ""))]
		var offer_id := str(offer.get("id", ""))
		var action_key := "character_offer:%s" % offer_id
		var attached := _array(record.get("attached_room_actions", [])).duplicate(true)
		attached.append({
			"id": action_key,
			"key": action_key,
			"label": str(offer.get("label", "Review offer")),
			"enabled": true,
			"disabled_reason": "",
			"record": {"object_type": "character_offer", "source_id": offer_id, "offer": offer},
			"action": {"id": "review", "source_id": offer_id, "enabled": true},
		})
		record["attached_room_actions"] = attached
		# The canvas card consumes inline actions. Keep the attached descriptor as
		# live dispatch authority and expose its existing URI route on that card.
		var inline_actions := _array(record.get("inline_actions", [])).duplicate(true)
		inline_actions.append({
			"label": str(offer.get("label", "Review offer")),
			"enabled": true,
			"disabled": false,
			"text": "",
			"emit_object_id": "room_action:%s:%s" % [str(record.get("object_id", "")).uri_encode(), action_key.uri_encode()],
		})
		record["inline_actions"] = inline_actions
		record["character_offer"] = offer
		record["interactive"] = true
		record["decorative"] = false
		result[index] = record
	return result


# Route alternatives bind a character's saved decision only after their real
# destination is available. Other eligibility remains in the shared model.
static func _character_offer_route_available(host: Variant, offer: Dictionary) -> bool:
	if str(offer.get("ride_target_node_id", "")).is_empty():
		return true
	var preview: Dictionary = host._character_offer_route_preview(offer)
	return not preview.is_empty()


static func _fail_pending_restore(host: Variant, entry_environment: Dictionary, records: Array, errors: Array) -> Array:
	host.run_state.set("current_environment", entry_environment)
	return _fail_closed_room_records(records, "Saved room projection could not be rebuilt: %s" % JSON.stringify(errors))


static func _join_object_manifest(records: Array, environment: Dictionary, synthesize_missing_hosts: bool, validated_proof: Dictionary = {}) -> Array:
	var manifest := _dict(environment.get("object_manifest", {}))
	var manifest_rows := _array(manifest.get("rows", []))
	var proof := validated_proof if not validated_proof.is_empty() else _object_manifest_join_proof(environment)
	if not bool(proof.get("ok", false)) or not _array(proof.get("errors", [])).is_empty():
		return _fail_closed_room_records(records, "object manifest or slot authority is invalid")
	var resolved_event_ids: Dictionary = {}
	for event_id_value in _array(environment.get("resolved_event_ids", [])):
		var event_id := str(event_id_value).strip_edges()
		if not event_id.is_empty():
			resolved_event_ids[event_id] = true
	# The manifest seals membership, while the persisted binder envelope seals the
	# actual family-local slot chosen for dynamic rows. Reuse that authority only
	# after authenticating its map and binding digests; runtime scenario contacts
	# usually have no authored exact-slot preference in the manifest itself.
	var layout_authority := _dict(proof.get("layout_authority", {}))
	var trusted_bindings := _dict(layout_authority.get("slot_bindings", {}))
	var trusted_rects := _dict(layout_authority.get("object_rects", {}))
	var scenario_snapshot_present := EnvironmentObjectManifestScript.has_causal_scenario_renderer_snapshot(environment)
	var result := records.duplicate(true)
	var record_indices: Dictionary = {}
	var physical_manifest_ids: Dictionary = {}
	for index in range(result.size()):
		var record := _dict(result[index])
		var record_id := str(record.get("object_id", "")).strip_edges()
		if not record_id.is_empty() and not record_indices.has(record_id):
			record_indices[record_id] = index
	for row_value in manifest_rows:
		var row := _dict(row_value)
		if row.is_empty() or not bool(row.get("active", true)) or not bool(row.get("physical", true)):
			continue
		var family := str(row.get("family", row.get("slot_family", ""))).strip_edges().to_lower()
		if family not in ["fixed", "event", "scenario", "exit"]:
			continue
		if _manifest_row_is_resolved_event(row, family, resolved_event_ids):
			continue
		var manifest_object_id := str(row.get("instance_object_id", row.get("object_id", row.get("stable_object_id", "")))).strip_edges()
		var presentation_id := str(row.get("presentation_id", row.get("presentation_object_id", manifest_object_id))).strip_edges()
		if manifest_object_id.is_empty():
			manifest_object_id = presentation_id
		if presentation_id.is_empty():
			presentation_id = manifest_object_id
		if manifest_object_id.is_empty() or presentation_id.is_empty():
			continue
		# Manifest action ids describe actions owned by this physical host; they are
		# not globally unique. Remember every tangible identity up front so a shared
		# command id cannot turn one physical host into an alias of another.
		physical_manifest_ids[manifest_object_id] = true
		physical_manifest_ids[presentation_id] = true
		var host_index := int(record_indices.get(presentation_id, record_indices.get(manifest_object_id, -1)))
		var direct_delivery_contact := family == "scenario" \
				and str(row.get("spot_field", "")) == "runtime_object_manifest_entries" \
				and _array(row.get("action_ids", [])).has("delivery_handoff_direct")
		# Projected owners return from their authenticated composition below. A
		# saved event-family contact is not a new base event or fixture.
		if host_index < 0 and synthesize_missing_hosts \
				and str(row.get("source_kind", "")) != "scenario_projection" \
				and (family != "scenario" or direct_delivery_contact):
			var host := _manifest_host_record(row, manifest_object_id, presentation_id, family)
			result.append(host)
			host_index = result.size() - 1
			record_indices[presentation_id] = host_index
	if not synthesize_missing_hosts:
		# A finalized scenario projection may introduce the matching presentation
		# record after the first manifest pass. Refresh the index before annotating.
		record_indices.clear()
		for index in range(result.size()):
			var record := _dict(result[index])
			var record_id := str(record.get("object_id", "")).strip_edges()
			if not record_id.is_empty() and not record_indices.has(record_id):
				record_indices[record_id] = index
	var action_host_candidates_by_index: Dictionary = {}
	for row_value in manifest_rows:
		var row := _dict(row_value)
		if row.is_empty() or not bool(row.get("active", true)) or not bool(row.get("physical", true)):
			continue
		var family := str(row.get("family", row.get("slot_family", ""))).strip_edges().to_lower()
		if family not in ["fixed", "event", "scenario", "exit"]:
			continue
		if _manifest_row_is_resolved_event(row, family, resolved_event_ids):
			continue
		var manifest_object_id := str(row.get("instance_object_id", row.get("object_id", row.get("stable_object_id", "")))).strip_edges()
		var presentation_id := str(row.get("presentation_id", row.get("presentation_object_id", manifest_object_id))).strip_edges()
		if manifest_object_id.is_empty():
			manifest_object_id = presentation_id
		if presentation_id.is_empty():
			presentation_id = manifest_object_id
		var host_index := int(record_indices.get(presentation_id, record_indices.get(manifest_object_id, -1)))
		if host_index < 0:
			continue
		var trusted_row := row
		if family == "scenario" and str(row.get("spot_field", "")) != "runtime_object_manifest_entries" and not scenario_snapshot_present:
			trusted_row = row.duplicate(true)
			trusted_row["action_ids"] = []
		var host := _manifest_annotated_record(_dict(result[host_index]), trusted_row, manifest_object_id, presentation_id, family)
		host = _manifest_layout_annotated_record(host, trusted_bindings, trusted_rects, manifest_object_id, presentation_id, family)
		result[host_index] = host
		var action_ids := _array(trusted_row.get("action_ids", []))
		if action_ids.is_empty():
			continue
		for index in range(result.size()):
			if index == host_index:
				continue
			var source := _dict(result[index])
			# Exact scenario/service attachment is authored authority. The manifest
			# join may corroborate it, but must never replace it based on a command id
			# that another host can legitimately share (for example a refusal action).
			var existing_binding_source_id := str(source.get("slot_binding_source_id", "")).strip_edges()
			if not existing_binding_source_id.is_empty():
				if existing_binding_source_id == presentation_id:
					source["manifest_action_host_id"] = manifest_object_id
					result[index] = source
				continue
			var source_object_id := str(source.get("object_id", "")).strip_edges()
			if physical_manifest_ids.has(source_object_id):
				continue
			if not _record_matches_manifest_action(source, action_ids):
				continue
			var candidates := _dict(action_host_candidates_by_index.get(index, {}))
			candidates[presentation_id] = manifest_object_id
			action_host_candidates_by_index[index] = candidates
	# Inference is safe only for a nonphysical action alias with one manifest
	# owner. Ambiguous aliases remain unattached so the authoritative final pass
	# reports the content error instead of silently choosing whichever row ran last.
	for index_value in action_host_candidates_by_index.keys():
		var index := int(index_value)
		var candidates := _dict(action_host_candidates_by_index.get(index_value, {}))
		if candidates.size() != 1 or index < 0 or index >= result.size():
			continue
		var presentation_ids := candidates.keys()
		var presentation_id := str(presentation_ids[0])
		var source := _dict(result[index])
		source["slot_binding_source_id"] = presentation_id
		source["manifest_action_host_id"] = str(candidates.get(presentation_id, ""))
		result[index] = source
	return result


static func _object_manifest_join_errors(environment: Dictionary) -> Array:
	return _array(_object_manifest_join_proof(environment).get("errors", []))


static func _object_manifest_join_proof(environment: Dictionary, require_renderer_proofs: bool = true) -> Dictionary:
	return RoomPresentationPublicationScript._object_manifest_join_proof(environment, require_renderer_proofs)


static func _manifest_layout_correlation_errors(manifest_rows: Array, bindings: Dictionary) -> Array:
	return RoomPresentationPublicationScript._manifest_layout_correlation_errors(manifest_rows, bindings)


static func _manifest_layout_annotated_record(record: Dictionary, bindings: Dictionary, object_rects: Dictionary, manifest_object_id: String, presentation_id: String, family: String) -> Dictionary:
	var binding_id := presentation_id if bindings.has(presentation_id) else manifest_object_id if bindings.has(manifest_object_id) else ""
	if binding_id.is_empty():
		return record
	var binding := _dict(bindings.get(binding_id, {}))
	var manifest_exact_slot_id := str(record.get("manifest_exact_slot_id", "")).strip_edges()
	if str(binding.get("slot_family", "")) != family \
			or family != "exit" and str(binding.get("placement_class", "")) != str(record.get("placement_class", "")) \
			or family in ["fixed", "exit"] and not manifest_exact_slot_id.is_empty() \
					and str(binding.get("slot_id", "")) != manifest_exact_slot_id:
		return record
	var result := record.duplicate(true)
	if str(result.get("slot_id", "")).strip_edges().is_empty():
		result["slot_id"] = str(binding.get("slot_id", ""))
	if str(result.get("slot_family", "")).strip_edges().is_empty():
		result["slot_family"] = family
	if not result.has("presentation_mode"):
		result["presentation_mode"] = str(binding.get("presentation_mode", "overflow"))
	# This binding has passed the sealed family/class/slot join above. A live
	# view model's default false must not re-enable legacy geometry expansion.
	result["fixed_slot_geometry"] = true
	var rect := _dict(object_rects.get(binding_id, {}))
	if not rect.is_empty() and str(result.get("presentation_mode", "")) == "room" and not result.has("focus_rect"):
		if not result.has("normalized_rect"):
			result["normalized_rect"] = rect.duplicate(true)
		result["focus_rect"] = rect.duplicate(true)
		if not result.has("focus_point"):
			result["focus_point"] = {
			"x": float(rect.get("x", 0.0)) + float(rect.get("w", 0.0)) * 0.5,
			"y": float(rect.get("y", 0.0)) + float(rect.get("h", 0.0)) * 0.5,
			}
	return result


# A record without manifest/binder authority may remain actionable in the Room
# actions surface, but it may not claim physical room presentation. Clearing all
# geometry fields prevents downstream renderers from fabricating a rectangle.
static func _fail_closed_room_records(records: Array, reason: String) -> Array:
	var result: Array = []
	for record_value in records:
		var record := _dict(record_value)
		if record.is_empty():
			continue
		if str(record.get("presentation_mode", "room")) == "room" \
				or bool(record.get("manifest_physical", false)) \
				or EnvironmentSlotBinderScript.base_record_requires_room_slot(record):
			record["presentation_mode"] = "overflow"
			record["room_geometry_rejected"] = true
			record["room_geometry_rejection_reason"] = reason
			for field in [
				"slot_id", "slot_family", "exact_slot_id", "normalized_rect",
				"normalized_hit_rect", "focus_rect", "pixel_hit_bounds", "hit_bounds",
				"small_screen_rect", "label_rect", "small_screen_label_rect",
				"focus_point", "fixed_slot_geometry", "scenario_layout_resolved",
				"scenario_layout_authority_identity", "scenario_layout_authority_digest",
			]:
				record.erase(field)
		result.append(record)
	return result


static func _manifest_row_is_resolved_event(row: Dictionary, family: String, resolved_event_ids: Dictionary) -> bool:
	if family != "event" or resolved_event_ids.is_empty():
		return false
	var source_id := str(row.get("source_id", "")).strip_edges()
	if source_id.is_empty():
		var presentation_id := str(row.get("presentation_object_id", row.get("object_id", ""))).strip_edges()
		if presentation_id.begins_with("event:"):
			source_id = presentation_id.trim_prefix("event:")
	return not source_id.is_empty() and resolved_event_ids.has(source_id)


static func _manifest_host_record(row: Dictionary, manifest_object_id: String, presentation_id: String, family: String) -> Dictionary:
	var metadata := _dict(row.get("metadata", {}))
	var placement_class := str(row.get("placement_class", "")).strip_edges()
	var render_key := str(row.get("render_key", metadata.get("render_key", ""))).strip_edges()
	var person := EnvironmentPlacementScript.is_person_class(placement_class)
	var object_type := str(row.get("object_type", metadata.get("object_type", "character" if person else "fixture"))).strip_edges()
	var visual_type := str(row.get("visual_type", metadata.get("visual_type", "character" if person else "prop"))).strip_edges()
	var missing_event_host := object_type == "event" or presentation_id.begins_with("event:")
	var label := str(row.get("label", metadata.get("label", metadata.get("display_name", metadata.get("name", ""))))).strip_edges()
	if label.is_empty():
		label = _manifest_label(render_key if not render_key.is_empty() else presentation_id)
	var action_ids := _array(row.get("action_ids", []))
	return _manifest_annotated_record({
		"object_id": presentation_id,
		"object_type": object_type,
		"visual_type": visual_type,
		"source_id": str(row.get("source_id", manifest_object_id)),
		"label": label,
		"short_description": str(metadata.get("description", metadata.get("short_description", label))),
		"presence": "fixed" if family == "fixed" else family,
		# A manifest row seals where a physical host belongs; it is not live
		# gameplay authority for whether that host currently has an action. Missing
		# live event records (for example The House Calls before Rourke actually
		# calls) must therefore begin inert. Exact live/action records restore or
		# attach availability later in the same projection pass.
		"interactive": false if missing_event_host else not action_ids.is_empty(),
		"decorative": true if missing_event_host else action_ids.is_empty(),
		"enabled": false if missing_event_host else true,
		"disabled_reason": "No action is currently available." if missing_event_host else "",
		"visible": family != "event" if missing_event_host else true,
		"manifest_live_membership_missing_event": missing_event_host,
		"presentation_mode": "room",
		"slot_id": str(row.get("exact_slot_id", "")),
		"slot_family": family,
		"placement_class": placement_class,
		"visual_key": render_key,
		"prop": str(metadata.get("prop", render_key)),
		"icon_key": str(metadata.get("icon_key", render_key)),
		"asset_path": str(metadata.get("asset_path", "")),
		"available_actions": [],
		"inline_actions": [],
		"confirm_action_id": "",
	}, row, manifest_object_id, presentation_id, family)


static func _manifest_annotated_record(record: Dictionary, row: Dictionary, manifest_object_id: String, presentation_id: String, family: String) -> Dictionary:
	var result := record.duplicate(true)
	var metadata := _dict(row.get("metadata", {}))
	var render_key := str(row.get("render_key", metadata.get("render_key", ""))).strip_edges()
	result["manifest_object_id"] = manifest_object_id
	result["manifest_presentation_id"] = presentation_id
	result["manifest_family"] = family
	result["manifest_source_kind"] = str(row.get("source_kind", row.get("source_field", "")))
	result["manifest_source_id"] = str(row.get("source_id", ""))
	result["manifest_exact_slot_id"] = str(row.get("exact_slot_id", ""))
	result["manifest_required"] = bool(row.get("required", false))
	result["manifest_physical"] = true
	result["manifest_render_key"] = render_key
	result["manifest_action_ids"] = _array(row.get("action_ids", []))
	result["manifest_metadata"] = metadata.duplicate(true)
	result["physical"] = true
	result["exact_slot_id"] = str(row.get("exact_slot_id", ""))
	result["action_ids"] = _array(row.get("action_ids", []))
	result["render_key"] = render_key
	result["slot_family"] = family
	if str(result.get("slot_id", "")).strip_edges().is_empty():
		result["slot_id"] = str(row.get("exact_slot_id", ""))
	if str(result.get("placement_class", "")).strip_edges().is_empty():
		result["placement_class"] = str(row.get("placement_class", ""))
	if str(result.get("visual_key", "")).strip_edges().is_empty() and not render_key.is_empty():
		result["visual_key"] = render_key
	if str(result.get("prop", "")).strip_edges().is_empty() and not render_key.is_empty():
		result["prop"] = str(metadata.get("prop", render_key))
	return result


static func _record_matches_manifest_action(record: Dictionary, action_ids: Array) -> bool:
	var identities: Dictionary = {}
	for value in [record.get("object_id", ""), record.get("source_id", ""), record.get("confirm_action_id", "")]:
		var identity := str(value).strip_edges()
		if not identity.is_empty():
			identities[identity] = true
	for action_value in action_entries_for_record(record):
		var action := _dict(action_value)
		for value in [action.get("id", ""), action.get("emit_object_id", ""), action.get("source_id", "")]:
			var identity := str(value).strip_edges()
			if not identity.is_empty():
				identities[identity] = true
	for action_id_value in action_ids:
		if identities.has(str(action_id_value).strip_edges()):
			return true
	return false


static func _manifest_label(value: String) -> String:
	var clean := value.strip_edges()
	for separator in ["::", ":", "."]:
		if clean.contains(separator):
			clean = clean.get_slice(separator, clean.get_slice_count(separator) - 1)
	return clean.replace("_", " ").capitalize()


static func _attached_room_action_label(source: Dictionary, action: Dictionary) -> String:
	# Sal is one visible character hosting both the shop merchant and pawn-lender
	# aliases. Preserve that single physical object while naming the two services
	# by what they actually do instead of exposing generic Talk / Use actions.
	var object_id := str(source.get("object_id", "")).strip_edges()
	var binding_source_id := str(source.get("slot_binding_source_id", "")).strip_edges()
	if object_id == "lender:sals_pawn_counter":
		return "Pawn Items"
	if object_id == "shopkeeper:merchant" and binding_source_id == "staff:pawn_counter_sal":
		return "Sell Items"
	return str(action.get("label", action.get("id", "Use"))).strip_edges()


static func _attach_action_only_records(records: Array, deferred_exact_action_hosts: Dictionary = {}) -> Array:
	var room_records: Array = []
	var action_only: Array = []
	for value in records:
		var record := _dict(value)
		if record.is_empty():
			continue
		var binding_source_id := str(record.get("slot_binding_source_id", "")).strip_edges()
		if str(record.get("presentation_mode", "room")) == "overflow" \
				or not binding_source_id.is_empty() and binding_source_id != str(record.get("object_id", "")) \
				or not bool(record.get("manifest_physical", false)) and not EnvironmentSlotBinderScript.base_record_requires_room_slot(record):
			action_only.append(record)
		else:
			room_records.append(record)
	for source_value in action_only:
		var source := _dict(source_value)
		var actions := action_entries_for_record(source)
		if actions.is_empty():
			continue
		var target_index := _attached_action_target_index(room_records, source)
		if target_index < 0:
			# Scenario composition can retain a self-hosted visual record and also
			# surface its action alias during the same refresh. If the visible record
			# already carries every action, the alias has nothing left to attach and
			# is not an orphan. Keep warnings for genuinely missing hosts/actions.
			if _visible_room_record_already_carries_actions(room_records, source, actions):
				continue
			if not _missing_action_host_warning_deferred(source, deferred_exact_action_hosts):
				push_warning("Room action %s has no visible room object to attach to." % str(source.get("object_id", "unknown")))
			continue
		var target := _dict(room_records[target_index])
		var attached := _array(target.get("attached_room_actions", []))
		for action_value in actions:
			var action := _dict(action_value)
			var key := str(action.get("_attached_action_key", ""))
			var duplicate := false
			for existing_value in attached:
				if str(_dict(existing_value).get("key", "")) == key:
					duplicate = true
					break
			if duplicate:
				continue
			attached.append({
				"key": key,
				"label": _attached_room_action_label(source, action),
				"enabled": action_is_enabled(source, action),
				"disabled_reason": str(action.get("disabled_reason", source.get("disabled_reason", "Unavailable."))),
				"record": source.duplicate(true),
				"action": action.duplicate(true),
			})
		target["attached_room_actions"] = attached
		if not attached.is_empty():
			target["interactive"] = true
			target["decorative"] = false
			if bool(target.get("manifest_live_membership_missing_event", false)):
				target["visible"] = true
				var attached_enabled := false
				for attached_value in attached:
					if bool(_dict(attached_value).get("enabled", false)):
						attached_enabled = true
						break
				target["enabled"] = attached_enabled
				if attached_enabled:
					target["disabled_reason"] = ""
			room_records[target_index] = target
	return room_records


static func _visible_room_record_already_carries_actions(records: Array, source: Dictionary, source_actions: Array) -> bool:
	var source_object_id := str(source.get("object_id", "")).strip_edges()
	if source_object_id.is_empty() or source_actions.is_empty():
		return false
	var required_action_ids: Dictionary = {}
	for action_value in source_actions:
		var action := _dict(action_value)
		var action_id := str(action.get("emit_object_id", action.get("id", ""))).strip_edges()
		if not action_id.is_empty():
			required_action_ids[action_id] = true
	if required_action_ids.is_empty():
		return false
	for record_value in records:
		var record := _dict(record_value)
		if str(record.get("object_id", "")).strip_edges() != source_object_id \
				or not bool(record.get("visible", true)) \
				or str(record.get("presentation_mode", "room")) != "room":
			continue
		var carried_action_ids: Dictionary = {}
		for action_value in action_entries_for_record(record):
			var action := _dict(action_value)
			var action_id := str(action.get("emit_object_id", action.get("id", ""))).strip_edges()
			if not action_id.is_empty():
				carried_action_ids[action_id] = true
		var complete := true
		for action_id_value in required_action_ids.keys():
			if not carried_action_ids.has(action_id_value):
				complete = false
				break
		if complete:
			return true
	return false


static func _missing_action_host_warning_deferred(source: Dictionary, deferred_exact_action_hosts: Dictionary) -> bool:
	var action_object_id := str(source.get("object_id", "")).strip_edges()
	var binding_source_id := str(source.get("slot_binding_source_id", "")).strip_edges()
	if action_object_id.is_empty() or binding_source_id.is_empty() \
			or not deferred_exact_action_hosts.has(action_object_id):
		return false
	return str(deferred_exact_action_hosts.get(action_object_id, "")).strip_edges() == binding_source_id


static func _attached_action_target_index(records: Array, source: Dictionary) -> int:
	var explicit_source_id := str(source.get("slot_binding_source_id", "")).strip_edges()
	if not explicit_source_id.is_empty():
		# Authored action aliases are placement authority, not a preference. If
		# their tangible host is absent, do not silently move the action onto an
		# unrelated person or prop merely because that record scored next-best.
		for index in range(records.size()):
			var explicit_candidate := _dict(records[index])
			if bool(explicit_candidate.get("visible", true)) \
					and str(explicit_candidate.get("presentation_mode", "room")) == "room" \
					and str(explicit_candidate.get("object_id", "")).strip_edges() == explicit_source_id:
				return index
		return -1
	var best_index := -1
	var best_score := -100000
	var source_tokens := _identity_tokens(source)
	for index in range(records.size()):
		var candidate := _dict(records[index])
		if not bool(candidate.get("visible", true)) or str(candidate.get("presentation_mode", "room")) != "room":
			continue
		var score := 0
		var object_type := str(candidate.get("object_type", ""))
		var visual_type := str(candidate.get("visual_type", ""))
		if visual_type == "character" or object_type in ["dialogue", "shopkeeper", "character", "scenario_actor"]:
			score += 80
		elif object_type == "travel":
			score -= 60
		elif bool(candidate.get("interactive", true)):
			score += 20
		var candidate_tokens := _identity_tokens(candidate)
		for token_value in source_tokens:
			var token := str(token_value)
			if token.length() >= 4 and candidate_tokens.has(token):
				score += 25
		for relation_key in ["anchor_id", "zone_id", "source_id", "parent_id"]:
			var relation := str(source.get(relation_key, "")).strip_edges()
			if not relation.is_empty() and relation in [
				str(candidate.get("anchor_id", "")), str(candidate.get("zone_id", "")),
				str(candidate.get("source_id", "")), str(candidate.get("stable_object_id", "")),
			]:
				score += 120
		if score > best_score:
			best_score = score
			best_index = index
	return best_index


static func _identity_tokens(record: Dictionary) -> Array:
	var seen: Dictionary = {}
	for key in ["object_id", "stable_object_id", "source_id", "label", "anchor_id", "zone_id"]:
		var text := str(record.get(key, "")).to_lower()
		for token in text.replace("::", "_").replace(":", "_").replace("-", "_").replace(" ", "_").split("_", false):
			if token.length() >= 3:
				seen[token] = true
	return seen.keys()


static func action_entries_for_record(record: Dictionary) -> Array:
	var entries: Array = []
	var seen: Dictionary = {}
	for source_value in ["inline_actions", "scenario_sequence_actions", "available_actions"]:
		var source := str(source_value)
		var actions := _array(record.get(source, []))
		for index in range(actions.size()):
			var action := _dict(actions[index])
			if action.is_empty() or not bool(action.get("visible", true)) \
					or not bool(action.get("presentation_visible", true)) \
					or bool(action.get("hidden", false)) or bool(action.get("hidden_only", false)):
				continue
			var action_id := str(action.get("emit_object_id", action.get("id", ""))).strip_edges()
			if action_id.is_empty():
				continue
			var dispatch_identity := "%s:%s:%s:%s" % [
				str(record.get("object_id", "")),
				str(record.get("owner_namespace", record.get("scenario_owner_namespace", ""))),
				str(record.get("stable_object_id", record.get("scenario_stable_object_id", ""))),
				action_id,
			]
			if seen.has(dispatch_identity):
				continue
			seen[dispatch_identity] = true
			action = action.duplicate(true)
			action["_attached_source"] = source
			action["_attached_action_key"] = "%s:%s:%d:%s" % [
				str(record.get("object_id", "")), source, index,
				JSON.stringify([dispatch_identity, action]).sha256_text(),
			]
			entries.append(action)
	return entries


static func action_is_enabled(record: Dictionary, action: Dictionary) -> bool:
	return bool(record.get("enabled", true)) \
		and bool(record.get("interactive", record.get("enabled", true))) \
		and bool(action.get("enabled", true))


static func commit_base_record_binding(run_state: Variant, layout_value: Dictionary, record_binding: Dictionary) -> Dictionary:
	if run_state == null or not bool(record_binding.get("ok", false)):
		return layout_value
	var environment := _dict(run_state.get("current_environment"))
	# bind_base_records has already authenticated both the reconciled prior layout
	# and this exact candidate. Verify its compact synchronous handoff proof instead
	# of repeating both complete map/manifest/geometry validation passes here.
	var layout := _dict(record_binding.get("validated_candidate_layout", {}))
	var expected_proof := str(record_binding.get("validated_candidate_commit_proof", ""))
	if layout.is_empty() or expected_proof.length() != 64:
		return layout_value
	var candidate_environment := environment.duplicate(false)
	candidate_environment["layout"] = layout
	if EnvironmentSlotBinderScript.base_layout_commit_proof(candidate_environment) != expected_proof:
		return layout_value
	environment["layout"] = layout.duplicate(true)
	run_state.set("current_environment", environment)
	return layout


static func _base_layout_reservations(records: Array, layout: Dictionary = {}) -> Array:
	var by_id: Dictionary = {}
	var object_rects := _dict(layout.get("object_rects", {}))
	for value in records:
		var record := _dict(value)
		var object_id := str(record.get("object_id", "")).strip_edges()
		if object_id.is_empty() or by_id.has(object_id) or not bool(record.get("visible", true)) \
				or str(record.get("presentation_mode", "room")) == "overflow" \
				or not _runtime_layout_reservation_id(object_id):
			continue
		var label := str(record.get("label", "")).strip_edges()
		if label.length() > 64:
			label = label.substr(0, 64)
		var authoritative_rect: Variant = object_rects.get(object_id, record.get("focus_rect", record.get("normalized_rect", {})))
		by_id[object_id] = {
			"object_id": object_id,
			"focus_rect": _duplicate_variant(authoritative_rect),
			"label": label,
		}
	# Generated slots remain part of the ordinary environment plane while their
	# events are dormant. Reserve those authored positions so a scenario prop can
	# never occupy a chain-event slot that becomes live later in the same visit.
	if not object_rects.is_empty():
		for object_id_value in object_rects.keys():
			var object_id := str(object_id_value).strip_edges()
			if object_id.is_empty() or by_id.has(object_id):
				continue
			by_id[object_id] = {
				"object_id": object_id,
				"focus_rect": _duplicate_variant(object_rects.get(object_id_value, {})),
				"label": "",
			}
	var ids := by_id.keys()
	ids.sort()
	var result: Array = []
	for object_id_value in ids:
		result.append(by_id.get(object_id_value))
	return result


# Static games/events/services/routes are already supplied as sealed base
# geometry. Only UI/runtime families omitted from that authority need a second
# read-only occupancy record; including the whole live list double-counts base
# controls and can over-constrain a scenario refresh. Delivery is deliberately
# excluded: its placement pass consumes the sealed scenario plane, so it must
# not feed back and relocate that plane on every cargo-state refresh.
static func _runtime_layout_reservation_id(object_id: String) -> bool:
	for prefix in [
		"numbers:", "crew_presence:", "game_hook:", "dialogue:",
		"item:", "cage_gift_item:", "shopkeeper:", "casino_fixture:",
		"home_tenure:", "home_sleep:", "home_storage:", "home_container:",
		"environment_layer:",
	]:
		if object_id.begins_with(prefix):
			return true
	return false


# Consumed ordinary event-family presence has no live layout authority. Retain
# its immutable semantic identity, fixed fixtures, and scenario-owned lifetimes.
static func _without_resolved_event_presence(records: Array, resolved_event_ids: Array) -> Array:
	if resolved_event_ids.is_empty(): return records
	var result: Array = []
	for value in records:
		var record := _dict(value)
		if str(record.get("object_type", "")) == "event" \
				and str(record.get("slot_family", record.get("manifest_family", ""))) == "event" \
				and str(record.get("owner_namespace", "")) != "scenario" \
				and resolved_event_ids.has(str(record.get("source_id", ""))):
			continue
		result.append(value)
	return result


# Scenario seals own identity and geometry, while live producers own current
# event/service/lender membership and the closed presentation allowlists below.
# Arbitrary runtime state never crosses this boundary.
static func restore_live_presentation_fields(projected_records: Array, live_records: Array, resolved_event_ids: Array = []) -> Array:
	var live_by_id: Dictionary = {}
	for live_value in live_records:
		var live := _dict(live_value)
		var live_id := str(live.get("object_id", "")).strip_edges()
		if not live_id.is_empty():
			live_by_id[live_id] = live
	var result: Array = []
	for record_value in projected_records:
		var record := _dict(record_value).duplicate(true)
		var object_id := str(record.get("object_id", "")).strip_edges()
		var live := _dict(live_by_id.get(object_id, {}))
		var owner_namespace := str(record.get("owner_namespace", "base"))
		var resolved_base_event := owner_namespace != "scenario" \
			and str(record.get("object_type", "")) == "event" \
			and resolved_event_ids.has(str(record.get("source_id", "")).strip_edges())
		if resolved_base_event:
			continue
		# Sealed identity/geometry does not keep a gated or departed event alive.
		# An inert manifest placeholder is placement authority, not live presence.
		if owner_namespace != "scenario" and _requires_live_membership(record) \
				and (live.is_empty() or bool(live.get("manifest_live_membership_missing_event", false))):
			continue
		if not live.is_empty() and owner_namespace != "scenario":
			var scenario_augmented_inline_actions := _array(record.get("scenario_augmented_inline_actions", []))
			for field in LIVE_PRESENTATION_FIELDS + LIVE_AVAILABILITY_ACTION_FIELDS + LIVE_RENDER_FIELDS:
				if live.has(field):
					record[field] = _duplicate_variant(live.get(field))
			_restore_live_slot_visual_state(record, live)
			# Live base actions replace their stale sealed snapshot. Authenticated
			# scenario augments remain additive and must still resolve by token.
			if not scenario_augmented_inline_actions.is_empty():
				record["inline_actions"] = _base_inline_actions_with_scenario_augments(live, scenario_augmented_inline_actions)
		result.append(record)
	return result


# Scenario semantics may add role/state/appearance to a base fixture, but those
# generic fields cannot replace a Slot cabinet's public machine identity. Restore
# only the bounded environment projection emitted by SlotGame; arbitrary visual
# or runtime state remains outside the live-presentation allowlist.
static func _restore_live_slot_visual_state(record: Dictionary, live: Dictionary) -> void:
	if str(record.get("object_type", "")) != "game" or str(record.get("source_id", "")) != "slot":
		return
	var live_runtime := _dict(live.get("runtime_state", {}))
	var restored_runtime := _dict(record.get("runtime_state", {})).duplicate(true)
	for field in LIVE_SLOT_RUNTIME_STATE_FIELDS:
		if live_runtime.has(field):
			restored_runtime[field] = _duplicate_variant(live_runtime.get(field))
	if not restored_runtime.is_empty():
		record["runtime_state"] = restored_runtime
	var live_visual := _dict(live.get("visual_state", {}))
	if live_visual.is_empty():
		return
	var restored_visual := _dict(record.get("visual_state", {})).duplicate(true)
	for field in LIVE_SLOT_VISUAL_STATE_FIELDS:
		if live_visual.has(field):
			restored_visual[field] = _duplicate_variant(live_visual.get(field))
	record["visual_state"] = restored_visual


static func _requires_live_membership(record: Dictionary) -> bool:
	var object_type := str(record.get("object_type", "")).strip_edges()
	if not LIVE_MEMBERSHIP_OBJECT_TYPES.has(object_type):
		return false
	return str(record.get("object_id", "")).strip_edges().begins_with("%s:" % object_type)


# Static scenario authority owns every record it seals, including removals.
# Runtime-only controls (delivery pickup/stash, Numbers, Crew presence, and
# authored live game hooks) have separate RunState/ContentLibrary producers and
# are not legal scenario targets until they are explicitly sealed. Preserve
# those ordinary controls only when their presentation id was never admitted to
# the scenario base inventory; a sealed tombstone can therefore never be
# resurrected by the live presentation pass.
static func append_unsealed_live_records(projected_records: Array, live_records: Array, sealed_base_records: Array, environment: Dictionary = {}) -> Array:
	var result := projected_records.duplicate(true)
	var sealed_ids: Dictionary = {}
	var visible_ids: Dictionary = {}
	var appended_ids: Dictionary = {}
	for record_value in sealed_base_records:
		var record := _dict(record_value)
		var object_id := str(record.get("object_id", "")).strip_edges()
		if not object_id.is_empty(): sealed_ids[object_id] = true
	for record_value in result:
		var record := _dict(record_value)
		var object_id := str(record.get("object_id", "")).strip_edges()
		if not object_id.is_empty(): visible_ids[object_id] = true
	for record_value in live_records:
		if typeof(record_value) != TYPE_DICTIONARY: continue
		var record := (record_value as Dictionary).duplicate(true)
		var object_id := str(record.get("object_id", "")).strip_edges()
		if object_id.is_empty() or sealed_ids.has(object_id) or visible_ids.has(object_id): continue
		result.append(record)
		visible_ids[object_id] = true
		appended_ids[object_id] = true
	return _reconcile_unsealed_record_slots(result, appended_ids, environment)


# Live and sealed inventories are bound independently. A late traveler can
# therefore claim a slot already retained by a sealed contact. Keep every
# projected record fixed and reconcile only newcomers through the existing
# authored-slot guard, before the combined catalog reaches the Canvas guard.
static func _reconcile_unsealed_record_slots(records: Array, appended_ids: Dictionary, environment: Dictionary) -> Array:
	if environment.is_empty() or appended_ids.is_empty():
		return records
	var slots := EnvironmentPlacementScript.all_slots(EnvironmentPlacementScript.surface_map(environment))
	var slots_by_id: Dictionary = {}
	for value in slots:
		var slot := _dict(value)
		slots_by_id[str(slot.get("id", ""))] = slot
	var occupied: Dictionary = {}
	var newcomers: Dictionary = {}
	for value in records:
		var record := _dict(value)
		if not bool(record.get("visible", true)) or str(record.get("presentation_mode", "room")) != "room" \
				or not EnvironmentSlotBinderScript.base_record_requires_room_slot(record):
			continue
		var identity := str(record.get("object_id", ""))
		var slot_id := str(record.get("slot_id", ""))
		if identity.is_empty() or not slots_by_id.has(slot_id):
			return _fail_closed_room_records(records, "Composed room record has no authored slot.")
		if appended_ids.has(identity):
			var binding := EnvironmentSlotBinderScript._room_binding(identity, str(record.get("placement_class", "")), str(record.get("slot_family", "")), _dict(slots_by_id[slot_id]))
			var route := _dict(record.get("actor_route_stage", {}))
			if not route.is_empty(): binding["route"] = route.duplicate(true)
			newcomers[identity] = binding
			continue
		var claims: Array = [slot_id]
		var route := _dict(record.get("actor_route_stage", {}))
		for field in ["start_slot_id", "end_slot_id"]:
			var endpoint := str(route.get(field, ""))
			if not endpoint.is_empty() and not claims.has(endpoint): claims.append(endpoint)
		for claim in claims:
			if occupied.has(claim) and str(occupied[claim]) != identity:
				return _fail_closed_room_records(records, "Projected room records conflict on a sealed slot.")
			occupied[claim] = identity
	if newcomers.is_empty():
		return records
	# Reserve uncontested newcomer slots first. A displaced actor must not steal
	# the valid position of a later row; colliding newcomers resolve by stable ID.
	var ordered := newcomers.keys()
	ordered.sort()
	for identity in ordered:
		var slot_id := str(newcomers[identity].slot_id)
		if not occupied.has(slot_id): occupied[slot_id] = identity
	var guarded := EnvironmentSlotBinderScript.guard_unique_slot_bindings(newcomers, appended_ids, occupied, slots, "sealed/live room composition")
	if not _array(guarded.get("errors", [])).is_empty():
		return _fail_closed_room_records(records, "Live room slot allocation failed: %s" % JSON.stringify(guarded.errors))
	var bindings := _dict(guarded.get("slot_bindings", {}))
	for index in range(records.size()):
		var record := _dict(records[index])
		var identity := str(record.get("object_id", ""))
		if not bindings.has(identity): continue
		var binding := _dict(bindings[identity])
		if str(record.get("slot_id", "")) == str(binding.get("slot_id", "")): continue
		var rect := EnvironmentSlotBinderScript.rect_from_binding(binding)
		var normalized := EnvironmentSlotBinderScript.normalized_rect(rect)
		var label_rect := EnvironmentSlotBinderScript.normalized_rect(EnvironmentSlotBinderScript.label_rect_from_binding(binding, str(record.get("label", ""))))
		record["slot_id"] = str(binding.slot_id)
		record["slot_family"] = str(binding.slot_family)
		record["normalized_rect"] = normalized.duplicate(true)
		record["focus_rect"] = normalized.duplicate(true)
		record["small_screen_rect"] = EnvironmentSlotBinderScript.normalized_rect(EnvironmentSlotBinderScript.expanded_rect(rect))
		record["label_rect"] = label_rect.duplicate(true)
		record["small_screen_label_rect"] = label_rect.duplicate(true)
		record["focus_point"] = {"x": rect.get_center().x, "y": rect.get_center().y}
		record["fixed_slot_geometry"] = true
		records[index] = record
	return records


static func project_finalized_sequence_interaction_result(base_records: Array, finalized: Dictionary) -> Dictionary:
	if not bool(finalized.get("ok", false)):
		return projection_failure_result(base_records, _array(finalized.get("errors", [])), _dict(finalized.get("layout_audit", {})))
	var resolved_projection := _dict(finalized.get("projection", {}))
	var semantic_state := _dict(resolved_projection.get("semantic_state", {}))
	var authority := _dict(finalized.get("layout_authority", {}))
	var authority_digest := str(finalized.get("layout_authority_digest", ""))
	var layout_audit := _dict(finalized.get("layout_audit", {}))
	if authority.is_empty() and not bool(layout_audit.get("active", false)):
		if authority_digest.length() != 64 \
			or _layout_authority_digest(authority) != authority_digest \
			or str(semantic_state.get("layout_authority_digest", "")) != authority_digest \
			or str(layout_audit.get("authority_digest", "")) != authority_digest \
			or not bool(layout_audit.get("valid", false)) \
			or not bool(layout_audit.get("sealed_passive", false)) \
			or not _semantic_projection_coverage_errors(resolved_projection, authority).is_empty():
			return projection_failure_result(base_records, ["Passive scenario layout authority failed closed digest correlation."], layout_audit)
		return {
			"ok": true,
			"records": base_records.duplicate(true),
			"projection": resolved_projection,
			"errors": [],
			"warnings": _array(finalized.get("warnings", [])),
			"layout_authority": {},
			"layout_authority_digest": authority_digest,
			"layout_audit": layout_audit,
		}
	if authority_digest.length() != 64 \
		or _layout_authority_digest(authority) != authority_digest \
		or str(semantic_state.get("layout_authority_digest", "")) != authority_digest \
		or str(layout_audit.get("authority_digest", "")) != authority_digest \
		or not bool(layout_audit.get("valid", false)):
		return projection_failure_result(base_records, ["Finalized scenario layout authority failed digest correlation."], layout_audit)
	var actor_authority_errors := _finalized_actor_authority_errors(semantic_state, authority)
	if not actor_authority_errors.is_empty():
		return projection_failure_result(base_records, actor_authority_errors, layout_audit)
	var composed := _compose_projected_records(base_records, resolved_projection, authority, authority_digest)
	if not bool(composed.get("ok", false)):
		return projection_failure_result(base_records, _array(composed.get("errors", [])), _dict(finalized.get("layout_audit", {})))
	var composed_records := _array(composed.get("records", []))
	var coverage_errors := _projected_record_authority_errors(composed_records, authority, authority_digest, resolved_projection)
	if not coverage_errors.is_empty():
		return projection_failure_result(base_records, coverage_errors, _dict(finalized.get("layout_audit", {})))
	return {
		"ok": true,
		"records": composed_records,
		"projection": resolved_projection,
		"errors": [],
		"warnings": _array(finalized.get("warnings", [])),
		"layout_authority": authority,
		"layout_authority_digest": authority_digest,
		"layout_audit": _dict(finalized.get("layout_audit", {})),
	}


static func _layout_authority_digest(authority: Dictionary) -> String:
	var canonical: Array = []
	var identities := authority.keys()
	identities.sort()
	for identity_value in identities:
		canonical.append(_dict(authority.get(identity_value, {})))
	return JSON.stringify(canonical).sha256_text()


static func _finalized_actor_authority_errors(semantic_state: Dictionary, authority: Dictionary) -> Array:
	var errors: Array = []
	var actors := _dict(semantic_state.get("actors", {}))
	for identity_value in actors.keys():
		var identity := str(identity_value)
		var actor := _dict(actors.get(identity_value, {}))
		if actor.is_empty() or not bool(actor.get("present", true)):
			continue
		var sealed := _dict(authority.get(identity, {}))
		if str(sealed.get("visual_kind", "")) != "actor":
			errors.append("Finalized scenario actor %s lost its sealed route authority." % identity)
			continue
		var owned_identity := "%s::%s" % [str(actor.get("owner_namespace", "")), str(actor.get("stable_object_id", ""))]
		var semantic_presentation_id := identity if identity.begins_with("scenario::") else str(actor.get("presentation_object_id", sealed.get("presentation_object_id", "")))
		for pair in [
			["identity", owned_identity, identity],
			["presentation_object_id", semantic_presentation_id, sealed.get("presentation_object_id", "")],
			["normalized_hit_rect", actor.get("normalized_hit_rect", {}), sealed.get("normalized_hit_rect", {})],
			["small_screen_rect", actor.get("small_screen_rect", {}), sealed.get("small_screen_rect", {})],
			["label_rect", actor.get("label_rect", {}), sealed.get("label_rect", {})],
			["small_screen_label_rect", actor.get("small_screen_label_rect", {}), sealed.get("small_screen_label_rect", {})],
			["route_points", actor.get("route_points", []), sealed.get("actor_route_points", [])],
			["route_stage", actor.get("route_stage", {}), sealed.get("actor_route_stage", {})],
			["presentation_mode", actor.get("presentation_mode", "room"), sealed.get("presentation_mode", "room")],
			["slot_id", actor.get("slot_id", ""), sealed.get("slot_id", "")],
			["z_order", actor.get("z_order", -1), sealed.get("z_order", -2)],
		]:
			var values := pair as Array
			if JSON.stringify(values[1]) != JSON.stringify(values[2]):
				errors.append("Finalized scenario actor %s %s diverged from sealed canvas authority." % [identity, str(values[0])])
	return errors


static func projection_failure_result(base_records: Array, errors: Array, layout_audit: Dictionary = {}, _fallback_authority: Dictionary = {}, trusted_projection: Dictionary = {}) -> Dictionary:
	# Layout is presentation only. Preserve every ordinary control exactly and
	# expose actions from the already-committed semantic projection through the
	# geometry-free Room actions surface. Never turn a drawing failure into a
	# disabled room object or an input blocker.
	var clean_errors: Array = []
	for value in errors:
		var message := str(value).strip_edges()
		if not message.is_empty() and not clean_errors.has(message):
			clean_errors.append(message)
	if clean_errors.is_empty():
		clean_errors.append("Scenario presentation validation failed.")
	var records := _projection_action_overflow_records(base_records, trusted_projection)
	var audit := layout_audit.duplicate(true)
	audit["active"] = true
	audit["valid"] = false
	audit["error_count"] = clean_errors.size()
	audit["fallback_visible"] = false
	audit["action_overflow_count"] = maxi(0, records.size() - base_records.size())
	return {
		"ok": false,
		"records": records,
		"projection": trusted_projection.duplicate(true),
		"errors": clean_errors,
		"warnings": [],
		"layout_authority": {},
		"layout_authority_digest": "",
		"layout_audit": audit,
	}


static func _projection_action_overflow_records(base_records: Array, projection: Dictionary) -> Array:
	var records := base_records.duplicate(true)
	var interactions := _dict(_dict(projection.get("semantic_state", {})).get("interactions", {}))
	var identities := interactions.keys()
	identities.sort()
	var focus_order := records.size()
	for identity_value in identities:
		var interaction := _dict(interactions.get(identity_value, {}))
		if interaction.is_empty() or not bool(interaction.get("present", true)) or not bool(interaction.get("visible", true)):
			continue
		var owner := str(interaction.get("owner_namespace", "")).strip_edges()
		var stable_id := str(interaction.get("stable_object_id", "")).strip_edges()
		if owner.is_empty() or stable_id.is_empty():
			continue
		var world_owner_token := str(interaction.get("world_sequence_owner_token", "")).strip_edges()
		var actions: Array = []
		for action_value in _array(interaction.get("available_actions", [])):
			var action := _dict(action_value)
			if action.is_empty():
				continue
			# Scenario-owned identities own all of their actions. An augmented base
			# identity contributes only actions stamped by a scenario/world receipt;
			# its ordinary action remains on the untouched base record.
			if owner == "scenario" \
					or not world_owner_token.is_empty() \
					or not str(action.get("world_sequence_owner_token", "")).strip_edges().is_empty() \
					or not str(action.get("action_origin_receipt_key", "")).strip_edges().is_empty():
				actions.append(action.duplicate(true))
		if actions.is_empty():
			continue
		var object_id := "scenario_overflow:%s:%s" % [owner, stable_id]
		var enabled := bool(interaction.get("enabled", true))
		var record := {
			"object_id": object_id,
			"object_type": "scenario_sequence",
			"visual_type": "scenario_object",
			"source_id": str(interaction.get("source_id", stable_id)),
			"owner_namespace": owner,
			"stable_object_id": stable_id,
			"label": str(interaction.get("label", stable_id.replace("_", " ").capitalize())),
			"short_description": str(interaction.get("prompt", "Choose an action.")),
			"action_summary": str(interaction.get("prompt", "Choose an action.")),
			"state_label": str(interaction.get("state_label", "Available" if enabled else "Unavailable")),
			"state_badge": str(interaction.get("non_color_state", "available" if enabled else "unavailable")),
			"non_color_state": str(interaction.get("non_color_state", "available" if enabled else "unavailable")),
			"presentation_mode": "overflow",
			"presentation_required": true,
			"scenario_layout_resolved": false,
			"scenario_projection_overflow": true,
			"visible": true,
			"interactive": true,
			"decorative": false,
			"enabled": enabled,
			"disabled_reason": str(interaction.get("disabled_reason", "")) if not enabled else "",
			"focus_order": maxi(0, int(interaction.get("focus_order", focus_order))),
			"safe_exit": bool(interaction.get("safe_exit", false)),
			"alternate_exit": bool(interaction.get("alternate_exit", false)),
			"available_actions": actions.duplicate(true),
			"inline_actions": [],
			"scenario_sequence_actions": actions.duplicate(true),
			"confirm_action_id": str(_dict(actions[0]).get("id", "")),
		}
		if not world_owner_token.is_empty():
			record["world_sequence_owner_token"] = world_owner_token
		records.append(record)
		focus_order += 1
	return records


static func _compose_projected_records(base_records: Array, resolved_projection: Dictionary, authority: Dictionary, authority_digest: String) -> Dictionary:
	var errors: Array = []
	var semantic_state := _dict(resolved_projection.get("semantic_state", {}))
	var semantic_interactions := _dict(semantic_state.get("interactions", {}))
	var semantic_scene_objects := _dict(semantic_state.get("scene_objects", {}))
	var semantic_actors := _dict(semantic_state.get("actors", {}))
	var semantic_visuals := semantic_scene_objects.duplicate(true)
	for actor_identity_value in semantic_actors.keys():
		var actor_identity := str(actor_identity_value)
		if not semantic_visuals.has(actor_identity):
			semantic_visuals[actor_identity] = _dict(semantic_actors.get(actor_identity_value, {}))
	var projected: Array = []
	var consumed: Dictionary = {}
	var used_presentation_ids: Dictionary = {}
	var scenario_presentation_ids: Dictionary = {}
	for collection in [semantic_visuals, semantic_interactions]:
		for semantic_value in (collection as Dictionary).values():
			var semantic := _dict(semantic_value)
			if str(semantic.get("owner_namespace", "")) == "scenario":
				var owned_identity := "scenario::%s" % str(semantic.get("stable_object_id", ""))
				scenario_presentation_ids[owned_identity] = true
	for record_value in base_records:
		if typeof(record_value) != TYPE_DICTIONARY: continue
		var record := (record_value as Dictionary).duplicate(true)
		var identity := "%s::%s" % [str(record.get("owner_namespace", "")), str(record.get("stable_object_id", ""))]
		var presentation_id := str(record.get("object_id", ""))
		if scenario_presentation_ids.has(presentation_id) and identity != presentation_id: continue
		if not authority.has(identity):
			errors.append("Finalized base interaction %s lost its sealed layout authority." % identity)
			continue
		# Layout authority seals the entire final record set, including ordinary
		# controls the sequence does not otherwise rewrite. This prevents a stale
		# producer normalized_rect from outranking the validated focus_rect later.
		record = _apply_layout_authority(record, _dict(authority.get(identity, {})), authority_digest)
		var semantic_scene := _dict(semantic_visuals.get(identity, {}))
		var semantic_interaction := _dict(semantic_interactions.get(identity, {}))
		if semantic_visuals.has(identity) and not bool(semantic_scene.get("present", true)):
			consumed[identity] = true
			continue
		if semantic_interactions.has(identity) and not bool(semantic_interaction.get("present", true)):
			consumed[identity] = true
			continue
		if semantic_visuals.has(identity):
			if not authority.has(identity):
				errors.append("Projected visual %s lost its sealed layout authority." % identity)
				continue
			record = _merge_projected_visual(record, semantic_scene, _dict(authority.get(identity, {})), authority_digest)
		if not semantic_interactions.has(identity):
			if semantic_visuals.has(identity) and str(semantic_scene.get("owner_namespace", "")) == "scenario":
				# Scenario-owned decoration is read-only, not inert: selecting it must
				# still open its authored room-history description.
				record["interactive"] = true
				record["scenario_sequence_actions"] = []
			projected.append(record)
			used_presentation_ids[str(record.get("object_id", ""))] = true
			consumed[identity] = true
			continue
		if not authority.has(identity):
			errors.append("Projected interaction %s lost its exact sealed layout authority." % identity)
			continue
		var merged := _merge_projected_interaction(record, semantic_interaction, _dict(authority.get(identity, {})), authority_digest, int(resolved_projection.get("boundary_serial", 0)))
		projected.append(merged)
		used_presentation_ids[str(merged.get("object_id", ""))] = true
		consumed[identity] = true
	var pending: Array = []
	for identity_value in semantic_interactions.keys():
		var identity := str(identity_value)
		if consumed.has(identity): continue
		var semantic := _dict(semantic_interactions.get(identity, {}))
		if semantic.is_empty() or not bool(semantic.get("present", true)): continue
		if not authority.has(identity):
			errors.append("Projected interaction %s has no exact sealed visual authority." % identity)
			continue
		var visual_base: Dictionary = {}
		if semantic_visuals.has(identity):
			visual_base = _merge_projected_visual({}, _dict(semantic_visuals.get(identity, {})), _dict(authority.get(identity, {})), authority_digest)
		var merged := _merge_projected_interaction(visual_base, semantic, _dict(authority.get(identity, {})), authority_digest, int(resolved_projection.get("boundary_serial", 0)))
		var presentation_id := str(merged.get("object_id", ""))
		if used_presentation_ids.has(presentation_id): continue
		pending.append(merged)
		used_presentation_ids[presentation_id] = true
		consumed[identity] = true
	for identity_value in semantic_visuals.keys():
		var identity := str(identity_value)
		if consumed.has(identity): continue
		var semantic := _dict(semantic_visuals.get(identity, {}))
		if semantic.is_empty() or not bool(semantic.get("present", true)): continue
		if not authority.has(identity):
			errors.append("Projected visual %s has no exact sealed layout authority." % identity)
			continue
		var merged := _merge_projected_visual({}, semantic, _dict(authority.get(identity, {})), authority_digest)
		var presentation_id := str(merged.get("object_id", ""))
		if used_presentation_ids.has(presentation_id): continue
		pending.append(merged)
		used_presentation_ids[presentation_id] = true
	pending.sort_custom(func(a: Variant, b: Variant) -> bool:
		var left := _dict(a)
		var right := _dict(b)
		var left_order := int(left.get("focus_order", 0))
		var right_order := int(right.get("focus_order", 0))
		return left_order < right_order if left_order != right_order else str(left.get("object_id", "")) < str(right.get("object_id", ""))
	)
	projected.append_array(pending)
	return {"ok": errors.is_empty(), "records": projected if errors.is_empty() else [], "errors": errors}


static func _merge_projected_interaction(base: Dictionary, semantic: Dictionary, authority: Dictionary, authority_digest: String, boundary_serial: int = 0) -> Dictionary:
	var result := base.duplicate(true)
	var world_owner_token := str(semantic.get("world_sequence_owner_token", ""))
	var scenario_owned := str(semantic.get("owner_namespace", "")) == "scenario" or not world_owner_token.is_empty()
	var owned_identity := "%s::%s" % [str(semantic.get("owner_namespace", "")), str(semantic.get("stable_object_id", ""))]
	var presentation_id := owned_identity if scenario_owned else str(semantic.get("presentation_object_id", result.get("object_id", "")))
	result["object_id"] = presentation_id
	result["object_type"] = "scenario_sequence" if scenario_owned else str(result.get("object_type", "info"))
	result["visual_type"] = str(result.get("visual_type", "fixture"))
	result["source_id"] = str(semantic.get("source_id", result.get("source_id", semantic.get("stable_object_id", ""))))
	result["icon_key"] = _scenario_icon_key(semantic, result)
	result["owner_namespace"] = str(semantic.get("owner_namespace", ""))
	result["stable_object_id"] = str(semantic.get("stable_object_id", ""))
	if not world_owner_token.is_empty(): result["world_sequence_owner_token"] = world_owner_token
	result["label"] = str(semantic.get("label", result.get("label", presentation_id)))
	result["short_description"] = str(semantic.get("prompt", result.get("short_description", "")))
	result["action_summary"] = str(semantic.get("prompt", result.get("action_summary", "Choose an action.")))
	result["state_label"] = str(semantic.get("state_label", result.get("state_label", "Available")))
	result["enabled"] = bool(result.get("enabled", true)) and bool(semantic.get("enabled", false))
	result["interactive"] = true
	result["disabled_reason"] = str(semantic.get("disabled_reason", ""))
	result["non_color_state"] = str(semantic.get("non_color_state", result.get("non_color_state", "available")))
	result["focus_order"] = int(semantic.get("focus_order", result.get("focus_order", 0)))
	result["safe_exit"] = bool(semantic.get("safe_exit", result.get("safe_exit", false)))
	result["alternate_exit"] = bool(semantic.get("alternate_exit", result.get("alternate_exit", false)))
	result["input_actions"] = _array(semantic.get("input_actions", result.get("input_actions", [])))
	result = _apply_layout_authority(result, authority, authority_digest)
	var actions := _array(semantic.get("available_actions", []))
	result["available_actions"] = actions
	result["confirm_action_id"] = str(_dict(actions[0]).get("id", "")) if not actions.is_empty() else ""
	var sequence_actions: Array = []
	for action_value in actions:
		var action := _dict(action_value)
		if scenario_owned or not str(action.get("action_origin_receipt_key", "")).is_empty() or not str(action.get("world_sequence_owner_token", "")).is_empty(): sequence_actions.append(action)
	result["scenario_sequence_actions"] = sequence_actions
	# The floating mouse card uses inline choices for multiple commands; its
	# generic fallback exposes only the first action on an ordinary object.
	if str(semantic.get("owner_namespace", "")) == "scenario" and world_owner_token.is_empty() and actions.size() > 1:
		result["inline_actions"] = ScenarioSemanticViewModelScript.inline_actions_for_interaction(semantic, boundary_serial)
	elif not scenario_owned and world_owner_token.is_empty():
		# Abstract scenario tasks may be hosted by an ordinary event or fixture.
		# Keep their exact origin/proof, but publish their choices additively so
		# the live base refresh and floating card cannot reduce them to just Talk.
		var attached_actions: Array = []
		for action_value in sequence_actions:
			var action := _dict(action_value)
			if str(action.get("attached_owner_namespace", "")) == "scenario" \
					and not str(action.get("attached_stable_object_id", "")).is_empty() \
					and not str(action.get("action_origin_receipt_key", "")).is_empty():
				attached_actions.append(action)
		if not attached_actions.is_empty():
			var attached_interaction := semantic.duplicate(true)
			attached_interaction["available_actions"] = attached_actions
			var augments := ScenarioSemanticViewModelScript.inline_actions_for_interaction(attached_interaction, boundary_serial)
			if not augments.is_empty():
				result["scenario_augmented_inline_actions"] = augments
				result["inline_actions"] = _base_inline_actions_with_scenario_augments(base, augments)
	return result


static func _base_inline_actions_with_scenario_augments(base: Dictionary, augments: Array) -> Array:
	var own_inline: Array = []
	for value in _array(base.get("inline_actions", [])):
		var action := _dict(value)
		if bool(action.get("visible", true)) and bool(action.get("presentation_visible", true)) \
				and not bool(action.get("hidden", false)) and not bool(action.get("hidden_only", false)):
			own_inline.append(action)
	if own_inline.is_empty():
		# The ordinary floating card normally emits the host identity for its
		# primary action. Retain that same dispatch when adding inline tasks.
		for value in _array(base.get("available_actions", [])):
			var action := _dict(value)
			if action.is_empty() or not bool(action.get("visible", true)) or not bool(action.get("presentation_visible", true)) \
					or bool(action.get("hidden", false)) or bool(action.get("hidden_only", false)):
				continue
			var primary := action.duplicate(true)
			var emit_id := str(primary.get("emit_object_id", base.get("object_id", ""))).strip_edges()
			if emit_id.is_empty() or str(primary.get("label", "")).strip_edges().is_empty():
				continue
			primary["emit_object_id"] = emit_id
			primary["enabled"] = bool(base.get("enabled", true)) and bool(primary.get("enabled", true)) and not bool(primary.get("disabled", false))
			own_inline.append(primary)
			break
	var result: Array = []
	var seen: Dictionary = {}
	for value in own_inline + augments:
		var action := _dict(value)
		var dispatch_id := str(action.get("emit_object_id", action.get("id", ""))).strip_edges()
		if action.is_empty() or dispatch_id.is_empty() or seen.has(dispatch_id):
			continue
		seen[dispatch_id] = true
		result.append(action.duplicate(true))
	return result


static func _merge_projected_visual(base: Dictionary, semantic: Dictionary, authority: Dictionary, authority_digest: String) -> Dictionary:
	if str(semantic.get("semantic_kind", "")) == "actor":
		return _merge_projected_actor(base, semantic, authority, authority_digest)
	return _merge_projected_scene_object(base, semantic, authority, authority_digest)


static func _merge_projected_scene_object(base: Dictionary, semantic: Dictionary, authority: Dictionary, authority_digest: String) -> Dictionary:
	var result := base.duplicate(true)
	var owner := str(semantic.get("owner_namespace", result.get("owner_namespace", "")))
	var stable_id := str(semantic.get("stable_object_id", result.get("stable_object_id", "")))
	var owned_identity := "%s::%s" % [owner, stable_id]
	result["object_id"] = owned_identity if owner == "scenario" else str(result.get("object_id", semantic.get("presentation_object_id", owned_identity)))
	var object_type := str(result.get("object_type", "scenario_scene_object" if owner == "scenario" else "info"))
	if owner == "scenario" and object_type in ["", "scenario_object"]:
		object_type = "scenario_scene_object"
	result["object_type"] = object_type
	result["visual_type"] = "scenario_object" if owner == "scenario" else str(result.get("visual_type", "fixture"))
	result["source_id"] = str(result.get("source_id", stable_id))
	result["icon_key"] = _scenario_icon_key(semantic, result)
	result["owner_namespace"] = owner
	result["stable_object_id"] = stable_id
	var world_owner_token := str(semantic.get("world_sequence_owner_token", ""))
	if not world_owner_token.is_empty(): result["world_sequence_owner_token"] = world_owner_token
	result["label"] = str(semantic.get("label", result.get("label", stable_id)))
	result["short_description"] = _scenario_description(semantic, result, "Room fixture")
	result["action_summary"] = str(result.get("action_summary", "Inspect the room detail."))
	result["state_label"] = str(semantic.get("state", semantic.get("appearance", result.get("state_label", "Present"))))
	result["enabled"] = bool(semantic.get("enabled", result.get("enabled", true)))
	result["visible"] = bool(semantic.get("visible", result.get("visible", true)))
	# Scenario decorations are authored investigation targets even without a
	# command. A world-sequence aftermath prop can explicitly seal as inert once
	# its correlated action has gone away.
	result["interactive"] = bool(authority.get("presentation_interactive", owner == "scenario"))
	result["scenario_sequence_actions"] = _array(result.get("scenario_sequence_actions", []))
	result["anchor_id"] = str(semantic.get("anchor_id", result.get("anchor_id", "")))
	result["zone_id"] = str(semantic.get("zone_id", result.get("zone_id", "")))
	result["semantic_role"] = str(semantic.get("role", result.get("semantic_role", "prop")))
	result["semantic_state"] = str(semantic.get("state", result.get("semantic_state", "")))
	result["semantic_appearance"] = str(semantic.get("appearance", result.get("semantic_appearance", "")))
	result["role"] = result["semantic_role"]
	result["state"] = result["semantic_state"]
	result["appearance"] = result["semantic_appearance"]
	result["non_color_state"] = str(semantic.get("non_color_state", result.get("non_color_state", result.get("state_label", "Present"))))
	result["visual_state"] = {
		"role": result["semantic_role"],
		"state": result["semantic_state"],
		"appearance": result["semantic_appearance"],
	}
	return _apply_layout_authority(result, authority, authority_digest)


static func _merge_projected_actor(base: Dictionary, semantic: Dictionary, authority: Dictionary, authority_digest: String) -> Dictionary:
	var result := _merge_projected_scene_object(base, semantic, authority, authority_digest)
	var owner := str(semantic.get("owner_namespace", result.get("owner_namespace", "")))
	if base.is_empty() or str(result.get("object_type", "")) == "scenario_scene_object":
		result["object_type"] = "scenario_actor" if owner == "scenario" else "character"
	result["visual_type"] = "character"
	result["presence"] = "character"
	result["short_description"] = _scenario_description(semantic, result, "%s; %s" % [
		str(semantic.get("behavior", "idle")).replace("_", " ").capitalize(),
		str(semantic.get("pose", "idle")).replace("_", " ").capitalize(),
	])
	result["actor_id"] = str(semantic.get("actor_id", result.get("source_id", "")))
	result["source_id"] = result["actor_id"]
	result["actor_pose"] = str(semantic.get("pose", "idle"))
	result["actor_behavior"] = str(semantic.get("behavior", "idle"))
	result["pose"] = result["actor_pose"]
	result["behavior"] = result["actor_behavior"]
	result["actor_route_id"] = str(semantic.get("route_id", ""))
	result["authored_position_route_id"] = str(semantic.get("authored_position_route_id", ""))
	result["actor_route_points"] = _array(authority.get("actor_route_points", []))
	result["actor_route_stage"] = _dict(authority.get("actor_route_stage", {}))
	result["character_actor"] = ScenarioSemanticViewModelScript.actor_character_model(semantic)
	return result


static func _scenario_icon_key(semantic: Dictionary, base: Dictionary) -> String:
	var authored_icon := str(semantic.get("icon_key", "")).strip_edges()
	if not authored_icon.is_empty():
		return authored_icon
	var semantic_kind := str(semantic.get("semantic_kind", "scene_object")).strip_edges()
	var label := str(semantic.get("label", base.get("label", ""))).strip_edges()
	var role := str(semantic.get("role", base.get("semantic_role", base.get("role", "")))).strip_edges()
	return "%s %s %s" % ["scenario_actor" if semantic_kind == "actor" else "scenario_scene", label, role]


static func _scenario_description(semantic: Dictionary, base: Dictionary, fallback: String) -> String:
	var description := str(semantic.get("description", base.get("short_description", ""))).strip_edges()
	var variants := _dict(semantic.get("description_variants", {}))
	for key in [str(semantic.get("state", "")), str(semantic.get("appearance", "")), str(semantic.get("pose", "")), str(semantic.get("behavior", "")), str(semantic.get("anchor_id", "")), str(semantic.get("zone_id", ""))]:
		var variant := str(variants.get(key, "")).strip_edges()
		if not variant.is_empty():
			description = variant
			break
	return fallback if description.is_empty() else description


static func _apply_layout_authority(record: Dictionary, authority: Dictionary, authority_digest: String) -> Dictionary:
	var result := record.duplicate(true)
	var normalized := _dict(authority.get("normalized_hit_rect", {}))
	var small := _dict(authority.get("small_screen_rect", {}))
	var label_rect := _dict(authority.get("label_rect", {}))
	var small_label_rect := _dict(authority.get("small_screen_label_rect", {}))
	var final_rect := Rect2(float(normalized.get("x", 0.0)), float(normalized.get("y", 0.0)), float(normalized.get("w", 0.0)), float(normalized.get("h", 0.0)))
	# Every production geometry consumer receives the same sealed rectangle.
	# `normalized_rect` used to retain a producer's stale pre-sequence value and
	# silently outrank focus_rect on PixelSceneCanvas.
	result["object_id"] = str(authority.get("presentation_object_id", ""))
	result["normalized_rect"] = normalized.duplicate(true)
	result["focus_rect"] = final_rect
	result["small_screen_rect"] = small
	result["label_rect"] = label_rect
	result["small_screen_label_rect"] = small_label_rect
	result["fixed_slot_geometry"] = true
	result["actor_route_points"] = _array(authority.get("actor_route_points", []))
	result["actor_route_stage"] = _dict(authority.get("actor_route_stage", {}))
	result["scenario_z_order"] = int(authority.get("z_order", 0))
	result["placement_class"] = str(authority.get("placement_class", result.get("placement_class", "")))
	result["contact"] = str(authority.get("contact", result.get("contact", "")))
	result["presentation_mode"] = str(authority.get("presentation_mode", result.get("presentation_mode", "room")))
	result["slot_id"] = str(authority.get("slot_id", result.get("slot_id", "")))
	result["slot_family"] = str(authority.get("slot_family", result.get("slot_family", "")))
	result["scenario_layout_resolved"] = true
	result["scenario_layout_authority_identity"] = str(authority.get("identity", ""))
	result["scenario_layout_authority_digest"] = authority_digest
	return result


static func committed_projection_status_result(run_state: Variant, projection_result: Dictionary, trusted_base_records: Array) -> Dictionary:
	var audit := _dict(projection_result.get("layout_audit", {}))
	# Pull fallback behavior only from the committed runtime. A rejected or forged
	# projection can never mint an action, while a real presentation failure keeps
	# the exact semantic command authority that was already playable.
	var trusted_projection: Dictionary = _dict(run_state.scenario_sequence_projection()) if run_state != null and run_state.has_method("scenario_sequence_projection") else {}
	if bool(projection_result.get("ok", false)):
		var committed_digest := str(run_state.current_environment.get("scenario_layout_authority_digest", ""))
		var projected_digest := str(projection_result.get("layout_authority_digest", ""))
		var projected_authority := _dict(projection_result.get("layout_authority", {}))
		var passive_projection := projected_authority.is_empty() \
			and not bool(audit.get("active", false)) \
			and bool(audit.get("valid", false)) \
			and bool(audit.get("sealed_passive", false)) \
			and projected_digest.length() == 64 \
			and _layout_authority_digest(projected_authority) == projected_digest
		var integrity_errors: Array = []
		if not passive_projection:
			integrity_errors = _projected_record_authority_errors(
				_array(projection_result.get("records", [])),
				projected_authority,
				projected_digest,
				_dict(projection_result.get("projection", {}))
			)
		var projected_semantics := _dict(_dict(projection_result.get("projection", {})).get("semantic_state", {}))
		var committed_semantics := _dict(_dict(run_state.current_environment.get("scenario_sequence_projection", {})).get("semantic_state", {}))
		if JSON.stringify(projected_semantics) != JSON.stringify(committed_semantics):
			integrity_errors.append("Projected scenario semantics diverged from the exact committed semantic state.")
		if committed_digest == projected_digest and integrity_errors.is_empty():
			run_state.current_environment.erase("scenario_sequence_lifecycle_errors")
			return projection_result.duplicate(true)
		var mismatch_errors := integrity_errors
		if mismatch_errors.is_empty():
			mismatch_errors.append("Committed scenario layout authority diverged from the finalized production projection.")
		run_state.current_environment["scenario_sequence_lifecycle_errors"] = mismatch_errors.duplicate(true)
		return projection_failure_result(trusted_base_records, mismatch_errors, audit, {}, trusted_projection)
	var projection_errors := _array(projection_result.get("errors", []))
	if projection_errors.is_empty():
		projection_errors.append("Scenario production projection was rejected without diagnostics.")
	run_state.current_environment["scenario_sequence_lifecycle_errors"] = projection_errors.duplicate(true)
	return projection_failure_result(trusted_base_records, projection_errors, audit, {}, trusted_projection)


static func _projected_record_authority_errors(records: Array, authority: Dictionary, authority_digest: String, projection: Dictionary) -> Array:
	var errors: Array = []
	if authority_digest.length() != 64 or _layout_authority_digest(authority) != authority_digest:
		errors.append("Projected scenario records no longer match their sealed authority digest.")
		return errors
	errors.append_array(_semantic_projection_coverage_errors(projection, authority))
	var expected_records: Dictionary = {}
	var expected_presentation_ids: Dictionary = {}
	var authority_identities := authority.keys()
	authority_identities.sort()
	for identity_value in authority_identities:
		var identity := str(identity_value)
		var sealed := _dict(authority.get(identity_value, {}))
		if typeof(sealed.get("presentation_required")) != TYPE_BOOL or typeof(sealed.get("presentation_visible")) != TYPE_BOOL or typeof(sealed.get("presentation_interactive")) != TYPE_BOOL or typeof(sealed.get("semantic_scene_object_member")) != TYPE_BOOL or typeof(sealed.get("semantic_actor_member")) != TYPE_BOOL or typeof(sealed.get("semantic_interaction_member")) != TYPE_BOOL:
			errors.append("Sealed presentation %s has malformed exact-coverage flags." % identity)
			continue
		var required := bool(sealed.get("presentation_required", false))
		if not required:
			if bool(sealed.get("presentation_visible", false)) or bool(sealed.get("presentation_interactive", false)):
				errors.append("Sealed presentation tombstone %s remains visible or interactive." % identity)
			continue
		var presentation_object_id := str(sealed.get("presentation_object_id", ""))
		if presentation_object_id.is_empty() or expected_presentation_ids.has(presentation_object_id):
			errors.append("Required sealed presentation %s has an empty or aliased canvas identity." % identity)
			continue
		expected_records[identity] = presentation_object_id
		expected_presentation_ids[presentation_object_id] = identity
	var seen_identities: Dictionary = {}
	var seen_presentation_ids: Dictionary = {}
	for value in records:
		var record := _dict(value)
		var identity := str(record.get("scenario_layout_authority_identity", ""))
		var presentation_object_id := str(record.get("object_id", ""))
		var owned_identity := "%s::%s" % [str(record.get("owner_namespace", "")), str(record.get("stable_object_id", ""))]
		if typeof(record.get("scenario_layout_resolved")) != TYPE_BOOL or not bool(record.get("scenario_layout_resolved", false)) or identity.is_empty() or identity != owned_identity or not authority.has(identity) or str(record.get("scenario_layout_authority_digest", "")) != authority_digest:
			errors.append("Projected record %s lost its correlated sealed layout authority." % str(record.get("object_id", "")))
			continue
		if not expected_records.has(identity):
			errors.append("Projected record %s is extra or contradicts a sealed presentation tombstone." % presentation_object_id)
			continue
		if seen_identities.has(identity) or presentation_object_id.is_empty() or seen_presentation_ids.has(presentation_object_id):
			errors.append("Projected record %s aliases another sealed canvas identity." % presentation_object_id)
			continue
		seen_identities[identity] = true
		seen_presentation_ids[presentation_object_id] = true
		var sealed := _dict(authority.get(identity, {}))
		if typeof(record.get("visible", true)) != TYPE_BOOL or typeof(record.get("interactive", true)) != TYPE_BOOL:
			errors.append("Projected record %s has malformed canvas presence flags." % presentation_object_id)
		for pair in [
			["object_id", record.get("object_id", ""), sealed.get("presentation_object_id", "")],
			["normalized_rect", record.get("normalized_rect", {}), sealed.get("normalized_hit_rect", {})],
			["small_screen_rect", record.get("small_screen_rect", {}), sealed.get("small_screen_rect", {})],
			["label_rect", record.get("label_rect", {}), sealed.get("label_rect", {})],
			["small_screen_label_rect", record.get("small_screen_label_rect", {}), sealed.get("small_screen_label_rect", {})],
			["scenario_z_order", record.get("scenario_z_order", -1), sealed.get("z_order", -2)],
			["actor_route_points", record.get("actor_route_points", []), sealed.get("actor_route_points", [])],
			["actor_route_stage", record.get("actor_route_stage", {}), sealed.get("actor_route_stage", {})],
			["presentation_mode", record.get("presentation_mode", "room"), sealed.get("presentation_mode", "room")],
			["slot_id", record.get("slot_id", ""), sealed.get("slot_id", "")],
			["visible", record.get("visible", true), sealed.get("presentation_visible", false)],
			["interactive", record.get("interactive", true), sealed.get("presentation_interactive", false)],
		]:
			var values := pair as Array
			if JSON.stringify(values[1]) != JSON.stringify(values[2]):
				errors.append("Projected record %s %s diverged from sealed canvas authority." % [str(record.get("object_id", "")), str(values[0])])
	var missing_identities := expected_records.keys()
	missing_identities.sort()
	for identity_value in missing_identities:
		var identity := str(identity_value)
		if not seen_identities.has(identity):
			errors.append("Required sealed presentation %s (%s) is missing from projected records." % [identity, str(expected_records.get(identity, ""))])
	return errors


static func _semantic_projection_coverage_errors(projection: Dictionary, authority: Dictionary) -> Array:
	var errors: Array = []
	var semantic_state := _dict(projection.get("semantic_state", {}))
	var scenes := _dict(semantic_state.get("scene_objects", {}))
	var actors := _dict(semantic_state.get("actors", {}))
	var interactions := _dict(semantic_state.get("interactions", {}))
	var semantic_identities: Dictionary = {}
	for collection_value in [scenes, actors, interactions]:
		var collection := collection_value as Dictionary
		for identity_value in collection.keys():
			semantic_identities[str(identity_value)] = true
	var identities := semantic_identities.keys()
	identities.sort()
	for identity_value in identities:
		var identity := str(identity_value)
		var visual_entries: Array = []
		for collection_value in [scenes, actors]:
			var collection := collection_value as Dictionary
			if collection.has(identity):
				visual_entries.append(_dict(collection.get(identity, {})))
		if visual_entries.size() > 1:
			errors.append("Semantic identity %s has multiple finalized visual presence contracts." % identity)
		var visual := _dict(visual_entries[0]) if not visual_entries.is_empty() else {}
		var interaction := _dict(interactions.get(identity, {}))
		var presence_values: Dictionary = {}
		var presence_entries := visual_entries.duplicate(true)
		if not interaction.is_empty():
			presence_entries.append(interaction)
		for semantic_value in presence_entries:
			var semantic := _dict(semantic_value)
			var owned_identity := "%s::%s" % [str(semantic.get("owner_namespace", "")), str(semantic.get("stable_object_id", ""))]
			if owned_identity != identity:
				errors.append("Semantic coverage identity %s diverges from its finalized owner/stable identity." % identity)
			if typeof(semantic.get("present", true)) != TYPE_BOOL:
				errors.append("Semantic coverage identity %s has non-boolean presence." % identity)
			else:
				presence_values[bool(semantic.get("present", true))] = true
		# A tombstone in either finalized collection suppresses the shared base
		# canvas record. Exact collection membership below, plus the committed
		# semantic-state comparison at the public gate, authenticates the split.
		var required := not presence_values.has(false)
		if not authority.has(identity):
			errors.append("Semantic presentation %s has no sealed collection-membership authority." % identity)
			continue
		var sealed := _dict(authority.get(identity, {}))
		if required != bool(sealed.get("presentation_required", false)):
			errors.append("Semantic identity %s presence diverged from sealed required-record coverage." % identity)
		if not visual.is_empty() and required:
			if typeof(visual.get("visible", true)) != TYPE_BOOL or bool(visual.get("visible", true)) != bool(sealed.get("presentation_visible", false)):
				errors.append("Semantic visual %s visibility diverged from sealed canvas coverage." % identity)
		if not interaction.is_empty():
			var expected_interactive := required and bool(interaction.get("present", true))
			if expected_interactive != bool(sealed.get("presentation_interactive", false)):
				errors.append("Semantic interaction %s presence diverged from sealed canvas interactivity." % identity)
		elif not visual.is_empty() and str(visual.get("owner_namespace", "")) == "scenario" and required and not bool(sealed.get("presentation_interactive", false)):
			errors.append("Scenario visual %s lost its sealed read-only inspectability." % identity)
	var sealed_identities := authority.keys()
	sealed_identities.sort()
	for identity_value in sealed_identities:
		var identity := str(identity_value)
		var sealed := _dict(authority.get(identity_value, {}))
		for membership_value in [
			["scene-object", scenes.has(identity), bool(sealed.get("semantic_scene_object_member", false))],
			["actor", actors.has(identity), bool(sealed.get("semantic_actor_member", false))],
			["interaction", interactions.has(identity), bool(sealed.get("semantic_interaction_member", false))],
		]:
			var membership := membership_value as Array
			if bool(membership[1]) != bool(membership[2]):
				errors.append("Semantic %s collection membership for %s diverged from sealed coverage." % [str(membership[0]), identity])
	return errors


static func crew_presence_interactable_objects(host: Variant, event_options: Array = []) -> Array:
	var result: Array = []
	if host.run_state == null:
		return result
	var index := 0
	for value in JsonCoerceScript._copy_array(host.run_state.current_environment.get("crew_presence", [])):
		if typeof(value) != TYPE_DICTIONARY:
			continue
		var presence: Dictionary = value
		var member_id := str(presence.get("member_id", "")).strip_edges()
		var line := str(presence.get("line", "")).strip_edges()
		if member_id.is_empty() or line.is_empty():
			continue
		var contact_event_id := str(presence.get("contact_event_id", "")).strip_edges()
		var contact_event: Dictionary = {}
		for event_value in event_options:
			if typeof(event_value) == TYPE_DICTIONARY and str((event_value as Dictionary).get("id", "")) == contact_event_id:
				contact_event = event_value
				break
		var speaker_source: Dictionary = contact_event.get("speaker", {}) if typeof(contact_event.get("speaker", {})) == TYPE_DICTIONARY else {
			"role": "crew",
			"name": member_id.trim_prefix("crew_").capitalize(),
			"character_id": member_id,
			"voice_line_key": "favor_due",
		}
		var speaker: Dictionary = host._resolve_character_speaker(speaker_source, "crew_presence:%s" % member_id, "favor_due")
		var label := str(speaker.get("speaking_character_name", member_id.trim_prefix("crew_").capitalize()))
		var choices: Array = contact_event.get("choices", []) if typeof(contact_event.get("choices", [])) == TYPE_ARRAY else []
		var interactive := not contact_event_id.is_empty() and not choices.is_empty()
		var object_id := "event:%s" % contact_event_id if interactive else "crew_presence:%s" % member_id
		result.append(host._make_interactable_object({
			"object_id": object_id,
			"object_type": "event" if interactive else "dialogue",
			"visual_type": "character",
			"source_id": contact_event_id if interactive else member_id,
			"label": label,
			"short_description": line,
			"presence": "ambient",
			"interactive": interactive,
			"enabled": interactive,
			"disabled_reason": "" if interactive else line,
			"action_summary": str(contact_event.get("start_summary", line)) if interactive else line,
			"status_summary": str(presence.get("rank", "marker")).replace("_", " ").capitalize(),
			"visual_key": "crew_presence",
			"prop": "patron",
			"icon_key": "rowdy_regular",
			"character_actor": speaker,
			"available_actions": [{"id": "inspect_event_choices", "label": "Review responses"}] if interactive else [],
			"inline_actions": host._event_inline_response_actions(contact_event_id, choices) if interactive else [],
			"confirm_action_id": "inspect_event_choices" if interactive else "",
			"focus_rect": host._interaction_rect_for_object(object_id, host.CONTEXT_MODE_EVENT if interactive else "dialogue", index),
		}))
		index += 1
	return result


static func delivery_interactable_objects(host: Variant, _occupied_objects: Array = []) -> Array:
	if host.run_state == null:
		return []
	var result: Array = []
	var physical_interactions: Array = host.run_state.delivery_physical_interactions() if host.run_state.has_method("delivery_physical_interactions") else []
	for physical_index in range(physical_interactions.size()):
		var interaction: Dictionary = physical_interactions[physical_index]
		var verb := str(interaction.get("verb", ""))
		var package_action := str(interaction.get("host_kind", "")) == "package"
		var delivery_prop := "crate" if package_action else "street_sign"
		var object_id := str(interaction.get("object_id", "delivery:%s" % verb))
		var delivery_class := EnvironmentPlacementScript.classify(interaction, "scene_object", object_id, delivery_prop)
		# Runtime delivery membership is reconciled into a scenario-family binding
		# before this read. Consume that exact authority instead of calculating a
		# second rectangle from whatever happens to be occupied on this frame.
		var focus_rect: Rect2 = host._interaction_rect_for_object(object_id, host.CONTEXT_MODE_DELIVERY, physical_index)
		result.append(host._make_interactable_object({
			"object_id": object_id,
			"object_type": host.CONTEXT_MODE_DELIVERY,
			"visual_type": "prop",
			"source_id": verb,
			"label": str(interaction.get("label", verb.replace("_", " ").capitalize())),
			"short_description": str(interaction.get("message", "The route has a physical choice here.")),
			"presence": "fixture",
			"interactive": true,
			"enabled": true,
			"action_summary": str(interaction.get("message", "Act here.")),
			"status_summary": str(interaction.get("cargo_label", "Crew route")),
			"visual_key": "item" if package_action else "travel",
			"prop": delivery_prop,
			"icon_key": "item" if package_action else "travel",
			"available_actions": JsonCoerceScript._copy_array(interaction.get("actions", [])),
			"delivery_actions": JsonCoerceScript._copy_array(interaction.get("actions", [])),
			"confirm_action_id": "delivery_physical_action",
			"focus_rect": focus_rect,
			"placement_class": delivery_class,
		}))
	return result


static func _attach_delivery_handoff_to_contact(host: Variant, records: Array) -> Array:
	if host.run_state == null:
		return records
	var handoff := _dict(host.run_state.delivery_arrival_interaction())
	if handoff.is_empty():
		return records
	for record_value in records:
		var existing_contact := _dict(record_value)
		if bool(existing_contact.get("delivery_contact", false)) \
				and not str(existing_contact.get("world_sequence_owner_token", "")).strip_edges().is_empty():
			return records
	var handoff_index := -1
	for index in range(records.size()):
		var record := _dict(records[index])
		if str(record.get("object_id", "")) == "crew::package_handoff" and not _array(record.get("scenario_sequence_actions", [])).is_empty():
			handoff_index = index
			break
	var node_id := str(handoff.get("node_id", "")).strip_edges()
	var presentation_owner := ""
	if host.run_state.has_method("delivery_world_sequence_owner_for_presentation"):
		presentation_owner = str(host.run_state.delivery_world_sequence_owner_for_presentation(node_id)).strip_edges()
	# The first manifest pass occurs before a world sequence's scenario actor is
	# finalized. Do not borrow an ordinary NPC during that gap; the second pass
	# will transform the sole `crew::package_handoff` actor once it exists.
	if handoff_index < 0 and not presentation_owner.is_empty():
		return records
	var target := {}
	for target_value in _array(host.run_state.delivery_snapshot().get("targets", [])):
		var candidate_target := _dict(target_value)
		if str(candidate_target.get("node_id", "")) == node_id and str(candidate_target.get("status", "pending")) == "pending":
			target = candidate_target
			break
	var contact_label := str(target.get("contact_label", "the marked contact"))
	var result := records.duplicate(true)
	var contact_index := -1
	var contact_score := -1
	var direct_handoff_id := str(handoff.get("object_id", "delivery:handoff:%s" % node_id)).strip_edges()
	# Direct jobs now own a reconciled runtime-manifest actor. Prefer that exact
	# host before considering ordinary NPCs so a delivery never steals another
	# object's identity, slot, or rectangle.
	if handoff_index < 0 and not direct_handoff_id.is_empty():
		for index in range(result.size()):
			if str(_dict(result[index]).get("object_id", "")) == direct_handoff_id:
				contact_index = index
				contact_score = 1000
				break
	for index in range(result.size()):
		if index == handoff_index:
			continue
		var record := _dict(result[index])
		var object_type := str(record.get("object_type", ""))
		if str(record.get("visual_type", "")) == "character" or object_type in [host.CONTEXT_MODE_DIALOGUE, host.CONTEXT_MODE_SHOPKEEPER, "character", "scenario_actor"]:
			# Prefer an actual person in a room slot. Event portraits and overflow-only
			# people remain valid fallbacks, but a handoff must not disappear behind
			# the room-action drawer when a visible contact is already present.
			var score := 0
			if str(record.get("presentation_mode", "room")) == "room":
				score += 4
			if object_type in [host.CONTEXT_MODE_DIALOGUE, host.CONTEXT_MODE_SHOPKEEPER, "character", "scenario_actor"]:
				score += 2
			if bool(record.get("visible", true)):
				score += 1
			if score > contact_score:
				contact_score = score
				contact_index = index
	if handoff_index >= 0:
		# The mounted world sequence already owns a reconciled scenario slot. Render
		# that authority as the contact itself; an ordinary bartender, clerk, or
		# patron remains a separate manifest-backed object in its original slot.
		var contact := _dict(result[handoff_index])
		var handoff_actions := _array(contact.get("scenario_sequence_actions", [])).duplicate(true)
		for action_value in handoff_actions:
			if typeof(action_value) == TYPE_DICTIONARY:
				(action_value as Dictionary)["label"] = "Hand Over The Package"
		contact["scenario_sequence_actions"] = handoff_actions
		contact["object_type"] = "character"
		contact["visual_type"] = "character"
		contact["source_id"] = str(target.get("contact_id", "delivery_contact_%s" % node_id))
		contact["label"] = contact_label.capitalize()
		contact["short_description"] = "%s waits for The Package." % contact_label.capitalize()
		contact["visual_key"] = "character"
		contact["prop"] = "patron_talk"
		contact["icon_key"] = "dialogue"
		contact["delivery_contact"] = true
		contact["delivery_contact_label"] = contact_label
		# The delivery owner is the live authority at this destination. A room NPC
		# may be unavailable for ordinary dialogue, but it must not swallow the
		# authenticated package handoff attached to that contact.
		contact["interactive"] = true
		contact["enabled"] = true
		contact["disabled_reason"] = ""
		contact["action_summary"] = "%s is expecting The Package." % contact_label.capitalize()
		contact["status_summary"] = "Delivery contact"
		result[handoff_index] = contact
		# Older semantic snapshots may still contain the former direct producer.
		# The owner-scoped actor is the sole handoff contact while mounted.
		for index in range(result.size() - 1, -1, -1):
			if index != handoff_index and str(_dict(result[index]).get("object_id", "")) == direct_handoff_id:
				result.remove_at(index)
		return _promote_delivery_contact_to_room_slot(result, str(contact.get("object_id", "")))
	if handoff_index < 0 and contact_index >= 0:
		# Legacy and non-world-sequence package jobs use the same NPC-facing flow,
		# but their completion is owned directly by DeliveryRunModel.
		var contact := _dict(result[contact_index])
		contact["delivery_handoff_object_id"] = str(handoff.get("object_id", "delivery:handoff:%s" % node_id))
		contact["object_type"] = "character"
		contact["visual_type"] = "character"
		contact["delivery_contact_id"] = str(target.get("contact_id", "delivery_contact_%s" % node_id))
		contact["label"] = contact_label.capitalize()
		contact["short_description"] = "%s waits for the delivery." % contact_label.capitalize()
		contact["delivery_contact"] = true
		contact["delivery_contact_label"] = contact_label
		contact["delivery_handoff_direct"] = true
		contact["delivery_handoff_node_id"] = node_id
		# This contact temporarily borrows an ordinary room person. Its authored
		# event responses do not belong to the active delivery, so expose only the
		# authenticated handoff while the delivery owns the contact.
		contact["available_actions"] = [{"id": "delivery_handoff_direct", "label": "Hand Over The Package"}]
		contact["inline_actions"] = []
		contact["scenario_sequence_actions"] = []
		contact["confirm_action_id"] = "delivery_handoff_direct"
		contact["interactive"] = true
		contact["enabled"] = true
		contact["disabled_reason"] = ""
		contact["action_summary"] = "%s is expecting the delivery." % contact_label.capitalize()
		contact["status_summary"] = "Delivery contact"
		result[contact_index] = contact
		return _promote_delivery_contact_to_room_slot(result, str(contact.get("object_id", "")))
	# A sparse generated venue may genuinely contain no ordinary person. Add the
	# named contact to the action drawer. Legacy jobs have no sealed scenario
	# owner, so they must not invent room geometry or borrow another object's slot.
	var generated_contact: Dictionary = _dict(host._make_interactable_object({
		"object_id": str(handoff.get("object_id", "delivery:handoff:%s" % node_id)),
		"object_type": "character",
		"visual_type": "character",
		"source_id": str(target.get("contact_id", "delivery_contact_%s" % node_id)),
		"label": contact_label.capitalize(),
		"short_description": "%s waits for the delivery." % contact_label.capitalize(),
		"presence": "character",
		"interactive": true,
		"enabled": true,
		"action_summary": "Speak to the contact and make the handoff.",
		"status_summary": "Delivery contact",
		"visual_key": "character",
		"prop": "patron_talk",
		"icon_key": "dialogue",
		"delivery_contact": true,
		"delivery_contact_label": contact_label,
		"delivery_handoff_direct": true,
		"delivery_handoff_node_id": node_id,
		"available_actions": [{"id": "delivery_handoff_direct", "label": "Hand Over The Package"}],
		"confirm_action_id": "delivery_handoff_direct",
		"presentation_mode": "overflow",
		"placement_class": "standing_person",
	}))
	result.append(generated_contact)
	return _promote_delivery_contact_to_room_slot(result, str(generated_contact.get("object_id", "")))


static func _promote_delivery_contact_to_room_slot(records: Array, contact_id: String) -> Array:
	var result := records.duplicate(true)
	var contact_index := -1
	for index in range(result.size()):
		if str(_dict(result[index]).get("object_id", "")) == contact_id:
			contact_index = index
			break
	if contact_index < 0:
		return result
	var contact := _dict(result[contact_index])
	var slot_family := str(contact.get("slot_family", "")).strip_edges()
	var slot_id := str(contact.get("slot_id", "")).strip_edges()
	var focus_value: Variant = contact.get("focus_rect", {})
	var has_room_geometry := typeof(focus_value) == TYPE_RECT2 and (focus_value as Rect2).size.x > 0.0 and (focus_value as Rect2).size.y > 0.0
	if typeof(focus_value) == TYPE_DICTIONARY:
		var focus_dictionary := focus_value as Dictionary
		has_room_geometry = float(focus_dictionary.get("w", 0.0)) > 0.0 and float(focus_dictionary.get("h", 0.0)) > 0.0
	var owns_room_slot := str(contact.get("presentation_mode", "room")) == "room" \
			and slot_family in ["fixed", "event", "scenario", "exit"] \
			and slot_id.begins_with("%s." % slot_family) \
			and has_room_geometry
	if owns_room_slot:
		return result
	# A contact without sealed authority remains playable in overflow. It never
	# acquires another object's identity, slot, rectangle, or manifest annotation.
	contact["presentation_mode"] = "overflow"
	for field in ["slot_id", "slot_family", "normalized_rect", "focus_rect", "small_screen_rect", "label_rect", "small_screen_label_rect", "focus_point", "fixed_slot_geometry", "scenario_layout_resolved", "scenario_layout_authority_identity", "scenario_layout_authority_digest"]:
		contact.erase(field)
	result[contact_index] = contact
	return result
static func numbers_interactable_objects(host: Variant) -> Array:
	var objects: Array = []
	if host.run_state == null:
		return objects
	var venue_id := str(host.run_state.current_environment.get("archetype_id", host.run_state.current_world_node_id())).strip_edges()
	var venue_row: Dictionary = {}
	for venue_value in JsonCoerceScript._copy_array(host.run_state.numbers_status().get("venue_status", [])):
		if typeof(venue_value) == TYPE_DICTIONARY and str((venue_value as Dictionary).get("id", "")) == venue_id:
			venue_row = (venue_value as Dictionary).duplicate(true)
			break
	var current_layer := str(host.run_state.current_environment.get("current_layer_id", "")).strip_edges()
	var at_desk := venue_id == "small_underground_casino" and current_layer == "back_room"
	if not venue_row.is_empty():
		var venue_label := str(venue_row.get("label", host._label_from_id(venue_id)))
		var book_source := "desk" if at_desk else "book"
		var object_id := "event:numbers_desk" if at_desk else "numbers:book"
		# The generated manifest and authenticated slot binding own both the Crew
		# desk and ordinary Numbers-book geometry. This keeps developer slot moves
		# authoritative and prevents the legacy category spot from overriding the
		# fixed.event_numbers_desk binding.
		var focus_rect: Rect2 = host._interaction_rect_for_object(object_id, host.CONTEXT_MODE_NUMBERS, 0)
		objects.append(host._make_interactable_object({
			"object_id": object_id,
			"object_type": host.CONTEXT_MODE_NUMBERS,
			"slot_family": "fixed",
			"placement_class": "surface_item",
			"source_id": book_source,
			"label": "The Numbers Desk" if at_desk else "%s Numbers Book" % venue_label,
			"short_description": "Five books, runner work, and crew paper." if at_desk else "A local book taking three-digit slips.",
			"presence": "fixture",
			"interactive": true,
			"enabled": true,
			"action_summary": "Work the desk." if at_desk else "Write a straight or box slip.",
			"visual_key": "event",
			"prop": "paper_note",
			"icon_key": "parking_note",
			"available_actions": [{"id": "open_numbers", "label": "Work the Desk" if at_desk else "Open Book"}],
			"confirm_action_id": "open_numbers",
			"focus_rect": focus_rect,
		}))
	var silas_here: bool = host.run_state.numbers_silas_is_here()
	if silas_here:
		var silas_dialogue_id := "silas_crow_numbers"
		var silas_dialogue: Dictionary = host.library.dialogue(silas_dialogue_id)
		var silas_speaker_source: Dictionary = silas_dialogue.get("speaker", {}) if typeof(silas_dialogue.get("speaker", {})) == TYPE_DICTIONARY else {}
		var silas_actor: Dictionary = host._resolve_character_speaker(
			host._normalized_talk_speaker(silas_speaker_source),
			silas_dialogue_id,
			str(silas_speaker_source.get("voice_line_key", "snitch"))
		)
		objects.append(host._make_interactable_object({
			"object_id": "numbers:silas",
			"object_type": host.CONTEXT_MODE_DIALOGUE,
			"visual_type": "character",
			"slot_family": "event",
			"placement_class": "standing_person",
			"source_id": silas_dialogue_id,
			"label": "Silas Crow",
			"short_description": "A sharp-eyed floor informant selling routes, numbers, and expensive discretion.",
			"identity_summary": host.EnvironmentInteractionViewModelScript.character_identity_summary(silas_actor),
			"status_summary": "Silas smiles at both exits. He treats every fact as inventory and every conversation as a sale.",
			"presence": "character",
			"interactive": true,
			"enabled": true,
			"action_summary": "Start a quiet conversation.",
			"visual_key": "character",
			"prop": "patron_talk",
			"icon_key": "silas_crow",
			"character_actor": silas_actor,
			"available_actions": [{"id": "start_dialogue", "label": "Talk"}],
			"confirm_action_id": "start_dialogue",
			"focus_rect": host._interaction_rect_for_object("numbers:silas", "numbers_silas", 0),
		}))
	return objects


static func _dict(value: Variant) -> Dictionary:
	return value as Dictionary if typeof(value) == TYPE_DICTIONARY else {}


static func _duplicate_variant(value: Variant) -> Variant:
	if typeof(value) == TYPE_DICTIONARY:
		return (value as Dictionary).duplicate(true)
	if typeof(value) == TYPE_ARRAY:
		return (value as Array).duplicate(true)
	return value


static func _array(value: Variant) -> Array:
	return value as Array if typeof(value) == TYPE_ARRAY else []


static func game_hook_interactable_objects(host: Variant, apply_failure_lock: bool = true) -> Array:
	var objects: Array = []
	if host.run_state == null or host.library == null:
		return objects
	var run_failed_without_recovery = host._run_failed_without_recovery() if apply_failure_lock else false
	var failed_reason := ""
	if apply_failure_lock:
		failed_reason = host._pressure_status_text(host._run_pressure_view())
		if failed_reason.strip_edges().is_empty():
			failed_reason = "Run failed."
	var hook_index := 0
	for game_id in JsonCoerceScript._raw_string_array(host.run_state.current_environment.get("game_ids", [])):
		var game = host._game_module_for_id(game_id)
		if game == null:
			continue
		for hook_value in game.environment_interactable_objects(host.run_state, host.run_state.current_environment):
			if typeof(hook_value) != TYPE_DICTIONARY:
				continue
			var hook: Dictionary = hook_value
			var hook_id := str(hook.get("id", hook.get("source_id", "")))
			if hook_id.is_empty():
				continue
			var dialogue_id := str(hook.get("dialogue_id", "")).strip_edges()
			var object_type = host.CONTEXT_MODE_DIALOGUE if not dialogue_id.is_empty() else host.CONTEXT_MODE_GAME_HOOK
			var character_actor: Dictionary = {}
			var visual_type := str(hook.get("visual_type", "service"))
			var dialogue_speaker_override := JsonCoerceScript._copy_dict(hook.get("dialogue_speaker_override", {}))
			if not dialogue_id.is_empty():
				var dialogue_definition: Dictionary = host.library.dialogue(dialogue_id)
				var dialogue_speaker := JsonCoerceScript._copy_dict(dialogue_definition.get("speaker", {}))
				for override_key in dialogue_speaker_override.keys():
					dialogue_speaker[override_key] = dialogue_speaker_override[override_key]
				if not dialogue_speaker.is_empty() and bool(dialogue_speaker.get("environment_actor", true)):
					character_actor = host._resolve_character_speaker(
						host._normalized_talk_speaker(dialogue_speaker),
						dialogue_id,
						str(dialogue_speaker.get("voice_line_key", ""))
					)
					visual_type = "character"
			var object_id := str(hook.get("object_id", ""))
			if object_id.is_empty():
				object_id = "dialogue:%s" % dialogue_id if not dialogue_id.is_empty() else "game_hook:%s:%s" % [game_id, hook_id]
			var unique_object_class := str(hook.get("unique_object_class", "")).strip_edges()
			var slot_binding_source_id := str(hook.get("slot_binding_source_id", "")).strip_edges()
			if not slot_binding_source_id.is_empty():
				unique_object_class = ""
			if unique_object_class in ["scratch_ticket_clerk", "pull_tab_clerk", "lottery_redemption_clerk"]:
				unique_object_class = "lottery_redemption_clerk"
			# Legacy/custom rooms without a configured sales-counter host still
			# merge both redemption providers into the Scratch Tickets identity.
			var unique_object_priority := int(hook.get("unique_object_priority", 0))
			if hook_id == "scratch_ticket_clerk":
				unique_object_priority = maxi(unique_object_priority, 121)
			var base_enabled := bool(hook.get("enabled", true))
			var enabled = base_enabled and not run_failed_without_recovery
			var disabled_reason := str(hook.get("disabled_reason", ""))
			if run_failed_without_recovery:
				disabled_reason = failed_reason
			var hook_actions: Array = JsonCoerceScript._copy_array(hook.get("available_actions", [])) if enabled else []
			if enabled and not dialogue_id.is_empty() and hook_actions.is_empty():
				hook_actions = [{"id": "start_dialogue", "label": "Talk"}]
			var confirm_action: String = str(hook.get("confirm_action_id", "start_dialogue" if not dialogue_id.is_empty() else "")) if enabled else ""
			var enriched_actions: Array = []
			for action_value in hook_actions:
				if typeof(action_value) != TYPE_DICTIONARY:
					continue
				var action_data: Dictionary = (action_value as Dictionary).duplicate(true)
				action_data["parent_id"] = game_id
				action_data["source_id"] = dialogue_id if not dialogue_id.is_empty() else hook_id
				action_data["hook_id"] = hook_id
				action_data["object_type"] = object_type
				enriched_actions.append(action_data)
			objects.append(host._make_interactable_object({
				"object_id": object_id,
				"object_type": object_type,
				"visual_type": visual_type,
				"source_id": dialogue_id if not dialogue_id.is_empty() else hook_id,
				"parent_id": game_id,
				"label": str(hook.get("label", host._label_from_id(hook_id))),
				"short_description": str(hook.get("short_description", "")),
				"identity_summary": host.EnvironmentInteractionViewModelScript.character_identity_summary(character_actor),
				"enabled": enabled,
				"disabled_reason": disabled_reason if not enabled else "",
				"action_summary": str(hook.get("action_summary", "")),
				"effect_summary": str(hook.get("effect_summary", "")),
				"risk_summary": str(hook.get("risk_summary", "")),
				"cost_summary": str(hook.get("cost_summary", "")),
				"dialogue_summary": str(hook.get("dialogue_summary", "")),
				"attribute_badges": JsonCoerceScript._copy_array(hook.get("attribute_badges", [])),
				"visual_key": str(hook.get("visual_key", "")),
				"icon_key": str(hook.get("icon_key", "service")),
				"character_actor": character_actor,
				"dialogue_speaker_override": dialogue_speaker_override,
				"slot_binding_source_id": slot_binding_source_id,
				"unique_object_class": unique_object_class,
				"unique_object_priority": unique_object_priority,
				"allow_duplicate_unique_class": bool(hook.get("allow_duplicate_unique_class", false)),
				"available_actions": enriched_actions,
				"confirm_action_id": confirm_action,
				"focus_rect": host._interaction_rect_for_object(object_id, object_type, hook_index),
			}))
			hook_index += 1
	return objects


static func home_interactable_objects(host: Variant) -> Array:
	var objects: Array = []
	if host.run_state == null or host.library == null or not host.run_state.is_current_home_environment():
		return objects
	var tenure_status = host.run_state.home_tenure_status()
	var tenure_action = host.run_state.home_tenure_action_status()
	var tenure_available := bool(tenure_action.get("available", false))
	var tenure_enabled := tenure_available and bool(tenure_action.get("enabled", false))
	var tenure_label := str(tenure_action.get("label", "Home Status"))
	var tenure_description := str(tenure_status.get("summary", host.run_state.home_status_summary()))
	var tenure_actions := [{"id": "home_tenure_action", "label": tenure_label}] if tenure_available else []
	objects.append(host._make_interactable_object({
		"object_id": "home_tenure:status",
		"object_type": host.CONTEXT_MODE_HOME_TENURE,
		"visual_type": host.CONTEXT_MODE_HOME_TENURE,
		"source_id": "status",
		"label": tenure_label,
		"short_description": tenure_description,
		"presence": "fixture",
		"interactive": tenure_available,
		"enabled": tenure_enabled,
		"disabled_reason": "" if tenure_enabled else str(tenure_action.get("disabled_reason", "")),
		"action_summary": "Settle the home clock." if tenure_enabled else tenure_description,
		"status_summary": tenure_description,
		"cost_summary": "Cost: %d" % int(tenure_action.get("cost", 0)) if tenure_available else "",
		"visual_key": "home_tenure",
		"prop": "paper_note",
		"icon_key": "service",
		"available_actions": tenure_actions if tenure_enabled else [],
		"confirm_action_id": "home_tenure_action" if tenure_enabled else "",
		"focus_rect": host._interaction_rect_for_object("home_tenure:status", host.CONTEXT_MODE_HOME_TENURE, 0),
	}))
	objects.append(host._make_interactable_object({
		"object_id": "home_sleep:bed",
		"object_type": host.CONTEXT_MODE_HOME_SLEEP,
		"visual_type": host.CONTEXT_MODE_HOME_SLEEP,
		"source_id": "bed",
		"label": "Sleep",
		"short_description": "Sleep at home for four to eight hours.",
		"presence": "fixture",
		"interactive": true,
		"enabled": true,
		"action_summary": "Sleep until you wake naturally.",
		"status_summary": "Several hours pass.",
		"effect_summary": "Cools heat and steadies the room.",
		"visual_key": "home_sleep",
		"prop": "bed",
		"icon_key": "motel_room",
		"available_actions": [{"id": "home_sleep", "label": "Sleep"}],
		"confirm_action_id": "home_sleep",
		"focus_rect": host._interaction_rect_for_object("home_sleep:bed", host.CONTEXT_MODE_HOME_SLEEP, 0),
	}))
	var held_containers = host._held_container_item_options()
	var storage_enabled = not held_containers.is_empty()
	objects.append(host._make_interactable_object({
		"object_id": "home_storage:place",
		"object_type": host.CONTEXT_MODE_HOME_STORAGE,
		"visual_type": host.CONTEXT_MODE_HOME_STORAGE,
		"source_id": "place",
		"label": "Storage Spot",
		"short_description": "Place a carried container here for home storage.",
		"presence": "fixture",
		"interactive": true,
		"enabled": storage_enabled,
		"disabled_reason": "" if storage_enabled else "Carry a container first.",
		"action_summary": "Place a carried container." if storage_enabled else "No carried container to place.",
		"status_summary": "%d carried container(s)" % held_containers.size(),
		"visual_key": "home_storage",
		"prop": "crate",
		"icon_key": "service",
		"available_actions": [{"id": "place_home_container", "label": "Place"}] if storage_enabled else [],
		"confirm_action_id": "place_home_container" if storage_enabled else "",
		"focus_rect": host._interaction_rect_for_object("home_storage:place", host.CONTEXT_MODE_HOME_STORAGE, 0),
	}))
	var containers = host.run_state.current_home_containers()
	for index in range(containers.size()):
		if typeof(containers[index]) != TYPE_DICTIONARY:
			continue
		var container: Dictionary = containers[index]
		var container_id := str(container.get("id", ""))
		var stored_items = JsonCoerceScript._raw_string_array(container.get("items", []))
		var capacity := maxi(0, int(container.get("capacity", 0)))
		var object_id := "home_container:%s" % container_id
		objects.append(host._make_interactable_object({
			"object_id": object_id,
			"object_type": host.CONTEXT_MODE_HOME_CONTAINER,
			"visual_type": host.CONTEXT_MODE_HOME_CONTAINER,
			"source_id": container_id,
			"label": str(container.get("display_name", "Container")),
			"short_description": "Home storage. Stored items do not grant effects while stashed.",
			"presence": "fixture",
			"interactive": true,
			"enabled": true,
			"action_summary": "Move items in or out.",
			"status_summary": "%d/%d stored" % [stored_items.size(), capacity],
			"effect_summary": host._home_container_contents_summary(container),
			"visual_key": "home_container",
			"prop": "satchel",
			"icon_key": str(container.get("item_id", "service")),
			"available_actions": [{"id": "manage_home_container", "label": "Open"}],
			"confirm_action_id": "manage_home_container",
			"focus_rect": host._interaction_rect_for_object(object_id, host.CONTEXT_MODE_HOME_CONTAINER, index),
		}))
	return objects


static func hook_interactable_objects(host: Variant, object_type: String, options: Array) -> Array:
	var objects: Array = []
	var run_failed_without_recovery = host._run_failed_without_recovery()
	var failed_reason = host._pressure_status_text(host._run_pressure_view())
	if failed_reason.strip_edges().is_empty():
		failed_reason = "Run failed."
	for index in range(options.size()):
		if typeof(options[index]) != TYPE_DICTIONARY:
			continue
		var option: Dictionary = options[index]
		var hook_id := str(option.get("id", ""))
		if hook_id.is_empty():
			continue
		var object_id := "%s:%s" % [object_type, hook_id]
		var presence := "fixture" if host._object_fixture_declared(object_id) else "dynamic"
		if bool(option.get("hidden", false)) and presence != "fixture":
			continue
		var supported := bool(option.get("mutation_supported", false))
		var lender_definition: Dictionary = host.library.lender(hook_id) if object_type == host.CONTEXT_MODE_LENDER else {}
		# A pawn counter is an inventory interface, not a one-shot loan action. It
		# must remain openable with empty pockets so players can inspect the counter,
		# redeem existing tickets, or return after their carried inventory changes.
		var is_pawn_counter := str(lender_definition.get("lender_type", "")) == "pawn"
		var repayment: Dictionary = {}
		if object_type == host.CONTEXT_MODE_LENDER and supported and not is_pawn_counter and not bool(option.get("enabled", true)) and host.run_state != null:
			repayment = host.run_state.lender_repayment_status(hook_id)
		var is_repayment := bool(repayment.get("available", false))
		var action_enabled := bool(repayment.get("enabled", false)) if is_repayment else bool(option.get("enabled", supported)) or is_pawn_counter
		var enabled = action_enabled and not run_failed_without_recovery
		var disabled_reason = "" if enabled else failed_reason if run_failed_without_recovery else str(repayment.get("disabled_reason", "")) if is_repayment else str(option.get("disabled_reason", option.get("status", "Display-only.")))
		var action_id := "repay_lender_debt" if is_repayment else "use_%s_hook" % object_type
		var action_label := "Pay $%d" % int(repayment.get("payoff_amount", 0)) if is_repayment else "Use"
		var availability_class := str(option.get("availability_class", RunState.AVAILABILITY_AVAILABLE))
		var category := str(option.get("category", ""))
		var duration_minutes := maxi(0, int(option.get("duration_minutes", 0)))
		var duration_summary := "Takes 1 hour." if duration_minutes == 60 else "Takes %d minutes." % duration_minutes if duration_minutes > 0 else ""
		var visual_type := "drink" if object_type == host.CONTEXT_MODE_SERVICE and category == "alcohol" else object_type
		var character_actor: Dictionary = {}
		if object_type == host.CONTEXT_MODE_LENDER:
			var lender_speaker: Dictionary = lender_definition.get("speaker", {}) if typeof(lender_definition.get("speaker", {})) == TYPE_DICTIONARY else {}
			if str(lender_definition.get("lender_type", "")) != "family_phone" and not lender_speaker.is_empty() and bool(lender_speaker.get("environment_actor", true)):
				character_actor = host._resolve_character_speaker(
					host._normalized_talk_speaker(lender_speaker),
					hook_id,
					str(lender_speaker.get("voice_line_key", "loan_offer"))
				)
				visual_type = "character"
		var icon_key := str(option.get("icon_key", visual_type)).strip_edges()
		if icon_key.is_empty():
			icon_key = visual_type
		objects.append(host._make_interactable_object({
			"object_id": object_id,
			"object_type": object_type,
			"visual_type": visual_type,
			"source_id": hook_id,
			"label": str(option.get("display_name", host._label_from_id(hook_id))),
			"short_description": str(option.get("summary", "")),
			"identity_summary": host.EnvironmentInteractionViewModelScript.character_identity_summary(character_actor),
			"presence": presence,
			"interactive": enabled or availability_class == RunState.AVAILABILITY_TRANSIENT_BLOCKED,
			"enabled": enabled,
			"disabled_reason": disabled_reason,
			"action_summary": "Double-click to repay." if enabled and is_repayment else "Double-click to use." if enabled else "",
			"status_summary": duration_summary,
			"risk_summary": "",
			"cost_summary": "Payoff: $%d" % int(repayment.get("payoff_amount", 0)) if is_repayment else "Cost: %d" % int(option.get("cost", 0)) if option.has("cost") else "",
			"effect_summary": str(option.get("delta_summary", "")),
			"attribute_badges": JsonCoerceScript._copy_array(option.get("attribute_badges", [])),
			"visual_key": visual_type,
			"prop": str(option.get("environment_prop", "")),
			"surface": str(option.get("surface", "")),
			"icon_key": icon_key,
			"asset_path": str(option.get("asset_path", "")),
			"character_actor": character_actor,
			"slot_binding_source_id": str(option.get("slot_binding_source_id", "")).strip_edges(),
			"available_actions": [{"id": action_id, "label": action_label}] if enabled else [],
			"confirm_action_id": action_id if enabled else "",
			"focus_rect": host._interaction_rect_for_object(object_id, object_type, index),
		}))
	return objects


static func interactable_object(host: Variant, object_id: String) -> Dictionary:
	for object_data in host._interactable_object_view_list():
		if typeof(object_data) == TYPE_DICTIONARY and str((object_data as Dictionary).get("object_id", "")) == object_id:
			return (object_data as Dictionary).duplicate(true)
	if object_id == "travel:leave":
		return host._travel_leave_interactable_object()
	return {}


# Programmatic category selection still names the gameplay action (for example
# service:cashier_tip), even when that action lives on one named physical host.
# Resolve only focus to that host; action dispatch continues to use the attached
# descriptor and therefore cannot impersonate the host's own action.
static func interactable_object_hosting_action(host: Variant, action_object_id: String) -> Dictionary:
	if action_object_id.is_empty():
		return {}
	for object_value in host._interactable_object_view_list():
		var object_data := _dict(object_value)
		for descriptor_value in _array(object_data.get("attached_room_actions", [])):
			var descriptor := _dict(descriptor_value)
			var source_record := _dict(descriptor.get("record", {}))
			if str(source_record.get("object_id", "")) == action_object_id:
				return object_data.duplicate(true)
	return {}


static func parent_home_return_interactable_object(host: Variant) -> Dictionary:
	var room_node_id = host._parent_home_node_id()
	if room_node_id.is_empty():
		return {}
	var choice = host._local_parent_home_door_travel_choice(room_node_id)
	if choice.is_empty():
		return {}
	return host._make_interactable_object({
		"object_id": "travel:%s" % room_node_id,
		"object_type": host.CONTEXT_MODE_TRAVEL,
		"source_id": room_node_id,
		"label": "Room Door",
		"short_description": "Return to your room.",
		"enabled": bool(choice.get("enabled", true)),
		"disabled_reason": str(choice.get("disabled_reason", "")),
		"action_summary": "Enter room.",
		"risk_summary": "",
		"impact_summary": "No fare. No street exposure.",
		"cost_summary": "Cost: 0",
		"attribute_badges": JsonCoerceScript._copy_array(choice.get("attribute_badges", [])),
		"preview_lines": JsonCoerceScript._copy_array(choice.get("preview_lines", [])),
		"unlock_conditions": [],
		"visual_key": "travel",
		"prop": "door",
		"icon_key": "travel",
		"available_actions": [{"id": "enter_room", "label": "Enter Room"}] if bool(choice.get("enabled", true)) else [],
		"confirm_action_id": "enter_room" if bool(choice.get("enabled", true)) else "",
		"focus_rect": host._interaction_rect_for_object("travel:%s" % room_node_id, host.CONTEXT_MODE_TRAVEL, 1),
	})


static func casino_spatial_interactable_objects(host: Variant) -> Array:
	var objects: Array = []
	if host.run_state == null or not host.run_state.is_grand_casino_environment():
		return objects
	var flags: Dictionary = host.run_state.current_environment.get("local_narrative_flags", {}) if typeof(host.run_state.current_environment.get("local_narrative_flags", {})) == TYPE_DICTIONARY else {}
	var fixture_index := 0
	for fixture_value in JsonCoerceScript._copy_array(flags.get("casino_fixtures", [])):
		if typeof(fixture_value) != TYPE_DICTIONARY:
			continue
		var fixture: Dictionary = fixture_value
		var fixture_id := str(fixture.get("id", "")).strip_edges()
		if fixture_id.is_empty():
			continue
		# The Cage case is scenery and shelving, not a catalog control. Its saved
		# stock is exposed below through the normal item-offer path so every gift
		# has its own icon, focus target, details, and purchase action.
		if fixture_id == "cage_gift_shop":
			continue
		var object_id := "casino_fixture:%s" % fixture_id
		var object_data := {
			"object_id": object_id,
			"object_type": host.CONTEXT_MODE_CASINO_FIXTURE,
			"source_id": fixture_id,
			"label": str(fixture.get("label", host._label_from_id(fixture_id))),
			"short_description": str(fixture.get("description", "A Grand Casino fixture.")),
			"presence": "fixture",
			"interactive": true,
			"enabled": true,
			"action_summary": str(fixture.get("action_summary", "Inspect.")),
			"interaction_message": str(fixture.get("interaction_message", "The casino staff acknowledge you.")),
			"visual_key": str(fixture.get("visual_key", "casino_fixture")),
			"prop": str(fixture.get("prop", "counter")),
			"surface": str(fixture.get("surface", "counter_case")),
			"icon_key": str(fixture.get("icon_key", "service")),
			"available_actions": [{"id": "inspect_casino_fixture", "label": "Inspect"}],
			"confirm_action_id": "inspect_casino_fixture",
			"focus_rect": host._interaction_rect_for_object(object_id, host.CONTEXT_MODE_CASINO_FIXTURE, fixture_index),
		}
		if fixture_id == "cage_atm":
			object_data["inline_actions"] = host._cage_atm_inline_actions()
		objects.append(host._make_interactable_object(object_data))
		fixture_index += 1
	var door_index := 0
	for target_id_value in JsonCoerceScript._copy_array(flags.get("casino_room_targets", [])):
		var target_id := str(target_id_value).strip_edges()
		var choice := casino_room_door_travel_choice(host, target_id)
		if choice.is_empty():
			continue
		var object_id := "travel:%s" % target_id
		var enabled := bool(choice.get("enabled", true))
		objects.append(host._make_interactable_object({
			"object_id": object_id,
			"object_type": host.CONTEXT_MODE_TRAVEL,
			"source_id": target_id,
			"label": str(choice.get("label", host._label_from_id(target_id))),
			"short_description": str(choice.get("description", "An interior casino door.")),
			"presence": "fixture",
			"interactive": true,
			"enabled": enabled,
			"disabled_reason": str(choice.get("disabled_reason", "")),
			"action_summary": "Enter room." if enabled else str(choice.get("disabled_reason", "Locked.")),
			"cost_summary": "Cost: %d" % int(choice.get("cost", 0)),
			"attribute_badges": JsonCoerceScript._copy_array(choice.get("attribute_badges", [])),
			"preview_lines": JsonCoerceScript._copy_array(choice.get("preview_lines", [])),
			"unlock_conditions": JsonCoerceScript._copy_array(choice.get("unlock_conditions", [])),
			"visual_key": "travel",
			"prop": "door",
			"icon_key": "travel",
			"available_actions": [{"id": "enter_room", "label": "Enter Room"}] if enabled else [],
			"confirm_action_id": "enter_room" if enabled else "",
			"focus_rect": host._interaction_rect_for_object(object_id, host.CONTEXT_MODE_TRAVEL, door_index + 1),
		}))
		door_index += 1
	return objects


static func environment_layer_interactable_objects(host: Variant) -> Array:
	var objects: Array = []
	if host.run_state == null or not host.run_state.is_layered_environment():
		return objects
	var ambient_line := str(host.run_state.current_environment.get("layer_ambient_line", "")).strip_edges()
	var ambient_label := str(host.run_state.current_environment.get("layer_ambient_label", "")).strip_edges()
	if not ambient_line.is_empty() and not ambient_label.is_empty():
		objects.append(host._make_interactable_object({
			"object_id": "environment_layer:ambient",
			"object_type": host.CONTEXT_MODE_ENVIRONMENT_LAYER,
			"source_id": "ambient",
			"label": ambient_label,
			"short_description": ambient_line,
			"presence": "fixture",
			"interactive": false,
			"enabled": false,
			"disabled_reason": ambient_line,
			"action_summary": ambient_line,
			"visual_key": "environment_layer_ambient",
			"prop": str(host.run_state.current_environment.get("layer_ambient_prop", "stage")),
			"icon_key": "service",
			"available_actions": [],
			"confirm_action_id": "",
			"focus_rect": host._interaction_rect_for_object("environment_layer:ambient", host.CONTEXT_MODE_ENVIRONMENT_LAYER, 0),
		}))
	var transition_index := 1
	for transition_value in JsonCoerceScript._copy_array(host.run_state.current_environment.get("layer_transitions", [])):
		if typeof(transition_value) != TYPE_DICTIONARY:
			continue
		var transition: Dictionary = transition_value
		var target_id := str(transition.get("target_layer_id", "")).strip_edges()
		if target_id.is_empty():
			continue
		var status: Dictionary = host.run_state.environment_layer_access_status(target_id)
		if bool(status.get("hidden", false)):
			continue
		var enabled := bool(status.get("available", false))
		var object_id := "environment_layer:%s" % target_id
		objects.append(host._make_interactable_object({
			"object_id": object_id,
			"object_type": host.CONTEXT_MODE_ENVIRONMENT_LAYER,
			"source_id": target_id,
			"label": str(transition.get("label", host._label_from_id(target_id))),
			"short_description": str(transition.get("description", "An interior door.")),
			"presence": "fixture",
			"interactive": true,
			"enabled": enabled,
			"disabled_reason": "" if enabled else str(status.get("reason", transition.get("locked_reason", "The door stays shut."))),
			"action_summary": "Enter room." if enabled else str(status.get("reason", transition.get("locked_reason", "The door stays shut."))),
			"impact_summary": "No fare. No street exposure.",
			"cost_summary": "Cost: 0",
			"visual_key": "environment_layer_door",
			"prop": str(transition.get("prop", "door")),
			"icon_key": str(transition.get("icon_key", "travel")),
			"available_actions": [{"id": "enter_environment_layer", "label": "Enter Room"}] if enabled else [],
			"confirm_action_id": "enter_environment_layer" if enabled else "",
			"focus_rect": host._interaction_rect_for_object(object_id, host.CONTEXT_MODE_ENVIRONMENT_LAYER, transition_index),
		}))
		transition_index += 1
	return objects


static func travel_leave_interactable_object(host: Variant) -> Dictionary:
	if host.run_state == null:
		return {}
	if host.has_method("_is_environment_test_session") and bool(host.call("_is_environment_test_session")):
		return host._make_interactable_object({
			"object_id": "travel:leave",
			"object_type": host.CONTEXT_MODE_TRAVEL,
			"source_id": "environment_library",
			"label": "Environments",
			"short_description": "Choose another environment practice room.",
			"enabled": true,
			"disabled_reason": "",
			"action_summary": "Open Environment Library.",
			"risk_summary": "No travel risk.",
			"impact_summary": "Player attributes carry forward.",
			"cost_summary": "Cost: 0",
			"attribute_badges": [],
			"preview_lines": ["No time or travel progression.", "Money, items, heat, and player state are preserved."],
			"unlock_conditions": [],
			"visual_key": "travel",
			"prop": "door",
			"icon_key": "travel",
			"available_actions": [{"id": "open_environment_library", "label": "Choose Environment"}],
			"confirm_action_id": "open_environment_library",
			"focus_rect": host._interaction_rect_for_object("travel:leave", host.CONTEXT_MODE_TRAVEL, 0),
		})
	var travel_choices = host._travel_choice_view_list()
	if travel_choices.is_empty():
		return {}
	var first_choice: Dictionary = travel_choices[0] if typeof(travel_choices[0]) == TYPE_DICTIONARY else {}
	var direct_room_exit = host._local_parent_home_door_travel_choice(host._parent_home_parent_target_id())
	if not direct_room_exit.is_empty():
		first_choice = direct_room_exit
	var any_enabled := false
	for choice_value in travel_choices:
		if typeof(choice_value) == TYPE_DICTIONARY and bool((choice_value as Dictionary).get("enabled", true)):
			any_enabled = true
			break
	var travel_enabled = not host._run_failed_without_recovery()
	var preview_lines = host._travel_leave_preview_lines(travel_choices, direct_room_exit)
	var travel_label := str(direct_room_exit.get("label", "Lobby")) if not direct_room_exit.is_empty() else "Leave"
	var travel_description := "Enter motel lobby." if not direct_room_exit.is_empty() else "Open city map."
	var travel_action_summary := "Enter lobby." if not direct_room_exit.is_empty() else "Open map." if any_enabled else "Inspect locked routes."
	var travel_available_actions := [{"id": "enter_lobby", "label": "Enter Lobby"}] if not direct_room_exit.is_empty() and travel_enabled else [{"id": "open_map", "label": "Open Map"}] if travel_enabled else []
	var travel_confirm_action := "enter_lobby" if not direct_room_exit.is_empty() and travel_enabled else "open_map" if travel_enabled else ""
	return host._make_interactable_object({
		"object_id": "travel:leave",
		"object_type": host.CONTEXT_MODE_TRAVEL,
		"source_id": "leave",
		"label": travel_label,
		"short_description": travel_description,
		"enabled": travel_enabled,
		"disabled_reason": host._pressure_status_text(host._run_pressure_view()) if not travel_enabled else "",
		"action_summary": travel_action_summary,
		"risk_summary": host._travel_risk_summary(first_choice),
		"impact_summary": host._travel_preview_summary(first_choice),
		"cost_summary": "%d route(s)" % travel_choices.size(),
		"attribute_badges": JsonCoerceScript._copy_array(first_choice.get("attribute_badges", [])),
		"preview_lines": preview_lines,
		"unlock_conditions": [],
		"visual_key": "travel",
		"prop": "door",
		"icon_key": "travel",
		"available_actions": travel_available_actions,
		"confirm_action_id": travel_confirm_action,
		"focus_rect": host._interaction_rect_for_object("travel:leave", host.CONTEXT_MODE_TRAVEL, 0),
	})


static func local_parent_home_door_travel_choice(host: Variant, target_id: String) -> Dictionary:
	var casino_choice := casino_room_door_travel_choice(host, target_id)
	if not casino_choice.is_empty():
		return casino_choice
	var door_kind = host._local_parent_home_door_kind(target_id)
	if door_kind.is_empty():
		return {}
	# A parent-home door is a physical adjacency, not one of the capped map
	# suggestions.  The map list may legitimately omit an undiscovered lobby;
	# requiring it here turned the room's only exit into Open Map and stranded the
	# player.  The authored parent relationship above is the authority for this
	# local move, while the ordinary route status below still preserves real locks.
	var route = host._world_route_for_target(target_id)
	if route.is_empty():
		route = host.library.route(target_id) if host.library != null else {}
	route["cost"] = 0
	route["base_cost"] = 0
	route["distance"] = "near"
	route["distance_blocks"] = 1
	route["risk"] = ""
	route["suspicion_delta"] = 0
	route["risk_decay"] = 0
	route["travel_method"] = "Door"
	var archetype = host._environment_archetype(target_id)
	var label = host._travel_label_from_archetype(archetype, target_id)
	var preview_line := "Step through the door into the lobby."
	if door_kind == "return":
		label = str(host.run_state.home_state.get("display_name", "Room"))
		preview_line = "Step through the door back into your room."
	elif label.is_empty() or label == target_id:
		label = "Lobby"
	var status = host.run_state.travel_route_status(route)
	if bool(status.get("hidden", false)):
		return {}
	return {
		"id": target_id,
		"label": label,
		"kind": str(archetype.get("kind", "")),
		"tier": int(archetype.get("tier", 1)),
		"description": "A local door between your room and the lobby.",
		"route": route.duplicate(true),
		"cost": 0,
		"risk": "",
		"suspicion_delta": 0,
		"distance": "near",
		"distance_blocks": 1,
		"risk_decay": 0,
		"travel_method": "Door",
		"risk_text": "",
		"risk_event": {},
		"attribute_badges": host.AttributeBadgesScript.for_route(route, {}),
		"unlock_conditions": JsonCoerceScript._copy_array(status.get("unlock_conditions", [])),
		"unlock_summary": str(status.get("unlock_summary", "")),
		"preview": {"level": "full", "lines": [preview_line]},
		"preview_level": "full",
		"preview_lines": [preview_line],
		"enabled": bool(status.get("available", true)),
		"disabled_reason": str(status.get("disabled_reason", "")),
		"local_door": true,
		"door_kind": door_kind,
	}


static func casino_room_door_travel_choice(host: Variant, target_id: String) -> Dictionary:
	if host.run_state == null or not host.run_state.is_grand_casino_environment():
		return {}
	var clean_target_id := target_id.strip_edges()
	var flags: Dictionary = host.run_state.current_environment.get("local_narrative_flags", {}) if typeof(host.run_state.current_environment.get("local_narrative_flags", {})) == TYPE_DICTIONARY else {}
	if not JsonCoerceScript._raw_string_array(flags.get("casino_room_targets", [])).has(clean_target_id):
		return {}
	var archetype = host._environment_archetype(clean_target_id)
	if archetype.is_empty():
		return {}
	var travel_minutes := maxi(1, int(flags.get("casino_room_travel_minutes", 5)))
	var buy_in := maxi(0, int(flags.get("casino_high_limit_buy_in", 60)))
	var room_access: Dictionary = host.run_state.grand_casino_room_access_status(clean_target_id, buy_in)
	var requires_buy_in := bool(room_access.get("cash_buy_in_required", false))
	var locked_back_room := clean_target_id == RunState.GRAND_CASINO_BACK_ROOM_ARCHETYPE_ID
	var route := {
		"id": clean_target_id,
		"destination_archetype": clean_target_id,
		"target_node_id": RunState.GRAND_CASINO_ARCHETYPE_ID,
		"cost": buy_in if requires_buy_in else 0,
		"base_cost": buy_in if requires_buy_in else 0,
		"distance": "near",
		"distance_blocks": 0,
		"risk": "",
		"suspicion_delta": 0,
		"risk_decay": 0,
		"travel_method": "Inside",
		"method": "Inside",
		"travel_minutes": travel_minutes,
		"local_casino_room": true,
	}
	var status = host.run_state.travel_route_status(route)
	var enabled := bool(status.get("available", true)) and bool(room_access.get("available", false))
	var disabled_reason := str(status.get("disabled_reason", room_access.get("reason", "")))
	var unlock_conditions: Array = []
	var preview_line := "Cross the Grand Casino interior in %d minutes." % travel_minutes
	if locked_back_room:
		enabled = false
		disabled_reason = "Locked. Rourke opens the Back Room only for a showdown."
		unlock_conditions = ["Rourke must take you there."]
		preview_line = "The Back Room door is visible, but Rourke controls the lock."
	elif requires_buy_in:
		unlock_conditions = ["Silver Players Card or a $%d cash buy-in." % buy_in]
		preview_line = "Pay the $%d cash buy-in, or enter later with Silver card access." % buy_in
		if not bool(room_access.get("available", false)):
			enabled = false
			disabled_reason = str(room_access.get("reason", "High-Limit requires Silver card access or a $%d cash buy-in." % buy_in))
	var label := str(archetype.get("display_name", "")).strip_edges()
	if label.is_empty():
		label = host._travel_label_from_archetype(archetype, clean_target_id)
	return {
		"id": clean_target_id,
		"label": label,
		"kind": str(archetype.get("kind", "boss")),
		"tier": int(archetype.get("tier", 3)),
		"description": str(archetype.get("room_description", "An interior Grand Casino room.")),
		"route": route.duplicate(true),
		"cost": int(route.get("cost", 0)),
		"risk": "",
		"suspicion_delta": 0,
		"distance": "near",
		"distance_blocks": 0,
		"risk_decay": 0,
		"travel_method": "Inside",
		"travel_minutes": travel_minutes,
		"local_door": true,
		"local_casino_room": true,
		"high_limit_buy_in": requires_buy_in,
		"attribute_badges": host.AttributeBadgesScript.for_route(route, {}),
		"unlock_conditions": unlock_conditions,
		"unlock_summary": "; ".join(unlock_conditions),
		"preview": {"level": "full", "lines": [preview_line]},
		"preview_level": "full",
		"preview_lines": [preview_line],
		"enabled": enabled,
		"disabled_reason": disabled_reason,
	}


static func local_parent_home_door_kind(host: Variant, target_id: String) -> String:
	if host.run_state == null or target_id.strip_edges().is_empty():
		return ""
	var room_node_id = host._parent_home_node_id()
	if room_node_id.is_empty():
		return ""
	var current_id = host._current_environment_archetype_id()
	var parent_id = host._parent_home_parent_target_id()
	if current_id == room_node_id and target_id == parent_id:
		return "exit"
	if current_id == parent_id and target_id == room_node_id:
		return "return"
	return ""


static func current_environment_archetype_id(host: Variant) -> String:
	if host.run_state == null:
		return ""
	return str(host.run_state.current_environment.get("world_node_id", host.run_state.current_environment.get("archetype_id", host.run_state.current_environment.get("id", "")))).strip_edges()


static func parent_home_node_id(host: Variant) -> String:
	if host.run_state == null or not host.run_state.home_is_active():
		return ""
	var home_id := str(host.run_state.home_state.get("home_archetype_id", "")).strip_edges()
	var home_archetype = host._environment_archetype(home_id)
	if str(home_archetype.get("parent_archetype", "")).strip_edges().is_empty():
		return ""
	var node_id := str(host.run_state.home_state.get("home_node_id", home_id)).strip_edges()
	return node_id if not node_id.is_empty() else home_id


static func parent_home_parent_target_id(host: Variant) -> String:
	if host.run_state == null:
		return ""
	var room_node_id = host._parent_home_node_id()
	if room_node_id.is_empty():
		return ""
	var room_archetype = host._environment_archetype(room_node_id)
	var parent_id := str(room_archetype.get("parent_archetype", "")).strip_edges()
	return parent_id


static func prepare_character_offers_at_boundary(host: Variant, records: Array = []) -> void:
	var eligibility := func(offer: Dictionary) -> bool:
		return _character_offer_route_available(host, offer)
	var hosts: Array = []
	for value in (records if not records.is_empty() else host.room_catalog_snapshot()):
		var record := _dict(value)
		if bool(record.get("manifest_physical", false)) and bool(record.get("visible", true)) \
				and str(record.get("presentation_mode", "room")) == "room":
			hosts.append(record)
	CharacterOfferModelScript.prepare_for_hosts(host.run_state, host.library, hosts, eligibility)
