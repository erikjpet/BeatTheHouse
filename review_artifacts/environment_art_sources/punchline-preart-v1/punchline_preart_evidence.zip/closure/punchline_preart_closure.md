# Public Punchline current6 pre-art closure

737 checks, zero findings. 73 actual canvas rows and selected titles;30 Runtime visual records;5 explicit authored exclusions.

All6 actual Tonight Comic records are disabled environment_layer floor_fixture with stage prop, empty character_actor and no asset_path. Production body falls through to generic item fixture/light, not a painted actor/mic/stand. Architectural mic is separate; no duplicate mic was observed. Final target decision remains director-owned.

The diagonal over Tonight Comic is the disabled status mark, not a second microphone. The dark table-side silhouettes are procedural legacy audience, omitted from the empty guide; they are not missing live canvas records.

Exact painted pixels in six existing full production board captures; no new native run and no model-envelope masks. Count exact scenario-tinted core-color samples, not all perceptually visible/translucently modified lamp pixels. A changed color can be translucent live paint, not full opaque occlusion. Counts are sampled frames, not full idle-cycle proof.

## Practical exact amber pixels /432 at2x
- __none: 144, 432, 198, 0
- punchline_bringer_show: 144, 208, 198, 0
- punchline_debt_court: 144, 432, 198, 0
- punchline_headliner_night: 144, 432, 198, 0
- punchline_open_mic_night: 144, 192, 198, 0
- punchline_raid_jitters: 144, 426, 198, 0

Live Ox fully covers practical4 at every captured frame. Do not claim a visible fourth pulse from this evidence. Practical1/3 legacy silhouette coverage is not a future pack mask.

## Stage wing model/label/hit envelopes
- punchline_bringer_show scenario::punchline_bringer_show_crowd_ropes {"left_stage_wing": {"model_envelope": [264, 221.0, 28.0, 31.0], "label_envelope": [264, 204.0, 38, 15.0], "hit_envelope": [264, 221.0, 28.0, 31.0]}}
- punchline_debt_court numbers:book {"right_stage_wing": {"model_envelope": [598, 202, 0, 0], "label_envelope": [598, 203.0, 25.0, 26.0], "hit_envelope": [598, 202, 0, 0]}}
- punchline_debt_court event:scenario_debt_court_office_hours {"left_stage_wing": {"model_envelope": [264, 248.0, 38, 4.0], "label_envelope": [264, 330.0, 38, 0], "hit_envelope": [264, 248.0, 38, 4.0]}}
- punchline_headliner_night scenario::punchline_headliner_night_credential_runner {"left_stage_wing": {"model_envelope": [264, 248.0, 38, 4.0], "label_envelope": [264, 231.0, 38, 15.0], "hit_envelope": [264, 248.0, 38, 4.0]}}
- punchline_open_mic_night numbers:book {"right_stage_wing": {"model_envelope": [598, 202, 0, 0], "label_envelope": [598, 203.0, 25.0, 26.0], "hit_envelope": [598, 202, 0, 0]}}
- punchline_open_mic_night scenario::punchline_open_mic_night_signup_lectern {"left_stage_wing": {"model_envelope": [264, 202, 4.0, 6.0], "label_envelope": [264, 210.0, 21.0, 26.0], "hit_envelope": [264, 202, 4.0, 6.0]}}
- punchline_open_mic_night scenario::punchline_open_mic_night_open_mic_host {"left_stage_wing": {"model_envelope": [264, 248.0, 38, 4.0], "label_envelope": [264, 330.0, 38, 0], "hit_envelope": [264, 248.0, 38, 4.0]}}
- punchline_raid_jitters scenario::punchline_raid_jitters_clear_bins {"right_stage_wing": {"model_envelope": [644.9999, 222.0, 0, 30.0], "label_envelope": [632.7999, 205.0, 3.2001000000000204, 15.0], "hit_envelope": [644.9999, 222.0, 0, 30.0]}}

No mapped public opaque foreground fronts. Preserve four round tables and296wide apron with dark wings. No invented legs, shelf, long tables or body relocation.

Scope: six initial production-publication states only. No outcomes/lifecycle/art PASS or owner acceptance. Native slot released.

## Fourth table source-shaped reflection option

Actual source outer-table material strip[810,216,4,18] retains all288 native2x pixels in every sampled board and is outside all six label envelopes. A tiny candidate[812,218,2,12] lies inside it. The later fixed side-door primitive startsx814: do not extend this table interpretation pastx814. This may support a director-authored warm material reflection, not legacy timed motion or a new lamp. No all-idle-cycle or final-animation proof.
