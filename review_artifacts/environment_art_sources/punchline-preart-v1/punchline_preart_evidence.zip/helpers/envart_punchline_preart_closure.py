import sys,os,json,hashlib,zipfile,collections
from pathlib import Path
from PIL import Image
sys.dont_write_bytecode=True
W=Path.cwd();E=Path(os.environ['BTH_QA_EVIDENCE_DIR']);R=Path(r'E:/CodexQA/BTH/runs');C=R/'BTH-ENVART-PUNCHLINE-20261114-capture-01/evidence';U=R/'BTH-ENVART-PUNCHLINE-20261114-union-01/evidence';P=R/'BTH-ENVART-PUNCHLINE-20261114-practical-pixels-01/evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((W/'punchline_source_identity.json').read_text());inputs=json.loads((W/'punchline_capture_inputs.json').read_text());u=json.loads((U/'punchline_preart_union.json').read_text());data=json.loads((C/'punchline_preart_metadata.json').read_text())
assert data['checks']==737 and data['findings']==[] and len(data['views'])==6
for rel,h in source['files'].items():assert sha(W/rel)==h,rel
for ref in source['reference_inputs'].values():assert sha(Path(ref['path']))==ref['sha256'],ref['path']
assert sha(Path(r'D:/Projects/Beat-The-House/.tmp/environment-art-layers/data/environments/developer_placement_overrides.json'))==source['files']['data/environments/developer_placement_overrides.json']
centers=[(108,194),(202,222),(704,194),(790,222)];practicals={}; masks={i:[] for i in range(4)}
def runs(coords):
 answer=[]
 for y in sorted(set(y for x,y in coords)):
  xs=sorted(x for x,yy in coords if yy==y)
  if not xs:continue
  start=previous=xs[0]
  for x in xs[1:]:
   if x!=previous+1:answer.append([start,y,previous-start+1,1]);start=x
   previous=x
  answer.append([start,y,previous-start+1,1])
 return answer
def maxrect(coords):
 if not coords:return None
 best=[0,0,0,0];xs=[x for x,y in coords];ys=[y for x,y in coords]
 for y0 in range(min(ys),max(ys)+1):
  keep=set(range(min(xs),max(xs)+1))
  for y1 in range(y0,max(ys)+1):
   keep &= {x for x,y in coords if y==y1}
   for x,_,w,_ in runs({(x,0) for x in keep}):
    h=y1-y0+1
    if w*h>best[2]*best[3]:best=[x,y0,w,h]
 return best
for name,view in data['views'].items():
 im=Image.open(C/(name+'_production_board_1800x860.png')).convert('RGBA');color=im.getpixel((1410,392));assert color[0]>200 and color[1]>100 and color[2]<100
 rows=[]
 for i,(x,y) in enumerate(centers):
  bx,by=2*(x-3),2*(y-15);coords={(xx,yy) for yy in range(by,by+36) for xx in range(bx,bx+12) if im.getpixel((xx,yy))==color};masks[i].append(coords)
  rows.append({'practical':i+1,'center_board':[x,y],'source_rectangle_board':[x-3,y-15,6,18],'total_source_pixels_at_2x':432,'unmodified_core_color_rgba':list(color),'observed_exact_core_color_pixels':len(coords),'non_core_color_pixels':432-len(coords),'surviving_core_pixel_runs':runs(coords),'largest_surviving_pixel_rect':maxrect(coords),'source_png_sha256':sha(C/(name+'_production_board_1800x860.png'))})
 practicals[name]=rows
intersection={}
for i,(x,y) in enumerate(centers):
 common=set.intersection(*masks[i]);box=maxrect(common)
 intersection[str(i+1)]={'all_six_sampled_exact_core_pixels':len(common),'pixel_runs':runs(common),'largest_pixel_rect':box,'largest_board_rect':[v/2 for v in box] if box else None}
guide=Image.open(source['reference_inputs']['provisional_guide']['path']).convert('RGBA');guide_counts=[]
for x,y in centers:
 pix=[guide.getpixel((xx,yy)) for yy in range(2*(y-15),2*(y+3)) for xx in range(2*(x-3),2*(x+3))];guide_counts.append(collections.Counter(pix)[(255,179,45,255)])
assert guide_counts==[432]*4,guide_counts
practical_report={'scope':'Exact painted pixels in six existing full production board captures; no new native run and no model-envelope masks. Count exact scenario-tinted core-color samples, not all perceptually visible/translucently modified lamp pixels. A changed color can be translucent live paint, not full opaque occlusion. Counts are sampled frames, not full idle-cycle proof.','reference_source_color':[255,179,45,255],'guide_unoccluded_source_color_pixels':guide_counts,'contexts':practicals,'intersection_across_six':intersection,'attribution':['Practical1 missing288 and practical3 missing234 Base pixels are source C_SHADOW silhouettes from _draw_punchline_club lines4784-4786, not missing canvas records. The empty guide intentionally omits these noninteractive legacy audience primitives; do not bake them into source. Their partial legacy coverage must not be adopted as a future art mask.','Practical2 has additional live prop/label/glow paint in Open Mic, Bringer and Raid Jitters; exact stable-color count is lower there. Current6 source-derived titles and model records accompany the pixels.','Practical4 has zero retained amber pixels in all six sampled PNGs. Actual pixels show Ox named-character body/arms, with #11131f jacket, #05060a hair, #8f5a48 skin and orange-accent shades from _character_style ox line5289. Actual staff:punchline_bouncer uses fixed_host_ox -> _draw_named_character. This live actor remains with an art pack, unlike omitted procedural audience. No visible fourth-core pulse is demonstrated by these samples.']}
(E/'punchline_practical_painted_visibility.json').write_text(json.dumps(practical_report,indent=2),newline='\n')
layouts=json.loads((W/'data/environments/scenario_slot_layouts.json').read_text())['layouts'];map=inputs['placement_map'];base_slots={slot['id']:slot for collection in ['fixed_slots','event_slots','scenario_slots','exit_slots'] for slot in map.get(collection,[])}
all_rows=[];ambient=[];wing=[]
for name,ctx in u['contexts'].items():
 matching=[x for x in layouts if x.get('map_id')=='small_underground_casino:club' and x.get('scenario_id')==name]
 slots=dict(base_slots)
 for layout in matching:
  for slot in layout.get('slots',layout.get('scenario_slots',[])):slots[slot['id']]=slot
 for row in ctx['rows']:
  m=row['model_rect'];cl=row['placement_class'];point=[m[0]+m[2]/2,m[1]+(m[3]/2 if cl in ['wall_mounted','hanging','doorway'] else m[3])]
  record={'context':name,'id':row['id'],'label':row['label'],'model_rect':m,'label_rect':row['label_rect'],'hit_rect':row['interaction_rect'],'contact_point_board':point,'slot_id':row['slot_id'],'placement_class':cl,'raw_slot_definition':slots.get(row['slot_id'],{}),'slot_source_candidates':matching,'body_draw_layer':row['body_draw_layer']}
  # Slot source candidates are linked rather than repeated whole contexts.
  record['slot_source_candidates']=[{'layout_id':x.get('id'), 'map_id':x.get('map_id'),'scenario_id':x.get('scenario_id')} for x in matching]
  all_rows.append(record)
  if row['id']=='environment_layer:ambient':ambient.append(record)
  crossed={k:v for k,v in row['region_intersections'].items() if k in ['left_stage_wing','right_stage_wing']}
  if crossed:wing.append({**record,'envelope_intersections':crossed})
source_text=(W/'scripts/ui/pixel_scene_canvas.gd').read_text(); snippets={}
for function in ['_draw_punchline_club','_draw_punchline_table','_draw_scene_object_body','_draw_manifest_specific_object','_draw_scene_object_adornments','_draw_disabled_scene_mark','_draw_item_prop','_draw_item_surface','_silhouette','_character_style']:
 lines=source_text.splitlines();start=next(i for i,x in enumerate(lines) if x.startswith('func '+function+'('));end=next((i for i in range(start+1,len(lines)) if lines[i].startswith('func ')),len(lines));snippets[function]={'path':'scripts/ui/pixel_scene_canvas.gd','first_line':start+1,'last_line':end,'text':'\n'.join(lines[start:end])}
closure={'status':'COMPLETE_CURRENT6_PREART_NOT_ART_PASS','commit':source['commit'],'tree':source['tree'],'placement_override_sha256':source['files']['data/environments/developer_placement_overrides.json'],'archive_sha256':source['archive_sha256'],'checks':data['checks'],'findings':data['findings'],'totals':u['totals'],'contexts':list(data['views']),'actual_identity':{'archetype':'small_underground_casino','layer':'club','override_key':'small_underground_casino:club','art_id':'punchline_club','placement_art_key':'comedy_club'},'source_files_verified':len(source['files']),'scope':data['scope'],'scope_limits':['Six initial states only, no work/outcome sweep, no save/revisit or gameplay lifecycle claim.','Transparent ambient-body diagnostic is a production painter attribution aid, not a complete room image or injected performer.','No art generation, guide/renderer/layout changes, target integration, live-site proof or public art PASS.','Source references remain unchanged; Jazz package approval/export is separate.'],'mic_observation':{'conclusion':'All6 actual Tonight Comic records are disabled environment_layer floor_fixture with stage prop, empty character_actor and no asset_path. Production body falls through to generic item fixture/light, not a painted actor/mic/stand. Architectural mic is separate; no duplicate mic was observed. Final target decision remains director-owned.','actual_records':ambient,'diagonal_mark':'Disabled-object adornment _draw_disabled_scene_mark lines8952-8955, not equipment.','label_color':'C_SOFT alpha0.56 because disabled, not the nominal type cyan.'},'stage_supports':{'central_apron':[302,202,296,50],'mapped_stage':[264,202,372,50],'all_contact_surfaces':u['all_contact_surfaces'],'foreground_surfaces':u['foreground_surfaces'],'wing_intersections':wing,'contact_rows':all_rows,'caveat':'These support IDs and contact coordinates are data, not permission for new painted furniture. Wing intersections are model/label/hit envelopes, not exact body-paint masks. Preserve current dark wings/central apron; no widening, legs or relocation inferred. Labels extend into wings in current contexts even where body contacts do not.'},'procedural_audience':{'classification':'Noninteractive legacy baked audience from room painter, deliberately omitted by empty guide; not missing current canvas records and not future source-art content.','calls':[{'position':[122,168],'scale':0.72,'line':4784},{'position':[716,166],'scale':0.78,'line':4785},{'position':[798,192],'scale':0.66,'line':4786}],'painter':'_silhouette at10365: head circle plus body and arm rectangles.'},'practical_pixel_report':{'path':str(E/'punchline_practical_painted_visibility.json'),'sha256':sha(E/'punchline_practical_painted_visibility.json'),'intersection_across_six':intersection},'source_snippets':snippets,'capture_metadata_sha256':sha(C/'punchline_preart_metadata.json'),'union_sha256':sha(U/'punchline_preart_union.json'),'native_release':'Import and capture Jobs exited0 with active_at_release0 before collector. No more Godot planned.','reference_inputs':source['reference_inputs']}
assert all(x['raw_slot_definition'] for x in all_rows),[(x['context'],x['slot_id']) for x in all_rows if not x['raw_slot_definition']]
(E/'punchline_preart_closure.json').write_text(json.dumps(closure,indent=2),newline='\n')
lines=['# Public Punchline current6 pre-art closure','',f"737 checks, zero findings. {u['totals']['actual_canvas_objects']} actual canvas rows and selected titles;30 Runtime visual records;5 explicit authored exclusions.",'',closure['mic_observation']['conclusion'],'','The diagonal over Tonight Comic is the disabled status mark, not a second microphone. The dark table-side silhouettes are procedural legacy audience, omitted from the empty guide; they are not missing live canvas records.','',practical_report['scope'],'','## Practical exact amber pixels /432 at2x']
for name,rows in practicals.items():lines.append('- '+name+': '+', '.join(str(x['observed_exact_core_color_pixels']) for x in rows))
lines += ['','Live Ox fully covers practical4 at every captured frame. Do not claim a visible fourth pulse from this evidence. Practical1/3 legacy silhouette coverage is not a future pack mask.','', '## Stage wing model/label/hit envelopes']
for x in wing:lines.append('- '+x['context']+' '+x['id']+' '+json.dumps(x['envelope_intersections']))
lines += ['', 'No mapped public opaque foreground fronts. Preserve four round tables and296wide apron with dark wings. No invented legs, shelf, long tables or body relocation.', '', 'Scope: six initial production-publication states only. No outcomes/lifecycle/art PASS or owner acceptance. Native slot released.']
(E/'punchline_preart_closure.md').write_text('\n'.join(lines),newline='\n')
files={}
def add(path,arc):assert path.is_file(),path;files[arc]=path
for rel in inputs['source_hashes']:add(W/rel,'source/'+rel)
for p in W.glob('tools/envart_punchline_*'):
 if p.is_file():add(p,'helpers/'+p.name)
for name in ['punchline_adapter.py','punchline_source_identity.json','punchline_capture_inputs.json','punchline_preart_plan.md']:add(W/name,'helpers/'+name)
for p in C.iterdir():
 if p.is_file():add(p,'capture/'+p.name)
for p in U.iterdir():
 if p.is_file():add(p,'union/'+p.name)
for p in P.iterdir():
 if p.is_file():add(p,'practical_analysis/'+p.name)
for run in ['source-archive-01','source-extract-01','prep-01','import-01']:
 for name in ['job.json','worker.log','launch-claim.json','storage-manifest.json']:
  p=R/('BTH-ENVART-PUNCHLINE-20261114-'+run)/'evidence'/name
  if p.exists():add(p,'receipts/'+run+'/'+name)
for p in list(E.glob('punchline_*')):add(p,'closure/'+p.name)
manifest={arc:{'sha256':sha(path),'bytes':path.stat().st_size} for arc,path in files.items()};(E/'bundle_manifest.json').write_text(json.dumps(manifest,indent=2),newline='\n');add(E/'bundle_manifest.json','bundle_manifest.json')
with zipfile.ZipFile(E/'punchline_preart_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for arc,p in files.items():z.write(p,arc)
print(json.dumps({'status':closure['status'],'checks':737,'totals':u['totals'],'practical_counts':{n:[x['observed_exact_core_color_pixels'] for x in rows] for n,rows in practicals.items()},'practical_intersection_maxrects':{k:v['largest_board_rect'] for k,v in intersection.items()},'bundle_files_before_collector_receipts':len(files)},indent=2))