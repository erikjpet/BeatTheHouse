import os,json,hashlib,zipfile
from pathlib import Path
W=Path.cwd();E=Path(os.environ['BTH_QA_EVIDENCE_DIR']);R=Path(r'E:/CodexQA/BTH/runs');O=R/'BTH-ENVART-PUNCHLINE-20261114-closure-01/evidence';N=R/'BTH-ENVART-PUNCHLINE-20261114-practical-rim-01/evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
closure=json.loads((O/'punchline_preart_closure.json').read_text());rim=json.loads((N/'punchline_fourth_table_rim_pixels.json').read_text())
closure['fourth_table_reflection_candidate']={'path':str(N/'punchline_fourth_table_rim_pixels.json'),'sha256':sha(N/'punchline_fourth_table_rim_pixels.json'),'actual_source_material_strip_board':[810,216,4,18],'tiny_candidate_subset_board':[812,218,2,12],'all_six_same_material_pixels':288,'all_six_label_envelopes_clear':True,'door_clip':'The later fixed side-door primitive begins at x814 and covers the rest of this candidate vicinity. Do not extend this table-material interpretation past x814.','scope':'Sampled pixel evidence only. Possible director-authored warm material reflection representing hidden practical4, not legacy timed motion. No table/Ox movement, new prop, final animation proof or whole-idle-cycle guarantee.'}
closure['collector_notes']=['Closure01 worker passed and drained. Its supervisor then stopped before receipt append because storage extra_write_paths mistakenly passed an existing file rather than its evidence directory. Closure01 retained untouched. Closure02 makes the bounded final package and validates the evidence directory before appending only its completed owned receipt. No launch restriction or capacity failure was bypassed.']
(E/'punchline_preart_closure.json').write_text(json.dumps(closure,indent=2),newline='\n')
md=(O/'punchline_preart_closure.md').read_text()+'\n\n## Fourth table source-shaped reflection option\n\nActual source outer-table material strip[810,216,4,18] retains all288 native2x pixels in every sampled board and is outside all six label envelopes. A tiny candidate[812,218,2,12] lies inside it. The later fixed side-door primitive startsx814: do not extend this table interpretation pastx814. This may support a director-authored warm material reflection, not legacy timed motion or a new lamp. No all-idle-cycle or final-animation proof.\n'
(E/'punchline_preart_closure.md').write_text(md,newline='\n')
entries={}
with zipfile.ZipFile(O/'punchline_preart_evidence.zip') as old:
 for name in old.namelist():
  if name in ['bundle_manifest.json','closure/punchline_preart_closure.json','closure/punchline_preart_closure.md']:continue
  entries[name]=old.read(name)
for name in ['punchline_preart_closure.json','punchline_preart_closure.md']:entries['closure/'+name]=(E/name).read_bytes()
for p in N.iterdir():
 if p.is_file():entries['practical_rim/'+p.name]=p.read_bytes()
for name in ['job.json','worker.log','launch-claim.json','storage-manifest.json']:entries['collector01_receipts/'+name]=(O/name).read_bytes()
entries['helpers/envart_punchline_preart_seal.py']=Path(__file__).read_bytes()
manifest={name:{'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload)} for name,payload in entries.items()};(E/'bundle_manifest.json').write_text(json.dumps(manifest,indent=2),newline='\n');entries['bundle_manifest.json']=(E/'bundle_manifest.json').read_bytes()
with zipfile.ZipFile(E/'punchline_preart_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,payload in entries.items():z.writestr(name,payload)
print(json.dumps({'status':closure['status'],'checks':closure['checks'],'findings':closure['findings'],'totals':closure['totals'],'fourth_table_strip':closure['fourth_table_reflection_candidate'],'members_before_sealing_receipts':len(entries)},indent=2))