# Public Punchline pre-art capture plan

{
  "status": "PREPARED_SOURCE_ONLY_PENDING_ENGINE_GO",
  "commit": "ab0b49deeab019deac7ef30b79b17f86ffbc521d",
  "tree": "de6973f05fac17cb19fe03f26c5bc0a00f4cdd5b",
  "archive_sha256": "846fb2b54ad0af5584a21c53ab08253568737b12b504737354b3efa744396c85",
  "placement_override_sha256": "c5c9808497ee3d4f056bb5a7f24a64524d4e59ee50e3fff106eb41e09383245f",
  "source_files_verified": 7092,
  "contexts": [
    "__none",
    "punchline_open_mic_night",
    "punchline_headliner_night",
    "punchline_bringer_show",
    "punchline_debt_court",
    "punchline_raid_jitters"
  ],
  "nonpublic_scenarios_excluded": [
    "punchline_high_stakes_night",
    "punchline_greased_week",
    "punchline_new_muscle"
  ],
  "files": {
    "punchline_adapter.py": "0fcddedb2872c36f05dcfbe8921396c646aab446c92e9e4a0ab0d538b2177864",
    "punchline_capture_inputs.json": "b2607f62a38fa581dd15bf3980442d87e8409d36979212b8cae899a65dae16b7",
    "punchline_source_identity.json": "fb03165da612bb149c37e142e990f159f3c59db6b1fb36cd3c0d28587267b754",
    "tools\\envart_punchline_comic_diagnostic.gd": "1140804469b3bf5ef78830dcf830fa5c8387aa980ab34f2083a7cab60ff272e6",
    "tools\\envart_punchline_preart_metadata.gd": "02a513c70b6ba196fea00b1a05230a3a4c98ca5b6cabe6270f7ce09fa6bff647",
    "tools\\envart_punchline_preart_union.py": "e9e25719e077480a92e3c823c3d1d192201b6174b233ad4236c96e165878a416"
  },
  "mic_decision": "PENDING actual full-context pixels and transparent production-body diagnostic. No removal, new geometry, source art or motion claim made.",
  "source_observations": [
    "Default layer club; exact scenario layer wins in the practice contract. Debt Court layer_id is club despite its casino hook flag.",
    "Tonight Comic is source ambient_label on club and ambient_prop stage, published environment_layer:ambient. Actual canvas type/painter remains to be observed.",
    "Public _draw_punchline_club has fixed mic stem and head, four round table bodies and center296 apron.",
    "Public has no dedicated scene-life branch; basement smoke/string lights/glints are separate dispatch.",
    "Public placement map has zero foreground_art_id counters."
  ],
  "scope": "Source/catalog/helper preparation only. No Godot/import/runtime/PNG capture; no target/source-art edits, user-save reads, gameplay lifecycle coverage, or art PASS."
}

After explicit ENGINE GO: cold import with one worker thread, then bounded native Base plus five current club scenarios using normal practice, same-initial-state Engine commit and RunState publication; wait natural arrivals; assert actual public identity, publication/visual/canvas/geometry/title chain; save complete context and native2x board PNGs plus clearly distinct ambient-body diagnostic. Build union with declared hidden/non-room/hosted exclusions. Inspect actual pixels before reporting mic/stage-wing implications. Bundle exact helpers, source identity, union, PNGs and owned-Job receipts. No art-source generation or guide edits.
