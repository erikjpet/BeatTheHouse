import os,sys,json,hashlib,shutil,math
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,r"D:\Projects\Beat-The-House\.tmp\environment-art-layers\tools")
from bth_qa_storage import Layout,validate_layout
from PIL import Image,ImageDraw
m=json.loads((Path(os.environ["BTH_QA_EVIDENCE_DIR"])/"storage-manifest.json").read_text())
layout=Layout(**{k:Path(v) for k,v in m["paths"].items()},run_id=m["run_id"],token=m["token"],prepared=True,expected_write_bytes=m["expected_write_bytes"],reserve_bytes=m["reserve_bytes"])
old=layout.workspace/"packages/gas_station_casino-v3-r7";r9=layout.workspace/"packages/gas_station_casino-v3-r9";root=layout.workspace/"packages/gas_station_casino-v3-r12"
validate_layout(layout,extra_write_paths=(root,));assert not root.exists();root.mkdir()
for part in ("assets","data"):shutil.copytree(old/part,root/part)
prev=json.loads((old/"package-seal.json").read_text());asset=root/"assets/art/environments/gas_station_casino"
refpath=Path(r"E:\CodexQA\BTH\workspaces\BTH-ENVART-ARTIST-20261114\gas_station_casino-v1\inputs\original-proof-background-afd2bab7.png")
refraw=refpath.read_bytes();assert hashlib.sha256(refraw).hexdigest()=="afd2bab7d8c6300abda5ce26e5eefe13a807a6daabcacb30d704563397f69880"
ref=Image.open(refpath).convert("RGB").resize((900,430),Image.Resampling.NEAREST)
s=Image.open(asset/"background.png").convert("RGB").resize((900,430),Image.Resampling.NEAREST)
q9=Image.open(r9/"assets/art/environments/gas_station_casino/background.png").convert("RGB").resize((900,430),Image.Resampling.NEAREST)
b=q9.copy()
def clamp(v):return max(0,min(255,round(v)))
def recolor(im,fun):
    z=im.copy();p=z.load()
    for y in range(z.height):
        for x in range(z.width):p[x,y]=fun(p[x,y],x,y)
    return z
# Dominant reference material: broad brightly separated plum masonry, exact existing wall field.
b.paste(ref.crop((0,86,900,248)),(0,86))
# Remove reference's structural tail below the immutable current column endpoints.
for x0,x1 in ((88,116),(408,438),(766,798)):
    b.paste(ref.crop((320,212,320+x1-x0,244)),(x0,212))
# Authored current support contacts remain solid/detailed, not reference placeholder faces.
for a in ((16,164,884,175),(318,74,424,90),(530,74,638,90),(658,74,766,90),(786,74,886,90),(406,190,514,206)):
    b.paste(q9.crop(a),a[:2])
# Reference-derived floor perspective, removing baked dashes, old rail/post bodies before current replay.
floor=ref.crop((0,248,900,430));fp=floor.load();rp=ref.load();sp=s.load()
def floor_sample(x,y):
    target_y=344+(y%17)
    xp=453+(x-453)*(.3*target_y-34)/(.3*y-34)
    return rp[max(0,min(899,round(xp))),target_y]
for yy in range(182):
    y=yy+248
    for x in range(900):
        r,g,bl=fp[x,yy]
        old_bottom=100<=x<800 and 393<=y<414
        dashed=377<=y<386 and r>g*2.1 and r>bl*1.05 and r>85
        old_post=any(a<=x<z for a,z in ((113,125),(447,459),(780,794))) and 254<=y<327
        if old_bottom or dashed:rgb=floor_sample(x,y)
        elif old_post:rgb=rp[min(899,x+18),y]
        else:rgb=(r,g,bl)
        # Fine current matte scuffs remain in the material, reference dominates rather than another grade.
        cr,cg,cb=sp[x,y];detail=(cr*1.12,cg*.76,cb*1.08)
        fp[x,yy]=tuple(clamp(rgb[i]*.88+detail[i]*.12) for i in range(3))
b.paste(floor,(0,248))
# Current detailed window frame and clean road-glass, recolored toward rich reference purple.
window=q9.crop((46,92,314,196));wp=window.load()
for y in range(window.height):
    for x in range(window.width):
        r,g,bl=wp[x,y];gx=x+46;gy=y+92
        if 56<=gx<302 and 103<=gy<186:
            # Keep current actual road details, no frozen car/headlight lines from reference.
            if not (78<=gx<174 and 103<=gy<121):
                wp[x,y]=(clamp(r*1.25+10),clamp(g*.90+4),clamp(bl*1.35+16))
        else:
            if max(r,g,bl)>48:wp[x,y]=(clamp(r*1.15+10),clamp(g*1.10+8),clamp(bl*1.12+14))
b.paste(window,(46,92))
# Strong separated lavender-gray column planes; current rivets/chips and exact silhouettes retained.
for x0,x1 in ((89,115),(409,435),(766,798)):
    col=s.crop((x0,0,x1,212));p=col.load();w=col.width
    for y in range(212):
        for x in range(w):
            r,g,bl=p[x,y];lum=r*.25+g*.5+bl*.25
            if max(r,g,bl)<24:
                p[x,y]=(clamp(r*.9),clamp(g*.7),clamp(bl*1.05));continue
            if y>=196 and r>g*1.18 and bl>r*.65:
                p[x,y]=(clamp(r*1.9+15),clamp(g*.65+4),clamp(bl*1.35+12));continue
            if x<4 or x>w-3:base=(190,172,222)
            elif x<round(w*.67):base=(131,114,184)
            else:base=(77,60,114)
            residual=(lum-54)*.55
            p[x,y]=tuple(clamp(v+residual) for v in base)
            if min(r,g,bl)>112:p[x,y]=(clamp(r*1.12+35),clamp(g*1.15+30),clamp(bl*1.10+35))
    b.paste(col,(x0,0))
# Reapply exact clean camera housing/monitor support, excluding the historical frozen ray.
camera=q9.crop((716,68,764,100));b.paste(camera,(716,68))
b.paste(q9.crop((406,190,514,206)),(406,190))  # Exact attendant ledge must occlude column.
b.paste(window,(46,92))  # Window naturally occludes the fixed columns behind it.
# Full unambiguous ochre/brass cage perimeter and existing bar facets, not barely warm gray.
cage=s.crop((656,100,832,232));cp=cage.load()
def gold(c):
    r,g,bl=c;v=r*.25+g*.5+bl*.25
    if max(c)<21:return (16,9,24)
    if v<38:return (clamp(54+v*.7),clamp(24+v*.40),clamp(21+v*.25))
    if v<80:return (clamp(112+v*1.0),clamp(62+v*.80),clamp(28+v*.35))
    return (clamp(166+v*.63),clamp(118+v*.64),clamp(47+v*.44))
for y in range(cage.height):
    for x in range(cage.width):
        gx=x+656;gy=y+100;c=cp[x,y];r,g,bl=c
        border=(gx<666 or gx>=821 or gy<112 or gy>=221)
        # Existing thin bar facets are selected by near-neutral material pixels inside glass.
        bar=(668<=gx<820 and 112<=gy<221 and any(abs(gx-k)<=2 for k in range(672,810,18)) and max(c)>54 and max(c)-min(c)<52)
        if border or bar:cp[x,y]=gold(c)
        else:cp[x,y]=(clamp(r*1.04+3),clamp(g*.88+2),clamp(bl*1.16+7))
b.paste(cage,(656,100))
# Detailed current thin rails/feet replace source's thick neon-ended placeholder supports.
for a in ((100,244,800,254),(100,400,800,408),(116,254,120,322),(450,254,454,322),(784,254,788,322),(113,322,124,326),(447,322,458,326),(781,322,792,326)):
    piece=s.crop(a)
    def metal(c,x,y):
        r,g,bl=c;v=max(c)
        if v<22:return (clamp(r*.9),clamp(g*.8),clamp(bl*1.1))
        if g>r*1.3 and bl>r*1.3:return (clamp(r+22),clamp(g*1.35+15),clamp(bl*1.35+15))
        return (clamp(r*1.40+15),clamp(g*1.35+13),clamp(bl*1.40+20))
    b.paste(recolor(piece,metal),a[:2])
# Crisp small pastel cyan/pink/white fascia cores, unchanged dimensions and masked around columns.
bp=b.load()
for y in range(70,78):
    for x in range(900):
        r,g,bl=sp[x,y]
        if g>r*1.4 and bl>r*1.4 and max(g,bl)>35:bp[x,y]=(75,215,233) if y in (70,77) else (19,155,184)
        elif r>g*1.6 and bl>g*1.4 and r>24:bp[x,y]=(226,60,175) if y in (73,74) else (170,27,117)
# Coherent quiet matte backing behind live labels, no moved text or support.
for a in ((320,80,424,96),(532,80,636,96),(660,80,764,96),(788,80,884,96)):
    for y in range(a[1],a[3]):
        for x in range(a[0],a[2]):
            r,g,bl=bp[x,y]
            # Keep physical lip and gold trim untouched, darken the lower wall backing coherently.
            if y>=88:bp[x,y]=(clamp(r*.38),clamp(g*.38),clamp(bl*.46))
# Pale physical Parking ledge face, with its exact rim/footprint and coherent painted wall bay beneath.
for y in range(80,88):
    for x in range(320,424):
        r,g,bl=sp[x,y];v=max(r,g,bl)
        if y==80 or y==87:
            bp[x,y]=(221,201,184) if v>60 else (77,59,86)
        else:
            t=(r+g+bl)/3-35
            bp[x,y]=(clamp(192+t*.30),clamp(179+t*.28),clamp(202+t*.30))
for y in range(88,96):
    for x in range(308,412):
        r,g,bl=rp[x,y]
        mortar=max(r,g,bl)<48
        base=(160,146,171) if mortar else (191,178,200)
        t=(r+g+bl)/3-45
        bp[x,y]=tuple(clamp(v+t*.20) for v in base)
b.resize((1800,860),Image.Resampling.NEAREST).save(asset/"background.png");b.save(root/"background-board-review.png")
b.crop((532,80,636,88)).resize((208,16),Image.Resampling.NEAREST).convert("RGBA").save(asset/"counters/gas_station_staff_window.png")
# Same motion shapes/alphas/cadence, with bright compact honey-white cores and reference trim colors.
for path in (asset/"anim").glob("*.png"):
    im=Image.open(path).convert("RGBA");p=im.load()
    if path.name=="fluorescent_tube.png":
        for y in range(im.height):
            for x in range(im.width):
                r,g,bl,a=p[x,y]
                if a and r>70 and r>bl*1.3:p[x,y]=(clamp(r*1.08),clamp(min(g*.65+r*.61,clamp(r*1.08)*.94)),clamp(min(bl*.5+r*.57,clamp(r*1.08)*.72)),a)
        im.save(path)
    elif path.name=="neon_fascia.png":
        for y in range(im.height):
            for x in range(im.width):
                r,g,bl,a=p[x,y]
                if a:
                    p[x,y]=(255,104,231,a) if r>g*2 else (112,255,255,a)
        im.save(path)
sources=dict(prev["sources"]);sources["dominant_original_reference_material"]={"path":str(refpath),"sha256":hashlib.sha256(refraw).hexdigest(),"size":[1800,860],"role":"Frozen original material/design source underlying owner-supplied screenshot. Baked moving subjects and person excluded."}
changes=prev["changes"]+[
"Latest owner requires majority supplied design influence, brighter sharp pixel art and a conspicuous gold cage border. R8/R9 do not pass this new direction.",
"Original preferred screenshot background is now the dominant brick/floor pattern source, not a subtle grade. Current detailed fixtures, empty glass, live geometry and solid counter stay.",
"Broad plum brick bays, distinct lavender-gray column planes, full ochre/brass cage perimeter/bar facets and bright compact honey-white/pastel light cores.",
"Richer purple highway glass keeps current clean road details and separated moving headlights. No reference frozen ray, frozen streaks or baked person copied.",
"Reference-derived perspective floor retains fine current scuffs but removes fixed marker dashes and old thick neon posts; exact current thin rails/feet replayed.",
"All14 existing motion entries, alpha, placement, speed, clock, Reduce Motion and six motifs retained. Only fascia/tube texture colors changed.",
"Quiet dark contact/wall backing under live labels preserved without moving text, objects or contact geometry.",
"R12 narrow cleanup: floor donor texture follows measured original joints x=453+k*(0.3*y-34); exact ledge restored over column; honey-white core hue clamp; pale physical Parking ledge/wall paint for unchanged glyph contrast. This is a sealed trial requiring independent actual-runtime director/auditor approval; no implementation implied."
]
files={}
for path in sorted(list((root/"assets").rglob("*.png"))+list((root/"data").rglob("*.json"))):
    key=path.relative_to(root).as_posix();data=path.read_bytes();e={"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)}
    if path.suffix==".png":
        im=Image.open(path);e.update(size=list(im.size),mode=im.mode)
        if im.mode=="RGBA":e["alpha_extrema"]=im.getchannel("A").getextrema()
    files[key]=e
sha=hashlib.sha256("\n".join(k+" "+v["sha256"] for k,v in sorted(files.items())).encode()).hexdigest()
seal={"package_id":"gas_station_casino-v3-r12","status":"SEALED_STYLE_TRIAL_NOT_PASSED","package_sha256":sha,"files":files,"sources":sources,"changes":changes,"parent_package_sha256":prev["package_sha256"],"owner_reference":{"library_file_id":"owner-reference-library-id-omitted","sha256":"0d804084cebfdd578ad79a479951bf65ba497be9257027fbd0b2182fb29dbbe7","inspection":"Actual pixels viewed by auditor and director on supported cloud materialization."}}
(root/"package-seal.json").write_text(json.dumps(seal,indent=2));(root/"edit-record.json").write_text(json.dumps(seal,indent=2))
print(json.dumps({"root":str(root),"sha256":sha,"background_sha256":files["assets/art/environments/gas_station_casino/background.png"]["sha256"],"status":"SEALED_STYLE_TRIAL_NOT_PASSED"}))
